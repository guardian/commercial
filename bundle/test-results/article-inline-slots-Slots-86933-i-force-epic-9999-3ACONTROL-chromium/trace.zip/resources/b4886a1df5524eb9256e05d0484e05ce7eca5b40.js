"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["Prebid.js"],{

/***/ "./src/lib/header-bidding/prebid/pbjs.ts":
/*!***********************************************!*\
  !*** ./src/lib/header-bidding/prebid/pbjs.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   pbjs: () => (/* reexport safe */ prebid_js__WEBPACK_IMPORTED_MODULE_0__["default"])
/* harmony export */ });
/* harmony import */ var prebid_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prebid.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/prebid.js");
/* harmony import */ var prebid_js_modules_consentManagementTcf__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prebid.js/modules/consentManagementTcf */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/consentManagementTcf.js");
/* harmony import */ var prebid_js_modules_consentManagementUsp__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prebid.js/modules/consentManagementUsp */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/consentManagementUsp.js");
/* harmony import */ var prebid_js_modules_consentManagementGpp__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prebid.js/modules/consentManagementGpp */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/consentManagementGpp.js");
/* harmony import */ var prebid_js_modules_criteoBidAdapter__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prebid.js/modules/criteoBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/criteoBidAdapter.js");
/* harmony import */ var prebid_js_modules_gridBidAdapter__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! prebid.js/modules/gridBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/gridBidAdapter.js");
/* harmony import */ var prebid_js_modules_ixBidAdapter__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! prebid.js/modules/ixBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/ixBidAdapter.js");
/* harmony import */ var prebid_js_modules_ozoneBidAdapter__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! prebid.js/modules/ozoneBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/ozoneBidAdapter.js");
/* harmony import */ var prebid_js_modules_pubmaticBidAdapter__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! prebid.js/modules/pubmaticBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/pubmaticBidAdapter.js");
/* harmony import */ var prebid_js_modules_tripleliftBidAdapter__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! prebid.js/modules/tripleliftBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/tripleliftBidAdapter.js");
/* harmony import */ var prebid_js_modules_kargoBidAdapter__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! prebid.js/modules/kargoBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/kargoBidAdapter.js");
/* harmony import */ var prebid_js_modules_rubiconBidAdapter__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! prebid.js/modules/rubiconBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/rubiconBidAdapter.js");
/* harmony import */ var prebid_js_modules_ttdBidAdapter__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! prebid.js/modules/ttdBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/ttdBidAdapter.js");
/* harmony import */ var prebid_js_modules_id5IdSystem__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! prebid.js/modules/id5IdSystem */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/id5IdSystem.js");
/* harmony import */ var prebid_js_modules_sharedIdSystem__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! prebid.js/modules/sharedIdSystem */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/sharedIdSystem.js");
/* harmony import */ var prebid_js_modules_userId__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! prebid.js/modules/userId */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/userId/index.js");
/* harmony import */ var prebid_js_modules_rtdModule__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! prebid.js/modules/rtdModule */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/rtdModule/index.js");
/* harmony import */ var prebid_js_modules_permutiveRtdProvider__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! prebid.js/modules/permutiveRtdProvider */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/permutiveRtdProvider.js");
/* harmony import */ var _modules_appnexusBidAdapter__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./modules/appnexusBidAdapter */ "./src/lib/header-bidding/prebid/modules/appnexusBidAdapter.ts");
/* harmony import */ var _modules_openxBidAdapter__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./modules/openxBidAdapter */ "./src/lib/header-bidding/prebid/modules/openxBidAdapter.ts");
/* harmony import */ var _modules_analyticsAdapter__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./modules/analyticsAdapter */ "./src/lib/header-bidding/prebid/modules/analyticsAdapter.ts");

// Consent management



// Bid adapters









// User IDs



// Real time data


// Guardian specific adapters that we have modified or created



prebid_js__WEBPACK_IMPORTED_MODULE_0__["default"].processQueue();


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uUHJlYmlkLmpzLmNvbW1lcmNpYWwuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE2QjtBQUM3QjtBQUNnRDtBQUNBO0FBQ0E7QUFDaEQ7QUFDNEM7QUFDRjtBQUNGO0FBQ0c7QUFDRztBQUNFO0FBQ0w7QUFDRTtBQUNKO0FBQ3pDO0FBQ3VDO0FBQ0c7QUFDUjtBQUNsQztBQUNxQztBQUNXO0FBQ2hEO0FBQ3NDO0FBQ0g7QUFDQztBQUNwQ0EsaURBQUksQ0FBQ0MsWUFBWSxDQUFDLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2hlYWRlci1iaWRkaW5nL3ByZWJpZC9wYmpzLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBwYmpzIGZyb20gJ3ByZWJpZC5qcyc7XG4vLyBDb25zZW50IG1hbmFnZW1lbnRcbmltcG9ydCAncHJlYmlkLmpzL21vZHVsZXMvY29uc2VudE1hbmFnZW1lbnRUY2YnO1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy9jb25zZW50TWFuYWdlbWVudFVzcCc7XG5pbXBvcnQgJ3ByZWJpZC5qcy9tb2R1bGVzL2NvbnNlbnRNYW5hZ2VtZW50R3BwJztcbi8vIEJpZCBhZGFwdGVyc1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy9jcml0ZW9CaWRBZGFwdGVyJztcbmltcG9ydCAncHJlYmlkLmpzL21vZHVsZXMvZ3JpZEJpZEFkYXB0ZXInO1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy9peEJpZEFkYXB0ZXInO1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy9vem9uZUJpZEFkYXB0ZXInO1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy9wdWJtYXRpY0JpZEFkYXB0ZXInO1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy90cmlwbGVsaWZ0QmlkQWRhcHRlcic7XG5pbXBvcnQgJ3ByZWJpZC5qcy9tb2R1bGVzL2thcmdvQmlkQWRhcHRlcic7XG5pbXBvcnQgJ3ByZWJpZC5qcy9tb2R1bGVzL3J1Ymljb25CaWRBZGFwdGVyJztcbmltcG9ydCAncHJlYmlkLmpzL21vZHVsZXMvdHRkQmlkQWRhcHRlcic7XG4vLyBVc2VyIElEc1xuaW1wb3J0ICdwcmViaWQuanMvbW9kdWxlcy9pZDVJZFN5c3RlbSc7XG5pbXBvcnQgJ3ByZWJpZC5qcy9tb2R1bGVzL3NoYXJlZElkU3lzdGVtJztcbmltcG9ydCAncHJlYmlkLmpzL21vZHVsZXMvdXNlcklkJztcbi8vIFJlYWwgdGltZSBkYXRhXG5pbXBvcnQgJ3ByZWJpZC5qcy9tb2R1bGVzL3J0ZE1vZHVsZSc7XG5pbXBvcnQgJ3ByZWJpZC5qcy9tb2R1bGVzL3Blcm11dGl2ZVJ0ZFByb3ZpZGVyJztcbi8vIEd1YXJkaWFuIHNwZWNpZmljIGFkYXB0ZXJzIHRoYXQgd2UgaGF2ZSBtb2RpZmllZCBvciBjcmVhdGVkXG5pbXBvcnQgJy4vbW9kdWxlcy9hcHBuZXh1c0JpZEFkYXB0ZXInO1xuaW1wb3J0ICcuL21vZHVsZXMvb3BlbnhCaWRBZGFwdGVyJztcbmltcG9ydCAnLi9tb2R1bGVzL2FuYWx5dGljc0FkYXB0ZXInO1xucGJqcy5wcm9jZXNzUXVldWUoKTtcbmV4cG9ydCB7IHBianMgfTtcbiJdLCJuYW1lcyI6WyJwYmpzIiwicHJvY2Vzc1F1ZXVlIl0sInNvdXJjZVJvb3QiOiIifQ==