"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["src_init_consented_remove-slots_ts-src_lib_error_report-error_ts-core_src_event-timer_ts"],{

/***/ "../core/src/event-timer.ts":
/*!**********************************!*\
  !*** ../core/src/event-timer.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EventTimer: () => (/* binding */ EventTimer),
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   supportsPerformanceAPI: () => (/* binding */ supportsPerformanceAPI)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var supportsPerformanceAPI = () => typeof window !== 'undefined' && typeof window.performance !== 'undefined' && typeof window.performance.mark === 'function';
// Events will be logged using the performance API for all slots, but only these slots will be tracked as commercial metrics and sent to the data lake
var trackedSlots = ['top-above-nav', 'inline1', 'inline2', 'fronts-banner-1', 'fronts-banner-2'];
// marks that we want to save as commercial metrics
var slotMarks = ['slotReady', 'adRenderStart', 'prebidStart', 'adOnPage', 'viewable'];
// measures that we want to save as commercial metrics
var slotMeasures = ['adRender', 'defineSlot', 'prepareSlot', 'prebid', 'fetchAd'];
var pageMarks = ['commercialStart', 'commercialModulesLoaded'];
// measures that we want to save as commercial metrics
var pageMeasures = ['commercialBoot', 'googletagInit'];
// all marks, including the measure start and end marks
var allSlotMarks = [...slotMarks, ...slotMeasures.map(measure => "".concat(measure, "Start")), ...slotMeasures.map(measure => "".concat(measure, "End"))];
var externalMarks = ['cmp-init', 'cmp-ui-displayed', 'cmp-got-consent'];
var shouldSave = name => {
  var [origin, type] = name.split('_');
  if (!type) {
    type = origin;
    origin = 'page';
  }
  var shouldSaveMark = trackedSlots.includes(origin) && slotMarks.includes(type) || origin === 'page' && pageMarks.includes(type);
  var shouldSaveMeasure = trackedSlots.includes(origin) && slotMeasures.includes(type) || origin === 'page' && pageMeasures.includes(type);
  return shouldSaveMark || shouldSaveMeasure;
};
class EventTimer {
  /**
   * Initialise the EventTimer class on page.
   * Returns the singleton instance of the EventTimer class and binds
   * to window.guardian.commercialTimer. If it's been previously
   * initialised and bound it returns the original instance
   * Note: We save to window.guardian.commercialTimer because
   * different bundles (DCR / DCP) can use commercial, and we want
   * all timer events saved to a single instance per-page
   * @returns {EventTimer} Instance of EventTimer
   */
  static init() {
    var _window$guardian, _window$guardian$comm;
    return (_window$guardian$comm = (_window$guardian = window.guardian).commercialTimer) !== null && _window$guardian$comm !== void 0 ? _window$guardian$comm : _window$guardian.commercialTimer = new EventTimer();
  }
  /**
   * Just a helper method to access the singleton instance of EventTimer.
   * Typical use case is EventTimer.get().trigger
   */
  static get() {
    return this.init();
  }
  /**
   * These are marks that are not triggered by commercial but we are interested in
   * tracking their performance. For example, CMP-related events.
   **/
  get _externalMarks() {
    if (!supportsPerformanceAPI()) {
      return new Map();
    }
    return externalMarks.reduce((map, mark) => {
      var entries = window.performance.getEntriesByName(mark);
      if (entries.length && entries[0]) {
        map.set(mark, entries[0]);
      }
      return map;
    }, new Map());
  }
  /**
   * Returns all performance marks that should be saved as commercial metrics.
   */
  get marks() {
    return [...this._marks, ...this._externalMarks].map(_ref => {
      var [name, timer] = _ref;
      return {
        name,
        ts: timer.startTime
      };
    });
  }
  /**
   * Returns all performance measures that should be saved as commercial metrics.
   */
  get measures() {
    return [...this._measures].map(_ref2 => {
      var [name, measure] = _ref2;
      return {
        name,
        duration: measure.duration
      };
    });
  }
  constructor() {
    _defineProperty(this, "_marks", void 0);
    _defineProperty(this, "_measures", void 0);
    _defineProperty(this, "properties", void 0);
    this._marks = new Map();
    this._measures = new Map();
    this.properties = {};
    if (window.navigator.connection) {
      this.properties.type = window.navigator.connection.type;
      this.properties.downlink = window.navigator.connection.downlink;
      this.properties.effectiveType = window.navigator.connection.effectiveType;
    }
  }
  /**
   * Adds a non timer measurement
   *
   * @param {string} name - the property's name
   * @param value - the property's value
   */
  setProperty(name, value) {
    this.properties[name] = value;
  }
  /**
   * Creates a new performance mark, and if the mark ends with 'End' it will
   * create a performance measure between the start and end marks.
   *
   * Marks can  be triggered multiple times, but we only save the first
   * instance of a mark, as things like ad refreshes can trigger the same mark.
   *
   * More info on the performance API:
   * https://developer.mozilla.org/en-US/docs/Web/API/Performance/mark
   * https://developer.mozilla.org/en-US/docs/Web/API/Performance/measure
   *
   * @todo more strict typing for eventName and origin
   * @param eventName The short name applied to the mark
   * @param origin - Either 'page' (default) or the name of the slot
   */
  mark(eventName) {
    var origin = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'page';
    var name = eventName;
    if (allSlotMarks.includes(eventName) && origin !== 'page') {
      name = "".concat(origin, "_").concat(name);
    }
    if (!!this._marks.get(name) || !supportsPerformanceAPI()) {
      return;
    }
    var mark = window.performance.mark(name);
    if (
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- browser support is patchy
    typeof (mark === null || mark === void 0 ? void 0 : mark.startTime) === 'number' &&
    // we only want to save the marks that are related to certain slots or the page
    shouldSave(name)) {
      this._marks.set(name, mark);
    }
    if (name.endsWith('End')) {
      this.measure(name);
    }
  }
  /**
   * Creates a performance measure given the name of the end marks.
   * The start mark is inferred from the end mark.
   *
   * @param endMark - The name of the mark that ends the measure
   **/
  measure(endMark) {
    var startMark = endMark.replace('End', 'Start');
    var measureName = endMark.replace('End', '');
    var startMarkExists = window.performance.getEntriesByName(startMark).length > 0;
    if (startMarkExists) {
      try {
        var measure = window.performance.measure(measureName, startMark, endMark);
        // we only want to save the measures that are related to certain slots or the page
        if (measure && shouldSave(measureName)) {
          this._measures.set(measureName, measure);
        }
      } catch (e) {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "error measuring ".concat(measureName), e);
      }
    }
  }
}
var _ = {
  slotMarks,
  slotMeasures,
  trackedSlots
};


/***/ }),

/***/ "./src/init/consented/remove-slots.ts":
/*!********************************************!*\
  !*** ./src/init/consented/remove-slots.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   removeDisabledSlots: () => (/* binding */ removeDisabledSlots),
/* harmony export */   removeSlots: () => (/* binding */ removeSlots)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");




// Remove ad slots
var selectors = [_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__.dfpEnv.adSlotSelector, '.top-banner-ad-container', '.top-fronts-banner-ad-container', '.ad-slot-container'];
var selectNodes = () => selectors.reduce((nodes, selector) => [...nodes, ...Array.from(document.querySelectorAll(selector))], []);
var isDisabled = node => window.getComputedStyle(node).display === 'none';
var filterDisabledNodes = nodes => nodes.filter(isDisabled);
var removeNodes = nodes => _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_3__["default"].mutate(() => nodes.forEach(node => {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "Removing ad slot: ".concat(node.id));
  node.remove();
}));
var removeSlots = () => {
  return removeNodes(selectNodes());
};
/**
 * Remove ad slot elements that have style display: none
 */
var removeDisabledSlots = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(() => removeNodes(filterDisabledNodes(selectNodes())));


/***/ }),

/***/ "./src/lib/dfp/dfp-env.ts":
/*!********************************!*\
  !*** ./src/lib/dfp/dfp-env.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dfpEnv: () => (/* binding */ dfpEnv)
/* harmony export */ });
/* harmony import */ var _detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _url__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../url */ "./src/lib/url.ts");
var _window$guardian$comm;


var getUrlVars = _url__WEBPACK_IMPORTED_MODULE_1__.getUrlVars;
var dfpEnv = {
  /* renderStartTime: integer. Point in time when DFP kicks in */
  renderStartTime: -1,
  /* adSlotSelector: string. A CSS selector to query ad slots in the DOM */
  adSlotSelector: '.js-ad-slot',
  /* lazyLoadEnabled: boolean. Set to true when adverts are lazy-loaded */
  lazyLoadEnabled: false,
  /* lazyLoadObserve: boolean. Use IntersectionObserver in supporting browsers */
  lazyLoadObserve: 'IntersectionObserver' in window,
  /* advertsToLoad - Lists adverts waiting to be loaded */
  advertsToLoad: [],
  /* adverts - Keeps track of adverts and their state */
  adverts: new Map(),
  /* shouldLazyLoad: () -> boolean. Determines whether ads should be lazy loaded */
  shouldLazyLoad() {
    if (getUrlVars().dll === '1') {
      return false;
    }
    if (['mobile', 'tablet'].includes((0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_0__.getCurrentBreakpoint)())) {
      return true;
    }
    if (window.guardian.config.page.hasPageSkin) {
      return false;
    }
    return true;
  }
};
window.guardian.commercial = (_window$guardian$comm = window.guardian.commercial) !== null && _window$guardian$comm !== void 0 ? _window$guardian$comm : {};
// expose this on the window, for use by debugger tools
window.guardian.commercial.dfpEnv = dfpEnv;


/***/ }),

/***/ "./src/lib/error/report-error.ts":
/*!***************************************!*\
  !*** ./src/lib/error/report-error.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   reportError: () => (/* binding */ reportError),
/* harmony export */   wrapWithErrorReporting: () => (/* binding */ wrapWithErrorReporting)
/* harmony export */ });
/**
 * This function is used to report errors to Sentry
 * It uses the function `window.guardian.modules.sentry.reportError` set by DCR
 */
var reportError = function (error, feature) {
  var tags = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var extras = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : {};
  try {
    var _window$guardian$modu;
    var err = error instanceof Error ? error : new Error(String(error));
    if ((_window$guardian$modu = window.guardian.modules.sentry) !== null && _window$guardian$modu !== void 0 && _window$guardian$modu.reportError) {
      window.guardian.modules.sentry.reportError(err, feature, tags, extras);
    }
  } catch (e) {
    console.error('Error reporting error to Sentry', e, feature, tags);
  }
};
var wrapWithErrorReporting = function (fn) {
  var tags = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var extras = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  return function (event) {
    try {
      fn(event);
    } catch (e) {
      reportError(e, 'commercial', tags, extras);
    }
  };
};


/***/ }),

/***/ "./src/lib/fastdom-promise.ts":
/*!************************************!*\
  !*** ./src/lib/fastdom-promise.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fastdom */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/fastdom.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fastdom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var fastdom_extensions_fastdom_promised__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! fastdom/extensions/fastdom-promised */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/extensions/fastdom-promised.js");
/* harmony import */ var fastdom_extensions_fastdom_promised__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fastdom_extensions_fastdom_promised__WEBPACK_IMPORTED_MODULE_1__);


/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (fastdom__WEBPACK_IMPORTED_MODULE_0___default().extend((fastdom_extensions_fastdom_promised__WEBPACK_IMPORTED_MODULE_1___default())));

/***/ }),

/***/ "./src/lib/url.ts":
/*!************************!*\
  !*** ./src/lib/url.ts ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getUrlVars: () => (/* binding */ getUrlVars),
/* harmony export */   pbTestNameMap: () => (/* binding */ pbTestNameMap)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/memoize.js");

/**
 * Commercial Testing Instrument
 *
 * Returns a map { <bidderName>: true } of bidders
 * according to the pbtest URL parameter
 */
var pbTestNameMap = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(() => new URLSearchParams(window.location.search).getAll('pbtest').reduce((acc, value) => {
  acc[value] = true;
  return acc;
}, {}), () =>
// Same implicit parameter as the memoized function
window.location.search);
var queryStringToUrlVars = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(queryString => Array.from(new URLSearchParams(queryString).entries()) // polyfill.io guarantees URLSearchParams
.reduce((acc, _ref) => {
  var [key, value] = _ref;
  acc[key] = value === '' ? true : value;
  return acc;
}, {}));
/**
 * returns a map of querystrings
 * eg ?foo=bar&fizz=buzz returns {foo: 'bar', fizz: 'buzz'}
 * ?foo=bar&foo=baz returns {foo: 'baz'}
 * ?foo returns { foo: true }
 */
var getUrlVars = query => queryStringToUrlVars(query !== null && query !== void 0 ? query : window.location.search);


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uc3JjX2luaXRfY29uc2VudGVkX3JlbW92ZS1zbG90c190cy1zcmNfbGliX2Vycm9yX3JlcG9ydC1lcnJvcl90cy1jb3JlX3NyY19ldmVudC10aW1lcl90cy5jb21tZXJjaWFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBcUM7QUFDckMsSUFBTUMsc0JBQXNCLEdBQUdBLENBQUEsS0FBTSxPQUFPQyxNQUFNLEtBQUssV0FBVyxJQUM5RCxPQUFPQSxNQUFNLENBQUNDLFdBQVcsS0FBSyxXQUFXLElBQ3pDLE9BQU9ELE1BQU0sQ0FBQ0MsV0FBVyxDQUFDQyxJQUFJLEtBQUssVUFBVTtBQUNqRDtBQUNBLElBQU1DLFlBQVksR0FBRyxDQUNqQixlQUFlLEVBQ2YsU0FBUyxFQUNULFNBQVMsRUFDVCxpQkFBaUIsRUFDakIsaUJBQWlCLENBQ3BCO0FBQ0Q7QUFDQSxJQUFNQyxTQUFTLEdBQUcsQ0FDZCxXQUFXLEVBQ1gsZUFBZSxFQUNmLGFBQWEsRUFDYixVQUFVLEVBQ1YsVUFBVSxDQUNiO0FBQ0Q7QUFDQSxJQUFNQyxZQUFZLEdBQUcsQ0FDakIsVUFBVSxFQUNWLFlBQVksRUFDWixhQUFhLEVBQ2IsUUFBUSxFQUNSLFNBQVMsQ0FDWjtBQUNELElBQU1DLFNBQVMsR0FBRyxDQUFDLGlCQUFpQixFQUFFLHlCQUF5QixDQUFDO0FBQ2hFO0FBQ0EsSUFBTUMsWUFBWSxHQUFHLENBQUMsZ0JBQWdCLEVBQUUsZUFBZSxDQUFDO0FBQ3hEO0FBQ0EsSUFBTUMsWUFBWSxHQUFHLENBQ2pCLEdBQUdKLFNBQVMsRUFDWixHQUFHQyxZQUFZLENBQUNJLEdBQUcsQ0FBRUMsT0FBTyxPQUFBQyxNQUFBLENBQVFELE9BQU8sVUFBTyxDQUFDLEVBQ25ELEdBQUdMLFlBQVksQ0FBQ0ksR0FBRyxDQUFFQyxPQUFPLE9BQUFDLE1BQUEsQ0FBUUQsT0FBTyxRQUFLLENBQUMsQ0FDcEQ7QUFDRCxJQUFNRSxhQUFhLEdBQUcsQ0FDbEIsVUFBVSxFQUNWLGtCQUFrQixFQUNsQixpQkFBaUIsQ0FDcEI7QUFDRCxJQUFNQyxVQUFVLEdBQUlDLElBQUksSUFBSztFQUN6QixJQUFJLENBQUNDLE1BQU0sRUFBRUMsSUFBSSxDQUFDLEdBQUdGLElBQUksQ0FBQ0csS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUNwQyxJQUFJLENBQUNELElBQUksRUFBRTtJQUNQQSxJQUFJLEdBQUdELE1BQU07SUFDYkEsTUFBTSxHQUFHLE1BQU07RUFDbkI7RUFDQSxJQUFNRyxjQUFjLEdBQUlmLFlBQVksQ0FBQ2dCLFFBQVEsQ0FBQ0osTUFBTSxDQUFDLElBQ2pEWCxTQUFTLENBQUNlLFFBQVEsQ0FBQ0gsSUFBSSxDQUFDLElBQ3ZCRCxNQUFNLEtBQUssTUFBTSxJQUFJVCxTQUFTLENBQUNhLFFBQVEsQ0FBQ0gsSUFBSSxDQUFFO0VBQ25ELElBQU1JLGlCQUFpQixHQUFJakIsWUFBWSxDQUFDZ0IsUUFBUSxDQUFDSixNQUFNLENBQUMsSUFDcERWLFlBQVksQ0FBQ2MsUUFBUSxDQUFDSCxJQUFJLENBQUMsSUFDMUJELE1BQU0sS0FBSyxNQUFNLElBQUlSLFlBQVksQ0FBQ1ksUUFBUSxDQUFDSCxJQUFJLENBQUU7RUFDdEQsT0FBT0UsY0FBYyxJQUFJRSxpQkFBaUI7QUFDOUMsQ0FBQztBQUNELE1BQU1DLFVBQVUsQ0FBQztFQUliO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0ksT0FBT0MsSUFBSUEsQ0FBQSxFQUFHO0lBQUEsSUFBQUMsZ0JBQUEsRUFBQUMscUJBQUE7SUFDVixRQUFBQSxxQkFBQSxHQUFRLENBQUFELGdCQUFBLEdBQUF2QixNQUFNLENBQUN5QixRQUFRLEVBQUNDLGVBQWUsY0FBQUYscUJBQUEsY0FBQUEscUJBQUEsR0FBL0JELGdCQUFBLENBQWdCRyxlQUFlLEdBQUssSUFBSUwsVUFBVSxDQUFDLENBQUM7RUFDaEU7RUFDQTtBQUNKO0FBQ0E7QUFDQTtFQUNJLE9BQU9NLEdBQUdBLENBQUEsRUFBRztJQUNULE9BQU8sSUFBSSxDQUFDTCxJQUFJLENBQUMsQ0FBQztFQUN0QjtFQUNBO0FBQ0o7QUFDQTtBQUNBO0VBQ0ksSUFBSU0sY0FBY0EsQ0FBQSxFQUFHO0lBQ2pCLElBQUksQ0FBQzdCLHNCQUFzQixDQUFDLENBQUMsRUFBRTtNQUMzQixPQUFPLElBQUk4QixHQUFHLENBQUMsQ0FBQztJQUNwQjtJQUNBLE9BQU9qQixhQUFhLENBQUNrQixNQUFNLENBQUMsQ0FBQ3JCLEdBQUcsRUFBRVAsSUFBSSxLQUFLO01BQ3ZDLElBQU02QixPQUFPLEdBQUcvQixNQUFNLENBQUNDLFdBQVcsQ0FBQytCLGdCQUFnQixDQUFDOUIsSUFBSSxDQUFDO01BQ3pELElBQUk2QixPQUFPLENBQUNFLE1BQU0sSUFBSUYsT0FBTyxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQzlCdEIsR0FBRyxDQUFDeUIsR0FBRyxDQUFDaEMsSUFBSSxFQUFFNkIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQzdCO01BQ0EsT0FBT3RCLEdBQUc7SUFDZCxDQUFDLEVBQUUsSUFBSW9CLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDakI7RUFDQTtBQUNKO0FBQ0E7RUFDSSxJQUFJTSxLQUFLQSxDQUFBLEVBQUc7SUFDUixPQUFPLENBQUMsR0FBRyxJQUFJLENBQUNDLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQ1IsY0FBYyxDQUFDLENBQUNuQixHQUFHLENBQUM0QixJQUFBO01BQUEsSUFBQyxDQUFDdkIsSUFBSSxFQUFFd0IsS0FBSyxDQUFDLEdBQUFELElBQUE7TUFBQSxPQUFNO1FBQ3BFdkIsSUFBSTtRQUNKeUIsRUFBRSxFQUFFRCxLQUFLLENBQUNFO01BQ2QsQ0FBQztJQUFBLENBQUMsQ0FBQztFQUNQO0VBQ0E7QUFDSjtBQUNBO0VBQ0ksSUFBSUMsUUFBUUEsQ0FBQSxFQUFHO0lBQ1gsT0FBTyxDQUFDLEdBQUcsSUFBSSxDQUFDQyxTQUFTLENBQUMsQ0FBQ2pDLEdBQUcsQ0FBQ2tDLEtBQUE7TUFBQSxJQUFDLENBQUM3QixJQUFJLEVBQUVKLE9BQU8sQ0FBQyxHQUFBaUMsS0FBQTtNQUFBLE9BQU07UUFDakQ3QixJQUFJO1FBQ0o4QixRQUFRLEVBQUVsQyxPQUFPLENBQUNrQztNQUN0QixDQUFDO0lBQUEsQ0FBQyxDQUFDO0VBQ1A7RUFDQUMsV0FBV0EsQ0FBQSxFQUFHO0lBQUFDLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQ1YsSUFBSSxDQUFDVixNQUFNLEdBQUcsSUFBSVAsR0FBRyxDQUFDLENBQUM7SUFDdkIsSUFBSSxDQUFDYSxTQUFTLEdBQUcsSUFBSWIsR0FBRyxDQUFDLENBQUM7SUFDMUIsSUFBSSxDQUFDa0IsVUFBVSxHQUFHLENBQUMsQ0FBQztJQUNwQixJQUFJL0MsTUFBTSxDQUFDZ0QsU0FBUyxDQUFDQyxVQUFVLEVBQUU7TUFDN0IsSUFBSSxDQUFDRixVQUFVLENBQUMvQixJQUFJLEdBQUdoQixNQUFNLENBQUNnRCxTQUFTLENBQUNDLFVBQVUsQ0FBQ2pDLElBQUk7TUFDdkQsSUFBSSxDQUFDK0IsVUFBVSxDQUFDRyxRQUFRLEdBQUdsRCxNQUFNLENBQUNnRCxTQUFTLENBQUNDLFVBQVUsQ0FBQ0MsUUFBUTtNQUMvRCxJQUFJLENBQUNILFVBQVUsQ0FBQ0ksYUFBYSxHQUN6Qm5ELE1BQU0sQ0FBQ2dELFNBQVMsQ0FBQ0MsVUFBVSxDQUFDRSxhQUFhO0lBQ2pEO0VBQ0o7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSUMsV0FBV0EsQ0FBQ3RDLElBQUksRUFBRXVDLEtBQUssRUFBRTtJQUNyQixJQUFJLENBQUNOLFVBQVUsQ0FBQ2pDLElBQUksQ0FBQyxHQUFHdUMsS0FBSztFQUNqQztFQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJbkQsSUFBSUEsQ0FBQ29ELFNBQVMsRUFBbUI7SUFBQSxJQUFqQnZDLE1BQU0sR0FBQXdDLFNBQUEsQ0FBQXRCLE1BQUEsUUFBQXNCLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsTUFBTTtJQUMzQixJQUFJekMsSUFBSSxHQUFHd0MsU0FBUztJQUNwQixJQUFJOUMsWUFBWSxDQUFDVyxRQUFRLENBQUNtQyxTQUFTLENBQUMsSUFBSXZDLE1BQU0sS0FBSyxNQUFNLEVBQUU7TUFDdkRELElBQUksTUFBQUgsTUFBQSxDQUFNSSxNQUFNLE9BQUFKLE1BQUEsQ0FBSUcsSUFBSSxDQUFFO0lBQzlCO0lBQ0EsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDc0IsTUFBTSxDQUFDVCxHQUFHLENBQUNiLElBQUksQ0FBQyxJQUFJLENBQUNmLHNCQUFzQixDQUFDLENBQUMsRUFBRTtNQUN0RDtJQUNKO0lBQ0EsSUFBTUcsSUFBSSxHQUFHRixNQUFNLENBQUNDLFdBQVcsQ0FBQ0MsSUFBSSxDQUFDWSxJQUFJLENBQUM7SUFDMUM7SUFDQTtJQUNBLFFBQU9aLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFc0MsU0FBUyxNQUFLLFFBQVE7SUFDL0I7SUFDQTNCLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDLEVBQUU7TUFDbEIsSUFBSSxDQUFDc0IsTUFBTSxDQUFDRixHQUFHLENBQUNwQixJQUFJLEVBQUVaLElBQUksQ0FBQztJQUMvQjtJQUNBLElBQUlZLElBQUksQ0FBQzJDLFFBQVEsQ0FBQyxLQUFLLENBQUMsRUFBRTtNQUN0QixJQUFJLENBQUMvQyxPQUFPLENBQUNJLElBQUksQ0FBQztJQUN0QjtFQUNKO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0lKLE9BQU9BLENBQUNnRCxPQUFPLEVBQUU7SUFDYixJQUFNQyxTQUFTLEdBQUdELE9BQU8sQ0FBQ0UsT0FBTyxDQUFDLEtBQUssRUFBRSxPQUFPLENBQUM7SUFDakQsSUFBTUMsV0FBVyxHQUFHSCxPQUFPLENBQUNFLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDO0lBQzlDLElBQU1FLGVBQWUsR0FBRzlELE1BQU0sQ0FBQ0MsV0FBVyxDQUFDK0IsZ0JBQWdCLENBQUMyQixTQUFTLENBQUMsQ0FBQzFCLE1BQU0sR0FBRyxDQUFDO0lBQ2pGLElBQUk2QixlQUFlLEVBQUU7TUFDakIsSUFBSTtRQUNBLElBQU1wRCxPQUFPLEdBQUdWLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDUyxPQUFPLENBQUNtRCxXQUFXLEVBQUVGLFNBQVMsRUFBRUQsT0FBTyxDQUFDO1FBQzNFO1FBQ0EsSUFBSWhELE9BQU8sSUFBSUcsVUFBVSxDQUFDZ0QsV0FBVyxDQUFDLEVBQUU7VUFDcEMsSUFBSSxDQUFDbkIsU0FBUyxDQUFDUixHQUFHLENBQUMyQixXQUFXLEVBQUVuRCxPQUFPLENBQUM7UUFDNUM7TUFDSixDQUFDLENBQ0QsT0FBT3FELENBQUMsRUFBRTtRQUNOakUsbURBQUcsQ0FBQyxZQUFZLHFCQUFBYSxNQUFBLENBQXFCa0QsV0FBVyxHQUFJRSxDQUFDLENBQUM7TUFDMUQ7SUFDSjtFQUNKO0FBQ0o7QUFDQSxJQUFNQyxDQUFDLEdBQUc7RUFDTjVELFNBQVM7RUFDVEMsWUFBWTtFQUNaRjtBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDck1vQztBQUNKO0FBQ2M7QUFDQztBQUNoRDtBQUNBLElBQU1pRSxTQUFTLEdBQUcsQ0FDZEYsb0RBQU0sQ0FBQ0csY0FBYyxFQUNyQiwwQkFBMEIsRUFDMUIsaUNBQWlDLEVBQ2pDLG9CQUFvQixDQUN2QjtBQUNELElBQU1DLFdBQVcsR0FBR0EsQ0FBQSxLQUFNRixTQUFTLENBQUN0QyxNQUFNLENBQUMsQ0FBQ3lDLEtBQUssRUFBRUMsUUFBUSxLQUFLLENBQzVELEdBQUdELEtBQUssRUFDUixHQUFHRSxLQUFLLENBQUNDLElBQUksQ0FBQ0MsUUFBUSxDQUFDQyxnQkFBZ0IsQ0FBQ0osUUFBUSxDQUFDLENBQUMsQ0FDckQsRUFBRSxFQUFFLENBQUM7QUFDTixJQUFNSyxVQUFVLEdBQUlDLElBQUksSUFBSzlFLE1BQU0sQ0FBQytFLGdCQUFnQixDQUFDRCxJQUFJLENBQUMsQ0FBQ0UsT0FBTyxLQUFLLE1BQU07QUFDN0UsSUFBTUMsbUJBQW1CLEdBQUlWLEtBQUssSUFBS0EsS0FBSyxDQUFDVyxNQUFNLENBQUNMLFVBQVUsQ0FBQztBQUMvRCxJQUFNTSxXQUFXLEdBQUlaLEtBQUssSUFBS0osNERBQU8sQ0FBQ2lCLE1BQU0sQ0FBQyxNQUFNYixLQUFLLENBQUNjLE9BQU8sQ0FBRVAsSUFBSSxJQUFLO0VBQ3hFaEYsbURBQUcsQ0FBQyxZQUFZLHVCQUFBYSxNQUFBLENBQXVCbUUsSUFBSSxDQUFDUSxFQUFFLENBQUUsQ0FBQztFQUNqRFIsSUFBSSxDQUFDUyxNQUFNLENBQUMsQ0FBQztBQUNqQixDQUFDLENBQUMsQ0FBQztBQUNILElBQU1DLFdBQVcsR0FBR0EsQ0FBQSxLQUFNO0VBQ3RCLE9BQU9MLFdBQVcsQ0FBQ2IsV0FBVyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBTW1CLG1CQUFtQixHQUFHeEIscURBQUksQ0FBQyxNQUFNa0IsV0FBVyxDQUFDRixtQkFBbUIsQ0FBQ1gsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNCcEI7QUFDaEI7QUFDbkQsSUFBTXFCLFVBQVUsR0FBR0MsNENBQVc7QUFDOUIsSUFBTTFCLE1BQU0sR0FBRztFQUNYO0VBQ0EyQixlQUFlLEVBQUUsQ0FBQyxDQUFDO0VBQ25CO0VBQ0F4QixjQUFjLEVBQUUsYUFBYTtFQUM3QjtFQUNBeUIsZUFBZSxFQUFFLEtBQUs7RUFDdEI7RUFDQUMsZUFBZSxFQUFFLHNCQUFzQixJQUFJL0YsTUFBTTtFQUNqRDtFQUNBZ0csYUFBYSxFQUFFLEVBQUU7RUFDakI7RUFDQUMsT0FBTyxFQUFFLElBQUlwRSxHQUFHLENBQUMsQ0FBQztFQUNsQjtFQUNBcUUsY0FBY0EsQ0FBQSxFQUFHO0lBQ2IsSUFBSVAsVUFBVSxDQUFDLENBQUMsQ0FBQ1EsR0FBRyxLQUFLLEdBQUcsRUFBRTtNQUMxQixPQUFPLEtBQUs7SUFDaEI7SUFDQSxJQUFJLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDaEYsUUFBUSxDQUFDdUUsK0VBQW9CLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDdkQsT0FBTyxJQUFJO0lBQ2Y7SUFDQSxJQUFJMUYsTUFBTSxDQUFDeUIsUUFBUSxDQUFDMkUsTUFBTSxDQUFDQyxJQUFJLENBQUNDLFdBQVcsRUFBRTtNQUN6QyxPQUFPLEtBQUs7SUFDaEI7SUFDQSxPQUFPLElBQUk7RUFDZjtBQUNKLENBQUM7QUFDRHRHLE1BQU0sQ0FBQ3lCLFFBQVEsQ0FBQzhFLFVBQVUsSUFBQS9FLHFCQUFBLEdBQUd4QixNQUFNLENBQUN5QixRQUFRLENBQUM4RSxVQUFVLGNBQUEvRSxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsQ0FBQztBQUM3RDtBQUNBeEIsTUFBTSxDQUFDeUIsUUFBUSxDQUFDOEUsVUFBVSxDQUFDckMsTUFBTSxHQUFHQSxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7O0FDaEMxQztBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1zQyxXQUFXLEdBQUcsU0FBQUEsQ0FBQ0MsS0FBSyxFQUFFQyxPQUFPLEVBQTZCO0VBQUEsSUFBM0JDLElBQUksR0FBQXBELFNBQUEsQ0FBQXRCLE1BQUEsUUFBQXNCLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQUEsSUFBRXFELE1BQU0sR0FBQXJELFNBQUEsQ0FBQXRCLE1BQUEsUUFBQXNCLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQ3ZELElBQUk7SUFBQSxJQUFBc0QscUJBQUE7SUFDQSxJQUFNQyxHQUFHLEdBQUdMLEtBQUssWUFBWU0sS0FBSyxHQUFHTixLQUFLLEdBQUcsSUFBSU0sS0FBSyxDQUFDQyxNQUFNLENBQUNQLEtBQUssQ0FBQyxDQUFDO0lBQ3JFLEtBQUFJLHFCQUFBLEdBQUk3RyxNQUFNLENBQUN5QixRQUFRLENBQUN3RixPQUFPLENBQUNDLE1BQU0sY0FBQUwscUJBQUEsZUFBOUJBLHFCQUFBLENBQWdDTCxXQUFXLEVBQUU7TUFDN0N4RyxNQUFNLENBQUN5QixRQUFRLENBQUN3RixPQUFPLENBQUNDLE1BQU0sQ0FBQ1YsV0FBVyxDQUFDTSxHQUFHLEVBQUVKLE9BQU8sRUFBRUMsSUFBSSxFQUFFQyxNQUFNLENBQUM7SUFDMUU7RUFDSixDQUFDLENBQ0QsT0FBTzdDLENBQUMsRUFBRTtJQUNOb0QsT0FBTyxDQUFDVixLQUFLLENBQUMsaUNBQWlDLEVBQUUxQyxDQUFDLEVBQUUyQyxPQUFPLEVBQUVDLElBQUksQ0FBQztFQUN0RTtBQUNKLENBQUM7QUFDRCxJQUFNUyxzQkFBc0IsR0FBRyxTQUFBQSxDQUFDQyxFQUFFLEVBQTZCO0VBQUEsSUFBM0JWLElBQUksR0FBQXBELFNBQUEsQ0FBQXRCLE1BQUEsUUFBQXNCLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQUEsSUFBRXFELE1BQU0sR0FBQXJELFNBQUEsQ0FBQXRCLE1BQUEsUUFBQXNCLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQ3RELE9BQU8sVUFBVStELEtBQUssRUFBRTtJQUNwQixJQUFJO01BQ0FELEVBQUUsQ0FBQ0MsS0FBSyxDQUFDO0lBQ2IsQ0FBQyxDQUNELE9BQU92RCxDQUFDLEVBQUU7TUFDTnlDLFdBQVcsQ0FBQ3pDLENBQUMsRUFBRSxZQUFZLEVBQUU0QyxJQUFJLEVBQUVDLE1BQU0sQ0FBQztJQUM5QztFQUNKLENBQUM7QUFDTCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEI2QjtBQUNvQztBQUNsRSxpRUFBZXpDLHFEQUFjLENBQUNvRCw0RUFBZSxDQUFDLEU7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGVjtBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNRyxhQUFhLEdBQUdELHFEQUFPLENBQUMsTUFBTSxJQUFJRSxlQUFlLENBQUMzSCxNQUFNLENBQUM0SCxRQUFRLENBQUNDLE1BQU0sQ0FBQyxDQUMxRUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUNoQmhHLE1BQU0sQ0FBQyxDQUFDaUcsR0FBRyxFQUFFMUUsS0FBSyxLQUFLO0VBQ3hCMEUsR0FBRyxDQUFDMUUsS0FBSyxDQUFDLEdBQUcsSUFBSTtFQUNqQixPQUFPMEUsR0FBRztBQUNkLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ1I7QUFDQS9ILE1BQU0sQ0FBQzRILFFBQVEsQ0FBQ0MsTUFBTSxDQUFDO0FBQ3ZCLElBQU1HLG9CQUFvQixHQUFHUCxxREFBTyxDQUFFUSxXQUFXLElBQUt4RCxLQUFLLENBQUNDLElBQUksQ0FBQyxJQUFJaUQsZUFBZSxDQUFDTSxXQUFXLENBQUMsQ0FBQ2xHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUFBLENBQ3hHRCxNQUFNLENBQUMsQ0FBQ2lHLEdBQUcsRUFBQTFGLElBQUEsS0FBbUI7RUFBQSxJQUFqQixDQUFDNkYsR0FBRyxFQUFFN0UsS0FBSyxDQUFDLEdBQUFoQixJQUFBO0VBQzFCMEYsR0FBRyxDQUFDRyxHQUFHLENBQUMsR0FBRzdFLEtBQUssS0FBSyxFQUFFLEdBQUcsSUFBSSxHQUFHQSxLQUFLO0VBQ3RDLE9BQU8wRSxHQUFHO0FBQ2QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNcEMsVUFBVSxHQUFJd0MsS0FBSyxJQUFLSCxvQkFBb0IsQ0FBQ0csS0FBSyxhQUFMQSxLQUFLLGNBQUxBLEtBQUssR0FBSW5JLE1BQU0sQ0FBQzRILFFBQVEsQ0FBQ0MsTUFBTSxDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL2NvcmUvc3JjL2V2ZW50LXRpbWVyLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRlZC9yZW1vdmUtc2xvdHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9kZnAvZGZwLWVudi50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2Vycm9yL3JlcG9ydC1lcnJvci50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2Zhc3Rkb20tcHJvbWlzZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL3VybC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5jb25zdCBzdXBwb3J0c1BlcmZvcm1hbmNlQVBJID0gKCkgPT4gdHlwZW9mIHdpbmRvdyAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICB0eXBlb2Ygd2luZG93LnBlcmZvcm1hbmNlICE9PSAndW5kZWZpbmVkJyAmJlxuICAgIHR5cGVvZiB3aW5kb3cucGVyZm9ybWFuY2UubWFyayA9PT0gJ2Z1bmN0aW9uJztcbi8vIEV2ZW50cyB3aWxsIGJlIGxvZ2dlZCB1c2luZyB0aGUgcGVyZm9ybWFuY2UgQVBJIGZvciBhbGwgc2xvdHMsIGJ1dCBvbmx5IHRoZXNlIHNsb3RzIHdpbGwgYmUgdHJhY2tlZCBhcyBjb21tZXJjaWFsIG1ldHJpY3MgYW5kIHNlbnQgdG8gdGhlIGRhdGEgbGFrZVxuY29uc3QgdHJhY2tlZFNsb3RzID0gW1xuICAgICd0b3AtYWJvdmUtbmF2JyxcbiAgICAnaW5saW5lMScsXG4gICAgJ2lubGluZTInLFxuICAgICdmcm9udHMtYmFubmVyLTEnLFxuICAgICdmcm9udHMtYmFubmVyLTInLFxuXTtcbi8vIG1hcmtzIHRoYXQgd2Ugd2FudCB0byBzYXZlIGFzIGNvbW1lcmNpYWwgbWV0cmljc1xuY29uc3Qgc2xvdE1hcmtzID0gW1xuICAgICdzbG90UmVhZHknLFxuICAgICdhZFJlbmRlclN0YXJ0JyxcbiAgICAncHJlYmlkU3RhcnQnLFxuICAgICdhZE9uUGFnZScsXG4gICAgJ3ZpZXdhYmxlJyxcbl07XG4vLyBtZWFzdXJlcyB0aGF0IHdlIHdhbnQgdG8gc2F2ZSBhcyBjb21tZXJjaWFsIG1ldHJpY3NcbmNvbnN0IHNsb3RNZWFzdXJlcyA9IFtcbiAgICAnYWRSZW5kZXInLFxuICAgICdkZWZpbmVTbG90JyxcbiAgICAncHJlcGFyZVNsb3QnLFxuICAgICdwcmViaWQnLFxuICAgICdmZXRjaEFkJyxcbl07XG5jb25zdCBwYWdlTWFya3MgPSBbJ2NvbW1lcmNpYWxTdGFydCcsICdjb21tZXJjaWFsTW9kdWxlc0xvYWRlZCddO1xuLy8gbWVhc3VyZXMgdGhhdCB3ZSB3YW50IHRvIHNhdmUgYXMgY29tbWVyY2lhbCBtZXRyaWNzXG5jb25zdCBwYWdlTWVhc3VyZXMgPSBbJ2NvbW1lcmNpYWxCb290JywgJ2dvb2dsZXRhZ0luaXQnXTtcbi8vIGFsbCBtYXJrcywgaW5jbHVkaW5nIHRoZSBtZWFzdXJlIHN0YXJ0IGFuZCBlbmQgbWFya3NcbmNvbnN0IGFsbFNsb3RNYXJrcyA9IFtcbiAgICAuLi5zbG90TWFya3MsXG4gICAgLi4uc2xvdE1lYXN1cmVzLm1hcCgobWVhc3VyZSkgPT4gYCR7bWVhc3VyZX1TdGFydGApLFxuICAgIC4uLnNsb3RNZWFzdXJlcy5tYXAoKG1lYXN1cmUpID0+IGAke21lYXN1cmV9RW5kYCksXG5dO1xuY29uc3QgZXh0ZXJuYWxNYXJrcyA9IFtcbiAgICAnY21wLWluaXQnLFxuICAgICdjbXAtdWktZGlzcGxheWVkJyxcbiAgICAnY21wLWdvdC1jb25zZW50Jyxcbl07XG5jb25zdCBzaG91bGRTYXZlID0gKG5hbWUpID0+IHtcbiAgICBsZXQgW29yaWdpbiwgdHlwZV0gPSBuYW1lLnNwbGl0KCdfJyk7XG4gICAgaWYgKCF0eXBlKSB7XG4gICAgICAgIHR5cGUgPSBvcmlnaW47XG4gICAgICAgIG9yaWdpbiA9ICdwYWdlJztcbiAgICB9XG4gICAgY29uc3Qgc2hvdWxkU2F2ZU1hcmsgPSAodHJhY2tlZFNsb3RzLmluY2x1ZGVzKG9yaWdpbikgJiZcbiAgICAgICAgc2xvdE1hcmtzLmluY2x1ZGVzKHR5cGUpKSB8fFxuICAgICAgICAob3JpZ2luID09PSAncGFnZScgJiYgcGFnZU1hcmtzLmluY2x1ZGVzKHR5cGUpKTtcbiAgICBjb25zdCBzaG91bGRTYXZlTWVhc3VyZSA9ICh0cmFja2VkU2xvdHMuaW5jbHVkZXMob3JpZ2luKSAmJlxuICAgICAgICBzbG90TWVhc3VyZXMuaW5jbHVkZXModHlwZSkpIHx8XG4gICAgICAgIChvcmlnaW4gPT09ICdwYWdlJyAmJiBwYWdlTWVhc3VyZXMuaW5jbHVkZXModHlwZSkpO1xuICAgIHJldHVybiBzaG91bGRTYXZlTWFyayB8fCBzaG91bGRTYXZlTWVhc3VyZTtcbn07XG5jbGFzcyBFdmVudFRpbWVyIHtcbiAgICBfbWFya3M7XG4gICAgX21lYXN1cmVzO1xuICAgIHByb3BlcnRpZXM7XG4gICAgLyoqXG4gICAgICogSW5pdGlhbGlzZSB0aGUgRXZlbnRUaW1lciBjbGFzcyBvbiBwYWdlLlxuICAgICAqIFJldHVybnMgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiB0aGUgRXZlbnRUaW1lciBjbGFzcyBhbmQgYmluZHNcbiAgICAgKiB0byB3aW5kb3cuZ3VhcmRpYW4uY29tbWVyY2lhbFRpbWVyLiBJZiBpdCdzIGJlZW4gcHJldmlvdXNseVxuICAgICAqIGluaXRpYWxpc2VkIGFuZCBib3VuZCBpdCByZXR1cm5zIHRoZSBvcmlnaW5hbCBpbnN0YW5jZVxuICAgICAqIE5vdGU6IFdlIHNhdmUgdG8gd2luZG93Lmd1YXJkaWFuLmNvbW1lcmNpYWxUaW1lciBiZWNhdXNlXG4gICAgICogZGlmZmVyZW50IGJ1bmRsZXMgKERDUiAvIERDUCkgY2FuIHVzZSBjb21tZXJjaWFsLCBhbmQgd2Ugd2FudFxuICAgICAqIGFsbCB0aW1lciBldmVudHMgc2F2ZWQgdG8gYSBzaW5nbGUgaW5zdGFuY2UgcGVyLXBhZ2VcbiAgICAgKiBAcmV0dXJucyB7RXZlbnRUaW1lcn0gSW5zdGFuY2Ugb2YgRXZlbnRUaW1lclxuICAgICAqL1xuICAgIHN0YXRpYyBpbml0KCkge1xuICAgICAgICByZXR1cm4gKHdpbmRvdy5ndWFyZGlhbi5jb21tZXJjaWFsVGltZXIgPz89IG5ldyBFdmVudFRpbWVyKCkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBKdXN0IGEgaGVscGVyIG1ldGhvZCB0byBhY2Nlc3MgdGhlIHNpbmdsZXRvbiBpbnN0YW5jZSBvZiBFdmVudFRpbWVyLlxuICAgICAqIFR5cGljYWwgdXNlIGNhc2UgaXMgRXZlbnRUaW1lci5nZXQoKS50cmlnZ2VyXG4gICAgICovXG4gICAgc3RhdGljIGdldCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuaW5pdCgpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBUaGVzZSBhcmUgbWFya3MgdGhhdCBhcmUgbm90IHRyaWdnZXJlZCBieSBjb21tZXJjaWFsIGJ1dCB3ZSBhcmUgaW50ZXJlc3RlZCBpblxuICAgICAqIHRyYWNraW5nIHRoZWlyIHBlcmZvcm1hbmNlLiBGb3IgZXhhbXBsZSwgQ01QLXJlbGF0ZWQgZXZlbnRzLlxuICAgICAqKi9cbiAgICBnZXQgX2V4dGVybmFsTWFya3MoKSB7XG4gICAgICAgIGlmICghc3VwcG9ydHNQZXJmb3JtYW5jZUFQSSgpKSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IE1hcCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBleHRlcm5hbE1hcmtzLnJlZHVjZSgobWFwLCBtYXJrKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBlbnRyaWVzID0gd2luZG93LnBlcmZvcm1hbmNlLmdldEVudHJpZXNCeU5hbWUobWFyayk7XG4gICAgICAgICAgICBpZiAoZW50cmllcy5sZW5ndGggJiYgZW50cmllc1swXSkge1xuICAgICAgICAgICAgICAgIG1hcC5zZXQobWFyaywgZW50cmllc1swXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gbWFwO1xuICAgICAgICB9LCBuZXcgTWFwKCkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGFsbCBwZXJmb3JtYW5jZSBtYXJrcyB0aGF0IHNob3VsZCBiZSBzYXZlZCBhcyBjb21tZXJjaWFsIG1ldHJpY3MuXG4gICAgICovXG4gICAgZ2V0IG1hcmtzKCkge1xuICAgICAgICByZXR1cm4gWy4uLnRoaXMuX21hcmtzLCAuLi50aGlzLl9leHRlcm5hbE1hcmtzXS5tYXAoKFtuYW1lLCB0aW1lcl0pID0+ICh7XG4gICAgICAgICAgICBuYW1lLFxuICAgICAgICAgICAgdHM6IHRpbWVyLnN0YXJ0VGltZSxcbiAgICAgICAgfSkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBSZXR1cm5zIGFsbCBwZXJmb3JtYW5jZSBtZWFzdXJlcyB0aGF0IHNob3VsZCBiZSBzYXZlZCBhcyBjb21tZXJjaWFsIG1ldHJpY3MuXG4gICAgICovXG4gICAgZ2V0IG1lYXN1cmVzKCkge1xuICAgICAgICByZXR1cm4gWy4uLnRoaXMuX21lYXN1cmVzXS5tYXAoKFtuYW1lLCBtZWFzdXJlXSkgPT4gKHtcbiAgICAgICAgICAgIG5hbWUsXG4gICAgICAgICAgICBkdXJhdGlvbjogbWVhc3VyZS5kdXJhdGlvbixcbiAgICAgICAgfSkpO1xuICAgIH1cbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgdGhpcy5fbWFya3MgPSBuZXcgTWFwKCk7XG4gICAgICAgIHRoaXMuX21lYXN1cmVzID0gbmV3IE1hcCgpO1xuICAgICAgICB0aGlzLnByb3BlcnRpZXMgPSB7fTtcbiAgICAgICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IuY29ubmVjdGlvbikge1xuICAgICAgICAgICAgdGhpcy5wcm9wZXJ0aWVzLnR5cGUgPSB3aW5kb3cubmF2aWdhdG9yLmNvbm5lY3Rpb24udHlwZTtcbiAgICAgICAgICAgIHRoaXMucHJvcGVydGllcy5kb3dubGluayA9IHdpbmRvdy5uYXZpZ2F0b3IuY29ubmVjdGlvbi5kb3dubGluaztcbiAgICAgICAgICAgIHRoaXMucHJvcGVydGllcy5lZmZlY3RpdmVUeXBlID1cbiAgICAgICAgICAgICAgICB3aW5kb3cubmF2aWdhdG9yLmNvbm5lY3Rpb24uZWZmZWN0aXZlVHlwZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvKipcbiAgICAgKiBBZGRzIGEgbm9uIHRpbWVyIG1lYXN1cmVtZW50XG4gICAgICpcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZSAtIHRoZSBwcm9wZXJ0eSdzIG5hbWVcbiAgICAgKiBAcGFyYW0gdmFsdWUgLSB0aGUgcHJvcGVydHkncyB2YWx1ZVxuICAgICAqL1xuICAgIHNldFByb3BlcnR5KG5hbWUsIHZhbHVlKSB7XG4gICAgICAgIHRoaXMucHJvcGVydGllc1tuYW1lXSA9IHZhbHVlO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDcmVhdGVzIGEgbmV3IHBlcmZvcm1hbmNlIG1hcmssIGFuZCBpZiB0aGUgbWFyayBlbmRzIHdpdGggJ0VuZCcgaXQgd2lsbFxuICAgICAqIGNyZWF0ZSBhIHBlcmZvcm1hbmNlIG1lYXN1cmUgYmV0d2VlbiB0aGUgc3RhcnQgYW5kIGVuZCBtYXJrcy5cbiAgICAgKlxuICAgICAqIE1hcmtzIGNhbiAgYmUgdHJpZ2dlcmVkIG11bHRpcGxlIHRpbWVzLCBidXQgd2Ugb25seSBzYXZlIHRoZSBmaXJzdFxuICAgICAqIGluc3RhbmNlIG9mIGEgbWFyaywgYXMgdGhpbmdzIGxpa2UgYWQgcmVmcmVzaGVzIGNhbiB0cmlnZ2VyIHRoZSBzYW1lIG1hcmsuXG4gICAgICpcbiAgICAgKiBNb3JlIGluZm8gb24gdGhlIHBlcmZvcm1hbmNlIEFQSTpcbiAgICAgKiBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUGVyZm9ybWFuY2UvbWFya1xuICAgICAqIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9QZXJmb3JtYW5jZS9tZWFzdXJlXG4gICAgICpcbiAgICAgKiBAdG9kbyBtb3JlIHN0cmljdCB0eXBpbmcgZm9yIGV2ZW50TmFtZSBhbmQgb3JpZ2luXG4gICAgICogQHBhcmFtIGV2ZW50TmFtZSBUaGUgc2hvcnQgbmFtZSBhcHBsaWVkIHRvIHRoZSBtYXJrXG4gICAgICogQHBhcmFtIG9yaWdpbiAtIEVpdGhlciAncGFnZScgKGRlZmF1bHQpIG9yIHRoZSBuYW1lIG9mIHRoZSBzbG90XG4gICAgICovXG4gICAgbWFyayhldmVudE5hbWUsIG9yaWdpbiA9ICdwYWdlJykge1xuICAgICAgICBsZXQgbmFtZSA9IGV2ZW50TmFtZTtcbiAgICAgICAgaWYgKGFsbFNsb3RNYXJrcy5pbmNsdWRlcyhldmVudE5hbWUpICYmIG9yaWdpbiAhPT0gJ3BhZ2UnKSB7XG4gICAgICAgICAgICBuYW1lID0gYCR7b3JpZ2lufV8ke25hbWV9YDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoISF0aGlzLl9tYXJrcy5nZXQobmFtZSkgfHwgIXN1cHBvcnRzUGVyZm9ybWFuY2VBUEkoKSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG1hcmsgPSB3aW5kb3cucGVyZm9ybWFuY2UubWFyayhuYW1lKTtcbiAgICAgICAgaWYgKFxuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVubmVjZXNzYXJ5LWNvbmRpdGlvbiAtLSBicm93c2VyIHN1cHBvcnQgaXMgcGF0Y2h5XG4gICAgICAgIHR5cGVvZiBtYXJrPy5zdGFydFRpbWUgPT09ICdudW1iZXInICYmXG4gICAgICAgICAgICAvLyB3ZSBvbmx5IHdhbnQgdG8gc2F2ZSB0aGUgbWFya3MgdGhhdCBhcmUgcmVsYXRlZCB0byBjZXJ0YWluIHNsb3RzIG9yIHRoZSBwYWdlXG4gICAgICAgICAgICBzaG91bGRTYXZlKG5hbWUpKSB7XG4gICAgICAgICAgICB0aGlzLl9tYXJrcy5zZXQobmFtZSwgbWFyayk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG5hbWUuZW5kc1dpdGgoJ0VuZCcpKSB7XG4gICAgICAgICAgICB0aGlzLm1lYXN1cmUobmFtZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLyoqXG4gICAgICogQ3JlYXRlcyBhIHBlcmZvcm1hbmNlIG1lYXN1cmUgZ2l2ZW4gdGhlIG5hbWUgb2YgdGhlIGVuZCBtYXJrcy5cbiAgICAgKiBUaGUgc3RhcnQgbWFyayBpcyBpbmZlcnJlZCBmcm9tIHRoZSBlbmQgbWFyay5cbiAgICAgKlxuICAgICAqIEBwYXJhbSBlbmRNYXJrIC0gVGhlIG5hbWUgb2YgdGhlIG1hcmsgdGhhdCBlbmRzIHRoZSBtZWFzdXJlXG4gICAgICoqL1xuICAgIG1lYXN1cmUoZW5kTWFyaykge1xuICAgICAgICBjb25zdCBzdGFydE1hcmsgPSBlbmRNYXJrLnJlcGxhY2UoJ0VuZCcsICdTdGFydCcpO1xuICAgICAgICBjb25zdCBtZWFzdXJlTmFtZSA9IGVuZE1hcmsucmVwbGFjZSgnRW5kJywgJycpO1xuICAgICAgICBjb25zdCBzdGFydE1hcmtFeGlzdHMgPSB3aW5kb3cucGVyZm9ybWFuY2UuZ2V0RW50cmllc0J5TmFtZShzdGFydE1hcmspLmxlbmd0aCA+IDA7XG4gICAgICAgIGlmIChzdGFydE1hcmtFeGlzdHMpIHtcbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbWVhc3VyZSA9IHdpbmRvdy5wZXJmb3JtYW5jZS5tZWFzdXJlKG1lYXN1cmVOYW1lLCBzdGFydE1hcmssIGVuZE1hcmspO1xuICAgICAgICAgICAgICAgIC8vIHdlIG9ubHkgd2FudCB0byBzYXZlIHRoZSBtZWFzdXJlcyB0aGF0IGFyZSByZWxhdGVkIHRvIGNlcnRhaW4gc2xvdHMgb3IgdGhlIHBhZ2VcbiAgICAgICAgICAgICAgICBpZiAobWVhc3VyZSAmJiBzaG91bGRTYXZlKG1lYXN1cmVOYW1lKSkge1xuICAgICAgICAgICAgICAgICAgICB0aGlzLl9tZWFzdXJlcy5zZXQobWVhc3VyZU5hbWUsIG1lYXN1cmUpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYGVycm9yIG1lYXN1cmluZyAke21lYXN1cmVOYW1lfWAsIGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxufVxuY29uc3QgXyA9IHtcbiAgICBzbG90TWFya3MsXG4gICAgc2xvdE1lYXN1cmVzLFxuICAgIHRyYWNrZWRTbG90cyxcbn07XG5leHBvcnQgeyBFdmVudFRpbWVyLCBfLCBzdXBwb3J0c1BlcmZvcm1hbmNlQVBJIH07XG4iLCJpbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBvbmNlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGRmcEVudiB9IGZyb20gJy4uLy4uL2xpYi9kZnAvZGZwLWVudic7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi8uLi9saWIvZmFzdGRvbS1wcm9taXNlJztcbi8vIFJlbW92ZSBhZCBzbG90c1xuY29uc3Qgc2VsZWN0b3JzID0gW1xuICAgIGRmcEVudi5hZFNsb3RTZWxlY3RvcixcbiAgICAnLnRvcC1iYW5uZXItYWQtY29udGFpbmVyJyxcbiAgICAnLnRvcC1mcm9udHMtYmFubmVyLWFkLWNvbnRhaW5lcicsXG4gICAgJy5hZC1zbG90LWNvbnRhaW5lcicsXG5dO1xuY29uc3Qgc2VsZWN0Tm9kZXMgPSAoKSA9PiBzZWxlY3RvcnMucmVkdWNlKChub2Rlcywgc2VsZWN0b3IpID0+IFtcbiAgICAuLi5ub2RlcyxcbiAgICAuLi5BcnJheS5mcm9tKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoc2VsZWN0b3IpKSxcbl0sIFtdKTtcbmNvbnN0IGlzRGlzYWJsZWQgPSAobm9kZSkgPT4gd2luZG93LmdldENvbXB1dGVkU3R5bGUobm9kZSkuZGlzcGxheSA9PT0gJ25vbmUnO1xuY29uc3QgZmlsdGVyRGlzYWJsZWROb2RlcyA9IChub2RlcykgPT4gbm9kZXMuZmlsdGVyKGlzRGlzYWJsZWQpO1xuY29uc3QgcmVtb3ZlTm9kZXMgPSAobm9kZXMpID0+IGZhc3Rkb20ubXV0YXRlKCgpID0+IG5vZGVzLmZvckVhY2goKG5vZGUpID0+IHtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCBgUmVtb3ZpbmcgYWQgc2xvdDogJHtub2RlLmlkfWApO1xuICAgIG5vZGUucmVtb3ZlKCk7XG59KSk7XG5jb25zdCByZW1vdmVTbG90cyA9ICgpID0+IHtcbiAgICByZXR1cm4gcmVtb3ZlTm9kZXMoc2VsZWN0Tm9kZXMoKSk7XG59O1xuLyoqXG4gKiBSZW1vdmUgYWQgc2xvdCBlbGVtZW50cyB0aGF0IGhhdmUgc3R5bGUgZGlzcGxheTogbm9uZVxuICovXG5jb25zdCByZW1vdmVEaXNhYmxlZFNsb3RzID0gb25jZSgoKSA9PiByZW1vdmVOb2RlcyhmaWx0ZXJEaXNhYmxlZE5vZGVzKHNlbGVjdE5vZGVzKCkpKSk7XG5leHBvcnQgeyByZW1vdmVTbG90cywgcmVtb3ZlRGlzYWJsZWRTbG90cyB9O1xuIiwiaW1wb3J0IHsgZ2V0Q3VycmVudEJyZWFrcG9pbnQgfSBmcm9tICcuLi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuaW1wb3J0IHsgZ2V0VXJsVmFycyBhcyBfZ2V0VXJsVmFycyB9IGZyb20gJy4uL3VybCc7XG5jb25zdCBnZXRVcmxWYXJzID0gX2dldFVybFZhcnM7XG5jb25zdCBkZnBFbnYgPSB7XG4gICAgLyogcmVuZGVyU3RhcnRUaW1lOiBpbnRlZ2VyLiBQb2ludCBpbiB0aW1lIHdoZW4gREZQIGtpY2tzIGluICovXG4gICAgcmVuZGVyU3RhcnRUaW1lOiAtMSxcbiAgICAvKiBhZFNsb3RTZWxlY3Rvcjogc3RyaW5nLiBBIENTUyBzZWxlY3RvciB0byBxdWVyeSBhZCBzbG90cyBpbiB0aGUgRE9NICovXG4gICAgYWRTbG90U2VsZWN0b3I6ICcuanMtYWQtc2xvdCcsXG4gICAgLyogbGF6eUxvYWRFbmFibGVkOiBib29sZWFuLiBTZXQgdG8gdHJ1ZSB3aGVuIGFkdmVydHMgYXJlIGxhenktbG9hZGVkICovXG4gICAgbGF6eUxvYWRFbmFibGVkOiBmYWxzZSxcbiAgICAvKiBsYXp5TG9hZE9ic2VydmU6IGJvb2xlYW4uIFVzZSBJbnRlcnNlY3Rpb25PYnNlcnZlciBpbiBzdXBwb3J0aW5nIGJyb3dzZXJzICovXG4gICAgbGF6eUxvYWRPYnNlcnZlOiAnSW50ZXJzZWN0aW9uT2JzZXJ2ZXInIGluIHdpbmRvdyxcbiAgICAvKiBhZHZlcnRzVG9Mb2FkIC0gTGlzdHMgYWR2ZXJ0cyB3YWl0aW5nIHRvIGJlIGxvYWRlZCAqL1xuICAgIGFkdmVydHNUb0xvYWQ6IFtdLFxuICAgIC8qIGFkdmVydHMgLSBLZWVwcyB0cmFjayBvZiBhZHZlcnRzIGFuZCB0aGVpciBzdGF0ZSAqL1xuICAgIGFkdmVydHM6IG5ldyBNYXAoKSxcbiAgICAvKiBzaG91bGRMYXp5TG9hZDogKCkgLT4gYm9vbGVhbi4gRGV0ZXJtaW5lcyB3aGV0aGVyIGFkcyBzaG91bGQgYmUgbGF6eSBsb2FkZWQgKi9cbiAgICBzaG91bGRMYXp5TG9hZCgpIHtcbiAgICAgICAgaWYgKGdldFVybFZhcnMoKS5kbGwgPT09ICcxJykge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChbJ21vYmlsZScsICd0YWJsZXQnXS5pbmNsdWRlcyhnZXRDdXJyZW50QnJlYWtwb2ludCgpKSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5oYXNQYWdlU2tpbikge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH0sXG59O1xud2luZG93Lmd1YXJkaWFuLmNvbW1lcmNpYWwgPSB3aW5kb3cuZ3VhcmRpYW4uY29tbWVyY2lhbCA/PyB7fTtcbi8vIGV4cG9zZSB0aGlzIG9uIHRoZSB3aW5kb3csIGZvciB1c2UgYnkgZGVidWdnZXIgdG9vbHNcbndpbmRvdy5ndWFyZGlhbi5jb21tZXJjaWFsLmRmcEVudiA9IGRmcEVudjtcbmV4cG9ydCB7IGRmcEVudiB9O1xuIiwiLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGlzIHVzZWQgdG8gcmVwb3J0IGVycm9ycyB0byBTZW50cnlcbiAqIEl0IHVzZXMgdGhlIGZ1bmN0aW9uIGB3aW5kb3cuZ3VhcmRpYW4ubW9kdWxlcy5zZW50cnkucmVwb3J0RXJyb3JgIHNldCBieSBEQ1JcbiAqL1xuY29uc3QgcmVwb3J0RXJyb3IgPSAoZXJyb3IsIGZlYXR1cmUsIHRhZ3MgPSB7fSwgZXh0cmFzID0ge30pID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBlcnIgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IgOiBuZXcgRXJyb3IoU3RyaW5nKGVycm9yKSk7XG4gICAgICAgIGlmICh3aW5kb3cuZ3VhcmRpYW4ubW9kdWxlcy5zZW50cnk/LnJlcG9ydEVycm9yKSB7XG4gICAgICAgICAgICB3aW5kb3cuZ3VhcmRpYW4ubW9kdWxlcy5zZW50cnkucmVwb3J0RXJyb3IoZXJyLCBmZWF0dXJlLCB0YWdzLCBleHRyYXMpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHJlcG9ydGluZyBlcnJvciB0byBTZW50cnknLCBlLCBmZWF0dXJlLCB0YWdzKTtcbiAgICB9XG59O1xuY29uc3Qgd3JhcFdpdGhFcnJvclJlcG9ydGluZyA9IChmbiwgdGFncyA9IHt9LCBleHRyYXMgPSB7fSkgPT4ge1xuICAgIHJldHVybiBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGZuKGV2ZW50KTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgcmVwb3J0RXJyb3IoZSwgJ2NvbW1lcmNpYWwnLCB0YWdzLCBleHRyYXMpO1xuICAgICAgICB9XG4gICAgfTtcbn07XG5leHBvcnQgeyByZXBvcnRFcnJvciwgd3JhcFdpdGhFcnJvclJlcG9ydGluZyB9O1xuIiwiaW1wb3J0IGZhc3Rkb20gZnJvbSAnZmFzdGRvbSc7XG5pbXBvcnQgZmFzdGRvbVByb21pc2VkIGZyb20gJ2Zhc3Rkb20vZXh0ZW5zaW9ucy9mYXN0ZG9tLXByb21pc2VkJztcbmV4cG9ydCBkZWZhdWx0IGZhc3Rkb20uZXh0ZW5kKGZhc3Rkb21Qcm9taXNlZCk7XG4iLCJpbXBvcnQgeyBtZW1vaXplIH0gZnJvbSAnbG9kYXNoLWVzJztcbi8qKlxuICogQ29tbWVyY2lhbCBUZXN0aW5nIEluc3RydW1lbnRcbiAqXG4gKiBSZXR1cm5zIGEgbWFwIHsgPGJpZGRlck5hbWU+OiB0cnVlIH0gb2YgYmlkZGVyc1xuICogYWNjb3JkaW5nIHRvIHRoZSBwYnRlc3QgVVJMIHBhcmFtZXRlclxuICovXG5jb25zdCBwYlRlc3ROYW1lTWFwID0gbWVtb2l6ZSgoKSA9PiBuZXcgVVJMU2VhcmNoUGFyYW1zKHdpbmRvdy5sb2NhdGlvbi5zZWFyY2gpXG4gICAgLmdldEFsbCgncGJ0ZXN0JylcbiAgICAucmVkdWNlKChhY2MsIHZhbHVlKSA9PiB7XG4gICAgYWNjW3ZhbHVlXSA9IHRydWU7XG4gICAgcmV0dXJuIGFjYztcbn0sIHt9KSwgKCkgPT4gXG4vLyBTYW1lIGltcGxpY2l0IHBhcmFtZXRlciBhcyB0aGUgbWVtb2l6ZWQgZnVuY3Rpb25cbndpbmRvdy5sb2NhdGlvbi5zZWFyY2gpO1xuY29uc3QgcXVlcnlTdHJpbmdUb1VybFZhcnMgPSBtZW1vaXplKChxdWVyeVN0cmluZykgPT4gQXJyYXkuZnJvbShuZXcgVVJMU2VhcmNoUGFyYW1zKHF1ZXJ5U3RyaW5nKS5lbnRyaWVzKCkpIC8vIHBvbHlmaWxsLmlvIGd1YXJhbnRlZXMgVVJMU2VhcmNoUGFyYW1zXG4gICAgLnJlZHVjZSgoYWNjLCBba2V5LCB2YWx1ZV0pID0+IHtcbiAgICBhY2Nba2V5XSA9IHZhbHVlID09PSAnJyA/IHRydWUgOiB2YWx1ZTtcbiAgICByZXR1cm4gYWNjO1xufSwge30pKTtcbi8qKlxuICogcmV0dXJucyBhIG1hcCBvZiBxdWVyeXN0cmluZ3NcbiAqIGVnID9mb289YmFyJmZpeno9YnV6eiByZXR1cm5zIHtmb286ICdiYXInLCBmaXp6OiAnYnV6eid9XG4gKiA/Zm9vPWJhciZmb289YmF6IHJldHVybnMge2ZvbzogJ2Jheid9XG4gKiA/Zm9vIHJldHVybnMgeyBmb286IHRydWUgfVxuICovXG5jb25zdCBnZXRVcmxWYXJzID0gKHF1ZXJ5KSA9PiBxdWVyeVN0cmluZ1RvVXJsVmFycyhxdWVyeSA/PyB3aW5kb3cubG9jYXRpb24uc2VhcmNoKTtcbmV4cG9ydCB7IGdldFVybFZhcnMsIHBiVGVzdE5hbWVNYXAgfTtcbiJdLCJuYW1lcyI6WyJsb2ciLCJzdXBwb3J0c1BlcmZvcm1hbmNlQVBJIiwid2luZG93IiwicGVyZm9ybWFuY2UiLCJtYXJrIiwidHJhY2tlZFNsb3RzIiwic2xvdE1hcmtzIiwic2xvdE1lYXN1cmVzIiwicGFnZU1hcmtzIiwicGFnZU1lYXN1cmVzIiwiYWxsU2xvdE1hcmtzIiwibWFwIiwibWVhc3VyZSIsImNvbmNhdCIsImV4dGVybmFsTWFya3MiLCJzaG91bGRTYXZlIiwibmFtZSIsIm9yaWdpbiIsInR5cGUiLCJzcGxpdCIsInNob3VsZFNhdmVNYXJrIiwiaW5jbHVkZXMiLCJzaG91bGRTYXZlTWVhc3VyZSIsIkV2ZW50VGltZXIiLCJpbml0IiwiX3dpbmRvdyRndWFyZGlhbiIsIl93aW5kb3ckZ3VhcmRpYW4kY29tbSIsImd1YXJkaWFuIiwiY29tbWVyY2lhbFRpbWVyIiwiZ2V0IiwiX2V4dGVybmFsTWFya3MiLCJNYXAiLCJyZWR1Y2UiLCJlbnRyaWVzIiwiZ2V0RW50cmllc0J5TmFtZSIsImxlbmd0aCIsInNldCIsIm1hcmtzIiwiX21hcmtzIiwiX3JlZiIsInRpbWVyIiwidHMiLCJzdGFydFRpbWUiLCJtZWFzdXJlcyIsIl9tZWFzdXJlcyIsIl9yZWYyIiwiZHVyYXRpb24iLCJjb25zdHJ1Y3RvciIsIl9kZWZpbmVQcm9wZXJ0eSIsInByb3BlcnRpZXMiLCJuYXZpZ2F0b3IiLCJjb25uZWN0aW9uIiwiZG93bmxpbmsiLCJlZmZlY3RpdmVUeXBlIiwic2V0UHJvcGVydHkiLCJ2YWx1ZSIsImV2ZW50TmFtZSIsImFyZ3VtZW50cyIsInVuZGVmaW5lZCIsImVuZHNXaXRoIiwiZW5kTWFyayIsInN0YXJ0TWFyayIsInJlcGxhY2UiLCJtZWFzdXJlTmFtZSIsInN0YXJ0TWFya0V4aXN0cyIsImUiLCJfIiwib25jZSIsImRmcEVudiIsImZhc3Rkb20iLCJzZWxlY3RvcnMiLCJhZFNsb3RTZWxlY3RvciIsInNlbGVjdE5vZGVzIiwibm9kZXMiLCJzZWxlY3RvciIsIkFycmF5IiwiZnJvbSIsImRvY3VtZW50IiwicXVlcnlTZWxlY3RvckFsbCIsImlzRGlzYWJsZWQiLCJub2RlIiwiZ2V0Q29tcHV0ZWRTdHlsZSIsImRpc3BsYXkiLCJmaWx0ZXJEaXNhYmxlZE5vZGVzIiwiZmlsdGVyIiwicmVtb3ZlTm9kZXMiLCJtdXRhdGUiLCJmb3JFYWNoIiwiaWQiLCJyZW1vdmUiLCJyZW1vdmVTbG90cyIsInJlbW92ZURpc2FibGVkU2xvdHMiLCJnZXRDdXJyZW50QnJlYWtwb2ludCIsImdldFVybFZhcnMiLCJfZ2V0VXJsVmFycyIsInJlbmRlclN0YXJ0VGltZSIsImxhenlMb2FkRW5hYmxlZCIsImxhenlMb2FkT2JzZXJ2ZSIsImFkdmVydHNUb0xvYWQiLCJhZHZlcnRzIiwic2hvdWxkTGF6eUxvYWQiLCJkbGwiLCJjb25maWciLCJwYWdlIiwiaGFzUGFnZVNraW4iLCJjb21tZXJjaWFsIiwicmVwb3J0RXJyb3IiLCJlcnJvciIsImZlYXR1cmUiLCJ0YWdzIiwiZXh0cmFzIiwiX3dpbmRvdyRndWFyZGlhbiRtb2R1IiwiZXJyIiwiRXJyb3IiLCJTdHJpbmciLCJtb2R1bGVzIiwic2VudHJ5IiwiY29uc29sZSIsIndyYXBXaXRoRXJyb3JSZXBvcnRpbmciLCJmbiIsImV2ZW50IiwiZmFzdGRvbVByb21pc2VkIiwiZXh0ZW5kIiwibWVtb2l6ZSIsInBiVGVzdE5hbWVNYXAiLCJVUkxTZWFyY2hQYXJhbXMiLCJsb2NhdGlvbiIsInNlYXJjaCIsImdldEFsbCIsImFjYyIsInF1ZXJ5U3RyaW5nVG9VcmxWYXJzIiwicXVlcnlTdHJpbmciLCJrZXkiLCJxdWVyeSJdLCJzb3VyY2VSb290IjoiIn0=