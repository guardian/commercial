"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["src_init_consented_ad-free-slot-remove_ts-src_init_consented_comscore_ts-src_init_consented_i-69c2bc"],{

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setSessionCookie.js":
/*!******************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setSessionCookie.js ***!
  \******************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setSessionCookie: () => (/* binding */ setSessionCookie)
/* harmony export */ });
/* harmony import */ var _ERR_INVALID_COOKIE_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ERR_INVALID_COOKIE.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/ERR_INVALID_COOKIE.js");
/* harmony import */ var _getCookieValues_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./getCookieValues.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookieValues.js");
/* harmony import */ var _getDomainAttribute_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./getDomainAttribute.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getDomainAttribute.js");
/* harmony import */ var _isValidCookie_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./isValidCookie.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/isValidCookie.js");
/* harmony import */ var _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./memoizedCookies.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/memoizedCookies.js");





var setSessionCookie = _ref => {
  var {
    name,
    value
  } = _ref;
  if (!(0,_isValidCookie_js__WEBPACK_IMPORTED_MODULE_3__.isValidCookie)(name, value)) {
    throw new Error("".concat(_ERR_INVALID_COOKIE_js__WEBPACK_IMPORTED_MODULE_0__.ERR_INVALID_COOKIE, " ").concat(name, "=").concat(value));
  }
  document.cookie = "".concat(name, "=").concat(value, "; path=/;").concat((0,_getDomainAttribute_js__WEBPACK_IMPORTED_MODULE_2__.getDomainAttribute)());
  if (_memoizedCookies_js__WEBPACK_IMPORTED_MODULE_4__.memoizedCookies.has(name)) {
    var [value2] = (0,_getCookieValues_js__WEBPACK_IMPORTED_MODULE_1__.getCookieValues)(name);
    if (value2) {
      _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_4__.memoizedCookies.set(name, value2);
    }
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/locale/getLocale.js":
/*!**********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/locale/getLocale.js ***!
  \**********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getLocale: () => (/* binding */ getLocale)
/* harmony export */ });
/* harmony import */ var _cookies_getCookie_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../cookies/getCookie.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _cookies_setSessionCookie_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../cookies/setSessionCookie.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setSessionCookie.js");
/* harmony import */ var _isString_isString_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../isString/isString.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _storage_storage_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../storage/storage.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }




var KEY = "GU_geo_country";
var KEY_OVERRIDE = "gu.geo.override";
var URL = "https://api.nextgen.guardianapps.co.uk/geolocation";
var COUNTRY_REGEX = /^[A-Z]{2}$/;
var isValidCountryCode = country => (0,_isString_isString_js__WEBPACK_IMPORTED_MODULE_2__.isString)(country) && COUNTRY_REGEX.test(country);
var locale;
var getLocale = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    if (locale) {
      return locale;
    }
    var geoOverride = _storage_storage_js__WEBPACK_IMPORTED_MODULE_3__.storage.local.get(KEY_OVERRIDE);
    if (isValidCountryCode(geoOverride)) {
      return locale = geoOverride;
    }
    var stored = (0,_cookies_getCookie_js__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
      name: "GU_geo_country"
    });
    if (stored && isValidCountryCode(stored)) {
      return locale = stored;
    }
    try {
      var {
        country
      } = yield fetch(URL).then(response => response.json());
      if (isValidCountryCode(country)) {
        (0,_cookies_setSessionCookie_js__WEBPACK_IMPORTED_MODULE_1__.setSessionCookie)({
          name: KEY,
          value: country
        });
        return locale = country;
      }
    } catch (e) {}
    return null;
  });
  return function getLocale() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/init/consented/ad-free-slot-remove.ts":
/*!***************************************************!*\
  !*** ./src/init/consented/ad-free-slot-remove.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   adFreeSlotRemove: () => (/* binding */ adFreeSlotRemove)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _remove_slots__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./remove-slots */ "./src/init/consented/remove-slots.ts");



/**
 * If the user is ad-free, remove all ad slots on the page,
 * as the ad slots are still left on the page on fronts, and mostpop on articles
 */
var adFreeSlotRemove = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(() => {
  if (!_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.adFree) {
    return Promise.resolve();
  }
  return (0,_remove_slots__WEBPACK_IMPORTED_MODULE_2__.removeSlots)();
});


/***/ }),

/***/ "./src/init/consented/comscore.ts":
/*!****************************************!*\
  !*** ./src/init/consented/comscore.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/loadScript/loadScript.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }



var comscoreSrc = '//sb.scorecardresearch.com/cs/6035250/beacon.js';
var comscoreC1 = '2';
var comscoreC2 = '6035250';
var getGlobals = (keywords, section) => {
  var globals = {
    c1: comscoreC1,
    c2: comscoreC2,
    cs_ucfr: '1',
    options: {
      enableFirstPartyCookie: true
    }
  };
  if (keywords !== 'Network Front') {
    globals.comscorekw = section;
  }
  return globals;
};
var initOnConsent = () => {
  var _window$_comscore;
  window._comscore = (_window$_comscore = window._comscore) !== null && _window$_comscore !== void 0 ? _window$_comscore : [];
  window._comscore.push(getGlobals(window.guardian.config.page.keywords, window.guardian.config.page.section));
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.loadScript)(comscoreSrc, {
    id: 'comscore',
    async: true
  });
};
/**
 * Initialise comscore, industry-wide audience tracking
 * https://www.comscore.com/About
 */
var setupComscore = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    if (!_lib_commercial_features__WEBPACK_IMPORTED_MODULE_4__.commercialFeatures.comscore) {
      return Promise.resolve();
    }
    try {
      var _ref2;
      var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
      /* Rule is that comscore can run:
      - in Tcfv2: Based on consent for comscore
      - in Australia: Always
      - in USNAT: If the user hasn't chosen Do Not Sell
      TODO move this logic to getConsentFor
      */
      var canRunTcfv2 = (_ref2 = consentState.tcfv2 && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)('comscore', consentState)) !== null && _ref2 !== void 0 ? _ref2 : false;
      var canRunAus = !!consentState.aus;
      var canRunUsnat = !!consentState.usnat && !consentState.usnat.doNotSell;
      if (!(canRunTcfv2 || canRunAus || canRunUsnat)) {
        throw Error('No consent for comscore');
      }
      yield initOnConsent();
      return;
    } catch (e) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', '⚠️ Failed to execute comscore', e);
    }
  });
  return function setupComscore() {
    return _ref.apply(this, arguments);
  };
}();
var setupComscoreOnce = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(setupComscore);
var init = () => setupComscoreOnce();
var _ = {
  getGlobals,
  setupComscore,
  comscoreSrc,
  comscoreC1,
  comscoreC2
};

/***/ }),

/***/ "./src/init/consented/ipsos-mori.ts":
/*!******************************************!*\
  !*** ./src/init/consented/ipsos-mori.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/loadScript/loadScript.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/locale/getLocale.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_vendor_ipsos_mori__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/__vendor/ipsos-mori */ "./src/lib/__vendor/ipsos-mori.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var loadIpsosScript = locale => {
  (0,_lib_vendor_ipsos_mori__WEBPACK_IMPORTED_MODULE_4__.ipsosMoriStub)();
  var ipsosTag = window.guardian.config.page.ipsosTag;
  if (ipsosTag === undefined) throw Error('Ipsos tag undefined');
  var ipsosSource = "https://".concat(locale, "-script.dotmetrics.net/door.js?d=").concat(document.location.host, "&t=").concat(ipsosTag);
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.loadScript)(ipsosSource, {
    id: 'ipsos',
    async: true,
    type: 'text/javascript'
  });
};
/**
 * Initialise Ipsos Mori - market research partner
 * documentation on DCR: [link](https://github.com/guardian/dotcom-rendering/blob/150fc2d81e6a66d9c3336185e874fc8cd0288546/dotcom-rendering/docs/architecture/3rd%20party%20technical%20review/002-ipsos-mori.md)
 * @returns Promise
 */
var init = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var locale = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getLocale)();
    var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
    var isAU = locale === 'AU' && !!consentState.aus;
    var isUK = locale === 'GB' && !!consentState.tcfv2;
    if (!isAU && !isUK) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', 'Skipping ipsos process outside GB or AU');
    }
    if (isAU) {
      void loadIpsosScript('au');
    } else if (isUK) {
      var hasConsent = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)('ipsos', consentState);
      if (hasConsent) {
        void loadIpsosScript('uk');
      } else {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', 'No consent for ipsos in GB');
      }
    }
  });
  return function init() {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/init/consented/teads-cookieless.ts":
/*!************************************************!*\
  !*** ./src/init/consented/teads-cookieless.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initTeadsCookieless: () => (/* binding */ initTeadsCookieless)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/loadScript/loadScript.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }

var initTeadsCookieless = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
    var hasConsent = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)('teads', consentState);
    // Teads only runs on these content types, so lets not give them any more data than necessary
    var allowedContentTypes = ['Article', 'LiveBlog'];
    if (hasConsent && allowedContentTypes.includes(window.guardian.config.page.contentType)) {
      var _window$teads_analyti, _window$teads_analyti2;
      window.teads_analytics = (_window$teads_analyti = window.teads_analytics) !== null && _window$teads_analyti !== void 0 ? _window$teads_analyti : {};
      window.teads_analytics.analytics_tag_id = 'PUB_2167';
      window.teads_analytics.share = (_window$teads_analyti2 = window.teads_analytics.share) !== null && _window$teads_analyti2 !== void 0 ? _window$teads_analyti2 : function () {
        if (window.teads_analytics) {
          var _window$teads_analyti3;
          (window.teads_analytics.shared_data = (_window$teads_analyti3 = window.teads_analytics.shared_data) !== null && _window$teads_analyti3 !== void 0 ? _window$teads_analyti3 : []).push(...arguments);
        }
      };
      yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.loadScript)('https://a.teads.tv/analytics/tag.js', {
        async: false
      });
    }
  });
  return function initTeadsCookieless() {
    return _ref.apply(this, arguments);
  };
}();
(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsentChange)(consentState => {
  var hasConsent = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)('teads', consentState);
  var teadsCookie = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.getCookie)({
    name: '_tfpvi'
  });
  if (!hasConsent && teadsCookie) {
    /*
    Teads sets a cookie called _tfpvi, which is used to track users across sites.
    We need to delete this cookie if the user has not consented to Teads.
    We can't use the @guardian/libs setCookie function here, because it normalizes
    the domain to theguardian.com but the cookie is set on www.theguardian.com
    */
    document.cookie = '_tfpvi=;path=/';
  }
});


/***/ }),

/***/ "./src/init/consented/track-gpc-signal.ts":
/*!************************************************!*\
  !*** ./src/init/consented/track-gpc-signal.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_track_gpc_signal__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/track-gpc-signal */ "./src/lib/track-gpc-signal.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


/**
 * Initialise gpc signal tracking
 * @returns Promise
 */
var init = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
    if (consentState.canTarget) {
      (0,_lib_track_gpc_signal__WEBPACK_IMPORTED_MODULE_2__.initTrackGpcSignal)(consentState);
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'tracking gpc signal');
    } else {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'No consent to track gpc signal');
    }
  });
  return function init() {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/init/consented/track-scroll-depth.ts":
/*!**************************************************!*\
  !*** ./src/init/consented/track-scroll-depth.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_track_scroll_depth__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/track-scroll-depth */ "./src/lib/track-scroll-depth.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


/**
 * Initialise scroll depth / velocity tracking if user has consented to relevant purposes.
 * @returns Promise
 */
var init = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var _state$tcfv;
    var state = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
    if (
    // Purpose 8 - Measure content performance
    state.framework == 'tcfv2' && !!((_state$tcfv = state.tcfv2) !== null && _state$tcfv !== void 0 && _state$tcfv.consents[8]) || state.canTarget) {
      (0,_lib_track_scroll_depth__WEBPACK_IMPORTED_MODULE_2__.initTrackScrollDepth)();
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'tracking scroll depth');
    } else {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'No consent to track scroll depth');
    }
  });
  return function init() {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/lib/__vendor/ipsos-mori.js":
/*!****************************************!*\
  !*** ./src/lib/__vendor/ipsos-mori.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ipsosMoriStub: () => (/* binding */ ipsosMoriStub)
/* harmony export */ });
/**
 * Load the Ipsos Mori Stub
 *
 * See {@Link https://github.com/guardian/dotcom-rendering/blob/150fc2d81e6a66d9c3336185e874fc8cd0288546/dotcom-rendering/docs/architecture/3rd%20party%20technical%20review/002-ipsos-mori.md documentation here }
 */
var ipsosMoriStub = () => {
  window.dm = window.dm || {
    AjaxData: []
  };
  window.dm.AjaxEvent = (et, d, ssid, ad) => {
    dm.AjaxData.push({
      et,
      d,
      ssid,
      ad
    });
    if (window.DotMetricsObj) {
      DotMetricsObj.onAjaxDataUpdate();
    }
  };
};

/***/ }),

/***/ "./src/lib/commercial-boot-utils.ts":
/*!******************************************!*\
  !*** ./src/lib/commercial-boot-utils.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bootCommercial: () => (/* binding */ bootCommercial)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _dfp_dfp_env_globals__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dfp/dfp-env-globals */ "./src/lib/dfp/dfp-env-globals.ts");
/* harmony import */ var _error_report_error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./error/report-error */ "./src/lib/error/report-error.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }




var tags = {
  bundle: 'standalone'
};
var recordCommercialMetrics = () => {
  var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get();
  eventTimer.mark('commercialBootEnd');
  eventTimer.mark('commercialModulesLoaded');
  // record the number of ad slots on the page
  var adSlotsTotal = document.querySelectorAll("[id^=\"".concat(_dfp_dfp_env_globals__WEBPACK_IMPORTED_MODULE_2__.adSlotIdPrefix, "\"]")).length;
  eventTimer.setProperty('adSlotsTotal', adSlotsTotal);
  // and the number of inline ad slots
  var adSlotsInline = document.querySelectorAll("[id^=\"".concat(_dfp_dfp_env_globals__WEBPACK_IMPORTED_MODULE_2__.adSlotIdPrefix, "inline\"]")).length;
  eventTimer.setProperty('adSlotsInline', adSlotsInline);
};
var bootCommercial = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (modules) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', '📦 standalone.commercial.ts', __webpack_require__.p);
    if (true) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "@guardian/commercial-core commit https://github.com/guardian/commercial/blob/".concat("3ea15c71d2c7cb7545c936fb4b2c1a01d51e1723"));
    }
    // Init Commercial event timers
    _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.init();
    _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('commercialStart');
    _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('commercialBootStart');
    // Stub the command queue
    // @ts-expect-error -- it’s a stub, not the whole Googletag object
    window.googletag = {
      cmd: []
    };
    try {
      return Promise.allSettled(modules.map(module => module())).then(recordCommercialMetrics);
    } catch (error) {
      // report async errors in bootCommercial to Sentry with the commercial feature tag
      (0,_error_report_error__WEBPACK_IMPORTED_MODULE_3__.reportError)(error, 'commercial', tags);
    }
  });
  return function bootCommercial(_x) {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/lib/dfp/dfp-env-globals.ts":
/*!****************************************!*\
  !*** ./src/lib/dfp/dfp-env-globals.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   adSlotIdPrefix: () => (/* binding */ adSlotIdPrefix)
/* harmony export */ });
/* prefix for id of all ad slot elements */
var adSlotIdPrefix = 'dfp-ad--';

/***/ }),

/***/ "./src/lib/track-gpc-signal.ts":
/*!*************************************!*\
  !*** ./src/lib/track-gpc-signal.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initTrackGpcSignal: () => (/* binding */ initTrackGpcSignal)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");


/**
 * Collect metrics on gpcSignal presence and value
 * https://globalprivacycontrol.github.io/gpc-spec/
 */
var initTrackGpcSignal = consentState => {
  // If undefined we set the property value to -1, false is 0, true is 1
  var gpcSignal = consentState.gpcSignal === undefined ? -1 : +consentState.gpcSignal;
  var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get();
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "gpcSignal ".concat(gpcSignal));
  eventTimer.setProperty('gpcSignal', gpcSignal);
};


/***/ }),

/***/ "./src/lib/track-scroll-depth.ts":
/*!***************************************!*\
  !*** ./src/lib/track-scroll-depth.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initTrackScrollDepth: () => (/* binding */ initTrackScrollDepth)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");


/**
 * Collect commercial metrics on scroll depth
 * Insert hidden elements at intervals of 1 viewport height
 * then use an intersection observer to mark the time when the viewport intersects with these elements.
 * Approach inspired by https://gist.github.com/bgreater/2412517f5a3f9c6fc4cafeb1ca71384f
 */
var initTrackScrollDepth = () => {
  var pageHeight = document.body.offsetHeight;
  var intViewportHeight = window.innerHeight;
  // this if statement is here to handle a bug in Firefox in Android where the innerHeight
  // of a new tab can be 0, so we end up dividing by 0 and looping through infinity
  if (intViewportHeight === 0) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Not tracking scroll depth because viewport height cannot be determined");
    return;
  }
  // how many viewports tall is the page?
  var pageHeightVH = Math.floor(pageHeight / intViewportHeight);
  var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get();
  eventTimer.setProperty('pageHeightVH', pageHeightVH);
  var observer = new IntersectionObserver(/* istanbul ignore next */
  entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        var currentDepthVH = String(entry.target.getAttribute('data-depth'));
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "current scroll depth ".concat(currentDepthVH));
        eventTimer.mark("scroll-depth-vh-".concat(currentDepthVH));
        observer.unobserve(entry.target);
      }
    });
  });
  for (var depth = 1; depth <= pageHeightVH; depth++) {
    var div = document.createElement('div');
    div.dataset.depth = String(depth);
    div.style.top = String(100 * depth) + '%';
    div.style.position = 'absolute';
    div.className = 'scroll-depth-marker';
    document.body.appendChild(div);
    observer.observe(div);
  }
};


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uc3JjX2luaXRfY29uc2VudGVkX2FkLWZyZWUtc2xvdC1yZW1vdmVfdHMtc3JjX2luaXRfY29uc2VudGVkX2NvbXNjb3JlX3RzLXNyY19pbml0X2NvbnNlbnRlZF9pLTY5YzJiYy5jb21tZXJjaWFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUE2RDtBQUNOO0FBQ007QUFDVjtBQUNJO0FBQ3ZELElBQU1LLGdCQUFnQixHQUFHQyxJQUFBLElBQXFCO0VBQUEsSUFBcEI7SUFBRUMsSUFBSTtJQUFFQztFQUFNLENBQUMsR0FBQUYsSUFBQTtFQUNyQyxJQUFJLENBQUNILGdFQUFhLENBQUNJLElBQUksRUFBRUMsS0FBSyxDQUFDLEVBQUU7SUFDN0IsTUFBTSxJQUFJQyxLQUFLLElBQUFDLE1BQUEsQ0FBSVYsc0VBQWtCLE9BQUFVLE1BQUEsQ0FBSUgsSUFBSSxPQUFBRyxNQUFBLENBQUlGLEtBQUssQ0FBRSxDQUFDO0VBQzdEO0VBQ0FHLFFBQVEsQ0FBQ0MsTUFBTSxNQUFBRixNQUFBLENBQU1ILElBQUksT0FBQUcsTUFBQSxDQUFJRixLQUFLLGVBQUFFLE1BQUEsQ0FBWVIsMEVBQWtCLENBQUMsQ0FBQyxDQUFFO0VBQ3BFLElBQUlFLGdFQUFlLENBQUNTLEdBQUcsQ0FBQ04sSUFBSSxDQUFDLEVBQUU7SUFDM0IsSUFBTSxDQUFDTyxNQUFNLENBQUMsR0FBR2Isb0VBQWUsQ0FBQ00sSUFBSSxDQUFDO0lBQ3RDLElBQUlPLE1BQU0sRUFBRTtNQUNSVixnRUFBZSxDQUFDVyxHQUFHLENBQUNSLElBQUksRUFBRU8sTUFBTSxDQUFDO0lBQ3JDO0VBQ0o7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQm1EO0FBQ2M7QUFDZjtBQUNIO0FBQ2hELElBQU1LLEdBQUcsR0FBRyxnQkFBZ0I7QUFDNUIsSUFBTUMsWUFBWSxHQUFHLGlCQUFpQjtBQUN0QyxJQUFNQyxHQUFHLEdBQUcsb0RBQW9EO0FBQ2hFLElBQU1DLGFBQWEsR0FBRyxZQUFZO0FBQ2xDLElBQU1DLGtCQUFrQixHQUFJQyxPQUFPLElBQUtQLCtEQUFRLENBQUNPLE9BQU8sQ0FBQyxJQUFJRixhQUFhLENBQUNHLElBQUksQ0FBQ0QsT0FBTyxDQUFDO0FBQ3hGLElBQUlFLE1BQU07QUFDVixJQUFNQyxTQUFTO0VBQUEsSUFBQXJCLElBQUEsR0FBQXNCLGlCQUFBLENBQUcsYUFBWTtJQUMxQixJQUFJRixNQUFNLEVBQUU7TUFDUixPQUFPQSxNQUFNO0lBQ2pCO0lBQ0EsSUFBTUcsV0FBVyxHQUFHWCx3REFBTyxDQUFDWSxLQUFLLENBQUNDLEdBQUcsQ0FBQ1gsWUFBWSxDQUFDO0lBQ25ELElBQUlHLGtCQUFrQixDQUFDTSxXQUFXLENBQUMsRUFBRTtNQUNqQyxPQUFPSCxNQUFNLEdBQUdHLFdBQVc7SUFDL0I7SUFDQSxJQUFNRyxNQUFNLEdBQUdoQixnRUFBUyxDQUFDO01BQUVULElBQUksRUFBRTtJQUFpQixDQUFDLENBQUM7SUFDcEQsSUFBSXlCLE1BQU0sSUFBSVQsa0JBQWtCLENBQUNTLE1BQU0sQ0FBQyxFQUFFO01BQ3RDLE9BQU9OLE1BQU0sR0FBR00sTUFBTTtJQUMxQjtJQUNBLElBQUk7TUFDQSxJQUFNO1FBQUVSO01BQVEsQ0FBQyxTQUFTUyxLQUFLLENBQUNaLEdBQUcsQ0FBQyxDQUFDYSxJQUFJLENBQUVDLFFBQVEsSUFBS0EsUUFBUSxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO01BQ3hFLElBQUliLGtCQUFrQixDQUFDQyxPQUFPLENBQUMsRUFBRTtRQUM3Qm5CLDhFQUFnQixDQUFDO1VBQUVFLElBQUksRUFBRVksR0FBRztVQUFFWCxLQUFLLEVBQUVnQjtRQUFRLENBQUMsQ0FBQztRQUMvQyxPQUFPRSxNQUFNLEdBQUdGLE9BQU87TUFDM0I7SUFDSixDQUFDLENBQ0QsT0FBT2EsQ0FBQyxFQUFFLENBQ1Y7SUFDQSxPQUFPLElBQUk7RUFDZixDQUFDO0VBQUEsZ0JBdEJLVixTQUFTQSxDQUFBO0lBQUEsT0FBQXJCLElBQUEsQ0FBQWdDLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FzQmQ7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hDZ0M7QUFDa0M7QUFDdEI7QUFDN0M7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNSSxnQkFBZ0IsR0FBR0gscURBQUksQ0FBQyxNQUFNO0VBQ2hDLElBQUksQ0FBQ0Msd0VBQWtCLENBQUNHLE1BQU0sRUFBRTtJQUM1QixPQUFPQyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0VBQzVCO0VBQ0EsT0FBT0osMERBQVcsQ0FBQyxDQUFDO0FBQ3hCLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaeUU7QUFDMUM7QUFDa0M7QUFDbkUsSUFBTVMsV0FBVyxHQUFHLGlEQUFpRDtBQUNyRSxJQUFNQyxVQUFVLEdBQUcsR0FBRztBQUN0QixJQUFNQyxVQUFVLEdBQUcsU0FBUztBQUM1QixJQUFNQyxVQUFVLEdBQUdBLENBQUNDLFFBQVEsRUFBRUMsT0FBTyxLQUFLO0VBQ3RDLElBQU1DLE9BQU8sR0FBRztJQUNaQyxFQUFFLEVBQUVOLFVBQVU7SUFDZE8sRUFBRSxFQUFFTixVQUFVO0lBQ2RPLE9BQU8sRUFBRSxHQUFHO0lBQ1pDLE9BQU8sRUFBRTtNQUNMQyxzQkFBc0IsRUFBRTtJQUM1QjtFQUNKLENBQUM7RUFDRCxJQUFJUCxRQUFRLEtBQUssZUFBZSxFQUFFO0lBQzlCRSxPQUFPLENBQUNNLFVBQVUsR0FBR1AsT0FBTztFQUNoQztFQUNBLE9BQU9DLE9BQU87QUFDbEIsQ0FBQztBQUNELElBQU1PLGFBQWEsR0FBR0EsQ0FBQSxLQUFNO0VBQUEsSUFBQUMsaUJBQUE7RUFDeEJDLE1BQU0sQ0FBQ0MsU0FBUyxJQUFBRixpQkFBQSxHQUFHQyxNQUFNLENBQUNDLFNBQVMsY0FBQUYsaUJBQUEsY0FBQUEsaUJBQUEsR0FBSSxFQUFFO0VBQ3pDQyxNQUFNLENBQUNDLFNBQVMsQ0FBQ0MsSUFBSSxDQUFDZCxVQUFVLENBQUNZLE1BQU0sQ0FBQ0csUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ2hCLFFBQVEsRUFBRVcsTUFBTSxDQUFDRyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDZixPQUFPLENBQUMsQ0FBQztFQUM1RyxPQUFPUiwwREFBVSxDQUFDRyxXQUFXLEVBQUU7SUFBRXFCLEVBQUUsRUFBRSxVQUFVO0lBQUVDLEtBQUssRUFBRTtFQUFLLENBQUMsQ0FBQztBQUNuRSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxhQUFhO0VBQUEsSUFBQXBFLElBQUEsR0FBQXNCLGlCQUFBLENBQUcsYUFBWTtJQUM5QixJQUFJLENBQUNhLHdFQUFrQixDQUFDa0MsUUFBUSxFQUFFO01BQzlCLE9BQU85QixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0lBQzVCO0lBQ0EsSUFBSTtNQUFBLElBQUE4QixLQUFBO01BQ0EsSUFBTUMsWUFBWSxTQUFTM0IseURBQVMsQ0FBQyxDQUFDO01BQ3RDO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNRLElBQU00QixXQUFXLElBQUFGLEtBQUEsR0FBSUMsWUFBWSxDQUFDRSxLQUFLLElBQUloQyw2REFBYSxDQUFDLFVBQVUsRUFBRThCLFlBQVksQ0FBQyxjQUFBRCxLQUFBLGNBQUFBLEtBQUEsR0FDOUUsS0FBSztNQUNULElBQU1JLFNBQVMsR0FBRyxDQUFDLENBQUNILFlBQVksQ0FBQ0ksR0FBRztNQUNwQyxJQUFNQyxXQUFXLEdBQUcsQ0FBQyxDQUFDTCxZQUFZLENBQUNNLEtBQUssSUFBSSxDQUFDTixZQUFZLENBQUNNLEtBQUssQ0FBQ0MsU0FBUztNQUN6RSxJQUFJLEVBQUVOLFdBQVcsSUFBSUUsU0FBUyxJQUFJRSxXQUFXLENBQUMsRUFBRTtRQUM1QyxNQUFNekUsS0FBSyxDQUFDLHlCQUF5QixDQUFDO01BQzFDO01BQ0EsTUFBTXVELGFBQWEsQ0FBQyxDQUFDO01BQ3JCO0lBQ0osQ0FBQyxDQUNELE9BQU8zQixDQUFDLEVBQUU7TUFDTlksbURBQUcsQ0FBQyxZQUFZLEVBQUUsK0JBQStCLEVBQUVaLENBQUMsQ0FBQztJQUN6RDtFQUNKLENBQUM7RUFBQSxnQkF6QktxQyxhQUFhQSxDQUFBO0lBQUEsT0FBQXBFLElBQUEsQ0FBQWdDLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0F5QmxCO0FBQ0QsSUFBTThDLGlCQUFpQixHQUFHN0MscURBQUksQ0FBQ2tDLGFBQWEsQ0FBQztBQUN0QyxJQUFNWSxJQUFJLEdBQUdBLENBQUEsS0FBTUQsaUJBQWlCLENBQUMsQ0FBQztBQUN0QyxJQUFNRSxDQUFDLEdBQUc7RUFDYmpDLFVBQVU7RUFDVm9CLGFBQWE7RUFDYnZCLFdBQVc7RUFDWEMsVUFBVTtFQUNWQztBQUNKLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0RzRjtBQUN6QjtBQUM5RCxJQUFNb0MsZUFBZSxHQUFJL0QsTUFBTSxJQUFLO0VBQ2hDOEQscUVBQWEsQ0FBQyxDQUFDO0VBQ2YsSUFBTUUsUUFBUSxHQUFHeEIsTUFBTSxDQUFDRyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDbUIsUUFBUTtFQUNyRCxJQUFJQSxRQUFRLEtBQUtDLFNBQVMsRUFDdEIsTUFBTWxGLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQztFQUN0QyxJQUFNbUYsV0FBVyxjQUFBbEYsTUFBQSxDQUFjZ0IsTUFBTSx1Q0FBQWhCLE1BQUEsQ0FBb0NDLFFBQVEsQ0FBQ2tGLFFBQVEsQ0FBQ0MsSUFBSSxTQUFBcEYsTUFBQSxDQUFNZ0YsUUFBUSxDQUFFO0VBQy9HLE9BQU8xQywwREFBVSxDQUFDNEMsV0FBVyxFQUFFO0lBQzNCcEIsRUFBRSxFQUFFLE9BQU87SUFDWEMsS0FBSyxFQUFFLElBQUk7SUFDWHNCLElBQUksRUFBRTtFQUNWLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTVQsSUFBSTtFQUFBLElBQUFoRixJQUFBLEdBQUFzQixpQkFBQSxDQUFHLGFBQVk7SUFDNUIsSUFBTUYsTUFBTSxTQUFTQyx5REFBUyxDQUFDLENBQUM7SUFDaEMsSUFBTWtELFlBQVksU0FBUzNCLHlEQUFTLENBQUMsQ0FBQztJQUN0QyxJQUFNOEMsSUFBSSxHQUFHdEUsTUFBTSxLQUFLLElBQUksSUFBSSxDQUFDLENBQUNtRCxZQUFZLENBQUNJLEdBQUc7SUFDbEQsSUFBTWdCLElBQUksR0FBR3ZFLE1BQU0sS0FBSyxJQUFJLElBQUksQ0FBQyxDQUFDbUQsWUFBWSxDQUFDRSxLQUFLO0lBQ3BELElBQUksQ0FBQ2lCLElBQUksSUFBSSxDQUFDQyxJQUFJLEVBQUU7TUFDaEJoRCxtREFBRyxDQUFDLFlBQVksRUFBRSx5Q0FBeUMsQ0FBQztJQUNoRTtJQUNBLElBQUkrQyxJQUFJLEVBQUU7TUFDTixLQUFLUCxlQUFlLENBQUMsSUFBSSxDQUFDO0lBQzlCLENBQUMsTUFDSSxJQUFJUSxJQUFJLEVBQUU7TUFDWCxJQUFNQyxVQUFVLEdBQUduRCw2REFBYSxDQUFDLE9BQU8sRUFBRThCLFlBQVksQ0FBQztNQUN2RCxJQUFJcUIsVUFBVSxFQUFFO1FBQ1osS0FBS1QsZUFBZSxDQUFDLElBQUksQ0FBQztNQUM5QixDQUFDLE1BQ0k7UUFDRHhDLG1EQUFHLENBQUMsWUFBWSxFQUFFLDRCQUE0QixDQUFDO01BQ25EO0lBQ0o7RUFDSixDQUFDO0VBQUEsZ0JBcEJZcUMsSUFBSUEsQ0FBQTtJQUFBLE9BQUFoRixJQUFBLENBQUFnQyxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBb0JoQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkNrRztBQUNuRyxJQUFNNkQsbUJBQW1CO0VBQUEsSUFBQTlGLElBQUEsR0FBQXNCLGlCQUFBLENBQUcsYUFBWTtJQUNwQyxJQUFNaUQsWUFBWSxTQUFTM0IseURBQVMsQ0FBQyxDQUFDO0lBQ3RDLElBQU1nRCxVQUFVLEdBQUduRCw2REFBYSxDQUFDLE9BQU8sRUFBRThCLFlBQVksQ0FBQztJQUN2RDtJQUNBLElBQU13QixtQkFBbUIsR0FBRyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUM7SUFDbkQsSUFBSUgsVUFBVSxJQUNWRyxtQkFBbUIsQ0FBQ0MsUUFBUSxDQUFDcEMsTUFBTSxDQUFDRyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDZ0MsV0FBVyxDQUFDLEVBQUU7TUFBQSxJQUFBQyxxQkFBQSxFQUFBQyxzQkFBQTtNQUN2RXZDLE1BQU0sQ0FBQ3dDLGVBQWUsSUFBQUYscUJBQUEsR0FBR3RDLE1BQU0sQ0FBQ3dDLGVBQWUsY0FBQUYscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxDQUFDLENBQUM7TUFDckR0QyxNQUFNLENBQUN3QyxlQUFlLENBQUNDLGdCQUFnQixHQUFHLFVBQVU7TUFDcER6QyxNQUFNLENBQUN3QyxlQUFlLENBQUNFLEtBQUssSUFBQUgsc0JBQUEsR0FDeEJ2QyxNQUFNLENBQUN3QyxlQUFlLENBQUNFLEtBQUssY0FBQUgsc0JBQUEsY0FBQUEsc0JBQUEsR0FDeEIsWUFBbUI7UUFDZixJQUFJdkMsTUFBTSxDQUFDd0MsZUFBZSxFQUFFO1VBQUEsSUFBQUcsc0JBQUE7VUFDeEIsQ0FBQzNDLE1BQU0sQ0FBQ3dDLGVBQWUsQ0FBQ0ksV0FBVyxJQUFBRCxzQkFBQSxHQUMvQjNDLE1BQU0sQ0FBQ3dDLGVBQWUsQ0FBQ0ksV0FBVyxjQUFBRCxzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLEVBQUUsRUFBRXpDLElBQUksQ0FBQyxHQUFBN0IsU0FBTyxDQUFDO1FBQy9EO01BQ0osQ0FBQztNQUNULE1BQU1TLDBEQUFVLENBQUMscUNBQXFDLEVBQUU7UUFDcER5QixLQUFLLEVBQUU7TUFDWCxDQUFDLENBQUM7SUFDTjtFQUNKLENBQUM7RUFBQSxnQkFyQksyQixtQkFBbUJBLENBQUE7SUFBQSxPQUFBOUYsSUFBQSxDQUFBZ0MsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQXFCeEI7QUFDRDRELCtEQUFlLENBQUV0QixZQUFZLElBQUs7RUFDOUIsSUFBTXFCLFVBQVUsR0FBR25ELDZEQUFhLENBQUMsT0FBTyxFQUFFOEIsWUFBWSxDQUFDO0VBQ3ZELElBQU1rQyxXQUFXLEdBQUcvRix5REFBUyxDQUFDO0lBQUVULElBQUksRUFBRTtFQUFTLENBQUMsQ0FBQztFQUNqRCxJQUFJLENBQUMyRixVQUFVLElBQUlhLFdBQVcsRUFBRTtJQUM1QjtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDUXBHLFFBQVEsQ0FBQ0MsTUFBTSxHQUFHLGdCQUFnQjtFQUN0QztBQUNKLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQzhDO0FBQ2dCO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTTBFLElBQUk7RUFBQSxJQUFBaEYsSUFBQSxHQUFBc0IsaUJBQUEsQ0FBRyxhQUFZO0lBQzVCLElBQU1pRCxZQUFZLFNBQVMzQix5REFBUyxDQUFDLENBQUM7SUFDdEMsSUFBSTJCLFlBQVksQ0FBQ29DLFNBQVMsRUFBRTtNQUN4QkQseUVBQWtCLENBQUNuQyxZQUFZLENBQUM7TUFDaEM1QixtREFBRyxDQUFDLFlBQVksRUFBRSxxQkFBcUIsQ0FBQztJQUM1QyxDQUFDLE1BQ0k7TUFDREEsbURBQUcsQ0FBQyxZQUFZLEVBQUUsZ0NBQWdDLENBQUM7SUFDdkQ7RUFDSixDQUFDO0VBQUEsZ0JBVFlxQyxJQUFJQSxDQUFBO0lBQUEsT0FBQWhGLElBQUEsQ0FBQWdDLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FTaEIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2YrQztBQUNvQjtBQUNwRTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU0rQyxJQUFJO0VBQUEsSUFBQWhGLElBQUEsR0FBQXNCLGlCQUFBLENBQUcsYUFBWTtJQUFBLElBQUF1RixXQUFBO0lBQzVCLElBQU1DLEtBQUssU0FBU2xFLHlEQUFTLENBQUMsQ0FBQztJQUMvQjtJQUNBO0lBQ0NrRSxLQUFLLENBQUNDLFNBQVMsSUFBSSxPQUFPLElBQUksQ0FBQyxHQUFBRixXQUFBLEdBQUNDLEtBQUssQ0FBQ3JDLEtBQUssY0FBQW9DLFdBQUEsZUFBWEEsV0FBQSxDQUFhRyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQ3JERixLQUFLLENBQUNILFNBQVMsRUFBRTtNQUNqQkMsNkVBQW9CLENBQUMsQ0FBQztNQUN0QmpFLG1EQUFHLENBQUMsWUFBWSxFQUFFLHVCQUF1QixDQUFDO0lBQzlDLENBQUMsTUFDSTtNQUNEQSxtREFBRyxDQUFDLFlBQVksRUFBRSxrQ0FBa0MsQ0FBQztJQUN6RDtFQUNKLENBQUM7RUFBQSxnQkFaWXFDLElBQUlBLENBQUE7SUFBQSxPQUFBaEYsSUFBQSxDQUFBZ0MsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQVloQixDOzs7Ozs7Ozs7Ozs7OztBQ2xCRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTWlELGFBQWEsR0FBR0EsQ0FBQSxLQUFNO0VBQy9CdEIsTUFBTSxDQUFDcUQsRUFBRSxHQUFHckQsTUFBTSxDQUFDcUQsRUFBRSxJQUFJO0lBQUVDLFFBQVEsRUFBRTtFQUFHLENBQUM7RUFDekN0RCxNQUFNLENBQUNxRCxFQUFFLENBQUNFLFNBQVMsR0FBRyxDQUFDQyxFQUFFLEVBQUVDLENBQUMsRUFBRUMsSUFBSSxFQUFFQyxFQUFFLEtBQUs7SUFDdkNOLEVBQUUsQ0FBQ0MsUUFBUSxDQUFDcEQsSUFBSSxDQUFDO01BQUVzRCxFQUFFO01BQUVDLENBQUM7TUFBRUMsSUFBSTtNQUFFQztJQUFHLENBQUMsQ0FBQztJQUNyQyxJQUFJM0QsTUFBTSxDQUFDNEQsYUFBYSxFQUFFO01BQ3RCQSxhQUFhLENBQUNDLGdCQUFnQixDQUFDLENBQUM7SUFDcEM7RUFDSixDQUFDO0FBQ0wsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2JrRTtBQUM5QjtBQUNrQjtBQUNKO0FBQ25ELElBQU1JLElBQUksR0FBRztFQUNUQyxNQUFNLEVBQUU7QUFDWixDQUFDO0FBQ0QsSUFBTUMsdUJBQXVCLEdBQUdBLENBQUEsS0FBTTtFQUNsQyxJQUFNQyxVQUFVLEdBQUdOLDZFQUFVLENBQUNqRyxHQUFHLENBQUMsQ0FBQztFQUNuQ3VHLFVBQVUsQ0FBQ0MsSUFBSSxDQUFDLG1CQUFtQixDQUFDO0VBQ3BDRCxVQUFVLENBQUNDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQztFQUMxQztFQUNBLElBQU1DLFlBQVksR0FBRzdILFFBQVEsQ0FBQzhILGdCQUFnQixXQUFBL0gsTUFBQSxDQUFVdUgsZ0VBQWMsUUFBSSxDQUFDLENBQUNTLE1BQU07RUFDbEZKLFVBQVUsQ0FBQ0ssV0FBVyxDQUFDLGNBQWMsRUFBRUgsWUFBWSxDQUFDO0VBQ3BEO0VBQ0EsSUFBTUksYUFBYSxHQUFHakksUUFBUSxDQUFDOEgsZ0JBQWdCLFdBQUEvSCxNQUFBLENBQVV1SCxnRUFBYyxjQUFVLENBQUMsQ0FBQ1MsTUFBTTtFQUN6RkosVUFBVSxDQUFDSyxXQUFXLENBQUMsZUFBZSxFQUFFQyxhQUFhLENBQUM7QUFDMUQsQ0FBQztBQUNELElBQU1DLGNBQWM7RUFBQSxJQUFBdkksSUFBQSxHQUFBc0IsaUJBQUEsQ0FBRyxXQUFPa0gsT0FBTyxFQUFLO0lBQ3RDN0YsbURBQUcsQ0FBQyxZQUFZLEVBQUUsNkJBQTZCLEVBQUU4RixxQkFBdUIsQ0FBQztJQUN6RSxJQUFJQyxJQUFzQixFQUFFO01BQ3hCL0YsbURBQUcsQ0FBQyxZQUFZLGtGQUFBdkMsTUFBQSxDQUFrRnNJLDBDQUFzQixDQUFFLENBQUM7SUFDL0g7SUFDQTtJQUNBaEIsNkVBQVUsQ0FBQzFDLElBQUksQ0FBQyxDQUFDO0lBQ2pCMEMsNkVBQVUsQ0FBQ2pHLEdBQUcsQ0FBQyxDQUFDLENBQUN3RyxJQUFJLENBQUMsaUJBQWlCLENBQUM7SUFDeENQLDZFQUFVLENBQUNqRyxHQUFHLENBQUMsQ0FBQyxDQUFDd0csSUFBSSxDQUFDLHFCQUFxQixDQUFDO0lBQzVDO0lBQ0E7SUFDQXJFLE1BQU0sQ0FBQ2lGLFNBQVMsR0FBRztNQUNmQyxHQUFHLEVBQUU7SUFDVCxDQUFDO0lBQ0QsSUFBSTtNQUNBLE9BQU92RyxPQUFPLENBQUN3RyxVQUFVLENBQUNQLE9BQU8sQ0FBQ1EsR0FBRyxDQUFFQyxNQUFNLElBQUtBLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDckgsSUFBSSxDQUFDbUcsdUJBQXVCLENBQUM7SUFDOUYsQ0FBQyxDQUNELE9BQU9tQixLQUFLLEVBQUU7TUFDVjtNQUNBdEIsZ0VBQVcsQ0FBQ3NCLEtBQUssRUFBRSxZQUFZLEVBQUVyQixJQUFJLENBQUM7SUFDMUM7RUFDSixDQUFDO0VBQUEsZ0JBckJLVSxjQUFjQSxDQUFBWSxFQUFBO0lBQUEsT0FBQW5KLElBQUEsQ0FBQWdDLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FxQm5COzs7Ozs7Ozs7Ozs7Ozs7QUN2Q0Q7QUFDTyxJQUFNMEYsY0FBYyxHQUFHLFVBQVUsQzs7Ozs7Ozs7Ozs7Ozs7OztBQ0QyQjtBQUM5QjtBQUNyQztBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1qQixrQkFBa0IsR0FBSW5DLFlBQVksSUFBSztFQUN6QztFQUNBLElBQU02RSxTQUFTLEdBQUc3RSxZQUFZLENBQUM2RSxTQUFTLEtBQUsvRCxTQUFTLEdBQUcsQ0FBQyxDQUFDLEdBQUcsQ0FBQ2QsWUFBWSxDQUFDNkUsU0FBUztFQUNyRixJQUFNcEIsVUFBVSxHQUFHTiw2RUFBVSxDQUFDakcsR0FBRyxDQUFDLENBQUM7RUFDbkNrQixtREFBRyxDQUFDLFlBQVksZUFBQXZDLE1BQUEsQ0FBZWdKLFNBQVMsQ0FBRSxDQUFDO0VBQzNDcEIsVUFBVSxDQUFDSyxXQUFXLENBQUMsV0FBVyxFQUFFZSxTQUFTLENBQUM7QUFDbEQsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaa0U7QUFDOUI7QUFDckM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTXhDLG9CQUFvQixHQUFHQSxDQUFBLEtBQU07RUFDL0IsSUFBTXlDLFVBQVUsR0FBR2hKLFFBQVEsQ0FBQ2lKLElBQUksQ0FBQ0MsWUFBWTtFQUM3QyxJQUFNQyxpQkFBaUIsR0FBRzVGLE1BQU0sQ0FBQzZGLFdBQVc7RUFDNUM7RUFDQTtFQUNBLElBQUlELGlCQUFpQixLQUFLLENBQUMsRUFBRTtJQUN6QjdHLG1EQUFHLENBQUMsWUFBWSwwRUFBMEUsQ0FBQztJQUMzRjtFQUNKO0VBQ0E7RUFDQSxJQUFNK0csWUFBWSxHQUFHQyxJQUFJLENBQUNDLEtBQUssQ0FBQ1AsVUFBVSxHQUFHRyxpQkFBaUIsQ0FBQztFQUMvRCxJQUFNeEIsVUFBVSxHQUFHTiw2RUFBVSxDQUFDakcsR0FBRyxDQUFDLENBQUM7RUFDbkN1RyxVQUFVLENBQUNLLFdBQVcsQ0FBQyxjQUFjLEVBQUVxQixZQUFZLENBQUM7RUFDcEQsSUFBTUcsUUFBUSxHQUFHLElBQUlDLG9CQUFvQixDQUN6QztFQUNDQyxPQUFPLElBQUs7SUFDVEEsT0FBTyxDQUFDQyxPQUFPLENBQUVDLEtBQUssSUFBSztNQUN2QixJQUFJQSxLQUFLLENBQUNDLGNBQWMsRUFBRTtRQUN0QixJQUFNQyxjQUFjLEdBQUdDLE1BQU0sQ0FBQ0gsS0FBSyxDQUFDSSxNQUFNLENBQUNDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN0RTNILG1EQUFHLENBQUMsWUFBWSwwQkFBQXZDLE1BQUEsQ0FBMEIrSixjQUFjLENBQUUsQ0FBQztRQUMzRG5DLFVBQVUsQ0FBQ0MsSUFBSSxvQkFBQTdILE1BQUEsQ0FBb0IrSixjQUFjLENBQUUsQ0FBQztRQUNwRE4sUUFBUSxDQUFDVSxTQUFTLENBQUNOLEtBQUssQ0FBQ0ksTUFBTSxDQUFDO01BQ3BDO0lBQ0osQ0FBQyxDQUFDO0VBQ04sQ0FBQyxDQUFDO0VBQ0YsS0FBSyxJQUFJRyxLQUFLLEdBQUcsQ0FBQyxFQUFFQSxLQUFLLElBQUlkLFlBQVksRUFBRWMsS0FBSyxFQUFFLEVBQUU7SUFDaEQsSUFBTUMsR0FBRyxHQUFHcEssUUFBUSxDQUFDcUssYUFBYSxDQUFDLEtBQUssQ0FBQztJQUN6Q0QsR0FBRyxDQUFDRSxPQUFPLENBQUNILEtBQUssR0FBR0osTUFBTSxDQUFDSSxLQUFLLENBQUM7SUFDakNDLEdBQUcsQ0FBQ0csS0FBSyxDQUFDQyxHQUFHLEdBQUdULE1BQU0sQ0FBQyxHQUFHLEdBQUdJLEtBQUssQ0FBQyxHQUFHLEdBQUc7SUFDekNDLEdBQUcsQ0FBQ0csS0FBSyxDQUFDRSxRQUFRLEdBQUcsVUFBVTtJQUMvQkwsR0FBRyxDQUFDTSxTQUFTLEdBQUcscUJBQXFCO0lBQ3JDMUssUUFBUSxDQUFDaUosSUFBSSxDQUFDMEIsV0FBVyxDQUFDUCxHQUFHLENBQUM7SUFDOUJaLFFBQVEsQ0FBQ29CLE9BQU8sQ0FBQ1IsR0FBRyxDQUFDO0VBQ3pCO0FBQ0osQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29va2llcy9zZXRTZXNzaW9uQ29va2llLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvbG9jYWxlL2dldExvY2FsZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvYWQtZnJlZS1zbG90LXJlbW92ZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvY29tc2NvcmUudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL2lwc29zLW1vcmkudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL3RlYWRzLWNvb2tpZWxlc3MudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL3RyYWNrLWdwYy1zaWduYWwudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL3RyYWNrLXNjcm9sbC1kZXB0aC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL19fdmVuZG9yL2lwc29zLW1vcmkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9jb21tZXJjaWFsLWJvb3QtdXRpbHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9kZnAvZGZwLWVudi1nbG9iYWxzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvdHJhY2stZ3BjLXNpZ25hbC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL3RyYWNrLXNjcm9sbC1kZXB0aC50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBFUlJfSU5WQUxJRF9DT09LSUUgfSBmcm9tICcuL0VSUl9JTlZBTElEX0NPT0tJRS5qcyc7XG5pbXBvcnQgeyBnZXRDb29raWVWYWx1ZXMgfSBmcm9tICcuL2dldENvb2tpZVZhbHVlcy5qcyc7XG5pbXBvcnQgeyBnZXREb21haW5BdHRyaWJ1dGUgfSBmcm9tICcuL2dldERvbWFpbkF0dHJpYnV0ZS5qcyc7XG5pbXBvcnQgeyBpc1ZhbGlkQ29va2llIH0gZnJvbSAnLi9pc1ZhbGlkQ29va2llLmpzJztcbmltcG9ydCB7IG1lbW9pemVkQ29va2llcyB9IGZyb20gJy4vbWVtb2l6ZWRDb29raWVzLmpzJztcbmNvbnN0IHNldFNlc3Npb25Db29raWUgPSAoeyBuYW1lLCB2YWx1ZSB9KSA9PiB7XG4gICAgaWYgKCFpc1ZhbGlkQ29va2llKG5hbWUsIHZhbHVlKSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYCR7RVJSX0lOVkFMSURfQ09PS0lFfSAke25hbWV9PSR7dmFsdWV9YCk7XG4gICAgfVxuICAgIGRvY3VtZW50LmNvb2tpZSA9IGAke25hbWV9PSR7dmFsdWV9OyBwYXRoPS87JHtnZXREb21haW5BdHRyaWJ1dGUoKX1gO1xuICAgIGlmIChtZW1vaXplZENvb2tpZXMuaGFzKG5hbWUpKSB7XG4gICAgICAgIGNvbnN0IFt2YWx1ZTJdID0gZ2V0Q29va2llVmFsdWVzKG5hbWUpO1xuICAgICAgICBpZiAodmFsdWUyKSB7XG4gICAgICAgICAgICBtZW1vaXplZENvb2tpZXMuc2V0KG5hbWUsIHZhbHVlMik7XG4gICAgICAgIH1cbiAgICB9XG59O1xuZXhwb3J0IHsgc2V0U2Vzc2lvbkNvb2tpZSB9O1xuIiwiaW1wb3J0IHsgZ2V0Q29va2llIH0gZnJvbSAnLi4vY29va2llcy9nZXRDb29raWUuanMnO1xuaW1wb3J0IHsgc2V0U2Vzc2lvbkNvb2tpZSB9IGZyb20gJy4uL2Nvb2tpZXMvc2V0U2Vzc2lvbkNvb2tpZS5qcyc7XG5pbXBvcnQgeyBpc1N0cmluZyB9IGZyb20gJy4uL2lzU3RyaW5nL2lzU3RyaW5nLmpzJztcbmltcG9ydCB7IHN0b3JhZ2UgfSBmcm9tICcuLi9zdG9yYWdlL3N0b3JhZ2UuanMnO1xuY29uc3QgS0VZID0gXCJHVV9nZW9fY291bnRyeVwiO1xuY29uc3QgS0VZX09WRVJSSURFID0gXCJndS5nZW8ub3ZlcnJpZGVcIjtcbmNvbnN0IFVSTCA9IFwiaHR0cHM6Ly9hcGkubmV4dGdlbi5ndWFyZGlhbmFwcHMuY28udWsvZ2VvbG9jYXRpb25cIjtcbmNvbnN0IENPVU5UUllfUkVHRVggPSAvXltBLVpdezJ9JC87XG5jb25zdCBpc1ZhbGlkQ291bnRyeUNvZGUgPSAoY291bnRyeSkgPT4gaXNTdHJpbmcoY291bnRyeSkgJiYgQ09VTlRSWV9SRUdFWC50ZXN0KGNvdW50cnkpO1xubGV0IGxvY2FsZTtcbmNvbnN0IGdldExvY2FsZSA9IGFzeW5jICgpID0+IHtcbiAgICBpZiAobG9jYWxlKSB7XG4gICAgICAgIHJldHVybiBsb2NhbGU7XG4gICAgfVxuICAgIGNvbnN0IGdlb092ZXJyaWRlID0gc3RvcmFnZS5sb2NhbC5nZXQoS0VZX09WRVJSSURFKTtcbiAgICBpZiAoaXNWYWxpZENvdW50cnlDb2RlKGdlb092ZXJyaWRlKSkge1xuICAgICAgICByZXR1cm4gbG9jYWxlID0gZ2VvT3ZlcnJpZGU7XG4gICAgfVxuICAgIGNvbnN0IHN0b3JlZCA9IGdldENvb2tpZSh7IG5hbWU6IFwiR1VfZ2VvX2NvdW50cnlcIiB9KTtcbiAgICBpZiAoc3RvcmVkICYmIGlzVmFsaWRDb3VudHJ5Q29kZShzdG9yZWQpKSB7XG4gICAgICAgIHJldHVybiBsb2NhbGUgPSBzdG9yZWQ7XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IHsgY291bnRyeSB9ID0gYXdhaXQgZmV0Y2goVVJMKS50aGVuKChyZXNwb25zZSkgPT4gcmVzcG9uc2UuanNvbigpKTtcbiAgICAgICAgaWYgKGlzVmFsaWRDb3VudHJ5Q29kZShjb3VudHJ5KSkge1xuICAgICAgICAgICAgc2V0U2Vzc2lvbkNvb2tpZSh7IG5hbWU6IEtFWSwgdmFsdWU6IGNvdW50cnkgfSk7XG4gICAgICAgICAgICByZXR1cm4gbG9jYWxlID0gY291bnRyeTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn07XG5leHBvcnQgeyBnZXRMb2NhbGUgfTtcbiIsImltcG9ydCB7IG9uY2UgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgY29tbWVyY2lhbEZlYXR1cmVzIH0gZnJvbSAnLi4vLi4vbGliL2NvbW1lcmNpYWwtZmVhdHVyZXMnO1xuaW1wb3J0IHsgcmVtb3ZlU2xvdHMgfSBmcm9tICcuL3JlbW92ZS1zbG90cyc7XG4vKipcbiAqIElmIHRoZSB1c2VyIGlzIGFkLWZyZWUsIHJlbW92ZSBhbGwgYWQgc2xvdHMgb24gdGhlIHBhZ2UsXG4gKiBhcyB0aGUgYWQgc2xvdHMgYXJlIHN0aWxsIGxlZnQgb24gdGhlIHBhZ2Ugb24gZnJvbnRzLCBhbmQgbW9zdHBvcCBvbiBhcnRpY2xlc1xuICovXG5jb25zdCBhZEZyZWVTbG90UmVtb3ZlID0gb25jZSgoKSA9PiB7XG4gICAgaWYgKCFjb21tZXJjaWFsRmVhdHVyZXMuYWRGcmVlKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlbW92ZVNsb3RzKCk7XG59KTtcbmV4cG9ydCB7IGFkRnJlZVNsb3RSZW1vdmUgfTtcbiIsImltcG9ydCB7IGdldENvbnNlbnRGb3IsIGxvYWRTY3JpcHQsIGxvZywgb25Db25zZW50IH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgb25jZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBjb21tZXJjaWFsRmVhdHVyZXMgfSBmcm9tICcuLi8uLi9saWIvY29tbWVyY2lhbC1mZWF0dXJlcyc7XG5jb25zdCBjb21zY29yZVNyYyA9ICcvL3NiLnNjb3JlY2FyZHJlc2VhcmNoLmNvbS9jcy82MDM1MjUwL2JlYWNvbi5qcyc7XG5jb25zdCBjb21zY29yZUMxID0gJzInO1xuY29uc3QgY29tc2NvcmVDMiA9ICc2MDM1MjUwJztcbmNvbnN0IGdldEdsb2JhbHMgPSAoa2V5d29yZHMsIHNlY3Rpb24pID0+IHtcbiAgICBjb25zdCBnbG9iYWxzID0ge1xuICAgICAgICBjMTogY29tc2NvcmVDMSxcbiAgICAgICAgYzI6IGNvbXNjb3JlQzIsXG4gICAgICAgIGNzX3VjZnI6ICcxJyxcbiAgICAgICAgb3B0aW9uczoge1xuICAgICAgICAgICAgZW5hYmxlRmlyc3RQYXJ0eUNvb2tpZTogdHJ1ZSxcbiAgICAgICAgfSxcbiAgICB9O1xuICAgIGlmIChrZXl3b3JkcyAhPT0gJ05ldHdvcmsgRnJvbnQnKSB7XG4gICAgICAgIGdsb2JhbHMuY29tc2NvcmVrdyA9IHNlY3Rpb247XG4gICAgfVxuICAgIHJldHVybiBnbG9iYWxzO1xufTtcbmNvbnN0IGluaXRPbkNvbnNlbnQgPSAoKSA9PiB7XG4gICAgd2luZG93Ll9jb21zY29yZSA9IHdpbmRvdy5fY29tc2NvcmUgPz8gW107XG4gICAgd2luZG93Ll9jb21zY29yZS5wdXNoKGdldEdsb2JhbHMod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmtleXdvcmRzLCB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2Uuc2VjdGlvbikpO1xuICAgIHJldHVybiBsb2FkU2NyaXB0KGNvbXNjb3JlU3JjLCB7IGlkOiAnY29tc2NvcmUnLCBhc3luYzogdHJ1ZSB9KTtcbn07XG4vKipcbiAqIEluaXRpYWxpc2UgY29tc2NvcmUsIGluZHVzdHJ5LXdpZGUgYXVkaWVuY2UgdHJhY2tpbmdcbiAqIGh0dHBzOi8vd3d3LmNvbXNjb3JlLmNvbS9BYm91dFxuICovXG5jb25zdCBzZXR1cENvbXNjb3JlID0gYXN5bmMgKCkgPT4ge1xuICAgIGlmICghY29tbWVyY2lhbEZlYXR1cmVzLmNvbXNjb3JlKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgY29uc2VudFN0YXRlID0gYXdhaXQgb25Db25zZW50KCk7XG4gICAgICAgIC8qIFJ1bGUgaXMgdGhhdCBjb21zY29yZSBjYW4gcnVuOlxuICAgICAgICAtIGluIFRjZnYyOiBCYXNlZCBvbiBjb25zZW50IGZvciBjb21zY29yZVxuICAgICAgICAtIGluIEF1c3RyYWxpYTogQWx3YXlzXG4gICAgICAgIC0gaW4gVVNOQVQ6IElmIHRoZSB1c2VyIGhhc24ndCBjaG9zZW4gRG8gTm90IFNlbGxcbiAgICAgICAgVE9ETyBtb3ZlIHRoaXMgbG9naWMgdG8gZ2V0Q29uc2VudEZvclxuICAgICAgICAqL1xuICAgICAgICBjb25zdCBjYW5SdW5UY2Z2MiA9IChjb25zZW50U3RhdGUudGNmdjIgJiYgZ2V0Q29uc2VudEZvcignY29tc2NvcmUnLCBjb25zZW50U3RhdGUpKSA/P1xuICAgICAgICAgICAgZmFsc2U7XG4gICAgICAgIGNvbnN0IGNhblJ1bkF1cyA9ICEhY29uc2VudFN0YXRlLmF1cztcbiAgICAgICAgY29uc3QgY2FuUnVuVXNuYXQgPSAhIWNvbnNlbnRTdGF0ZS51c25hdCAmJiAhY29uc2VudFN0YXRlLnVzbmF0LmRvTm90U2VsbDtcbiAgICAgICAgaWYgKCEoY2FuUnVuVGNmdjIgfHwgY2FuUnVuQXVzIHx8IGNhblJ1blVzbmF0KSkge1xuICAgICAgICAgICAgdGhyb3cgRXJyb3IoJ05vIGNvbnNlbnQgZm9yIGNvbXNjb3JlJyk7XG4gICAgICAgIH1cbiAgICAgICAgYXdhaXQgaW5pdE9uQ29uc2VudCgpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsICfimqDvuI8gRmFpbGVkIHRvIGV4ZWN1dGUgY29tc2NvcmUnLCBlKTtcbiAgICB9XG59O1xuY29uc3Qgc2V0dXBDb21zY29yZU9uY2UgPSBvbmNlKHNldHVwQ29tc2NvcmUpO1xuZXhwb3J0IGNvbnN0IGluaXQgPSAoKSA9PiBzZXR1cENvbXNjb3JlT25jZSgpO1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgZ2V0R2xvYmFscyxcbiAgICBzZXR1cENvbXNjb3JlLFxuICAgIGNvbXNjb3JlU3JjLFxuICAgIGNvbXNjb3JlQzEsXG4gICAgY29tc2NvcmVDMixcbn07XG4iLCJpbXBvcnQgeyBnZXRDb25zZW50Rm9yLCBnZXRMb2NhbGUsIGxvYWRTY3JpcHQsIGxvZywgb25Db25zZW50LCB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGlwc29zTW9yaVN0dWIgfSBmcm9tICcuLi8uLi9saWIvX192ZW5kb3IvaXBzb3MtbW9yaSc7XG5jb25zdCBsb2FkSXBzb3NTY3JpcHQgPSAobG9jYWxlKSA9PiB7XG4gICAgaXBzb3NNb3JpU3R1YigpO1xuICAgIGNvbnN0IGlwc29zVGFnID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlwc29zVGFnO1xuICAgIGlmIChpcHNvc1RhZyA9PT0gdW5kZWZpbmVkKVxuICAgICAgICB0aHJvdyBFcnJvcignSXBzb3MgdGFnIHVuZGVmaW5lZCcpO1xuICAgIGNvbnN0IGlwc29zU291cmNlID0gYGh0dHBzOi8vJHtsb2NhbGV9LXNjcmlwdC5kb3RtZXRyaWNzLm5ldC9kb29yLmpzP2Q9JHtkb2N1bWVudC5sb2NhdGlvbi5ob3N0fSZ0PSR7aXBzb3NUYWd9YDtcbiAgICByZXR1cm4gbG9hZFNjcmlwdChpcHNvc1NvdXJjZSwge1xuICAgICAgICBpZDogJ2lwc29zJyxcbiAgICAgICAgYXN5bmM6IHRydWUsXG4gICAgICAgIHR5cGU6ICd0ZXh0L2phdmFzY3JpcHQnLFxuICAgIH0pO1xufTtcbi8qKlxuICogSW5pdGlhbGlzZSBJcHNvcyBNb3JpIC0gbWFya2V0IHJlc2VhcmNoIHBhcnRuZXJcbiAqIGRvY3VtZW50YXRpb24gb24gRENSOiBbbGlua10oaHR0cHM6Ly9naXRodWIuY29tL2d1YXJkaWFuL2RvdGNvbS1yZW5kZXJpbmcvYmxvYi8xNTBmYzJkODFlNmE2NmQ5YzMzMzYxODVlODc0ZmM4Y2QwMjg4NTQ2L2RvdGNvbS1yZW5kZXJpbmcvZG9jcy9hcmNoaXRlY3R1cmUvM3JkJTIwcGFydHklMjB0ZWNobmljYWwlMjByZXZpZXcvMDAyLWlwc29zLW1vcmkubWQpXG4gKiBAcmV0dXJucyBQcm9taXNlXG4gKi9cbmV4cG9ydCBjb25zdCBpbml0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGxvY2FsZSA9IGF3YWl0IGdldExvY2FsZSgpO1xuICAgIGNvbnN0IGNvbnNlbnRTdGF0ZSA9IGF3YWl0IG9uQ29uc2VudCgpO1xuICAgIGNvbnN0IGlzQVUgPSBsb2NhbGUgPT09ICdBVScgJiYgISFjb25zZW50U3RhdGUuYXVzO1xuICAgIGNvbnN0IGlzVUsgPSBsb2NhbGUgPT09ICdHQicgJiYgISFjb25zZW50U3RhdGUudGNmdjI7XG4gICAgaWYgKCFpc0FVICYmICFpc1VLKSB7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsICdTa2lwcGluZyBpcHNvcyBwcm9jZXNzIG91dHNpZGUgR0Igb3IgQVUnKTtcbiAgICB9XG4gICAgaWYgKGlzQVUpIHtcbiAgICAgICAgdm9pZCBsb2FkSXBzb3NTY3JpcHQoJ2F1Jyk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzVUspIHtcbiAgICAgICAgY29uc3QgaGFzQ29uc2VudCA9IGdldENvbnNlbnRGb3IoJ2lwc29zJywgY29uc2VudFN0YXRlKTtcbiAgICAgICAgaWYgKGhhc0NvbnNlbnQpIHtcbiAgICAgICAgICAgIHZvaWQgbG9hZElwc29zU2NyaXB0KCd1aycpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ05vIGNvbnNlbnQgZm9yIGlwc29zIGluIEdCJyk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuIiwiaW1wb3J0IHsgZ2V0Q29uc2VudEZvciwgZ2V0Q29va2llLCBsb2FkU2NyaXB0LCBvbkNvbnNlbnQsIG9uQ29uc2VudENoYW5nZSwgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5jb25zdCBpbml0VGVhZHNDb29raWVsZXNzID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGNvbnNlbnRTdGF0ZSA9IGF3YWl0IG9uQ29uc2VudCgpO1xuICAgIGNvbnN0IGhhc0NvbnNlbnQgPSBnZXRDb25zZW50Rm9yKCd0ZWFkcycsIGNvbnNlbnRTdGF0ZSk7XG4gICAgLy8gVGVhZHMgb25seSBydW5zIG9uIHRoZXNlIGNvbnRlbnQgdHlwZXMsIHNvIGxldHMgbm90IGdpdmUgdGhlbSBhbnkgbW9yZSBkYXRhIHRoYW4gbmVjZXNzYXJ5XG4gICAgY29uc3QgYWxsb3dlZENvbnRlbnRUeXBlcyA9IFsnQXJ0aWNsZScsICdMaXZlQmxvZyddO1xuICAgIGlmIChoYXNDb25zZW50ICYmXG4gICAgICAgIGFsbG93ZWRDb250ZW50VHlwZXMuaW5jbHVkZXMod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmNvbnRlbnRUeXBlKSkge1xuICAgICAgICB3aW5kb3cudGVhZHNfYW5hbHl0aWNzID0gd2luZG93LnRlYWRzX2FuYWx5dGljcyA/PyB7fTtcbiAgICAgICAgd2luZG93LnRlYWRzX2FuYWx5dGljcy5hbmFseXRpY3NfdGFnX2lkID0gJ1BVQl8yMTY3JztcbiAgICAgICAgd2luZG93LnRlYWRzX2FuYWx5dGljcy5zaGFyZSA9XG4gICAgICAgICAgICB3aW5kb3cudGVhZHNfYW5hbHl0aWNzLnNoYXJlID8/XG4gICAgICAgICAgICAgICAgZnVuY3Rpb24gKC4uLmFyZ3MpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHdpbmRvdy50ZWFkc19hbmFseXRpY3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICh3aW5kb3cudGVhZHNfYW5hbHl0aWNzLnNoYXJlZF9kYXRhID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cudGVhZHNfYW5hbHl0aWNzLnNoYXJlZF9kYXRhID8/IFtdKS5wdXNoKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgYXdhaXQgbG9hZFNjcmlwdCgnaHR0cHM6Ly9hLnRlYWRzLnR2L2FuYWx5dGljcy90YWcuanMnLCB7XG4gICAgICAgICAgICBhc3luYzogZmFsc2UsXG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5vbkNvbnNlbnRDaGFuZ2UoKGNvbnNlbnRTdGF0ZSkgPT4ge1xuICAgIGNvbnN0IGhhc0NvbnNlbnQgPSBnZXRDb25zZW50Rm9yKCd0ZWFkcycsIGNvbnNlbnRTdGF0ZSk7XG4gICAgY29uc3QgdGVhZHNDb29raWUgPSBnZXRDb29raWUoeyBuYW1lOiAnX3RmcHZpJyB9KTtcbiAgICBpZiAoIWhhc0NvbnNlbnQgJiYgdGVhZHNDb29raWUpIHtcbiAgICAgICAgLypcbiAgICAgICAgVGVhZHMgc2V0cyBhIGNvb2tpZSBjYWxsZWQgX3RmcHZpLCB3aGljaCBpcyB1c2VkIHRvIHRyYWNrIHVzZXJzIGFjcm9zcyBzaXRlcy5cbiAgICAgICAgV2UgbmVlZCB0byBkZWxldGUgdGhpcyBjb29raWUgaWYgdGhlIHVzZXIgaGFzIG5vdCBjb25zZW50ZWQgdG8gVGVhZHMuXG4gICAgICAgIFdlIGNhbid0IHVzZSB0aGUgQGd1YXJkaWFuL2xpYnMgc2V0Q29va2llIGZ1bmN0aW9uIGhlcmUsIGJlY2F1c2UgaXQgbm9ybWFsaXplc1xuICAgICAgICB0aGUgZG9tYWluIHRvIHRoZWd1YXJkaWFuLmNvbSBidXQgdGhlIGNvb2tpZSBpcyBzZXQgb24gd3d3LnRoZWd1YXJkaWFuLmNvbVxuICAgICAgICAqL1xuICAgICAgICBkb2N1bWVudC5jb29raWUgPSAnX3RmcHZpPTtwYXRoPS8nO1xuICAgIH1cbn0pO1xuZXhwb3J0IHsgaW5pdFRlYWRzQ29va2llbGVzcyB9O1xuIiwiaW1wb3J0IHsgbG9nLCBvbkNvbnNlbnQgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBpbml0VHJhY2tHcGNTaWduYWwgfSBmcm9tICcuLi8uLi9saWIvdHJhY2stZ3BjLXNpZ25hbCc7XG4vKipcbiAqIEluaXRpYWxpc2UgZ3BjIHNpZ25hbCB0cmFja2luZ1xuICogQHJldHVybnMgUHJvbWlzZVxuICovXG5leHBvcnQgY29uc3QgaW5pdCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBjb25zZW50U3RhdGUgPSBhd2FpdCBvbkNvbnNlbnQoKTtcbiAgICBpZiAoY29uc2VudFN0YXRlLmNhblRhcmdldCkge1xuICAgICAgICBpbml0VHJhY2tHcGNTaWduYWwoY29uc2VudFN0YXRlKTtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ3RyYWNraW5nIGdwYyBzaWduYWwnKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsICdObyBjb25zZW50IHRvIHRyYWNrIGdwYyBzaWduYWwnKTtcbiAgICB9XG59O1xuIiwiaW1wb3J0IHsgbG9nLCBvbkNvbnNlbnQgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBpbml0VHJhY2tTY3JvbGxEZXB0aCB9IGZyb20gJy4uLy4uL2xpYi90cmFjay1zY3JvbGwtZGVwdGgnO1xuLyoqXG4gKiBJbml0aWFsaXNlIHNjcm9sbCBkZXB0aCAvIHZlbG9jaXR5IHRyYWNraW5nIGlmIHVzZXIgaGFzIGNvbnNlbnRlZCB0byByZWxldmFudCBwdXJwb3Nlcy5cbiAqIEByZXR1cm5zIFByb21pc2VcbiAqL1xuZXhwb3J0IGNvbnN0IGluaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3Qgc3RhdGUgPSBhd2FpdCBvbkNvbnNlbnQoKTtcbiAgICBpZiAoXG4gICAgLy8gUHVycG9zZSA4IC0gTWVhc3VyZSBjb250ZW50IHBlcmZvcm1hbmNlXG4gICAgKHN0YXRlLmZyYW1ld29yayA9PSAndGNmdjInICYmICEhc3RhdGUudGNmdjI/LmNvbnNlbnRzWzhdKSB8fFxuICAgICAgICBzdGF0ZS5jYW5UYXJnZXQpIHtcbiAgICAgICAgaW5pdFRyYWNrU2Nyb2xsRGVwdGgoKTtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ3RyYWNraW5nIHNjcm9sbCBkZXB0aCcpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ05vIGNvbnNlbnQgdG8gdHJhY2sgc2Nyb2xsIGRlcHRoJyk7XG4gICAgfVxufTtcbiIsIi8qKlxuICogTG9hZCB0aGUgSXBzb3MgTW9yaSBTdHViXG4gKlxuICogU2VlIHtATGluayBodHRwczovL2dpdGh1Yi5jb20vZ3VhcmRpYW4vZG90Y29tLXJlbmRlcmluZy9ibG9iLzE1MGZjMmQ4MWU2YTY2ZDljMzMzNjE4NWU4NzRmYzhjZDAyODg1NDYvZG90Y29tLXJlbmRlcmluZy9kb2NzL2FyY2hpdGVjdHVyZS8zcmQlMjBwYXJ0eSUyMHRlY2huaWNhbCUyMHJldmlldy8wMDItaXBzb3MtbW9yaS5tZCBkb2N1bWVudGF0aW9uIGhlcmUgfVxuICovXG5leHBvcnQgY29uc3QgaXBzb3NNb3JpU3R1YiA9ICgpID0+IHtcbiAgICB3aW5kb3cuZG0gPSB3aW5kb3cuZG0gfHwgeyBBamF4RGF0YTogW10gfTtcbiAgICB3aW5kb3cuZG0uQWpheEV2ZW50ID0gKGV0LCBkLCBzc2lkLCBhZCkgPT4ge1xuICAgICAgICBkbS5BamF4RGF0YS5wdXNoKHsgZXQsIGQsIHNzaWQsIGFkIH0pO1xuICAgICAgICBpZiAod2luZG93LkRvdE1ldHJpY3NPYmopIHtcbiAgICAgICAgICAgIERvdE1ldHJpY3NPYmoub25BamF4RGF0YVVwZGF0ZSgpO1xuICAgICAgICB9XG4gICAgfTtcbn07XG4iLCJpbXBvcnQgeyBFdmVudFRpbWVyIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9ldmVudC10aW1lcic7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBhZFNsb3RJZFByZWZpeCB9IGZyb20gJy4vZGZwL2RmcC1lbnYtZ2xvYmFscyc7XG5pbXBvcnQgeyByZXBvcnRFcnJvciB9IGZyb20gJy4vZXJyb3IvcmVwb3J0LWVycm9yJztcbmNvbnN0IHRhZ3MgPSB7XG4gICAgYnVuZGxlOiAnc3RhbmRhbG9uZScsXG59O1xuY29uc3QgcmVjb3JkQ29tbWVyY2lhbE1ldHJpY3MgPSAoKSA9PiB7XG4gICAgY29uc3QgZXZlbnRUaW1lciA9IEV2ZW50VGltZXIuZ2V0KCk7XG4gICAgZXZlbnRUaW1lci5tYXJrKCdjb21tZXJjaWFsQm9vdEVuZCcpO1xuICAgIGV2ZW50VGltZXIubWFyaygnY29tbWVyY2lhbE1vZHVsZXNMb2FkZWQnKTtcbiAgICAvLyByZWNvcmQgdGhlIG51bWJlciBvZiBhZCBzbG90cyBvbiB0aGUgcGFnZVxuICAgIGNvbnN0IGFkU2xvdHNUb3RhbCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoYFtpZF49XCIke2FkU2xvdElkUHJlZml4fVwiXWApLmxlbmd0aDtcbiAgICBldmVudFRpbWVyLnNldFByb3BlcnR5KCdhZFNsb3RzVG90YWwnLCBhZFNsb3RzVG90YWwpO1xuICAgIC8vIGFuZCB0aGUgbnVtYmVyIG9mIGlubGluZSBhZCBzbG90c1xuICAgIGNvbnN0IGFkU2xvdHNJbmxpbmUgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKGBbaWRePVwiJHthZFNsb3RJZFByZWZpeH1pbmxpbmVcIl1gKS5sZW5ndGg7XG4gICAgZXZlbnRUaW1lci5zZXRQcm9wZXJ0eSgnYWRTbG90c0lubGluZScsIGFkU2xvdHNJbmxpbmUpO1xufTtcbmNvbnN0IGJvb3RDb21tZXJjaWFsID0gYXN5bmMgKG1vZHVsZXMpID0+IHtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCAn8J+TpiBzdGFuZGFsb25lLmNvbW1lcmNpYWwudHMnLCBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyk7XG4gICAgaWYgKHByb2Nlc3MuZW52LkNPTU1JVF9TSEEpIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYEBndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUgY29tbWl0IGh0dHBzOi8vZ2l0aHViLmNvbS9ndWFyZGlhbi9jb21tZXJjaWFsL2Jsb2IvJHtwcm9jZXNzLmVudi5DT01NSVRfU0hBfWApO1xuICAgIH1cbiAgICAvLyBJbml0IENvbW1lcmNpYWwgZXZlbnQgdGltZXJzXG4gICAgRXZlbnRUaW1lci5pbml0KCk7XG4gICAgRXZlbnRUaW1lci5nZXQoKS5tYXJrKCdjb21tZXJjaWFsU3RhcnQnKTtcbiAgICBFdmVudFRpbWVyLmdldCgpLm1hcmsoJ2NvbW1lcmNpYWxCb290U3RhcnQnKTtcbiAgICAvLyBTdHViIHRoZSBjb21tYW5kIHF1ZXVlXG4gICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtLSBpdOKAmXMgYSBzdHViLCBub3QgdGhlIHdob2xlIEdvb2dsZXRhZyBvYmplY3RcbiAgICB3aW5kb3cuZ29vZ2xldGFnID0ge1xuICAgICAgICBjbWQ6IFtdLFxuICAgIH07XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UuYWxsU2V0dGxlZChtb2R1bGVzLm1hcCgobW9kdWxlKSA9PiBtb2R1bGUoKSkpLnRoZW4ocmVjb3JkQ29tbWVyY2lhbE1ldHJpY3MpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgLy8gcmVwb3J0IGFzeW5jIGVycm9ycyBpbiBib290Q29tbWVyY2lhbCB0byBTZW50cnkgd2l0aCB0aGUgY29tbWVyY2lhbCBmZWF0dXJlIHRhZ1xuICAgICAgICByZXBvcnRFcnJvcihlcnJvciwgJ2NvbW1lcmNpYWwnLCB0YWdzKTtcbiAgICB9XG59O1xuZXhwb3J0IHsgYm9vdENvbW1lcmNpYWwgfTtcbiIsIi8qIHByZWZpeCBmb3IgaWQgb2YgYWxsIGFkIHNsb3QgZWxlbWVudHMgKi9cbmV4cG9ydCBjb25zdCBhZFNsb3RJZFByZWZpeCA9ICdkZnAtYWQtLSc7XG4iLCJpbXBvcnQgeyBFdmVudFRpbWVyIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9ldmVudC10aW1lcic7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG4vKipcbiAqIENvbGxlY3QgbWV0cmljcyBvbiBncGNTaWduYWwgcHJlc2VuY2UgYW5kIHZhbHVlXG4gKiBodHRwczovL2dsb2JhbHByaXZhY3ljb250cm9sLmdpdGh1Yi5pby9ncGMtc3BlYy9cbiAqL1xuY29uc3QgaW5pdFRyYWNrR3BjU2lnbmFsID0gKGNvbnNlbnRTdGF0ZSkgPT4ge1xuICAgIC8vIElmIHVuZGVmaW5lZCB3ZSBzZXQgdGhlIHByb3BlcnR5IHZhbHVlIHRvIC0xLCBmYWxzZSBpcyAwLCB0cnVlIGlzIDFcbiAgICBjb25zdCBncGNTaWduYWwgPSBjb25zZW50U3RhdGUuZ3BjU2lnbmFsID09PSB1bmRlZmluZWQgPyAtMSA6ICtjb25zZW50U3RhdGUuZ3BjU2lnbmFsO1xuICAgIGNvbnN0IGV2ZW50VGltZXIgPSBFdmVudFRpbWVyLmdldCgpO1xuICAgIGxvZygnY29tbWVyY2lhbCcsIGBncGNTaWduYWwgJHtncGNTaWduYWx9YCk7XG4gICAgZXZlbnRUaW1lci5zZXRQcm9wZXJ0eSgnZ3BjU2lnbmFsJywgZ3BjU2lnbmFsKTtcbn07XG5leHBvcnQgeyBpbml0VHJhY2tHcGNTaWduYWwgfTtcbiIsImltcG9ydCB7IEV2ZW50VGltZXIgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2V2ZW50LXRpbWVyJztcbmltcG9ydCB7IGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbi8qKlxuICogQ29sbGVjdCBjb21tZXJjaWFsIG1ldHJpY3Mgb24gc2Nyb2xsIGRlcHRoXG4gKiBJbnNlcnQgaGlkZGVuIGVsZW1lbnRzIGF0IGludGVydmFscyBvZiAxIHZpZXdwb3J0IGhlaWdodFxuICogdGhlbiB1c2UgYW4gaW50ZXJzZWN0aW9uIG9ic2VydmVyIHRvIG1hcmsgdGhlIHRpbWUgd2hlbiB0aGUgdmlld3BvcnQgaW50ZXJzZWN0cyB3aXRoIHRoZXNlIGVsZW1lbnRzLlxuICogQXBwcm9hY2ggaW5zcGlyZWQgYnkgaHR0cHM6Ly9naXN0LmdpdGh1Yi5jb20vYmdyZWF0ZXIvMjQxMjUxN2Y1YTNmOWM2ZmM0Y2FmZWIxY2E3MTM4NGZcbiAqL1xuY29uc3QgaW5pdFRyYWNrU2Nyb2xsRGVwdGggPSAoKSA9PiB7XG4gICAgY29uc3QgcGFnZUhlaWdodCA9IGRvY3VtZW50LmJvZHkub2Zmc2V0SGVpZ2h0O1xuICAgIGNvbnN0IGludFZpZXdwb3J0SGVpZ2h0ID0gd2luZG93LmlubmVySGVpZ2h0O1xuICAgIC8vIHRoaXMgaWYgc3RhdGVtZW50IGlzIGhlcmUgdG8gaGFuZGxlIGEgYnVnIGluIEZpcmVmb3ggaW4gQW5kcm9pZCB3aGVyZSB0aGUgaW5uZXJIZWlnaHRcbiAgICAvLyBvZiBhIG5ldyB0YWIgY2FuIGJlIDAsIHNvIHdlIGVuZCB1cCBkaXZpZGluZyBieSAwIGFuZCBsb29waW5nIHRocm91Z2ggaW5maW5pdHlcbiAgICBpZiAoaW50Vmlld3BvcnRIZWlnaHQgPT09IDApIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYE5vdCB0cmFja2luZyBzY3JvbGwgZGVwdGggYmVjYXVzZSB2aWV3cG9ydCBoZWlnaHQgY2Fubm90IGJlIGRldGVybWluZWRgKTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvLyBob3cgbWFueSB2aWV3cG9ydHMgdGFsbCBpcyB0aGUgcGFnZT9cbiAgICBjb25zdCBwYWdlSGVpZ2h0VkggPSBNYXRoLmZsb29yKHBhZ2VIZWlnaHQgLyBpbnRWaWV3cG9ydEhlaWdodCk7XG4gICAgY29uc3QgZXZlbnRUaW1lciA9IEV2ZW50VGltZXIuZ2V0KCk7XG4gICAgZXZlbnRUaW1lci5zZXRQcm9wZXJ0eSgncGFnZUhlaWdodFZIJywgcGFnZUhlaWdodFZIKTtcbiAgICBjb25zdCBvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihcbiAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICAgIChlbnRyaWVzKSA9PiB7XG4gICAgICAgIGVudHJpZXMuZm9yRWFjaCgoZW50cnkpID0+IHtcbiAgICAgICAgICAgIGlmIChlbnRyeS5pc0ludGVyc2VjdGluZykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGN1cnJlbnREZXB0aFZIID0gU3RyaW5nKGVudHJ5LnRhcmdldC5nZXRBdHRyaWJ1dGUoJ2RhdGEtZGVwdGgnKSk7XG4gICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYGN1cnJlbnQgc2Nyb2xsIGRlcHRoICR7Y3VycmVudERlcHRoVkh9YCk7XG4gICAgICAgICAgICAgICAgZXZlbnRUaW1lci5tYXJrKGBzY3JvbGwtZGVwdGgtdmgtJHtjdXJyZW50RGVwdGhWSH1gKTtcbiAgICAgICAgICAgICAgICBvYnNlcnZlci51bm9ic2VydmUoZW50cnkudGFyZ2V0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfSk7XG4gICAgZm9yIChsZXQgZGVwdGggPSAxOyBkZXB0aCA8PSBwYWdlSGVpZ2h0Vkg7IGRlcHRoKyspIHtcbiAgICAgICAgY29uc3QgZGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgIGRpdi5kYXRhc2V0LmRlcHRoID0gU3RyaW5nKGRlcHRoKTtcbiAgICAgICAgZGl2LnN0eWxlLnRvcCA9IFN0cmluZygxMDAgKiBkZXB0aCkgKyAnJSc7XG4gICAgICAgIGRpdi5zdHlsZS5wb3NpdGlvbiA9ICdhYnNvbHV0ZSc7XG4gICAgICAgIGRpdi5jbGFzc05hbWUgPSAnc2Nyb2xsLWRlcHRoLW1hcmtlcic7XG4gICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoZGl2KTtcbiAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShkaXYpO1xuICAgIH1cbn07XG5leHBvcnQgeyBpbml0VHJhY2tTY3JvbGxEZXB0aCB9O1xuIl0sIm5hbWVzIjpbIkVSUl9JTlZBTElEX0NPT0tJRSIsImdldENvb2tpZVZhbHVlcyIsImdldERvbWFpbkF0dHJpYnV0ZSIsImlzVmFsaWRDb29raWUiLCJtZW1vaXplZENvb2tpZXMiLCJzZXRTZXNzaW9uQ29va2llIiwiX3JlZiIsIm5hbWUiLCJ2YWx1ZSIsIkVycm9yIiwiY29uY2F0IiwiZG9jdW1lbnQiLCJjb29raWUiLCJoYXMiLCJ2YWx1ZTIiLCJzZXQiLCJnZXRDb29raWUiLCJpc1N0cmluZyIsInN0b3JhZ2UiLCJLRVkiLCJLRVlfT1ZFUlJJREUiLCJVUkwiLCJDT1VOVFJZX1JFR0VYIiwiaXNWYWxpZENvdW50cnlDb2RlIiwiY291bnRyeSIsInRlc3QiLCJsb2NhbGUiLCJnZXRMb2NhbGUiLCJfYXN5bmNUb0dlbmVyYXRvciIsImdlb092ZXJyaWRlIiwibG9jYWwiLCJnZXQiLCJzdG9yZWQiLCJmZXRjaCIsInRoZW4iLCJyZXNwb25zZSIsImpzb24iLCJlIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJvbmNlIiwiY29tbWVyY2lhbEZlYXR1cmVzIiwicmVtb3ZlU2xvdHMiLCJhZEZyZWVTbG90UmVtb3ZlIiwiYWRGcmVlIiwiUHJvbWlzZSIsInJlc29sdmUiLCJnZXRDb25zZW50Rm9yIiwibG9hZFNjcmlwdCIsImxvZyIsIm9uQ29uc2VudCIsImNvbXNjb3JlU3JjIiwiY29tc2NvcmVDMSIsImNvbXNjb3JlQzIiLCJnZXRHbG9iYWxzIiwia2V5d29yZHMiLCJzZWN0aW9uIiwiZ2xvYmFscyIsImMxIiwiYzIiLCJjc191Y2ZyIiwib3B0aW9ucyIsImVuYWJsZUZpcnN0UGFydHlDb29raWUiLCJjb21zY29yZWt3IiwiaW5pdE9uQ29uc2VudCIsIl93aW5kb3ckX2NvbXNjb3JlIiwid2luZG93IiwiX2NvbXNjb3JlIiwicHVzaCIsImd1YXJkaWFuIiwiY29uZmlnIiwicGFnZSIsImlkIiwiYXN5bmMiLCJzZXR1cENvbXNjb3JlIiwiY29tc2NvcmUiLCJfcmVmMiIsImNvbnNlbnRTdGF0ZSIsImNhblJ1blRjZnYyIiwidGNmdjIiLCJjYW5SdW5BdXMiLCJhdXMiLCJjYW5SdW5Vc25hdCIsInVzbmF0IiwiZG9Ob3RTZWxsIiwic2V0dXBDb21zY29yZU9uY2UiLCJpbml0IiwiXyIsImlwc29zTW9yaVN0dWIiLCJsb2FkSXBzb3NTY3JpcHQiLCJpcHNvc1RhZyIsInVuZGVmaW5lZCIsImlwc29zU291cmNlIiwibG9jYXRpb24iLCJob3N0IiwidHlwZSIsImlzQVUiLCJpc1VLIiwiaGFzQ29uc2VudCIsIm9uQ29uc2VudENoYW5nZSIsImluaXRUZWFkc0Nvb2tpZWxlc3MiLCJhbGxvd2VkQ29udGVudFR5cGVzIiwiaW5jbHVkZXMiLCJjb250ZW50VHlwZSIsIl93aW5kb3ckdGVhZHNfYW5hbHl0aSIsIl93aW5kb3ckdGVhZHNfYW5hbHl0aTIiLCJ0ZWFkc19hbmFseXRpY3MiLCJhbmFseXRpY3NfdGFnX2lkIiwic2hhcmUiLCJfd2luZG93JHRlYWRzX2FuYWx5dGkzIiwic2hhcmVkX2RhdGEiLCJ0ZWFkc0Nvb2tpZSIsImluaXRUcmFja0dwY1NpZ25hbCIsImNhblRhcmdldCIsImluaXRUcmFja1Njcm9sbERlcHRoIiwiX3N0YXRlJHRjZnYiLCJzdGF0ZSIsImZyYW1ld29yayIsImNvbnNlbnRzIiwiZG0iLCJBamF4RGF0YSIsIkFqYXhFdmVudCIsImV0IiwiZCIsInNzaWQiLCJhZCIsIkRvdE1ldHJpY3NPYmoiLCJvbkFqYXhEYXRhVXBkYXRlIiwiRXZlbnRUaW1lciIsImFkU2xvdElkUHJlZml4IiwicmVwb3J0RXJyb3IiLCJ0YWdzIiwiYnVuZGxlIiwicmVjb3JkQ29tbWVyY2lhbE1ldHJpY3MiLCJldmVudFRpbWVyIiwibWFyayIsImFkU2xvdHNUb3RhbCIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJsZW5ndGgiLCJzZXRQcm9wZXJ0eSIsImFkU2xvdHNJbmxpbmUiLCJib290Q29tbWVyY2lhbCIsIm1vZHVsZXMiLCJfX3dlYnBhY2tfcHVibGljX3BhdGhfXyIsInByb2Nlc3MiLCJlbnYiLCJDT01NSVRfU0hBIiwiZ29vZ2xldGFnIiwiY21kIiwiYWxsU2V0dGxlZCIsIm1hcCIsIm1vZHVsZSIsImVycm9yIiwiX3giLCJncGNTaWduYWwiLCJwYWdlSGVpZ2h0IiwiYm9keSIsIm9mZnNldEhlaWdodCIsImludFZpZXdwb3J0SGVpZ2h0IiwiaW5uZXJIZWlnaHQiLCJwYWdlSGVpZ2h0VkgiLCJNYXRoIiwiZmxvb3IiLCJvYnNlcnZlciIsIkludGVyc2VjdGlvbk9ic2VydmVyIiwiZW50cmllcyIsImZvckVhY2giLCJlbnRyeSIsImlzSW50ZXJzZWN0aW5nIiwiY3VycmVudERlcHRoVkgiLCJTdHJpbmciLCJ0YXJnZXQiLCJnZXRBdHRyaWJ1dGUiLCJ1bm9ic2VydmUiLCJkZXB0aCIsImRpdiIsImNyZWF0ZUVsZW1lbnQiLCJkYXRhc2V0Iiwic3R5bGUiLCJ0b3AiLCJwb3NpdGlvbiIsImNsYXNzTmFtZSIsImFwcGVuZENoaWxkIiwib2JzZXJ2ZSJdLCJzb3VyY2VSb290IjoiIn0=