"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["src_events_empty-advert_ts-src_init_shared_reload-page-on-consent-change_ts-src_init_shared_s-78f028"],{

/***/ "../core/src/ad-sizes.ts":
/*!*******************************!*\
  !*** ../core/src/ad-sizes.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AdSize: () => (/* binding */ AdSize),
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   adSizes: () => (/* binding */ adSizes),
/* harmony export */   createAdSize: () => (/* binding */ createAdSize),
/* harmony export */   findAppliedSizesForBreakpoint: () => (/* binding */ findAppliedSizesForBreakpoint),
/* harmony export */   getAdSize: () => (/* binding */ getAdSize),
/* harmony export */   outstreamSizes: () => (/* binding */ outstreamSizes),
/* harmony export */   slotSizeMappings: () => (/* binding */ slotSizeMappings),
/* harmony export */   standardAdSizes: () => (/* binding */ standardAdSizes)
/* harmony export */ });
/* harmony import */ var _breakpoint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./breakpoint */ "../core/src/breakpoint.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

/**
 * Store ad sizes in a way that is compatible with google-tag but also accessible via
 * more semantic `width`/`height` properties and keep things readonly.
 *
 * example:
 * const size = new AdSize([300, 250]);
 *
 * size.width === 300; // true
 * size[0] === 300; // true
 *
 * size.height === 250; // true
 * size[1] === 250; // true
 *
 * size[0] = 200; // throws error
 * size.width = 200; // throws error
 *
 */
class AdSize extends Array {
  constructor(_ref) {
    var [width, height] = _ref;
    super();
    _defineProperty(this, 0, void 0);
    _defineProperty(this, 1, void 0);
    this[0] = width;
    this[1] = height;
  }
  toString() {
    return this.width === 0 && this.height === 0 ? 'fluid' : "".concat(this.width, ",").concat(this.height);
  }
  toArray() {
    return [this[0], this[1]];
  }
  // The advert size is not reflective of the actual size of the advert.
  // For example, fluid ads and Guardian merch ads are larger than the dimensions
  isProxy() {
    var isOutOfPage = this.width === 1 && this.height === 1;
    var isEmpty = this.width === 2 && this.height === 2;
    var isFluid = this.toString() === 'fluid';
    var isMerch = this.width === 88;
    var isSponsorLogo = this.width === 3 && this.height === 3;
    return isOutOfPage || isEmpty || isFluid || isMerch || isSponsorLogo;
  }
  get width() {
    return this[0];
  }
  get height() {
    return this[1];
  }
}
var createAdSize = (width, height) => {
  return new AdSize([width, height]);
};
var namedStandardAdSizes = {
  billboard: createAdSize(970, 250),
  halfPage: createAdSize(300, 600),
  leaderboard: createAdSize(728, 90),
  mobilesticky: createAdSize(320, 50),
  mpu: createAdSize(300, 250),
  portrait: createAdSize(300, 1050),
  skyscraper: createAdSize(160, 600),
  cascade: createAdSize(940, 230),
  portraitInterstitial: createAdSize(320, 480)
};
var standardAdSizes = {
  '970x250': namedStandardAdSizes.billboard,
  '300x600': namedStandardAdSizes.halfPage,
  '728x90': namedStandardAdSizes.leaderboard,
  '300x250': namedStandardAdSizes.mpu,
  '300x1050': namedStandardAdSizes.portrait,
  '160x600': namedStandardAdSizes.skyscraper
};
var outstreamSizes = {
  outstreamDesktop: createAdSize(620, 350),
  outstreamGoogleDesktop: createAdSize(550, 310),
  outstreamMobile: createAdSize(300, 197)
};
/**
 * Ad sizes commonly associated with third parties
 */
var proprietaryAdSizes = {
  fluid: createAdSize(0, 0),
  googleCard: createAdSize(300, 274),
  outOfPage: createAdSize(1, 1),
  pubmaticInterscroller: createAdSize(371, 660) // pubmatic only mobile size
};
/**
 * Ad sizes associated with in-house formats
 */
var guardianProprietaryAdSizes = {
  empty: createAdSize(2, 2),
  fabric: createAdSize(88, 71),
  merchandising: createAdSize(88, 88),
  merchandisingHigh: createAdSize(88, 87),
  merchandisingHighAdFeature: createAdSize(88, 89),
  /**
   * This is a proxy size (not the true size of the rendered creative)
   * that can be used to ensure that no other high priority line items
   * fill a certain slot.
   */
  sponsorLogo: createAdSize(3, 3)
};
var adSizes = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, namedStandardAdSizes), standardAdSizes), outstreamSizes), proprietaryAdSizes), guardianProprietaryAdSizes);
/**
 * mark: 432b3a46-90c1-4573-90d3-2400b51af8d0
 * Some of these may or may not need to be synced for with the sizes in ./create-ad-slot.ts
 * these were originally from DCR, create-ad-slot.ts ones were in frontend.
 *
 * Note:
 * If a breakpoint is not defined in a size mapping for a slot, that breakpoint will use the sizes
 * of the next breakpoint down that has a size mapping. For example, if only "mobile" and "phablet" sizes
 * are defined for a slot, all breakpoints larger than "phablet" will use the mapping for "phablet".
 *
 * In another example, if a slot has only "tablet" as a size mapping defined,
 * then "desktop" will use the size mapping for "tablet". "mobile" and "phablet"
 * will have no size mapping. This type of example may be used in cases where
 * we only want the slot to appear on the "tablet" size or greater.
 **/
var slotSizeMappings = {
  inline: {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.outstreamMobile, adSizes.mpu, adSizes.googleCard, adSizes.fluid],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.fluid]
  },
  right: {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.halfPage, adSizes.fluid]
  },
  comments: {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.outstreamMobile, adSizes.mpu, adSizes.googleCard, adSizes.fluid],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.fluid]
  },
  'comments-expanded': {
    mobile: [adSizes.mpu, adSizes.empty],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.fluid, adSizes.skyscraper, adSizes.halfPage]
  },
  'top-above-nav': {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.fabric, adSizes.outstreamMobile, adSizes.mpu, adSizes.fluid],
    tablet: [adSizes.outOfPage, adSizes.empty, adSizes.fabric, adSizes.fluid, adSizes.leaderboard],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.leaderboard, createAdSize(940, 230), createAdSize(900, 250), adSizes.billboard, adSizes.fabric, adSizes.fluid]
  },
  'fronts-banner': {
    tablet: [adSizes.empty, adSizes.leaderboard],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.billboard, adSizes.merchandisingHigh, adSizes.fluid]
  },
  mostpop: {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.fluid],
    phablet: [adSizes.outOfPage, adSizes.empty, adSizes.outstreamMobile, adSizes.mpu, adSizes.googleCard, adSizes.halfPage, adSizes.fluid],
    tablet: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.halfPage, adSizes.fluid],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.googleCard, adSizes.halfPage, adSizes.fluid]
  },
  'liveblog-top': {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.mpu, adSizes.fluid],
    tablet: [],
    desktop: []
  },
  'merchandising-high': {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.merchandisingHigh, adSizes.fluid, adSizes.mpu],
    tablet: [adSizes.outOfPage, adSizes.empty, adSizes.merchandisingHigh, adSizes.fluid],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.merchandisingHigh, adSizes.fluid, adSizes.billboard]
  },
  merchandising: {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.merchandising, adSizes.fluid, adSizes.mpu],
    tablet: [adSizes.outOfPage, adSizes.empty, adSizes.merchandising, adSizes.fluid],
    desktop: [adSizes.outOfPage, adSizes.empty, adSizes.merchandising, adSizes.fluid, adSizes.billboard]
  },
  survey: {
    desktop: [adSizes.outOfPage]
  },
  carrot: {
    mobile: [adSizes.fluid]
  },
  'mobile-sticky': {
    mobile: [adSizes.mobilesticky, adSizes.empty, createAdSize(300, 50)]
  },
  'crossword-banner-mobile': {
    mobile: [adSizes.mobilesticky]
  },
  'football-right': {
    desktop: [adSizes.empty, adSizes.mpu, adSizes.skyscraper, adSizes.halfPage]
  },
  'article-end': {
    mobile: [] // Mappings are dynamically added for this slot using additionalSizes
  },
  exclusion: {
    mobile: [adSizes.empty]
  },
  /**
   * @deprecated Use `slotSizeMappings['sponsor-logo']` instead
   */
  external: {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.fluid, adSizes.mpu]
  },
  'sponsor-logo': {
    mobile: [adSizes.outOfPage, adSizes.empty, adSizes.fluid, adSizes.sponsorLogo]
  },
  interactive: {
    // Mappings are dynamically added for this slot using data attributes
    mobile: [adSizes.outOfPage, adSizes.empty],
    tablet: [adSizes.outOfPage, adSizes.empty],
    desktop: [adSizes.outOfPage, adSizes.empty]
  }
};
var getAdSize = size => adSizes[size];
/**
 * Finds the ad sizes that will be used for a breakpoint given a size mapping
 *
 * If ad sizes are defined in the size mapping for the specified breakpoint, we use that.
 * If no sizes are defined for the breakpoint, use the next smallest breakpoint with defined ad sizes.
 * If no smaller breakpoints have defined ad sizes, return an empty array
 *
 * Example:
 * For the following slotSizeMappings:
 *     inline: {
 *         phablet: [adSizes.mpu],
 *         desktop: [adSizes.billboard]
 *     }
 * the applied sizes for each breakpoint for the "inline" slot will be:
 *     mobile: []
 *     phablet: [adSizes.mpu]
 *     tablet: [adSizes.mpu]
 *     desktop: [adSizes.billboard]
 *
 * See ad-sizes.test.ts for more examples
 */
var findAppliedSizesForBreakpoint = (sizeMappings, breakpoint) => {
  if (!(0,_breakpoint__WEBPACK_IMPORTED_MODULE_0__.isBreakpoint)(breakpoint)) {
    return [];
  }
  var breakpointIndex = _breakpoint__WEBPACK_IMPORTED_MODULE_0__.breakpoints.findIndex(b => b === breakpoint);
  while (breakpointIndex >= 0) {
    var breakpointToTry = _breakpoint__WEBPACK_IMPORTED_MODULE_0__.breakpoints[breakpointIndex];
    var sizeMapping = sizeMappings[breakpointToTry];
    if (sizeMapping !== null && sizeMapping !== void 0 && sizeMapping.length) {
      return sizeMapping;
    }
    breakpointIndex--;
  }
  // There are no size mappings defined for any size smaller than the breakpoint
  return [];
};
// Export for testing
var _ = {
  createAdSize
};


/***/ }),

/***/ "../core/src/breakpoint.ts":
/*!*********************************!*\
  !*** ../core/src/breakpoint.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   breakpoints: () => (/* binding */ breakpoints),
/* harmony export */   isBreakpoint: () => (/* binding */ isBreakpoint)
/* harmony export */ });
/**
 * Breakpoints ordered from smallest to largest
 */
var breakpoints = ['mobile', 'phablet', 'tablet', 'desktop', 'wide'];
var isBreakpoint = s => breakpoints.includes(s);


/***/ }),

/***/ "../core/src/constants/prebid-timeout.ts":
/*!***********************************************!*\
  !*** ../core/src/constants/prebid-timeout.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   PREBID_TIMEOUT: () => (/* binding */ PREBID_TIMEOUT)
/* harmony export */ });
/**
 * Unit: milliseconds
 */
var PREBID_TIMEOUT = 1500;

/***/ }),

/***/ "../core/src/geo/country-code.ts":
/*!***************************************!*\
  !*** ../core/src/geo/country-code.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCountryCode: () => (/* binding */ getCountryCode)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");

var editionToCountryCodeMap = {
  UK: 'GB',
  US: 'US',
  AU: 'AU'
};
var editionToCountryCode = function () {
  var editionKey = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 'UK';
  return editionToCountryCodeMap[editionKey];
};
var countryCookieName = 'GU_geo_country';
var countryOverrideName = 'gu.geo.override';
/*
   This method can be used as a non async way of getting the country code
   after init has been called. Returning locale should cover all/most
   of the cases but if a race condition happen or the cookie is not set,
   we keep fallbacks to cookie or geo from edition.
*/
var getCountryCode = () => {
  var _ref;
  var pageEdition = window.guardian.config.page.edition;
  var maybeCountryOverride = _guardian_libs__WEBPACK_IMPORTED_MODULE_2__.storage.local.get(countryOverrideName);
  var countryOverride = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isString)(maybeCountryOverride) ? maybeCountryOverride : null;
  return (_ref = countryOverride !== null && countryOverride !== void 0 ? countryOverride : (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
    name: countryCookieName,
    shouldMemoize: true
  })) !== null && _ref !== void 0 ? _ref : editionToCountryCode(pageEdition);
};


/***/ }),

/***/ "../core/src/geo/geo-utils.ts":
/*!************************************!*\
  !*** ../core/src/geo/geo-utils.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   isInAuOrNz: () => (/* binding */ isInAuOrNz),
/* harmony export */   isInAustralia: () => (/* binding */ isInAustralia),
/* harmony export */   isInCanada: () => (/* binding */ isInCanada),
/* harmony export */   isInNewZealand: () => (/* binding */ isInNewZealand),
/* harmony export */   isInRow: () => (/* binding */ isInRow),
/* harmony export */   isInUk: () => (/* binding */ isInUk),
/* harmony export */   isInUsOrCa: () => (/* binding */ isInUsOrCa),
/* harmony export */   isInUsa: () => (/* binding */ isInUsa)
/* harmony export */ });
/* harmony import */ var _country_code__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./country-code */ "../core/src/geo/country-code.ts");

// cache the users location so we only have to look it up once
var geo;
var currentGeoLocation = () => {
  geo = geo !== null && geo !== void 0 ? geo : (0,_country_code__WEBPACK_IMPORTED_MODULE_0__.getCountryCode)();
  return geo;
};
var isInUk = () => currentGeoLocation() === 'GB';
var isInUsa = () => currentGeoLocation() === 'US';
var isInCanada = () => currentGeoLocation() === 'CA';
var isInAustralia = () => currentGeoLocation() === 'AU';
var isInNewZealand = () => currentGeoLocation() === 'NZ';
var isInUsOrCa = () => isInUsa() || isInCanada();
var isInAuOrNz = () => isInAustralia() || isInNewZealand();
var isInRow = () => !isInUk() && !isInUsOrCa() && !isInAuOrNz();
var _ = {
  resetModule: () => {
    geo = undefined;
  }
};

/***/ }),

/***/ "../core/src/geo/get-locale.ts":
/*!*************************************!*\
  !*** ../core/src/geo/get-locale.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   __resetCachedValue: () => (/* binding */ __resetCachedValue),
/* harmony export */   getLocale: () => (/* binding */ getLocale)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");

var KEY = 'GU_geo_country';
var KEY_OVERRIDE = 'gu.geo.override';
var COUNTRY_REGEX = /^[A-Z]{2}$/;
// best guess that we have a valid code, without actually shipping the entire list
var isValidCountryCode = country => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isString)(country) && COUNTRY_REGEX.test(country);
// we'll cache any successful lookups so we only have to do this once
var locale;
var editionToGeolocationMap = {
  UK: 'GB',
  US: 'US',
  AU: 'AU'
};
var editionToGeolocation = editionKey => editionToGeolocationMap[editionKey];
// just used for tests
var __resetCachedValue = () => locale = undefined;
/**
 * Fetches the user's current location as an ISO 3166-1 alpha-2 string e.g. 'GB', 'AU' etc
 * Note: This has been copied from guardian-libs and made syncronous by ommiting the call to
 * the geolocation API
 */
var getLocale = () => {
  if (locale) return locale;
  // return overridden geo from localStorage, used for changing geo only for development purposes
  var geoOverride = _guardian_libs__WEBPACK_IMPORTED_MODULE_2__.storage.local.get(KEY_OVERRIDE);
  if (isValidCountryCode(geoOverride)) {
    return locale = geoOverride;
  }
  // return locale from cookie if it exists
  var stored = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
    name: KEY
  });
  if (stored && isValidCountryCode(stored)) {
    return locale = stored;
  }
  // return locale from edition
  var editionCountryCode = editionToGeolocation(window.guardian.config.page.edition);
  return locale = editionCountryCode;
};

/***/ }),

/***/ "../core/src/messenger/post-message.ts":
/*!*********************************************!*\
  !*** ../core/src/messenger/post-message.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   postMessage: () => (/* binding */ postMessage)
/* harmony export */ });
var postMessage = function (message, target) {
  var targetOrigin = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '*';
  target.postMessage(JSON.stringify(message), {
    targetOrigin
  });
};

/***/ }),

/***/ "../core/src/permutive.ts":
/*!********************************!*\
  !*** ../core/src/permutive.ts ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   clearPermutiveSegments: () => (/* binding */ clearPermutiveSegments),
/* harmony export */   getPermutivePFPSegments: () => (/* binding */ getPermutivePFPSegments),
/* harmony export */   getPermutiveSegments: () => (/* binding */ getPermutiveSegments)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");

var PERMUTIVE_KEY = "_papns";
var PERMUTIVE_PFP_KEY = "_pdfps";
var getSegments = key => {
  try {
    var rawSegments = _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.getRaw(key);
    var segments = rawSegments ? JSON.parse(rawSegments) : null;
    if (!Array.isArray(segments)) return [];
    return segments.slice(0, 250).map(s => Number.parseInt(s, 10)).filter(n => typeof n === 'number' && !Number.isNaN(n)).map(String);
  } catch (err) {
    return [];
  }
};
var getPermutiveSegments = () => getSegments(PERMUTIVE_KEY);
var getPermutivePFPSegments = () => getSegments(PERMUTIVE_PFP_KEY);
var clearPermutiveSegments = () => {
  _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.remove(PERMUTIVE_KEY);
  _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.remove(PERMUTIVE_PFP_KEY);
};
var _ = {
  PERMUTIVE_KEY,
  PERMUTIVE_PFP_KEY,
  getSegments
};


/***/ }),

/***/ "../core/src/send-commercial-metrics.ts":
/*!**********************************************!*\
  !*** ../core/src/send-commercial-metrics.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   bypassCommercialMetricsSampling: () => (/* binding */ bypassCommercialMetricsSampling),
/* harmony export */   checkConsent: () => (/* binding */ checkConsent),
/* harmony export */   initCommercialMetrics: () => (/* binding */ initCommercialMetrics)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isNonNullable/isNonNullable.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/performance/getMeasures.js");
/* harmony import */ var _event_timer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./event-timer */ "../core/src/event-timer.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var Endpoints;
(function (Endpoints) {
  Endpoints["CODE"] = "//performance-events.code.dev-guardianapis.com/commercial-metrics";
  Endpoints["PROD"] = "//performance-events.guardianapis.com/commercial-metrics";
})(Endpoints || (Endpoints = {}));
var commercialMetricsPayload = {
  page_view_id: undefined,
  browser_id: undefined,
  platform: 'NEXT_GEN',
  metrics: [],
  properties: []
};
var devProperties = [];
var adBlockerProperties = [];
var endpoint;
var setEndpoint = isDev => endpoint = isDev ? Endpoints.CODE : Endpoints.PROD;
var setDevProperties = isDev => devProperties = isDev ? [{
  name: 'isDev',
  value: window.location.hostname
}] : [];
var setAdBlockerProperties = adBlockerInUse => {
  adBlockerProperties = adBlockerInUse !== undefined ? [{
    name: 'adBlockerInUse',
    value: adBlockerInUse.toString()
  }] : [];
};
var transformToObjectEntries = eventTimerProperties => {
  // Transforms object {key: value} pairs into an array of [key, value] arrays
  return Object.entries(eventTimerProperties);
};
var mapEventTimerPropertiesToString = properties => {
  return properties.map(_ref => {
    var [name, value] = _ref;
    return {
      name: String(name),
      value: String(value)
    };
  });
};
var roundTimeStamp = (events, measures) => {
  var roundedEvents = events.map(_ref2 => {
    var {
      name,
      ts
    } = _ref2;
    return {
      name,
      value: Math.ceil(ts)
    };
  });
  var roundedMeasures = measures.map(_ref3 => {
    var {
      name,
      duration
    } = _ref3;
    return {
      name,
      value: Math.ceil(duration)
    };
  });
  return [...roundedEvents, ...roundedMeasures];
};
function sendMetrics() {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', 'About to send commercial metrics', commercialMetricsPayload);
  void fetch(endpoint, {
    method: 'POST',
    body: JSON.stringify(commercialMetricsPayload),
    keepalive: true,
    cache: 'no-store',
    mode: 'no-cors'
  });
}
/**
 * Gather how many times the user has experienced the “offline” event
 * @see https://developer.mozilla.org/en-US/docs/Web/API/Window/offline_event
 *
 * This value should be fetched as late as possible in the page lifecycle,
 * to get an accurate value.
 *
 * Relevant for an @guardian/open-journalism investigation.
 */
var getOfflineCount = () => typeof window.guardian.offlineCount === 'number' ? [{
  name: 'offlineCount',
  value: window.guardian.offlineCount
}] : [];
/**
 * Measures added with @guardian/libs’s `startPerformanceMeasure`
 *
 * Allows for more granular monitoring of web page performance.
 */
var getPerformanceMeasures = function () {
  for (var _len = arguments.length, teams = new Array(_len), _key = 0; _key < _len; _key++) {
    teams[_key] = arguments[_key];
  }
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.getMeasures)(teams).map(_ref4 => {
    var {
      detail: {
        subscription,
        name,
        action
      },
      duration
    } = _ref4;
    return {
      name: [subscription, name, action].filter(_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isNonNullable).join('_'),
      value: duration
    };
  });
};
function gatherMetricsOnPageUnload() {
  // Assemble commercial properties and metrics
  var eventTimer = _event_timer__WEBPACK_IMPORTED_MODULE_4__.EventTimer.get();
  var transformedEntries = transformToObjectEntries(eventTimer.properties);
  var filteredEventTimerProperties = transformedEntries.filter(item => typeof item[1] !== 'undefined');
  var mappedEventTimerProperties = mapEventTimerPropertiesToString(filteredEventTimerProperties);
  var properties = mappedEventTimerProperties.concat(devProperties).concat(adBlockerProperties);
  commercialMetricsPayload.properties = properties;
  var metrics = roundTimeStamp(eventTimer.marks, eventTimer.measures).concat(getOfflineCount()).concat(getPerformanceMeasures('dotcom'));
  commercialMetricsPayload.metrics = metrics;
  sendMetrics();
}
var listener = e => {
  if (window.guardian.config.shouldSendCommercialMetrics) {
    switch (e.type) {
      case 'visibilitychange':
        if (document.visibilityState === 'hidden') {
          gatherMetricsOnPageUnload();
        }
        return;
      case 'pagehide':
        gatherMetricsOnPageUnload();
        return;
    }
  }
};
var addVisibilityListeners = () => {
  // Report all available metrics when the page is unloaded or in background.
  window.addEventListener('visibilitychange', listener, {
    once: true
  });
  // Safari does not reliably fire the `visibilitychange` on page unload.
  window.addEventListener('pagehide', listener, {
    once: true
  });
};
var checkConsent = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator(function* () {
    var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
    if (consentState.tcfv2) {
      // TCFv2 mode - check for consent
      var consents = consentState.tcfv2.consents;
      var REQUIRED_CONSENTS = [7, 8];
      return REQUIRED_CONSENTS.every(consent => consents[consent]);
    }
    // non-TCFv2 mode - don't check for consent
    return true;
  });
  return function checkConsent() {
    return _ref5.apply(this, arguments);
  };
}();
/**
 * A method to asynchronously send metrics after initialization.
 */
function bypassCommercialMetricsSampling() {
  return _bypassCommercialMetricsSampling.apply(this, arguments);
}
/**
 * A method to initialise metrics.
 * Note: this is initialised in the frontend/DCR bundles, not the commercial bundle.
 * @param init.pageViewId - identifies the page view. Usually available on `guardian.config.ophan.pageViewId`. Defaults to `null`
 * @param init.browserId - identifies the browser. Usually available via `getCookie({ name: 'bwid' })`. Defaults to `null`
 * @param init.isDev - used to determine whether to use CODE or PROD endpoints.
 * @param init.adBlockerInUse - indicates whether or not an adblocker is being used.
 * @param init.sampling - rate at which to sample commercial metrics - the default is to send for 1% of pageviews
 */
function _bypassCommercialMetricsSampling() {
  _bypassCommercialMetricsSampling = _asyncToGenerator(function* () {
    if (!window.guardian.config.commercialMetricsInitialised) {
      console.warn('initCommercialMetrics not yet initialised');
      return;
    }
    var consented = yield checkConsent();
    if (consented) {
      window.guardian.config.shouldSendCommercialMetrics = true;
    } else {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', "Metrics won't be sent because consent wasn't given");
    }
  });
  return _bypassCommercialMetricsSampling.apply(this, arguments);
}
function initCommercialMetrics(_x) {
  return _initCommercialMetrics.apply(this, arguments);
}
function _initCommercialMetrics() {
  _initCommercialMetrics = _asyncToGenerator(function* (_ref6) {
    var {
      pageViewId,
      browserId,
      isDev,
      adBlockerInUse,
      sampling = 1 / 100
    } = _ref6;
    commercialMetricsPayload.page_view_id = pageViewId;
    commercialMetricsPayload.browser_id = browserId;
    setEndpoint(isDev);
    setDevProperties(isDev);
    setAdBlockerProperties(adBlockerInUse);
    addVisibilityListeners();
    if (window.guardian.config.commercialMetricsInitialised) {
      return false;
    }
    window.guardian.config.commercialMetricsInitialised = true;
    var userIsInSamplingGroup = Math.random() <= sampling;
    if (isDev || userIsInSamplingGroup) {
      var consented = yield checkConsent();
      if (consented) {
        window.guardian.config.shouldSendCommercialMetrics = true;
        return true;
      }
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', "Metrics won't be sent because consent wasn't given");
    }
    return false;
  });
  return _initCommercialMetrics.apply(this, arguments);
}
var _ = {
  Endpoints,
  setEndpoint,
  mapEventTimerPropertiesToString,
  roundTimeStamp,
  transformToObjectEntries,
  reset: () => {
    window.guardian.config.commercialMetricsInitialised = false;
    window.guardian.config.shouldSendCommercialMetrics = false;
    commercialMetricsPayload = {
      page_view_id: undefined,
      browser_id: undefined,
      platform: 'NEXT_GEN',
      metrics: [],
      properties: []
    };
    removeEventListener('visibilitychange', listener);
    removeEventListener('pagehide', listener);
  }
};


/***/ }),

/***/ "../core/src/targeting/build-page-targeting.ts":
/*!*****************************************************!*\
  !*** ../core/src/targeting/build-page-targeting.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildPageTargeting: () => (/* binding */ buildPageTargeting),
/* harmony export */   filterValues: () => (/* binding */ filterValues),
/* harmony export */   getLocalHour: () => (/* reexport safe */ _shared__WEBPACK_IMPORTED_MODULE_8__.getLocalHour)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _event_timer__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _geo_get_locale__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../geo/get-locale */ "../core/src/geo/get-locale.ts");
/* harmony import */ var _content__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./content */ "../core/src/targeting/content.ts");
/* harmony import */ var _personalised__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./personalised */ "../core/src/targeting/personalised.ts");
/* harmony import */ var _session__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./session */ "../core/src/targeting/session.ts");
/* harmony import */ var _shared__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./shared */ "../core/src/targeting/shared.ts");
/* harmony import */ var _viewport__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./viewport */ "../core/src/targeting/viewport.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }








var filterValues = pageTargets => {
  var filtered = {};
  for (var key in pageTargets) {
    var value = pageTargets[key];
    if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.isString)(value)) {
      filtered[key] = value;
    } else if (Array.isArray(value) && value.length > 0 && value.every(_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.isString)) {
      filtered[key] = value;
    }
  }
  return filtered;
};
var lastPerformanceEntryIsNavigationType = () => {
  if (!(0,_event_timer__WEBPACK_IMPORTED_MODULE_3__.supportsPerformanceAPI)()) {
    return false;
  }
  var navigationEvents = performance.getEntriesByType('navigation');
  var lastNavigationEvent = navigationEvents[navigationEvents.length - 1];
  // https://developer.mozilla.org/en-US/docs/Web/API/PerformanceEntry/entryType#navigation
  return (lastNavigationEvent === null || lastNavigationEvent === void 0 ? void 0 : lastNavigationEvent.entryType) === 'navigation';
};
var referrerMatchesHost = referrer => {
  if (!referrer) {
    return false;
  }
  var referrerUrl = new URL(referrer);
  return referrerUrl.hostname === window.location.hostname;
};
// A consentless friendly way of determining if this is the users first visit to the page
var isFirstVisit = referrer => {
  if ((0,_event_timer__WEBPACK_IMPORTED_MODULE_3__.supportsPerformanceAPI)() && !lastPerformanceEntryIsNavigationType()) {
    return false;
  }
  return !referrerMatchesHost(referrer);
};
var buildPageTargeting = _ref => {
  var _sharedAdTargeting$k, _window$guardian$conf;
  var {
    adFree,
    clientSideParticipations,
    consentState,
    isSignedIn = false,
    youtube = false
  } = _ref;
  var {
    page,
    isDotcomRendering
  } = window.guardian.config;
  var adFreeTargeting = adFree ? {
    af: 't'
  } : {};
  var sharedAdTargeting = page.sharedAdTargeting ? (0,_shared__WEBPACK_IMPORTED_MODULE_8__.getSharedTargeting)(page.sharedAdTargeting) : {};
  var contentTargeting = (0,_content__WEBPACK_IMPORTED_MODULE_5__.getContentTargeting)({
    webPublicationDate: page.webPublicationDate,
    eligibleForDCR: page.dcrCouldRender,
    path: "/".concat(page.pageId),
    renderingPlatform: isDotcomRendering ? 'dotcom-rendering' : 'dotcom-platform',
    section: page.section,
    sensitive: page.isSensitive,
    videoLength: page.videoDuration,
    keywords: (_sharedAdTargeting$k = sharedAdTargeting.k) !== null && _sharedAdTargeting$k !== void 0 ? _sharedAdTargeting$k : []
  });
  var referrer = document.referrer || '';
  var sessionTargeting = (0,_session__WEBPACK_IMPORTED_MODULE_7__.getSessionTargeting)({
    adTest: (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.getCookie)({
      name: 'adtest',
      shouldMemoize: true
    }),
    countryCode: (0,_geo_get_locale__WEBPACK_IMPORTED_MODULE_4__.getLocale)(),
    localHour: (0,_shared__WEBPACK_IMPORTED_MODULE_8__.getLocalHour)(),
    isSignedIn,
    pageViewId: window.guardian.config.ophan.pageViewId,
    participations: {
      clientSideParticipations,
      serverSideParticipations: (_window$guardian$conf = window.guardian.config.tests) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : {}
    },
    referrer
  });
  var getViewport = () => {
    return {
      width: window.innerWidth || document.body.clientWidth || 0,
      height: window.innerHeight || document.body.clientHeight || 0
    };
  };
  var viewportTargeting = (0,_viewport__WEBPACK_IMPORTED_MODULE_9__.getViewportTargeting)({
    viewPortWidth: getViewport().width,
    cmpBannerWillShow: !_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.cmp.hasInitialised() || _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.cmp.willShowPrivacyMessageSync()
  });
  var personalisedTargeting = (0,_personalised__WEBPACK_IMPORTED_MODULE_6__.getPersonalisedTargeting)({
    state: consentState,
    youtube
  });
  var consentlessTargeting = {};
  if (!(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)('googletag', consentState)) {
    consentlessTargeting.firstvisit = isFirstVisit(referrer) ? 't' : 'f';
  }
  var pageTargets = _objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread(_objectSpread({}, personalisedTargeting), sharedAdTargeting), adFreeTargeting), contentTargeting), sessionTargeting), viewportTargeting), consentlessTargeting);
  // filter !(string | string[]) and empty values
  var pageTargeting = filterValues(pageTargets);
  return pageTargeting;
};


/***/ }),

/***/ "../core/src/targeting/content.ts":
/*!****************************************!*\
  !*** ../core/src/targeting/content.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getContentTargeting: () => (/* binding */ getContentTargeting)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");

/* -- Types -- */
var videoLengths = ['25',
// TODO: confirm this is a real value
'30', '60', '90', '120', '150', '180', '210', '240', '270', '300'];
/* -- Methods -- */
var getVideoLength = videoLength => {
  var _videoLengths$index;
  var index = Math.min(Math.ceil(videoLength / 30), 10);
  return (_videoLengths$index = videoLengths[index]) !== null && _videoLengths$index !== void 0 ? _videoLengths$index : null;
};
var getUrlKeywords = url => {
  var lastSegment = url.split('/').filter(Boolean) // This handles a trailing slash
  .slice(-1)[0];
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isString)(lastSegment) ? lastSegment.split('-').filter(Boolean) : [];
};
var concatUnique = (a, b) => [...new Set([...a, ...b])];
// "0" means content < 2 hours old
// "1" means content between 2 hours and 24 hours old.
// "2" means content between 24 hours and 3 days old
// "3" means content between 3 and 7 days old
// "4" means content between 7 days and 1 month old
// "5" means content between 1 and 10 months old
// "6" means content between 10 and 14 months old
// "7" means content more than 14 months old
var calculateRecentlyPublishedBucket = webPublicationDate => {
  var now = Date.now();
  var hoursSincePublication = (now - webPublicationDate) / 1000 / 60 / 60;
  var daysSincePublication = hoursSincePublication / 24;
  var monthsSincePublication = daysSincePublication / 30; // near enough for our purposes
  if (hoursSincePublication < 2) return '0';
  if (hoursSincePublication < 24) return '1';
  if (daysSincePublication < 3) return '2';
  if (daysSincePublication < 7) return '3';
  if (daysSincePublication < 30) return '4';
  if (monthsSincePublication < 10) return '5';
  if (monthsSincePublication < 14) return '6';
  return '7';
};
var getContentTargeting = _ref => {
  var {
    eligibleForDCR,
    path,
    renderingPlatform,
    section,
    sensitive,
    videoLength,
    webPublicationDate,
    keywords
  } = _ref;
  var urlkw = getUrlKeywords(path);
  return {
    dcre: eligibleForDCR ? 't' : 'f',
    rc: calculateRecentlyPublishedBucket(webPublicationDate),
    rp: renderingPlatform,
    s: section,
    sens: sensitive ? 't' : 'f',
    urlkw,
    vl: videoLength ? getVideoLength(videoLength) : null,
    allkw: concatUnique(urlkw, keywords)
  };
};


/***/ }),

/***/ "../core/src/targeting/personalised.ts":
/*!*********************************************!*\
  !*** ../core/src/targeting/personalised.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getPersonalisedTargeting: () => (/* binding */ getPersonalisedTargeting)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
/* harmony import */ var _permutive__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../permutive */ "../core/src/permutive.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


/* -- Types -- */
var frequency = ['0', '1', '2', '3', '4', '5', '6-9', '10-15', '16-19', '20-29', '30plus'];
var AMTGRP_STORAGE_KEY = 'gu.adManagerGroup';
var adManagerGroups = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12'];
/* -- Methods -- */
var getRawWithConsent = (key, state) => {
  if (state.tcfv2) {
    if (state.tcfv2.consents['1']) return _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.getRaw(key);
  }
  if (state.usnat) {
    if (!state.usnat.doNotSell) return _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.getRaw(key);
  }
  if (state.aus) {
    if (state.aus.personalisedAdvertising) return _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.getRaw(key);
  }
  return null;
};
var getFrequencyValue = state => {
  var rawValue = getRawWithConsent('gu.alreadyVisited', state);
  if (!rawValue) return '0';
  var visitCount = parseInt(rawValue, 10);
  if (visitCount <= 5) {
    var _frequency$visitCount;
    return (_frequency$visitCount = frequency[visitCount]) !== null && _frequency$visitCount !== void 0 ? _frequency$visitCount : '0';
  } else if (visitCount >= 6 && visitCount <= 9) {
    return '6-9';
  } else if (visitCount >= 10 && visitCount <= 15) {
    return '10-15';
  } else if (visitCount >= 16 && visitCount <= 19) {
    return '16-19';
  } else if (visitCount >= 20 && visitCount <= 29) {
    return '20-29';
  } else if (visitCount >= 30) {
    return '30plus';
  }
  return '0';
};
var getCMPTargeting = state => {
  if (state.tcfv2) {
    return {
      cmp_interaction: state.tcfv2.eventStatus,
      pa: state.canTarget ? 't' : 'f',
      consent_tcfv2: state.canTarget ? 't' : 'f',
      rdp: 'na'
    };
  }
  if (state.usnat) {
    return {
      consent_tcfv2: 'na',
      rdp: !state.canTarget ? 't' : 'f',
      pa: state.canTarget ? 't' : 'f'
    };
  }
  if (state.aus) {
    return {
      consent_tcfv2: 'na',
      rdp: 'na',
      pa: state.canTarget ? 't' : 'f'
    };
  }
  return {
    cmp_interaction: 'na',
    consent_tcfv2: 'na',
    rdp: 'na',
    pa: 'f'
  };
};
var isAdManagerGroup = s => adManagerGroups.some(g => g === s);
var createAdManagerGroup = () => {
  var _adManagerGroups$inde;
  var index = Math.floor(Math.random() * adManagerGroups.length);
  var group = (_adManagerGroups$inde = adManagerGroups[index]) !== null && _adManagerGroups$inde !== void 0 ? _adManagerGroups$inde : '12';
  _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.setRaw(AMTGRP_STORAGE_KEY, group);
  return group;
};
var getAdManagerGroup = state => {
  if (!state.framework) {
    _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.remove(AMTGRP_STORAGE_KEY);
    return null;
  }
  if (state.tcfv2 && !state.canTarget) {
    _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.remove(AMTGRP_STORAGE_KEY);
    return null;
  }
  var existingGroup = _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local.getRaw(AMTGRP_STORAGE_KEY);
  return isAdManagerGroup(existingGroup) ? existingGroup : createAdManagerGroup();
};
var getPermutiveWithState = (state, youtube) => {
  if (state.canTarget) {
    return youtube ? (0,_permutive__WEBPACK_IMPORTED_MODULE_1__.getPermutivePFPSegments)() : (0,_permutive__WEBPACK_IMPORTED_MODULE_1__.getPermutiveSegments)();
  }
  (0,_permutive__WEBPACK_IMPORTED_MODULE_1__.clearPermutiveSegments)();
  return [];
};
var getPersonalisedTargeting = _ref => {
  var {
    state,
    youtube
  } = _ref;
  return _objectSpread({
    amtgrp: getAdManagerGroup(state),
    fr: getFrequencyValue(state),
    permutive: getPermutiveWithState(state, youtube)
  }, getCMPTargeting(state));
};


/***/ }),

/***/ "../core/src/targeting/pick-targeting-values.ts":
/*!******************************************************!*\
  !*** ../core/src/targeting/pick-targeting-values.ts ***!
  \******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   pickTargetingValues: () => (/* binding */ pickTargetingValues)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");

var isTargetingString = string => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isString)(string) && string !== '';
var isTargetingArray = array => Array.isArray(array) && array.filter(isTargetingString).length > 0;
var isValidTargeting = value => {
  if (isTargetingString(value)) return true;
  if (isTargetingArray(value)) return true;
  return false;
};
/**
 * Picks only keys with targeting values from an object.
 * A targeting values is defined as either:
 * - a non-empty string
 * - an array of non-empty strings
 *
 * If you object is read-only, you can safely access properties on the result.
 * For example:
 *
 * ```ts
 * dirty = {
 *   valid: 'real',
 *   invalid: undefined,
 * } as const;
 *
 * clean = pickDefinedValues(dirty);
 *
 * // @ts-expect-error -- you can’t access this property
 * clean.invalid
 * ```
 */
var pickTargetingValues = obj => {
  var initialValue = {};
  return Object.entries(obj).reduce((valid, _ref) => {
    var [key, value] = _ref;
    if (isValidTargeting(value)) {
      // @ts-expect-error -- isValidTargeting checks this
      valid[key] = Array.isArray(value) ? value.filter(isTargetingString) : value;
    }
    return valid;
  }, initialValue);
};

/***/ }),

/***/ "../core/src/targeting/session.ts":
/*!****************************************!*\
  !*** ../core/src/targeting/session.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   experimentsTargeting: () => (/* binding */ experimentsTargeting),
/* harmony export */   getSessionTargeting: () => (/* binding */ getSessionTargeting)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");

/* -- Types -- */
var referrers = [{
  id: 'facebook',
  match: 'facebook.com'
}, {
  id: 'google',
  match: 'www.google'
}, {
  id: 'twitter',
  match: '/t.co/'
}, {
  id: 'reddit',
  match: 'reddit.com'
}];
/* -- Methods -- */
var getReferrer = referrer => {
  var _referrers$find;
  if (referrer === '') return null;
  var matchedRef = (_referrers$find = referrers.find(referrerType => referrer.includes(referrerType.match))) !== null && _referrers$find !== void 0 ? _referrers$find : null;
  return matchedRef ? matchedRef.id : null;
};
var experimentsTargeting = _ref => {
  var {
    clientSideParticipations,
    serverSideParticipations
  } = _ref;
  var testToParams = (testName, variant) => {
    if (variant === 'notintest') return null;
    // GAM key-value pairs accept value strings up to 40 characters long
    return "".concat(testName, "-").concat(variant).substring(0, 40);
  };
  var clientSideExperiment = Object.entries(clientSideParticipations).map(test => {
    var [name, variant] = test;
    return testToParams(name, variant.variant);
  }).filter(_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isString);
  var serverSideExperiments = Object.entries(serverSideParticipations).map(test => testToParams(...test)).filter(_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isString);
  if (clientSideExperiment.length + serverSideExperiments.length === 0) {
    return null;
  }
  return [...clientSideExperiment, ...serverSideExperiments];
};
var getSessionTargeting = _ref2 => {
  var {
    adTest,
    countryCode,
    localHour,
    isSignedIn,
    pageViewId,
    participations,
    referrer
  } = _ref2;
  return {
    ab: experimentsTargeting(participations),
    at: adTest,
    cc: countryCode,
    lh: localHour,
    pv: pageViewId,
    ref: getReferrer(referrer),
    si: isSignedIn ? 't' : 'f'
  };
};


/***/ }),

/***/ "../core/src/targeting/shared.ts":
/*!***************************************!*\
  !*** ../core/src/targeting/shared.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   getLocalHour: () => (/* binding */ getLocalHour),
/* harmony export */   getSharedTargeting: () => (/* binding */ getSharedTargeting)
/* harmony export */ });
/* harmony import */ var _pick_targeting_values__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./pick-targeting-values */ "../core/src/targeting/pick-targeting-values.ts");

var surges = {
  0: '0',
  50: '5',
  100: '4',
  200: '3',
  300: '2',
  400: '1'
};
/* -- Methods -- */
var getSurgingParam = surging => {
  if (surging < 50 || isNaN(surging)) return ['0'];
  var thresholds = [400, 300, 200, 100, 50];
  return thresholds.filter(n => n <= surging).map(s => surges[s]);
};
/* -- Targeting -- */
var getLocalHour = () => {
  return new Date().getHours().toString();
};
/**
 * What goes in comes out
 */
var getSharedTargeting = shared => (0,_pick_targeting_values__WEBPACK_IMPORTED_MODULE_0__.pickTargetingValues)(shared);
var _ = {
  getSurgingParam
};


/***/ }),

/***/ "../core/src/targeting/teads-eligibility.ts":
/*!**************************************************!*\
  !*** ../core/src/targeting/teads-eligibility.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isEligibleForTeads: () => (/* binding */ isEligibleForTeads)
/* harmony export */ });
var allowedContentTypes = ['Article', 'LiveBlog'];
var isEligibleForTeads = slotId => {
  var {
    contentType,
    isSensitive
  } = window.guardian.config.page;
  // This IAS value is returned when a page is thought to contain content which is not brand safe
  var isBrandSafe = !window.googletag.pubads().getTargeting('ias-kw').includes('IAS_16425_KW');
  if (slotId === 'dfp-ad--inline1' && allowedContentTypes.includes(contentType) && !isSensitive && isBrandSafe) {
    return true;
  }
  return false;
};


/***/ }),

/***/ "../core/src/targeting/viewport.ts":
/*!*****************************************!*\
  !*** ../core/src/targeting/viewport.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getViewportTargeting: () => (/* binding */ getViewportTargeting)
/* harmony export */ });
/* -- Methods -- */
var findBreakpoint = width => {
  if (width >= 980) return 'desktop';
  if (width >= 660) return 'tablet';
  return 'mobile';
};
var getViewportTargeting = _ref => {
  var {
    viewPortWidth,
    cmpBannerWillShow
  } = _ref;
  // Don’t show inskin if if a privacy message will be shown or on preview
  var isPreview = window.guardian.config.page.isPreview;
  var inskin = cmpBannerWillShow || isPreview ? 'f' : 't';
  return {
    bp: findBreakpoint(viewPortWidth),
    skinsize: viewPortWidth >= 1560 ? 'l' : 's',
    inskin
  };
};


/***/ }),

/***/ "./src/define/Advert.ts":
/*!******************************!*\
  !*** ./src/define/Advert.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Advert: () => (/* binding */ Advert),
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   findSmallestAdHeightForSlot: () => (/* binding */ findSmallestAdHeightForSlot),
/* harmony export */   isAdSize: () => (/* binding */ isAdSize)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/source/foundations */ "../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _define_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./define-slot */ "./src/define/define-slot.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }





var stringToTuple = size => {
  var dimensions = size.split(',', 2).map(Number);
  // Return an outOfPage tuple if the string is not `[number, number]`
  if (dimensions.length !== 2 || !dimensions[0] || !dimensions[1] || dimensions.some(n => isNaN(n))) {
    return [0, 0];
  }
  return [dimensions[0], dimensions[1]];
};
/**
 * A breakpoint can have various sizes assigned to it. You can assign either on
 * set of sizes or multiple.
 *
 * One size       - `data-mobile="300,50"`
 * Multiple sizes - `data-mobile="300,50|320,50"`
 */
var createSizeMapping = attr => attr.split('|').map(size => (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(...stringToTuple(size)));
/**
 * Convert a breakpoint name to a form suitable for use as an attribute
 * Regex matches a lowercase letter followed by an uppercase letter
 *
 * e.g. `mobileLandscape` => `mobile-landscape`
 */
var breakpointNameToAttribute = breakpointName => breakpointName.replace(/([a-z])([A-Z])/g, '$1-$2').toLowerCase();
/**
 * Extract the ad sizes from the breakpoint data attributes of an ad slot
 *
 * @param advertNode The ad slot HTML element that contains the breakpoint attributes
 * @returns A mapping from the breakpoints supported by the slot to an array of ad sizes
 */
var getSlotSizeMappingsFromDataAttrs = advertNode => Object.entries(_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_1__.breakpoints).reduce((sizes, _ref) => {
  var [breakpointName] = _ref;
  var data = advertNode.getAttribute("data-".concat(breakpointNameToAttribute(breakpointName)));
  if (data) {
    sizes[breakpointName] = createSizeMapping(data);
  }
  return sizes;
}, {});
var isSlotName = slotName => {
  return slotName in _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.slotSizeMappings;
};
var getSlotSizeMapping = name => {
  var slotName;
  if (name.includes('inline')) {
    slotName = 'inline';
  } else if (name.includes('fronts-banner')) {
    slotName = 'fronts-banner';
  } else if (name.includes('external')) {
    slotName = 'external';
  } else if (name.includes('comments-expanded')) {
    slotName = 'comments-expanded';
  } else if (name.includes('interactive')) {
    slotName = 'interactive';
  } else {
    slotName = name;
  }
  if (isSlotName(slotName)) {
    return _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.slotSizeMappings[slotName];
  }
  return {};
};
/**
 * Finds the smallest possible known ad size that can fill a slot
 * Useful for minimising CLS.
 */
var findSmallestAdHeightForSlot = (slot, breakpoint) => {
  var sizes = getSlotSizeMapping(slot);
  if (!Object.keys(sizes).length) return null;
  var sizesForBreakpoint = (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.findAppliedSizesForBreakpoint)(sizes, breakpoint);
  var heights = sizesForBreakpoint.filter(size => !size.isProxy()).map(_ref2 => {
    var {
      height
    } = _ref2;
    return height;
  });
  if (!heights.length) return null;
  return Math.min(...heights);
};
var isSizeMappingEmpty = sizeMapping => {
  return Object.keys(sizeMapping).length === 0 || Object.entries(sizeMapping).every(_ref3 => {
    var [, mapping] = _ref3;
    return mapping.length === 0;
  });
};
class Advert {
  //Ozone testgroup property
  constructor(adSlotNode) {
    var additionalSizeMapping = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    var slotTargeting = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    _defineProperty(this, "id", void 0);
    _defineProperty(this, "node", void 0);
    _defineProperty(this, "sizes", void 0);
    _defineProperty(this, "headerBiddingSizes", null);
    _defineProperty(this, "size", null);
    _defineProperty(this, "slot", void 0);
    _defineProperty(this, "isEmpty", null);
    _defineProperty(this, "isRendered", false);
    _defineProperty(this, "shouldRefresh", false);
    _defineProperty(this, "whenSlotReady", void 0);
    _defineProperty(this, "extraNodeClasses", []);
    _defineProperty(this, "hasPrebidSize", false);
    _defineProperty(this, "headerBiddingBidRequest", null);
    _defineProperty(this, "lineItemId", null);
    _defineProperty(this, "creativeId", null);
    _defineProperty(this, "creativeTemplateId", null);
    _defineProperty(this, "testgroup", void 0);
    this.id = adSlotNode.id;
    this.node = adSlotNode;
    this.sizes = this.generateSizeMapping(additionalSizeMapping);
    var slotDefinition = (0,_define_slot__WEBPACK_IMPORTED_MODULE_4__.defineSlot)(adSlotNode, this.sizes, slotTargeting);
    this.slot = slotDefinition.slot;
    this.whenSlotReady = slotDefinition.slotReady;
    this.testgroup = slotDefinition.slot.getTargeting('testgroup')[0];
  }
  /**
   * Call this method once the ad has been rendered, it will set the
   * `isRendered` flag to true, which is used to determine whether to load
   * or refresh the ad
   *
   * @param isRendered was an advert rendered
   */
  finishedRendering(isRendered) {
    this.isRendered = isRendered;
  }
  /**
   * Update the "extra" classes for this slot e.g. `ad-slot--outstream`, so that the base classes
   * like `ad-slot` etc. are never removed
   *
   * @param newClasses An array of classes to set on the slot
   **/
  updateExtraSlotClasses() {
    var _arguments = arguments,
      _this = this;
    return _asyncToGenerator(function* () {
      for (var _len = _arguments.length, newClasses = new Array(_len), _key = 0; _key < _len; _key++) {
        newClasses[_key] = _arguments[_key];
      }
      var classesToRemove = _this.extraNodeClasses.filter(c => !newClasses.includes(c));
      yield _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_3__["default"].mutate(() => {
        _this.node.classList.remove(...classesToRemove);
        _this.node.classList.add(...newClasses);
      });
      _this.extraNodeClasses = newClasses;
    })();
  }
  /**
   * Combine the size mapping from the mappings in commercial with
   * any additional size mappings, if none are found check data-attributes, if still
   * none are found throws an error
   *
   * @param additionalSizeMapping A mapping of breakpoints to ad sizes
   * @returns A mapping of breakpoints to ad sizes
   */
  generateSizeMapping(additionalSizeMapping) {
    // Try to use defined size mappings if available
    var defaultSizeMappingForSlot = this.node.dataset.name ? getSlotSizeMapping(this.node.dataset.name) : {};
    // Data attribute size mappings are used in interactives e.g. https://www.theguardian.com/education/ng-interactive/2021/sep/11/the-best-uk-universities-2022-rankings
    var dataAttrSizeMapping = getSlotSizeMappingsFromDataAttrs(this.node);
    var sizeMapping = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.concatSizeMappings)(defaultSizeMappingForSlot, additionalSizeMapping);
    sizeMapping = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.concatSizeMappings)(sizeMapping, dataAttrSizeMapping);
    // If the size mapping is still empty, throw an error as this should never happen
    if (isSizeMappingEmpty(sizeMapping)) {
      var _this$node$dataset$na;
      throw new Error("Tried to render ad slot '".concat((_this$node$dataset$na = this.node.dataset.name) !== null && _this$node$dataset$na !== void 0 ? _this$node$dataset$na : '', "' without any size mappings"));
    }
    return sizeMapping;
  }
  /**
   * Update the size mapping for this slot, you will need to call
   * refreshAdvert to update the ad immediately
   *
   * @param additionalSizeMapping A mapping of breakpoints to ad sizes
   **/
  updateSizeMapping(additionalSizeMapping) {
    var sizeMapping = this.generateSizeMapping(additionalSizeMapping);
    this.sizes = sizeMapping;
    var googletagSizeMapping = (0,_define_slot__WEBPACK_IMPORTED_MODULE_4__.buildGoogletagSizeMapping)(sizeMapping);
    if (googletagSizeMapping) {
      this.slot.defineSizeMapping(googletagSizeMapping);
    }
  }
}
var isAdSize = size => {
  return size !== null && size !== 'fluid';
};

var _ = {
  getSlotSizeMapping
};

/***/ }),

/***/ "./src/define/create-advert.ts":
/*!*************************************!*\
  !*** ./src/define/create-advert.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createAdvert: () => (/* binding */ createAdvert)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _Advert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Advert */ "./src/define/Advert.ts");
/* harmony import */ var _define_slot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./define-slot */ "./src/define/define-slot.ts");




var createAdvert = (adSlot, additionalSizes, slotTargeting) => {
  try {
    var advert = new _Advert__WEBPACK_IMPORTED_MODULE_2__.Advert(adSlot, additionalSizes, slotTargeting);
    return advert;
  } catch (error) {
    if (error instanceof _define_slot__WEBPACK_IMPORTED_MODULE_3__.DefineSlotError) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', error.message, {
        adSlotId: adSlot.id,
        sizeMapping: error.sizeMapping
      });
      if (error.report) {
        (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(error, 'commercial', {}, {
          adSlotId: adSlot.id,
          sizeMapping: error.sizeMapping
        });
      }
    } else {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', error instanceof Error ? error.message : String(error));
      // The DuckDuckGo browser blocks ads from loading by default, so it causes a lot of noise in Sentry.
      // We filter these errors out here - DuckDuckGo is in the user agent string if someone is using the
      // desktop browser, and Ddg is present for those using the mobile browser, so we filter out both.
      if (!navigator.userAgent.includes('DuckDuckGo') && !navigator.userAgent.includes('Ddg')) {
        (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(error, 'commercial', {}, {
          adSlotId: adSlot.id,
          additionalSizes: additionalSizes
        });
      }
    }
    return null;
  }
};


/***/ }),

/***/ "./src/define/define-slot.ts":
/*!***********************************!*\
  !*** ./src/define/define-slot.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   DefineSlotError: () => (/* binding */ DefineSlotError),
/* harmony export */   buildGoogletagSizeMapping: () => (/* binding */ buildGoogletagSizeMapping),
/* harmony export */   canDefineSlot: () => (/* binding */ canDefineSlot),
/* harmony export */   collectSizes: () => (/* binding */ collectSizes),
/* harmony export */   defineSlot: () => (/* binding */ defineSlot)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_commercial_core_targeting_teads_eligibility__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/targeting/teads-eligibility */ "../core/src/targeting/teads-eligibility.ts");
/* harmony import */ var _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/source/foundations */ "../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_url__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/url */ "./src/lib/url.ts");
/* harmony import */ var _init_slot_ias__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./init-slot-ias */ "./src/define/init-slot-ias.ts");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }






var breakpointViewports = {
  mobile: [0, 0],
  // this is width 0 to cover all widths until the next breakpoint if any
  phablet: [_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.phablet, 0],
  tablet: [_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.tablet, 0],
  desktop: [_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.desktop, 0],
  wide: [_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.wide, 0]
};
var adUnit = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(() => {
  var urlVars = (0,_lib_url__WEBPACK_IMPORTED_MODULE_4__.getUrlVars)();
  return urlVars['ad-unit'] ? "/".concat(window.guardian.config.page.dfpAccountId, "/").concat(String(urlVars['ad-unit'])) : window.guardian.config.page.adUnit;
});
var isBreakpoint = breakpoint => breakpoint in breakpointViewports;
var toGoogleTagSize = size => {
  // not using width and height here as to maintain compatibility with plain arrays
  return size[0] === 0 && size[1] === 0 ? 'fluid' : [size[0], size[1]];
};
/**
 *  Test a known good size mapping, if this fails we can't define slots!
 *  This can happen if googletag has been shimmed by an adblocker
 */
var canDefineSlot = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(() => {
  var testMapping = window.googletag.sizeMapping().addSize([0, 0], [[300, 250]]).build();
  return !!testMapping;
});
/**
 * Builds a googletag size mapping based on the breakpoints and ad sizes from
 * the defined size mapping and the viewport sizes from source-foundations.
 */
var buildGoogletagSizeMapping = sizeMapping => {
  var mapping = window.googletag.sizeMapping();
  Object.entries(sizeMapping).forEach(_ref => {
    var [breakpoint, sizes] = _ref;
    if (isBreakpoint(breakpoint)) {
      mapping.addSize(breakpointViewports[breakpoint], sizes.map(toGoogleTagSize));
    }
  });
  return mapping.build();
};
var isMultiSize = size => {
  return Array.isArray(size) && !!size.length;
};
var isSizeInArray = (size, sizes) => {
  if (size === 'fluid') {
    return sizes.includes('fluid');
  } else if (Array.isArray(size)) {
    return !!sizes.find(item => item[0] === size[0] && item[1] === size[1]);
  }
  return false;
};
/**
 * Take all the sizes in a size mapping and reduce to a single array of sizes, for use in `defineSlot`
 *
 * @todo this is possibly redundant as these are only used if a size mapping is not defined which we always provide.
 * @param sizeMapping googletag size mapping
 * @returns all the sizes that were present in the size mapping
 */
var collectSizes = sizeMapping => {
  var sizes = [];
  // as we're using sizeMapping, pull out all the ad sizes, as an array of arrays
  sizeMapping === null || sizeMapping === void 0 || sizeMapping.forEach(_ref2 => {
    var [, sizesForBreakpoint] = _ref2;
    if (isMultiSize(sizesForBreakpoint)) {
      sizesForBreakpoint.forEach(size => {
        if (!isSizeInArray(size, sizes)) {
          sizes.push(size);
        }
      });
    }
  });
  return sizes;
};
var isEligibleForOutstream = slotTarget => typeof slotTarget === 'string' && (slotTarget === 'inline1' || slotTarget === 'top-above-nav');
var allowSafeFrameToExpand = slot => {
  slot.setSafeFrameConfig({
    allowOverlayExpansion: false,
    allowPushExpansion: true,
    sandbox: true
  });
  return slot;
};
class DefineSlotError extends Error {
  constructor(message, sizeMapping) {
    var report = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : true;
    super(message);
    _defineProperty(this, "sizeMapping", void 0);
    _defineProperty(this, "report", void 0);
    this.name = 'DefineSlotError';
    this.sizeMapping = JSON.stringify(sizeMapping);
    this.report = report;
  }
}
var defineSlot = function (adSlotNode, sizeMapping) {
  var slotTargeting = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  var slotTarget = adSlotNode.getAttribute('data-name');
  _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('defineSlotStart', slotTarget);
  var id = adSlotNode.id;
  var googletagSizeMapping = buildGoogletagSizeMapping(sizeMapping);
  if (!googletagSizeMapping) {
    if (canDefineSlot()) {
      throw new DefineSlotError('googletag.sizeMapping did not return a size mapping', sizeMapping);
    } else {
      throw new DefineSlotError('Could not define slot. googletag.sizeMapping has been shimmed.', sizeMapping, false);
    }
  }
  var sizes = collectSizes(googletagSizeMapping);
  var slot;
  if (adSlotNode.getAttribute('data-out-of-page')) {
    var _slot;
    slot = window.googletag.defineOutOfPageSlot(adUnit(), id);
    (_slot = slot) === null || _slot === void 0 || _slot.defineSizeMapping(googletagSizeMapping);
  } else {
    var _slot2;
    slot = window.googletag.defineSlot(adUnit(), sizes, id);
    (_slot2 = slot) === null || _slot2 === void 0 || _slot2.defineSizeMapping(googletagSizeMapping);
    if (slot && isEligibleForOutstream(slotTarget)) {
      allowSafeFrameToExpand(slot);
    }
  }
  if (!slot) {
    throw new DefineSlotError("googletag.defineSlot did not return a slot", sizeMapping);
  }
  var slotReady = (0,_init_slot_ias__WEBPACK_IMPORTED_MODULE_5__.initSlotIas)(id, slot);
  void slotReady.then(() => {
    _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('defineSlotEnd', slotTarget);
    _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('slotReady', slotTarget);
    // wait until IAS has initialised before checking teads eligibility
    var isTeadsEligible = (0,_guardian_commercial_core_targeting_teads_eligibility__WEBPACK_IMPORTED_MODULE_1__.isEligibleForTeads)(id);
    if (isTeadsEligible) {
      slot.setTargeting('teadsEligible', 'true');
    } else {
      slot.setTargeting('teadsEligible', 'false');
    }
  });
  var isbn = window.guardian.config.page.isbn;
  if (slotTarget === isbn) {
    slot.setTargeting('isbn', isbn);
  }
  var fabricKeyValues = new Map([['top-above-nav', 'fabric1'], ['merchandising-high', 'fabric2'], ['merchandising', 'fabric3']]);
  var slotFabric = fabricKeyValues.get(slotTarget);
  if (slotFabric) {
    slot.setTargeting('slot-fabric', slotFabric);
  }
  Object.entries(slotTargeting).forEach(_ref3 => {
    var [key, value] = _ref3;
    slot.setTargeting(key, value);
  });
  slot.addService(window.googletag.pubads()).setTargeting('slot', slotTarget).setTargeting('testgroup', String(Math.floor(100 * Math.random())));
  return {
    slot,
    slotReady
  };
};


/***/ }),

/***/ "./src/define/init-slot-ias.ts":
/*!*************************************!*\
  !*** ./src/define/init-slot-ias.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initSlotIas: () => (/* binding */ initSlotIas)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_url__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/url */ "./src/lib/url.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var adUnit = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(() => {
  var urlVars = (0,_lib_url__WEBPACK_IMPORTED_MODULE_1__.getUrlVars)();
  return urlVars['ad-unit'] ? "/".concat(window.guardian.config.page.dfpAccountId, "/").concat(String(urlVars['ad-unit'])) : window.guardian.config.page.adUnit;
});
var timeout = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (promise, ms) {
    var timeoutId;
    return Promise.race([promise, new Promise(resolve => {
      timeoutId = window.setTimeout(resolve, ms);
    })]).then(result => {
      window.clearTimeout(timeoutId);
      return result;
    });
  });
  return function timeout(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * For each ad slot defined, we request information from IAS, based
 * on slot name, ad unit and sizes. We then add this targeting to the
 * slot prior to requesting it from DFP.
 *
 * We create a timer, such that if the timeout resolves before the request
 * to IAS returns, then the slot is defined without the additional IAS data.
 * To see debugging output from IAS add the URL param `&iasdebug=true` to the page URL
 *
 * this should all have been instantiated by lib/third-party-tags/ias.js
 *
 * @param id - the slot id
 * @param slot - the googletag slot object
 * @returns a promise that resolves when the IAS data is returned or the timeout resolves
 **/
var initSlotIas = (id, slot) => timeout(new Promise(resolve => {
  var _window$__iasPET, _iasPET$queue;
  window.__iasPET = (_window$__iasPET = window.__iasPET) !== null && _window$__iasPET !== void 0 ? _window$__iasPET : {};
  var iasPET = window.__iasPET;
  iasPET.queue = (_iasPET$queue = iasPET.queue) !== null && _iasPET$queue !== void 0 ? _iasPET$queue : [];
  iasPET.pubId = '10249';
  // need to reorganize the type due to https://github.com/microsoft/TypeScript/issues/33591
  var slotSizes = slot.getSizes();
  // IAS Optimization Targeting
  var iasPETSlots = [{
    adSlotId: id,
    size: slotSizes.filter(size => size !== 'fluid').map(size => [size.getWidth(), size.getHeight()]),
    adUnitPath: adUnit() // why do we have this method and not just slot.getAdUnitPath()?
  }];
  var iasDataCallback = targetingJSON => {
    var _targeting$custom;
    /*  There is a name-clash with the `fr` targeting returned by IAS
    and the `fr` paramater we already use for frequency. Therefore
    we apply the targeting to the slot ourselves and rename the IAS
    fr parameter to `fra` (given that, here, it relates to fraud).
    */
    var targeting = JSON.parse(targetingJSON);
    // brand safety is on a page level
    Object.keys(targeting.brandSafety).forEach(key => {
      var brandSafetyValue = targeting.brandSafety[key];
      if (brandSafetyValue) {
        window.googletag.pubads().setTargeting(key, brandSafetyValue);
      }
    });
    if (targeting.fr) {
      window.googletag.pubads().setTargeting('fra', targeting.fr);
    }
    if ((_targeting$custom = targeting.custom) !== null && _targeting$custom !== void 0 && _targeting$custom['ias-kw']) {
      window.googletag.pubads().setTargeting('ias-kw', targeting.custom['ias-kw']);
    }
    // viewability targeting is on a slot level
    var ignoredKeys = ['pub'];
    var slotTargeting = targeting.slots[id];
    if (slotTargeting) {
      Object.keys(slotTargeting).filter(x => !ignoredKeys.includes(x)).forEach(key => {
        var targetingSlot = targeting.slots[id];
        if (targetingSlot) {
          var targetingValue = targetingSlot[key];
          if (targetingValue) {
            slot.setTargeting(key, targetingValue);
          }
        }
      });
    }
    resolve();
  };
  iasPET.queue.push({
    adSlots: iasPETSlots,
    dataHandler: iasDataCallback
  });
}), 1000);


/***/ }),

/***/ "./src/display/lazy-load.ts":
/*!**********************************!*\
  !*** ./src/display/lazy-load.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   enableLazyLoad: () => (/* binding */ enableLazyLoad)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _load_advert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./load-advert */ "./src/display/load-advert.ts");
/* harmony import */ var _request_bids__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./request-bids */ "./src/display/request-bids.ts");







var displayAd = advertId => {
  var advert = (0,_lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_4__.getAdvertById)(advertId);
  if (advert) {
    if (advert.isRendered) {
      (0,_load_advert__WEBPACK_IMPORTED_MODULE_5__.refreshAdvert)(advert);
    } else {
      (0,_load_advert__WEBPACK_IMPORTED_MODULE_5__.loadAdvert)(advert);
    }
  }
};
var requestBids = advertId => {
  var advert = (0,_lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_4__.getAdvertById)(advertId);
  if (advert) {
    void (0,_request_bids__WEBPACK_IMPORTED_MODULE_6__.requestBidsForAd)(advert);
  }
};
var onIntersectDisplayAd = (entries, observer) => {
  var advertIds = [];
  entries.filter(entry => !('isIntersecting' in entry) || entry.isIntersecting).forEach(entry => {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'display observer triggered for: ', entry.target.id);
    observer.unobserve(entry.target);
    displayAd(entry.target.id);
    advertIds.push(entry.target.id);
  });
  _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_3__.dfpEnv.advertsToLoad = _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_3__.dfpEnv.advertsToLoad.filter(advert => !advertIds.includes(advert.id));
};
var onIntersectPrebid = (entries, observer) => {
  var advertIds = [];
  entries.filter(entry => !('isIntersecting' in entry) || entry.isIntersecting).forEach(entry => {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'prebid observer triggered for: ', entry.target.id);
    observer.unobserve(entry.target);
    requestBids(entry.target.id);
    advertIds.push(entry.target.id);
  });
};
var getDisplayAdObserver = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(isEagerPrebid => {
  return new window.IntersectionObserver(onIntersectDisplayAd, {
    rootMargin: isEagerPrebid ? '10% 0px' : '20% 0px'
  });
});
var getPrebidObserver = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(() => {
  return new window.IntersectionObserver(onIntersectPrebid, {
    rootMargin: '50% 0px'
  });
});
/**
 * Only load Prebid eagerly on desktop and above
 */
var shouldRunEagerPrebid = () => ['desktop', 'wide'].includes((0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__.getCurrentBreakpoint)());
var enableLazyLoad = advert => {
  if (_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_3__.dfpEnv.lazyLoadObserve) {
    var isEagerPrebid = shouldRunEagerPrebid();
    getDisplayAdObserver(isEagerPrebid).observe(advert.node);
    if (isEagerPrebid) {
      getPrebidObserver().observe(advert.node);
    }
  } else {
    displayAd(advert.id);
  }
};

/***/ }),

/***/ "./src/display/load-advert.ts":
/*!************************************!*\
  !*** ./src/display/load-advert.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadAdvert: () => (/* binding */ loadAdvert),
/* harmony export */   refreshAdvert: () => (/* binding */ refreshAdvert)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! fastdom */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/fastdom.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fastdom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/header-bidding/utils */ "./src/lib/header-bidding/utils.ts");
/* harmony import */ var _request_bids__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./request-bids */ "./src/display/request-bids.ts");




var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get();
var loadAdvert = advert => {
  var adName = (0,_lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_2__.stripDfpAdPrefixFrom)(advert.id);
  eventTimer.mark('adRenderStart', adName);
  // TODO can slotReady come after header bidding?
  // If so, the callbacks pushed onto the ias queue in define-slot.js
  // could be run in parallel with the calls to requestBids below, reducing the
  // total time to display the ad.
  void advert.whenSlotReady.catch(() => {
    // The display needs to be called, even in the event of an error.
  }).then(() => {
    eventTimer.mark('prepareSlotStart', adName);
    // If the advert has already had bids requested, then we don't need to request them again.
    if (advert.headerBiddingBidRequest) {
      return advert.headerBiddingBidRequest;
    }
    return (0,_request_bids__WEBPACK_IMPORTED_MODULE_3__.requestBidsForAd)(advert);
  }).then(() => {
    eventTimer.mark('prepareSlotEnd', adName);
    eventTimer.mark('fetchAdStart', adName);
    window.googletag.display(advert.id);
  });
};
var refreshAdvert = advert => {
  // advert.size contains the effective size being displayed prior to refreshing
  void advert.whenSlotReady.then(() => fastdom__WEBPACK_IMPORTED_MODULE_1___default().mutate(() => {
    if (advert.id.includes('fronts-banner')) {
      var _advert$node$closest;
      (_advert$node$closest = advert.node.closest('.ad-slot-container')) === null || _advert$node$closest === void 0 || _advert$node$closest.classList.remove('ad-slot--full-width');
    }
  })).then(() => {
    return (0,_request_bids__WEBPACK_IMPORTED_MODULE_3__.refreshBidsForAd)(advert);
  }).then(() => {
    advert.slot.setTargeting('refreshed', 'true');
    // slots that have refreshed are not eligible for teads
    advert.slot.setTargeting('teadsEligible', 'false');
    if (advert.id === 'dfp-ad--top-above-nav') {
      // force the slot sizes to be the same as advert.size (current)
      // only when advert.size is an array (forget 'fluid' and other specials)
      if (Array.isArray(advert.size)) {
        var mapping = window.googletag.sizeMapping();
        mapping.addSize([0, 0], advert.size);
        advert.slot.defineSizeMapping(mapping.build());
      }
    }
    window.googletag.pubads().refresh([advert.slot]);
  });
};

/***/ }),

/***/ "./src/display/request-bids.ts":
/*!*************************************!*\
  !*** ./src/display/request-bids.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   refreshBidsForAd: () => (/* binding */ refreshBidsForAd),
/* harmony export */   requestBidsForAd: () => (/* binding */ requestBidsForAd)
/* harmony export */ });
/* harmony import */ var _lib_header_bidding_a9_a9__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/header-bidding/a9/a9 */ "./src/lib/header-bidding/a9/a9.ts");
/* harmony import */ var _lib_header_bidding_prebid_prebid__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/header-bidding/prebid/prebid */ "./src/lib/header-bidding/prebid/prebid.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var retainAdSizeOnRefresh = (advertSize, hbSlot) => {
  // Only top-above-nav and fronts-banner ads are currently applicable for their ad size not changing
  if (hbSlot.key !== 'top-above-nav' && !hbSlot.key.startsWith('fronts-banner')) {
    return [hbSlot];
  }
  // No point forcing a size, as there is already only one possible (mobile/tablet).
  // See prebid/slot-config.js
  if (hbSlot.sizes.length === 1) {
    return [hbSlot];
  }
  // If advert.size is not an array, there is no point having this hbSlot
  if (!Array.isArray(advertSize)) {
    return [];
  }
  // Force the refreshed advert to be the same size as the first
  return [_objectSpread(_objectSpread({}, hbSlot), {}, {
    sizes: [[advertSize[0], advertSize[1]]]
  })];
};
/**
 * This is used to request bids for multiple adverts, it's possible for adverts to be
 * passed in that have already had bids requested, this can happen if they're already in
 * the viewport, it will only request bids for adverts that haven't already had bids requested.
 */
var requestBidsForAds = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (adverts) {
    var adsToRequestBidsFor = adverts.filter(advert => !advert.headerBiddingBidRequest);
    var promise = Promise.all([_lib_header_bidding_prebid_prebid__WEBPACK_IMPORTED_MODULE_1__.prebid.requestBids(adsToRequestBidsFor), _lib_header_bidding_a9_a9__WEBPACK_IMPORTED_MODULE_0__.a9.requestBids(adsToRequestBidsFor)]);
    adsToRequestBidsFor.forEach(advert => {
      advert.headerBiddingBidRequest = promise;
    });
    yield promise;
  });
  return function requestBidsForAds(_x) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * This is used to request bids for a single advert. This should only be called if
 * an ad is already in the viewport and load-advert is invoked immediately, before
 * space-finder is finished and prebid is called for all dynamic slots.
 */
var requestBidsForAd = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* (advert) {
    advert.headerBiddingBidRequest = requestBidsForAds([advert]);
    yield advert.headerBiddingBidRequest;
  });
  return function requestBidsForAd(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
/**
 * This is used to refresh bids for a single advert. retainTopAboveNavSlotSize is
 * used to force the refreshed advert to be the same size as the first
 */
var refreshBidsForAd = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator(function* (advert) {
    var prebidPromise = _lib_header_bidding_prebid_prebid__WEBPACK_IMPORTED_MODULE_1__.prebid.requestBids([advert], prebidSlot => retainAdSizeOnRefresh(advert.size, prebidSlot));
    var a9Promise = _lib_header_bidding_a9_a9__WEBPACK_IMPORTED_MODULE_0__.a9.requestBids([advert], a9Slot => retainAdSizeOnRefresh(advert.size, a9Slot));
    yield Promise.all([prebidPromise, a9Promise]);
  });
  return function refreshBidsForAd(_x3) {
    return _ref3.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/events/empty-advert.ts":
/*!************************************!*\
  !*** ./src/events/empty-advert.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   emptyAdvert: () => (/* binding */ emptyAdvert),
/* harmony export */   removeSlotFromDom: () => (/* binding */ removeSlotFromDom)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! fastdom */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/fastdom.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fastdom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");



var removeFromDfpEnv = advert => {
  _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__.dfpEnv.adverts.delete(advert.id);
  _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__.dfpEnv.advertsToLoad = _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__.dfpEnv.advertsToLoad.filter(_ => _ !== advert);
};
/**
 * Find the highest element responsible for the advert.
 *
 * Sometimes an advert has an advert container as a direct parent
 * Sometimes that container has a top-level container ancestor
 */
var findElementToRemove = advertNode => {
  var parent = advertNode.parentElement;
  var isAdContainer = parent instanceof HTMLElement && parent.classList.contains('ad-slot-container');
  if (!isAdContainer) {
    return advertNode;
  }
  var topLevelContainer = parent.closest('.top-fronts-banner-ad-container, .top-banner-ad-container');
  if (!topLevelContainer) {
    return parent;
  }
  return topLevelContainer;
};
var removeSlotFromDom = slotElement => {
  var elementToRemove = findElementToRemove(slotElement);
  elementToRemove.style.display = 'none';
};
var emptyAdvert = advert => {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "Removing empty advert: ".concat(advert.id));
  fastdom__WEBPACK_IMPORTED_MODULE_1___default().mutate(() => {
    window.googletag.destroySlots([advert.slot]);
    removeSlotFromDom(advert.node);
    removeFromDfpEnv(advert);
  });
};

var _ = {
  findElementToRemove
};

/***/ }),

/***/ "./src/events/render-advert-label.ts":
/*!*******************************************!*\
  !*** ./src/events/render-advert-label.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   renderAdvertLabel: () => (/* binding */ renderAdvertLabel),
/* harmony export */   renderStickyScrollForMoreLabel: () => (/* binding */ renderStickyScrollForMoreLabel),
/* harmony export */   shouldRenderLabel: () => (/* binding */ shouldRenderLabel),
/* harmony export */   templatesWithoutLabels: () => (/* binding */ templatesWithoutLabels)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _static_svg_icon_cross_svg__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../static/svg/icon/cross.svg */ "./static/svg/icon/cross.svg");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");



var templatesWithoutLabels = [10077207,
// CAPI_MULTIPLE_HOSTED
10069167,
// CAPI_MULTIPLE_PAIDFOR
12317037,
// EVENTS_MULTIPLE
10070487,
// CAPI_SINGLE_PAIDFOR
10063287 // MANUAL_MULTIPLE
];
var shouldRenderLabel = (adSlotNode, creativeTemplateId) => {
  if (creativeTemplateId && templatesWithoutLabels.includes(creativeTemplateId)) {
    return false;
  }
  if (adSlotNode.classList.contains('ad-slot--frame') || adSlotNode.classList.contains('ad-slot--gc') || adSlotNode.classList.contains('u-h') ||
  // set for out-of-page (1x1) and empty (2x2) ads
  adSlotNode.classList.contains('ad-slot--collapse') || adSlotNode.getAttribute('data-label') === 'false') {
    return false;
  }
  return true;
};
var shouldRenderCloseButton = adSlotNode => adSlotNode.classList.contains('ad-slot--mobile-sticky');
var createAdCloseDiv = () => {
  var buttonEl = document.createElement('button');
  buttonEl.className = 'ad-slot__close-button';
  buttonEl.innerHTML = _static_svg_icon_cross_svg__WEBPACK_IMPORTED_MODULE_1__["default"];
  buttonEl.onclick = () => {
    var container = buttonEl.closest('.mobilesticky-container');
    if (container) container.remove();
  };
  var closeDiv = document.createElement('div');
  closeDiv.style.cssText = 'position: relative;padding: 0;height: 0';
  closeDiv.appendChild(buttonEl);
  return closeDiv;
};
var shouldRenderAdTestLabel = adSlotNode => !!(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
  name: 'adtestInLabels',
  shouldMemoize: true
}) && !adSlotNode.classList.contains('ad-slot--sky');
// If `adtest` cookie is set, display its value in the ad label
var createAdTestLabel = (shouldRender, adTestName) => {
  var adTestLabel = '';
  if (shouldRender && adTestName) {
    adTestLabel += " [?adtest=".concat(adTestName, "] ");
  }
  return adTestLabel;
};
var createAdTestCookieRemovalLink = () => {
  var adTestCookieRemovalLink = document.createElement('div');
  adTestCookieRemovalLink.style.cssText = 'position: relative;padding: 0;text-align: left;box-sizing: border-box;display: block;width: 0;height: 0';
  var url = new URL(window.location.href);
  url.searchParams.set('adtest', 'clear');
  var clearLink = document.createElement('a');
  clearLink.className = 'ad-slot__adtest-cookie-clear-link';
  clearLink.href = url.href;
  clearLink.innerHTML = 'clear';
  adTestCookieRemovalLink.appendChild(clearLink);
  return adTestCookieRemovalLink;
};
var renderAdvertLabel = (adSlotNode, creativeTemplateId) => {
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].measure(() => {
    if (shouldRenderLabel(adSlotNode, creativeTemplateId)) {
      var _adSlotNode$parentNod;
      var renderAdTestLabel = shouldRenderAdTestLabel(adSlotNode);
      var adTestClearExists = ((_adSlotNode$parentNod = adSlotNode.parentNode) === null || _adSlotNode$parentNod === void 0 || (_adSlotNode$parentNod = _adSlotNode$parentNod.firstElementChild) === null || _adSlotNode$parentNod === void 0 ? void 0 : _adSlotNode$parentNod.firstElementChild) instanceof HTMLAnchorElement;
      var adTestCookieName = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
        name: 'adtest',
        shouldMemoize: true
      });
      var adLabelContent = "Advertisement".concat(createAdTestLabel(renderAdTestLabel, adTestCookieName));
      return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
        var _adSlotNode$parentEle;
        adSlotNode.setAttribute('data-label-show', 'true');
        adSlotNode.setAttribute('ad-label-text', adLabelContent);
        // Remove this once new `ad-slot-container--centre-slot` class is in place
        if ((_adSlotNode$parentEle = adSlotNode.parentElement) !== null && _adSlotNode$parentEle !== void 0 && _adSlotNode$parentEle.classList.contains('ad-slot-container') && adSlotNode.id === 'dfp-ad--top-above-nav') {
          adSlotNode.parentElement.setAttribute('top-above-nav-ad-rendered', 'true');
        }
        // \Remove this
        if (shouldRenderCloseButton(adSlotNode)) {
          adSlotNode.insertBefore(createAdCloseDiv(), adSlotNode.firstChild);
        }
        if (renderAdTestLabel && adTestCookieName && !adTestClearExists) {
          var _adSlotNode$parentNod2;
          (_adSlotNode$parentNod2 = adSlotNode.parentNode) === null || _adSlotNode$parentNod2 === void 0 || _adSlotNode$parentNod2.insertBefore(createAdTestCookieRemovalLink(), adSlotNode);
        }
      });
    }
    return Promise.resolve();
  });
};
var renderStickyScrollForMoreLabel = (adSlotNode, isGallery) => _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
  var scrollForMoreLabel = document.createElement('div');
  scrollForMoreLabel.classList.add('ad-slot__scroll');
  scrollForMoreLabel.innerHTML = 'Scroll for More';
  scrollForMoreLabel.setAttribute('role', 'button');
  scrollForMoreLabel.onclick = event => {
    adSlotNode.scrollIntoView({
      behavior: 'smooth',
      block: 'start'
    });
    event.preventDefault();
  };
  if (isGallery) {
    scrollForMoreLabel.classList.add('ad-slot--dark');
  }
  adSlotNode.appendChild(scrollForMoreLabel);
});


/***/ }),

/***/ "./src/experiments/ab-tests.ts":
/*!*************************************!*\
  !*** ./src/experiments/ab-tests.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   concurrentTests: () => (/* binding */ concurrentTests)
/* harmony export */ });
/* harmony import */ var _tests_admiral_adblocker_recovery__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./tests/admiral-adblocker-recovery */ "./src/experiments/tests/admiral-adblocker-recovery.ts");
/* harmony import */ var _tests_prebid946__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./tests/prebid946 */ "./src/experiments/tests/prebid946.ts");


/**
 * You only need to add tests to this file if the code you are testing is here in
 * the commercial code. Any test here also needs to be in both DCR and Frontend,
 * but any tests in DCR and Frontend do not need to necessarily be added here.
 */
var concurrentTests = [
// one test per line
_tests_prebid946__WEBPACK_IMPORTED_MODULE_1__.prebid946, _tests_admiral_adblocker_recovery__WEBPACK_IMPORTED_MODULE_0__.admiralAdblockRecovery];

/***/ }),

/***/ "./src/experiments/ab-url.ts":
/*!***********************************!*\
  !*** ./src/experiments/ab-url.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getForcedParticipationsFromUrl: () => (/* binding */ getForcedParticipationsFromUrl)
/* harmony export */ });
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var getForcedParticipationsFromUrl = () => {
  if (window.location.hash.startsWith('#ab')) {
    var tokens = window.location.hash.replace('#ab-', '').split(',');
    return tokens.reduce((obj, token) => {
      var [testId, variantId] = token.split('=');
      if (testId) {
        if (variantId) {
          return _objectSpread(_objectSpread({}, obj), {}, {
            [testId]: {
              variant: variantId
            }
          });
        }
        return _objectSpread(_objectSpread({}, obj), {}, {
          [testId]: undefined
        });
      }
      return obj;
    }, {});
  }
  return {};
};

/***/ }),

/***/ "./src/experiments/ab.ts":
/*!*******************************!*\
  !*** ./src/experiments/ab.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getParticipations: () => (/* binding */ getParticipations),
/* harmony export */   getVariant: () => (/* binding */ getVariant),
/* harmony export */   isUserInVariant: () => (/* binding */ isUserInVariant)
/* harmony export */ });
/* harmony import */ var _guardian_ab_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/ab-core */ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/ab.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_ab_localstorage__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/ab-localstorage */ "./src/lib/ab-localstorage.ts");
/* harmony import */ var _ab_tests__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./ab-tests */ "./src/experiments/ab-tests.ts");
/* harmony import */ var _ab_url__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./ab-url */ "./src/experiments/ab-url.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }





var mvtMinValue = 1;
var mvtMaxValue = 1000000;
/** Parse a valid MVT ID between 1 and 1,000,000 or undefined if it fails */
var parseMvtId = id => {
  if (!id) return; // null or empty string
  var number = Number(id);
  if (Number.isNaN(number)) return;
  if (number < mvtMinValue) return;
  if (number > mvtMaxValue) return;
  return number;
};
var getMvtId = () => parseMvtId((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.getCookie)({
  name: 'GU_mvt_id',
  shouldMemoize: true
}));
var mvtId = getMvtId();
var abTestSwitches = Object.entries(window.guardian.config.switches).reduce((prev, _ref) => {
  var [key, val] = _ref;
  return _objectSpread(_objectSpread({}, prev), {}, {
    [key]: val
  });
}, {});
var init = () => {
  var _window$guardian$conf;
  var forcedTestVariants = _objectSpread(_objectSpread({}, (0,_lib_ab_localstorage__WEBPACK_IMPORTED_MODULE_3__.getParticipationsFromLocalStorage)()), (0,_ab_url__WEBPACK_IMPORTED_MODULE_5__.getForcedParticipationsFromUrl)());
  (0,_lib_ab_localstorage__WEBPACK_IMPORTED_MODULE_3__.setParticipationsInLocalStorage)(forcedTestVariants);
  var ophanEvents = [];
  // If ophan is not available, store the events in an array and replay them when ophan is available
  var ophanRecord = event => {
    ophanEvents.push(event);
    if (window.guardian.ophan) {
      ophanEvents.forEach(e => {
        var _window$guardian$opha;
        return (_window$guardian$opha = window.guardian.ophan) === null || _window$guardian$opha === void 0 ? void 0 : _window$guardian$opha.record(e);
      });
    }
  };
  var ab = new _guardian_ab_core__WEBPACK_IMPORTED_MODULE_0__.AB({
    mvtId: mvtId !== null && mvtId !== void 0 ? mvtId : -1,
    mvtMaxValue,
    pageIsSensitive: window.guardian.config.page.isSensitive,
    abTestSwitches,
    arrayOfTestObjects: _ab_tests__WEBPACK_IMPORTED_MODULE_4__.concurrentTests,
    forcedTestVariants,
    ophanRecord,
    serverSideTests: (_window$guardian$conf = window.guardian.config.tests) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : {},
    errorReporter: error => {
      console.log('AB tests error:', error);
    }
  });
  var allRunnableTests = ab.allRunnableTests(_ab_tests__WEBPACK_IMPORTED_MODULE_4__.concurrentTests);
  ab.trackABTests(allRunnableTests);
  ab.registerImpressionEvents(allRunnableTests);
  ab.registerCompleteEvents(allRunnableTests);
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', 'AB tests initialised');
  return ab;
};
var getParticipations = () => {
  var ab = init();
  var runnableTests = ab.allRunnableTests(_ab_tests__WEBPACK_IMPORTED_MODULE_4__.concurrentTests);
  var participations = runnableTests.reduce((acc, test) => {
    acc[test.id] = {
      variant: test.variantToRun.id
    };
    return acc;
  }, {});
  return participations;
};
var isUserInVariant = (test, variantId) => {
  var ab = init();
  return ab.isUserInVariant(test.id, variantId);
};
var getVariant = test => {
  var _participations$test$;
  var participations = getParticipations();
  return (_participations$test$ = participations[test.id]) === null || _participations$test$ === void 0 ? void 0 : _participations$test$.variant;
};

/***/ }),

/***/ "./src/experiments/tests/admiral-adblocker-recovery.ts":
/*!*************************************************************!*\
  !*** ./src/experiments/tests/admiral-adblocker-recovery.ts ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   admiralAdblockRecovery: () => (/* binding */ admiralAdblockRecovery)
/* harmony export */ });
var admiralAdblockRecovery = {
  id: 'AdmiralAdblockRecovery',
  author: '@commercial-dev',
  start: '2025-08-13',
  expiry: '2025-09-17',
  audience: 100 / 100,
  audienceOffset: 0 / 100,
  audienceCriteria: '',
  successMeasure: '',
  description: 'Test the Admiral ad blocker detection integration ahead of go-live',
  variants: [{
    id: 'control',
    test: () => {
      /* no-op */
    }
  },
  /**
   * variant-detect will run the Admiral script but will not launch
   * the recovery modal for users with ad blockers
   */
  {
    id: 'variant-detect',
    test: () => {
      /* no-op */
    }
  },
  /**
   * variant-recover will run the Admiral script and launch the
   * recovery modal for users with ad blockers
   */
  {
    id: 'variant-recover',
    test: () => {
      /* no-op */
    }
  }],
  canRun: () => true
};

/***/ }),

/***/ "./src/experiments/tests/prebid946.ts":
/*!********************************************!*\
  !*** ./src/experiments/tests/prebid946.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prebid946: () => (/* binding */ prebid946)
/* harmony export */ });
var prebid946 = {
  id: 'Prebid946',
  author: '@commercial-dev',
  start: '2025-08-12',
  expiry: '2025-08-29',
  audience: 5 / 100,
  audienceOffset: 0 / 100,
  audienceCriteria: '',
  successMeasure: '',
  description: 'Test v9.46.0 of Prebid ahead of general upgrade',
  variants: [{
    id: 'control',
    test: () => {
      /* no-op */
    }
  }, {
    id: 'variant',
    test: () => {
      /* no-op */
    }
  }],
  canRun: () => true
};

/***/ }),

/***/ "./src/init/shared/reload-page-on-consent-change.ts":
/*!**********************************************************!*\
  !*** ./src/init/shared/reload-page-on-consent-change.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   reloadPageOnConsentChange: () => (/* binding */ reloadPageOnConsentChange)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");

var initialConsentState;
/**
 * If consent has been set, and if consent then changes, reload the page so the correct
 * state is reflected in the rendered page
 */
var reloadPageOnConsentChange = () => {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsentChange)(consent => {
    if (initialConsentState === undefined) {
      initialConsentState = consent;
    }
    if (initialConsentState.canTarget !== consent.canTarget) {
      window.location.reload();
    }
  }, true);
  return Promise.resolve();
};


/***/ }),

/***/ "./src/init/shared/set-adtest-cookie.ts":
/*!**********************************************!*\
  !*** ./src/init/shared/set-adtest-cookie.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/removeCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setCookie.js");
/* harmony import */ var _lib_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/url */ "./src/lib/url.ts");


/**
 * Set or remove adtest cookie.
 * This is used as a custom targeting parameter in Google Ad Manager
 * in order to test individual line items
 * @returns Promise
 */
var init = () => {
  var queryParams = (0,_lib_url__WEBPACK_IMPORTED_MODULE_2__.getUrlVars)();
  if (queryParams.adtest === 'clear') {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.removeCookie)({
      name: 'adtest'
    });
  } else if (queryParams.adtest) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.setCookie)({
      name: 'adtest',
      value: encodeURIComponent(queryParams.adtest),
      daysToLive: 10
    });
  }
  return Promise.resolve();
};


/***/ }),

/***/ "./src/init/shared/set-adtest-in-labels-cookie.ts":
/*!********************************************************!*\
  !*** ./src/init/shared/set-adtest-in-labels-cookie.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/removeCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setCookie.js");
/* harmony import */ var _lib_url__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/url */ "./src/lib/url.ts");


/**
 * Not to be confused with set-adtest-cookie.ts!
 * Set or remove `adtestInLabels` cookie
 * This is used when determining whether or not to display the value of the `adtest` cookie in ad labels
 * @returns Promise
 */
var init = () => {
  var queryParams = (0,_lib_url__WEBPACK_IMPORTED_MODULE_2__.getUrlVars)();
  if (queryParams.adtestInLabels === 'clear') {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.removeCookie)({
      name: 'adtestInLabels'
    });
  } else if (queryParams.adtestInLabels) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.setCookie)({
      name: 'adtestInLabels',
      value: 'true'
    });
  }
  return Promise.resolve();
};


/***/ }),

/***/ "./src/insert/fill-dynamic-advert-slot.ts":
/*!************************************************!*\
  !*** ./src/insert/fill-dynamic-advert-slot.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fillDynamicAdSlot: () => (/* binding */ fillDynamicAdSlot)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _define_create_advert__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../define/create-advert */ "./src/define/create-advert.ts");
/* harmony import */ var _display_lazy_load__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../display/lazy-load */ "./src/display/lazy-load.ts");
/* harmony import */ var _display_load_advert__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../display/load-advert */ "./src/display/load-advert.ts");
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _lib_dfp_queue_advert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lib/dfp/queue-advert */ "./src/lib/dfp/queue-advert.ts");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../lib/error/report-error */ "./src/lib/error/report-error.ts");







var displayAd = (advert, forceDisplay) => {
  if (_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_4__.dfpEnv.shouldLazyLoad() && !forceDisplay) {
    (0,_lib_dfp_queue_advert__WEBPACK_IMPORTED_MODULE_5__.queueAdvert)(advert);
    (0,_display_lazy_load__WEBPACK_IMPORTED_MODULE_2__.enableLazyLoad)(advert);
  } else {
    (0,_display_load_advert__WEBPACK_IMPORTED_MODULE_3__.loadAdvert)(advert);
  }
};
var fillDynamicAdSlot = (adSlot, forceDisplay, additionalSizes, slotTargeting) => {
  return new Promise(resolve => {
    window.googletag.cmd.push(() => {
      // Don't recreate an advert if one has already been created for this slot
      if (_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_4__.dfpEnv.adverts.has(adSlot.id)) {
        var errorMessage = "Attempting to add slot with exisiting id ".concat(adSlot.id);
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', errorMessage);
        (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_6__.reportError)(Error(errorMessage), 'commercial', {
          slotId: adSlot.id
        });
        return;
      }
      var advert = (0,_define_create_advert__WEBPACK_IMPORTED_MODULE_1__.createAdvert)(adSlot, additionalSizes, slotTargeting);
      if (advert === null) return;
      _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_4__.dfpEnv.adverts.set(advert.id, advert);
      displayAd(advert, forceDisplay);
      resolve(advert);
    });
  });
};


/***/ }),

/***/ "./src/insert/spacefinder/article.ts":
/*!*******************************************!*\
  !*** ./src/insert/spacefinder/article.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   addInlineAds: () => (/* binding */ addInlineAds),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _sticky_inlines__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../sticky-inlines */ "./src/insert/sticky-inlines.ts");
/* harmony import */ var _carrot_traffic_driver__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./carrot-traffic-driver */ "./src/insert/spacefinder/carrot-traffic-driver.ts");
/* harmony import */ var _rules__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./rules */ "./src/insert/spacefinder/rules.ts");
/* harmony import */ var _space_filler__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./space-filler */ "./src/insert/spacefinder/space-filler.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }









var articleBodySelector = '.article-body-commercial-selector';
var isPaidContent = window.guardian.config.page.isPaidContent;
/**
 * Get the classname for an ad slot container
 *
 * We add 2 to the index because these are always ads added in the second pass.
 *
 * e.g. the 0th container inserted in pass 2 will have suffix `-2` to match `inline2`
 *
 * @param i Index of winning paragraph
 * @returns The classname for container
 */
var getStickyContainerClassname = i => "".concat(_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.adSlotContainerClass, "-").concat(i + 2);
var insertSlotAtPara = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (para, name, type, classes) {
    var containerOptions = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
    var ad = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.createAdSlot)(type, {
      name,
      classes
    });
    var node = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.wrapSlotInContainer)(ad, containerOptions);
    yield _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_4__["default"].mutate(() => {
      if (para.parentNode) {
        para.parentNode.insertBefore(node, para);
      }
    });
    return ad;
  });
  return function insertSlotAtPara(_x, _x2, _x3, _x4) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * Decide whether we have enough space to add additional sizes for a given advert.
 * This function ensures we don't insert large height ads at the bottom of articles,
 * when there's not enough room.
 *
 * This prevents adverts at the bottom of articles pushing down content.
 */
var decideAdditionalSizes = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* (winningPara, sizes, isLastInline) {
    // If this ad isn't the last inline then return all additional sizes
    if (!isLastInline) {
      return sizes;
    }
    // Compute the vertical distance from the TOP of the winning para to the BOTTOM of the article body
    var distanceFromBottom = yield _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_4__["default"].measure(() => {
      var _document$querySelect;
      var paraTop = winningPara.getBoundingClientRect().top;
      var articleBodyBottom = (_document$querySelect = document.querySelector(articleBodySelector)) === null || _document$querySelect === void 0 ? void 0 : _document$querySelect.getBoundingClientRect().bottom;
      return articleBodyBottom ? Math.abs(paraTop - articleBodyBottom) : undefined;
    });
    // Return all of the sizes that will fit in the distance to bottom
    return sizes.filter(adSize => distanceFromBottom ? distanceFromBottom >= adSize.height : false);
  });
  return function decideAdditionalSizes(_x5, _x6, _x7) {
    return _ref2.apply(this, arguments);
  };
}();
var addDesktopInline1 = fillSlot => {
  // these are added here and not in size mappings because the inline[i] name
  // is also used on fronts, where we don't want outstream or tall ads
  var additionalSizes = {
    phablet: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop],
    desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop]
  };
  var insertAd = /*#__PURE__*/function () {
    var _ref3 = _asyncToGenerator(function* (paras) {
      var slots = paras.slice(0, 1).map(/*#__PURE__*/function () {
        var _ref4 = _asyncToGenerator(function* (para) {
          var name = 'inline1';
          var slot = yield insertSlotAtPara(para, name, 'inline', 'inline');
          yield fillSlot(name, slot, additionalSizes);
        });
        return function (_x9) {
          return _ref4.apply(this, arguments);
        };
      }());
      yield Promise.all(slots);
    });
    return function insertAd(_x8) {
      return _ref3.apply(this, arguments);
    };
  }();
  return _space_filler__WEBPACK_IMPORTED_MODULE_8__.spaceFiller.fillSpace(_rules__WEBPACK_IMPORTED_MODULE_7__.rules.desktopInline1, insertAd, {
    waitForImages: true,
    waitForInteractives: true,
    pass: 'inline1'
  });
};
/**
 * Inserts all inline ads on desktop except for inline1.
 */
var addDesktopRightRailAds = (fillSlot, isConsentless) => {
  var insertAds = /*#__PURE__*/function () {
    var _ref5 = _asyncToGenerator(function* (paras) {
      var stickyContainerHeights = yield (0,_sticky_inlines__WEBPACK_IMPORTED_MODULE_5__.computeStickyHeights)(paras, articleBodySelector);
      void (0,_sticky_inlines__WEBPACK_IMPORTED_MODULE_5__.insertHeightStyles)(stickyContainerHeights.map((height, index) => [getStickyContainerClassname(index), height]));
      var slots = paras.slice(0, paras.length).map(/*#__PURE__*/function () {
        var _ref6 = _asyncToGenerator(function* (para, i) {
          var isLastInline = i === paras.length - 1;
          var containerClasses = getStickyContainerClassname(i) + ' offset-right ad-slot--offset-right ad-slot-container--offset-right';
          var containerOptions = {
            sticky: true,
            className: containerClasses
          };
          // these are added here and not in size mappings because the inline[i] name
          // is also used on fronts, where we don't want outstream or tall ads
          var additionalSizes = {
            desktop: yield decideAdditionalSizes(para, [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper], isLastInline)
          };
          var slot = yield insertSlotAtPara(para, "inline".concat(i + 2), 'inline', 'inline', containerOptions);
          return fillSlot("inline".concat(i + 2), slot, additionalSizes);
        });
        return function (_x1, _x10) {
          return _ref6.apply(this, arguments);
        };
      }());
      yield Promise.all(slots);
    });
    return function insertAds(_x0) {
      return _ref5.apply(this, arguments);
    };
  }();
  return _space_filler__WEBPACK_IMPORTED_MODULE_8__.spaceFiller.fillSpace(_rules__WEBPACK_IMPORTED_MODULE_7__.rules.desktopRightRail(isConsentless), insertAds, {
    waitForImages: true,
    waitForInteractives: true,
    pass: 'subsequent-inlines'
  });
};
var additionalMobileAndTabletInlineSizes = index => {
  if (index === 1) {
    return {
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.portraitInterstitial]
    };
  } else if (index === 2) {
    return {
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.portraitInterstitial, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.pubmaticInterscroller]
    };
  }
  return undefined;
};
var addMobileAndTabletInlineAds = (fillSlot, currentBreakpoint) => {
  var insertAds = /*#__PURE__*/function () {
    var _ref7 = _asyncToGenerator(function* (paras) {
      var slots = paras.map(/*#__PURE__*/function () {
        var _ref8 = _asyncToGenerator(function* (para, i) {
          //Mobile top-above-nav is the first ad in the body and the inline1 is the second ad in the body.
          //Tablet top-above-nav is above the website's navigation and the inline1 is the first ad in the body.
          var name = currentBreakpoint === 'mobile' && i === 0 ? 'top-above-nav' : currentBreakpoint === 'tablet' ? "inline".concat(i + 1) : "inline".concat(i);
          var type = currentBreakpoint === 'mobile' && i === 0 ? 'top-above-nav' : 'inline';
          var slot = yield insertSlotAtPara(para, name, type, 'inline');
          return fillSlot(name, slot, additionalMobileAndTabletInlineSizes(i));
        });
        return function (_x12, _x13) {
          return _ref8.apply(this, arguments);
        };
      }());
      yield Promise.all(slots);
    });
    return function insertAds(_x11) {
      return _ref7.apply(this, arguments);
    };
  }();
  return _space_filler__WEBPACK_IMPORTED_MODULE_8__.spaceFiller.fillSpace(_rules__WEBPACK_IMPORTED_MODULE_7__.rules.mobileAndTabletInlines, insertAds, {
    waitForImages: true,
    waitForInteractives: true,
    pass: 'mobile-inlines'
  });
};
/**
 * Add inline slots to the article body
 * @param fillSlot A function to call that will fill the slot when each ad slot has been inserted,
 * these could be google display ads or opt opt consentless ads.
 */
var addInlineAds = (fillSlot, isConsentless) => {
  var currentBreakpoint = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__.getCurrentBreakpoint)();
  if (['mobile', 'tablet'].includes(currentBreakpoint)) {
    return addMobileAndTabletInlineAds(fillSlot, currentBreakpoint);
  }
  if (isPaidContent) {
    return addDesktopRightRailAds(fillSlot, isConsentless);
  }
  return addDesktopInline1(fillSlot).then(() => addDesktopRightRailAds(fillSlot, isConsentless));
};
/**
 * Init all the article body adverts, including `carrot`
 * @param fillAdSlot a function to fill the ad slots
 */
var init = /*#__PURE__*/function () {
  var _ref9 = _asyncToGenerator(function* (fillAdSlot) {
    if (!_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.articleBodyAdverts) {
      return Promise.resolve();
    }
    yield addInlineAds(fillAdSlot, false);
    yield (0,_carrot_traffic_driver__WEBPACK_IMPORTED_MODULE_6__.initCarrot)();
  });
  return function init(_x14) {
    return _ref9.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/insert/spacefinder/carrot-traffic-driver.ts":
/*!*********************************************************!*\
  !*** ./src/insert/spacefinder/carrot-traffic-driver.ts ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initCarrot: () => (/* binding */ initCarrot)
/* harmony export */ });
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");
/* harmony import */ var _space_filler__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./space-filler */ "./src/insert/spacefinder/space-filler.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }






var bodySelector = '.article-body-commercial-selector';
var wideRules = {
  bodySelector,
  candidateSelector: ':scope > p',
  minDistanceFromTop: 500,
  minDistanceFromBottom: 400,
  clearContentMeta: 0,
  opponentSelectorRules: {
    '.element-rich-link': {
      marginBottom: 100,
      marginTop: 400
    },
    '.element-image': {
      marginBottom: 440,
      marginTop: 440
    },
    '.player': {
      marginBottom: 50,
      marginTop: 50
    },
    ':scope > h1': {
      marginBottom: 50,
      marginTop: 50
    },
    ':scope > h2': {
      marginBottom: 50,
      marginTop: 50
    },
    ':scope > *:not(p):not(h2):not(blockquote):not(#sign-in-gate)': {
      marginBottom: 50,
      marginTop: 50
    },
    '.ad-slot': {
      marginBottom: 100,
      marginTop: 100
    },
    '.element-pullquote': {
      marginBottom: 400,
      marginTop: 400
    },
    // Don't place carrot ads near newsletter sign-up blocks
    ':scope > figure[data-spacefinder-role="inline"]': {
      marginBottom: 400,
      marginTop: 400
    }
  },
  fromBottom: true
};
// anything below leftCol (1140) : desktop, tablet, ..., mobile
var desktopRules = _objectSpread(_objectSpread({}, wideRules), {}, {
  opponentSelectorRules: _objectSpread(_objectSpread({}, wideRules.opponentSelectorRules), {}, {
    '.element-rich-link': {
      marginBottom: 400,
      marginTop: 400
    },
    '.ad-slot': {
      marginBottom: 400,
      marginTop: 400
    }
  })
});
var insertSlot = paras => {
  var slot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__.createAdSlot)('carrot');
  var candidates = paras.slice(1);
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_3__["default"].mutate(() => {
    var _candidates$;
    if ((_candidates$ = candidates[0]) !== null && _candidates$ !== void 0 && _candidates$.parentNode) {
      candidates[0].parentNode.insertBefore(slot, candidates[0]);
    }
  }).then(() => void (0,_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_4__.fillDynamicAdSlot)(slot, true));
};
var getRules = () => {
  switch ((0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__.getCurrentTweakpoint)()) {
    case 'leftCol':
    case 'wide':
      return wideRules;
    default:
      return desktopRules;
  }
};
var initCarrot = () => {
  if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_0__.commercialFeatures.carrotTrafficDriver) {
    return _space_filler__WEBPACK_IMPORTED_MODULE_5__.spaceFiller.fillSpace(getRules(), insertSlot, {
      waitForImages: true,
      waitForInteractives: true,
      pass: 'carrot'
    });
  }
  return Promise.resolve(false);
};

/***/ }),

/***/ "./src/insert/spacefinder/rules.ts":
/*!*****************************************!*\
  !*** ./src/insert/spacefinder/rules.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   rules: () => (/* binding */ rules)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
var _window$guardian$conf;


var bodySelector = '.article-body-commercial-selector';
var adSlotContainerSelector = ".".concat(_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__.adSlotContainerClass);
var highValueSections = ['business', 'environment', 'music', 'money', 'artanddesign', 'science', 'stage', 'travel', 'wellness', 'games'];
var isInHighValueSection = highValueSections.includes(window.guardian.config.page.section);
/**
 * As estimation of the height of the most viewed island.
 * This appears from desktop breakpoints on the right-hand side.
 * Knowing the height of the element is useful when
 * calculating where to place ads in the right column.
 */
var MOST_VIEWED_HEIGHT = 600;
var isImmersive = window.guardian.config.page.isImmersive;
var hasImages = !!((_window$guardian$conf = window.guardian.config.page.lightboxImages) !== null && _window$guardian$conf !== void 0 && _window$guardian$conf.images.length);
var hasVideo = window.guardian.config.page.hasYouTubeAtom;
var isPaidContent = window.guardian.config.page.isPaidContent;
var hasShowcaseMainElement = window.guardian.config.page.hasShowcaseMainElement;
var minDistanceBetweenRightRailAds = 500;
var minDistanceBetweenInlineAds = isInHighValueSection ? 500 : 750;
var candidateSelector = ':scope > p, [data-spacefinder-role="nested"] > p';
var leftColumnOpponentSelector = ['richLink', 'thumbnail'].map(role => ":scope > [data-spacefinder-role=\"".concat(role, "\"]")).join(',');
var rightColumnOpponentSelector = ':scope > [data-spacefinder-role="immersive"]';
var inlineOpponentSelector = ['inline', 'supporting', 'showcase', 'halfWidth'].map(role => ":scope > [data-spacefinder-role=\"".concat(role, "\"], [data-spacefinder-role=\"nested\"] > [data-spacefinder-role=\"").concat(role, "\"]")).join(',');
var headingSelector = ":scope > h2, [data-spacefinder-role=\"nested\"] > h2, :scope > h3, [data-spacefinder-role=\"nested\"] > h3";
var desktopInline1 = {
  bodySelector,
  candidateSelector,
  minDistanceFromTop: isImmersive ? 700 : 300,
  minDistanceFromBottom: 300,
  opponentSelectorRules: {
    // don't place ads right after a heading
    [headingSelector]: {
      marginBottom: 150,
      marginTop: isInHighValueSection ? 0 : 190
    },
    [adSlotContainerSelector]: {
      marginBottom: 500,
      marginTop: 500
    },
    [inlineOpponentSelector]: {
      marginBottom: 35,
      marginTop: 200
    },
    [leftColumnOpponentSelector]: {
      marginBottom: 50,
      marginTop: 100
    },
    [rightColumnOpponentSelector]: {
      marginBottom: 0,
      marginTop: 150
    },
    ['[data-spacefinder-role="supporting"]']: {
      marginBottom: 0,
      marginTop: 100
    }
  }
};
var desktopRightRailMinAbove = isConsentless => {
  var base = 1000;
  /**
   * In special cases, inline2 can overlap the "Most viewed" island, so
   * we need to make an adjustment to move the inline2 further down the page
   */
  if (isPaidContent || !hasImages && !hasVideo || isConsentless) {
    return base + MOST_VIEWED_HEIGHT;
  }
  if (hasShowcaseMainElement || !hasImages && hasVideo) {
    return base + 250;
  }
  return base;
};
var desktopRightRail = isConsentless => {
  return {
    bodySelector,
    candidateSelector,
    minDistanceFromTop: desktopRightRailMinAbove(isConsentless),
    minDistanceFromBottom: 300,
    opponentSelectorRules: {
      [adSlotContainerSelector]: {
        marginBottom: 500,
        marginTop: 500
      },
      [rightColumnOpponentSelector]: {
        marginBottom: 0,
        marginTop: 600
      }
    },
    /**
     * Filter out any candidates that are too close to the last winner
     * see https://github.com/guardian/commercial/tree/main/docs/spacefinder#avoiding-other-winning-candidates
     * for more information
     **/
    filter: (candidate, lastWinner) => {
      if (!lastWinner) {
        return true;
      }
      var largestSizeForSlot = _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage.height;
      var distanceBetweenAds = candidate.top - lastWinner.top - largestSizeForSlot;
      return distanceBetweenAds >= minDistanceBetweenRightRailAds;
    }
  };
};
var mobileMinDistanceFromArticleTop = 200;
var mobileCandidateSelector = ':scope > p, :scope > h2, :scope > [data-spacefinder-type$="NumberedTitleBlockElement"], [data-spacefinder-role="nested"] > p';
var mobileHeadingSelector = "".concat(headingSelector, ", :scope > [data-spacefinder-type$=\"NumberedTitleBlockElement\"]");
var mobileOpponentSelectorRules = {
  // don't place ads right after a heading
  [mobileHeadingSelector]: {
    marginBottom: 100,
    marginTop: 0
  },
  [adSlotContainerSelector]: {
    marginBottom: minDistanceBetweenInlineAds,
    marginTop: minDistanceBetweenInlineAds
  },
  ["".concat(inlineOpponentSelector, ",").concat(leftColumnOpponentSelector)]: {
    marginBottom: 35,
    marginTop: 200,
    // Usually we don't want an ad right before videos, embeds and atoms etc. so that we don't break up related content too much. But if we have a heading above, anything above the heading won't be related to the current content, so we can place an ad there.
    bypassMinTop: 'h2,[data-spacefinder-type$="NumberedTitleBlockElement"]'
  },
  [rightColumnOpponentSelector]: {
    marginBottom: 35,
    marginTop: 200,
    // Usually we don't want an ad right before videos, embeds and atoms etc. so that we don't break up related content too much. But if we have a heading above, anything above the heading won't be related to the current content, so we can place an ad there.
    bypassMinTop: 'h2,[data-spacefinder-type$="NumberedTitleBlockElement"]'
  }
};
var mobileAndTabletInlines = {
  bodySelector,
  candidateSelector: mobileCandidateSelector,
  minDistanceFromTop: mobileMinDistanceFromArticleTop,
  minDistanceFromBottom: 200,
  opponentSelectorRules: mobileOpponentSelectorRules,
  /**
   * Filter out any candidates that are too close to the last winner
   * see https://github.com/guardian/commercial/tree/main/docs/spacefinder#avoiding-other-winning-candidates
   * for more information
   **/
  filter: (candidate, lastWinner) => {
    if (!lastWinner) {
      return true;
    }
    var distanceBetweenAds = candidate.top - lastWinner.top;
    return distanceBetweenAds >= minDistanceBetweenInlineAds;
  }
};
var rules = {
  desktopInline1,
  desktopRightRail,
  mobileAndTabletInlines
};

/***/ }),

/***/ "./src/insert/spacefinder/space-filler.ts":
/*!************************************************!*\
  !*** ./src/insert/spacefinder/space-filler.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   spaceFiller: () => (/* binding */ spaceFiller)
/* harmony export */ });
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _spacefinder__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./spacefinder */ "./src/insert/spacefinder/spacefinder.ts");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


class SpaceFiller {
  constructor() {
    _defineProperty(this, "queue", Promise.resolve(true));
  }
  /**
   * A safer way of using spacefinder.
   * Given a set of spacefinder rules, applies a writer to the first matching paragraph.
   * Uses fastdom to avoid layout-thrashing, but queues up asynchronous writes to avoid race conditions. We don't
   * seek a slot for a new component until all the other component writes have finished.
   */
  fillSpace(rules, writer, options) {
    var insertNextContent = () => (0,_spacefinder__WEBPACK_IMPORTED_MODULE_1__.findSpace)(rules, options).then(paragraphs => writer(paragraphs)).then(() => {
      return true;
    }).catch(ex => {
      if (ex instanceof _spacefinder__WEBPACK_IMPORTED_MODULE_1__.SpaceError) {
        return false;
      }
      throw ex;
    });
    this.queue = this.queue.then(insertNextContent).catch(e => {
      // e.g. if writer fails
      (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_0__.reportError)(e, 'space-filler');
      return false;
    });
    return this.queue;
  }
}
var spaceFiller = new SpaceFiller();


/***/ }),

/***/ "./src/insert/spacefinder/spacefinder.ts":
/*!***********************************************!*\
  !*** ./src/insert/spacefinder/spacefinder.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   SpaceError: () => (/* binding */ SpaceError),
/* harmony export */   findSpace: () => (/* binding */ findSpace)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/memoize.js");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _lib_url__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/url */ "./src/lib/url.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
// total_hours_spent_maintaining_this = 81.5




var query = (selector, context) => [...(context !== null && context !== void 0 ? context : document).querySelectorAll(selector)];
/** maximum time (in ms) to wait for images to be loaded */
var LOADING_TIMEOUT = 5000;
var defaultOptions = {
  waitForImages: true,
  waitForInteractives: false,
  pass: 'inline1'
};
var isIframe = node => node instanceof HTMLIFrameElement;
var isIframeLoaded = iframe => {
  try {
    var _iframe$contentWindow;
    return ((_iframe$contentWindow = iframe.contentWindow) === null || _iframe$contentWindow === void 0 ? void 0 : _iframe$contentWindow.document.readyState) === 'complete';
  } catch (err) {
    return true;
  }
};
var getFuncId = rules => rules.bodySelector || 'document';
var isImage = element => element instanceof HTMLImageElement;
var onImagesLoaded = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(rules => {
  var notLoaded = query('img', rules.body).filter(isImage).filter(img => !img.complete && img.loading !== 'lazy');
  var imgPromises = notLoaded.map(img => new Promise(resolve => {
    img.addEventListener('load', resolve);
  }));
  return Promise.all(imgPromises).then(() => Promise.resolve());
}, getFuncId);
var waitForSetHeightMessage = (iframe, callback) => {
  window.addEventListener('message', event => {
    if (event.source !== iframe.contentWindow) return;
    try {
      var message = JSON.parse(event.data);
      if (message.type === 'set-height' && Number(message.value) > 0) {
        callback();
      }
    } catch (ex) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'Unparsable message sent from iframe', ex);
    }
  });
};
var onInteractivesLoaded = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (rules) {
    var notLoaded = query('.element-interactive', rules.body).filter(interactive => {
      var iframes = Array.from(interactive.children).filter(isIframe);
      return !(iframes[0] && isIframeLoaded(iframes[0]));
    });
    if (notLoaded.length === 0 || !('MutationObserver' in window)) {
      return Promise.resolve();
    }
    var mutations = notLoaded.map(interactive => new Promise(resolve => {
      // Listen for when iframes are added as children to interactives
      new MutationObserver((records, instance) => {
        var _records$, _records$2;
        if (!((_records$ = records[0]) !== null && _records$ !== void 0 && _records$.addedNodes[0]) || !isIframe((_records$2 = records[0]) === null || _records$2 === void 0 ? void 0 : _records$2.addedNodes[0])) {
          return;
        }
        var iframe = records[0].addedNodes[0];
        // Listen for when the iframes are resized
        // This is a sign they have fully loaded and spacefinder can proceed
        waitForSetHeightMessage(iframe, () => {
          instance.disconnect();
          resolve();
        });
      }).observe(interactive, {
        childList: true
      });
    }));
    yield Promise.all(mutations);
  });
  return function (_x) {
    return _ref.apply(this, arguments);
  };
}(), getFuncId);
var partitionCandidates = (list, filterElement) => {
  var filtered = [];
  var exclusions = [];
  list.forEach(element => {
    if (filterElement(element, filtered[filtered.length - 1])) {
      filtered.push(element);
    } else {
      exclusions.push(element);
    }
  });
  return [filtered, exclusions];
};
/**
 * Check if the top of the candidate is far enough from the opponent
 *
 * The candidate is the element where we would like to insert an ad above. Candidates satisfy the `selector` rule.
 *
 * Opponents are other elements in the article that are in the spacefinder ruleset
 * for the current pass. This includes slots inserted by a previous pass but not
 * those in the current pass as they're all inserted at the end.
 *
 *                                                        │
 *                     Opponent Below                     │             Opponent Above
 *                                                        │
 *                  ───────────────────  Top of container │          ───────────────────  Top of container
 *                    ▲              ▲                    │            ▲              ▲
 *                    │              │                    │            │              │ opponent.top
 *                    │ ┌──────────┐ │                    │            │ ┌──────────┐ ▼   (insertion point)
 *                    │ │          │ |candidate.bottom    │            │ │          │
 *                    │ │ Candidate│ │                    │            │ │ Opponent |
 *       opponent.top │ │          │ │                    candidate.top│ │          │
 *                    │ └──────────┘ ▼                    │            │ └──────────┘
 *                    │                                   │            │           ▲
 *                    │ ────────────                      │            │           │ marginBottom
 *                    │           ▲                       │            │           ▼
 *                    │           │ marginTop             │            │  ───────────
 *                    │           ▼                       │            │
 * (insertion point)  ▼ ┌──────────┐                      │            ▼ ┌──────────┐
 *                      │          │                      │              │          │
 *                      │ Opponent |                      │              │ Candidate│
 *                      │          │                      │              │          │
 *                      └──────────┘                      │              └──────────┘
 *                                                        │
 *                                                        │
 */
var isTopOfCandidateFarEnoughFromOpponent = (candidate, opponent, rule, isOpponentBelow) => {
  var potentialInsertPosition = candidate.top;
  if (isOpponentBelow && rule.marginTop) {
    if (rule.bypassMinTop && candidate.element.matches(rule.bypassMinTop)) {
      return true;
    }
    return opponent.top - potentialInsertPosition >= rule.marginTop;
  }
  if (!isOpponentBelow && rule.marginBottom) {
    return potentialInsertPosition - opponent.bottom >= rule.marginBottom;
  }
  // if no rule is set (or they're 0), return true
  return true;
};
/**
 * Check if 1 - the candidate is the same as the opponent or 2- if the opponent contains the candidate
 *
 * 1 can happen when the candidate and opponent selectors overlap
 * 2 can happen when there are nested candidates, it may try t avoid it's own ancestor
 */
var bypassTestCandidate = (candidate, opponent) => candidate.element === opponent.element || opponent.element.contains(candidate.element);
// test one element vs another for the given rules
var testCandidate = (rule, candidate, opponent) => {
  if (bypassTestCandidate(candidate, opponent)) {
    return true;
  }
  var isOpponentBelow = opponent.bottom > candidate.bottom && opponent.top >= candidate.bottom;
  var isOpponentAbove = opponent.top < candidate.top && opponent.bottom <= candidate.top;
  // this can happen when the an opponent like an image or interactive is floated right
  var opponentOverlaps = isOpponentAbove && isOpponentBelow || !isOpponentAbove && !isOpponentBelow;
  var pass = !opponentOverlaps && isTopOfCandidateFarEnoughFromOpponent(candidate, opponent, rule, isOpponentBelow);
  if (!pass) {
    if (opponentOverlaps) {
      candidate.meta.overlaps.push({
        element: opponent.element
      });
    } else {
      // if the test fails, add debug information to the candidate metadata
      var required = isOpponentBelow ? rule.marginTop : rule.marginBottom;
      var actual = isOpponentBelow ? opponent.top - candidate.top : candidate.top - opponent.bottom;
      candidate.meta.tooClose.push({
        required,
        actual,
        element: opponent.element
      });
    }
  }
  return pass;
};
// test one element vs an array of other elements for the given rule
var testCandidates = (rule, candidate, opponents) => opponents.map(opponent => testCandidate(rule, candidate, opponent)).every(Boolean);
var enforceRules = (measurements, rules, spacefinderExclusions) => {
  var candidates = measurements.candidates;
  // enforce absoluteMinDistanceFromTop rule
  var [filtered, exclusions] = partitionCandidates(candidates, candidate => !rules.absoluteMinDistanceFromTop || candidate.top + measurements.bodyTop >= rules.absoluteMinDistanceFromTop);
  spacefinderExclusions.absoluteMinDistanceFromTop = exclusions;
  candidates = filtered;
  // enforce minAbove and minBelow rules
  [filtered, exclusions] = partitionCandidates(candidates, candidate => {
    var farEnoughFromTopOfBody = candidate.top >= rules.minDistanceFromTop;
    var farEnoughFromBottomOfBody = candidate.top + rules.minDistanceFromBottom <= measurements.bodyHeight;
    return farEnoughFromTopOfBody && farEnoughFromBottomOfBody;
  });
  spacefinderExclusions.aboveAndBelow = exclusions;
  candidates = filtered;
  // enforce content meta rule
  var {
    clearContentMeta
  } = rules;
  if (clearContentMeta) {
    [filtered, exclusions] = partitionCandidates(candidates, candidate => !!measurements.contentMeta && candidate.top > measurements.contentMeta.bottom + clearContentMeta);
    spacefinderExclusions.contentMeta = exclusions;
    candidates = filtered;
  }
  // enforce selector rules
  if (rules.opponentSelectorRules) {
    var selectorExclusions = [];
    var _loop = function (selector, rule) {
      [filtered, exclusions] = partitionCandidates(candidates, candidate => {
        var _measurements$opponen, _measurements$opponen2;
        return testCandidates(rule, candidate, (_measurements$opponen = (_measurements$opponen2 = measurements.opponents) === null || _measurements$opponen2 === void 0 ? void 0 : _measurements$opponen2[selector]) !== null && _measurements$opponen !== void 0 ? _measurements$opponen : []);
      });
      spacefinderExclusions[selector] = exclusions;
      selectorExclusions.push(...exclusions);
    };
    for (var [selector, rule] of Object.entries(rules.opponentSelectorRules)) {
      _loop(selector, rule);
    }
    candidates = candidates.filter(candidate => !selectorExclusions.includes(candidate));
  }
  if (rules.filter) {
    [filtered, exclusions] = partitionCandidates(candidates, rules.filter);
    spacefinderExclusions.custom = exclusions;
    candidates = filtered;
  }
  return candidates;
};
class SpaceError extends Error {
  constructor(rules) {
    super();
    this.name = 'SpaceError';
    this.message = "There is no space left matching rules from ".concat(rules.bodySelector);
  }
}
/**
 * Wait for the page to be ready (images loaded, interactives loaded)
 * or for LOADING_TIMEOUT to elapse, whichever comes first.
 * @param  {SpacefinderRules} rules
 * @param  {SpacefinderOptions} options
 */
var getReady = (rules, options) => Promise.race([new Promise(resolve => window.setTimeout(() => resolve('timeout'), LOADING_TIMEOUT)), Promise.all([options.waitForImages ? onImagesLoaded(rules) : Promise.resolve(), options.waitForInteractives ? onInteractivesLoaded(rules) : Promise.resolve()])]).then(value => {
  if (value === 'timeout') {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'Spacefinder timeout hit');
  }
});
var getCandidates = (rules, spacefinderExclusions) => {
  var candidates = query(rules.candidateSelector, rules.body);
  if (rules.fromBottom) {
    candidates.reverse();
  }
  if (rules.startAt) {
    var drop = true;
    var [filtered, exclusions] = partitionCandidates(candidates, candidate => {
      if (candidate === rules.startAt) {
        drop = false;
      }
      return !drop;
    });
    spacefinderExclusions.startAt = exclusions;
    candidates = filtered;
  }
  if (rules.stopAt) {
    var keep = true;
    var [_filtered, _exclusions] = partitionCandidates(candidates, candidate => {
      if (candidate === rules.stopAt) {
        keep = false;
      }
      return keep;
    });
    spacefinderExclusions.stopAt = _exclusions;
    candidates = _filtered;
  }
  return candidates;
};
var getDimensions = element => Object.freeze({
  top: element.offsetTop,
  bottom: element.offsetTop + element.offsetHeight,
  element,
  meta: {
    tooClose: [],
    overlaps: []
  }
});
var getMeasurements = (rules, candidates) => {
  var _document$querySelect;
  var contentMeta = rules.clearContentMeta ? (_document$querySelect = document.querySelector('.js-content-meta')) !== null && _document$querySelect !== void 0 ? _document$querySelect : undefined : undefined;
  var opponents = rules.opponentSelectorRules ? Object.keys(rules.opponentSelectorRules).map(selector => [selector, query(selector, rules.body)]) : [];
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].measure(() => {
    var bodyDistanceToTopOfPage = 0;
    var bodyHeight = 0;
    if (rules.body instanceof Element) {
      var bodyElement = rules.body.getBoundingClientRect();
      // bodyElement is relative to the viewport, so we need to add scroll position to get the distance
      bodyDistanceToTopOfPage = bodyElement.top + window.scrollY;
      bodyHeight = bodyElement.height;
    }
    var candidatesWithDims = candidates.map(getDimensions);
    var contentMetaWithDims = rules.clearContentMeta && contentMeta ? getDimensions(contentMeta) : undefined;
    var opponentsWithDims = opponents.reduce((result, _ref2) => {
      var [selector, selectedElements] = _ref2;
      result[selector] = selectedElements.map(getDimensions);
      return result;
    }, {});
    return {
      bodyTop: bodyDistanceToTopOfPage,
      bodyHeight,
      candidates: candidatesWithDims,
      contentMeta: contentMetaWithDims,
      opponents: opponentsWithDims
    };
  });
};
// Rather than calling this directly, use spaceFiller to inject content into the page.
// SpaceFiller will safely queue up all the various asynchronous DOM actions to avoid any race conditions.
var findSpace = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator(function* (rules, options) {
    var _document$querySelect2, _measure$duration;
    var exclusions = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    options = _objectSpread(_objectSpread({}, defaultOptions), options);
    rules.body = rules.bodySelector ? (_document$querySelect2 = document.querySelector(rules.bodySelector)) !== null && _document$querySelect2 !== void 0 ? _document$querySelect2 : document : document;
    window.performance.mark('commercial:spacefinder:findSpace:start');
    yield getReady(rules, options);
    var candidates = getCandidates(rules, exclusions);
    var measurements = yield getMeasurements(rules, candidates);
    var winners = enforceRules(measurements, rules, exclusions);
    var enableDebug = !!(0,_lib_url__WEBPACK_IMPORTED_MODULE_3__.getUrlVars)().sfdebug;
    if (enableDebug) {
      var pass = options.pass;
      void __webpack_require__.e(/*! import() */ "src_insert_spacefinder_spacefinder-debug-tools_ts").then(__webpack_require__.bind(__webpack_require__, /*! ./spacefinder-debug-tools */ "./src/insert/spacefinder/spacefinder-debug-tools.ts")).then(_ref4 => {
        var {
          init
        } = _ref4;
        init(exclusions, winners, rules, pass);
      });
    }
    window.performance.mark('commercial:spacefinder:findSpace:end');
    var measure = window.performance.measure('commercial:spacefinder:findSpace', 'commercial:spacefinder:findSpace:start', 'commercial:spacefinder:findSpace:end');
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "Spacefinder took ".concat(Math.round((_measure$duration = measure === null || measure === void 0 ? void 0 : measure.duration) !== null && _measure$duration !== void 0 ? _measure$duration : 0), "ms for '").concat(options.pass, "' pass"), {
      rules,
      options
    });
    // TODO Is this really an error condition?
    if (!winners.length) {
      throw new SpaceError(rules);
    }
    return winners.map(candidate => candidate.element);
  });
  return function findSpace(_x2, _x3) {
    return _ref3.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/insert/sticky-inlines.ts":
/*!**************************************!*\
  !*** ./src/insert/sticky-inlines.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   computeStickyHeights: () => (/* binding */ computeStickyHeights),
/* harmony export */   insertHeightStyles: () => (/* binding */ insertHeightStyles)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isUndefined/isUndefined.js");
/* harmony import */ var _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/source/foundations */ "../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }



/**
 * The minimum buffer between two adverts (aka winning paragraphs) in the right column
 */
var PARAGRAPH_BUFFER_PX = 600;
/**
 * The minimum buffer between a right column advert and an immersive element
 */
var IMMERSIVE_BUFFER_PX = 100;
/**
 * The minimum buffer between a right column advert and the bottom of the article body
 */
var ARTICLE_BOTTOM_BUFFER_PX = 100;
/**
 * The height of the labs header on paid content pages
 */
var LABS_HEADER_HEIGHT = 55;
/**
 * Add a stylesheet to the document that adds height properties for a given set of class names
 *
 * Note these are only above on desktop and above
 *
 * @param heightMapping The mapping from class name to height value in pixels
 */
var insertHeightStyles = heightMapping => {
  /**
   * Paid content has a banner at the top of the page. We don't want this
   * banner to overlap the advert. Adds extra padding for visual benefit
   */
  var top = window.guardian.config.page.isPaidContent ? "".concat(LABS_HEADER_HEIGHT + 6, "px") : 0;
  var heightClasses = heightMapping.reduce((css, _ref) => {
    var [name, height] = _ref;
    return "".concat(css, " .").concat(name, " { min-height: ").concat(height, "px; } .").concat(name, " > * { position: sticky; top: ").concat(top, "; }");
  }, '');
  var css = "\n        @media (min-width: ".concat(_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_1__.breakpoints.desktop, "px) {\n            ").concat(heightClasses, "\n        }\n    ");
  var style = document.createElement('style');
  style.appendChild(document.createTextNode(css));
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
    document.head.appendChild(style);
  });
};
/**
 * Compute the distance between each winning paragraph and subsequent paragraph,
 * taking into account elements that extend into the right column
 */
var computeStickyHeights = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* (winners, articleBodySelector) {
    // Immersive figures can extend into the right column
    // Therefore we have to take them into account when we can compute how far an ad can be sticky for
    var immersiveFigures = [...document.querySelectorAll('[data-spacefinder-role="immersive"]')];
    var {
      figures,
      winningParas,
      articleBodyElementHeightBottom
    } = yield _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].measure(() => {
      var _document$querySelect, _document$querySelect2;
      var figures = immersiveFigures.map(element => ({
        kind: 'figure',
        top: element.getBoundingClientRect().top,
        element
      }));
      var winningParas = winners.map(element => ({
        kind: 'winningPara',
        top: element.getBoundingClientRect().top,
        element
      }));
      var articleBodyElementHeightBottom = (_document$querySelect = (_document$querySelect2 = document.querySelector(articleBodySelector)) === null || _document$querySelect2 === void 0 ? void 0 : _document$querySelect2.getBoundingClientRect().bottom) !== null && _document$querySelect !== void 0 ? _document$querySelect : 0;
      return {
        figures,
        winningParas,
        articleBodyElementHeightBottom
      };
    });
    return (
      // Concat the set of figures and winning paragraphs in the article
      [...figures, ...winningParas]
      // Sort so they appear in order of their top coordinates
      .sort((first, second) => first.top - second.top)
      // Step through each one by one, measuring the height we can make the container of the ad slot
      .map((current, index, items) => {
        // We don't care about computing the distance *from* figures
        // These will be filtered out in the next step
        if (current.kind === 'figure') {
          return undefined;
        }
        // Retrieve the next element to which we'll extend the container height
        // This can be undefined if there is no next item
        var next = items[index + 1];
        // If there is no `next` element we've reached the final element in the article body
        // In this case we want to make the sticky distance extend until the bottom of the article body,
        // minus a small constant buffer
        if (next === undefined) {
          return articleBodyElementHeightBottom - current.top - ARTICLE_BOTTOM_BUFFER_PX;
        }
        // Choose height of buffer depending on the kind of element we're measuring to
        var buffer = next.kind === 'winningPara' ? PARAGRAPH_BUFFER_PX : IMMERSIVE_BUFFER_PX;
        // Compute the distance from the top of the current element to the top of the next element, minus the buffer
        return Math.floor(next.top - current.top - buffer);
      })
      // Remove the figures marked as undefined
      // In effect keeping only the heights for winning paragraphs
      .filter(height => !(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isUndefined)(height))
    );
  });
  return function computeStickyHeights(_x, _x2) {
    return _ref2.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/lib/__vendor/pubmatic.js":
/*!**************************************!*\
  !*** ./src/lib/__vendor/pubmatic.js ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   pubmatic: () => (/* binding */ pubmatic)
/* harmony export */ });
/**
 * Pubmatic custom override script
 *
 * From {@Link https://gist.github.com/abhinavsinha001/de46bd4ac4f02d98eb50c1f4f995545e}
 */
var pubmatic = function (bid, data, acEnabled, utils, defaultFn) {
  if (defaultFn) {
    // keep this to move to default function once supported by RTD submodule
    bid = defaultFn(bid, data, acEnabled);
  } else {
    var segments = [];
    // add all user segments
    try {
      var psegs = JSON.parse(localStorage._psegs || '[]').map(String);
      var ppam = JSON.parse(localStorage._ppam || '[]');
      var pcrprs = JSON.parse(localStorage._pcrprs || '[]');
      segments = [...psegs, ...ppam, ...pcrprs];
    } catch (e) {}
    // add AC specific segments (these would typically go to a separate key-value, but not sure if we can have 2 lists of segments here?)
    if (acEnabled && data.ac && data.ac.length > 0) {
      segments = segments.concat(data.ac);
    }
    segments = segments.map(function (seg) {
      return {
        id: seg
      };
    });
    pbjs.setBidderConfig({
      // Note this will replace existing bidder FPD config till merge is supported.
      bidders: ['pubmatic'],
      config: {
        ortb2: {
          user: {
            data: [{
              name: 'permutive.com',
              segment: segments
            }]
          }
        }
      }
    });
  }
};

/***/ }),

/***/ "./src/lib/ab-localstorage.ts":
/*!************************************!*\
  !*** ./src/lib/ab-localstorage.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getParticipationsFromLocalStorage: () => (/* binding */ getParticipationsFromLocalStorage),
/* harmony export */   setParticipationsInLocalStorage: () => (/* binding */ setParticipationsInLocalStorage)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");

var participationsKey = 'gu.ab.participations';
var isParticipations = participations => {
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isObject)(participations) && Object.values(participations).every(participation => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isObject)(participation) && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isString)(participation.variant));
};
var getParticipationsFromLocalStorage = () => {
  var participations = _guardian_libs__WEBPACK_IMPORTED_MODULE_2__.storage.local.get(participationsKey);
  return isParticipations(participations) ? participations : {};
};
var setParticipationsInLocalStorage = participations => {
  _guardian_libs__WEBPACK_IMPORTED_MODULE_2__.storage.local.set(participationsKey, participations);
};

/***/ }),

/***/ "./src/lib/create-ad-slot.ts":
/*!***********************************!*\
  !*** ./src/lib/create-ad-slot.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   adSlotContainerClass: () => (/* binding */ adSlotContainerClass),
/* harmony export */   concatSizeMappings: () => (/* binding */ concatSizeMappings),
/* harmony export */   createAdSlot: () => (/* binding */ createAdSlot),
/* harmony export */   wrapSlotInContainer: () => (/* binding */ wrapSlotInContainer)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_breakpoint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/breakpoint */ "../core/src/breakpoint.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var adSlotIdPrefix = 'dfp-ad--';
var adSlotConfigs = {
  'merchandising-high': {
    refresh: false
  },
  carrot: {
    label: false,
    refresh: false,
    name: 'carrot'
  },
  'mobile-sticky': {
    label: true,
    refresh: true,
    name: 'mobile-sticky'
  }
};
/**
  Returns an adSlot HTMLElement which is the main DFP slot.

  Insert that element as siblings at the place you want adverts to appear.

  Note that for the DFP slot to be filled by GTP, you'll have to
  use addSlot from fill-dynamic-advert-slot.ts
*/
var createAdSlotElement = (name, attrs, classes) => {
  var id = "".concat(adSlotIdPrefix).concat(name);
  // 3562dc07-78e9-4507-b922-78b979d4c5cb
  if (window.guardian.config.isDotcomRendering && name === 'top-above-nav') {
    // This is to prevent a problem that appeared with DCR.
    // We are simply making sure that if we are about to
    // introduce dfp-ad--top-above-nav then there isn't already one.
    var node = document.getElementById(id);
    if (node !== null && node !== void 0 && node.parentNode) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "warning: cleaning up dom node id: dfp-ad--".concat(name));
      node.parentNode.removeChild(node);
    }
  }
  // The 'main' adSlot
  var adSlot = document.createElement('div');
  adSlot.id = id;
  adSlot.className = "js-ad-slot ad-slot ".concat(classes.join(' '));
  adSlot.dataset.linkName = "ad slot ".concat(name);
  adSlot.dataset.name = name;
  adSlot.setAttribute('aria-hidden', 'true');
  Object.entries(attrs).forEach(_ref => {
    var [k, v] = _ref;
    return adSlot.dataset[k] = v;
  });
  return adSlot;
};
/**
 * Split class names and prefix all with ad-slot--${className}
 */
var createClasses = (slotName, classes) => {
  var _classes$split;
  return [...((_classes$split = classes === null || classes === void 0 ? void 0 : classes.split(' ')) !== null && _classes$split !== void 0 ? _classes$split : []), slotName].map(className => "ad-slot--".concat(className));
};
/**
 * Given default size mappings and additional size mappings from
 * the createAdSlot options parameter.
 *
 * 1. Check that the options size mappings use known device names
 * 2. If so concat the size mappings
 */
var concatSizeMappings = function (defaultSizeMappings) {
  var optionSizeMappings = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  return Object.entries(optionSizeMappings).reduce((combinedSizeMapping, _ref2) => {
    var _combinedSizeMapping$;
    var [device, optionSizes] = _ref2;
    if (!(0,_guardian_commercial_core_breakpoint__WEBPACK_IMPORTED_MODULE_0__.isBreakpoint)(device)) {
      throw new Error("Unknown device breakpoint: ".concat(device));
    }
    var sizes = optionSizes.reduce((acc, size) => {
      var existingSize = acc.find(s => s.width === size.width && s.height === size.height);
      if (!existingSize) {
        acc.push(size);
      }
      return acc;
    }, [...((_combinedSizeMapping$ = combinedSizeMapping[device]) !== null && _combinedSizeMapping$ !== void 0 ? _combinedSizeMapping$ : [])]);
    return _objectSpread(_objectSpread({}, combinedSizeMapping), {}, {
      [device]: sizes
    });
  }, _objectSpread({}, defaultSizeMappings));
};
var adSlotContainerClass = 'ad-slot-container';
var wrapSlotInContainer = function (adSlot) {
  var _options$className;
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var container = document.createElement('div');
  container.className = "".concat(adSlotContainerClass, " ").concat((_options$className = options.className) !== null && _options$className !== void 0 ? _options$className : '');
  container.dataset.adSlot = 'true';
  container.appendChild(adSlot);
  return container;
};
var createAdSlot = function (name) {
  var _adSlotConfigs$name, _ref3, _options$name;
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  var adSlotConfig = (_adSlotConfigs$name = adSlotConfigs[name]) !== null && _adSlotConfigs$name !== void 0 ? _adSlotConfigs$name : {};
  var slotName = (_ref3 = (_options$name = options.name) !== null && _options$name !== void 0 ? _options$name : adSlotConfig.name) !== null && _ref3 !== void 0 ? _ref3 : name;
  var dataAttributes = {};
  if (adSlotConfig.label === false) {
    dataAttributes.label = 'false';
  }
  if (adSlotConfig.refresh === false) {
    dataAttributes.refresh = 'false';
  }
  return createAdSlotElement(slotName, dataAttributes, createClasses(slotName, options.classes));
};


/***/ }),

/***/ "./src/lib/dfp/get-advert-by-id.ts":
/*!*****************************************!*\
  !*** ./src/lib/dfp/get-advert-by-id.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getAdvertById: () => (/* binding */ getAdvertById)
/* harmony export */ });
/* harmony import */ var _dfp_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dfp-env */ "./src/lib/dfp/dfp-env.ts");

var getAdvertById = id => {
  var _dfpEnv$adverts$get;
  return (_dfpEnv$adverts$get = _dfp_env__WEBPACK_IMPORTED_MODULE_0__.dfpEnv.adverts.get(id)) !== null && _dfpEnv$adverts$get !== void 0 ? _dfpEnv$adverts$get : null;
};


/***/ }),

/***/ "./src/lib/dfp/queue-advert.ts":
/*!*************************************!*\
  !*** ./src/lib/dfp/queue-advert.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   queueAdvert: () => (/* binding */ queueAdvert)
/* harmony export */ });
/* harmony import */ var _dfp_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./dfp-env */ "./src/lib/dfp/dfp-env.ts");

var queueAdvert = advert => {
  _dfp_env__WEBPACK_IMPORTED_MODULE_0__.dfpEnv.advertsToLoad.push(advert);
};

/***/ }),

/***/ "./src/lib/header-bidding/a9/a9.ts":
/*!*****************************************!*\
  !*** ./src/lib/header-bidding/a9/a9.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   a9: () => (/* binding */ a9)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/flatten.js");
/* harmony import */ var _error_report_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _slot_config__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../slot-config */ "./src/lib/header-bidding/slot-config.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }



/*
 * Amazon's header bidding javascript library
 * https://ams.amazon.com/webpublisher/uam/docs/web-integration-documentation/integration-guide/javascript-guide/display.html
 */
class A9AdUnit {
  constructor(advert, slot) {
    _defineProperty(this, "slotID", void 0);
    _defineProperty(this, "slotName", void 0);
    _defineProperty(this, "sizes", void 0);
    this.slotID = advert.id;
    this.slotName = window.guardian.config.page.adUnit;
    this.sizes = slot.sizes.map(size => Array.from(size));
  }
}
var initialised = false;
var requestQueue = Promise.resolve();
var bidderTimeout = 1500;
var initialise = () => {
  if (!initialised && window.apstag) {
    initialised = true;
    var blockedBidders = window.guardian.config.page.isFront ? ['1lsxjb4' // GumGum, as they have been showing wonky formats on fronts
    ] : [];
    window.apstag.init({
      pubID: window.guardian.config.page.a9PublisherId,
      adServer: 'googletag',
      bidTimeout: bidderTimeout,
      blockedBidders
    });
  }
};
var logA9BidResponse = bidResponse => {
  var _window$guardian, _window$guardian$comm, _window$guardian$comm2, _window$guardian$comm3;
  (_window$guardian$comm = (_window$guardian = window.guardian).commercial) !== null && _window$guardian$comm !== void 0 ? _window$guardian$comm : _window$guardian.commercial = {};
  (_window$guardian$comm3 = (_window$guardian$comm2 = window.guardian.commercial).a9WinningBids) !== null && _window$guardian$comm3 !== void 0 ? _window$guardian$comm3 : _window$guardian$comm2.a9WinningBids = [];
  window.guardian.commercial.a9WinningBids.push(...bidResponse);
};
// slotFlatMap allows you to dynamically interfere with the PrebidSlot definition
// for this given request for bids.
var requestBids = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (adverts, slotFlatMap) {
    if (!initialised) {
      return requestQueue;
    }
    if (!window.guardian.config.switches.a9HeaderBidding) {
      return requestQueue;
    }
    var adUnits = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(adverts.map(advert => (0,_slot_config__WEBPACK_IMPORTED_MODULE_2__.getHeaderBiddingAdSlots)(advert, slotFlatMap).map(slot => new A9AdUnit(advert, slot))));
    if (adUnits.length === 0) {
      return requestQueue;
    }
    requestQueue = requestQueue.then(() => new Promise(resolve => {
      var _window$apstag;
      (_window$apstag = window.apstag) === null || _window$apstag === void 0 || _window$apstag.fetchBids({
        slots: adUnits
      }, bidResponse => {
        logA9BidResponse(bidResponse);
        window.googletag.cmd.push(() => {
          var _window$apstag2;
          (_window$apstag2 = window.apstag) === null || _window$apstag2 === void 0 || _window$apstag2.setDisplayBids();
          resolve();
        });
      });
    })).catch(() => {
      (0,_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(new Error('a9 header bidding error'), 'commercial');
    });
    return requestQueue;
  });
  return function requestBids(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
var a9 = {
  initialise,
  requestBids,
  logA9BidResponse
};
var _ = {
  resetModule: () => {
    initialised = false;
    requestQueue = Promise.resolve();
  }
};

/***/ }),

/***/ "./src/lib/header-bidding/prebid/appnexus.ts":
/*!***************************************************!*\
  !*** ./src/lib/header-bidding/prebid/appnexus.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   getAppNexusDirectBidParams: () => (/* binding */ getAppNexusDirectBidParams),
/* harmony export */   getAppNexusDirectPlacementId: () => (/* binding */ getAppNexusDirectPlacementId)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _page_targeting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../page-targeting */ "./src/lib/page-targeting.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../utils */ "./src/lib/header-bidding/utils.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }



var getAppNexusInvCode = sizes => {
  var device = (0,_utils__WEBPACK_IMPORTED_MODULE_2__.getBreakpointKey)() === 'M' ? 'M' : 'D';
  // section is optional and makes it through to the config object as an empty string... OTL
  var sectionName = window.guardian.config.page.section || window.guardian.config.page.sectionName.replace(/ /g, '-');
  var slotSize = (0,_utils__WEBPACK_IMPORTED_MODULE_2__.getLargestSize)(sizes);
  if (slotSize) {
    return "".concat(device).concat(sectionName.toLowerCase()).concat(slotSize.join('x'));
  }
};
var getAppNexusDirectPlacementId = sizes => {
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
    return '11016434';
  }
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)() && (0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsMobileSticky)(sizes)) {
    return '31512573';
  }
  var defaultPlacementId = '9251752';
  switch ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.getBreakpointKey)()) {
    case 'D':
      // The only prebid compatible size for fronts-banner-ads and the merchandising-high is the billboard (970x250)
      // This check is to distinguish from the top-above-nav which includes a leaderboard
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsBillboardNotLeaderboard)(sizes)) {
        return '30017511';
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsMpuOrDmpu)(sizes)) {
        return '9251752';
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsLeaderboardOrBillboard)(sizes)) {
        return '9926678';
      }
      return defaultPlacementId;
    case 'M':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsMpu)(sizes)) {
        return '4298191';
      }
      return defaultPlacementId;
    case 'T':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsMpu)(sizes)) {
        return '4371641';
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.containsLeaderboard)(sizes)) {
        return '4371640';
      }
      return defaultPlacementId;
    default:
      return defaultPlacementId;
  }
};
var getAppNexusDirectBidParams = (sizes, pageTargeting, slotId) => {
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)() && window.guardian.config.switches.prebidAppnexusInvcode) {
    var invCode = getAppNexusInvCode(sizes);
    if (invCode) {
      return {
        invCode,
        member: '7012',
        keywords: _objectSpread(_objectSpread({
          invc: [invCode]
        }, (0,_page_targeting__WEBPACK_IMPORTED_MODULE_1__.buildAppNexusTargetingObject)(pageTargeting)), {}, {
          slot: slotId
        })
      };
    }
  }
  return {
    placementId: getAppNexusDirectPlacementId(sizes),
    keywords: _objectSpread(_objectSpread({}, (0,_page_targeting__WEBPACK_IMPORTED_MODULE_1__.buildAppNexusTargetingObject)(pageTargeting)), {}, {
      slot: slotId
    })
  };
};
var _ = {
  getAppNexusDirectPlacementId
};

/***/ }),

/***/ "./src/lib/header-bidding/prebid/bid-config.ts":
/*!*****************************************************!*\
  !*** ./src/lib/header-bidding/prebid/bid-config.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   bids: () => (/* binding */ bids)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _page_targeting__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../page-targeting */ "./src/lib/page-targeting.ts");
/* harmony import */ var _url__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../url */ "./src/lib/url.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../utils */ "./src/lib/header-bidding/utils.ts");
/* harmony import */ var _appnexus__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./appnexus */ "./src/lib/header-bidding/prebid/appnexus.ts");
/* harmony import */ var _magnite__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./magnite */ "./src/lib/header-bidding/prebid/magnite.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }








var isArticle = window.guardian.config.page.contentType === 'Article';
var isDesktopAndArticle = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.getBreakpointKey)() === 'D' && isArticle;
var getTrustXAdUnitId = (slotId, isDesktopArticle) => {
  switch ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.stripMobileSuffix)(slotId)) {
    case 'dfp-ad--inline1':
      return '2960';
    case 'dfp-ad--inline2':
      if (isDesktopArticle) return '3826';
      return '3827';
    case 'dfp-ad--inline3':
      if (isDesktopArticle) return '3828';
      return '3829';
    case 'dfp-ad--inline4':
      if (isDesktopArticle) return '3830';
      return '3831';
    case 'dfp-ad--inline5':
      if (isDesktopArticle) return '3832';
      return '3833';
    case 'dfp-ad--inline6':
      if (isDesktopArticle) return '3834';
      return '3835';
    case 'dfp-ad--inline7':
      if (isDesktopArticle) return '3836';
      return '3837';
    case 'dfp-ad--inline8':
      if (isDesktopArticle) return '3838';
      return '3839';
    case 'dfp-ad--inline9':
      if (isDesktopArticle) return '3840';
      return '3841';
    case 'dfp-ad--mostpop':
      return '2961';
    case 'dfp-ad--right':
      return '2962';
    case 'dfp-ad--top-above-nav':
      return '2963';
    case 'dfp-ad--comments':
      return '3840';
    case 'dfp-ad--mobile-sticky':
      return '8519';
    default:
      // for inline10 and onwards just use same IDs as inline9
      if (slotId.startsWith('dfp-ad--inline')) {
        if (isDesktopArticle) return '3840';
        return '3841';
      }
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "PREBID: Failed to get TrustX ad unit for slot ".concat(slotId, "."));
      return '';
  }
};
/**
 * We store a mapping of sections to Index site ids server-side, where each is
 * split out by breakpoint. These are transferred to the client via the window,
 * and read here
 *
 * This appears to be an old method of assigning site ids, with the newer method
 * being to assign them according to ad size (@see getIndexSiteId)
 */
var getIndexSiteIdFromConfig = () => {
  var site = window.guardian.config.page.pbIndexSites.find(s => s.bp === (0,_utils__WEBPACK_IMPORTED_MODULE_5__.getBreakpointKey)());
  return site !== null && site !== void 0 && site.id ? site.id.toString() : '';
};
var getIndexSiteId = slotSizes => {
  // The only prebid compatible size for fronts-banner-ads and the merchandising-high is the billboard (970x250)
  // This check is to distinguish from the top-above-nav slot, which includes a leaderboard
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsBillboardNotLeaderboard)(slotSizes)) {
    return '983842';
  }
  // Return a specific site id for the mobile sticky slot
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMobileSticky)(slotSizes)) {
    return '1047869';
  }
  // Fall back to reading the site id from the window
  return getIndexSiteIdFromConfig();
};
var getXaxisPlacementId = sizes => {
  switch ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.getBreakpointKey)()) {
    case 'D':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMpuOrDmpu)(sizes)) {
        return 20943665;
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsLeaderboardOrBillboard)(sizes)) {
        return 20943666;
      }
      return 20943668;
    case 'M':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMpuOrDmpu)(sizes)) {
        return 20943669;
      }
      return 20943670;
    case 'T':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMpuOrDmpu)(sizes)) {
        return 20943671;
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsLeaderboardOrBillboard)(sizes)) {
        return 20943672;
      }
      return 20943674;
    default:
      return -1;
  }
};
var getTripleLiftInventoryCode = (slotId, sizes) => {
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsLeaderboard)(sizes)) {
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
      return 'theguardian_topbanner_728x90_prebid';
    } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
      return 'theguardian_topbanner_728x90_prebid_AU';
    }
  }
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMpu)(sizes)) {
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
      return isArticle ? 'theguardian_article_300x250_prebid' : 'theguardian_sectionfront_300x250_prebid';
    } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
      return isArticle ? 'theguardian_article_300x250_prebid_AU' : 'theguardian_sectionfront_300x250_prebid_AU';
    }
  }
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsBillboard)(sizes)) {
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
      return 'theguardian_article_970x250_prebid';
    } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
      return 'theguardian_article_970x250_prebid_AU';
    }
  }
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMobileSticky)(sizes)) {
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
      return 'theguardian_320x50_HDX';
    } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
      return 'theguardian_320x50_HDX_AU';
    }
  }
  return '';
};
// Is pbtest being used?
var isPbTestOn = () => Object.keys((0,_url__WEBPACK_IMPORTED_MODULE_4__.pbTestNameMap)()).length > 0;
// Helper for conditions
var inPbTestOr = liveClause => isPbTestOn() || liveClause;
/* Bidders */
var appNexusBidder = pageTargeting => ({
  name: 'and',
  switchName: 'prebidAppnexus',
  bidParams: (slotId, sizes) => (0,_appnexus__WEBPACK_IMPORTED_MODULE_6__.getAppNexusDirectBidParams)(sizes, pageTargeting, (0,_utils__WEBPACK_IMPORTED_MODULE_5__.stripDfpAdPrefixFrom)(slotId))
});
var openxBidder = pageTargeting => ({
  name: 'oxd',
  switchName: 'prebidOpenx',
  bidParams: (slotId, sizes) => {
    var customParams = (0,_page_targeting__WEBPACK_IMPORTED_MODULE_3__.buildAppNexusTargetingObject)(pageTargeting);
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
      return {
        delDomain: 'guardian-us-d.openx.net',
        unit: '540279544',
        customParams
      };
    }
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
      return {
        delDomain: 'guardian-aus-d.openx.net',
        unit: '540279542',
        customParams
      };
    }
    // ROW has a unique unit ID for mobile-sticky
    if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)() && (0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMobileSticky)(sizes)) {
      return {
        delDomain: 'guardian-d.openx.net',
        unit: '560429384',
        customParams
      };
    }
    // UK and ROW
    return {
      delDomain: 'guardian-d.openx.net',
      unit: '540279541',
      customParams
    };
  }
});
var getOzonePlacementId = sizes => {
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsa)()) {
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.getBreakpointKey)() === 'D') {
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsBillboard)(sizes)) {
        return '3500010912';
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMpu)(sizes)) {
        return '3500010911';
      }
    }
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.getBreakpointKey)() === 'M') {
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMobileSticky)(sizes)) {
        return '3500014217';
      }
    }
    return '1420436308';
  }
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMobileSticky)(sizes)) {
      return '1500000260';
    }
  }
  return '0420420500';
};
var ozoneBidder = pageTargeting => ({
  name: 'ozone',
  switchName: 'prebidOzone',
  bidParams: (_slotId, sizes) => {
    var advert = _dfp_dfp_env__WEBPACK_IMPORTED_MODULE_2__.dfpEnv.adverts.get(_slotId);
    var testgroup = advert !== null && advert !== void 0 && advert.testgroup ? {
      testgroup: advert.testgroup
    } : {};
    return {
      publisherId: 'OZONEGMG0001',
      siteId: '4204204209',
      placementId: getOzonePlacementId(sizes),
      customData: [{
        settings: {},
        targeting: _objectSpread(_objectSpread({}, testgroup), (0,_page_targeting__WEBPACK_IMPORTED_MODULE_3__.buildAppNexusTargetingObject)(pageTargeting))
      }],
      ozoneData: {} // TODO: confirm if we need to send any
    };
  }
});
var getPubmaticPublisherId = () => {
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
    return '157206';
  }
  if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
    return '157203';
  }
  return '157207';
};
var getKargoPlacementId = sizes => {
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.getBreakpointKey)() === 'D') {
    // top-above-nav on desktop, fronts-banners in the future
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsLeaderboardOrBillboard)(sizes)) {
      return '_yflg9S7c2x';
    }
    // right hand slots on desktop, aka right, inline2+ or mostpop
    if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMpu)(sizes) && (0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsDmpu)(sizes)) {
      return '_zOpeEAyfiz';
    }
    // other MPUs on desktop (inline1)
    return '_qDBbBXYtzA';
  }
  // mobile-sticky on mobile
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsMobileSticky)(sizes)) {
    return '_odszPLn2hK';
  }
  // MPUs on mobile aka top-above-nav, inline on mobile and tablet
  return '_y9LINEsbfh';
};
var getPubmaticPlacementId = (slotId, slotSizes) => {
  if (slotId === 'dfp-ad--inline2' && slotSizes.find(size => size.width === 371 && size.height === 660)) {
    return (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsa)() ? 'seenthis_guardian_mweb_us' : 'seenthis_guardian_371x660_mweb';
  }
  return undefined;
};
var pubmaticBidder = slotSizes => {
  var defaultParams = {
    name: 'pubmatic',
    switchName: 'prebidPubmatic',
    bidParams: slotId => ({
      publisherId: getPubmaticPublisherId(),
      adSlot: (0,_utils__WEBPACK_IMPORTED_MODULE_5__.stripDfpAdPrefixFrom)(slotId),
      placementId: getPubmaticPlacementId(slotId, slotSizes)
    })
  };
  // The only prebid compatible size for fronts-banner-ads and the merchandising-high is the billboard (970x250)
  // This check is to distinguish from the top-above-nav which, includes a leaderboard
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsBillboardNotLeaderboard)(slotSizes)) {
    return _objectSpread(_objectSpread({}, defaultParams), {}, {
      bidParams: slotId => _objectSpread(_objectSpread({}, defaultParams.bidParams(slotId)), {}, {
        placementId: 'theguardian_970x250_only'
      })
    });
  }
  return defaultParams;
};
var trustXBidder = {
  name: 'trustx',
  switchName: 'prebidTrustx',
  bidParams: slotId => ({
    uid: getTrustXAdUnitId(slotId, isDesktopAndArticle)
  })
};
var tripleLiftBidder = {
  name: 'triplelift',
  switchName: 'prebidTriplelift',
  bidParams: (slotId, sizes) => ({
    inventoryCode: getTripleLiftInventoryCode(slotId, sizes),
    tagid: getTripleLiftInventoryCode(slotId, sizes)
  })
};
var xaxisBidder = {
  name: 'xhb',
  switchName: 'prebidXaxis',
  bidParams: (slotId, sizes) => ({
    placementId: getXaxisPlacementId(sizes)
  })
};
var criteoBidder = slotSizes => {
  var defaultParams = {
    name: 'criteo',
    switchName: 'prebidCriteo'
  };
  // The only prebid compatible size for fronts-banner-ads and the merchandising-high is the billboard (970x250)
  // This check is to distinguish from the top-above-nav slot, which includes a leaderboard
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_5__.containsBillboardNotLeaderboard)(slotSizes)) {
    return _objectSpread(_objectSpread({}, defaultParams), {}, {
      bidParams: () => ({
        zoneId: 1759354
      })
    });
  }
  return _objectSpread(_objectSpread({}, defaultParams), {}, {
    bidParams: () => ({
      networkId: 337
    })
  });
};
var kargoBidder = {
  name: 'kargo',
  switchName: 'prebidKargo',
  bidParams: (_slotId, sizes) => ({
    placementId: getKargoPlacementId(sizes)
  })
};
var magniteBidder = {
  //Rubicon is the old name for Magnite but it is still used for the integration
  name: 'rubicon',
  switchName: 'prebidMagnite',
  bidParams: (slotId, sizes) => ({
    accountId: 26644,
    siteId: (0,_magnite__WEBPACK_IMPORTED_MODULE_7__.getMagniteSiteId)(),
    zoneId: (0,_magnite__WEBPACK_IMPORTED_MODULE_7__.getMagniteZoneId)(slotId, sizes),
    keywords: window.guardian.config.page.keywords ? window.guardian.config.page.keywords.split(',') : []
  })
};
var theTradeDeskBidder = gpid => ({
  name: 'ttd',
  switchName: 'prebidTheTradeDesk',
  bidParams: () => ({
    supplySourceId: 'theguardian',
    publisherId: '1',
    placementId: gpid
  })
});
// There's an IX bidder for every size that the slot can take
var indexExchangeBidders = slotSizes => {
  var siteId = getIndexSiteId(slotSizes);
  return slotSizes.map(size => ({
    name: 'ix',
    switchName: 'prebidIndexExchange',
    bidParams: () => ({
      siteId,
      size
    })
  }));
};
var biddersBeingTested = allBidders => allBidders.filter(bidder => (0,_url__WEBPACK_IMPORTED_MODULE_4__.pbTestNameMap)()[bidder.name]);
var currentBidders = (slotSizes, pageTargeting, gpid, consentState) => {
  var shouldInclude = (0,_utils__WEBPACK_IMPORTED_MODULE_5__.shouldIncludeBidder)(consentState);
  var ixBidders = shouldInclude('ix') ? indexExchangeBidders(slotSizes) : [];
  var biddersToCheck = [[shouldInclude('criteo'), criteoBidder(slotSizes)], [shouldInclude('trustx'), trustXBidder], [shouldInclude('triplelift'), tripleLiftBidder], [shouldInclude('and'), appNexusBidder(pageTargeting)], [shouldInclude('xhb'), xaxisBidder], [shouldInclude('pubmatic'), pubmaticBidder(slotSizes)], [shouldInclude('ozone'), ozoneBidder(pageTargeting)], [shouldInclude('oxd'), openxBidder(pageTargeting)], [shouldInclude('kargo'), kargoBidder], [shouldInclude('rubicon'), magniteBidder], [shouldInclude('ttd'), theTradeDeskBidder(gpid)]];
  var otherBidders = biddersToCheck.filter(_ref => {
    var [shouldInclude] = _ref;
    return inPbTestOr(shouldInclude);
  }).map(_ref2 => {
    var [, bidder] = _ref2;
    return bidder;
  });
  var allBidders = [...ixBidders, ...otherBidders];
  return isPbTestOn() ? biddersBeingTested(allBidders) : allBidders;
};
var bids = (slotId, slotSizes, pageTargeting, gpid, consentState) => currentBidders(slotSizes, pageTargeting, gpid, consentState).map(bidder => ({
  bidder: bidder.name,
  params: bidder.bidParams(slotId, slotSizes)
}));
var _ = {
  getIndexSiteIdFromConfig,
  getXaxisPlacementId,
  getTrustXAdUnitId,
  indexExchangeBidders,
  getOzonePlacementId
};

/***/ }),

/***/ "./src/lib/header-bidding/prebid/magnite.ts":
/*!**************************************************!*\
  !*** ./src/lib/header-bidding/prebid/magnite.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getMagniteSiteId: () => (/* binding */ getMagniteSiteId),
/* harmony export */   getMagniteZoneId: () => (/* binding */ getMagniteZoneId)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../utils */ "./src/lib/header-bidding/utils.ts");


var getMagniteZoneId = (slotId, sizes) => {
  switch ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.getBreakpointKey)()) {
    case 'D':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsMpuOrDmpu)(sizes) || (0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsWS)(sizes)) {
        if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUk)()) {
          return 3426780;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
          return 3426822;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
          return 3471422;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
          return 3471452;
        }
      }
      // top-above-nav on desktop
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsLeaderboardOrBillboard)(sizes) && slotId === 'dfp-ad--top-above-nav') {
        if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUk)()) {
          return 3426786;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
          return 3426828;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
          return 3471428;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
          return 3471458;
        }
      }
      // Fronts-banners on desktop
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsBillboard)(sizes) && slotId.includes('fronts-banner')) {
        if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUk)()) {
          return 3426790;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
          return 3426834;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
          return 3471434;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
          return 3471462;
        }
      }
      break;
    case 'M':
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsMpu)(sizes) || (0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsPortraitInterstitial)(sizes)) {
        if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUk)()) {
          return 3426778;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
          return 3426836;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
          return 3471436;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
          return 3471464;
        }
      }
      if ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.containsMobileSticky)(sizes)) {
        if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
          return 3477560;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
          return 3471440;
        } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
          return 3471468;
        }
      }
      break;
  }
  return -1;
};
var getMagniteSiteId = () => {
  switch ((0,_utils__WEBPACK_IMPORTED_MODULE_1__.getBreakpointKey)()) {
    case 'D':
      if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUk)()) {
        return 549358;
      } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
        return 549496;
      } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
        return 554244;
      } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
        return 554256;
      }
      break;
    case 'M':
      if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUk)()) {
        return 549374;
      } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInRow)()) {
        return 549498;
      } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsOrCa)()) {
        return 554248;
      } else if ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)()) {
        return 554258;
      }
      break;
  }
  return -1;
};

/***/ }),

/***/ "./src/lib/header-bidding/prebid/prebid.ts":
/*!*************************************************!*\
  !*** ./src/lib/header-bidding/prebid/prebid.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   prebid: () => (/* binding */ prebid)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_commercial_core_constants_prebid_timeout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/constants/prebid-timeout */ "../core/src/constants/prebid-timeout.ts");
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_commercial_core_permutive__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/commercial-core/permutive */ "../core/src/permutive.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/flatten.js");
/* harmony import */ var _experiments_ab__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../experiments/ab */ "./src/experiments/ab.ts");
/* harmony import */ var _vendor_pubmatic__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../__vendor/pubmatic */ "./src/lib/__vendor/pubmatic.js");
/* harmony import */ var _dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _identity_api__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../identity/api */ "./src/lib/identity/api.ts");
/* harmony import */ var _page_targeting__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../page-targeting */ "./src/lib/page-targeting.ts");
/* harmony import */ var _slot_config__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../slot-config */ "./src/lib/header-bidding/slot-config.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../utils */ "./src/lib/header-bidding/utils.ts");
/* harmony import */ var _bid_config__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./bid-config */ "./src/lib/header-bidding/prebid/bid-config.ts");
/* harmony import */ var _price_config__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./price-config */ "./src/lib/header-bidding/prebid/price-config.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }















class PrebidAdUnit {
  constructor(advert, slot, pageTargeting, consentState) {
    _defineProperty(this, "code", void 0);
    _defineProperty(this, "bids", void 0);
    _defineProperty(this, "mediaTypes", void 0);
    _defineProperty(this, "gpid", void 0);
    _defineProperty(this, "ortb2Imp", void 0);
    this.code = advert.id;
    this.mediaTypes = {
      banner: {
        sizes: slot.sizes
      }
    };
    this.gpid = this.generateGpid(advert, slot);
    this.ortb2Imp = {
      ext: {
        gpid: this.gpid,
        data: {
          pbadslot: this.gpid
        }
      }
    };
    this.bids = (0,_bid_config__WEBPACK_IMPORTED_MODULE_15__.bids)(advert.id, slot.sizes, pageTargeting, this.gpid, consentState);
    advert.headerBiddingSizes = slot.sizes;
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_6__.log)('commercial', "PrebidAdUnit ".concat(this.code), this.bids);
  }
  isEmpty() {
    return this.code == null;
  }
  generateGpid(advert, slot) {
    var sectionName = window.guardian.config.page.section;
    var contentType = window.guardian.config.page.contentType;
    var slotName = slot.key;
    return "/59666047/gu/".concat(sectionName, "/").concat(contentType, "/").concat(slotName);
  }
}
var shouldEnableAnalytics = () => {
  var _window$guardian$conf;
  if (!window.guardian.config.switches.prebidAnalytics) {
    return false;
  }
  var analyticsSampleRate = 10 / 100;
  var isInSample = Math.random() < analyticsSampleRate;
  var isInServerSideTest = Object.keys((_window$guardian$conf = window.guardian.config.tests) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : {}).length > 0;
  var isInClientSideTest = Object.keys((0,_experiments_ab__WEBPACK_IMPORTED_MODULE_8__.getParticipations)()).length > 0;
  var hasQueryParam = window.location.search.includes('pbjs-analytics=true');
  return isInServerSideTest || isInClientSideTest || isInSample || hasQueryParam;
};
/**
 * Prebid supports an additional timeout buffer to account for noisiness in
 * timing JavaScript on the page. This value is passed to the Prebid config
 * and is adjustable via this constant
 */
var timeoutBuffer = 400;
/**
 * The amount of time reserved for the auction
 */
var bidderTimeout = _guardian_commercial_core_constants_prebid_timeout__WEBPACK_IMPORTED_MODULE_1__.PREBID_TIMEOUT;
var requestQueue = Promise.resolve();
var initialised = false;
var initialise = (window, consentState) => {
  var _window$guardian$opha;
  if (!window.pbjs) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_6__.log)('commercial', 'window.pbjs not found on window');
    return; // We couldn’t initialise
  }
  initialised = true;
  var userIds = [{
    name: 'sharedId',
    storage: {
      type: 'cookie',
      name: '_pubcid',
      expires: 365
    }
  }];
  if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_4__.getConsentFor)('id5', consentState)) {
    userIds.push({
      name: 'id5Id',
      params: {
        partner: 182
      },
      storage: {
        type: 'html5',
        name: 'id5id',
        expires: 90,
        refreshInSeconds: 7200
      }
    });
  }
  var userSync = (0,_utils__WEBPACK_IMPORTED_MODULE_14__.isSwitchedOn)('prebidUserSync') ? {
    syncsPerBidder: 0,
    // allow all syncs
    filterSettings: {
      all: {
        bidders: '*',
        // allow all bidders to sync by iframe or image beacons
        filter: 'include'
      }
    },
    userIds
  } : {
    syncEnabled: false
  };
  var consentManagement = () => {
    switch (consentState.framework) {
      /** @see https://docs.prebid.org/dev-docs/modules/consentManagementUsp.html */
      case 'aus':
        return {
          usp: {
            cmpApi: 'iab',
            timeout: 1500
          }
        };
      /** @see https://docs.prebid.org/dev-docs/modules/consentManagementGpp.html */
      case 'usnat':
        return {
          gpp: {
            cmpApi: 'iab',
            timeout: 1500
          }
        };
      /** @see https://docs.prebid.org/dev-docs/modules/consentManagementTcf.html */
      case 'tcfv2':
      default:
        return {
          gdpr: {
            cmpApi: 'iab',
            timeout: 200,
            defaultGdprScope: true
          }
        };
    }
  };
  /** Helper function to decide if a bidder should be included.
   * It is a curried function prepared with the consent state
   * at the time of initialisation to avoid unnecessary repetition
   * of consent state throughout */
  var shouldInclude = (0,_utils__WEBPACK_IMPORTED_MODULE_14__.shouldIncludeBidder)(consentState);
  var pbjsConfig = Object.assign({}, {
    bidderTimeout,
    timeoutBuffer,
    priceGranularity: _price_config__WEBPACK_IMPORTED_MODULE_16__.priceGranularity,
    userSync
  });
  var keywordsArray = window.guardian.config.page.keywords.split(',');
  pbjsConfig.ortb2 = {
    site: {
      ext: {
        data: {
          keywords: keywordsArray
        }
      }
    }
  };
  window.pbjs.bidderSettings = {};
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_14__.isSwitchedOn)('consentManagement')) {
    pbjsConfig.consentManagement = consentManagement();
  }
  if ((0,_utils__WEBPACK_IMPORTED_MODULE_14__.shouldIncludePermutive)(consentState)) {
    var includedAcBidders = ['and', 'ix', 'ozone', 'pubmatic', 'trustx'].filter(shouldInclude)
    // "and" is the alias for the custom Guardian "appnexus" direct bidder
    .map(bidder => bidder === 'and' ? 'appnexus' : bidder);
    pbjsConfig.realTimeData = {
      dataProviders: [{
        name: 'permutive',
        params: _objectSpread({
          acBidders: includedAcBidders
        }, includedAcBidders.includes('pubmatic') ? {
          overwrites: {
            pubmatic: _vendor_pubmatic__WEBPACK_IMPORTED_MODULE_9__.pubmatic
          }
        } : {})
      }]
    };
  }
  if (shouldInclude('criteo')) {
    window.pbjs.bidderSettings.criteo = {
      storageAllowed: true,
      // Use a custom price granularity, which is based upon the size of the slot being auctioned
      adserverTargeting: [{
        key: 'hb_pb',
        val(_ref) {
          var {
            width,
            height,
            cpm,
            pbCg
          } = _ref;
          return (0,_price_config__WEBPACK_IMPORTED_MODULE_16__.overridePriceBucket)('criteo', width, height, cpm, pbCg);
        }
      }]
    };
  }
  if (shouldInclude('ozone')) {
    // Use a custom price granularity, which is based upon the size of the slot being auctioned
    window.pbjs.bidderSettings.ozone = {
      adserverTargeting: [{
        key: 'hb_pb',
        val: _ref2 => {
          var {
            width,
            height,
            cpm,
            pbCg
          } = _ref2;
          return (0,_price_config__WEBPACK_IMPORTED_MODULE_16__.overridePriceBucket)('ozone', width, height, cpm, pbCg);
        }
      }]
    };
  }
  if (shouldInclude('ix')) {
    // Use a custom price granularity, which is based upon the size of the slot being auctioned
    window.pbjs.bidderSettings.ix = {
      adserverTargeting: [{
        key: 'hb_pb',
        val(_ref3) {
          var {
            width,
            height,
            cpm,
            pbCg
          } = _ref3;
          return (0,_price_config__WEBPACK_IMPORTED_MODULE_16__.overridePriceBucket)('ix', width, height, cpm, pbCg);
        }
      }]
    };
  }
  if (shouldEnableAnalytics() && (_window$guardian$opha = window.guardian.ophan) !== null && _window$guardian$opha !== void 0 && _window$guardian$opha.pageViewId) {
    window.pbjs.enableAnalytics([{
      provider: 'gu',
      options: {
        url: window.guardian.config.page.isDev || window.location.hostname.includes('localhost') ? "//performance-events.code.dev-guardianapis.com/header-bidding" : "//performance-events.guardianapis.com/header-bidding",
        pv: window.guardian.ophan.pageViewId
      }
    }]);
  }
  if (shouldInclude('xhb')) {
    window.pbjs.bidderSettings.xhb = {
      adserverTargeting: [{
        key: 'hb_buyer_id',
        val(bidResponse) {
          var _bidResponse$appnexus, _bidResponse$appnexus2;
          // TODO: should we return null or an empty string?
          return (_bidResponse$appnexus = (_bidResponse$appnexus2 = bidResponse.appnexus) === null || _bidResponse$appnexus2 === void 0 ? void 0 : _bidResponse$appnexus2.buyerMemberId) !== null && _bidResponse$appnexus !== void 0 ? _bidResponse$appnexus : '';
        }
      }],
      bidCpmAdjustment: bidCpm => {
        return bidCpm * 1.05;
      }
    };
  }
  if (shouldInclude('kargo')) {
    window.pbjs.bidderSettings.kargo = {
      storageAllowed: true
    };
  }
  if (shouldInclude('rubicon')) {
    window.pbjs.bidderSettings.magnite = {
      storageAllowed: true
    };
    window.pbjs.setBidderConfig({
      bidders: ['rubicon'],
      config: {
        ortb2: {
          user: {
            ext: {
              data: {
                permutive: (0,_guardian_commercial_core_permutive__WEBPACK_IMPORTED_MODULE_3__.getPermutiveSegments)()
              }
            }
          }
        }
      }
    });
  }
  window.pbjs.setConfig(pbjsConfig);
  // Adjust slot size when prebid ad loads
  window.pbjs.onEvent('bidWon', data => {
    var {
      width,
      height,
      adUnitCode
    } = data;
    if (!width || !height || !adUnitCode) {
      return;
    }
    var size = (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(width, height); // eg. [300, 250]
    var advert = (0,_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_10__.getAdvertById)(adUnitCode);
    if (!advert) {
      return;
    }
    advert.size = size;
    /**
     * when hasPrebidSize is true we use size
     * set here when adjusting the slot size.
     * */
    advert.hasPrebidSize = true;
  });
};
var bidsBackHandler = (adUnits, eventTimer) => new Promise(resolve => {
  var _window$pbjs;
  (_window$pbjs = window.pbjs) === null || _window$pbjs === void 0 || _window$pbjs.setTargetingForGPTAsync(adUnits.map(u => u.code).filter(_guardian_libs__WEBPACK_IMPORTED_MODULE_5__.isString));
  resolve();
  adUnits.forEach(adUnit => {
    if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_5__.isString)(adUnit.code)) {
      eventTimer.mark('prebidEnd', (0,_utils__WEBPACK_IMPORTED_MODULE_14__.stripDfpAdPrefixFrom)(adUnit.code));
    }
  });
});
// slotFlatMap allows you to dynamically interfere with the PrebidSlot definition
// for this given request for bids.
var requestBids = /*#__PURE__*/function () {
  var _ref4 = _asyncToGenerator(function* (adverts, slotFlatMap) {
    if (!initialised) {
      return requestQueue;
    }
    if (!window.guardian.config.switches.prebidHeaderBidding) {
      return requestQueue;
    }
    var adUnits = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_4__.onConsent)().then(/*#__PURE__*/function () {
      var _ref5 = _asyncToGenerator(function* (consentState) {
        // calculate this once before mapping over
        var isSignedIn = yield (0,_identity_api__WEBPACK_IMPORTED_MODULE_11__.isUserLoggedIn)();
        var pageTargeting = (0,_page_targeting__WEBPACK_IMPORTED_MODULE_12__.getPageTargeting)(consentState, isSignedIn);
        return (0,lodash_es__WEBPACK_IMPORTED_MODULE_7__["default"])(adverts.map(advert => (0,_slot_config__WEBPACK_IMPORTED_MODULE_13__.getHeaderBiddingAdSlots)(advert, slotFlatMap).map(slot => new PrebidAdUnit(advert, slot, pageTargeting, consentState)).filter(adUnit => !adUnit.isEmpty())));
      });
      return function (_x3) {
        return _ref5.apply(this, arguments);
      };
    }()).catch(e => {
      // silently fail
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_6__.log)('commercial', 'Failed to execute prebid onConsent', e);
      return [];
    });
    var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_2__.EventTimer.get();
    requestQueue = requestQueue.then(() => new Promise(resolve => {
      var _window$pbjs2;
      adUnits.forEach(adUnit => {
        if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_5__.isString)(adUnit.code)) {
          eventTimer.mark('prebidStart', (0,_utils__WEBPACK_IMPORTED_MODULE_14__.stripDfpAdPrefixFrom)(adUnit.code));
        }
      });
      (_window$pbjs2 = window.pbjs) === null || _window$pbjs2 === void 0 || _window$pbjs2.que.push(() => {
        var _window$pbjs3;
        (_window$pbjs3 = window.pbjs) === null || _window$pbjs3 === void 0 || _window$pbjs3.requestBids({
          adUnits,
          bidsBackHandler: () => void bidsBackHandler(adUnits, eventTimer).then(resolve)
        });
      });
    }));
    return requestQueue;
  });
  return function requestBids(_x, _x2) {
    return _ref4.apply(this, arguments);
  };
}();
var prebid = {
  initialise,
  requestBids
};

/***/ }),

/***/ "./src/lib/header-bidding/prebid/price-config.ts":
/*!*******************************************************!*\
  !*** ./src/lib/header-bidding/prebid/price-config.ts ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   criteoPriceGranularity: () => (/* binding */ criteoPriceGranularity),
/* harmony export */   getPriceGranularityForSize: () => (/* binding */ getPriceGranularityForSize),
/* harmony export */   indexPriceGranularity: () => (/* binding */ indexPriceGranularity),
/* harmony export */   overridePriceBucket: () => (/* binding */ overridePriceBucket),
/* harmony export */   ozonePriceGranularity: () => (/* binding */ ozonePriceGranularity),
/* harmony export */   priceGranularity: () => (/* binding */ priceGranularity)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var prebid_js_src_cpmBucketManager__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prebid.js/src/cpmBucketManager */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/cpmBucketManager.js");



var priceGranularity = {
  buckets: [{
    max: 10,
    increment: 0.01
  }, {
    max: 15,
    increment: 0.1
  }, {
    max: 100,
    increment: 1
  }]
};
var criteoPriceGranularity = {
  buckets: [{
    max: 12,
    increment: 0.01
  }, {
    max: 20,
    increment: 0.05
  }, {
    max: 500,
    increment: 1
  }]
};
var ozonePriceGranularity = (width, height) => {
  var sizeString = [width, height].join(',');
  if (sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage.toString()) {
    return {
      buckets: [{
        max: 10,
        increment: 0.01
      }, {
        max: 15,
        increment: 0.1
      }, {
        max: 50,
        increment: 1
      }]
    };
  }
  if (sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.leaderboard.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamMobile.toString()) {
    return {
      buckets: [{
        max: 12,
        increment: 0.01
      }, {
        max: 20,
        increment: 0.1
      }, {
        max: 50,
        increment: 1
      }]
    };
  }
  return undefined;
};
var indexPriceGranularity = (width, height) => {
  var sizeString = [width, height].join(',');
  if (sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage.toString()) {
    return {
      buckets: [{
        max: 10,
        increment: 0.01
      }, {
        max: 15,
        increment: 0.05
      }, {
        max: 50,
        increment: 1
      }]
    };
  }
  if (sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.leaderboard.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard.toString() || sizeString === _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.toString()) {
    return {
      buckets: [{
        max: 12,
        increment: 0.01
      }, {
        max: 20,
        increment: 0.05
      }, {
        max: 50,
        increment: 1
      }]
    };
  }
  return undefined;
};
var getPriceGranularityForSize = (bidder, width, height) => {
  if (bidder === 'ozone') {
    return ozonePriceGranularity(width, height);
  }
  return indexPriceGranularity(width, height);
};
var overridePriceBucket = (bidder, width, height, cpm, defaultPriceBucket) => {
  var priceGranularity = bidder === 'criteo' ? criteoPriceGranularity : getPriceGranularityForSize(bidder, width, height);
  if (!priceGranularity) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "".concat(bidder, " price granularity for size (").concat(width, "x").concat(height, ") not found"));
    return defaultPriceBucket;
  }
  var priceBucket = (0,prebid_js_src_cpmBucketManager__WEBPACK_IMPORTED_MODULE_2__.getPriceBucketString)(cpm, priceGranularity).custom;
  if (priceBucket !== defaultPriceBucket) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "".concat(bidder, " price bucket for size (").concat(width, "x").concat(height, ") with cpm ").concat(cpm, " overriden from ").concat(defaultPriceBucket, " to ").concat(priceBucket));
  } else {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "".concat(bidder, " price bucket for size (").concat(width, "x").concat(height, ") with cpm ").concat(cpm, " not overriden (").concat(priceBucket, ")"));
  }
  return priceBucket;
};

/***/ }),

/***/ "./src/lib/header-bidding/slot-config.ts":
/*!***********************************************!*\
  !*** ./src/lib/header-bidding/slot-config.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getHeaderBiddingAdSlots: () => (/* binding */ getHeaderBiddingAdSlots)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./utils */ "./src/lib/header-bidding/utils.ts");



var getHbBreakpoint = () => {
  switch ((0,_utils__WEBPACK_IMPORTED_MODULE_2__.getBreakpointKey)()) {
    case 'M':
      return 'mobile';
    case 'T':
      return 'tablet';
    default:
      return 'desktop';
  }
};
/**
 * Remove any header bidding sizes that do not appear in the set
 * of slot sizes for the current breakpoint
 *
 * NOTE we currently only perform this filtering on `inline` slots
 * (this does not include inline1)
 */
var filterBySizeMapping = function () {
  var slotSizes = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : [];
  return _ref => {
    var {
      key,
      sizes
    } = _ref;
    // For now, only apply filtering to inline header bidding slots
    // In the future we may want to expand this to all slots
    if (key !== 'inline') {
      return {
        key,
        sizes
      };
    }
    var filteredSizes = sizes.filter(_ref2 => {
      var [hbWidth, hbHeight] = _ref2;
      return slotSizes.some(adSize => hbWidth === adSize.width && hbHeight === adSize.height);
    });
    return {
      key,
      sizes: filteredSizes
    };
  };
};
var getHeaderBiddingKey = (slotName, name) => {
  if (slotName.some(key => key === name)) {
    return name;
  }
  if (name !== null && name !== void 0 && name.includes('inline')) {
    return 'inline';
  }
  if (name !== null && name !== void 0 && name.includes('fronts-banner')) {
    return 'fronts-banner';
  }
  return undefined;
};
var getSlotNamesFromSizeMapping = sizeMapping => Object.keys(sizeMapping).filter(key => key !== 'inline');
var filterByAdvert = (ad, breakpoint, sizeMapping) => {
  var _sizeMapping$key;
  var slotNames = getSlotNamesFromSizeMapping(sizeMapping);
  var key = getHeaderBiddingKey(slotNames, ad.node.dataset.name);
  if (!key) {
    return [];
  }
  var sizes = (_sizeMapping$key = sizeMapping[key]) === null || _sizeMapping$key === void 0 ? void 0 : _sizeMapping$key[breakpoint];
  if (!sizes || sizes.length < 1) {
    return [];
  }
  return [{
    key,
    sizes
  }];
};
var getSlots = () => {
  var {
    contentType,
    hasShowcaseMainElement
  } = window.guardian.config.page;
  var isArticle = contentType === 'Article';
  var hasExtendedMostPop = isArticle && window.guardian.config.switches.extendedMostPopular;
  return {
    right: {
      desktop: hasShowcaseMainElement ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      tablet: hasShowcaseMainElement ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      mobile: hasShowcaseMainElement ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu]
    },
    'top-above-nav': {
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.leaderboard],
      tablet: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.leaderboard],
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu]
    },
    'fronts-banner': {
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard]
    },
    inline: {
      desktop: isArticle ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      tablet: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu]
    },
    inline1: {
      desktop: isArticle ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      tablet: isArticle ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      mobile: isArticle ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamMobile, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.portraitInterstitial] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu]
    },
    inline2: {
      desktop: isArticle ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      tablet: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      mobile: isArticle ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.portraitInterstitial, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.pubmaticInterscroller] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu]
    },
    mostpop: {
      desktop: hasExtendedMostPop ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      tablet: hasExtendedMostPop ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.leaderboard] : [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu]
    },
    comments: {
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage]
    },
    'comments-expanded': {
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage]
    },
    banner: {
      // Banner slots appear on interactives, like on
      // https://www.theguardian.com/us-news/ng-interactive/2018/nov/06/midterm-elections-2018-live-results-latest-winners-and-seats
      desktop: [(0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(88, 70), _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.leaderboard, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.cascade, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(900, 250), _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard]
    },
    'mobile-sticky': {
      mobile: (0,_utils__WEBPACK_IMPORTED_MODULE_2__.shouldIncludeMobileSticky)() ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mobilesticky, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(300, 50)] : []
    },
    'crossword-banner-mobile': {
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mobilesticky]
    },
    'football-right': {
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.empty, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage]
    },
    merchandising: {
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard]
    },
    'merchandising-high': {
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu],
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard]
    },
    'article-end': {
      mobile: (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUk)() ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [],
      tablet: (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUk)() ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : [],
      desktop: (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUk)() ? [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu] : []
    }
  };
};
var getHeaderBiddingAdSlots = function (ad) {
  var slotFlatMap = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : s => [s];
  var breakpoint = getHbBreakpoint();
  var headerBiddingSlots = filterByAdvert(ad, breakpoint, getSlots());
  return headerBiddingSlots.map(filterBySizeMapping(ad.sizes[breakpoint])).map(slotFlatMap).reduce((acc, elt) => acc.concat(elt), []); // the "flat" in "flatMap"
};

/***/ }),

/***/ "./src/lib/header-bidding/utils.ts":
/*!*****************************************!*\
  !*** ./src/lib/header-bidding/utils.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   containsBillboard: () => (/* binding */ containsBillboard),
/* harmony export */   containsBillboardNotLeaderboard: () => (/* binding */ containsBillboardNotLeaderboard),
/* harmony export */   containsDmpu: () => (/* binding */ containsDmpu),
/* harmony export */   containsLeaderboard: () => (/* binding */ containsLeaderboard),
/* harmony export */   containsLeaderboardOrBillboard: () => (/* binding */ containsLeaderboardOrBillboard),
/* harmony export */   containsMobileSticky: () => (/* binding */ containsMobileSticky),
/* harmony export */   containsMpu: () => (/* binding */ containsMpu),
/* harmony export */   containsMpuOrDmpu: () => (/* binding */ containsMpuOrDmpu),
/* harmony export */   containsPortraitInterstitial: () => (/* binding */ containsPortraitInterstitial),
/* harmony export */   containsWS: () => (/* binding */ containsWS),
/* harmony export */   getBreakpointKey: () => (/* binding */ getBreakpointKey),
/* harmony export */   getLargestSize: () => (/* binding */ getLargestSize),
/* harmony export */   getRandomIntInclusive: () => (/* binding */ getRandomIntInclusive),
/* harmony export */   isSwitchedOn: () => (/* binding */ isSwitchedOn),
/* harmony export */   removeFalsyValues: () => (/* binding */ removeFalsyValues),
/* harmony export */   shouldIncludeBidder: () => (/* binding */ shouldIncludeBidder),
/* harmony export */   shouldIncludeMobileSticky: () => (/* binding */ shouldIncludeMobileSticky),
/* harmony export */   shouldIncludeOnlyA9: () => (/* binding */ shouldIncludeOnlyA9),
/* harmony export */   shouldIncludePermutive: () => (/* binding */ shouldIncludePermutive),
/* harmony export */   stripDfpAdPrefixFrom: () => (/* binding */ stripDfpAdPrefixFrom),
/* harmony export */   stripMobileSuffix: () => (/* binding */ stripMobileSuffix),
/* harmony export */   stripTrailingNumbersAbove1: () => (/* binding */ stripTrailingNumbersAbove1)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _url__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../url */ "./src/lib/url.ts");






var SUFFIX_REGEXPS = {};
var stripSuffix = (s, suffix) => {
  var _SUFFIX_REGEXPS$suffi;
  var re = (_SUFFIX_REGEXPS$suffi = SUFFIX_REGEXPS[suffix]) !== null && _SUFFIX_REGEXPS$suffi !== void 0 ? _SUFFIX_REGEXPS$suffi : SUFFIX_REGEXPS[suffix] = new RegExp("".concat(suffix, "$"));
  return s.replace(re, '');
};
var PREFIX_REGEXPS = {};
var stripPrefix = (s, prefix) => {
  var _PREFIX_REGEXPS$prefi;
  var re = (_PREFIX_REGEXPS$prefi = PREFIX_REGEXPS[prefix]) !== null && _PREFIX_REGEXPS$prefi !== void 0 ? _PREFIX_REGEXPS$prefi : PREFIX_REGEXPS[prefix] = new RegExp("^".concat(prefix));
  return s.replace(re, '');
};
var contains = (sizes, size) => Boolean(sizes.find(s => s[0] === size[0] && s[1] === size[1]));
var isValidPageForMobileSticky = () => {
  var {
    contentType,
    pageId
  } = window.guardian.config.page;
  return contentType === 'Article' || contentType === 'Interactive' || pageId.startsWith('football/');
};
/**
 * Cleans an object for targetting. Removes empty strings and other falsy values.
 * @param o object with falsy values
 * @returns {Record<string, string | string[]>} object with only non-empty strings, or arrays of non-empty strings.
 */
var removeFalsyValues = o => Object.entries(o).reduce((prev, curr) => {
  var [key, val] = curr;
  if (!val) return prev;
  if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.isString)(val)) {
    prev[key] = val;
  }
  if (Array.isArray(val) && val.length > 0 && val.some(Boolean) && val.every(_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.isString)) {
    prev[key] = val.filter(Boolean);
  }
  return prev;
}, {});
var stripDfpAdPrefixFrom = s => stripPrefix(s, 'dfp-ad--');
var containsMpu = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(300, 250));
var containsDmpu = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(300, 600));
var containsLeaderboard = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(728, 90));
var containsBillboard = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(970, 250));
var containsBillboardNotLeaderboard = sizes => containsBillboard(sizes) && !containsLeaderboard(sizes);
var containsMpuOrDmpu = sizes => containsMpu(sizes) || containsDmpu(sizes);
var containsMobileSticky = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(320, 50));
var containsLeaderboardOrBillboard = sizes => containsLeaderboard(sizes) || containsBillboard(sizes);
var containsPortraitInterstitial = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(320, 480));
var getLargestSize = sizes => {
  var reducer = (previous, current) => {
    if (previous[0] >= current[0] && previous[1] >= current[1]) {
      return previous;
    }
    return current;
  };
  return sizes.length > 0 ? sizes.reduce(reducer) : null;
};
var getBreakpointKey = () => {
  switch ((0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_5__.getCurrentTweakpoint)()) {
    case 'mobile':
    case 'mobileMedium':
    case 'mobileLandscape':
      return 'M';
    case 'phablet':
    case 'tablet':
      return 'T';
    case 'desktop':
    case 'leftCol':
    case 'wide':
      return 'D';
    default:
      return 'M';
  }
};
var getRandomIntInclusive = (minimum, maximum) => {
  var min = Math.ceil(minimum);
  var max = Math.floor(maximum);
  return Math.floor(Math.random() * (max - min + 1)) + min;
};
var isSwitchedOn = switchName => {
  var _window$guardian$conf;
  return (_window$guardian$conf = window.guardian.config.switches[switchName]) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : false;
};
var shouldIncludeBidder = consentState => bidder => {
  switch (bidder) {
    case 'and':
      return isSwitchedOn('prebidAppnexus') && ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInAuOrNz)() || isSwitchedOn('prebidAppnexusUkRow') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('xandr', consentState) && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUsOrCa)() || !!(0,_url__WEBPACK_IMPORTED_MODULE_6__.pbTestNameMap)().and);
    case 'criteo':
      return isSwitchedOn('prebidCriteo') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('criteo', consentState);
    case 'ix':
      return isSwitchedOn('prebidIndexExchange') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('indexExchange', consentState);
    case 'kargo':
      return isSwitchedOn('prebidKargo') && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUsa)();
    case 'oxd':
      return isSwitchedOn('prebidOpenx') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('openX', consentState) && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUsOrCa)();
    case 'ozone':
      return isSwitchedOn('prebidOzone') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('ozone', consentState) && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInCanada)() && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInAuOrNz)();
    case 'pubmatic':
      return isSwitchedOn('prebidPubmatic') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('pubmatic', consentState);
    case 'rubicon':
      return isSwitchedOn('prebidMagnite') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('magnite', consentState);
    case 'triplelift':
      return isSwitchedOn('prebidTriplelift') && ((0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUsOrCa)() || (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInAuOrNz)());
    case 'trustx':
      return isSwitchedOn('prebidTrustx') && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUsOrCa)();
    case 'ttd':
      return isSwitchedOn('prebidTheTradeDesk') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('theTradeDesk', consentState);
    case 'xhb':
      return isSwitchedOn('prebidXaxis') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('xandr', consentState) && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUk)();
  }
};
var shouldIncludePermutive = consentState => isSwitchedOn('permutive') && /** this switch specifically controls whether or not the Permutive Audience Connector can run with Prebid */
isSwitchedOn('prebidPermutiveAudience') && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)('permutive', consentState);
var shouldIncludeMobileSticky = (0,lodash_es__WEBPACK_IMPORTED_MODULE_4__["default"])(() => window.location.hash.includes('#mobile-sticky') || (0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_5__.matchesBreakpoints)({
  min: 'mobile',
  max: 'mobileLandscape'
}) && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUk)() && isValidPageForMobileSticky() && !window.guardian.config.page.isHosted);
var stripMobileSuffix = s => stripSuffix(stripSuffix(s, '--mobile'), 'Mobile');
var stripTrailingNumbersAbove1 = s => stripSuffix(s, '([2-9]|\\d{2,})');
var containsWS = sizes => contains(sizes, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(160, 600));
var shouldIncludeOnlyA9 = window.location.hash.includes('#only-a9');

/***/ }),

/***/ "./src/lib/identity/api.ts":
/*!*********************************!*\
  !*** ./src/lib/identity/api.ts ***!
  \*********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getAuthStatus: () => (/* binding */ getAuthStatus),
/* harmony export */   getGoogleTagId: () => (/* binding */ getGoogleTagId),
/* harmony export */   isUserLoggedIn: () => (/* binding */ isUserLoggedIn)
/* harmony export */ });
/* harmony import */ var _guardian_identity_auth_frontend__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/identity-auth-frontend */ "../node_modules/.pnpm/@guardian+identity-auth-frontend@12.0.0_@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0__hy3woi5sfpbstbkj7mijybq7mu/node_modules/@guardian/identity-auth-frontend/dist/index.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }

var getAuthStatus = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var {
      isAuthenticated,
      accessToken,
      idToken
    } = yield (0,_guardian_identity_auth_frontend__WEBPACK_IMPORTED_MODULE_0__.getIdentityAuth)().isSignedInWithAuthState();
    if (isAuthenticated) {
      return {
        kind: 'SignedIn',
        accessToken,
        idToken
      };
    }
    return {
      kind: 'SignedOut'
    };
  });
  return function getAuthStatus() {
    return _ref.apply(this, arguments);
  };
}();
var isUserLoggedIn = () => (0,_guardian_identity_auth_frontend__WEBPACK_IMPORTED_MODULE_0__.getIdentityAuth)().isSignedIn();
/**
 * Get the user's Google Tag ID
 *
 * Returns the value from the ID token `google_tag_id` claim
 * @returns one of:
 * - string if the user signed in with Okta
 * - null if the user is signed out
 */
var getGoogleTagId = () => getAuthStatus().then(authStatus => authStatus.kind === 'SignedIn' ? authStatus.idToken.claims.google_tag_id : null);


/***/ }),

/***/ "./src/lib/messenger.ts":
/*!******************************!*\
  !*** ./src/lib/messenger.ts ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init),
/* harmony export */   register: () => (/* binding */ register),
/* harmony export */   registerPersistentListener: () => (/* binding */ registerPersistentListener),
/* harmony export */   unregister: () => (/* binding */ unregister)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_messenger_post_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/messenger/post-message */ "../core/src/messenger/post-message.ts");
/* harmony import */ var _error_report_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./error/report-error */ "./src/lib/error/report-error.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }

 // Keep this import relative otherwise Frontend will not be able to import this module. TODO: move all imports to relative imports
var LISTENERS = {};
var REGISTERED_LISTENERS = 0;
var error405 = {
  code: 405,
  message: 'Service %% not implemented'
};
var error500 = {
  code: 500,
  message: 'Internal server error\n\n%%'
};
/**
 * Determine if an unknown payload has the shape of a programmatic message
 *
 * @param payload The unknown message payload
 */
var isProgrammaticMessage = payload => {
  var payloadToCheck = payload;
  return payloadToCheck.type === 'set-ad-height' && ('id' in payloadToCheck.value || 'slotId' in payloadToCheck.value) && 'height' in payloadToCheck.value;
};
/**
 * Convert a legacy programmatic message to a standard message
 *
 * Note that this only applies to specific resize programmatic messages
 * (these include specific width and height values)
 */
var toStandardMessage = payload => ({
  id: 'aaaa0000-bb11-cc22-dd33-eeeeee444444',
  type: 'resize',
  iframeId: payload.value.id,
  slotId: payload.value.slotId,
  value: {
    height: payload.value.height,
    width: payload.value.width
  }
});
/**
 * Retrieve a reference to the calling iFrame
 *
 * Attempts the following strategies to find the correct iframe:
 * - using the slotId from the incoming message
 * - using the iframeId from the incoming message
 * - checking message event.source (i.e. window) against all page level iframe contentWindows
 *
 * Listeners can then use the iFrame to determine the slot making the postMessage call
 */
var getIframe = (message, messageEventSource) => {
  if (message.slotId) {
    var _container$querySelec;
    var container = document.getElementById("dfp-ad--".concat(message.slotId));
    return (_container$querySelec = container === null || container === void 0 ? void 0 : container.querySelector('iframe')) !== null && _container$querySelec !== void 0 ? _container$querySelec : undefined;
  } else if (message.iframeId) {
    var el = document.getElementById(message.iframeId);
    return el instanceof HTMLIFrameElement ? el : undefined;
  } else if (messageEventSource) {
    var iframes = document.querySelectorAll('iframe');
    return Array.from(iframes).find(iframe => iframe.contentWindow === messageEventSource);
  }
};
// Regex for testing validity of message ids
var validMessageRegex = /^[a-f0-9]{8}-([a-f0-9]{4}-){3}[a-f0-9]{12}$/;
/**
 * Narrow an `unknown` payload to the standard message format
 *
 * Until DFP provides a way for us to identify with 100% certainty our
 * in-house creatives, we are left with doing some basic tests
 * such as validating the anatomy of the payload and whitelisting
 * event type
 */
var isValidPayload = payload => {
  var payloadToCheck = payload;
  return 'type' in payloadToCheck && 'value' in payloadToCheck && 'id' in payloadToCheck && payloadToCheck.type in LISTENERS && validMessageRegex.test(payloadToCheck.id);
};
/**
 * Cheap string formatting function
 *
 * @param error An object `{ code, message }`. `message` is a string where successive
 * occurrences of %% will be replaced by the following arguments
 * @param args Arguments that will replace %%
 *
 * @example
 * formatError({ message: "%%, you are so %%" }, "Regis", "lovely")
 * => { message: "Regis, you are so lovely" }
 */
var formatError = function (error) {
  for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    args[_key - 1] = arguments[_key];
  }
  return args.reduce((e, arg) => {
    e.message = e.message.replace('%%', arg);
    return e;
  }, error);
};
/**
 * Convert a posted message to our StandardMessage format
 *
 * @param event The message event received on the window
 * @returns A message with the `StandardMessage` format, or null if the conversion was unsuccessful
 */
var eventToStandardMessage = event => {
  try {
    // Currently all non-string messages are discarded here since parsing throws an error
    // TODO Review whether this is the desired outcome
    var data = JSON.parse(event.data);
    var message = isProgrammaticMessage(data) ? toStandardMessage(data) : data;
    if (isValidPayload(message)) {
      return message;
    }
  } catch (ex) {
    // Do nothing
  }
};
/**
 * Respond to the original iframe with the result of calling the
 * persistent listener / listener chain
 */
var respond = (id, target, error, result) => {
  (0,_guardian_commercial_core_messenger_post_message__WEBPACK_IMPORTED_MODULE_0__.postMessage)({
    id,
    error,
    result
  }, target !== null && target !== void 0 ? target : window);
};
/**
 * Callback that is fired when an arbitrary message is received on the window
 *
 * @param event The message event received on the window
 */
var onMessage = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (event) {
    var message = eventToStandardMessage(event);
    if (!message) {
      return;
    }
    var listener = LISTENERS[message.type];
    if (Array.isArray(listener) && listener.length) {
      // Because any listener can have side-effects (by unregistering itself),
      // we run the promise chain on a copy of the `LISTENERS` array.
      // Hat tip @piuccio
      var promise =
      // We offer, but don't impose, the possibility that a listener returns
      // a value that must be sent back to the calling frame. To do this,
      // we pass the cumulated returned value as a second argument to each
      // listener. Notice we don't try some clever way to compose the result
      // value ourselves, this would only make the solution more complex.
      // That means a listener can ignore the cumulated return value and
      // return something else entirely—life is unfair.
      // We don't know what each callack will be made of, we don't want to.
      // And so we wrap each call in a promise chain, in case one drops the
      // occasional fastdom bomb in the middle.
      listener.reduce((func, listener) => func.then(ret => {
        var thisRet = listener(message.value, ret, getIframe(message, event.source));
        return thisRet === undefined ? ret : thisRet;
      }), Promise.resolve());
      return promise.then(response => {
        respond(message.id, event.source, null, response);
      }).catch(ex => {
        (0,_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(ex, 'native-ads');
        respond(message.id, event.source, formatError(error500, ex.toString()), null);
      });
    } else if (typeof listener === 'function') {
      // We found a persistent listener, to which we just delegate
      // responsibility to write something. Anything. Really.
      // The listener writes something by being given the `respond` function as the spec
      listener(
      // TODO change the arguments expected by persistent listeners to avoid this
      (error, result) => respond(message.id, event.source, error, result), message.value, getIframe(message, event.source));
    } else {
      // If there is no routine attached to this event type, we just answer
      // with an error code
      respond(message.id, event.source, formatError(error405, message.type), null);
    }
  });
  return function onMessage(_x) {
    return _ref.apply(this, arguments);
  };
}();
var on = window => {
  window.addEventListener('message', event => void onMessage(event));
};
var off = window => {
  window.removeEventListener('message', event => void onMessage(event));
};
/**
 * Register a listener for a given type of iframe message
 *
 * @param type The `type` of message to register against
 * @param callback The listener callback to register that will receive messages of the given type
 * @param options Options for the target window
 */
var register = (type, callback, options) => {
  var _LISTENERS$type;
  if (REGISTERED_LISTENERS === 0) {
    var _options$window;
    on((_options$window = options === null || options === void 0 ? void 0 : options.window) !== null && _options$window !== void 0 ? _options$window : window);
  }
  var listeners = (_LISTENERS$type = LISTENERS[type]) !== null && _LISTENERS$type !== void 0 ? _LISTENERS$type : [];
  if (Array.isArray(listeners) && !listeners.includes(callback)) {
    LISTENERS[type] = [...listeners, callback];
    REGISTERED_LISTENERS += 1;
  }
};
/**
 * Register a persistent listener for a given type of iframe message
 *
 * @param type The `type` of message to register against
 * @param callback The persistent listener callback to register that will receive messages of the given type
 * @param options Options for the target window and whether the callback is persistent
 */
var registerPersistentListener = (type, callback, options) => {
  if (REGISTERED_LISTENERS === 0) {
    var _options$window2;
    on((_options$window2 = options === null || options === void 0 ? void 0 : options.window) !== null && _options$window2 !== void 0 ? _options$window2 : window);
  }
  LISTENERS[type] = callback;
  REGISTERED_LISTENERS += 1;
};
/**
 * Unregister a callback for a given type
 *
 * @param type The type of message to unregister against. An iframe will send
 * messages annotated with the type
 * @param callback Optionally include the original callback. If this is included
 * for a persistent callback this function will be unregistered. If it's
 * included for a non-persistent callback only the matching callback is removed,
 * otherwise all callbacks for that type will be unregistered
 * @param options Option for the target window
 */
var unregister = (type, callback, options) => {
  var listeners = LISTENERS[type];
  if (listeners === undefined) {
    throw new Error(formatError(error405, type).message);
  } else if (listeners === callback) {
    LISTENERS[type] = undefined;
    REGISTERED_LISTENERS -= 1;
  } else if (Array.isArray(listeners)) {
    if (callback === undefined) {
      LISTENERS[type] = [];
      REGISTERED_LISTENERS -= listeners.length;
    } else {
      LISTENERS[type] = listeners.filter(cb => {
        var callbacksEqual = cb === callback;
        if (callbacksEqual) {
          REGISTERED_LISTENERS -= 1;
        }
        return !callbacksEqual;
      });
    }
  }
  if (REGISTERED_LISTENERS === 0) {
    var _options$window3;
    off((_options$window3 = options === null || options === void 0 ? void 0 : options.window) !== null && _options$window3 !== void 0 ? _options$window3 : window);
  }
};
/**
 * Initialize an array of listener callbacks in a batch
 *
 * @param listeners The listener registration functions
 * @param persistentListeners The persistent listener registration functions
 */
var init = (listeners, persistentListeners) => {
  listeners.forEach(moduleInit => moduleInit(register));
  persistentListeners.forEach(moduleInit => moduleInit(registerPersistentListener));
};
var _ = {
  onMessage
};

/***/ }),

/***/ "./src/lib/messenger/background.ts":
/*!*****************************************!*\
  !*** ./src/lib/messenger/background.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");
/* harmony import */ var _events_render_advert_label__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../events/render-advert-label */ "./src/events/render-advert-label.ts");
/* harmony import */ var _dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _fastdom_promise__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _video_progress_reporting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../video-progress-reporting */ "./src/lib/video-progress-reporting.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }





var isGallery = window.guardian.config.page.contentType === 'Gallery';
var INTERSCROLLER_TEMPLATE_ID = 11885667;
var getStylesFromSpec = specs => {
  var styles = _objectSpread({}, specs);
  delete styles.scrollType;
  delete styles.ctaUrl;
  delete styles.videoSource;
  // native templates are sometimes using the british spelling of background-color for some reason
  if (styles.backgroundColour) {
    styles.backgroundColor = styles.backgroundColour;
    delete styles.backgroundColour;
  }
  return styles;
};
var isBackgroundSpecs = specs => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isObject)(specs) && 'backgroundImage' in specs;
var createParent = (adSlot, scrollType) => {
  var backgroundParent = adSlot.querySelector('.creative__background-parent');
  var background = adSlot.querySelector('.creative__background');
  if (!backgroundParent || !background) {
    backgroundParent = document.createElement('div');
    background = document.createElement('div');
    backgroundParent.classList.add('creative__background-parent');
    background.classList.add('creative__background');
    if (scrollType) {
      backgroundParent.classList.add("creative__background-parent--".concat(scrollType));
      background.classList.add("creative__background--".concat(scrollType));
    }
    backgroundParent.appendChild(background);
    backgroundParent.style.zIndex = '-1';
    backgroundParent.style.position = 'absolute';
    backgroundParent.style.inset = '0';
    backgroundParent.style.clipPath = 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)';
    backgroundParent.style.overflow = 'hidden';
    background.style.inset = '0';
    background.style.transition = 'background 100ms ease';
    if (scrollType === 'interscroller') {
      background.style.height = '100vh';
    }
  }
  return {
    backgroundParent,
    background
  };
};
var setBackgroundStyles = (specs, background) => {
  var specStyles = getStylesFromSpec(specs);
  Object.assign(background.style, specStyles);
};
var setCtaURL = (ctaURL, backgroundParent) => {
  var ctaURLAnchor = document.createElement('a');
  ctaURLAnchor.href = ctaURL;
  ctaURLAnchor.target = '_new';
  ctaURLAnchor.appendChild(backgroundParent);
  ctaURLAnchor.style.width = '100%';
  ctaURLAnchor.style.height = '100%';
  ctaURLAnchor.style.display = 'inline-block';
  return ctaURLAnchor;
};
var renderBottomLine = (background, backgroundParent, isGallery) => {
  background.style.position = 'fixed';
  var bottomLine = document.createElement('div');
  bottomLine.classList.add('ad-slot__line');
  bottomLine.style.position = 'absolute';
  bottomLine.style.width = '100%';
  bottomLine.style.bottom = '0';
  if (isGallery) {
    bottomLine.style.borderBottom = '1px solid #333333';
  } else {
    bottomLine.style.borderBottom = '1px solid #dcdcdc';
  }
  backgroundParent.appendChild(bottomLine);
};
var setupParallax = (adSlot, background, backgroundParent) => {
  background.style.position = 'absolute';
  adSlot.style.position = 'relative';
  var onScroll = background => _fastdom_promise__WEBPACK_IMPORTED_MODULE_3__["default"].measure(() => background.getBoundingClientRect()).then(rect => _fastdom_promise__WEBPACK_IMPORTED_MODULE_3__["default"].mutate(() => {
    var backgroundHeight = rect.height;
    var windowHeight = window.innerHeight;
    // we should scroll at a rate such that we don't run out of background (when non-repeating)
    var parallaxBackgroundMovement = Math.floor(rect.bottom / (windowHeight + backgroundHeight) * 130);
    background.style.backgroundPositionY = "".concat(parallaxBackgroundMovement, "%");
  }));
  var onIntersect = entries => entries.filter(entry => entry.isIntersecting).forEach(() => {
    window.addEventListener('scroll', () => void onScroll(background), {
      passive: true
    });
    void onScroll(background);
  });
  var observer = new IntersectionObserver(onIntersect, {
    rootMargin: '10px'
  });
  observer.observe(backgroundParent);
};
var setupBackground = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (specs, adSlot) {
    var {
      backgroundParent,
      background
    } = createParent(adSlot, specs.scrollType);
    var interscrollerTemplateId = 11885667;
    return _fastdom_promise__WEBPACK_IMPORTED_MODULE_3__["default"].mutate(() => {
      setBackgroundStyles(specs, background);
      if (specs.scrollType === 'parallax') {
        setupParallax(adSlot, background, backgroundParent);
      }
      // fixed background is very similar to interscroller, generally with a smaller height
      if (specs.scrollType === 'fixed') {
        adSlot.style.position = 'relative';
        background.style.position = 'fixed';
        if (specs.backgroundColor) {
          backgroundParent.style.backgroundColor = specs.backgroundColor;
        }
      }
      if (specs.scrollType === 'interscroller') {
        adSlot.style.height = '85vh';
        adSlot.style.marginBottom = '12px';
        adSlot.style.position = 'relative';
        adSlot.style.width = '100%';
        void (0,_events_render_advert_label__WEBPACK_IMPORTED_MODULE_1__.renderAdvertLabel)(adSlot, interscrollerTemplateId);
        void (0,_events_render_advert_label__WEBPACK_IMPORTED_MODULE_1__.renderStickyScrollForMoreLabel)(backgroundParent, isGallery);
        void renderBottomLine(background, backgroundParent, isGallery);
        if (specs.ctaUrl) {
          var anchor = setCtaURL(specs.ctaUrl, backgroundParent);
          adSlot.insertBefore(anchor, adSlot.firstChild);
        }
        if (specs.videoSource) {
          var video = document.createElement('video');
          video.autoplay = true;
          video.muted = true;
          video.playsInline = true;
          video.src = specs.videoSource;
          video.style.inset = '50% 0 0 50%';
          video.style.position = 'fixed';
          video.style.height = '100%';
          video.style.transform = 'translate(-50%, -50%)';
          background.appendChild(video);
          var played = false;
          video.onended = () => played = true;
          var observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
              if (entry.isIntersecting && !played && video.paused) {
                void video.play();
              } else {
                video.pause();
              }
            });
          }, {
            root: null,
            rootMargin: '0px',
            threshold: 0.2
          });
          observer.observe(backgroundParent);
          var advert = (0,_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__.getAdvertById)(adSlot.id);
          var shouldReportVideoProgress = (advert === null || advert === void 0 ? void 0 : advert.creativeTemplateId) === INTERSCROLLER_TEMPLATE_ID;
          if (shouldReportVideoProgress) {
            void (0,_video_progress_reporting__WEBPACK_IMPORTED_MODULE_4__.sendProgressOnUnloadOnce)();
            video.ontimeupdate = function () {
              var percent = Math.round(100 * (video.currentTime / video.duration));
              (0,_video_progress_reporting__WEBPACK_IMPORTED_MODULE_4__.updateVideoProgress)(adSlot.id, percent);
            };
          }
        }
      } else {
        adSlot.insertBefore(backgroundParent, adSlot.firstChild);
      }
    });
  });
  return function setupBackground(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
var init = register => {
  register('background', /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator(function* (specs, ret, iframe) {
      if (!isBackgroundSpecs(specs)) {
        return Promise.resolve();
      }
      var adSlot = iframe === null || iframe === void 0 ? void 0 : iframe.closest('.js-ad-slot');
      if (adSlot) {
        return setupBackground(specs, adSlot);
      }
    });
    return function (_x3, _x4, _x5) {
      return _ref2.apply(this, arguments);
    };
  }());
};
var _ = {
  setupBackground,
  getStylesFromSpec
};


/***/ }),

/***/ "./src/lib/messenger/resize.ts":
/*!*************************************!*\
  !*** ./src/lib/messenger/resize.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../fastdom-promise */ "./src/lib/fastdom-promise.ts");


var isValidResizeSpecs = specs => {
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isObject)(specs) && (specs.width === undefined || (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isString)(specs.width) || typeof specs.width === 'number') && (specs.height === undefined || (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isString)(specs.height) || typeof specs.height === 'number');
};
var normalise = length => {
  var _matches$;
  var lengthRegexp = /^(\d+)(%|px|em|ex|ch|rem|vh|vw|vmin|vmax)?/;
  var defaultUnit = 'px';
  var matches = lengthRegexp.exec(String(length));
  if (!matches) {
    return '';
  }
  var number = matches[1];
  var unit = (_matches$ = matches[2]) !== null && _matches$ !== void 0 ? _matches$ : defaultUnit;
  if (!number) {
    return '';
  }
  return number + unit;
};
var resize = (specs, iframe, iframeContainer, adSlot) => {
  if (!isValidResizeSpecs(specs) || !adSlot) {
    return Promise.resolve();
  }
  var styles = {};
  if (specs.width) {
    styles.width = normalise(specs.width);
  }
  if (specs.height) {
    styles.height = normalise(specs.height);
  }
  return _fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
    Object.assign(iframe.style, styles);
    if (iframeContainer) {
      Object.assign(iframeContainer.style, styles);
    }
    adSlot.style.maxHeight = 'none';
  });
};
// When an outstream resizes we want it to revert to its original styling
var removeAnyOutstreamClass = adSlot => {
  void _fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
    adSlot.classList.remove('ad-slot--outstream');
  });
};
var init = register => {
  register('resize', (specs, ret, iframe) => {
    if (iframe && specs) {
      var _iframe$closest, _iframe$closest2;
      var adSlot = (_iframe$closest = iframe.closest('.js-ad-slot')) !== null && _iframe$closest !== void 0 ? _iframe$closest : undefined;
      if (adSlot) {
        removeAnyOutstreamClass(adSlot);
      }
      var iframeContainer = (_iframe$closest2 = iframe.closest('.ad-slot__content')) !== null && _iframe$closest2 !== void 0 ? _iframe$closest2 : undefined;
      return resize(specs, iframe, iframeContainer, adSlot);
    }
  });
};
var _ = {
  resize,
  normalise
};


/***/ }),

/***/ "./src/lib/messenger/type.ts":
/*!***********************************!*\
  !*** ./src/lib/messenger/type.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _fastdom_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../fastdom-promise */ "./src/lib/fastdom-promise.ts");


var setType = (adSlotType, adSlot) => _fastdom_promise__WEBPACK_IMPORTED_MODULE_1__["default"].mutate(() => {
  adSlot.classList.add("ad-slot--".concat(adSlotType));
});
var init = register => {
  register('type', (specs, ret, iframe) => {
    var adSlot = iframe === null || iframe === void 0 ? void 0 : iframe.closest('.js-ad-slot');
    if (adSlot && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isString)(specs)) {
      void setType(specs, adSlot);
    }
  });
};


/***/ }),

/***/ "./src/lib/page-targeting.ts":
/*!***********************************!*\
  !*** ./src/lib/page-targeting.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildAppNexusTargeting: () => (/* binding */ buildAppNexusTargeting),
/* harmony export */   buildAppNexusTargetingObject: () => (/* binding */ buildAppNexusTargetingObject),
/* harmony export */   getPageTargeting: () => (/* binding */ getPageTargeting)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_targeting_build_page_targeting__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/targeting/build-page-targeting */ "../core/src/targeting/build-page-targeting.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _experiments_ab__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../experiments/ab */ "./src/experiments/ab.ts");
/* harmony import */ var _commercial_features__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _header_bidding_utils__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./header-bidding/utils */ "./src/lib/header-bidding/utils.ts");






var formatAppNexusTargeting = obj => {
  var asKeyValues = Object.entries(obj).map(entry => {
    var [key, value] = entry;
    return Array.isArray(value) ? value.map(nestedValue => "".concat(key, "=").concat(nestedValue)) : "".concat(key, "=").concat(value);
  });
  var flattenDeep = Array.prototype.concat.apply([], asKeyValues);
  return flattenDeep.join(',');
};
var buildAppNexusTargetingObject = (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(pageTargeting => (0,_header_bidding_utils__WEBPACK_IMPORTED_MODULE_5__.removeFalsyValues)({
  sens: pageTargeting.sens,
  pt1: pageTargeting.url,
  pt2: pageTargeting.edition,
  pt3: pageTargeting.ct,
  pt4: pageTargeting.p,
  pt5: pageTargeting.k,
  pt6: pageTargeting.su,
  pt7: pageTargeting.bp,
  pt9: [pageTargeting.pv, pageTargeting.co, pageTargeting.tn].join('|'),
  permutive: pageTargeting.permutive
}));
var buildAppNexusTargeting = (0,lodash_es__WEBPACK_IMPORTED_MODULE_2__["default"])(pageTargeting => formatAppNexusTargeting(buildAppNexusTargetingObject(pageTargeting)));
var getPageTargeting = (consentState, isSignedIn) => {
  var {
    page
  } = window.guardian.config;
  var pageTargeting = (0,_guardian_commercial_core_targeting_build_page_targeting__WEBPACK_IMPORTED_MODULE_0__.buildPageTargeting)({
    adFree: _commercial_features__WEBPACK_IMPORTED_MODULE_4__.commercialFeatures.adFree,
    clientSideParticipations: (0,_experiments_ab__WEBPACK_IMPORTED_MODULE_3__.getParticipations)(),
    consentState,
    isSignedIn
  });
  // third-parties wish to access our page targeting, before the googletag script is loaded.
  page.appNexusPageTargeting = buildAppNexusTargeting(pageTargeting);
  // This can be removed once we get sign-off from third parties who prefer to use appNexusPageTargeting.
  page.pageAdTargeting = pageTargeting;
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'pageTargeting object:', pageTargeting);
  return pageTargeting;
};


/***/ }),

/***/ "./src/lib/video-progress-reporting.ts":
/*!*********************************************!*\
  !*** ./src/lib/video-progress-reporting.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   sendProgressOnUnloadOnce: () => (/* binding */ sendProgressOnUnloadOnce),
/* harmony export */   updateVideoProgress: () => (/* binding */ updateVideoProgress)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_send_commercial_metrics__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/send-commercial-metrics */ "../core/src/send-commercial-metrics.ts");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }



var endpoint = window.guardian.config.page.isDev ? '//logs.code.dev-guardianapis.com/log' : '//logs.guardianapis.com/log';
// This is a map of video progress for each slotId.
var videoProgress = {};
var sendProgress = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(() => {
  Object.entries(videoProgress).forEach(_ref => {
    var [key, value] = _ref;
    var advert = (0,_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__.getAdvertById)(key);
    if (!(advert !== null && advert !== void 0 && advert.creativeId) || !advert.lineItemId) {
      return;
    }
    var {
      creativeId,
      lineItemId
    } = advert;
    var progress = value !== null && value !== void 0 ? value : 0;
    void fetch(endpoint, {
      method: 'POST',
      body: JSON.stringify({
        label: 'commercial.interscroller.videoProgress',
        properties: [{
          name: 'creativeId',
          value: creativeId
        }, {
          name: 'lineItemId',
          value: lineItemId
        }, {
          name: 'progress',
          value: progress
        }, {
          name: 'pageviewId',
          value: window.guardian.config.ophan.pageViewId
        }]
      }),
      keepalive: true,
      cache: 'no-store',
      mode: 'no-cors'
    });
  });
});
var sendProgressOnUnloadOnce = (0,lodash_es__WEBPACK_IMPORTED_MODULE_1__["default"])(/*#__PURE__*/_asyncToGenerator(function* () {
  if (yield (0,_guardian_commercial_core_send_commercial_metrics__WEBPACK_IMPORTED_MODULE_0__.checkConsent)()) {
    window.addEventListener('visibilitychange', sendProgress, {
      once: true
    });
    // Safari does not reliably fire the `visibilitychange` on page unload.
    window.addEventListener('pagehide', sendProgress, {
      once: true
    });
  }
}));
var updateVideoProgress = (slotId, updatedProgress) => {
  videoProgress[slotId] = updatedProgress;
};


/***/ }),

/***/ "./static/svg/icon/cross.svg":
/*!***********************************!*\
  !*** ./static/svg/icon/cross.svg ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ("<svg width=\"18\" height=\"18\" viewBox=\"0 0 18 18\"><path d=\"M7.5 9l-6.5-7 1-1 7 6.5 7-6.5 1 1-6.5 7 6.5 7-1 1-7-6.5-7 6.5-1-1 6.5-7z\"/></svg>\n");

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uc3JjX2V2ZW50c19lbXB0eS1hZHZlcnRfdHMtc3JjX2luaXRfc2hhcmVkX3JlbG9hZC1wYWdlLW9uLWNvbnNlbnQtY2hhbmdlX3RzLXNyY19pbml0X3NoYXJlZF9zLTc4ZjAyOC5jb21tZXJjaWFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUF5RDtBQUN6RDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTUUsTUFBTSxTQUFTQyxLQUFLLENBQUM7RUFHdkJDLFdBQVdBLENBQUFDLElBQUEsRUFBa0I7SUFBQSxJQUFqQixDQUFDQyxLQUFLLEVBQUVDLE1BQU0sQ0FBQyxHQUFBRixJQUFBO0lBQ3ZCLEtBQUssQ0FBQyxDQUFDO0lBQUNHLGVBQUEsT0FIWCxDQUFDO0lBQUFBLGVBQUEsT0FDRCxDQUFDO0lBR0UsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHRixLQUFLO0lBQ2YsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHQyxNQUFNO0VBQ3BCO0VBQ0FFLFFBQVFBLENBQUEsRUFBRztJQUNQLE9BQU8sSUFBSSxDQUFDSCxLQUFLLEtBQUssQ0FBQyxJQUFJLElBQUksQ0FBQ0MsTUFBTSxLQUFLLENBQUMsR0FDdEMsT0FBTyxNQUFBRyxNQUFBLENBQ0osSUFBSSxDQUFDSixLQUFLLE9BQUFJLE1BQUEsQ0FBSSxJQUFJLENBQUNILE1BQU0sQ0FBRTtFQUN4QztFQUNBSSxPQUFPQSxDQUFBLEVBQUc7SUFDTixPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUM3QjtFQUNBO0VBQ0E7RUFDQUMsT0FBT0EsQ0FBQSxFQUFHO0lBQ04sSUFBTUMsV0FBVyxHQUFHLElBQUksQ0FBQ1AsS0FBSyxLQUFLLENBQUMsSUFBSSxJQUFJLENBQUNDLE1BQU0sS0FBSyxDQUFDO0lBQ3pELElBQU1PLE9BQU8sR0FBRyxJQUFJLENBQUNSLEtBQUssS0FBSyxDQUFDLElBQUksSUFBSSxDQUFDQyxNQUFNLEtBQUssQ0FBQztJQUNyRCxJQUFNUSxPQUFPLEdBQUcsSUFBSSxDQUFDTixRQUFRLENBQUMsQ0FBQyxLQUFLLE9BQU87SUFDM0MsSUFBTU8sT0FBTyxHQUFHLElBQUksQ0FBQ1YsS0FBSyxLQUFLLEVBQUU7SUFDakMsSUFBTVcsYUFBYSxHQUFHLElBQUksQ0FBQ1gsS0FBSyxLQUFLLENBQUMsSUFBSSxJQUFJLENBQUNDLE1BQU0sS0FBSyxDQUFDO0lBQzNELE9BQU9NLFdBQVcsSUFBSUMsT0FBTyxJQUFJQyxPQUFPLElBQUlDLE9BQU8sSUFBSUMsYUFBYTtFQUN4RTtFQUNBLElBQUlYLEtBQUtBLENBQUEsRUFBRztJQUNSLE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNsQjtFQUNBLElBQUlDLE1BQU1BLENBQUEsRUFBRztJQUNULE9BQU8sSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNsQjtBQUNKO0FBQ0EsSUFBTVcsWUFBWSxHQUFHQSxDQUFDWixLQUFLLEVBQUVDLE1BQU0sS0FBSztFQUNwQyxPQUFPLElBQUlMLE1BQU0sQ0FBQyxDQUFDSSxLQUFLLEVBQUVDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLENBQUM7QUFDRCxJQUFNWSxvQkFBb0IsR0FBRztFQUN6QkMsU0FBUyxFQUFFRixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUNqQ0csUUFBUSxFQUFFSCxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUNoQ0ksV0FBVyxFQUFFSixZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztFQUNsQ0ssWUFBWSxFQUFFTCxZQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQztFQUNuQ00sR0FBRyxFQUFFTixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUMzQk8sUUFBUSxFQUFFUCxZQUFZLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQztFQUNqQ1EsVUFBVSxFQUFFUixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUNsQ1MsT0FBTyxFQUFFVCxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUMvQlUsb0JBQW9CLEVBQUVWLFlBQVksQ0FBQyxHQUFHLEVBQUUsR0FBRztBQUMvQyxDQUFDO0FBQ0QsSUFBTVcsZUFBZSxHQUFHO0VBQ3BCLFNBQVMsRUFBRVYsb0JBQW9CLENBQUNDLFNBQVM7RUFDekMsU0FBUyxFQUFFRCxvQkFBb0IsQ0FBQ0UsUUFBUTtFQUN4QyxRQUFRLEVBQUVGLG9CQUFvQixDQUFDRyxXQUFXO0VBQzFDLFNBQVMsRUFBRUgsb0JBQW9CLENBQUNLLEdBQUc7RUFDbkMsVUFBVSxFQUFFTCxvQkFBb0IsQ0FBQ00sUUFBUTtFQUN6QyxTQUFTLEVBQUVOLG9CQUFvQixDQUFDTztBQUNwQyxDQUFDO0FBQ0QsSUFBTUksY0FBYyxHQUFHO0VBQ25CQyxnQkFBZ0IsRUFBRWIsWUFBWSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7RUFDeENjLHNCQUFzQixFQUFFZCxZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUM5Q2UsZUFBZSxFQUFFZixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUc7QUFDMUMsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLElBQU1nQixrQkFBa0IsR0FBRztFQUN2QkMsS0FBSyxFQUFFakIsWUFBWSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7RUFDekJrQixVQUFVLEVBQUVsQixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztFQUNsQ21CLFNBQVMsRUFBRW5CLFlBQVksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQzdCb0IscUJBQXFCLEVBQUVwQixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFFO0FBQ25ELENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxJQUFNcUIsMEJBQTBCLEdBQUc7RUFDL0JDLEtBQUssRUFBRXRCLFlBQVksQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQ3pCdUIsTUFBTSxFQUFFdkIsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUM7RUFDNUJ3QixhQUFhLEVBQUV4QixZQUFZLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQztFQUNuQ3lCLGlCQUFpQixFQUFFekIsWUFBWSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUM7RUFDdkMwQiwwQkFBMEIsRUFBRTFCLFlBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDO0VBQ2hEO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7RUFDSTJCLFdBQVcsRUFBRTNCLFlBQVksQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNsQyxDQUFDO0FBQ0QsSUFBTTRCLE9BQU8sR0FBQUMsYUFBQSxDQUFBQSxhQUFBLENBQUFBLGFBQUEsQ0FBQUEsYUFBQSxDQUFBQSxhQUFBLEtBQ041QixvQkFBb0IsR0FDcEJVLGVBQWUsR0FDZkMsY0FBYyxHQUNkSSxrQkFBa0IsR0FDbEJLLDBCQUEwQixDQUNoQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1TLGdCQUFnQixHQUFHO0VBQ3JCQyxNQUFNLEVBQUU7SUFDSkMsTUFBTSxFQUFFLENBQ0pKLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ2IsZUFBZSxFQUN2QmEsT0FBTyxDQUFDdEIsR0FBRyxFQUNYc0IsT0FBTyxDQUFDVixVQUFVLEVBQ2xCVSxPQUFPLENBQUNYLEtBQUssQ0FDaEI7SUFDRGdCLE9BQU8sRUFBRSxDQUNMTCxPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNWLFVBQVUsRUFDbEJVLE9BQU8sQ0FBQ1gsS0FBSztFQUVyQixDQUFDO0VBQ0RpQixLQUFLLEVBQUU7SUFDSEYsTUFBTSxFQUFFLENBQ0pKLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ3RCLEdBQUcsRUFDWHNCLE9BQU8sQ0FBQ1YsVUFBVSxFQUNsQlUsT0FBTyxDQUFDekIsUUFBUSxFQUNoQnlCLE9BQU8sQ0FBQ1gsS0FBSztFQUVyQixDQUFDO0VBQ0RrQixRQUFRLEVBQUU7SUFDTkgsTUFBTSxFQUFFLENBQ0pKLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ2IsZUFBZSxFQUN2QmEsT0FBTyxDQUFDdEIsR0FBRyxFQUNYc0IsT0FBTyxDQUFDVixVQUFVLEVBQ2xCVSxPQUFPLENBQUNYLEtBQUssQ0FDaEI7SUFDRGdCLE9BQU8sRUFBRSxDQUNMTCxPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNWLFVBQVUsRUFDbEJVLE9BQU8sQ0FBQ1gsS0FBSztFQUVyQixDQUFDO0VBQ0QsbUJBQW1CLEVBQUU7SUFDakJlLE1BQU0sRUFBRSxDQUFDSixPQUFPLENBQUN0QixHQUFHLEVBQUVzQixPQUFPLENBQUNOLEtBQUssQ0FBQztJQUNwQ1csT0FBTyxFQUFFLENBQ0xMLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ3RCLEdBQUcsRUFDWHNCLE9BQU8sQ0FBQ1YsVUFBVSxFQUNsQlUsT0FBTyxDQUFDWCxLQUFLLEVBQ2JXLE9BQU8sQ0FBQ3BCLFVBQVUsRUFDbEJvQixPQUFPLENBQUN6QixRQUFRO0VBRXhCLENBQUM7RUFDRCxlQUFlLEVBQUU7SUFDYjZCLE1BQU0sRUFBRSxDQUNKSixPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUNMLE1BQU0sRUFDZEssT0FBTyxDQUFDYixlQUFlLEVBQ3ZCYSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNYLEtBQUssQ0FDaEI7SUFDRG1CLE1BQU0sRUFBRSxDQUNKUixPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUNMLE1BQU0sRUFDZEssT0FBTyxDQUFDWCxLQUFLLEVBQ2JXLE9BQU8sQ0FBQ3hCLFdBQVcsQ0FDdEI7SUFDRDZCLE9BQU8sRUFBRSxDQUNMTCxPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUN4QixXQUFXLEVBQ25CSixZQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxFQUN0QkEsWUFBWSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFDdEI0QixPQUFPLENBQUMxQixTQUFTLEVBQ2pCMEIsT0FBTyxDQUFDTCxNQUFNLEVBQ2RLLE9BQU8sQ0FBQ1gsS0FBSztFQUVyQixDQUFDO0VBQ0QsZUFBZSxFQUFFO0lBQ2JtQixNQUFNLEVBQUUsQ0FBQ1IsT0FBTyxDQUFDTixLQUFLLEVBQUVNLE9BQU8sQ0FBQ3hCLFdBQVcsQ0FBQztJQUM1QzZCLE9BQU8sRUFBRSxDQUNMTCxPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUMxQixTQUFTLEVBQ2pCMEIsT0FBTyxDQUFDSCxpQkFBaUIsRUFDekJHLE9BQU8sQ0FBQ1gsS0FBSztFQUVyQixDQUFDO0VBQ0RvQixPQUFPLEVBQUU7SUFDTEwsTUFBTSxFQUFFLENBQ0pKLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ3RCLEdBQUcsRUFDWHNCLE9BQU8sQ0FBQ1YsVUFBVSxFQUNsQlUsT0FBTyxDQUFDWCxLQUFLLENBQ2hCO0lBQ0RxQixPQUFPLEVBQUUsQ0FDTFYsT0FBTyxDQUFDVCxTQUFTLEVBQ2pCUyxPQUFPLENBQUNOLEtBQUssRUFDYk0sT0FBTyxDQUFDYixlQUFlLEVBQ3ZCYSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNWLFVBQVUsRUFDbEJVLE9BQU8sQ0FBQ3pCLFFBQVEsRUFDaEJ5QixPQUFPLENBQUNYLEtBQUssQ0FDaEI7SUFDRG1CLE1BQU0sRUFBRSxDQUNKUixPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNWLFVBQVUsRUFDbEJVLE9BQU8sQ0FBQ3pCLFFBQVEsRUFDaEJ5QixPQUFPLENBQUNYLEtBQUssQ0FDaEI7SUFDRGdCLE9BQU8sRUFBRSxDQUNMTCxPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNWLFVBQVUsRUFDbEJVLE9BQU8sQ0FBQ3pCLFFBQVEsRUFDaEJ5QixPQUFPLENBQUNYLEtBQUs7RUFFckIsQ0FBQztFQUNELGNBQWMsRUFBRTtJQUNaZSxNQUFNLEVBQUUsQ0FBQ0osT0FBTyxDQUFDVCxTQUFTLEVBQUVTLE9BQU8sQ0FBQ04sS0FBSyxFQUFFTSxPQUFPLENBQUN0QixHQUFHLEVBQUVzQixPQUFPLENBQUNYLEtBQUssQ0FBQztJQUN0RW1CLE1BQU0sRUFBRSxFQUFFO0lBQ1ZILE9BQU8sRUFBRTtFQUNiLENBQUM7RUFDRCxvQkFBb0IsRUFBRTtJQUNsQkQsTUFBTSxFQUFFLENBQ0pKLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ0gsaUJBQWlCLEVBQ3pCRyxPQUFPLENBQUNYLEtBQUssRUFDYlcsT0FBTyxDQUFDdEIsR0FBRyxDQUNkO0lBQ0Q4QixNQUFNLEVBQUUsQ0FDSlIsT0FBTyxDQUFDVCxTQUFTLEVBQ2pCUyxPQUFPLENBQUNOLEtBQUssRUFDYk0sT0FBTyxDQUFDSCxpQkFBaUIsRUFDekJHLE9BQU8sQ0FBQ1gsS0FBSyxDQUNoQjtJQUNEZ0IsT0FBTyxFQUFFLENBQ0xMLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ0gsaUJBQWlCLEVBQ3pCRyxPQUFPLENBQUNYLEtBQUssRUFDYlcsT0FBTyxDQUFDMUIsU0FBUztFQUV6QixDQUFDO0VBQ0RzQixhQUFhLEVBQUU7SUFDWFEsTUFBTSxFQUFFLENBQ0pKLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ0osYUFBYSxFQUNyQkksT0FBTyxDQUFDWCxLQUFLLEVBQ2JXLE9BQU8sQ0FBQ3RCLEdBQUcsQ0FDZDtJQUNEOEIsTUFBTSxFQUFFLENBQ0pSLE9BQU8sQ0FBQ1QsU0FBUyxFQUNqQlMsT0FBTyxDQUFDTixLQUFLLEVBQ2JNLE9BQU8sQ0FBQ0osYUFBYSxFQUNyQkksT0FBTyxDQUFDWCxLQUFLLENBQ2hCO0lBQ0RnQixPQUFPLEVBQUUsQ0FDTEwsT0FBTyxDQUFDVCxTQUFTLEVBQ2pCUyxPQUFPLENBQUNOLEtBQUssRUFDYk0sT0FBTyxDQUFDSixhQUFhLEVBQ3JCSSxPQUFPLENBQUNYLEtBQUssRUFDYlcsT0FBTyxDQUFDMUIsU0FBUztFQUV6QixDQUFDO0VBQ0RxQyxNQUFNLEVBQUU7SUFDSk4sT0FBTyxFQUFFLENBQUNMLE9BQU8sQ0FBQ1QsU0FBUztFQUMvQixDQUFDO0VBQ0RxQixNQUFNLEVBQUU7SUFDSlIsTUFBTSxFQUFFLENBQUNKLE9BQU8sQ0FBQ1gsS0FBSztFQUMxQixDQUFDO0VBQ0QsZUFBZSxFQUFFO0lBQ2JlLE1BQU0sRUFBRSxDQUFDSixPQUFPLENBQUN2QixZQUFZLEVBQUV1QixPQUFPLENBQUNOLEtBQUssRUFBRXRCLFlBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDO0VBQ3ZFLENBQUM7RUFDRCx5QkFBeUIsRUFBRTtJQUN2QmdDLE1BQU0sRUFBRSxDQUFDSixPQUFPLENBQUN2QixZQUFZO0VBQ2pDLENBQUM7RUFDRCxnQkFBZ0IsRUFBRTtJQUNkNEIsT0FBTyxFQUFFLENBQ0xMLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUN0QixHQUFHLEVBQ1hzQixPQUFPLENBQUNwQixVQUFVLEVBQ2xCb0IsT0FBTyxDQUFDekIsUUFBUTtFQUV4QixDQUFDO0VBQ0QsYUFBYSxFQUFFO0lBQ1g2QixNQUFNLEVBQUUsRUFBRSxDQUFFO0VBQ2hCLENBQUM7RUFDRFMsU0FBUyxFQUFFO0lBQ1BULE1BQU0sRUFBRSxDQUFDSixPQUFPLENBQUNOLEtBQUs7RUFDMUIsQ0FBQztFQUNEO0FBQ0o7QUFDQTtFQUNJb0IsUUFBUSxFQUFFO0lBQ05WLE1BQU0sRUFBRSxDQUFDSixPQUFPLENBQUNULFNBQVMsRUFBRVMsT0FBTyxDQUFDTixLQUFLLEVBQUVNLE9BQU8sQ0FBQ1gsS0FBSyxFQUFFVyxPQUFPLENBQUN0QixHQUFHO0VBQ3pFLENBQUM7RUFDRCxjQUFjLEVBQUU7SUFDWjBCLE1BQU0sRUFBRSxDQUNKSixPQUFPLENBQUNULFNBQVMsRUFDakJTLE9BQU8sQ0FBQ04sS0FBSyxFQUNiTSxPQUFPLENBQUNYLEtBQUssRUFDYlcsT0FBTyxDQUFDRCxXQUFXO0VBRTNCLENBQUM7RUFDRGdCLFdBQVcsRUFBRTtJQUNUO0lBQ0FYLE1BQU0sRUFBRSxDQUFDSixPQUFPLENBQUNULFNBQVMsRUFBRVMsT0FBTyxDQUFDTixLQUFLLENBQUM7SUFDMUNjLE1BQU0sRUFBRSxDQUFDUixPQUFPLENBQUNULFNBQVMsRUFBRVMsT0FBTyxDQUFDTixLQUFLLENBQUM7SUFDMUNXLE9BQU8sRUFBRSxDQUFDTCxPQUFPLENBQUNULFNBQVMsRUFBRVMsT0FBTyxDQUFDTixLQUFLO0VBQzlDO0FBQ0osQ0FBQztBQUNELElBQU1zQixTQUFTLEdBQUlDLElBQUksSUFBS2pCLE9BQU8sQ0FBQ2lCLElBQUksQ0FBQztBQUN6QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyw2QkFBNkIsR0FBR0EsQ0FBQ0MsWUFBWSxFQUFFQyxVQUFVLEtBQUs7RUFDaEUsSUFBSSxDQUFDakUseURBQVksQ0FBQ2lFLFVBQVUsQ0FBQyxFQUFFO0lBQzNCLE9BQU8sRUFBRTtFQUNiO0VBQ0EsSUFBSUMsZUFBZSxHQUFHbkUsb0RBQVcsQ0FBQ29FLFNBQVMsQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLEtBQUtILFVBQVUsQ0FBQztFQUNwRSxPQUFPQyxlQUFlLElBQUksQ0FBQyxFQUFFO0lBQ3pCLElBQU1HLGVBQWUsR0FBR3RFLG9EQUFXLENBQUNtRSxlQUFlLENBQUM7SUFDcEQsSUFBTUksV0FBVyxHQUFHTixZQUFZLENBQUNLLGVBQWUsQ0FBQztJQUNqRCxJQUFJQyxXQUFXLGFBQVhBLFdBQVcsZUFBWEEsV0FBVyxDQUFFQyxNQUFNLEVBQUU7TUFDckIsT0FBT0QsV0FBVztJQUN0QjtJQUNBSixlQUFlLEVBQUU7RUFDckI7RUFDQTtFQUNBLE9BQU8sRUFBRTtBQUNiLENBQUM7QUFDRDtBQUNPLElBQU1NLENBQUMsR0FBRztFQUFFdkQ7QUFBYSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDcFlqQztBQUNBO0FBQ0E7QUFDQSxJQUFNbEIsV0FBVyxHQUFHLENBQUMsUUFBUSxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQztBQUN0RSxJQUFNQyxZQUFZLEdBQUl5RSxDQUFDLElBQUsxRSxXQUFXLENBQUMyRSxRQUFRLENBQUNELENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDSm5EO0FBQ0E7QUFDQTtBQUNPLElBQU1FLGNBQWMsR0FBRyxJQUFJLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSDRCO0FBQzlELElBQU1JLHVCQUF1QixHQUFHO0VBQzVCQyxFQUFFLEVBQUUsSUFBSTtFQUNSQyxFQUFFLEVBQUUsSUFBSTtFQUNSQyxFQUFFLEVBQUU7QUFDUixDQUFDO0FBQ0QsSUFBTUMsb0JBQW9CLEdBQUcsU0FBQUEsQ0FBQTtFQUFBLElBQUNDLFVBQVUsR0FBQUMsU0FBQSxDQUFBZCxNQUFBLFFBQUFjLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsSUFBSTtFQUFBLE9BQUtOLHVCQUF1QixDQUFDSyxVQUFVLENBQUM7QUFBQTtBQUN2RixJQUFNRyxpQkFBaUIsR0FBRyxnQkFBZ0I7QUFDMUMsSUFBTUMsbUJBQW1CLEdBQUcsaUJBQWlCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLGNBQWMsR0FBR0EsQ0FBQSxLQUFNO0VBQUEsSUFBQXJGLElBQUE7RUFDekIsSUFBTXNGLFdBQVcsR0FBR0MsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDQyxPQUFPO0VBQ3ZELElBQU1DLG9CQUFvQixHQUFHbEIsbURBQU8sQ0FBQ21CLEtBQUssQ0FBQ0MsR0FBRyxDQUFDVixtQkFBbUIsQ0FBQztFQUNuRSxJQUFNVyxlQUFlLEdBQUd0Qix3REFBUSxDQUFDbUIsb0JBQW9CLENBQUMsR0FDaERBLG9CQUFvQixHQUNwQixJQUFJO0VBQ1YsUUFBQTVGLElBQUEsR0FBUStGLGVBQWUsYUFBZkEsZUFBZSxjQUFmQSxlQUFlLEdBQ25CdkIseURBQVMsQ0FBQztJQUNOd0IsSUFBSSxFQUFFYixpQkFBaUI7SUFDdkJjLGFBQWEsRUFBRTtFQUNuQixDQUFDLENBQUMsY0FBQWpHLElBQUEsY0FBQUEsSUFBQSxHQUNGK0Usb0JBQW9CLENBQUNPLFdBQVcsQ0FBQztBQUN6QyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQitDO0FBQ2hEO0FBQ0EsSUFBSVksR0FBRztBQUNQLElBQU1DLGtCQUFrQixHQUFHQSxDQUFBLEtBQU07RUFDN0JELEdBQUcsR0FBR0EsR0FBRyxhQUFIQSxHQUFHLGNBQUhBLEdBQUcsR0FBSWIsNkRBQWMsQ0FBQyxDQUFDO0VBQzdCLE9BQU9hLEdBQUc7QUFDZCxDQUFDO0FBQ00sSUFBTUUsTUFBTSxHQUFHQSxDQUFBLEtBQU1ELGtCQUFrQixDQUFDLENBQUMsS0FBSyxJQUFJO0FBQ2xELElBQU1FLE9BQU8sR0FBR0EsQ0FBQSxLQUFNRixrQkFBa0IsQ0FBQyxDQUFDLEtBQUssSUFBSTtBQUNuRCxJQUFNRyxVQUFVLEdBQUdBLENBQUEsS0FBTUgsa0JBQWtCLENBQUMsQ0FBQyxLQUFLLElBQUk7QUFDdEQsSUFBTUksYUFBYSxHQUFHQSxDQUFBLEtBQU1KLGtCQUFrQixDQUFDLENBQUMsS0FBSyxJQUFJO0FBQ3pELElBQU1LLGNBQWMsR0FBR0EsQ0FBQSxLQUFNTCxrQkFBa0IsQ0FBQyxDQUFDLEtBQUssSUFBSTtBQUMxRCxJQUFNTSxVQUFVLEdBQUdBLENBQUEsS0FBTUosT0FBTyxDQUFDLENBQUMsSUFBSUMsVUFBVSxDQUFDLENBQUM7QUFDbEQsSUFBTUksVUFBVSxHQUFHQSxDQUFBLEtBQU1ILGFBQWEsQ0FBQyxDQUFDLElBQUlDLGNBQWMsQ0FBQyxDQUFDO0FBQzVELElBQU1HLE9BQU8sR0FBR0EsQ0FBQSxLQUFNLENBQUNQLE1BQU0sQ0FBQyxDQUFDLElBQUksQ0FBQ0ssVUFBVSxDQUFDLENBQUMsSUFBSSxDQUFDQyxVQUFVLENBQUMsQ0FBQztBQUNqRSxJQUFNdEMsQ0FBQyxHQUFHO0VBQ2J3QyxXQUFXLEVBQUVBLENBQUEsS0FBTTtJQUNmVixHQUFHLEdBQUdoQixTQUFTO0VBQ25CO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQjZEO0FBQzlELElBQU0yQixHQUFHLEdBQUcsZ0JBQWdCO0FBQzVCLElBQU1DLFlBQVksR0FBRyxpQkFBaUI7QUFDdEMsSUFBTUMsYUFBYSxHQUFHLFlBQVk7QUFDbEM7QUFDQSxJQUFNQyxrQkFBa0IsR0FBSUMsT0FBTyxJQUFLeEMsd0RBQVEsQ0FBQ3dDLE9BQU8sQ0FBQyxJQUFJRixhQUFhLENBQUNHLElBQUksQ0FBQ0QsT0FBTyxDQUFDO0FBQ3hGO0FBQ0EsSUFBSUUsTUFBTTtBQUNWLElBQU1DLHVCQUF1QixHQUFHO0VBQzVCeEMsRUFBRSxFQUFFLElBQUk7RUFDUkMsRUFBRSxFQUFFLElBQUk7RUFDUkMsRUFBRSxFQUFFO0FBQ1IsQ0FBQztBQUNELElBQU11QyxvQkFBb0IsR0FBSXJDLFVBQVUsSUFBS29DLHVCQUF1QixDQUFDcEMsVUFBVSxDQUFDO0FBQ2hGO0FBQ08sSUFBTXNDLGtCQUFrQixHQUFHQSxDQUFBLEtBQU9ILE1BQU0sR0FBR2pDLFNBQVU7QUFDNUQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1xQyxTQUFTLEdBQUdBLENBQUEsS0FBTTtFQUMzQixJQUFJSixNQUFNLEVBQ04sT0FBT0EsTUFBTTtFQUNqQjtFQUNBLElBQU1LLFdBQVcsR0FBRzlDLG1EQUFPLENBQUNtQixLQUFLLENBQUNDLEdBQUcsQ0FBQ2dCLFlBQVksQ0FBQztFQUNuRCxJQUFJRSxrQkFBa0IsQ0FBQ1EsV0FBVyxDQUFDLEVBQUU7SUFDakMsT0FBUUwsTUFBTSxHQUFHSyxXQUFXO0VBQ2hDO0VBQ0E7RUFDQSxJQUFNQyxNQUFNLEdBQUdqRCx5REFBUyxDQUFDO0lBQUV3QixJQUFJLEVBQUVhO0VBQUksQ0FBQyxDQUFDO0VBQ3ZDLElBQUlZLE1BQU0sSUFBSVQsa0JBQWtCLENBQUNTLE1BQU0sQ0FBQyxFQUFFO0lBQ3RDLE9BQVFOLE1BQU0sR0FBR00sTUFBTTtFQUMzQjtFQUNBO0VBQ0EsSUFBTUMsa0JBQWtCLEdBQUdMLG9CQUFvQixDQUFDOUIsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDQyxPQUFPLENBQUM7RUFDcEYsT0FBUXdCLE1BQU0sR0FBR08sa0JBQWtCO0FBQ3ZDLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7QUNyQ00sSUFBTUMsV0FBVyxHQUFHLFNBQUFBLENBQUNDLE9BQU8sRUFBRUMsTUFBTSxFQUF5QjtFQUFBLElBQXZCQyxZQUFZLEdBQUE3QyxTQUFBLENBQUFkLE1BQUEsUUFBQWMsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBRyxHQUFHO0VBQzNENEMsTUFBTSxDQUFDRixXQUFXLENBQUNJLElBQUksQ0FBQ0MsU0FBUyxDQUFDSixPQUFPLENBQUMsRUFBRTtJQUFFRTtFQUFhLENBQUMsQ0FBQztBQUNqRSxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0Z3QztBQUN6QyxJQUFNRyxhQUFhLFdBQVc7QUFDOUIsSUFBTUMsaUJBQWlCLFdBQVc7QUFDbEMsSUFBTUMsV0FBVyxHQUFJQyxHQUFHLElBQUs7RUFDekIsSUFBSTtJQUNBLElBQU1DLFdBQVcsR0FBRzNELG1EQUFPLENBQUNtQixLQUFLLENBQUN5QyxNQUFNLENBQUNGLEdBQUcsQ0FBQztJQUM3QyxJQUFNRyxRQUFRLEdBQUdGLFdBQVcsR0FDdEJOLElBQUksQ0FBQ1MsS0FBSyxDQUFDSCxXQUFXLENBQUMsR0FDdkIsSUFBSTtJQUNWLElBQUksQ0FBQ3ZJLEtBQUssQ0FBQzJJLE9BQU8sQ0FBQ0YsUUFBUSxDQUFDLEVBQ3hCLE9BQU8sRUFBRTtJQUNiLE9BQU9BLFFBQVEsQ0FDVkcsS0FBSyxDQUFDLENBQUMsRUFBRSxHQUFHLENBQUMsQ0FDYkMsR0FBRyxDQUFFdEUsQ0FBQyxJQUFLdUUsTUFBTSxDQUFDQyxRQUFRLENBQUN4RSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FDbEN5RSxNQUFNLENBQUVDLENBQUMsSUFBSyxPQUFPQSxDQUFDLEtBQUssUUFBUSxJQUFJLENBQUNILE1BQU0sQ0FBQ0ksS0FBSyxDQUFDRCxDQUFDLENBQUMsQ0FBQyxDQUN4REosR0FBRyxDQUFDTSxNQUFNLENBQUM7RUFDcEIsQ0FBQyxDQUNELE9BQU9DLEdBQUcsRUFBRTtJQUNSLE9BQU8sRUFBRTtFQUNiO0FBQ0osQ0FBQztBQUNELElBQU1DLG9CQUFvQixHQUFHQSxDQUFBLEtBQU1oQixXQUFXLENBQUNGLGFBQWEsQ0FBQztBQUM3RCxJQUFNbUIsdUJBQXVCLEdBQUdBLENBQUEsS0FBTWpCLFdBQVcsQ0FBQ0QsaUJBQWlCLENBQUM7QUFDcEUsSUFBTW1CLHNCQUFzQixHQUFHQSxDQUFBLEtBQU07RUFDakMzRSxtREFBTyxDQUFDbUIsS0FBSyxDQUFDeUQsTUFBTSxDQUFDckIsYUFBYSxDQUFDO0VBQ25DdkQsbURBQU8sQ0FBQ21CLEtBQUssQ0FBQ3lELE1BQU0sQ0FBQ3BCLGlCQUFpQixDQUFDO0FBQzNDLENBQUM7QUFDTSxJQUFNOUQsQ0FBQyxHQUFHO0VBQ2I2RCxhQUFhO0VBQ2JDLGlCQUFpQjtFQUNqQkM7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0IyRTtBQUNqQztBQUMzQyxJQUFJeUIsU0FBUztBQUNiLENBQUMsVUFBVUEsU0FBUyxFQUFFO0VBQ2xCQSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsbUVBQW1FO0VBQ3ZGQSxTQUFTLENBQUMsTUFBTSxDQUFDLEdBQUcsMERBQTBEO0FBQ2xGLENBQUMsRUFBRUEsU0FBUyxLQUFLQSxTQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqQyxJQUFJQyx3QkFBd0IsR0FBRztFQUMzQkMsWUFBWSxFQUFFNUUsU0FBUztFQUN2QjZFLFVBQVUsRUFBRTdFLFNBQVM7RUFDckI4RSxRQUFRLEVBQUUsVUFBVTtFQUNwQkMsT0FBTyxFQUFFLEVBQUU7RUFDWEMsVUFBVSxFQUFFO0FBQ2hCLENBQUM7QUFDRCxJQUFJQyxhQUFhLEdBQUcsRUFBRTtBQUN0QixJQUFJQyxtQkFBbUIsR0FBRyxFQUFFO0FBQzVCLElBQUlDLFFBQVE7QUFDWixJQUFNQyxXQUFXLEdBQUlDLEtBQUssSUFBTUYsUUFBUSxHQUFHRSxLQUFLLEdBQUdYLFNBQVMsQ0FBQ1ksSUFBSSxHQUFHWixTQUFTLENBQUNhLElBQUs7QUFDbkYsSUFBTUMsZ0JBQWdCLEdBQUlILEtBQUssSUFBTUosYUFBYSxHQUFHSSxLQUFLLEdBQ3BELENBQUM7RUFBRXZFLElBQUksRUFBRSxPQUFPO0VBQUUyRSxLQUFLLEVBQUVwRixNQUFNLENBQUNxRixRQUFRLENBQUNDO0FBQVMsQ0FBQyxDQUFDLEdBQ3BELEVBQUc7QUFDVCxJQUFNQyxzQkFBc0IsR0FBSUMsY0FBYyxJQUFLO0VBQy9DWCxtQkFBbUIsR0FDZlcsY0FBYyxLQUFLN0YsU0FBUyxHQUN0QixDQUNFO0lBQ0ljLElBQUksRUFBRSxnQkFBZ0I7SUFDdEIyRSxLQUFLLEVBQUVJLGNBQWMsQ0FBQzNLLFFBQVEsQ0FBQztFQUNuQyxDQUFDLENBQ0osR0FDQyxFQUFFO0FBQ2hCLENBQUM7QUFDRCxJQUFNNEssd0JBQXdCLEdBQUlDLG9CQUFvQixJQUFLO0VBQ3ZEO0VBQ0EsT0FBT0MsTUFBTSxDQUFDQyxPQUFPLENBQUNGLG9CQUFvQixDQUFDO0FBQy9DLENBQUM7QUFDRCxJQUFNRywrQkFBK0IsR0FBSWxCLFVBQVUsSUFBSztFQUNwRCxPQUFPQSxVQUFVLENBQUN2QixHQUFHLENBQUMzSSxJQUFBO0lBQUEsSUFBQyxDQUFDZ0csSUFBSSxFQUFFMkUsS0FBSyxDQUFDLEdBQUEzSyxJQUFBO0lBQUEsT0FBTTtNQUN0Q2dHLElBQUksRUFBRWlELE1BQU0sQ0FBQ2pELElBQUksQ0FBQztNQUNsQjJFLEtBQUssRUFBRTFCLE1BQU0sQ0FBQzBCLEtBQUs7SUFDdkIsQ0FBQztFQUFBLENBQUMsQ0FBQztBQUNQLENBQUM7QUFDRCxJQUFNVSxjQUFjLEdBQUdBLENBQUNDLE1BQU0sRUFBRUMsUUFBUSxLQUFLO0VBQ3pDLElBQU1DLGFBQWEsR0FBR0YsTUFBTSxDQUFDM0MsR0FBRyxDQUFDOEMsS0FBQTtJQUFBLElBQUM7TUFBRXpGLElBQUk7TUFBRTBGO0lBQUcsQ0FBQyxHQUFBRCxLQUFBO0lBQUEsT0FBTTtNQUNoRHpGLElBQUk7TUFDSjJFLEtBQUssRUFBRWdCLElBQUksQ0FBQ0MsSUFBSSxDQUFDRixFQUFFO0lBQ3ZCLENBQUM7RUFBQSxDQUFDLENBQUM7RUFDSCxJQUFNRyxlQUFlLEdBQUdOLFFBQVEsQ0FBQzVDLEdBQUcsQ0FBQ21ELEtBQUE7SUFBQSxJQUFDO01BQUU5RixJQUFJO01BQUUrRjtJQUFTLENBQUMsR0FBQUQsS0FBQTtJQUFBLE9BQU07TUFDMUQ5RixJQUFJO01BQ0oyRSxLQUFLLEVBQUVnQixJQUFJLENBQUNDLElBQUksQ0FBQ0csUUFBUTtJQUM3QixDQUFDO0VBQUEsQ0FBQyxDQUFDO0VBQ0gsT0FBTyxDQUFDLEdBQUdQLGFBQWEsRUFBRSxHQUFHSyxlQUFlLENBQUM7QUFDakQsQ0FBQztBQUNELFNBQVNHLFdBQVdBLENBQUEsRUFBRztFQUNuQnZDLG1EQUFHLENBQUMsWUFBWSxFQUFFLGtDQUFrQyxFQUFFSSx3QkFBd0IsQ0FBQztFQUMvRSxLQUFLb0MsS0FBSyxDQUFDNUIsUUFBUSxFQUFFO0lBQ2pCNkIsTUFBTSxFQUFFLE1BQU07SUFDZEMsSUFBSSxFQUFFcEUsSUFBSSxDQUFDQyxTQUFTLENBQUM2Qix3QkFBd0IsQ0FBQztJQUM5Q3VDLFNBQVMsRUFBRSxJQUFJO0lBQ2ZDLEtBQUssRUFBRSxVQUFVO0lBQ2pCQyxJQUFJLEVBQUU7RUFDVixDQUFDLENBQUM7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLGVBQWUsR0FBR0EsQ0FBQSxLQUFNLE9BQU9oSCxNQUFNLENBQUNDLFFBQVEsQ0FBQ2dILFlBQVksS0FBSyxRQUFRLEdBQ3hFLENBQ0U7RUFDSXhHLElBQUksRUFBRSxjQUFjO0VBQ3BCMkUsS0FBSyxFQUFFcEYsTUFBTSxDQUFDQyxRQUFRLENBQUNnSDtBQUMzQixDQUFDLENBQ0osR0FDQyxFQUFFO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLHNCQUFzQixHQUFHLFNBQUFBLENBQUE7RUFBQSxTQUFBQyxJQUFBLEdBQUF6SCxTQUFBLENBQUFkLE1BQUEsRUFBSXdJLEtBQUssT0FBQTdNLEtBQUEsQ0FBQTRNLElBQUEsR0FBQUUsSUFBQSxNQUFBQSxJQUFBLEdBQUFGLElBQUEsRUFBQUUsSUFBQTtJQUFMRCxLQUFLLENBQUFDLElBQUEsSUFBQTNILFNBQUEsQ0FBQTJILElBQUE7RUFBQTtFQUFBLE9BQUtyRCwyREFBVyxDQUFDb0QsS0FBSyxDQUFDLENBQUNoRSxHQUFHLENBQUNrRSxLQUFBO0lBQUEsSUFBQztNQUFFQyxNQUFNLEVBQUU7UUFBRUMsWUFBWTtRQUFFL0csSUFBSTtRQUFFZ0g7TUFBTyxDQUFDO01BQUVqQjtJQUFTLENBQUMsR0FBQWMsS0FBQTtJQUFBLE9BQU07TUFDM0g3RyxJQUFJLEVBQUUsQ0FBQytHLFlBQVksRUFBRS9HLElBQUksRUFBRWdILE1BQU0sQ0FBQyxDQUFDbEUsTUFBTSxDQUFDVSx5REFBYSxDQUFDLENBQUN5RCxJQUFJLENBQUMsR0FBRyxDQUFDO01BQ2xFdEMsS0FBSyxFQUFFb0I7SUFDWCxDQUFDO0VBQUEsQ0FBQyxDQUFDO0FBQUE7QUFDSCxTQUFTbUIseUJBQXlCQSxDQUFBLEVBQUc7RUFDakM7RUFDQSxJQUFNQyxVQUFVLEdBQUd4RCxvREFBVSxDQUFDN0QsR0FBRyxDQUFDLENBQUM7RUFDbkMsSUFBTXNILGtCQUFrQixHQUFHcEMsd0JBQXdCLENBQUNtQyxVQUFVLENBQUNqRCxVQUFVLENBQUM7RUFDMUUsSUFBTW1ELDRCQUE0QixHQUFHRCxrQkFBa0IsQ0FBQ3RFLE1BQU0sQ0FBRXdFLElBQUksSUFBSyxPQUFPQSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxDQUFDO0VBQ3hHLElBQU1DLDBCQUEwQixHQUFHbkMsK0JBQStCLENBQUNpQyw0QkFBNEIsQ0FBQztFQUNoRyxJQUFNbkQsVUFBVSxHQUFHcUQsMEJBQTBCLENBQ3hDbE4sTUFBTSxDQUFDOEosYUFBYSxDQUFDLENBQ3JCOUosTUFBTSxDQUFDK0osbUJBQW1CLENBQUM7RUFDaENQLHdCQUF3QixDQUFDSyxVQUFVLEdBQUdBLFVBQVU7RUFDaEQsSUFBTUQsT0FBTyxHQUFHb0IsY0FBYyxDQUFDOEIsVUFBVSxDQUFDSyxLQUFLLEVBQUVMLFVBQVUsQ0FBQzVCLFFBQVEsQ0FBQyxDQUNoRWxMLE1BQU0sQ0FBQ2tNLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FDekJsTSxNQUFNLENBQUNvTSxzQkFBc0IsQ0FBQyxRQUFRLENBQUMsQ0FBQztFQUM3QzVDLHdCQUF3QixDQUFDSSxPQUFPLEdBQUdBLE9BQU87RUFDMUMrQixXQUFXLENBQUMsQ0FBQztBQUNqQjtBQUNBLElBQU15QixRQUFRLEdBQUlDLENBQUMsSUFBSztFQUNwQixJQUFJbkksTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ2tJLDJCQUEyQixFQUFFO0lBQ3BELFFBQVFELENBQUMsQ0FBQ0UsSUFBSTtNQUNWLEtBQUssa0JBQWtCO1FBQ25CLElBQUlDLFFBQVEsQ0FBQ0MsZUFBZSxLQUFLLFFBQVEsRUFBRTtVQUN2Q1oseUJBQXlCLENBQUMsQ0FBQztRQUMvQjtRQUNBO01BQ0osS0FBSyxVQUFVO1FBQ1hBLHlCQUF5QixDQUFDLENBQUM7UUFDM0I7SUFDUjtFQUNKO0FBQ0osQ0FBQztBQUNELElBQU1hLHNCQUFzQixHQUFHQSxDQUFBLEtBQU07RUFDakM7RUFDQXhJLE1BQU0sQ0FBQ3lJLGdCQUFnQixDQUFDLGtCQUFrQixFQUFFUCxRQUFRLEVBQUU7SUFBRVEsSUFBSSxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQ3JFO0VBQ0ExSSxNQUFNLENBQUN5SSxnQkFBZ0IsQ0FBQyxVQUFVLEVBQUVQLFFBQVEsRUFBRTtJQUFFUSxJQUFJLEVBQUU7RUFBSyxDQUFDLENBQUM7QUFDakUsQ0FBQztBQUNELElBQU1DLFlBQVk7RUFBQSxJQUFBQyxLQUFBLEdBQUFDLGlCQUFBLENBQUcsYUFBWTtJQUM3QixJQUFNQyxZQUFZLFNBQVMzRSx5REFBUyxDQUFDLENBQUM7SUFDdEMsSUFBSTJFLFlBQVksQ0FBQ0MsS0FBSyxFQUFFO01BQ3BCO01BQ0EsSUFBTUMsUUFBUSxHQUFHRixZQUFZLENBQUNDLEtBQUssQ0FBQ0MsUUFBUTtNQUM1QyxJQUFNQyxpQkFBaUIsR0FBRyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7TUFDaEMsT0FBT0EsaUJBQWlCLENBQUNDLEtBQUssQ0FBRUMsT0FBTyxJQUFLSCxRQUFRLENBQUNHLE9BQU8sQ0FBQyxDQUFDO0lBQ2xFO0lBQ0E7SUFDQSxPQUFPLElBQUk7RUFDZixDQUFDO0VBQUEsZ0JBVktSLFlBQVlBLENBQUE7SUFBQSxPQUFBQyxLQUFBLENBQUFRLEtBQUEsT0FBQTFKLFNBQUE7RUFBQTtBQUFBLEdBVWpCO0FBQ0Q7QUFDQTtBQUNBO0FBRkEsU0FHZTJKLCtCQUErQkEsQ0FBQTtFQUFBLE9BQUFDLGdDQUFBLENBQUFGLEtBQUEsT0FBQTFKLFNBQUE7QUFBQTtBQWE5QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFSQSxTQUFBNEosaUNBQUE7RUFBQUEsZ0NBQUEsR0FBQVQsaUJBQUEsQ0FiQSxhQUFpRDtJQUM3QyxJQUFJLENBQUM3SSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDcUosNEJBQTRCLEVBQUU7TUFDdERDLE9BQU8sQ0FBQ0MsSUFBSSxDQUFDLDJDQUEyQyxDQUFDO01BQ3pEO0lBQ0o7SUFDQSxJQUFNQyxTQUFTLFNBQVNmLFlBQVksQ0FBQyxDQUFDO0lBQ3RDLElBQUllLFNBQVMsRUFBRTtNQUNYMUosTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ2tJLDJCQUEyQixHQUFHLElBQUk7SUFDN0QsQ0FBQyxNQUNJO01BQ0RsRSxtREFBRyxDQUFDLFlBQVksRUFBRSxvREFBb0QsQ0FBQztJQUMzRTtFQUNKLENBQUM7RUFBQSxPQUFBb0YsZ0NBQUEsQ0FBQUYsS0FBQSxPQUFBMUosU0FBQTtBQUFBO0FBQUEsU0FVY2lLLHFCQUFxQkEsQ0FBQUMsRUFBQTtFQUFBLE9BQUFDLHNCQUFBLENBQUFULEtBQUEsT0FBQTFKLFNBQUE7QUFBQTtBQUFBLFNBQUFtSyx1QkFBQTtFQUFBQSxzQkFBQSxHQUFBaEIsaUJBQUEsQ0FBcEMsV0FBQWlCLEtBQUEsRUFBNEc7SUFBQSxJQUF2RTtNQUFFQyxVQUFVO01BQUVDLFNBQVM7TUFBRWhGLEtBQUs7TUFBRVEsY0FBYztNQUFFeUUsUUFBUSxHQUFHLENBQUMsR0FBRztJQUFLLENBQUMsR0FBQUgsS0FBQTtJQUN0R3hGLHdCQUF3QixDQUFDQyxZQUFZLEdBQUd3RixVQUFVO0lBQ2xEekYsd0JBQXdCLENBQUNFLFVBQVUsR0FBR3dGLFNBQVM7SUFDL0NqRixXQUFXLENBQUNDLEtBQUssQ0FBQztJQUNsQkcsZ0JBQWdCLENBQUNILEtBQUssQ0FBQztJQUN2Qk8sc0JBQXNCLENBQUNDLGNBQWMsQ0FBQztJQUN0Q2dELHNCQUFzQixDQUFDLENBQUM7SUFDeEIsSUFBSXhJLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNxSiw0QkFBNEIsRUFBRTtNQUNyRCxPQUFPLEtBQUs7SUFDaEI7SUFDQXZKLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNxSiw0QkFBNEIsR0FBRyxJQUFJO0lBQzFELElBQU1XLHFCQUFxQixHQUFHOUQsSUFBSSxDQUFDK0QsTUFBTSxDQUFDLENBQUMsSUFBSUYsUUFBUTtJQUN2RCxJQUFJakYsS0FBSyxJQUFJa0YscUJBQXFCLEVBQUU7TUFDaEMsSUFBTVIsU0FBUyxTQUFTZixZQUFZLENBQUMsQ0FBQztNQUN0QyxJQUFJZSxTQUFTLEVBQUU7UUFDWDFKLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNrSSwyQkFBMkIsR0FBRyxJQUFJO1FBQ3pELE9BQU8sSUFBSTtNQUNmO01BQ0FsRSxtREFBRyxDQUFDLFlBQVksRUFBRSxvREFBb0QsQ0FBQztJQUMzRTtJQUNBLE9BQU8sS0FBSztFQUNoQixDQUFDO0VBQUEsT0FBQTJGLHNCQUFBLENBQUFULEtBQUEsT0FBQTFKLFNBQUE7QUFBQTtBQUNNLElBQU1iLENBQUMsR0FBRztFQUNid0YsU0FBUztFQUNUVSxXQUFXO0VBQ1hjLCtCQUErQjtFQUMvQkMsY0FBYztFQUNkTCx3QkFBd0I7RUFDeEIyRSxLQUFLLEVBQUVBLENBQUEsS0FBTTtJQUNUcEssTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ3FKLDRCQUE0QixHQUFHLEtBQUs7SUFDM0R2SixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDa0ksMkJBQTJCLEdBQUcsS0FBSztJQUMxRDlELHdCQUF3QixHQUFHO01BQ3ZCQyxZQUFZLEVBQUU1RSxTQUFTO01BQ3ZCNkUsVUFBVSxFQUFFN0UsU0FBUztNQUNyQjhFLFFBQVEsRUFBRSxVQUFVO01BQ3BCQyxPQUFPLEVBQUUsRUFBRTtNQUNYQyxVQUFVLEVBQUU7SUFDaEIsQ0FBQztJQUNEMEYsbUJBQW1CLENBQUMsa0JBQWtCLEVBQUVuQyxRQUFRLENBQUM7SUFDakRtQyxtQkFBbUIsQ0FBQyxVQUFVLEVBQUVuQyxRQUFRLENBQUM7RUFDN0M7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFNd0U7QUFDakI7QUFDVjtBQUNFO0FBQ1U7QUFDVjtBQUNZO0FBQ1Y7QUFDbEQsSUFBTTZDLFlBQVksR0FBSUMsV0FBVyxJQUFLO0VBQ2xDLElBQU1DLFFBQVEsR0FBRyxDQUFDLENBQUM7RUFDbkIsS0FBSyxJQUFNcEksR0FBRyxJQUFJbUksV0FBVyxFQUFFO0lBQzNCLElBQU01RixLQUFLLEdBQUc0RixXQUFXLENBQUNuSSxHQUFHLENBQUM7SUFDOUIsSUFBSTNELHdEQUFRLENBQUNrRyxLQUFLLENBQUMsRUFBRTtNQUNqQjZGLFFBQVEsQ0FBQ3BJLEdBQUcsQ0FBQyxHQUFHdUMsS0FBSztJQUN6QixDQUFDLE1BQ0ksSUFBSTdLLEtBQUssQ0FBQzJJLE9BQU8sQ0FBQ2tDLEtBQUssQ0FBQyxJQUN6QkEsS0FBSyxDQUFDeEcsTUFBTSxHQUFHLENBQUMsSUFDaEJ3RyxLQUFLLENBQUM4RCxLQUFLLENBQUNoSyxvREFBUSxDQUFDLEVBQUU7TUFDdkIrTCxRQUFRLENBQUNwSSxHQUFHLENBQUMsR0FBR3VDLEtBQUs7SUFDekI7RUFDSjtFQUNBLE9BQU82RixRQUFRO0FBQ25CLENBQUM7QUFDRCxJQUFNQyxvQ0FBb0MsR0FBR0EsQ0FBQSxLQUFNO0VBQy9DLElBQUksQ0FBQ1Ysb0VBQXNCLENBQUMsQ0FBQyxFQUFFO0lBQzNCLE9BQU8sS0FBSztFQUNoQjtFQUNBLElBQU1XLGdCQUFnQixHQUFHQyxXQUFXLENBQUNDLGdCQUFnQixDQUFDLFlBQVksQ0FBQztFQUNuRSxJQUFNQyxtQkFBbUIsR0FBR0gsZ0JBQWdCLENBQUNBLGdCQUFnQixDQUFDdk0sTUFBTSxHQUFHLENBQUMsQ0FBQztFQUN6RTtFQUNBLE9BQU8sQ0FBQTBNLG1CQUFtQixhQUFuQkEsbUJBQW1CLHVCQUFuQkEsbUJBQW1CLENBQUVDLFNBQVMsTUFBSyxZQUFZO0FBQzFELENBQUM7QUFDRCxJQUFNQyxtQkFBbUIsR0FBSUMsUUFBUSxJQUFLO0VBQ3RDLElBQUksQ0FBQ0EsUUFBUSxFQUFFO0lBQ1gsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBTUMsV0FBVyxHQUFHLElBQUlDLEdBQUcsQ0FBQ0YsUUFBUSxDQUFDO0VBQ3JDLE9BQU9DLFdBQVcsQ0FBQ3BHLFFBQVEsS0FBS3RGLE1BQU0sQ0FBQ3FGLFFBQVEsQ0FBQ0MsUUFBUTtBQUM1RCxDQUFDO0FBQ0Q7QUFDQSxJQUFNc0csWUFBWSxHQUFJSCxRQUFRLElBQUs7RUFDL0IsSUFBSWpCLG9FQUFzQixDQUFDLENBQUMsSUFBSSxDQUFDVSxvQ0FBb0MsQ0FBQyxDQUFDLEVBQUU7SUFDckUsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsT0FBTyxDQUFDTSxtQkFBbUIsQ0FBQ0MsUUFBUSxDQUFDO0FBQ3pDLENBQUM7QUFDRCxJQUFNSSxrQkFBa0IsR0FBR3BSLElBQUEsSUFBOEY7RUFBQSxJQUFBcVIsb0JBQUEsRUFBQUMscUJBQUE7RUFBQSxJQUE3RjtJQUFFQyxNQUFNO0lBQUVDLHdCQUF3QjtJQUFFbkQsWUFBWTtJQUFFb0QsVUFBVSxHQUFHLEtBQUs7SUFBRUMsT0FBTyxHQUFHO0VBQU8sQ0FBQyxHQUFBMVIsSUFBQTtFQUNoSCxJQUFNO0lBQUUwRixJQUFJO0lBQUVpTTtFQUFrQixDQUFDLEdBQUdwTSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTTtFQUMxRCxJQUFNbU0sZUFBZSxHQUFHTCxNQUFNLEdBQUc7SUFBRU0sRUFBRSxFQUFFO0VBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNqRCxJQUFNQyxpQkFBaUIsR0FBR3BNLElBQUksQ0FBQ29NLGlCQUFpQixHQUMxQzFCLDJEQUFrQixDQUFDMUssSUFBSSxDQUFDb00saUJBQWlCLENBQUMsR0FDMUMsQ0FBQyxDQUFDO0VBQ1IsSUFBTUMsZ0JBQWdCLEdBQUcvQiw2REFBbUIsQ0FBQztJQUN6Q2dDLGtCQUFrQixFQUFFdE0sSUFBSSxDQUFDc00sa0JBQWtCO0lBQzNDQyxjQUFjLEVBQUV2TSxJQUFJLENBQUN3TSxjQUFjO0lBQ25DQyxJQUFJLE1BQUE5UixNQUFBLENBQU1xRixJQUFJLENBQUMwTSxNQUFNLENBQUU7SUFDdkJDLGlCQUFpQixFQUFFVixpQkFBaUIsR0FDOUIsa0JBQWtCLEdBQ2xCLGlCQUFpQjtJQUN2QlcsT0FBTyxFQUFFNU0sSUFBSSxDQUFDNE0sT0FBTztJQUNyQkMsU0FBUyxFQUFFN00sSUFBSSxDQUFDOE0sV0FBVztJQUMzQkMsV0FBVyxFQUFFL00sSUFBSSxDQUFDZ04sYUFBYTtJQUMvQkMsUUFBUSxHQUFBdEIsb0JBQUEsR0FBRVMsaUJBQWlCLENBQUNjLENBQUMsY0FBQXZCLG9CQUFBLGNBQUFBLG9CQUFBLEdBQUk7RUFDckMsQ0FBQyxDQUFDO0VBQ0YsSUFBTUwsUUFBUSxHQUFHbkQsUUFBUSxDQUFDbUQsUUFBUSxJQUFJLEVBQUU7RUFDeEMsSUFBTTZCLGdCQUFnQixHQUFHM0MsNkRBQW1CLENBQUM7SUFDekM0QyxNQUFNLEVBQUV0Tyx5REFBUyxDQUFDO01BQUV3QixJQUFJLEVBQUUsUUFBUTtNQUFFQyxhQUFhLEVBQUU7SUFBSyxDQUFDLENBQUM7SUFDMUQ4TSxXQUFXLEVBQUV4TCwwREFBUyxDQUFDLENBQUM7SUFDeEJ5TCxTQUFTLEVBQUU3QyxxREFBWSxDQUFDLENBQUM7SUFDekJzQixVQUFVO0lBQ1ZuQyxVQUFVLEVBQUUvSixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDd04sS0FBSyxDQUFDM0QsVUFBVTtJQUNuRDRELGNBQWMsRUFBRTtNQUNaMUIsd0JBQXdCO01BQ3hCMkIsd0JBQXdCLEdBQUE3QixxQkFBQSxHQUFFL0wsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQzJOLEtBQUssY0FBQTlCLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQztJQUMvRCxDQUFDO0lBQ0ROO0VBQ0osQ0FBQyxDQUFDO0VBQ0YsSUFBTXFDLFdBQVcsR0FBR0EsQ0FBQSxLQUFNO0lBQ3RCLE9BQU87TUFDSHBULEtBQUssRUFBRXNGLE1BQU0sQ0FBQytOLFVBQVUsSUFBSXpGLFFBQVEsQ0FBQzFCLElBQUksQ0FBQ29ILFdBQVcsSUFBSSxDQUFDO01BQzFEclQsTUFBTSxFQUFFcUYsTUFBTSxDQUFDaU8sV0FBVyxJQUFJM0YsUUFBUSxDQUFDMUIsSUFBSSxDQUFDc0gsWUFBWSxJQUFJO0lBQ2hFLENBQUM7RUFDTCxDQUFDO0VBQ0QsSUFBTUMsaUJBQWlCLEdBQUdyRCwrREFBb0IsQ0FBQztJQUMzQ3NELGFBQWEsRUFBRU4sV0FBVyxDQUFDLENBQUMsQ0FBQ3BULEtBQUs7SUFDbEMyVCxpQkFBaUIsRUFBRSxDQUFDL0QsK0NBQUcsQ0FBQ2dFLGNBQWMsQ0FBQyxDQUFDLElBQUloRSwrQ0FBRyxDQUFDaUUsMEJBQTBCLENBQUM7RUFDL0UsQ0FBQyxDQUFDO0VBQ0YsSUFBTUMscUJBQXFCLEdBQUc5RCx1RUFBd0IsQ0FBQztJQUNuRCtELEtBQUssRUFBRTNGLFlBQVk7SUFDbkJxRDtFQUNKLENBQUMsQ0FBQztFQUNGLElBQU11QyxvQkFBb0IsR0FBRyxDQUFDLENBQUM7RUFDL0IsSUFBSSxDQUFDbkUsNkRBQWEsQ0FBQyxXQUFXLEVBQUV6QixZQUFZLENBQUMsRUFBRTtJQUMzQzRGLG9CQUFvQixDQUFDQyxVQUFVLEdBQUcvQyxZQUFZLENBQUNILFFBQVEsQ0FBQyxHQUFHLEdBQUcsR0FBRyxHQUFHO0VBQ3hFO0VBQ0EsSUFBTVQsV0FBVyxHQUFBN04sYUFBQSxDQUFBQSxhQUFBLENBQUFBLGFBQUEsQ0FBQUEsYUFBQSxDQUFBQSxhQUFBLENBQUFBLGFBQUEsQ0FBQUEsYUFBQSxLQUNWcVIscUJBQXFCLEdBQ3JCakMsaUJBQWlCLEdBQ2pCRixlQUFlLEdBQ2ZHLGdCQUFnQixHQUNoQmMsZ0JBQWdCLEdBQ2hCYSxpQkFBaUIsR0FDakJPLG9CQUFvQixDQUMxQjtFQUNEO0VBQ0EsSUFBTUUsYUFBYSxHQUFHN0QsWUFBWSxDQUFDQyxXQUFXLENBQUM7RUFDL0MsT0FBTzRELGFBQWE7QUFDeEIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztBQzNHeUM7QUFDMUM7QUFDQSxJQUFNQyxZQUFZLEdBQUcsQ0FDakIsSUFBSTtBQUFFO0FBQ04sSUFBSSxFQUNKLElBQUksRUFDSixJQUFJLEVBQ0osS0FBSyxFQUNMLEtBQUssRUFDTCxLQUFLLEVBQ0wsS0FBSyxFQUNMLEtBQUssRUFDTCxLQUFLLEVBQ0wsS0FBSyxDQUNSO0FBQ0Q7QUFDQSxJQUFNQyxjQUFjLEdBQUk1QixXQUFXLElBQUs7RUFBQSxJQUFBNkIsbUJBQUE7RUFDcEMsSUFBTUMsS0FBSyxHQUFHNUksSUFBSSxDQUFDNkksR0FBRyxDQUFDN0ksSUFBSSxDQUFDQyxJQUFJLENBQUM2RyxXQUFXLEdBQUcsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDO0VBQ3ZELFFBQUE2QixtQkFBQSxHQUFPRixZQUFZLENBQUNHLEtBQUssQ0FBQyxjQUFBRCxtQkFBQSxjQUFBQSxtQkFBQSxHQUFJLElBQUk7QUFDdEMsQ0FBQztBQUNELElBQU1HLGNBQWMsR0FBSUMsR0FBRyxJQUFLO0VBQzVCLElBQU1DLFdBQVcsR0FBR0QsR0FBRyxDQUNsQkUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUNWOUwsTUFBTSxDQUFDK0wsT0FBTyxDQUFDLENBQUM7RUFBQSxDQUNoQm5NLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUNqQixPQUFPakUsd0RBQVEsQ0FBQ2tRLFdBQVcsQ0FBQyxHQUFHQSxXQUFXLENBQUNDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzlMLE1BQU0sQ0FBQytMLE9BQU8sQ0FBQyxHQUFHLEVBQUU7QUFDOUUsQ0FBQztBQUNELElBQU1DLFlBQVksR0FBR0EsQ0FBQ0MsQ0FBQyxFQUFFL1EsQ0FBQyxLQUFLLENBQzNCLEdBQUcsSUFBSWdSLEdBQUcsQ0FBQyxDQUFDLEdBQUdELENBQUMsRUFBRSxHQUFHL1EsQ0FBQyxDQUFDLENBQUMsQ0FDM0I7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTWlSLGdDQUFnQyxHQUFJakQsa0JBQWtCLElBQUs7RUFDN0QsSUFBTWtELEdBQUcsR0FBR0MsSUFBSSxDQUFDRCxHQUFHLENBQUMsQ0FBQztFQUN0QixJQUFNRSxxQkFBcUIsR0FBRyxDQUFDRixHQUFHLEdBQUdsRCxrQkFBa0IsSUFBSSxJQUFJLEdBQUcsRUFBRSxHQUFHLEVBQUU7RUFDekUsSUFBTXFELG9CQUFvQixHQUFHRCxxQkFBcUIsR0FBRyxFQUFFO0VBQ3ZELElBQU1FLHNCQUFzQixHQUFHRCxvQkFBb0IsR0FBRyxFQUFFLENBQUMsQ0FBQztFQUMxRCxJQUFJRCxxQkFBcUIsR0FBRyxDQUFDLEVBQ3pCLE9BQU8sR0FBRztFQUNkLElBQUlBLHFCQUFxQixHQUFHLEVBQUUsRUFDMUIsT0FBTyxHQUFHO0VBQ2QsSUFBSUMsb0JBQW9CLEdBQUcsQ0FBQyxFQUN4QixPQUFPLEdBQUc7RUFDZCxJQUFJQSxvQkFBb0IsR0FBRyxDQUFDLEVBQ3hCLE9BQU8sR0FBRztFQUNkLElBQUlBLG9CQUFvQixHQUFHLEVBQUUsRUFDekIsT0FBTyxHQUFHO0VBQ2QsSUFBSUMsc0JBQXNCLEdBQUcsRUFBRSxFQUMzQixPQUFPLEdBQUc7RUFDZCxJQUFJQSxzQkFBc0IsR0FBRyxFQUFFLEVBQzNCLE9BQU8sR0FBRztFQUNkLE9BQU8sR0FBRztBQUNkLENBQUM7QUFDRCxJQUFNdEYsbUJBQW1CLEdBQUdoUSxJQUFBLElBQWlIO0VBQUEsSUFBaEg7SUFBRWlTLGNBQWM7SUFBRUUsSUFBSTtJQUFFRSxpQkFBaUI7SUFBRUMsT0FBTztJQUFFQyxTQUFTO0lBQUVFLFdBQVc7SUFBRVQsa0JBQWtCO0lBQUVXO0VBQVUsQ0FBQyxHQUFBM1MsSUFBQTtFQUNwSSxJQUFNdVYsS0FBSyxHQUFHZCxjQUFjLENBQUN0QyxJQUFJLENBQUM7RUFDbEMsT0FBTztJQUNIcUQsSUFBSSxFQUFFdkQsY0FBYyxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQ2hDd0QsRUFBRSxFQUFFUixnQ0FBZ0MsQ0FBQ2pELGtCQUFrQixDQUFDO0lBQ3hEMEQsRUFBRSxFQUFFckQsaUJBQWlCO0lBQ3JCaE8sQ0FBQyxFQUFFaU8sT0FBTztJQUNWcUQsSUFBSSxFQUFFcEQsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQzNCZ0QsS0FBSztJQUNMSyxFQUFFLEVBQUVuRCxXQUFXLEdBQUc0QixjQUFjLENBQUM1QixXQUFXLENBQUMsR0FBRyxJQUFJO0lBQ3BEb0QsS0FBSyxFQUFFZixZQUFZLENBQUNTLEtBQUssRUFBRTVDLFFBQVE7RUFDdkMsQ0FBQztBQUNMLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RXdDO0FBQzZEO0FBQ3RHO0FBQ0EsSUFBTW1ELFNBQVMsR0FBRyxDQUNkLEdBQUcsRUFDSCxHQUFHLEVBQ0gsR0FBRyxFQUNILEdBQUcsRUFDSCxHQUFHLEVBQ0gsR0FBRyxFQUNILEtBQUssRUFDTCxPQUFPLEVBQ1AsT0FBTyxFQUNQLE9BQU8sRUFDUCxRQUFRLENBQ1g7QUFDRCxJQUFNQyxrQkFBa0IsR0FBRyxtQkFBbUI7QUFDOUMsSUFBTUMsZUFBZSxHQUFHLENBQ3BCLEdBQUcsRUFDSCxHQUFHLEVBQ0gsR0FBRyxFQUNILEdBQUcsRUFDSCxHQUFHLEVBQ0gsR0FBRyxFQUNILEdBQUcsRUFDSCxHQUFHLEVBQ0gsR0FBRyxFQUNILElBQUksRUFDSixJQUFJLEVBQ0osSUFBSSxDQUNQO0FBQ0Q7QUFDQSxJQUFNQyxpQkFBaUIsR0FBR0EsQ0FBQzdOLEdBQUcsRUFBRTRMLEtBQUssS0FBSztFQUN0QyxJQUFJQSxLQUFLLENBQUMxRixLQUFLLEVBQUU7SUFDYixJQUFJMEYsS0FBSyxDQUFDMUYsS0FBSyxDQUFDQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQ3pCLE9BQU83SixtREFBTyxDQUFDbUIsS0FBSyxDQUFDeUMsTUFBTSxDQUFDRixHQUFHLENBQUM7RUFDeEM7RUFDQSxJQUFJNEwsS0FBSyxDQUFDa0MsS0FBSyxFQUFFO0lBQ2IsSUFBSSxDQUFDbEMsS0FBSyxDQUFDa0MsS0FBSyxDQUFDQyxTQUFTLEVBQ3RCLE9BQU96UixtREFBTyxDQUFDbUIsS0FBSyxDQUFDeUMsTUFBTSxDQUFDRixHQUFHLENBQUM7RUFDeEM7RUFDQSxJQUFJNEwsS0FBSyxDQUFDb0MsR0FBRyxFQUFFO0lBQ1gsSUFBSXBDLEtBQUssQ0FBQ29DLEdBQUcsQ0FBQ0MsdUJBQXVCLEVBQ2pDLE9BQU8zUixtREFBTyxDQUFDbUIsS0FBSyxDQUFDeUMsTUFBTSxDQUFDRixHQUFHLENBQUM7RUFDeEM7RUFDQSxPQUFPLElBQUk7QUFDZixDQUFDO0FBQ0QsSUFBTWtPLGlCQUFpQixHQUFJdEMsS0FBSyxJQUFLO0VBQ2pDLElBQU11QyxRQUFRLEdBQUdOLGlCQUFpQixDQUFDLG1CQUFtQixFQUFFakMsS0FBSyxDQUFDO0VBQzlELElBQUksQ0FBQ3VDLFFBQVEsRUFDVCxPQUFPLEdBQUc7RUFDZCxJQUFNQyxVQUFVLEdBQUczTixRQUFRLENBQUMwTixRQUFRLEVBQUUsRUFBRSxDQUFDO0VBQ3pDLElBQUlDLFVBQVUsSUFBSSxDQUFDLEVBQUU7SUFBQSxJQUFBQyxxQkFBQTtJQUNqQixRQUFBQSxxQkFBQSxHQUFPWCxTQUFTLENBQUNVLFVBQVUsQ0FBQyxjQUFBQyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEdBQUc7RUFDdkMsQ0FBQyxNQUNJLElBQUlELFVBQVUsSUFBSSxDQUFDLElBQUlBLFVBQVUsSUFBSSxDQUFDLEVBQUU7SUFDekMsT0FBTyxLQUFLO0VBQ2hCLENBQUMsTUFDSSxJQUFJQSxVQUFVLElBQUksRUFBRSxJQUFJQSxVQUFVLElBQUksRUFBRSxFQUFFO0lBQzNDLE9BQU8sT0FBTztFQUNsQixDQUFDLE1BQ0ksSUFBSUEsVUFBVSxJQUFJLEVBQUUsSUFBSUEsVUFBVSxJQUFJLEVBQUUsRUFBRTtJQUMzQyxPQUFPLE9BQU87RUFDbEIsQ0FBQyxNQUNJLElBQUlBLFVBQVUsSUFBSSxFQUFFLElBQUlBLFVBQVUsSUFBSSxFQUFFLEVBQUU7SUFDM0MsT0FBTyxPQUFPO0VBQ2xCLENBQUMsTUFDSSxJQUFJQSxVQUFVLElBQUksRUFBRSxFQUFFO0lBQ3ZCLE9BQU8sUUFBUTtFQUNuQjtFQUNBLE9BQU8sR0FBRztBQUNkLENBQUM7QUFDRCxJQUFNRSxlQUFlLEdBQUkxQyxLQUFLLElBQUs7RUFDL0IsSUFBSUEsS0FBSyxDQUFDMUYsS0FBSyxFQUFFO0lBQ2IsT0FBTztNQUNIcUksZUFBZSxFQUFFM0MsS0FBSyxDQUFDMUYsS0FBSyxDQUFDc0ksV0FBVztNQUN4Q0MsRUFBRSxFQUFFN0MsS0FBSyxDQUFDOEMsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO01BQy9CQyxhQUFhLEVBQUUvQyxLQUFLLENBQUM4QyxTQUFTLEdBQUcsR0FBRyxHQUFHLEdBQUc7TUFDMUNFLEdBQUcsRUFBRTtJQUNULENBQUM7RUFDTDtFQUNBLElBQUloRCxLQUFLLENBQUNrQyxLQUFLLEVBQUU7SUFDYixPQUFPO01BQ0hhLGFBQWEsRUFBRSxJQUFJO01BQ25CQyxHQUFHLEVBQUUsQ0FBQ2hELEtBQUssQ0FBQzhDLFNBQVMsR0FBRyxHQUFHLEdBQUcsR0FBRztNQUNqQ0QsRUFBRSxFQUFFN0MsS0FBSyxDQUFDOEMsU0FBUyxHQUFHLEdBQUcsR0FBRztJQUNoQyxDQUFDO0VBQ0w7RUFDQSxJQUFJOUMsS0FBSyxDQUFDb0MsR0FBRyxFQUFFO0lBQ1gsT0FBTztNQUNIVyxhQUFhLEVBQUUsSUFBSTtNQUNuQkMsR0FBRyxFQUFFLElBQUk7TUFDVEgsRUFBRSxFQUFFN0MsS0FBSyxDQUFDOEMsU0FBUyxHQUFHLEdBQUcsR0FBRztJQUNoQyxDQUFDO0VBQ0w7RUFDQSxPQUFPO0lBQ0hILGVBQWUsRUFBRSxJQUFJO0lBQ3JCSSxhQUFhLEVBQUUsSUFBSTtJQUNuQkMsR0FBRyxFQUFFLElBQUk7SUFDVEgsRUFBRSxFQUFFO0VBQ1IsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNSSxnQkFBZ0IsR0FBSTVTLENBQUMsSUFBSzJSLGVBQWUsQ0FBQ2tCLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLEtBQUs5UyxDQUFDLENBQUM7QUFDcEUsSUFBTStTLG9CQUFvQixHQUFHQSxDQUFBLEtBQU07RUFBQSxJQUFBQyxxQkFBQTtFQUMvQixJQUFNOUMsS0FBSyxHQUFHNUksSUFBSSxDQUFDMkwsS0FBSyxDQUFDM0wsSUFBSSxDQUFDK0QsTUFBTSxDQUFDLENBQUMsR0FBR3NHLGVBQWUsQ0FBQzdSLE1BQU0sQ0FBQztFQUNoRSxJQUFNb1QsS0FBSyxJQUFBRixxQkFBQSxHQUFHckIsZUFBZSxDQUFDekIsS0FBSyxDQUFDLGNBQUE4QyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLElBQUk7RUFDNUMzUyxtREFBTyxDQUFDbUIsS0FBSyxDQUFDMlIsTUFBTSxDQUFDekIsa0JBQWtCLEVBQUV3QixLQUFLLENBQUM7RUFDL0MsT0FBT0EsS0FBSztBQUNoQixDQUFDO0FBQ0QsSUFBTUUsaUJBQWlCLEdBQUl6RCxLQUFLLElBQUs7RUFDakMsSUFBSSxDQUFDQSxLQUFLLENBQUMwRCxTQUFTLEVBQUU7SUFDbEJoVCxtREFBTyxDQUFDbUIsS0FBSyxDQUFDeUQsTUFBTSxDQUFDeU0sa0JBQWtCLENBQUM7SUFDeEMsT0FBTyxJQUFJO0VBQ2Y7RUFDQSxJQUFJL0IsS0FBSyxDQUFDMUYsS0FBSyxJQUFJLENBQUMwRixLQUFLLENBQUM4QyxTQUFTLEVBQUU7SUFDakNwUyxtREFBTyxDQUFDbUIsS0FBSyxDQUFDeUQsTUFBTSxDQUFDeU0sa0JBQWtCLENBQUM7SUFDeEMsT0FBTyxJQUFJO0VBQ2Y7RUFDQSxJQUFNNEIsYUFBYSxHQUFHalQsbURBQU8sQ0FBQ21CLEtBQUssQ0FBQ3lDLE1BQU0sQ0FBQ3lOLGtCQUFrQixDQUFDO0VBQzlELE9BQU9rQixnQkFBZ0IsQ0FBQ1UsYUFBYSxDQUFDLEdBQ2hDQSxhQUFhLEdBQ2JQLG9CQUFvQixDQUFDLENBQUM7QUFDaEMsQ0FBQztBQUNELElBQU1RLHFCQUFxQixHQUFHQSxDQUFDNUQsS0FBSyxFQUFFdEMsT0FBTyxLQUFLO0VBQzlDLElBQUlzQyxLQUFLLENBQUM4QyxTQUFTLEVBQUU7SUFDakIsT0FBT3BGLE9BQU8sR0FBR3RJLG1FQUF1QixDQUFDLENBQUMsR0FBR0QsZ0VBQW9CLENBQUMsQ0FBQztFQUN2RTtFQUNBRSxrRUFBc0IsQ0FBQyxDQUFDO0VBQ3hCLE9BQU8sRUFBRTtBQUNiLENBQUM7QUFDRCxJQUFNNEcsd0JBQXdCLEdBQUdqUSxJQUFBO0VBQUEsSUFBQztJQUFFZ1UsS0FBSztJQUFFdEM7RUFBUyxDQUFDLEdBQUExUixJQUFBO0VBQUEsT0FBQTBDLGFBQUE7SUFDakRtVixNQUFNLEVBQUVKLGlCQUFpQixDQUFDekQsS0FBSyxDQUFDO0lBQ2hDOEQsRUFBRSxFQUFFeEIsaUJBQWlCLENBQUN0QyxLQUFLLENBQUM7SUFDNUIrRCxTQUFTLEVBQUVILHFCQUFxQixDQUFDNUQsS0FBSyxFQUFFdEMsT0FBTztFQUFDLEdBQzdDZ0YsZUFBZSxDQUFDMUMsS0FBSyxDQUFDO0FBQUEsQ0FDM0I7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2SXdDO0FBQzFDLElBQU1nRSxpQkFBaUIsR0FBSUMsTUFBTSxJQUFLeFQsd0RBQVEsQ0FBQ3dULE1BQU0sQ0FBQyxJQUFJQSxNQUFNLEtBQUssRUFBRTtBQUN2RSxJQUFNQyxnQkFBZ0IsR0FBSUMsS0FBSyxJQUFLclksS0FBSyxDQUFDMkksT0FBTyxDQUFDMFAsS0FBSyxDQUFDLElBQUlBLEtBQUssQ0FBQ3JQLE1BQU0sQ0FBQ2tQLGlCQUFpQixDQUFDLENBQUM3VCxNQUFNLEdBQUcsQ0FBQztBQUN0RyxJQUFNaVUsZ0JBQWdCLEdBQUl6TixLQUFLLElBQUs7RUFDaEMsSUFBSXFOLGlCQUFpQixDQUFDck4sS0FBSyxDQUFDLEVBQ3hCLE9BQU8sSUFBSTtFQUNmLElBQUl1TixnQkFBZ0IsQ0FBQ3ZOLEtBQUssQ0FBQyxFQUN2QixPQUFPLElBQUk7RUFDZixPQUFPLEtBQUs7QUFDaEIsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU0wTixtQkFBbUIsR0FBSUMsR0FBRyxJQUFLO0VBQ3hDLElBQU1DLFlBQVksR0FBRyxDQUFDLENBQUM7RUFDdkIsT0FBT3JOLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDbU4sR0FBRyxDQUFDLENBQUNFLE1BQU0sQ0FBQyxDQUFDQyxLQUFLLEVBQUF6WSxJQUFBLEtBQW1CO0lBQUEsSUFBakIsQ0FBQ29JLEdBQUcsRUFBRXVDLEtBQUssQ0FBQyxHQUFBM0ssSUFBQTtJQUNsRCxJQUFJb1ksZ0JBQWdCLENBQUN6TixLQUFLLENBQUMsRUFBRTtNQUN6QjtNQUNBOE4sS0FBSyxDQUFDclEsR0FBRyxDQUFDLEdBQUd0SSxLQUFLLENBQUMySSxPQUFPLENBQUNrQyxLQUFLLENBQUMsR0FDM0JBLEtBQUssQ0FBQzdCLE1BQU0sQ0FBQ2tQLGlCQUFpQixDQUFDLEdBQy9Cck4sS0FBSztJQUNmO0lBQ0EsT0FBTzhOLEtBQUs7RUFDaEIsQ0FBQyxFQUFFRixZQUFZLENBQUM7QUFDcEIsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDMUN5QztBQUMxQztBQUNBLElBQU1HLFNBQVMsR0FBRyxDQUNkO0VBQ0lDLEVBQUUsRUFBRSxVQUFVO0VBQ2RDLEtBQUssRUFBRTtBQUNYLENBQUMsRUFDRDtFQUNJRCxFQUFFLEVBQUUsUUFBUTtFQUNaQyxLQUFLLEVBQUU7QUFDWCxDQUFDLEVBQ0Q7RUFDSUQsRUFBRSxFQUFFLFNBQVM7RUFDYkMsS0FBSyxFQUFFO0FBQ1gsQ0FBQyxFQUNEO0VBQ0lELEVBQUUsRUFBRSxRQUFRO0VBQ1pDLEtBQUssRUFBRTtBQUNYLENBQUMsQ0FDSjtBQUNEO0FBQ0EsSUFBTUMsV0FBVyxHQUFJN0gsUUFBUSxJQUFLO0VBQUEsSUFBQThILGVBQUE7RUFDOUIsSUFBSTlILFFBQVEsS0FBSyxFQUFFLEVBQ2YsT0FBTyxJQUFJO0VBQ2YsSUFBTStILFVBQVUsSUFBQUQsZUFBQSxHQUFHSixTQUFTLENBQUNNLElBQUksQ0FBRUMsWUFBWSxJQUFLakksUUFBUSxDQUFDMU0sUUFBUSxDQUFDMlUsWUFBWSxDQUFDTCxLQUFLLENBQUMsQ0FBQyxjQUFBRSxlQUFBLGNBQUFBLGVBQUEsR0FBSSxJQUFJO0VBQ2xHLE9BQU9DLFVBQVUsR0FBR0EsVUFBVSxDQUFDSixFQUFFLEdBQUcsSUFBSTtBQUM1QyxDQUFDO0FBQ0QsSUFBTU8sb0JBQW9CLEdBQUdsWixJQUFBLElBQTZEO0VBQUEsSUFBNUQ7SUFBRXdSLHdCQUF3QjtJQUFFMkI7RUFBMEIsQ0FBQyxHQUFBblQsSUFBQTtFQUNqRixJQUFNbVosWUFBWSxHQUFHQSxDQUFDQyxRQUFRLEVBQUVDLE9BQU8sS0FBSztJQUN4QyxJQUFJQSxPQUFPLEtBQUssV0FBVyxFQUN2QixPQUFPLElBQUk7SUFDZjtJQUNBLE9BQU8sR0FBQWhaLE1BQUEsQ0FBRytZLFFBQVEsT0FBQS9ZLE1BQUEsQ0FBSWdaLE9BQU8sRUFBR0MsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7RUFDcEQsQ0FBQztFQUNELElBQU1DLG9CQUFvQixHQUFHck8sTUFBTSxDQUFDQyxPQUFPLENBQUNxRyx3QkFBd0IsQ0FBQyxDQUNoRTdJLEdBQUcsQ0FBRXpCLElBQUksSUFBSztJQUNmLElBQU0sQ0FBQ2xCLElBQUksRUFBRXFULE9BQU8sQ0FBQyxHQUFHblMsSUFBSTtJQUM1QixPQUFPaVMsWUFBWSxDQUFDblQsSUFBSSxFQUFFcVQsT0FBTyxDQUFDQSxPQUFPLENBQUM7RUFDOUMsQ0FBQyxDQUFDLENBQ0d2USxNQUFNLENBQUNyRSxvREFBUSxDQUFDO0VBQ3JCLElBQU0rVSxxQkFBcUIsR0FBR3RPLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDZ0ksd0JBQXdCLENBQUMsQ0FDakV4SyxHQUFHLENBQUV6QixJQUFJLElBQUtpUyxZQUFZLENBQUMsR0FBR2pTLElBQUksQ0FBQyxDQUFDLENBQ3BDNEIsTUFBTSxDQUFDckUsb0RBQVEsQ0FBQztFQUNyQixJQUFJOFUsb0JBQW9CLENBQUNwVixNQUFNLEdBQUdxVixxQkFBcUIsQ0FBQ3JWLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDbEUsT0FBTyxJQUFJO0VBQ2Y7RUFDQSxPQUFPLENBQUMsR0FBR29WLG9CQUFvQixFQUFFLEdBQUdDLHFCQUFxQixDQUFDO0FBQzlELENBQUM7QUFDRCxJQUFNdEosbUJBQW1CLEdBQUd6RSxLQUFBO0VBQUEsSUFBQztJQUFFcUgsTUFBTTtJQUFFQyxXQUFXO0lBQUVDLFNBQVM7SUFBRXZCLFVBQVU7SUFBRW5DLFVBQVU7SUFBRTRELGNBQWM7SUFBRWxDO0VBQVUsQ0FBQyxHQUFBdkYsS0FBQTtFQUFBLE9BQU07SUFDcEhnTyxFQUFFLEVBQUVQLG9CQUFvQixDQUFDaEcsY0FBYyxDQUFDO0lBQ3hDd0csRUFBRSxFQUFFNUcsTUFBTTtJQUNWNkcsRUFBRSxFQUFFNUcsV0FBVztJQUNmNkcsRUFBRSxFQUFFNUcsU0FBUztJQUNiNkcsRUFBRSxFQUFFdkssVUFBVTtJQUNkd0ssR0FBRyxFQUFFakIsV0FBVyxDQUFDN0gsUUFBUSxDQUFDO0lBQzFCK0ksRUFBRSxFQUFFdEksVUFBVSxHQUFHLEdBQUcsR0FBRztFQUMzQixDQUFDO0FBQUEsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEQ0RDtBQUM5RCxJQUFNdUksTUFBTSxHQUFHO0VBQ1gsQ0FBQyxFQUFFLEdBQUc7RUFDTixFQUFFLEVBQUUsR0FBRztFQUNQLEdBQUcsRUFBRSxHQUFHO0VBQ1IsR0FBRyxFQUFFLEdBQUc7RUFDUixHQUFHLEVBQUUsR0FBRztFQUNSLEdBQUcsRUFBRTtBQUNULENBQUM7QUFDRDtBQUNBLElBQU1DLGVBQWUsR0FBSUMsT0FBTyxJQUFLO0VBQ2pDLElBQUlBLE9BQU8sR0FBRyxFQUFFLElBQUlsUixLQUFLLENBQUNrUixPQUFPLENBQUMsRUFDOUIsT0FBTyxDQUFDLEdBQUcsQ0FBQztFQUNoQixJQUFNQyxVQUFVLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDO0VBQzNDLE9BQU9BLFVBQVUsQ0FBQ3JSLE1BQU0sQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLElBQUltUixPQUFPLENBQUMsQ0FBQ3ZSLEdBQUcsQ0FBRXRFLENBQUMsSUFBSzJWLE1BQU0sQ0FBQzNWLENBQUMsQ0FBQyxDQUFDO0FBQ3ZFLENBQUM7QUFDRDtBQUNBLElBQU04TCxZQUFZLEdBQUdBLENBQUEsS0FBTTtFQUN2QixPQUFPLElBQUlnRixJQUFJLENBQUMsQ0FBQyxDQUFDaUYsUUFBUSxDQUFDLENBQUMsQ0FBQ2hhLFFBQVEsQ0FBQyxDQUFDO0FBQzNDLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxJQUFNZ1Esa0JBQWtCLEdBQUlpSyxNQUFNLElBQUtoQywyRUFBbUIsQ0FBQ2dDLE1BQU0sQ0FBQztBQUMzRCxJQUFNalcsQ0FBQyxHQUFHO0VBQ2I2VjtBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzFCRCxJQUFNSyxtQkFBbUIsR0FBRyxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUM7QUFDbkQsSUFBTUMsa0JBQWtCLEdBQUlDLE1BQU0sSUFBSztFQUNuQyxJQUFNO0lBQUVDLFdBQVc7SUFBRWpJO0VBQVksQ0FBQyxHQUFHak4sTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSTtFQUNoRTtFQUNBLElBQU1nVixXQUFXLEdBQUcsQ0FBQ25WLE1BQU0sQ0FBQ29WLFNBQVMsQ0FDaENDLE1BQU0sQ0FBQyxDQUFDLENBQ1JDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FDdEJ2VyxRQUFRLENBQUMsY0FBYyxDQUFDO0VBQzdCLElBQUlrVyxNQUFNLEtBQUssaUJBQWlCLElBQzVCRixtQkFBbUIsQ0FBQ2hXLFFBQVEsQ0FBQ21XLFdBQVcsQ0FBQyxJQUN6QyxDQUFDakksV0FBVyxJQUNaa0ksV0FBVyxFQUFFO0lBQ2IsT0FBTyxJQUFJO0VBQ2Y7RUFDQSxPQUFPLEtBQUs7QUFDaEIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDZkQ7QUFDQSxJQUFNSSxjQUFjLEdBQUk3YSxLQUFLLElBQUs7RUFDOUIsSUFBSUEsS0FBSyxJQUFJLEdBQUcsRUFDWixPQUFPLFNBQVM7RUFDcEIsSUFBSUEsS0FBSyxJQUFJLEdBQUcsRUFDWixPQUFPLFFBQVE7RUFDbkIsT0FBTyxRQUFRO0FBQ25CLENBQUM7QUFDRCxJQUFNb1Esb0JBQW9CLEdBQUdyUSxJQUFBLElBQTJDO0VBQUEsSUFBMUM7SUFBRTJULGFBQWE7SUFBRUM7RUFBbUIsQ0FBQyxHQUFBNVQsSUFBQTtFQUMvRDtFQUNBLElBQU0rYSxTQUFTLEdBQUd4VixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNxVixTQUFTO0VBQ3ZELElBQU1DLE1BQU0sR0FBR3BILGlCQUFpQixJQUFJbUgsU0FBUyxHQUFHLEdBQUcsR0FBRyxHQUFHO0VBQ3pELE9BQU87SUFDSEUsRUFBRSxFQUFFSCxjQUFjLENBQUNuSCxhQUFhLENBQUM7SUFDakN1SCxRQUFRLEVBQUV2SCxhQUFhLElBQUksSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHO0lBQzNDcUg7RUFDSixDQUFDO0FBQ0wsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pCbUg7QUFDcEM7QUFDckI7QUFDZDtBQUN5QjtBQUN0RSxJQUFNUSxhQUFhLEdBQUk5WCxJQUFJLElBQUs7RUFDNUIsSUFBTStYLFVBQVUsR0FBRy9YLElBQUksQ0FBQ2tSLEtBQUssQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUNqTSxHQUFHLENBQUNDLE1BQU0sQ0FBQztFQUNqRDtFQUNBLElBQUk2UyxVQUFVLENBQUN0WCxNQUFNLEtBQUssQ0FBQyxJQUN2QixDQUFDc1gsVUFBVSxDQUFDLENBQUMsQ0FBQyxJQUNkLENBQUNBLFVBQVUsQ0FBQyxDQUFDLENBQUMsSUFDZEEsVUFBVSxDQUFDdkUsSUFBSSxDQUFFbk8sQ0FBQyxJQUFLQyxLQUFLLENBQUNELENBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDbEMsT0FBTyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7RUFDakI7RUFDQSxPQUFPLENBQUMwUyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUVBLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxpQkFBaUIsR0FBSUMsSUFBSSxJQUFLQSxJQUFJLENBQUMvRyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUNqTSxHQUFHLENBQUVqRixJQUFJLElBQUs3QyxnRkFBWSxDQUFDLEdBQUcyYSxhQUFhLENBQUM5WCxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQ3ZHO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1rWSx5QkFBeUIsR0FBSUMsY0FBYyxJQUFLQSxjQUFjLENBQUNDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxPQUFPLENBQUMsQ0FBQ0MsV0FBVyxDQUFDLENBQUM7QUFDdEg7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUMsZ0NBQWdDLEdBQUlDLFVBQVUsSUFBSy9RLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDZ1EscUVBQWlCLENBQUMsQ0FBQzNDLE1BQU0sQ0FBQyxDQUFDMEQsS0FBSyxFQUFBbGMsSUFBQSxLQUF1QjtFQUFBLElBQXJCLENBQUM2YixjQUFjLENBQUMsR0FBQTdiLElBQUE7RUFDdEgsSUFBTW1jLElBQUksR0FBR0YsVUFBVSxDQUFDRyxZQUFZLFNBQUEvYixNQUFBLENBQVN1Yix5QkFBeUIsQ0FBQ0MsY0FBYyxDQUFDLENBQUUsQ0FBQztFQUN6RixJQUFJTSxJQUFJLEVBQUU7SUFDTkQsS0FBSyxDQUFDTCxjQUFjLENBQUMsR0FBR0gsaUJBQWlCLENBQUNTLElBQUksQ0FBQztFQUNuRDtFQUNBLE9BQU9ELEtBQUs7QUFDaEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ04sSUFBTUcsVUFBVSxHQUFJQyxRQUFRLElBQUs7RUFDN0IsT0FBT0EsUUFBUSxJQUFJM1osZ0ZBQWdCO0FBQ3ZDLENBQUM7QUFDRCxJQUFNNFosa0JBQWtCLEdBQUl2VyxJQUFJLElBQUs7RUFDakMsSUFBSXNXLFFBQVE7RUFDWixJQUFJdFcsSUFBSSxDQUFDMUIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0lBQ3pCZ1ksUUFBUSxHQUFHLFFBQVE7RUFDdkIsQ0FBQyxNQUNJLElBQUl0VyxJQUFJLENBQUMxQixRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7SUFDckNnWSxRQUFRLEdBQUcsZUFBZTtFQUM5QixDQUFDLE1BQ0ksSUFBSXRXLElBQUksQ0FBQzFCLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRTtJQUNoQ2dZLFFBQVEsR0FBRyxVQUFVO0VBQ3pCLENBQUMsTUFDSSxJQUFJdFcsSUFBSSxDQUFDMUIsUUFBUSxDQUFDLG1CQUFtQixDQUFDLEVBQUU7SUFDekNnWSxRQUFRLEdBQUcsbUJBQW1CO0VBQ2xDLENBQUMsTUFDSSxJQUFJdFcsSUFBSSxDQUFDMUIsUUFBUSxDQUFDLGFBQWEsQ0FBQyxFQUFFO0lBQ25DZ1ksUUFBUSxHQUFHLGFBQWE7RUFDNUIsQ0FBQyxNQUNJO0lBQ0RBLFFBQVEsR0FBR3RXLElBQUk7RUFDbkI7RUFDQSxJQUFJcVcsVUFBVSxDQUFDQyxRQUFRLENBQUMsRUFBRTtJQUN0QixPQUFPM1osZ0ZBQWdCLENBQUMyWixRQUFRLENBQUM7RUFDckM7RUFDQSxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1FLDJCQUEyQixHQUFHQSxDQUFDQyxJQUFJLEVBQUU1WSxVQUFVLEtBQUs7RUFDdEQsSUFBTXFZLEtBQUssR0FBR0ssa0JBQWtCLENBQUNFLElBQUksQ0FBQztFQUN0QyxJQUFJLENBQUN2UixNQUFNLENBQUN3UixJQUFJLENBQUNSLEtBQUssQ0FBQyxDQUFDL1gsTUFBTSxFQUMxQixPQUFPLElBQUk7RUFDZixJQUFNd1ksa0JBQWtCLEdBQUdoWixpR0FBNkIsQ0FBQ3VZLEtBQUssRUFBRXJZLFVBQVUsQ0FBQztFQUMzRSxJQUFNK1ksT0FBTyxHQUFHRCxrQkFBa0IsQ0FDN0I3VCxNQUFNLENBQUVwRixJQUFJLElBQUssQ0FBQ0EsSUFBSSxDQUFDbkQsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUNqQ29JLEdBQUcsQ0FBQzhDLEtBQUE7SUFBQSxJQUFDO01BQUV2TDtJQUFPLENBQUMsR0FBQXVMLEtBQUE7SUFBQSxPQUFLdkwsTUFBTTtFQUFBLEVBQUM7RUFDaEMsSUFBSSxDQUFDMGMsT0FBTyxDQUFDelksTUFBTSxFQUNmLE9BQU8sSUFBSTtFQUNmLE9BQU93SCxJQUFJLENBQUM2SSxHQUFHLENBQUMsR0FBR29JLE9BQU8sQ0FBQztBQUMvQixDQUFDO0FBQ0QsSUFBTUMsa0JBQWtCLEdBQUkzWSxXQUFXLElBQUs7RUFDeEMsT0FBUWdILE1BQU0sQ0FBQ3dSLElBQUksQ0FBQ3hZLFdBQVcsQ0FBQyxDQUFDQyxNQUFNLEtBQUssQ0FBQyxJQUN6QytHLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDakgsV0FBVyxDQUFDLENBQUN1SyxLQUFLLENBQUMzQyxLQUFBO0lBQUEsSUFBQyxHQUFHZ1IsT0FBTyxDQUFDLEdBQUFoUixLQUFBO0lBQUEsT0FBS2dSLE9BQU8sQ0FBQzNZLE1BQU0sS0FBSyxDQUFDO0VBQUEsRUFBQztBQUNoRixDQUFDO0FBQ0QsTUFBTTRZLE1BQU0sQ0FBQztFQWlCRTtFQUNYaGQsV0FBV0EsQ0FBQ2lkLFVBQVUsRUFBa0Q7SUFBQSxJQUFoREMscUJBQXFCLEdBQUFoWSxTQUFBLENBQUFkLE1BQUEsUUFBQWMsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBRyxDQUFDLENBQUM7SUFBQSxJQUFFaVksYUFBYSxHQUFBalksU0FBQSxDQUFBZCxNQUFBLFFBQUFjLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0lBQUE5RSxlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBLDZCQWRqRCxJQUFJO0lBQUFBLGVBQUEsZUFDbEIsSUFBSTtJQUFBQSxlQUFBO0lBQUFBLGVBQUEsa0JBRUQsSUFBSTtJQUFBQSxlQUFBLHFCQUNELEtBQUs7SUFBQUEsZUFBQSx3QkFDRixLQUFLO0lBQUFBLGVBQUE7SUFBQUEsZUFBQSwyQkFFRixFQUFFO0lBQUFBLGVBQUEsd0JBQ0wsS0FBSztJQUFBQSxlQUFBLGtDQUNLLElBQUk7SUFBQUEsZUFBQSxxQkFDakIsSUFBSTtJQUFBQSxlQUFBLHFCQUNKLElBQUk7SUFBQUEsZUFBQSw2QkFDSSxJQUFJO0lBQUFBLGVBQUE7SUFHckIsSUFBSSxDQUFDd1ksRUFBRSxHQUFHcUUsVUFBVSxDQUFDckUsRUFBRTtJQUN2QixJQUFJLENBQUN3RSxJQUFJLEdBQUdILFVBQVU7SUFDdEIsSUFBSSxDQUFDZCxLQUFLLEdBQUcsSUFBSSxDQUFDa0IsbUJBQW1CLENBQUNILHFCQUFxQixDQUFDO0lBQzVELElBQU1JLGNBQWMsR0FBRzlCLHdEQUFVLENBQUN5QixVQUFVLEVBQUUsSUFBSSxDQUFDZCxLQUFLLEVBQUVnQixhQUFhLENBQUM7SUFDeEUsSUFBSSxDQUFDVCxJQUFJLEdBQUdZLGNBQWMsQ0FBQ1osSUFBSTtJQUMvQixJQUFJLENBQUNhLGFBQWEsR0FBR0QsY0FBYyxDQUFDRSxTQUFTO0lBQzdDLElBQUksQ0FBQ0MsU0FBUyxHQUFHSCxjQUFjLENBQUNaLElBQUksQ0FBQzVCLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDckU7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJNEMsaUJBQWlCQSxDQUFDQyxVQUFVLEVBQUU7SUFDMUIsSUFBSSxDQUFDQSxVQUFVLEdBQUdBLFVBQVU7RUFDaEM7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDVUMsc0JBQXNCQSxDQUFBLEVBQWdCO0lBQUEsSUFBQUMsVUFBQSxHQUFBM1ksU0FBQTtNQUFBNFksS0FBQTtJQUFBLE9BQUF6UCxpQkFBQTtNQUFBLFNBQUExQixJQUFBLEdBQUFrUixVQUFBLENBQUF6WixNQUFBLEVBQVoyWixVQUFVLE9BQUFoZSxLQUFBLENBQUE0TSxJQUFBLEdBQUFFLElBQUEsTUFBQUEsSUFBQSxHQUFBRixJQUFBLEVBQUFFLElBQUE7UUFBVmtSLFVBQVUsQ0FBQWxSLElBQUEsSUFBQWdSLFVBQUEsQ0FBQWhSLElBQUE7TUFBQTtNQUN0QyxJQUFNbVIsZUFBZSxHQUFHRixLQUFJLENBQUNHLGdCQUFnQixDQUFDbFYsTUFBTSxDQUFFbVYsQ0FBQyxJQUFLLENBQUNILFVBQVUsQ0FBQ3haLFFBQVEsQ0FBQzJaLENBQUMsQ0FBQyxDQUFDO01BQ3BGLE1BQU01Qyw0REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07UUFDdkJMLEtBQUksQ0FBQ1YsSUFBSSxDQUFDZ0IsU0FBUyxDQUFDN1UsTUFBTSxDQUFDLEdBQUd5VSxlQUFlLENBQUM7UUFDOUNGLEtBQUksQ0FBQ1YsSUFBSSxDQUFDZ0IsU0FBUyxDQUFDQyxHQUFHLENBQUMsR0FBR04sVUFBVSxDQUFDO01BQzFDLENBQUMsQ0FBQztNQUNGRCxLQUFJLENBQUNHLGdCQUFnQixHQUFHRixVQUFVO0lBQUM7RUFDdkM7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0lWLG1CQUFtQkEsQ0FBQ0gscUJBQXFCLEVBQUU7SUFDdkM7SUFDQSxJQUFNb0IseUJBQXlCLEdBQUcsSUFBSSxDQUFDbEIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDdFksSUFBSSxHQUNsRHVXLGtCQUFrQixDQUFDLElBQUksQ0FBQ1ksSUFBSSxDQUFDbUIsT0FBTyxDQUFDdFksSUFBSSxDQUFDLEdBQzFDLENBQUMsQ0FBQztJQUNSO0lBQ0EsSUFBTXVZLG1CQUFtQixHQUFHdkMsZ0NBQWdDLENBQUMsSUFBSSxDQUFDbUIsSUFBSSxDQUFDO0lBQ3ZFLElBQUlqWixXQUFXLEdBQUdrWCx1RUFBa0IsQ0FBQ2lELHlCQUF5QixFQUFFcEIscUJBQXFCLENBQUM7SUFDdEYvWSxXQUFXLEdBQUdrWCx1RUFBa0IsQ0FBQ2xYLFdBQVcsRUFBRXFhLG1CQUFtQixDQUFDO0lBQ2xFO0lBQ0EsSUFBSTFCLGtCQUFrQixDQUFDM1ksV0FBVyxDQUFDLEVBQUU7TUFBQSxJQUFBc2EscUJBQUE7TUFDakMsTUFBTSxJQUFJQyxLQUFLLDZCQUFBcGUsTUFBQSxFQUFBbWUscUJBQUEsR0FBNkIsSUFBSSxDQUFDckIsSUFBSSxDQUFDbUIsT0FBTyxDQUFDdFksSUFBSSxjQUFBd1kscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFLGdDQUE2QixDQUFDO0lBQzFHO0lBQ0EsT0FBT3RhLFdBQVc7RUFDdEI7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSXdhLGlCQUFpQkEsQ0FBQ3pCLHFCQUFxQixFQUFFO0lBQ3JDLElBQU0vWSxXQUFXLEdBQUcsSUFBSSxDQUFDa1osbUJBQW1CLENBQUNILHFCQUFxQixDQUFDO0lBQ25FLElBQUksQ0FBQ2YsS0FBSyxHQUFHaFksV0FBVztJQUN4QixJQUFNeWEsb0JBQW9CLEdBQUdyRCx1RUFBeUIsQ0FBQ3BYLFdBQVcsQ0FBQztJQUNuRSxJQUFJeWEsb0JBQW9CLEVBQUU7TUFDdEIsSUFBSSxDQUFDbEMsSUFBSSxDQUFDbUMsaUJBQWlCLENBQUNELG9CQUFvQixDQUFDO0lBQ3JEO0VBQ0o7QUFDSjtBQUNBLElBQU1FLFFBQVEsR0FBSW5iLElBQUksSUFBSztFQUN2QixPQUFPQSxJQUFJLEtBQUssSUFBSSxJQUFJQSxJQUFJLEtBQUssT0FBTztBQUM1QyxDQUFDO0FBQ3dEO0FBQ2xELElBQU1VLENBQUMsR0FBRztFQUNibVk7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNMb0M7QUFDbUI7QUFDdEI7QUFDYztBQUNoRCxJQUFNeUMsWUFBWSxHQUFHQSxDQUFDQyxNQUFNLEVBQUVDLGVBQWUsRUFBRWhDLGFBQWEsS0FBSztFQUM3RCxJQUFJO0lBQ0EsSUFBTWlDLE1BQU0sR0FBRyxJQUFJcEMsMkNBQU0sQ0FBQ2tDLE1BQU0sRUFBRUMsZUFBZSxFQUFFaEMsYUFBYSxDQUFDO0lBQ2pFLE9BQU9pQyxNQUFNO0VBQ2pCLENBQUMsQ0FDRCxPQUFPQyxLQUFLLEVBQUU7SUFDVixJQUFJQSxLQUFLLFlBQVlMLHlEQUFlLEVBQUU7TUFDbEN0VixtREFBRyxDQUFDLFlBQVksRUFBRTJWLEtBQUssQ0FBQ3hYLE9BQU8sRUFBRTtRQUM3QnlYLFFBQVEsRUFBRUosTUFBTSxDQUFDdEcsRUFBRTtRQUNuQnpVLFdBQVcsRUFBRWtiLEtBQUssQ0FBQ2xiO01BQ3ZCLENBQUMsQ0FBQztNQUNGLElBQUlrYixLQUFLLENBQUNFLE1BQU0sRUFBRTtRQUNkUixvRUFBVyxDQUFDTSxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUFFO1VBQ2pDQyxRQUFRLEVBQUVKLE1BQU0sQ0FBQ3RHLEVBQUU7VUFDbkJ6VSxXQUFXLEVBQUVrYixLQUFLLENBQUNsYjtRQUN2QixDQUFDLENBQUM7TUFDTjtJQUNKLENBQUMsTUFDSTtNQUNEdUYsbURBQUcsQ0FBQyxZQUFZLEVBQUUyVixLQUFLLFlBQVlYLEtBQUssR0FBR1csS0FBSyxDQUFDeFgsT0FBTyxHQUFHcUIsTUFBTSxDQUFDbVcsS0FBSyxDQUFDLENBQUM7TUFDekU7TUFDQTtNQUNBO01BQ0EsSUFBSSxDQUFDRyxTQUFTLENBQUNDLFNBQVMsQ0FBQ2xiLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFDM0MsQ0FBQ2liLFNBQVMsQ0FBQ0MsU0FBUyxDQUFDbGIsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO1FBQ3RDd2Esb0VBQVcsQ0FBQ00sS0FBSyxFQUFFLFlBQVksRUFBRSxDQUFDLENBQUMsRUFBRTtVQUNqQ0MsUUFBUSxFQUFFSixNQUFNLENBQUN0RyxFQUFFO1VBQ25CdUcsZUFBZSxFQUFFQTtRQUNyQixDQUFDLENBQUM7TUFDTjtJQUNKO0lBQ0EsT0FBTyxJQUFJO0VBQ2Y7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckNrRTtBQUN3QjtBQUNYO0FBQy9DO0FBQ087QUFDTTtBQUM5QyxJQUFNUyxtQkFBbUIsR0FBRztFQUN4QjljLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7RUFBRTtFQUNoQk0sT0FBTyxFQUFFLENBQUNnWSxxRUFBaUIsQ0FBQ2hZLE9BQU8sRUFBRSxDQUFDLENBQUM7RUFDdkNGLE1BQU0sRUFBRSxDQUFDa1kscUVBQWlCLENBQUNsWSxNQUFNLEVBQUUsQ0FBQyxDQUFDO0VBQ3JDSCxPQUFPLEVBQUUsQ0FBQ3FZLHFFQUFpQixDQUFDclksT0FBTyxFQUFFLENBQUMsQ0FBQztFQUN2QzhjLElBQUksRUFBRSxDQUFDekUscUVBQWlCLENBQUN5RSxJQUFJLEVBQUUsQ0FBQztBQUNwQyxDQUFDO0FBQ0QsSUFBTUMsTUFBTSxHQUFHNVIscURBQUksQ0FBQyxNQUFNO0VBQ3RCLElBQU02UixPQUFPLEdBQUdMLG9EQUFVLENBQUMsQ0FBQztFQUM1QixPQUFPSyxPQUFPLENBQUMsU0FBUyxDQUFDLE9BQUF6ZixNQUFBLENBQ2ZrRixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNxYSxZQUFZLE9BQUExZixNQUFBLENBQUk0SSxNQUFNLENBQUM2VyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUMsSUFDMUV2YSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNtYSxNQUFNO0FBQzVDLENBQUMsQ0FBQztBQUNGLElBQU1qZ0IsWUFBWSxHQUFJaUUsVUFBVSxJQUFLQSxVQUFVLElBQUk4YixtQkFBbUI7QUFDdEUsSUFBTUssZUFBZSxHQUFJdGMsSUFBSSxJQUFLO0VBQzlCO0VBQ0EsT0FBT0EsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsSUFBSUEsSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsR0FBRyxPQUFPLEdBQUcsQ0FBQ0EsSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFQSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEUsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTXVjLGFBQWEsR0FBR2hTLHFEQUFJLENBQUMsTUFBTTtFQUM3QixJQUFNaVMsV0FBVyxHQUFHM2EsTUFBTSxDQUFDb1YsU0FBUyxDQUMvQnpXLFdBQVcsQ0FBQyxDQUFDLENBQ2JpYyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQzdCQyxLQUFLLENBQUMsQ0FBQztFQUNaLE9BQU8sQ0FBQyxDQUFDRixXQUFXO0FBQ3hCLENBQUMsQ0FBQztBQUNGO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTTVFLHlCQUF5QixHQUFJcFgsV0FBVyxJQUFLO0VBQy9DLElBQU00WSxPQUFPLEdBQUd2WCxNQUFNLENBQUNvVixTQUFTLENBQUN6VyxXQUFXLENBQUMsQ0FBQztFQUM5Q2dILE1BQU0sQ0FBQ0MsT0FBTyxDQUFDakgsV0FBVyxDQUFDLENBQUNtYyxPQUFPLENBQUNyZ0IsSUFBQSxJQUF5QjtJQUFBLElBQXhCLENBQUM2RCxVQUFVLEVBQUVxWSxLQUFLLENBQUMsR0FBQWxjLElBQUE7SUFDcEQsSUFBSUosWUFBWSxDQUFDaUUsVUFBVSxDQUFDLEVBQUU7TUFDMUJpWixPQUFPLENBQUNxRCxPQUFPLENBQUNSLG1CQUFtQixDQUFDOWIsVUFBVSxDQUFDLEVBQUVxWSxLQUFLLENBQUN2VCxHQUFHLENBQUNxWCxlQUFlLENBQUMsQ0FBQztJQUNoRjtFQUNKLENBQUMsQ0FBQztFQUNGLE9BQU9sRCxPQUFPLENBQUNzRCxLQUFLLENBQUMsQ0FBQztBQUMxQixDQUFDO0FBQ0QsSUFBTUUsV0FBVyxHQUFJNWMsSUFBSSxJQUFLO0VBQzFCLE9BQU81RCxLQUFLLENBQUMySSxPQUFPLENBQUMvRSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUNBLElBQUksQ0FBQ1MsTUFBTTtBQUMvQyxDQUFDO0FBQ0QsSUFBTW9jLGFBQWEsR0FBR0EsQ0FBQzdjLElBQUksRUFBRXdZLEtBQUssS0FBSztFQUNuQyxJQUFJeFksSUFBSSxLQUFLLE9BQU8sRUFBRTtJQUNsQixPQUFPd1ksS0FBSyxDQUFDNVgsUUFBUSxDQUFDLE9BQU8sQ0FBQztFQUNsQyxDQUFDLE1BQ0ksSUFBSXhFLEtBQUssQ0FBQzJJLE9BQU8sQ0FBQy9FLElBQUksQ0FBQyxFQUFFO0lBQzFCLE9BQU8sQ0FBQyxDQUFDd1ksS0FBSyxDQUFDbEQsSUFBSSxDQUFFMUwsSUFBSSxJQUFLQSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs1SixJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk0SixJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUs1SixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDN0U7RUFDQSxPQUFPLEtBQUs7QUFDaEIsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTThjLFlBQVksR0FBSXRjLFdBQVcsSUFBSztFQUNsQyxJQUFNZ1ksS0FBSyxHQUFHLEVBQUU7RUFDaEI7RUFDQWhZLFdBQVcsYUFBWEEsV0FBVyxlQUFYQSxXQUFXLENBQUVtYyxPQUFPLENBQUM1VSxLQUFBLElBQTRCO0lBQUEsSUFBM0IsR0FBR2tSLGtCQUFrQixDQUFDLEdBQUFsUixLQUFBO0lBQ3hDLElBQUk2VSxXQUFXLENBQUMzRCxrQkFBa0IsQ0FBQyxFQUFFO01BQ2pDQSxrQkFBa0IsQ0FBQzBELE9BQU8sQ0FBRTNjLElBQUksSUFBSztRQUNqQyxJQUFJLENBQUM2YyxhQUFhLENBQUM3YyxJQUFJLEVBQUV3WSxLQUFLLENBQUMsRUFBRTtVQUM3QkEsS0FBSyxDQUFDdUUsSUFBSSxDQUFDL2MsSUFBSSxDQUFDO1FBQ3BCO01BQ0osQ0FBQyxDQUFDO0lBQ047RUFDSixDQUFDLENBQUM7RUFDRixPQUFPd1ksS0FBSztBQUNoQixDQUFDO0FBQ0QsSUFBTXdFLHNCQUFzQixHQUFJQyxVQUFVLElBQUssT0FBT0EsVUFBVSxLQUFLLFFBQVEsS0FDeEVBLFVBQVUsS0FBSyxTQUFTLElBQUlBLFVBQVUsS0FBSyxlQUFlLENBQUM7QUFDaEUsSUFBTUMsc0JBQXNCLEdBQUluRSxJQUFJLElBQUs7RUFDckNBLElBQUksQ0FBQ29FLGtCQUFrQixDQUFDO0lBQ3BCQyxxQkFBcUIsRUFBRSxLQUFLO0lBQzVCQyxrQkFBa0IsRUFBRSxJQUFJO0lBQ3hCQyxPQUFPLEVBQUU7RUFDYixDQUFDLENBQUM7RUFDRixPQUFPdkUsSUFBSTtBQUNmLENBQUM7QUFDRCxNQUFNc0MsZUFBZSxTQUFTTixLQUFLLENBQUM7RUFHaEMxZSxXQUFXQSxDQUFDNkgsT0FBTyxFQUFFMUQsV0FBVyxFQUFpQjtJQUFBLElBQWZvYixNQUFNLEdBQUFyYSxTQUFBLENBQUFkLE1BQUEsUUFBQWMsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBRyxJQUFJO0lBQzNDLEtBQUssQ0FBQzJDLE9BQU8sQ0FBQztJQUFDekgsZUFBQTtJQUFBQSxlQUFBO0lBQ2YsSUFBSSxDQUFDNkYsSUFBSSxHQUFHLGlCQUFpQjtJQUM3QixJQUFJLENBQUM5QixXQUFXLEdBQUc2RCxJQUFJLENBQUNDLFNBQVMsQ0FBQzlELFdBQVcsQ0FBQztJQUM5QyxJQUFJLENBQUNvYixNQUFNLEdBQUdBLE1BQU07RUFDeEI7QUFDSjtBQUNBLElBQU0vRCxVQUFVLEdBQUcsU0FBQUEsQ0FBQ3lCLFVBQVUsRUFBRTlZLFdBQVcsRUFBeUI7RUFBQSxJQUF2QmdaLGFBQWEsR0FBQWpZLFNBQUEsQ0FBQWQsTUFBQSxRQUFBYyxTQUFBLFFBQUFDLFNBQUEsR0FBQUQsU0FBQSxNQUFHLENBQUMsQ0FBQztFQUMzRCxJQUFNMGIsVUFBVSxHQUFHM0QsVUFBVSxDQUFDWixZQUFZLENBQUMsV0FBVyxDQUFDO0VBQ3ZEelMsNkVBQVUsQ0FBQzdELEdBQUcsQ0FBQyxDQUFDLENBQUNtYixJQUFJLENBQUMsaUJBQWlCLEVBQUVOLFVBQVUsQ0FBQztFQUNwRCxJQUFNaEksRUFBRSxHQUFHcUUsVUFBVSxDQUFDckUsRUFBRTtFQUN4QixJQUFNZ0csb0JBQW9CLEdBQUdyRCx5QkFBeUIsQ0FBQ3BYLFdBQVcsQ0FBQztFQUNuRSxJQUFJLENBQUN5YSxvQkFBb0IsRUFBRTtJQUN2QixJQUFJc0IsYUFBYSxDQUFDLENBQUMsRUFBRTtNQUNqQixNQUFNLElBQUlsQixlQUFlLENBQUMscURBQXFELEVBQUU3YSxXQUFXLENBQUM7SUFDakcsQ0FBQyxNQUNJO01BQ0QsTUFBTSxJQUFJNmEsZUFBZSxDQUFDLGdFQUFnRSxFQUFFN2EsV0FBVyxFQUFFLEtBQUssQ0FBQztJQUNuSDtFQUNKO0VBQ0EsSUFBTWdZLEtBQUssR0FBR3NFLFlBQVksQ0FBQzdCLG9CQUFvQixDQUFDO0VBQ2hELElBQUlsQyxJQUFJO0VBQ1IsSUFBSU8sVUFBVSxDQUFDWixZQUFZLENBQUMsa0JBQWtCLENBQUMsRUFBRTtJQUFBLElBQUE4RSxLQUFBO0lBQzdDekUsSUFBSSxHQUFHbFgsTUFBTSxDQUFDb1YsU0FBUyxDQUFDd0csbUJBQW1CLENBQUN0QixNQUFNLENBQUMsQ0FBQyxFQUFFbEgsRUFBRSxDQUFDO0lBQ3pELENBQUF1SSxLQUFBLEdBQUF6RSxJQUFJLGNBQUF5RSxLQUFBLGVBQUpBLEtBQUEsQ0FBTXRDLGlCQUFpQixDQUFDRCxvQkFBb0IsQ0FBQztFQUNqRCxDQUFDLE1BQ0k7SUFBQSxJQUFBeUMsTUFBQTtJQUNEM0UsSUFBSSxHQUFHbFgsTUFBTSxDQUFDb1YsU0FBUyxDQUFDWSxVQUFVLENBQUNzRSxNQUFNLENBQUMsQ0FBQyxFQUFFM0QsS0FBSyxFQUFFdkQsRUFBRSxDQUFDO0lBQ3ZELENBQUF5SSxNQUFBLEdBQUEzRSxJQUFJLGNBQUEyRSxNQUFBLGVBQUpBLE1BQUEsQ0FBTXhDLGlCQUFpQixDQUFDRCxvQkFBb0IsQ0FBQztJQUM3QyxJQUFJbEMsSUFBSSxJQUFJaUUsc0JBQXNCLENBQUNDLFVBQVUsQ0FBQyxFQUFFO01BQzVDQyxzQkFBc0IsQ0FBQ25FLElBQUksQ0FBQztJQUNoQztFQUNKO0VBQ0EsSUFBSSxDQUFDQSxJQUFJLEVBQUU7SUFDUCxNQUFNLElBQUlzQyxlQUFlLCtDQUErQzdhLFdBQVcsQ0FBQztFQUN4RjtFQUNBLElBQU1xWixTQUFTLEdBQUdtQywyREFBVyxDQUFDL0csRUFBRSxFQUFFOEQsSUFBSSxDQUFDO0VBQ3ZDLEtBQUtjLFNBQVMsQ0FBQzhELElBQUksQ0FBQyxNQUFNO0lBQ3RCMVgsNkVBQVUsQ0FBQzdELEdBQUcsQ0FBQyxDQUFDLENBQUNtYixJQUFJLENBQUMsZUFBZSxFQUFFTixVQUFVLENBQUM7SUFDbERoWCw2RUFBVSxDQUFDN0QsR0FBRyxDQUFDLENBQUMsQ0FBQ21iLElBQUksQ0FBQyxXQUFXLEVBQUVOLFVBQVUsQ0FBQztJQUM5QztJQUNBLElBQU1XLGVBQWUsR0FBRy9HLHlHQUFrQixDQUFDNUIsRUFBRSxDQUFDO0lBQzlDLElBQUkySSxlQUFlLEVBQUU7TUFDakI3RSxJQUFJLENBQUM4RSxZQUFZLENBQUMsZUFBZSxFQUFFLE1BQU0sQ0FBQztJQUM5QyxDQUFDLE1BQ0k7TUFDRDlFLElBQUksQ0FBQzhFLFlBQVksQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDO0lBQy9DO0VBQ0osQ0FBQyxDQUFDO0VBQ0YsSUFBTUMsSUFBSSxHQUFHamMsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDOGIsSUFBSTtFQUM3QyxJQUFJYixVQUFVLEtBQUthLElBQUksRUFBRTtJQUNyQi9FLElBQUksQ0FBQzhFLFlBQVksQ0FBQyxNQUFNLEVBQUVDLElBQUksQ0FBQztFQUNuQztFQUNBLElBQU1DLGVBQWUsR0FBRyxJQUFJQyxHQUFHLENBQUMsQ0FDNUIsQ0FBQyxlQUFlLEVBQUUsU0FBUyxDQUFDLEVBQzVCLENBQUMsb0JBQW9CLEVBQUUsU0FBUyxDQUFDLEVBQ2pDLENBQUMsZUFBZSxFQUFFLFNBQVMsQ0FBQyxDQUMvQixDQUFDO0VBQ0YsSUFBTUMsVUFBVSxHQUFHRixlQUFlLENBQUMzYixHQUFHLENBQUM2YSxVQUFVLENBQUM7RUFDbEQsSUFBSWdCLFVBQVUsRUFBRTtJQUNabEYsSUFBSSxDQUFDOEUsWUFBWSxDQUFDLGFBQWEsRUFBRUksVUFBVSxDQUFDO0VBQ2hEO0VBQ0F6VyxNQUFNLENBQUNDLE9BQU8sQ0FBQytSLGFBQWEsQ0FBQyxDQUFDbUQsT0FBTyxDQUFDdlUsS0FBQSxJQUFrQjtJQUFBLElBQWpCLENBQUMxRCxHQUFHLEVBQUV1QyxLQUFLLENBQUMsR0FBQW1CLEtBQUE7SUFDL0MyUSxJQUFJLENBQUM4RSxZQUFZLENBQUNuWixHQUFHLEVBQUV1QyxLQUFLLENBQUM7RUFDakMsQ0FBQyxDQUFDO0VBQ0Y4UixJQUFJLENBQUNtRixVQUFVLENBQUNyYyxNQUFNLENBQUNvVixTQUFTLENBQUNDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FDckMyRyxZQUFZLENBQUMsTUFBTSxFQUFFWixVQUFVLENBQUMsQ0FDaENZLFlBQVksQ0FBQyxXQUFXLEVBQUV0WSxNQUFNLENBQUMwQyxJQUFJLENBQUMyTCxLQUFLLENBQUMsR0FBRyxHQUFHM0wsSUFBSSxDQUFDK0QsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkUsT0FBTztJQUNIK00sSUFBSTtJQUNKYztFQUNKLENBQUM7QUFDTCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdEtnQztBQUNPO0FBQ3hDLElBQU1zQyxNQUFNLEdBQUc1UixxREFBSSxDQUFDLE1BQU07RUFDdEIsSUFBTTZSLE9BQU8sR0FBR0wsb0RBQVUsQ0FBQyxDQUFDO0VBQzVCLE9BQU9LLE9BQU8sQ0FBQyxTQUFTLENBQUMsT0FBQXpmLE1BQUEsQ0FDZmtGLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ3FhLFlBQVksT0FBQTFmLE1BQUEsQ0FBSTRJLE1BQU0sQ0FBQzZXLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxJQUMxRXZhLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ21hLE1BQU07QUFDNUMsQ0FBQyxDQUFDO0FBQ0YsSUFBTWdDLE9BQU87RUFBQSxJQUFBN2hCLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsV0FBTzBULE9BQU8sRUFBRUMsRUFBRSxFQUFLO0lBQ25DLElBQUlDLFNBQVM7SUFDYixPQUFPQyxPQUFPLENBQUNDLElBQUksQ0FBQyxDQUNoQkosT0FBTyxFQUNQLElBQUlHLE9BQU8sQ0FBRUUsT0FBTyxJQUFLO01BQ3JCSCxTQUFTLEdBQUd6YyxNQUFNLENBQUM2YyxVQUFVLENBQUNELE9BQU8sRUFBRUosRUFBRSxDQUFDO0lBQzlDLENBQUMsQ0FBQyxDQUNMLENBQUMsQ0FBQ1YsSUFBSSxDQUFFZ0IsTUFBTSxJQUFLO01BQ2hCOWMsTUFBTSxDQUFDK2MsWUFBWSxDQUFDTixTQUFTLENBQUM7TUFDOUIsT0FBT0ssTUFBTTtJQUNqQixDQUFDLENBQUM7RUFDTixDQUFDO0VBQUEsZ0JBWEtSLE9BQU9BLENBQUExUyxFQUFBLEVBQUFvVCxHQUFBO0lBQUEsT0FBQXZpQixJQUFBLENBQUEyTyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQVdaO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTXlhLFdBQVcsR0FBR0EsQ0FBQy9HLEVBQUUsRUFBRThELElBQUksS0FBS29GLE9BQU8sQ0FBQyxJQUFJSSxPQUFPLENBQUVFLE9BQU8sSUFBSztFQUFBLElBQUFLLGdCQUFBLEVBQUFDLGFBQUE7RUFDL0RsZCxNQUFNLENBQUNtZCxRQUFRLElBQUFGLGdCQUFBLEdBQUdqZCxNQUFNLENBQUNtZCxRQUFRLGNBQUFGLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUksQ0FBQyxDQUFDO0VBQ3ZDLElBQU1HLE1BQU0sR0FBR3BkLE1BQU0sQ0FBQ21kLFFBQVE7RUFDOUJDLE1BQU0sQ0FBQ0MsS0FBSyxJQUFBSCxhQUFBLEdBQUdFLE1BQU0sQ0FBQ0MsS0FBSyxjQUFBSCxhQUFBLGNBQUFBLGFBQUEsR0FBSSxFQUFFO0VBQ2pDRSxNQUFNLENBQUNFLEtBQUssR0FBRyxPQUFPO0VBQ3RCO0VBQ0EsSUFBTUMsU0FBUyxHQUFHckcsSUFBSSxDQUFDc0csUUFBUSxDQUFDLENBQUM7RUFDakM7RUFDQSxJQUFNQyxXQUFXLEdBQUcsQ0FDaEI7SUFDSTNELFFBQVEsRUFBRTFHLEVBQUU7SUFDWmpWLElBQUksRUFBRW9mLFNBQVMsQ0FDVmhhLE1BQU0sQ0FBRXBGLElBQUksSUFBS0EsSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUNsQ2lGLEdBQUcsQ0FBRWpGLElBQUksSUFBSyxDQUFDQSxJQUFJLENBQUN1ZixRQUFRLENBQUMsQ0FBQyxFQUFFdmYsSUFBSSxDQUFDd2YsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ3ZEQyxVQUFVLEVBQUV0RCxNQUFNLENBQUMsQ0FBQyxDQUFFO0VBQzFCLENBQUMsQ0FDSjtFQUNELElBQU11RCxlQUFlLEdBQUlDLGFBQWEsSUFBSztJQUFBLElBQUFDLGlCQUFBO0lBQ3ZDO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7SUFDUSxJQUFNQyxTQUFTLEdBQUd4YixJQUFJLENBQUNTLEtBQUssQ0FBQzZhLGFBQWEsQ0FBQztJQUMzQztJQUNBblksTUFBTSxDQUFDd1IsSUFBSSxDQUFDNkcsU0FBUyxDQUFDQyxXQUFXLENBQUMsQ0FBQ25ELE9BQU8sQ0FBRWpZLEdBQUcsSUFBSztNQUNoRCxJQUFNcWIsZ0JBQWdCLEdBQUdGLFNBQVMsQ0FBQ0MsV0FBVyxDQUFDcGIsR0FBRyxDQUFDO01BQ25ELElBQUlxYixnQkFBZ0IsRUFBRTtRQUNsQmxlLE1BQU0sQ0FBQ29WLFNBQVMsQ0FDWEMsTUFBTSxDQUFDLENBQUMsQ0FDUjJHLFlBQVksQ0FBQ25aLEdBQUcsRUFBRXFiLGdCQUFnQixDQUFDO01BQzVDO0lBQ0osQ0FBQyxDQUFDO0lBQ0YsSUFBSUYsU0FBUyxDQUFDekwsRUFBRSxFQUFFO01BQ2R2UyxNQUFNLENBQUNvVixTQUFTLENBQUNDLE1BQU0sQ0FBQyxDQUFDLENBQUMyRyxZQUFZLENBQUMsS0FBSyxFQUFFZ0MsU0FBUyxDQUFDekwsRUFBRSxDQUFDO0lBQy9EO0lBQ0EsS0FBQXdMLGlCQUFBLEdBQUlDLFNBQVMsQ0FBQ0csTUFBTSxjQUFBSixpQkFBQSxlQUFoQkEsaUJBQUEsQ0FBbUIsUUFBUSxDQUFDLEVBQUU7TUFDOUIvZCxNQUFNLENBQUNvVixTQUFTLENBQ1hDLE1BQU0sQ0FBQyxDQUFDLENBQ1IyRyxZQUFZLENBQUMsUUFBUSxFQUFFZ0MsU0FBUyxDQUFDRyxNQUFNLENBQUMsUUFBUSxDQUFDLENBQUM7SUFDM0Q7SUFDQTtJQUNBLElBQU1DLFdBQVcsR0FBRyxDQUFDLEtBQUssQ0FBQztJQUMzQixJQUFNekcsYUFBYSxHQUFHcUcsU0FBUyxDQUFDSyxLQUFLLENBQUNqTCxFQUFFLENBQUM7SUFDekMsSUFBSXVFLGFBQWEsRUFBRTtNQUNmaFMsTUFBTSxDQUFDd1IsSUFBSSxDQUFDUSxhQUFhLENBQUMsQ0FDckJwVSxNQUFNLENBQUUrYSxDQUFDLElBQUssQ0FBQ0YsV0FBVyxDQUFDcmYsUUFBUSxDQUFDdWYsQ0FBQyxDQUFDLENBQUMsQ0FDdkN4RCxPQUFPLENBQUVqWSxHQUFHLElBQUs7UUFDbEIsSUFBTTBiLGFBQWEsR0FBR1AsU0FBUyxDQUFDSyxLQUFLLENBQUNqTCxFQUFFLENBQUM7UUFDekMsSUFBSW1MLGFBQWEsRUFBRTtVQUNmLElBQU1DLGNBQWMsR0FBR0QsYUFBYSxDQUFDMWIsR0FBRyxDQUFDO1VBQ3pDLElBQUkyYixjQUFjLEVBQUU7WUFDaEJ0SCxJQUFJLENBQUM4RSxZQUFZLENBQUNuWixHQUFHLEVBQUUyYixjQUFjLENBQUM7VUFDMUM7UUFDSjtNQUNKLENBQUMsQ0FBQztJQUNOO0lBQ0E1QixPQUFPLENBQUMsQ0FBQztFQUNiLENBQUM7RUFDRFEsTUFBTSxDQUFDQyxLQUFLLENBQUNuQyxJQUFJLENBQUM7SUFDZHVELE9BQU8sRUFBRWhCLFdBQVc7SUFDcEJpQixXQUFXLEVBQUViO0VBQ2pCLENBQUMsQ0FBQztBQUNOLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xHNEI7QUFDSjtBQUNzQztBQUMzQjtBQUNnQjtBQUNGO0FBQ1I7QUFDbEQsSUFBTW9CLFNBQVMsR0FBSUMsUUFBUSxJQUFLO0VBQzVCLElBQU10RixNQUFNLEdBQUdpRix3RUFBYSxDQUFDSyxRQUFRLENBQUM7RUFDdEMsSUFBSXRGLE1BQU0sRUFBRTtJQUNSLElBQUlBLE1BQU0sQ0FBQ3pCLFVBQVUsRUFBRTtNQUNuQjRHLDJEQUFhLENBQUNuRixNQUFNLENBQUM7SUFDekIsQ0FBQyxNQUNJO01BQ0RrRix3REFBVSxDQUFDbEYsTUFBTSxDQUFDO0lBQ3RCO0VBQ0o7QUFDSixDQUFDO0FBQ0QsSUFBTXVGLFdBQVcsR0FBSUQsUUFBUSxJQUFLO0VBQzlCLElBQU10RixNQUFNLEdBQUdpRix3RUFBYSxDQUFDSyxRQUFRLENBQUM7RUFDdEMsSUFBSXRGLE1BQU0sRUFBRTtJQUNSLEtBQUtvRiwrREFBZ0IsQ0FBQ3BGLE1BQU0sQ0FBQztFQUNqQztBQUNKLENBQUM7QUFDRCxJQUFNd0Ysb0JBQW9CLEdBQUdBLENBQUN4WixPQUFPLEVBQUV5WixRQUFRLEtBQUs7RUFDaEQsSUFBTUMsU0FBUyxHQUFHLEVBQUU7RUFDcEIxWixPQUFPLENBQ0ZyQyxNQUFNLENBQUVnYyxLQUFLLElBQUssRUFBRSxnQkFBZ0IsSUFBSUEsS0FBSyxDQUFDLElBQUlBLEtBQUssQ0FBQ0MsY0FBYyxDQUFDLENBQ3ZFMUUsT0FBTyxDQUFFeUUsS0FBSyxJQUFLO0lBQ3BCcmIsbURBQUcsQ0FBQyxZQUFZLEVBQUUsa0NBQWtDLEVBQUVxYixLQUFLLENBQUNqZCxNQUFNLENBQUM4USxFQUFFLENBQUM7SUFDdEVpTSxRQUFRLENBQUNJLFNBQVMsQ0FBQ0YsS0FBSyxDQUFDamQsTUFBTSxDQUFDO0lBQ2hDMmMsU0FBUyxDQUFDTSxLQUFLLENBQUNqZCxNQUFNLENBQUM4USxFQUFFLENBQUM7SUFDMUJrTSxTQUFTLENBQUNwRSxJQUFJLENBQUNxRSxLQUFLLENBQUNqZCxNQUFNLENBQUM4USxFQUFFLENBQUM7RUFDbkMsQ0FBQyxDQUFDO0VBQ0Z3TCxvREFBTSxDQUFDYyxhQUFhLEdBQUdkLG9EQUFNLENBQUNjLGFBQWEsQ0FBQ25jLE1BQU0sQ0FBRXFXLE1BQU0sSUFBSyxDQUFDMEYsU0FBUyxDQUFDdmdCLFFBQVEsQ0FBQzZhLE1BQU0sQ0FBQ3hHLEVBQUUsQ0FBQyxDQUFDO0FBQ2xHLENBQUM7QUFDRCxJQUFNdU0saUJBQWlCLEdBQUdBLENBQUMvWixPQUFPLEVBQUV5WixRQUFRLEtBQUs7RUFDN0MsSUFBTUMsU0FBUyxHQUFHLEVBQUU7RUFDcEIxWixPQUFPLENBQ0ZyQyxNQUFNLENBQUVnYyxLQUFLLElBQUssRUFBRSxnQkFBZ0IsSUFBSUEsS0FBSyxDQUFDLElBQUlBLEtBQUssQ0FBQ0MsY0FBYyxDQUFDLENBQ3ZFMUUsT0FBTyxDQUFFeUUsS0FBSyxJQUFLO0lBQ3BCcmIsbURBQUcsQ0FBQyxZQUFZLEVBQUUsaUNBQWlDLEVBQUVxYixLQUFLLENBQUNqZCxNQUFNLENBQUM4USxFQUFFLENBQUM7SUFDckVpTSxRQUFRLENBQUNJLFNBQVMsQ0FBQ0YsS0FBSyxDQUFDamQsTUFBTSxDQUFDO0lBQ2hDNmMsV0FBVyxDQUFDSSxLQUFLLENBQUNqZCxNQUFNLENBQUM4USxFQUFFLENBQUM7SUFDNUJrTSxTQUFTLENBQUNwRSxJQUFJLENBQUNxRSxLQUFLLENBQUNqZCxNQUFNLENBQUM4USxFQUFFLENBQUM7RUFDbkMsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNELElBQU13TSxvQkFBb0IsR0FBR2xYLHFEQUFJLENBQUVtWCxhQUFhLElBQUs7RUFDakQsT0FBTyxJQUFJN2YsTUFBTSxDQUFDOGYsb0JBQW9CLENBQUNWLG9CQUFvQixFQUFFO0lBQ3pEVyxVQUFVLEVBQUVGLGFBQWEsR0FBRyxTQUFTLEdBQUc7RUFDNUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDO0FBQ0YsSUFBTUcsaUJBQWlCLEdBQUd0WCxxREFBSSxDQUFDLE1BQU07RUFDakMsT0FBTyxJQUFJMUksTUFBTSxDQUFDOGYsb0JBQW9CLENBQUNILGlCQUFpQixFQUFFO0lBQ3RESSxVQUFVLEVBQUU7RUFDaEIsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDO0FBQ0Y7QUFDQTtBQUNBO0FBQ0EsSUFBTUUsb0JBQW9CLEdBQUdBLENBQUEsS0FBTSxDQUFDLFNBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQ2xoQixRQUFRLENBQUM0ZixtRkFBb0IsQ0FBQyxDQUFDLENBQUM7QUFDaEYsSUFBTXVCLGNBQWMsR0FBSXRHLE1BQU0sSUFBSztFQUN0QyxJQUFJZ0Ysb0RBQU0sQ0FBQ3VCLGVBQWUsRUFBRTtJQUN4QixJQUFNTixhQUFhLEdBQUdJLG9CQUFvQixDQUFDLENBQUM7SUFDNUNMLG9CQUFvQixDQUFDQyxhQUFhLENBQUMsQ0FBQ08sT0FBTyxDQUFDeEcsTUFBTSxDQUFDaEMsSUFBSSxDQUFDO0lBQ3hELElBQUlpSSxhQUFhLEVBQUU7TUFDZkcsaUJBQWlCLENBQUMsQ0FBQyxDQUFDSSxPQUFPLENBQUN4RyxNQUFNLENBQUNoQyxJQUFJLENBQUM7SUFDNUM7RUFDSixDQUFDLE1BQ0k7SUFDRHFILFNBQVMsQ0FBQ3JGLE1BQU0sQ0FBQ3hHLEVBQUUsQ0FBQztFQUN4QjtBQUNKLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4RWtFO0FBQ3JDO0FBQ3FDO0FBQ0M7QUFDcEUsSUFBTXhMLFVBQVUsR0FBR3hELDZFQUFVLENBQUM3RCxHQUFHLENBQUMsQ0FBQztBQUM1QixJQUFNdWUsVUFBVSxHQUFJbEYsTUFBTSxJQUFLO0VBQ2xDLElBQU0yRyxNQUFNLEdBQUdGLCtFQUFvQixDQUFDekcsTUFBTSxDQUFDeEcsRUFBRSxDQUFDO0VBQzlDeEwsVUFBVSxDQUFDOFQsSUFBSSxDQUFDLGVBQWUsRUFBRTZFLE1BQU0sQ0FBQztFQUN4QztFQUNBO0VBQ0E7RUFDQTtFQUNBLEtBQUszRyxNQUFNLENBQUM3QixhQUFhLENBQ3BCeUksS0FBSyxDQUFDLE1BQU07SUFDYjtFQUFBLENBQ0gsQ0FBQyxDQUNHMUUsSUFBSSxDQUFDLE1BQU07SUFDWmxVLFVBQVUsQ0FBQzhULElBQUksQ0FBQyxrQkFBa0IsRUFBRTZFLE1BQU0sQ0FBQztJQUMzQztJQUNBLElBQUkzRyxNQUFNLENBQUM2Ryx1QkFBdUIsRUFBRTtNQUNoQyxPQUFPN0csTUFBTSxDQUFDNkcsdUJBQXVCO0lBQ3pDO0lBQ0EsT0FBT3pCLCtEQUFnQixDQUFDcEYsTUFBTSxDQUFDO0VBQ25DLENBQUMsQ0FBQyxDQUNHa0MsSUFBSSxDQUFDLE1BQU07SUFDWmxVLFVBQVUsQ0FBQzhULElBQUksQ0FBQyxnQkFBZ0IsRUFBRTZFLE1BQU0sQ0FBQztJQUN6QzNZLFVBQVUsQ0FBQzhULElBQUksQ0FBQyxjQUFjLEVBQUU2RSxNQUFNLENBQUM7SUFDdkN2Z0IsTUFBTSxDQUFDb1YsU0FBUyxDQUFDc0wsT0FBTyxDQUFDOUcsTUFBTSxDQUFDeEcsRUFBRSxDQUFDO0VBQ3ZDLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDTSxJQUFNMkwsYUFBYSxHQUFJbkYsTUFBTSxJQUFLO0VBQ3JDO0VBQ0EsS0FBS0EsTUFBTSxDQUFDN0IsYUFBYSxDQUNwQitELElBQUksQ0FBQyxNQUFNaEcscURBQWMsQ0FBQyxNQUFNO0lBQ2pDLElBQUk4RCxNQUFNLENBQUN4RyxFQUFFLENBQUNyVSxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7TUFBQSxJQUFBNGhCLG9CQUFBO01BQ3JDLENBQUFBLG9CQUFBLEdBQUEvRyxNQUFNLENBQUNoQyxJQUFJLENBQ05nSixPQUFPLENBQUMsb0JBQW9CLENBQUMsY0FBQUQsb0JBQUEsZUFEbENBLG9CQUFBLENBRU0vSCxTQUFTLENBQUM3VSxNQUFNLENBQUMscUJBQXFCLENBQUM7SUFDakQ7RUFDSixDQUFDLENBQUMsQ0FBQyxDQUNFK1gsSUFBSSxDQUFDLE1BQU07SUFDWixPQUFPd0UsK0RBQWdCLENBQUMxRyxNQUFNLENBQUM7RUFDbkMsQ0FBQyxDQUFDLENBQ0drQyxJQUFJLENBQUMsTUFBTTtJQUNabEMsTUFBTSxDQUFDMUMsSUFBSSxDQUFDOEUsWUFBWSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUM7SUFDN0M7SUFDQXBDLE1BQU0sQ0FBQzFDLElBQUksQ0FBQzhFLFlBQVksQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDO0lBQ2xELElBQUlwQyxNQUFNLENBQUN4RyxFQUFFLEtBQUssdUJBQXVCLEVBQUU7TUFDdkM7TUFDQTtNQUNBLElBQUk3WSxLQUFLLENBQUMySSxPQUFPLENBQUMwVyxNQUFNLENBQUN6YixJQUFJLENBQUMsRUFBRTtRQUM1QixJQUFNb1osT0FBTyxHQUFHdlgsTUFBTSxDQUFDb1YsU0FBUyxDQUFDelcsV0FBVyxDQUFDLENBQUM7UUFDOUM0WSxPQUFPLENBQUNxRCxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLEVBQUVoQixNQUFNLENBQUN6YixJQUFJLENBQUM7UUFDcEN5YixNQUFNLENBQUMxQyxJQUFJLENBQUNtQyxpQkFBaUIsQ0FBQzlCLE9BQU8sQ0FBQ3NELEtBQUssQ0FBQyxDQUFDLENBQUM7TUFDbEQ7SUFDSjtJQUNBN2EsTUFBTSxDQUFDb1YsU0FBUyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDd0wsT0FBTyxDQUFDLENBQUNqSCxNQUFNLENBQUMxQyxJQUFJLENBQUMsQ0FBQztFQUNwRCxDQUFDLENBQUM7QUFDTixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFEZ0Q7QUFDWTtBQUM3RCxJQUFNOEoscUJBQXFCLEdBQUdBLENBQUNDLFVBQVUsRUFBRUMsTUFBTSxLQUFLO0VBQ2xEO0VBQ0EsSUFBSUEsTUFBTSxDQUFDcmUsR0FBRyxLQUFLLGVBQWUsSUFDOUIsQ0FBQ3FlLE1BQU0sQ0FBQ3JlLEdBQUcsQ0FBQ3NlLFVBQVUsQ0FBQyxlQUFlLENBQUMsRUFBRTtJQUN6QyxPQUFPLENBQUNELE1BQU0sQ0FBQztFQUNuQjtFQUNBO0VBQ0E7RUFDQSxJQUFJQSxNQUFNLENBQUN2SyxLQUFLLENBQUMvWCxNQUFNLEtBQUssQ0FBQyxFQUFFO0lBQzNCLE9BQU8sQ0FBQ3NpQixNQUFNLENBQUM7RUFDbkI7RUFDQTtFQUNBLElBQUksQ0FBQzNtQixLQUFLLENBQUMySSxPQUFPLENBQUMrZCxVQUFVLENBQUMsRUFBRTtJQUM1QixPQUFPLEVBQUU7RUFDYjtFQUNBO0VBQ0EsT0FBTyxDQUFBOWpCLGFBQUEsQ0FBQUEsYUFBQSxLQUVJK2pCLE1BQU07SUFDVHZLLEtBQUssRUFBRSxDQUFDLENBQUNzSyxVQUFVLENBQUMsQ0FBQyxDQUFDLEVBQUVBLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztFQUFDLEdBRTlDO0FBQ0wsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNRyxpQkFBaUI7RUFBQSxJQUFBM21CLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsV0FBT3dZLE9BQU8sRUFBSztJQUN6QyxJQUFNQyxtQkFBbUIsR0FBR0QsT0FBTyxDQUFDOWQsTUFBTSxDQUFFcVcsTUFBTSxJQUFLLENBQUNBLE1BQU0sQ0FBQzZHLHVCQUF1QixDQUFDO0lBQ3ZGLElBQU1sRSxPQUFPLEdBQUdHLE9BQU8sQ0FBQzZFLEdBQUcsQ0FBQyxDQUN4QlIscUVBQU0sQ0FBQzVCLFdBQVcsQ0FBQ21DLG1CQUFtQixDQUFDLEVBQ3ZDUix5REFBRSxDQUFDM0IsV0FBVyxDQUFDbUMsbUJBQW1CLENBQUMsQ0FDdEMsQ0FBQztJQUNGQSxtQkFBbUIsQ0FBQ3hHLE9BQU8sQ0FBRWxCLE1BQU0sSUFBSztNQUNwQ0EsTUFBTSxDQUFDNkcsdUJBQXVCLEdBQUdsRSxPQUFPO0lBQzVDLENBQUMsQ0FBQztJQUNGLE1BQU1BLE9BQU87RUFDakIsQ0FBQztFQUFBLGdCQVZLNkUsaUJBQWlCQSxDQUFBeFgsRUFBQTtJQUFBLE9BQUFuUCxJQUFBLENBQUEyTyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQVV0QjtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFNc2YsZ0JBQWdCO0VBQUEsSUFBQTlZLEtBQUEsR0FBQTJDLGlCQUFBLENBQUcsV0FBTytRLE1BQU0sRUFBSztJQUM5Q0EsTUFBTSxDQUFDNkcsdUJBQXVCLEdBQUdXLGlCQUFpQixDQUFDLENBQUN4SCxNQUFNLENBQUMsQ0FBQztJQUM1RCxNQUFNQSxNQUFNLENBQUM2Ryx1QkFBdUI7RUFDeEMsQ0FBQztFQUFBLGdCQUhZekIsZ0JBQWdCQSxDQUFBaEMsR0FBQTtJQUFBLE9BQUE5VyxLQUFBLENBQUFrRCxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQUc1QjtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTTRnQixnQkFBZ0I7RUFBQSxJQUFBL1osS0FBQSxHQUFBc0MsaUJBQUEsQ0FBRyxXQUFPK1EsTUFBTSxFQUFLO0lBQzlDLElBQU00SCxhQUFhLEdBQUdULHFFQUFNLENBQUM1QixXQUFXLENBQUMsQ0FBQ3ZGLE1BQU0sQ0FBQyxFQUFHNkgsVUFBVSxJQUFLVCxxQkFBcUIsQ0FBQ3BILE1BQU0sQ0FBQ3piLElBQUksRUFBRXNqQixVQUFVLENBQUMsQ0FBQztJQUNsSCxJQUFNQyxTQUFTLEdBQUdaLHlEQUFFLENBQUMzQixXQUFXLENBQUMsQ0FBQ3ZGLE1BQU0sQ0FBQyxFQUFHK0gsTUFBTSxJQUFLWCxxQkFBcUIsQ0FBQ3BILE1BQU0sQ0FBQ3piLElBQUksRUFBRXdqQixNQUFNLENBQUMsQ0FBQztJQUNsRyxNQUFNakYsT0FBTyxDQUFDNkUsR0FBRyxDQUFDLENBQUNDLGFBQWEsRUFBRUUsU0FBUyxDQUFDLENBQUM7RUFDakQsQ0FBQztFQUFBLGdCQUpZcEIsZ0JBQWdCQSxDQUFBc0IsR0FBQTtJQUFBLE9BQUFyYixLQUFBLENBQUE2QyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQUk1QixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFEb0M7QUFDUDtBQUNjO0FBQzVDLElBQU1taUIsZ0JBQWdCLEdBQUlqSSxNQUFNLElBQUs7RUFDakNnRixvREFBTSxDQUFDeUMsT0FBTyxDQUFDUyxNQUFNLENBQUNsSSxNQUFNLENBQUN4RyxFQUFFLENBQUM7RUFDaEN3TCxvREFBTSxDQUFDYyxhQUFhLEdBQUdkLG9EQUFNLENBQUNjLGFBQWEsQ0FBQ25jLE1BQU0sQ0FBRTFFLENBQUMsSUFBS0EsQ0FBQyxLQUFLK2EsTUFBTSxDQUFDO0FBQzNFLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNbUksbUJBQW1CLEdBQUlyTCxVQUFVLElBQUs7RUFDeEMsSUFBTXNMLE1BQU0sR0FBR3RMLFVBQVUsQ0FBQ3VMLGFBQWE7RUFDdkMsSUFBTUMsYUFBYSxHQUFHRixNQUFNLFlBQVlHLFdBQVcsSUFDL0NILE1BQU0sQ0FBQ3BKLFNBQVMsQ0FBQ3dKLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQztFQUNsRCxJQUFJLENBQUNGLGFBQWEsRUFBRTtJQUNoQixPQUFPeEwsVUFBVTtFQUNyQjtFQUNBLElBQU0yTCxpQkFBaUIsR0FBR0wsTUFBTSxDQUFDcEIsT0FBTyxDQUFDLDJEQUEyRCxDQUFDO0VBQ3JHLElBQUksQ0FBQ3lCLGlCQUFpQixFQUFFO0lBQ3BCLE9BQU9MLE1BQU07RUFDakI7RUFDQSxPQUFPSyxpQkFBaUI7QUFDNUIsQ0FBQztBQUNELElBQU1DLGlCQUFpQixHQUFJQyxXQUFXLElBQUs7RUFDdkMsSUFBTUMsZUFBZSxHQUFHVCxtQkFBbUIsQ0FBQ1EsV0FBVyxDQUFDO0VBQ3hEQyxlQUFlLENBQUNDLEtBQUssQ0FBQy9CLE9BQU8sR0FBRyxNQUFNO0FBQzFDLENBQUM7QUFDRCxJQUFNZ0MsV0FBVyxHQUFJOUksTUFBTSxJQUFLO0VBQzVCMVYsbURBQUcsQ0FBQyxZQUFZLDRCQUFBcEosTUFBQSxDQUE0QjhlLE1BQU0sQ0FBQ3hHLEVBQUUsQ0FBRSxDQUFDO0VBQ3hEMEMscURBQWMsQ0FBQyxNQUFNO0lBQ2pCOVYsTUFBTSxDQUFDb1YsU0FBUyxDQUFDdU4sWUFBWSxDQUFDLENBQUMvSSxNQUFNLENBQUMxQyxJQUFJLENBQUMsQ0FBQztJQUM1Q29MLGlCQUFpQixDQUFDMUksTUFBTSxDQUFDaEMsSUFBSSxDQUFDO0lBQzlCaUssZ0JBQWdCLENBQUNqSSxNQUFNLENBQUM7RUFDNUIsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUN5QztBQUNuQyxJQUFNL2EsQ0FBQyxHQUFHO0VBQ2JrakI7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekMwQztBQUNhO0FBQ1g7QUFDN0MsSUFBTWMsc0JBQXNCLEdBQUcsQ0FDM0IsUUFBUTtBQUFFO0FBQ1YsUUFBUTtBQUFFO0FBQ1YsUUFBUTtBQUFFO0FBQ1YsUUFBUTtBQUFFO0FBQ1YsUUFBUSxDQUFFO0FBQUEsQ0FDYjtBQUNELElBQU1DLGlCQUFpQixHQUFHQSxDQUFDckwsVUFBVSxFQUFFc0wsa0JBQWtCLEtBQUs7RUFDMUQsSUFBSUEsa0JBQWtCLElBQ2xCRixzQkFBc0IsQ0FBQzlqQixRQUFRLENBQUNna0Isa0JBQWtCLENBQUMsRUFBRTtJQUNyRCxPQUFPLEtBQUs7RUFDaEI7RUFDQSxJQUFJdEwsVUFBVSxDQUFDbUIsU0FBUyxDQUFDd0osUUFBUSxDQUFDLGdCQUFnQixDQUFDLElBQy9DM0ssVUFBVSxDQUFDbUIsU0FBUyxDQUFDd0osUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUM1QzNLLFVBQVUsQ0FBQ21CLFNBQVMsQ0FBQ3dKLFFBQVEsQ0FBQyxLQUFLLENBQUM7RUFDcEM7RUFDQTNLLFVBQVUsQ0FBQ21CLFNBQVMsQ0FBQ3dKLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxJQUNsRDNLLFVBQVUsQ0FBQ1osWUFBWSxDQUFDLFlBQVksQ0FBQyxLQUFLLE9BQU8sRUFBRTtJQUNuRCxPQUFPLEtBQUs7RUFDaEI7RUFDQSxPQUFPLElBQUk7QUFDZixDQUFDO0FBQ0QsSUFBTW1NLHVCQUF1QixHQUFJdkwsVUFBVSxJQUFLQSxVQUFVLENBQUNtQixTQUFTLENBQUN3SixRQUFRLENBQUMsd0JBQXdCLENBQUM7QUFDdkcsSUFBTWEsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTTtFQUMzQixJQUFNQyxRQUFRLEdBQUc1YSxRQUFRLENBQUM2YSxhQUFhLENBQUMsUUFBUSxDQUFDO0VBQ2pERCxRQUFRLENBQUNFLFNBQVMsR0FBRyx1QkFBdUI7RUFDNUNGLFFBQVEsQ0FBQ0csU0FBUyxHQUFHVCxrRUFBUztFQUM5Qk0sUUFBUSxDQUFDSSxPQUFPLEdBQUcsTUFBTTtJQUNyQixJQUFNQyxTQUFTLEdBQUdMLFFBQVEsQ0FBQ3RDLE9BQU8sQ0FBQyx5QkFBeUIsQ0FBQztJQUM3RCxJQUFJMkMsU0FBUyxFQUNUQSxTQUFTLENBQUN4ZixNQUFNLENBQUMsQ0FBQztFQUMxQixDQUFDO0VBQ0QsSUFBTXlmLFFBQVEsR0FBR2xiLFFBQVEsQ0FBQzZhLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDOUNLLFFBQVEsQ0FBQ2YsS0FBSyxDQUFDZ0IsT0FBTyxHQUFHLHlDQUF5QztFQUNsRUQsUUFBUSxDQUFDRSxXQUFXLENBQUNSLFFBQVEsQ0FBQztFQUM5QixPQUFPTSxRQUFRO0FBQ25CLENBQUM7QUFDRCxJQUFNRyx1QkFBdUIsR0FBSWxNLFVBQVUsSUFBSyxDQUFDLENBQUN4WSx5REFBUyxDQUFDO0VBQ3hEd0IsSUFBSSxFQUFFLGdCQUFnQjtFQUN0QkMsYUFBYSxFQUFFO0FBQ25CLENBQUMsQ0FBQyxJQUFJLENBQUMrVyxVQUFVLENBQUNtQixTQUFTLENBQUN3SixRQUFRLENBQUMsY0FBYyxDQUFDO0FBQ3BEO0FBQ0EsSUFBTXdCLGlCQUFpQixHQUFHQSxDQUFDQyxZQUFZLEVBQUVDLFVBQVUsS0FBSztFQUNwRCxJQUFJQyxXQUFXLEdBQUcsRUFBRTtFQUNwQixJQUFJRixZQUFZLElBQUlDLFVBQVUsRUFBRTtJQUM1QkMsV0FBVyxpQkFBQWpwQixNQUFBLENBQWlCZ3BCLFVBQVUsT0FBSTtFQUM5QztFQUNBLE9BQU9DLFdBQVc7QUFDdEIsQ0FBQztBQUNELElBQU1DLDZCQUE2QixHQUFHQSxDQUFBLEtBQU07RUFDeEMsSUFBTUMsdUJBQXVCLEdBQUczYixRQUFRLENBQUM2YSxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQzdEYyx1QkFBdUIsQ0FBQ3hCLEtBQUssQ0FBQ2dCLE9BQU8sR0FDakMseUdBQXlHO0VBQzdHLElBQU10VSxHQUFHLEdBQUcsSUFBSXhELEdBQUcsQ0FBQzNMLE1BQU0sQ0FBQ3FGLFFBQVEsQ0FBQzZlLElBQUksQ0FBQztFQUN6Qy9VLEdBQUcsQ0FBQ2dWLFlBQVksQ0FBQ0MsR0FBRyxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7RUFDdkMsSUFBTUMsU0FBUyxHQUFHL2IsUUFBUSxDQUFDNmEsYUFBYSxDQUFDLEdBQUcsQ0FBQztFQUM3Q2tCLFNBQVMsQ0FBQ2pCLFNBQVMsR0FBRyxtQ0FBbUM7RUFDekRpQixTQUFTLENBQUNILElBQUksR0FBRy9VLEdBQUcsQ0FBQytVLElBQUk7RUFDekJHLFNBQVMsQ0FBQ2hCLFNBQVMsR0FBRyxPQUFPO0VBQzdCWSx1QkFBdUIsQ0FBQ1AsV0FBVyxDQUFDVyxTQUFTLENBQUM7RUFDOUMsT0FBT0osdUJBQXVCO0FBQ2xDLENBQUM7QUFDRCxJQUFNSyxpQkFBaUIsR0FBR0EsQ0FBQzdNLFVBQVUsRUFBRXNMLGtCQUFrQixLQUFLO0VBQzFELE9BQU9qTiw0REFBTyxDQUFDeU8sT0FBTyxDQUFDLE1BQU07SUFDekIsSUFBSXpCLGlCQUFpQixDQUFDckwsVUFBVSxFQUFFc0wsa0JBQWtCLENBQUMsRUFBRTtNQUFBLElBQUF5QixxQkFBQTtNQUNuRCxJQUFNQyxpQkFBaUIsR0FBR2QsdUJBQXVCLENBQUNsTSxVQUFVLENBQUM7TUFDN0QsSUFBTWlOLGlCQUFpQixHQUFHLEVBQUFGLHFCQUFBLEdBQUEvTSxVQUFVLENBQUNrTixVQUFVLGNBQUFILHFCQUFBLGdCQUFBQSxxQkFBQSxHQUFyQkEscUJBQUEsQ0FBdUJJLGlCQUFpQixjQUFBSixxQkFBQSx1QkFBeENBLHFCQUFBLENBQ3BCSSxpQkFBaUIsYUFBWUMsaUJBQWlCO01BQ3BELElBQU1DLGdCQUFnQixHQUFHN2xCLHlEQUFTLENBQUM7UUFDL0J3QixJQUFJLEVBQUUsUUFBUTtRQUNkQyxhQUFhLEVBQUU7TUFDbkIsQ0FBQyxDQUFDO01BQ0YsSUFBTXFrQixjQUFjLG1CQUFBanFCLE1BQUEsQ0FBbUI4b0IsaUJBQWlCLENBQUNhLGlCQUFpQixFQUFFSyxnQkFBZ0IsQ0FBQyxDQUFFO01BQy9GLE9BQU9oUCw0REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07UUFBQSxJQUFBcU0scUJBQUE7UUFDeEJ2TixVQUFVLENBQUN3TixZQUFZLENBQUMsaUJBQWlCLEVBQUUsTUFBTSxDQUFDO1FBQ2xEeE4sVUFBVSxDQUFDd04sWUFBWSxDQUFDLGVBQWUsRUFBRUYsY0FBYyxDQUFDO1FBQ3hEO1FBQ0EsSUFBSSxDQUFBQyxxQkFBQSxHQUFBdk4sVUFBVSxDQUFDd0ssYUFBYSxjQUFBK0MscUJBQUEsZUFBeEJBLHFCQUFBLENBQTBCcE0sU0FBUyxDQUFDd0osUUFBUSxDQUFDLG1CQUFtQixDQUFDLElBQ2pFM0ssVUFBVSxDQUFDckUsRUFBRSxLQUFLLHVCQUF1QixFQUFFO1VBQzNDcUUsVUFBVSxDQUFDd0ssYUFBYSxDQUFDZ0QsWUFBWSxDQUFDLDJCQUEyQixFQUFFLE1BQU0sQ0FBQztRQUM5RTtRQUNBO1FBQ0EsSUFBSWpDLHVCQUF1QixDQUFDdkwsVUFBVSxDQUFDLEVBQUU7VUFDckNBLFVBQVUsQ0FBQ3lOLFlBQVksQ0FBQ2pDLGdCQUFnQixDQUFDLENBQUMsRUFBRXhMLFVBQVUsQ0FBQzBOLFVBQVUsQ0FBQztRQUN0RTtRQUNBLElBQUlWLGlCQUFpQixJQUNqQkssZ0JBQWdCLElBQ2hCLENBQUNKLGlCQUFpQixFQUFFO1VBQUEsSUFBQVUsc0JBQUE7VUFDcEIsQ0FBQUEsc0JBQUEsR0FBQTNOLFVBQVUsQ0FBQ2tOLFVBQVUsY0FBQVMsc0JBQUEsZUFBckJBLHNCQUFBLENBQXVCRixZQUFZLENBQUNsQiw2QkFBNkIsQ0FBQyxDQUFDLEVBQUV2TSxVQUFVLENBQUM7UUFDcEY7TUFDSixDQUFDLENBQUM7SUFDTjtJQUNBLE9BQU9pRixPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0VBQzVCLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxJQUFNeUksOEJBQThCLEdBQUdBLENBQUM1TixVQUFVLEVBQUU2TixTQUFTLEtBQUt4UCw0REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07RUFDbkYsSUFBTTRNLGtCQUFrQixHQUFHamQsUUFBUSxDQUFDNmEsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUN4RG9DLGtCQUFrQixDQUFDM00sU0FBUyxDQUFDQyxHQUFHLENBQUMsaUJBQWlCLENBQUM7RUFDbkQwTSxrQkFBa0IsQ0FBQ2xDLFNBQVMsR0FBRyxpQkFBaUI7RUFDaERrQyxrQkFBa0IsQ0FBQ04sWUFBWSxDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUM7RUFDakRNLGtCQUFrQixDQUFDakMsT0FBTyxHQUFJa0MsS0FBSyxJQUFLO0lBQ3BDL04sVUFBVSxDQUFDZ08sY0FBYyxDQUFDO01BQ3RCQyxRQUFRLEVBQUUsUUFBUTtNQUNsQkMsS0FBSyxFQUFFO0lBQ1gsQ0FBQyxDQUFDO0lBQ0ZILEtBQUssQ0FBQ0ksY0FBYyxDQUFDLENBQUM7RUFDMUIsQ0FBQztFQUNELElBQUlOLFNBQVMsRUFBRTtJQUNYQyxrQkFBa0IsQ0FBQzNNLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDLGVBQWUsQ0FBQztFQUNyRDtFQUNBcEIsVUFBVSxDQUFDaU0sV0FBVyxDQUFDNkIsa0JBQWtCLENBQUM7QUFDOUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2xIMEU7QUFDOUI7QUFDOUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1RLGVBQWUsR0FBRztBQUMzQjtBQUNBRCx1REFBUyxFQUNURCxxRkFBc0IsQ0FDekIsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1hNLElBQU1HLDhCQUE4QixHQUFHQSxDQUFBLEtBQU07RUFDaEQsSUFBSWhtQixNQUFNLENBQUNxRixRQUFRLENBQUM0Z0IsSUFBSSxDQUFDOUUsVUFBVSxDQUFDLEtBQUssQ0FBQyxFQUFFO0lBQ3hDLElBQU0rRSxNQUFNLEdBQUdsbUIsTUFBTSxDQUFDcUYsUUFBUSxDQUFDNGdCLElBQUksQ0FBQzFQLE9BQU8sQ0FBQyxNQUFNLEVBQUUsRUFBRSxDQUFDLENBQUNsSCxLQUFLLENBQUMsR0FBRyxDQUFDO0lBQ2xFLE9BQU82VyxNQUFNLENBQUNqVCxNQUFNLENBQUMsQ0FBQ0YsR0FBRyxFQUFFb1QsS0FBSyxLQUFLO01BQ2pDLElBQU0sQ0FBQ0MsTUFBTSxFQUFFQyxTQUFTLENBQUMsR0FBR0YsS0FBSyxDQUFDOVcsS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUM1QyxJQUFJK1csTUFBTSxFQUFFO1FBQ1IsSUFBSUMsU0FBUyxFQUFFO1VBQ1gsT0FBQWxwQixhQUFBLENBQUFBLGFBQUEsS0FDTzRWLEdBQUc7WUFDTixDQUFDcVQsTUFBTSxHQUFHO2NBQ050UyxPQUFPLEVBQUV1UztZQUNiO1VBQUM7UUFFVDtRQUNBLE9BQUFscEIsYUFBQSxDQUFBQSxhQUFBLEtBQ080VixHQUFHO1VBQ04sQ0FBQ3FULE1BQU0sR0FBR3ptQjtRQUFTO01BRTNCO01BQ0EsT0FBT29ULEdBQUc7SUFDZCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDVjtFQUNBLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2QnNDO0FBQ1M7QUFDNkQ7QUFDaEU7QUFDYTtBQUMxRCxJQUFNMFQsV0FBVyxHQUFHLENBQUM7QUFDckIsSUFBTUMsV0FBVyxHQUFHLE9BQVM7QUFDN0I7QUFDQSxJQUFNQyxVQUFVLEdBQUl2VCxFQUFFLElBQUs7RUFDdkIsSUFBSSxDQUFDQSxFQUFFLEVBQ0gsT0FBTyxDQUFDO0VBQ1osSUFBTXdULE1BQU0sR0FBR3ZqQixNQUFNLENBQUMrUCxFQUFFLENBQUM7RUFDekIsSUFBSS9QLE1BQU0sQ0FBQ0ksS0FBSyxDQUFDbWpCLE1BQU0sQ0FBQyxFQUNwQjtFQUNKLElBQUlBLE1BQU0sR0FBR0gsV0FBVyxFQUNwQjtFQUNKLElBQUlHLE1BQU0sR0FBR0YsV0FBVyxFQUNwQjtFQUNKLE9BQU9FLE1BQU07QUFDakIsQ0FBQztBQUNELElBQU1DLFFBQVEsR0FBR0EsQ0FBQSxLQUFNRixVQUFVLENBQUMxbkIseURBQVMsQ0FBQztFQUN4Q3dCLElBQUksRUFBRSxXQUFXO0VBQ2pCQyxhQUFhLEVBQUU7QUFDbkIsQ0FBQyxDQUFDLENBQUM7QUFDSCxJQUFNb21CLEtBQUssR0FBR0QsUUFBUSxDQUFDLENBQUM7QUFDeEIsSUFBTUUsY0FBYyxHQUFHcGhCLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDNUYsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQzhtQixRQUFRLENBQUMsQ0FBQy9ULE1BQU0sQ0FBQyxDQUFDZ1UsSUFBSSxFQUFBeHNCLElBQUE7RUFBQSxJQUFFLENBQUNvSSxHQUFHLEVBQUVxa0IsR0FBRyxDQUFDLEdBQUF6c0IsSUFBQTtFQUFBLE9BQUEwQyxhQUFBLENBQUFBLGFBQUEsS0FBVzhwQixJQUFJO0lBQUUsQ0FBQ3BrQixHQUFHLEdBQUdxa0I7RUFBRztBQUFBLENBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNsSSxJQUFNQyxJQUFJLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUFwYixxQkFBQTtFQUNmLElBQU1xYixrQkFBa0IsR0FBQWpxQixhQUFBLENBQUFBLGFBQUEsS0FDakJvcEIsdUZBQWlDLENBQUMsQ0FBQyxHQUNuQ1AsdUVBQThCLENBQUMsQ0FBQyxDQUN0QztFQUNEUSxxRkFBK0IsQ0FBQ1ksa0JBQWtCLENBQUM7RUFDbkQsSUFBTUMsV0FBVyxHQUFHLEVBQUU7RUFDdEI7RUFDQSxJQUFNQyxXQUFXLEdBQUk5QixLQUFLLElBQUs7SUFDM0I2QixXQUFXLENBQUNuTSxJQUFJLENBQUNzSyxLQUFLLENBQUM7SUFDdkIsSUFBSXhsQixNQUFNLENBQUNDLFFBQVEsQ0FBQ3lOLEtBQUssRUFBRTtNQUN2QjJaLFdBQVcsQ0FBQ3ZNLE9BQU8sQ0FBRTNTLENBQUM7UUFBQSxJQUFBb2YscUJBQUE7UUFBQSxRQUFBQSxxQkFBQSxHQUFLdm5CLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDeU4sS0FBSyxjQUFBNloscUJBQUEsdUJBQXJCQSxxQkFBQSxDQUF1QkMsTUFBTSxDQUFDcmYsQ0FBQyxDQUFDO01BQUEsRUFBQztJQUNoRTtFQUNKLENBQUM7RUFDRCxJQUFNK0wsRUFBRSxHQUFHLElBQUlvUyxpREFBRSxDQUFDO0lBQ2RRLEtBQUssRUFBRUEsS0FBSyxhQUFMQSxLQUFLLGNBQUxBLEtBQUssR0FBSSxDQUFDLENBQUM7SUFDbEJKLFdBQVc7SUFDWGUsZUFBZSxFQUFFem5CLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzhNLFdBQVc7SUFDeEQ4WixjQUFjO0lBQ2RXLGtCQUFrQixFQUFFM0Isc0RBQWU7SUFDbkNxQixrQkFBa0I7SUFDbEJFLFdBQVc7SUFDWEssZUFBZSxHQUFBNWIscUJBQUEsR0FBRS9MLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUMyTixLQUFLLGNBQUE5QixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsQ0FBQztJQUNuRDZiLGFBQWEsRUFBRy9OLEtBQUssSUFBSztNQUN0QnJRLE9BQU8sQ0FBQ3RGLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRTJWLEtBQUssQ0FBQztJQUN6QztFQUNKLENBQUMsQ0FBQztFQUNGLElBQU1nTyxnQkFBZ0IsR0FBRzNULEVBQUUsQ0FBQzJULGdCQUFnQixDQUFDOUIsc0RBQWUsQ0FBQztFQUM3RDdSLEVBQUUsQ0FBQzRULFlBQVksQ0FBQ0QsZ0JBQWdCLENBQUM7RUFDakMzVCxFQUFFLENBQUM2VCx3QkFBd0IsQ0FBQ0YsZ0JBQWdCLENBQUM7RUFDN0MzVCxFQUFFLENBQUM4VCxzQkFBc0IsQ0FBQ0gsZ0JBQWdCLENBQUM7RUFDM0MzakIsbURBQUcsQ0FBQyxZQUFZLEVBQUUsc0JBQXNCLENBQUM7RUFDekMsT0FBT2dRLEVBQUU7QUFDYixDQUFDO0FBQ00sSUFBTStULGlCQUFpQixHQUFHQSxDQUFBLEtBQU07RUFDbkMsSUFBTS9ULEVBQUUsR0FBR2lULElBQUksQ0FBQyxDQUFDO0VBQ2pCLElBQU1lLGFBQWEsR0FBR2hVLEVBQUUsQ0FBQzJULGdCQUFnQixDQUFDOUIsc0RBQWUsQ0FBQztFQUMxRCxJQUFNcFksY0FBYyxHQUFHdWEsYUFBYSxDQUFDalYsTUFBTSxDQUFDLENBQUNrVixHQUFHLEVBQUV4bUIsSUFBSSxLQUFLO0lBQ3ZEd21CLEdBQUcsQ0FBQ3htQixJQUFJLENBQUN5UixFQUFFLENBQUMsR0FBRztNQUFFVSxPQUFPLEVBQUVuUyxJQUFJLENBQUN5bUIsWUFBWSxDQUFDaFY7SUFBRyxDQUFDO0lBQ2hELE9BQU8rVSxHQUFHO0VBQ2QsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ04sT0FBT3hhLGNBQWM7QUFDekIsQ0FBQztBQUNNLElBQU0wYSxlQUFlLEdBQUdBLENBQUMxbUIsSUFBSSxFQUFFMGtCLFNBQVMsS0FBSztFQUNoRCxJQUFNblMsRUFBRSxHQUFHaVQsSUFBSSxDQUFDLENBQUM7RUFDakIsT0FBT2pULEVBQUUsQ0FBQ21VLGVBQWUsQ0FBQzFtQixJQUFJLENBQUN5UixFQUFFLEVBQUVpVCxTQUFTLENBQUM7QUFDakQsQ0FBQztBQUNNLElBQU1pQyxVQUFVLEdBQUkzbUIsSUFBSSxJQUFLO0VBQUEsSUFBQTRtQixxQkFBQTtFQUNoQyxJQUFNNWEsY0FBYyxHQUFHc2EsaUJBQWlCLENBQUMsQ0FBQztFQUMxQyxRQUFBTSxxQkFBQSxHQUFPNWEsY0FBYyxDQUFDaE0sSUFBSSxDQUFDeVIsRUFBRSxDQUFDLGNBQUFtVixxQkFBQSx1QkFBdkJBLHFCQUFBLENBQXlCelUsT0FBTztBQUMzQyxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7O0FDNUVNLElBQU0rUixzQkFBc0IsR0FBRztFQUNsQ3pTLEVBQUUsRUFBRSx3QkFBd0I7RUFDNUJvVixNQUFNLEVBQUUsaUJBQWlCO0VBQ3pCQyxLQUFLLEVBQUUsWUFBWTtFQUNuQkMsTUFBTSxFQUFFLFlBQVk7RUFDcEJDLFFBQVEsRUFBRSxHQUFHLEdBQUcsR0FBRztFQUNuQkMsY0FBYyxFQUFFLENBQUMsR0FBRyxHQUFHO0VBQ3ZCQyxnQkFBZ0IsRUFBRSxFQUFFO0VBQ3BCQyxjQUFjLEVBQUUsRUFBRTtFQUNsQkMsV0FBVyxFQUFFLG9FQUFvRTtFQUNqRkMsUUFBUSxFQUFFLENBQ047SUFDSTVWLEVBQUUsRUFBRSxTQUFTO0lBQ2J6UixJQUFJLEVBQUVBLENBQUEsS0FBTTtNQUNSO0lBQUE7RUFFUixDQUFDO0VBQ0Q7QUFDUjtBQUNBO0FBQ0E7RUFDUTtJQUNJeVIsRUFBRSxFQUFFLGdCQUFnQjtJQUNwQnpSLElBQUksRUFBRUEsQ0FBQSxLQUFNO01BQ1I7SUFBQTtFQUVSLENBQUM7RUFDRDtBQUNSO0FBQ0E7QUFDQTtFQUNRO0lBQ0l5UixFQUFFLEVBQUUsaUJBQWlCO0lBQ3JCelIsSUFBSSxFQUFFQSxDQUFBLEtBQU07TUFDUjtJQUFBO0VBRVIsQ0FBQyxDQUNKO0VBQ0RzbkIsTUFBTSxFQUFFQSxDQUFBLEtBQU07QUFDbEIsQ0FBQyxDOzs7Ozs7Ozs7Ozs7OztBQ3ZDTSxJQUFNbkQsU0FBUyxHQUFHO0VBQ3JCMVMsRUFBRSxFQUFFLFdBQVc7RUFDZm9WLE1BQU0sRUFBRSxpQkFBaUI7RUFDekJDLEtBQUssRUFBRSxZQUFZO0VBQ25CQyxNQUFNLEVBQUUsWUFBWTtFQUNwQkMsUUFBUSxFQUFFLENBQUMsR0FBRyxHQUFHO0VBQ2pCQyxjQUFjLEVBQUUsQ0FBQyxHQUFHLEdBQUc7RUFDdkJDLGdCQUFnQixFQUFFLEVBQUU7RUFDcEJDLGNBQWMsRUFBRSxFQUFFO0VBQ2xCQyxXQUFXLEVBQUUsaURBQWlEO0VBQzlEQyxRQUFRLEVBQUUsQ0FDTjtJQUNJNVYsRUFBRSxFQUFFLFNBQVM7SUFDYnpSLElBQUksRUFBRUEsQ0FBQSxLQUFNO01BQ1I7SUFBQTtFQUVSLENBQUMsRUFDRDtJQUNJeVIsRUFBRSxFQUFFLFNBQVM7SUFDYnpSLElBQUksRUFBRUEsQ0FBQSxLQUFNO01BQ1I7SUFBQTtFQUVSLENBQUMsQ0FDSjtFQUNEc25CLE1BQU0sRUFBRUEsQ0FBQSxLQUFNO0FBQ2xCLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7O0FDekJnRDtBQUNqRCxJQUFJRSxtQkFBbUI7QUFDdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyx5QkFBeUIsR0FBR0EsQ0FBQSxLQUFNO0VBQ3BDRiwrREFBZSxDQUFFL2YsT0FBTyxJQUFLO0lBQ3pCLElBQUlnZ0IsbUJBQW1CLEtBQUt4cEIsU0FBUyxFQUFFO01BQ25Dd3BCLG1CQUFtQixHQUFHaGdCLE9BQU87SUFDakM7SUFDQSxJQUFJZ2dCLG1CQUFtQixDQUFDNVgsU0FBUyxLQUFLcEksT0FBTyxDQUFDb0ksU0FBUyxFQUFFO01BQ3JEdlIsTUFBTSxDQUFDcUYsUUFBUSxDQUFDZ2tCLE1BQU0sQ0FBQyxDQUFDO0lBQzVCO0VBQ0osQ0FBQyxFQUFFLElBQUksQ0FBQztFQUNSLE9BQU8zTSxPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0FBQzVCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2hCd0Q7QUFDZDtBQUMzQztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNdUssSUFBSSxHQUFHQSxDQUFBLEtBQU07RUFDZixJQUFNcUMsV0FBVyxHQUFHdFAsb0RBQVUsQ0FBQyxDQUFDO0VBQ2hDLElBQUlzUCxXQUFXLENBQUNDLE1BQU0sS0FBSyxPQUFPLEVBQUU7SUFDaENILDREQUFZLENBQUM7TUFBRTdvQixJQUFJLEVBQUU7SUFBUyxDQUFDLENBQUM7RUFDcEMsQ0FBQyxNQUNJLElBQUkrb0IsV0FBVyxDQUFDQyxNQUFNLEVBQUU7SUFDekJGLHlEQUFTLENBQUM7TUFDTjlvQixJQUFJLEVBQUUsUUFBUTtNQUNkMkUsS0FBSyxFQUFFc2tCLGtCQUFrQixDQUFDRixXQUFXLENBQUNDLE1BQU0sQ0FBQztNQUM3Q0UsVUFBVSxFQUFFO0lBQ2hCLENBQUMsQ0FBQztFQUNOO0VBQ0EsT0FBT2pOLE9BQU8sQ0FBQ0UsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckJ3RDtBQUNkO0FBQzNDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU11SyxJQUFJLEdBQUdBLENBQUEsS0FBTTtFQUNmLElBQU1xQyxXQUFXLEdBQUd0UCxvREFBVSxDQUFDLENBQUM7RUFDaEMsSUFBSXNQLFdBQVcsQ0FBQ0ksY0FBYyxLQUFLLE9BQU8sRUFBRTtJQUN4Q04sNERBQVksQ0FBQztNQUFFN29CLElBQUksRUFBRTtJQUFpQixDQUFDLENBQUM7RUFDNUMsQ0FBQyxNQUNJLElBQUkrb0IsV0FBVyxDQUFDSSxjQUFjLEVBQUU7SUFDakNMLHlEQUFTLENBQUM7TUFDTjlvQixJQUFJLEVBQUUsZ0JBQWdCO01BQ3RCMkUsS0FBSyxFQUFFO0lBQ1gsQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPc1gsT0FBTyxDQUFDRSxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEJvQztBQUNrQjtBQUNEO0FBQ0Y7QUFDUjtBQUNVO0FBQ0U7QUFDeEQsSUFBTXFDLFNBQVMsR0FBR0EsQ0FBQ3JGLE1BQU0sRUFBRWtRLFlBQVksS0FBSztFQUN4QyxJQUFJbEwsb0RBQU0sQ0FBQ21MLGNBQWMsQ0FBQyxDQUFDLElBQUksQ0FBQ0QsWUFBWSxFQUFFO0lBQzFDRCxrRUFBVyxDQUFDalEsTUFBTSxDQUFDO0lBQ25Cc0csa0VBQWMsQ0FBQ3RHLE1BQU0sQ0FBQztFQUMxQixDQUFDLE1BQ0k7SUFDRGtGLGdFQUFVLENBQUNsRixNQUFNLENBQUM7RUFDdEI7QUFDSixDQUFDO0FBQ0QsSUFBTW9RLGlCQUFpQixHQUFHQSxDQUFDdFEsTUFBTSxFQUFFb1EsWUFBWSxFQUFFblEsZUFBZSxFQUFFaEMsYUFBYSxLQUFLO0VBQ2hGLE9BQU8sSUFBSStFLE9BQU8sQ0FBRUUsT0FBTyxJQUFLO0lBQzVCNWMsTUFBTSxDQUFDb1YsU0FBUyxDQUFDNlUsR0FBRyxDQUFDL08sSUFBSSxDQUFDLE1BQU07TUFDNUI7TUFDQSxJQUFJMEQsb0RBQU0sQ0FBQ3lDLE9BQU8sQ0FBQzZJLEdBQUcsQ0FBQ3hRLE1BQU0sQ0FBQ3RHLEVBQUUsQ0FBQyxFQUFFO1FBQy9CLElBQU0rVyxZQUFZLCtDQUFBcnZCLE1BQUEsQ0FBK0M0ZSxNQUFNLENBQUN0RyxFQUFFLENBQUU7UUFDNUVsUCxtREFBRyxDQUFDLFlBQVksRUFBRWltQixZQUFZLENBQUM7UUFDL0I1USxvRUFBVyxDQUFDTCxLQUFLLENBQUNpUixZQUFZLENBQUMsRUFBRSxZQUFZLEVBQUU7VUFDM0NsVixNQUFNLEVBQUV5RSxNQUFNLENBQUN0RztRQUNuQixDQUFDLENBQUM7UUFDRjtNQUNKO01BQ0EsSUFBTXdHLE1BQU0sR0FBR0gsbUVBQVksQ0FBQ0MsTUFBTSxFQUFFQyxlQUFlLEVBQUVoQyxhQUFhLENBQUM7TUFDbkUsSUFBSWlDLE1BQU0sS0FBSyxJQUFJLEVBQ2Y7TUFDSmdGLG9EQUFNLENBQUN5QyxPQUFPLENBQUMrQyxHQUFHLENBQUN4SyxNQUFNLENBQUN4RyxFQUFFLEVBQUV3RyxNQUFNLENBQUM7TUFDckNxRixTQUFTLENBQUNyRixNQUFNLEVBQUVrUSxZQUFZLENBQUM7TUFDL0JsTixPQUFPLENBQUNoRCxNQUFNLENBQUM7SUFDbkIsQ0FBQyxDQUFDO0VBQ04sQ0FBQyxDQUFDO0FBQ04sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEM0RDtBQUNNO0FBQ2lDO0FBQzFCO0FBQzFCO0FBQzZCO0FBQ3hCO0FBQ3JCO0FBQ2E7QUFDN0MsSUFBTWlSLG1CQUFtQixHQUFHLG1DQUFtQztBQUMvRCxJQUFNQyxhQUFhLEdBQUc5cUIsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDMnFCLGFBQWE7QUFDL0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQywyQkFBMkIsR0FBSUMsQ0FBQyxPQUFBbHdCLE1BQUEsQ0FBUXV2QixxRUFBb0IsT0FBQXZ2QixNQUFBLENBQUlrd0IsQ0FBQyxHQUFHLENBQUMsQ0FBRTtBQUM3RSxJQUFNQyxnQkFBZ0I7RUFBQSxJQUFBeHdCLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsV0FBT3FpQixJQUFJLEVBQUV6cUIsSUFBSSxFQUFFNEgsSUFBSSxFQUFFOGlCLE9BQU8sRUFBNEI7SUFBQSxJQUExQkMsZ0JBQWdCLEdBQUExckIsU0FBQSxDQUFBZCxNQUFBLFFBQUFjLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0lBQzVFLElBQU0yckIsRUFBRSxHQUFHZixpRUFBWSxDQUFDamlCLElBQUksRUFBRTtNQUMxQjVILElBQUk7TUFDSjBxQjtJQUNKLENBQUMsQ0FBQztJQUNGLElBQU12VCxJQUFJLEdBQUcyUyx3RUFBbUIsQ0FBQ2MsRUFBRSxFQUFFRCxnQkFBZ0IsQ0FBQztJQUN0RCxNQUFNdFYsNERBQU8sQ0FBQzZDLE1BQU0sQ0FBQyxNQUFNO01BQ3ZCLElBQUl1UyxJQUFJLENBQUN2RyxVQUFVLEVBQUU7UUFDakJ1RyxJQUFJLENBQUN2RyxVQUFVLENBQUNPLFlBQVksQ0FBQ3ROLElBQUksRUFBRXNULElBQUksQ0FBQztNQUM1QztJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU9HLEVBQUU7RUFDYixDQUFDO0VBQUEsZ0JBWktKLGdCQUFnQkEsQ0FBQXJoQixFQUFBLEVBQUFvVCxHQUFBLEVBQUE0RSxHQUFBLEVBQUEwSixHQUFBO0lBQUEsT0FBQTd3QixJQUFBLENBQUEyTyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQVlyQjtBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTTZyQixxQkFBcUI7RUFBQSxJQUFBcmxCLEtBQUEsR0FBQTJDLGlCQUFBLENBQUcsV0FBTzJpQixXQUFXLEVBQUU3VSxLQUFLLEVBQUU4VSxZQUFZLEVBQUs7SUFDdEU7SUFDQSxJQUFJLENBQUNBLFlBQVksRUFBRTtNQUNmLE9BQU85VSxLQUFLO0lBQ2hCO0lBQ0E7SUFDQSxJQUFNK1Usa0JBQWtCLFNBQVM1Viw0REFBTyxDQUFDeU8sT0FBTyxDQUFDLE1BQU07TUFBQSxJQUFBb0gscUJBQUE7TUFDbkQsSUFBTUMsT0FBTyxHQUFHSixXQUFXLENBQUNLLHFCQUFxQixDQUFDLENBQUMsQ0FBQ0MsR0FBRztNQUN2RCxJQUFNQyxpQkFBaUIsSUFBQUoscUJBQUEsR0FBR3JqQixRQUFRLENBQzdCMGpCLGFBQWEsQ0FBQ25CLG1CQUFtQixDQUFDLGNBQUFjLHFCQUFBLHVCQURiQSxxQkFBQSxDQUVwQkUscUJBQXFCLENBQUMsQ0FBQyxDQUFDSSxNQUFNO01BQ3BDLE9BQU9GLGlCQUFpQixHQUNsQjNsQixJQUFJLENBQUM4bEIsR0FBRyxDQUFDTixPQUFPLEdBQUdHLGlCQUFpQixDQUFDLEdBQ3JDcHNCLFNBQVM7SUFDbkIsQ0FBQyxDQUFDO0lBQ0Y7SUFDQSxPQUFPZ1gsS0FBSyxDQUFDcFQsTUFBTSxDQUFFNG9CLE1BQU0sSUFBS1Qsa0JBQWtCLEdBQUdBLGtCQUFrQixJQUFJUyxNQUFNLENBQUN4eEIsTUFBTSxHQUFHLEtBQUssQ0FBQztFQUNyRyxDQUFDO0VBQUEsZ0JBakJLNHdCLHFCQUFxQkEsQ0FBQWEsR0FBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUE7SUFBQSxPQUFBcG1CLEtBQUEsQ0FBQWtELEtBQUEsT0FBQTFKLFNBQUE7RUFBQTtBQUFBLEdBaUIxQjtBQUNELElBQU02c0IsaUJBQWlCLEdBQUlDLFFBQVEsSUFBSztFQUNwQztFQUNBO0VBQ0EsSUFBTTdTLGVBQWUsR0FBRztJQUNwQi9iLE9BQU8sRUFBRSxDQUFDVix1RUFBTyxDQUFDZixnQkFBZ0IsRUFBRWUsdUVBQU8sQ0FBQ2Qsc0JBQXNCLENBQUM7SUFDbkVtQixPQUFPLEVBQUUsQ0FBQ0wsdUVBQU8sQ0FBQ2YsZ0JBQWdCLEVBQUVlLHVFQUFPLENBQUNkLHNCQUFzQjtFQUN0RSxDQUFDO0VBQ0QsSUFBTXF3QixRQUFRO0lBQUEsSUFBQWxtQixLQUFBLEdBQUFzQyxpQkFBQSxDQUFHLFdBQU82akIsS0FBSyxFQUFLO01BQzlCLElBQU1yTyxLQUFLLEdBQUdxTyxLQUFLLENBQUN2cEIsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQ0MsR0FBRztRQUFBLElBQUFrRSxLQUFBLEdBQUF1QixpQkFBQSxDQUFDLFdBQU9xaUIsSUFBSSxFQUFLO1VBQ2hELElBQU16cUIsSUFBSSxHQUFHLFNBQVM7VUFDdEIsSUFBTXlXLElBQUksU0FBUytULGdCQUFnQixDQUFDQyxJQUFJLEVBQUV6cUIsSUFBSSxFQUFFLFFBQVEsRUFBRSxRQUFRLENBQUM7VUFDbkUsTUFBTStyQixRQUFRLENBQUMvckIsSUFBSSxFQUFFeVcsSUFBSSxFQUFFeUMsZUFBZSxDQUFDO1FBQy9DLENBQUM7UUFBQSxpQkFBQWdULEdBQUE7VUFBQSxPQUFBcmxCLEtBQUEsQ0FBQThCLEtBQUEsT0FBQTFKLFNBQUE7UUFBQTtNQUFBLElBQUM7TUFDRixNQUFNZ2QsT0FBTyxDQUFDNkUsR0FBRyxDQUFDbEQsS0FBSyxDQUFDO0lBQzVCLENBQUM7SUFBQSxnQkFQS29PLFFBQVFBLENBQUFHLEdBQUE7TUFBQSxPQUFBcm1CLEtBQUEsQ0FBQTZDLEtBQUEsT0FBQTFKLFNBQUE7SUFBQTtFQUFBLEdBT2I7RUFDRCxPQUFPa3JCLHNEQUFXLENBQUNpQyxTQUFTLENBQUNsQyx5Q0FBSyxDQUFDbUMsY0FBYyxFQUFFTCxRQUFRLEVBQUU7SUFDekRNLGFBQWEsRUFBRSxJQUFJO0lBQ25CQyxtQkFBbUIsRUFBRSxJQUFJO0lBQ3pCQyxJQUFJLEVBQUU7RUFDVixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBTUMsc0JBQXNCLEdBQUdBLENBQUNWLFFBQVEsRUFBRVcsYUFBYSxLQUFLO0VBQ3hELElBQU1DLFNBQVM7SUFBQSxJQUFBeGtCLEtBQUEsR0FBQUMsaUJBQUEsQ0FBRyxXQUFPNmpCLEtBQUssRUFBSztNQUMvQixJQUFNVyxzQkFBc0IsU0FBUzdDLHFFQUFvQixDQUFDa0MsS0FBSyxFQUFFN0IsbUJBQW1CLENBQUM7TUFDckYsS0FBS0osbUVBQWtCLENBQUM0QyxzQkFBc0IsQ0FBQ2pxQixHQUFHLENBQUMsQ0FBQ3pJLE1BQU0sRUFBRXFVLEtBQUssS0FBSyxDQUNsRStiLDJCQUEyQixDQUFDL2IsS0FBSyxDQUFDLEVBQ2xDclUsTUFBTSxDQUNULENBQUMsQ0FBQztNQUNILElBQU0wakIsS0FBSyxHQUFHcU8sS0FBSyxDQUFDdnBCLEtBQUssQ0FBQyxDQUFDLEVBQUV1cEIsS0FBSyxDQUFDOXRCLE1BQU0sQ0FBQyxDQUFDd0UsR0FBRztRQUFBLElBQUEwRyxLQUFBLEdBQUFqQixpQkFBQSxDQUFDLFdBQU9xaUIsSUFBSSxFQUFFRixDQUFDLEVBQUs7VUFDOUQsSUFBTVMsWUFBWSxHQUFHVCxDQUFDLEtBQUswQixLQUFLLENBQUM5dEIsTUFBTSxHQUFHLENBQUM7VUFDM0MsSUFBTTB1QixnQkFBZ0IsR0FBR3ZDLDJCQUEyQixDQUFDQyxDQUFDLENBQUMsR0FDbkQscUVBQXFFO1VBQ3pFLElBQU1JLGdCQUFnQixHQUFHO1lBQ3JCbUMsTUFBTSxFQUFFLElBQUk7WUFDWm5LLFNBQVMsRUFBRWtLO1VBQ2YsQ0FBQztVQUNEO1VBQ0E7VUFDQSxJQUFNM1QsZUFBZSxHQUFHO1lBQ3BCcGMsT0FBTyxRQUFRZ3VCLHFCQUFxQixDQUFDTCxJQUFJLEVBQUUsQ0FBQ2h1Qix1RUFBTyxDQUFDekIsUUFBUSxFQUFFeUIsdUVBQU8sQ0FBQ3BCLFVBQVUsQ0FBQyxFQUFFMnZCLFlBQVk7VUFDbkcsQ0FBQztVQUNELElBQU12VSxJQUFJLFNBQVMrVCxnQkFBZ0IsQ0FBQ0MsSUFBSSxXQUFBcHdCLE1BQUEsQ0FBV2t3QixDQUFDLEdBQUcsQ0FBQyxHQUFJLFFBQVEsRUFBRSxRQUFRLEVBQUVJLGdCQUFnQixDQUFDO1VBQ2pHLE9BQU9vQixRQUFRLFVBQUExeEIsTUFBQSxDQUFVa3dCLENBQUMsR0FBRyxDQUFDLEdBQUk5VCxJQUFJLEVBQUV5QyxlQUFlLENBQUM7UUFDNUQsQ0FBQztRQUFBLGlCQUFBNlQsR0FBQSxFQUFBQyxJQUFBO1VBQUEsT0FBQTNqQixLQUFBLENBQUFWLEtBQUEsT0FBQTFKLFNBQUE7UUFBQTtNQUFBLElBQUM7TUFDRixNQUFNZ2QsT0FBTyxDQUFDNkUsR0FBRyxDQUFDbEQsS0FBSyxDQUFDO0lBQzVCLENBQUM7SUFBQSxnQkF2QksrTyxTQUFTQSxDQUFBTSxHQUFBO01BQUEsT0FBQTlrQixLQUFBLENBQUFRLEtBQUEsT0FBQTFKLFNBQUE7SUFBQTtFQUFBLEdBdUJkO0VBQ0QsT0FBT2tyQixzREFBVyxDQUFDaUMsU0FBUyxDQUFDbEMseUNBQUssQ0FBQ2dELGdCQUFnQixDQUFDUixhQUFhLENBQUMsRUFBRUMsU0FBUyxFQUFFO0lBQzNFTCxhQUFhLEVBQUUsSUFBSTtJQUNuQkMsbUJBQW1CLEVBQUUsSUFBSTtJQUN6QkMsSUFBSSxFQUFFO0VBQ1YsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNELElBQU1XLG9DQUFvQyxHQUFJNWUsS0FBSyxJQUFLO0VBQ3BELElBQUlBLEtBQUssS0FBSyxDQUFDLEVBQUU7SUFDYixPQUFPO01BQ0gxUixNQUFNLEVBQUUsQ0FBQ0osdUVBQU8sQ0FBQ2xCLG9CQUFvQjtJQUN6QyxDQUFDO0VBQ0wsQ0FBQyxNQUNJLElBQUlnVCxLQUFLLEtBQUssQ0FBQyxFQUFFO0lBQ2xCLE9BQU87TUFDSDFSLE1BQU0sRUFBRSxDQUNKSix1RUFBTyxDQUFDbEIsb0JBQW9CLEVBQzVCa0IsdUVBQU8sQ0FBQ1IscUJBQXFCO0lBRXJDLENBQUM7RUFDTDtFQUNBLE9BQU9pRCxTQUFTO0FBQ3BCLENBQUM7QUFDRCxJQUFNa3VCLDJCQUEyQixHQUFHQSxDQUFDckIsUUFBUSxFQUFFc0IsaUJBQWlCLEtBQUs7RUFDakUsSUFBTVYsU0FBUztJQUFBLElBQUFXLEtBQUEsR0FBQWxsQixpQkFBQSxDQUFHLFdBQU82akIsS0FBSyxFQUFLO01BQy9CLElBQU1yTyxLQUFLLEdBQUdxTyxLQUFLLENBQUN0cEIsR0FBRztRQUFBLElBQUE0cUIsS0FBQSxHQUFBbmxCLGlCQUFBLENBQUMsV0FBT3FpQixJQUFJLEVBQUVGLENBQUMsRUFBSztVQUN2QztVQUNBO1VBQ0EsSUFBTXZxQixJQUFJLEdBQUdxdEIsaUJBQWlCLEtBQUssUUFBUSxJQUFJOUMsQ0FBQyxLQUFLLENBQUMsR0FDaEQsZUFBZSxHQUNmOEMsaUJBQWlCLEtBQUssUUFBUSxZQUFBaHpCLE1BQUEsQ0FDakJrd0IsQ0FBQyxHQUFHLENBQUMsYUFBQWx3QixNQUFBLENBQ0xrd0IsQ0FBQyxDQUFFO1VBQ3RCLElBQU0zaUIsSUFBSSxHQUFHeWxCLGlCQUFpQixLQUFLLFFBQVEsSUFBSTlDLENBQUMsS0FBSyxDQUFDLEdBQ2hELGVBQWUsR0FDZixRQUFRO1VBQ2QsSUFBTTlULElBQUksU0FBUytULGdCQUFnQixDQUFDQyxJQUFJLEVBQUV6cUIsSUFBSSxFQUFFNEgsSUFBSSxFQUFFLFFBQVEsQ0FBQztVQUMvRCxPQUFPbWtCLFFBQVEsQ0FBQy9yQixJQUFJLEVBQUV5VyxJQUFJLEVBQUUwVyxvQ0FBb0MsQ0FBQzVDLENBQUMsQ0FBQyxDQUFDO1FBQ3hFLENBQUM7UUFBQSxpQkFBQWlELElBQUEsRUFBQUMsSUFBQTtVQUFBLE9BQUFGLEtBQUEsQ0FBQTVrQixLQUFBLE9BQUExSixTQUFBO1FBQUE7TUFBQSxJQUFDO01BQ0YsTUFBTWdkLE9BQU8sQ0FBQzZFLEdBQUcsQ0FBQ2xELEtBQUssQ0FBQztJQUM1QixDQUFDO0lBQUEsZ0JBaEJLK08sU0FBU0EsQ0FBQWUsSUFBQTtNQUFBLE9BQUFKLEtBQUEsQ0FBQTNrQixLQUFBLE9BQUExSixTQUFBO0lBQUE7RUFBQSxHQWdCZDtFQUNELE9BQU9rckIsc0RBQVcsQ0FBQ2lDLFNBQVMsQ0FBQ2xDLHlDQUFLLENBQUN5RCxzQkFBc0IsRUFBRWhCLFNBQVMsRUFBRTtJQUNsRUwsYUFBYSxFQUFFLElBQUk7SUFDbkJDLG1CQUFtQixFQUFFLElBQUk7SUFDekJDLElBQUksRUFBRTtFQUNWLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTW9CLFlBQVksR0FBR0EsQ0FBQzdCLFFBQVEsRUFBRVcsYUFBYSxLQUFLO0VBQzlDLElBQU1XLGlCQUFpQixHQUFHblAsbUZBQW9CLENBQUMsQ0FBQztFQUNoRCxJQUFJLENBQUMsUUFBUSxFQUFFLFFBQVEsQ0FBQyxDQUFDNWYsUUFBUSxDQUFDK3VCLGlCQUFpQixDQUFDLEVBQUU7SUFDbEQsT0FBT0QsMkJBQTJCLENBQUNyQixRQUFRLEVBQUVzQixpQkFBaUIsQ0FBQztFQUNuRTtFQUNBLElBQUloRCxhQUFhLEVBQUU7SUFDZixPQUFPb0Msc0JBQXNCLENBQUNWLFFBQVEsRUFBRVcsYUFBYSxDQUFDO0VBQzFEO0VBQ0EsT0FBT1osaUJBQWlCLENBQUNDLFFBQVEsQ0FBQyxDQUFDMVEsSUFBSSxDQUFDLE1BQU1vUixzQkFBc0IsQ0FBQ1YsUUFBUSxFQUFFVyxhQUFhLENBQUMsQ0FBQztBQUNsRyxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNaEcsSUFBSTtFQUFBLElBQUFtSCxLQUFBLEdBQUF6bEIsaUJBQUEsQ0FBRyxXQUFPMGxCLFVBQVUsRUFBSztJQUMvQixJQUFJLENBQUNuRSx3RUFBa0IsQ0FBQ29FLGtCQUFrQixFQUFFO01BQ3hDLE9BQU85UixPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQzVCO0lBQ0EsTUFBTXlSLFlBQVksQ0FBQ0UsVUFBVSxFQUFFLEtBQUssQ0FBQztJQUNyQyxNQUFNN0Qsa0VBQVUsQ0FBQyxDQUFDO0VBQ3RCLENBQUM7RUFBQSxnQkFOS3ZELElBQUlBLENBQUFzSCxJQUFBO0lBQUEsT0FBQUgsS0FBQSxDQUFBbGxCLEtBQUEsT0FBQTFKLFNBQUE7RUFBQTtBQUFBLEdBTVQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcExrRTtBQUNYO0FBQ2tCO0FBQzFCO0FBQ2dCO0FBQ25CO0FBQzdDLElBQU1pdkIsWUFBWSxHQUFHLG1DQUFtQztBQUN4RCxJQUFNQyxTQUFTLEdBQUc7RUFDZEQsWUFBWTtFQUNaRSxpQkFBaUIsRUFBRSxZQUFZO0VBQy9CQyxrQkFBa0IsRUFBRSxHQUFHO0VBQ3ZCQyxxQkFBcUIsRUFBRSxHQUFHO0VBQzFCQyxnQkFBZ0IsRUFBRSxDQUFDO0VBQ25CQyxxQkFBcUIsRUFBRTtJQUNuQixvQkFBb0IsRUFBRTtNQUNsQkMsWUFBWSxFQUFFLEdBQUc7TUFDakJDLFNBQVMsRUFBRTtJQUNmLENBQUM7SUFDRCxnQkFBZ0IsRUFBRTtNQUNkRCxZQUFZLEVBQUUsR0FBRztNQUNqQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELFNBQVMsRUFBRTtNQUNQRCxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELGFBQWEsRUFBRTtNQUNYRCxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELGFBQWEsRUFBRTtNQUNYRCxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELDhEQUE4RCxFQUFFO01BQzVERCxZQUFZLEVBQUUsRUFBRTtNQUNoQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELFVBQVUsRUFBRTtNQUNSRCxZQUFZLEVBQUUsR0FBRztNQUNqQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELG9CQUFvQixFQUFFO01BQ2xCRCxZQUFZLEVBQUUsR0FBRztNQUNqQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNEO0lBQ0EsaURBQWlELEVBQUU7TUFDL0NELFlBQVksRUFBRSxHQUFHO01BQ2pCQyxTQUFTLEVBQUU7SUFDZjtFQUNKLENBQUM7RUFDREMsVUFBVSxFQUFFO0FBQ2hCLENBQUM7QUFDRDtBQUNBLElBQU1DLFlBQVksR0FBQWx5QixhQUFBLENBQUFBLGFBQUEsS0FDWHl4QixTQUFTO0VBQ1pLLHFCQUFxQixFQUFBOXhCLGFBQUEsQ0FBQUEsYUFBQSxLQUNkeXhCLFNBQVMsQ0FBQ0sscUJBQXFCO0lBQ2xDLG9CQUFvQixFQUFFO01BQ2xCQyxZQUFZLEVBQUUsR0FBRztNQUNqQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELFVBQVUsRUFBRTtNQUNSRCxZQUFZLEVBQUUsR0FBRztNQUNqQkMsU0FBUyxFQUFFO0lBQ2Y7RUFBQztBQUNKLEVBQ0o7QUFDRCxJQUFNRyxVQUFVLEdBQUk1QyxLQUFLLElBQUs7RUFDMUIsSUFBTXhWLElBQUksR0FBR29ULGlFQUFZLENBQUMsUUFBUSxDQUFDO0VBQ25DLElBQU1pRixVQUFVLEdBQUc3QyxLQUFLLENBQUN2cEIsS0FBSyxDQUFDLENBQUMsQ0FBQztFQUNqQyxPQUFPMlMsNERBQU8sQ0FDVDZDLE1BQU0sQ0FBQyxNQUFNO0lBQUEsSUFBQTZXLFlBQUE7SUFDZCxLQUFBQSxZQUFBLEdBQUlELFVBQVUsQ0FBQyxDQUFDLENBQUMsY0FBQUMsWUFBQSxlQUFiQSxZQUFBLENBQWU3SyxVQUFVLEVBQUU7TUFDM0I0SyxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUM1SyxVQUFVLENBQUNPLFlBQVksQ0FBQ2hPLElBQUksRUFBRXFZLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztJQUM5RDtFQUNKLENBQUMsQ0FBQyxDQUNHelQsSUFBSSxDQUFDLE1BQU0sS0FBS2tPLDRFQUFpQixDQUFDOVMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDO0FBQ3ZELENBQUM7QUFDRCxJQUFNdVksUUFBUSxHQUFHQSxDQUFBLEtBQU07RUFDbkIsUUFBUWYsbUZBQW9CLENBQUMsQ0FBQztJQUMxQixLQUFLLFNBQVM7SUFDZCxLQUFLLE1BQU07TUFDUCxPQUFPRSxTQUFTO0lBQ3BCO01BQ0ksT0FBT1MsWUFBWTtFQUMzQjtBQUNKLENBQUM7QUFDTSxJQUFNM0UsVUFBVSxHQUFHQSxDQUFBLEtBQU07RUFDNUIsSUFBSU4sd0VBQWtCLENBQUNzRixtQkFBbUIsRUFBRTtJQUN4QyxPQUFPOUUsc0RBQVcsQ0FBQ2lDLFNBQVMsQ0FBQzRDLFFBQVEsQ0FBQyxDQUFDLEVBQUVILFVBQVUsRUFBRTtNQUNqRHZDLGFBQWEsRUFBRSxJQUFJO01BQ25CQyxtQkFBbUIsRUFBRSxJQUFJO01BQ3pCQyxJQUFJLEVBQUU7SUFDVixDQUFDLENBQUM7RUFDTjtFQUNBLE9BQU92USxPQUFPLENBQUNFLE9BQU8sQ0FBQyxLQUFLLENBQUM7QUFDakMsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2xHNEQ7QUFDRztBQUNoRSxJQUFNK1IsWUFBWSxHQUFHLG1DQUFtQztBQUN4RCxJQUFNZ0IsdUJBQXVCLE9BQUE3MEIsTUFBQSxDQUFPdXZCLHFFQUFvQixDQUFFO0FBQzFELElBQU11RixpQkFBaUIsR0FBRyxDQUN0QixVQUFVLEVBQ1YsYUFBYSxFQUNiLE9BQU8sRUFDUCxPQUFPLEVBQ1AsY0FBYyxFQUNkLFNBQVMsRUFDVCxPQUFPLEVBQ1AsUUFBUSxFQUNSLFVBQVUsRUFDVixPQUFPLENBQ1Y7QUFDRCxJQUFNQyxvQkFBb0IsR0FBR0QsaUJBQWlCLENBQUM3d0IsUUFBUSxDQUFDaUIsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDNE0sT0FBTyxDQUFDO0FBQzVGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU0raUIsa0JBQWtCLEdBQUcsR0FBRztBQUM5QixJQUFNQyxXQUFXLEdBQUcvdkIsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDNHZCLFdBQVc7QUFDM0QsSUFBTUMsU0FBUyxHQUFHLENBQUMsR0FBQWprQixxQkFBQSxHQUFDL0wsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDOHZCLGNBQWMsY0FBQWxrQixxQkFBQSxlQUExQ0EscUJBQUEsQ0FBNENta0IsTUFBTSxDQUFDdHhCLE1BQU07QUFDN0UsSUFBTXV4QixRQUFRLEdBQUdud0IsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDaXdCLGNBQWM7QUFDM0QsSUFBTXRGLGFBQWEsR0FBRzlxQixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMycUIsYUFBYTtBQUMvRCxJQUFNdUYsc0JBQXNCLEdBQUdyd0IsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDa3dCLHNCQUFzQjtBQUNqRixJQUFNQyw4QkFBOEIsR0FBRyxHQUFHO0FBQzFDLElBQU1DLDJCQUEyQixHQUFHVixvQkFBb0IsR0FBRyxHQUFHLEdBQUcsR0FBRztBQUNwRSxJQUFNaEIsaUJBQWlCLEdBQUcsa0RBQWtEO0FBQzVFLElBQU0yQiwwQkFBMEIsR0FBRyxDQUFDLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FDdkRwdEIsR0FBRyxDQUFFcXRCLElBQUkseUNBQUEzMUIsTUFBQSxDQUF5QzIxQixJQUFJLFFBQUksQ0FBQyxDQUMzRC9vQixJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ2QsSUFBTWdwQiwyQkFBMkIsR0FBRyw4Q0FBOEM7QUFDbEYsSUFBTUMsc0JBQXNCLEdBQUcsQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFLFVBQVUsRUFBRSxXQUFXLENBQUMsQ0FDM0V2dEIsR0FBRyxDQUFFcXRCLElBQUkseUNBQUEzMUIsTUFBQSxDQUF5QzIxQixJQUFJLHlFQUFBMzFCLE1BQUEsQ0FBa0UyMUIsSUFBSSxRQUFJLENBQUMsQ0FDakkvb0IsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNkLElBQU1rcEIsZUFBZSwrR0FBMkc7QUFDaEksSUFBTTlELGNBQWMsR0FBRztFQUNuQjZCLFlBQVk7RUFDWkUsaUJBQWlCO0VBQ2pCQyxrQkFBa0IsRUFBRWlCLFdBQVcsR0FBRyxHQUFHLEdBQUcsR0FBRztFQUMzQ2hCLHFCQUFxQixFQUFFLEdBQUc7RUFDMUJFLHFCQUFxQixFQUFFO0lBQ25CO0lBQ0EsQ0FBQzJCLGVBQWUsR0FBRztNQUNmMUIsWUFBWSxFQUFFLEdBQUc7TUFDakJDLFNBQVMsRUFBRVUsb0JBQW9CLEdBQUcsQ0FBQyxHQUFHO0lBQzFDLENBQUM7SUFDRCxDQUFDRix1QkFBdUIsR0FBRztNQUN2QlQsWUFBWSxFQUFFLEdBQUc7TUFDakJDLFNBQVMsRUFBRTtJQUNmLENBQUM7SUFDRCxDQUFDd0Isc0JBQXNCLEdBQUc7TUFDdEJ6QixZQUFZLEVBQUUsRUFBRTtNQUNoQkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELENBQUNxQiwwQkFBMEIsR0FBRztNQUMxQnRCLFlBQVksRUFBRSxFQUFFO01BQ2hCQyxTQUFTLEVBQUU7SUFDZixDQUFDO0lBQ0QsQ0FBQ3VCLDJCQUEyQixHQUFHO01BQzNCeEIsWUFBWSxFQUFFLENBQUM7TUFDZkMsU0FBUyxFQUFFO0lBQ2YsQ0FBQztJQUNELENBQUMsc0NBQXNDLEdBQUc7TUFDdENELFlBQVksRUFBRSxDQUFDO01BQ2ZDLFNBQVMsRUFBRTtJQUNmO0VBQ0o7QUFDSixDQUFDO0FBQ0QsSUFBTTBCLHdCQUF3QixHQUFJMUQsYUFBYSxJQUFLO0VBQ2hELElBQU0yRCxJQUFJLEdBQUcsSUFBSTtFQUNqQjtBQUNKO0FBQ0E7QUFDQTtFQUNJLElBQUloRyxhQUFhLElBQUssQ0FBQ2tGLFNBQVMsSUFBSSxDQUFDRyxRQUFTLElBQUloRCxhQUFhLEVBQUU7SUFDN0QsT0FBTzJELElBQUksR0FBR2hCLGtCQUFrQjtFQUNwQztFQUNBLElBQUlPLHNCQUFzQixJQUFLLENBQUNMLFNBQVMsSUFBSUcsUUFBUyxFQUFFO0lBQ3BELE9BQU9XLElBQUksR0FBRyxHQUFHO0VBQ3JCO0VBQ0EsT0FBT0EsSUFBSTtBQUNmLENBQUM7QUFDRCxJQUFNbkQsZ0JBQWdCLEdBQUlSLGFBQWEsSUFBSztFQUN4QyxPQUFPO0lBQ0h3QixZQUFZO0lBQ1pFLGlCQUFpQjtJQUNqQkMsa0JBQWtCLEVBQUUrQix3QkFBd0IsQ0FBQzFELGFBQWEsQ0FBQztJQUMzRDRCLHFCQUFxQixFQUFFLEdBQUc7SUFDMUJFLHFCQUFxQixFQUFFO01BQ25CLENBQUNVLHVCQUF1QixHQUFHO1FBQ3ZCVCxZQUFZLEVBQUUsR0FBRztRQUNqQkMsU0FBUyxFQUFFO01BQ2YsQ0FBQztNQUNELENBQUN1QiwyQkFBMkIsR0FBRztRQUMzQnhCLFlBQVksRUFBRSxDQUFDO1FBQ2ZDLFNBQVMsRUFBRTtNQUNmO0lBQ0osQ0FBQztJQUNEO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7SUFDUTVyQixNQUFNLEVBQUVBLENBQUN3dEIsU0FBUyxFQUFFQyxVQUFVLEtBQUs7TUFDL0IsSUFBSSxDQUFDQSxVQUFVLEVBQUU7UUFDYixPQUFPLElBQUk7TUFDZjtNQUNBLElBQU1DLGtCQUFrQixHQUFHL3pCLHVFQUFPLENBQUN6QixRQUFRLENBQUNkLE1BQU07TUFDbEQsSUFBTXUyQixrQkFBa0IsR0FBR0gsU0FBUyxDQUFDakYsR0FBRyxHQUFHa0YsVUFBVSxDQUFDbEYsR0FBRyxHQUFHbUYsa0JBQWtCO01BQzlFLE9BQU9DLGtCQUFrQixJQUFJWiw4QkFBOEI7SUFDL0Q7RUFDSixDQUFDO0FBQ0wsQ0FBQztBQUNELElBQU1hLCtCQUErQixHQUFHLEdBQUc7QUFDM0MsSUFBTUMsdUJBQXVCLEdBQUcsOEhBQThIO0FBQzlKLElBQU1DLHFCQUFxQixNQUFBdjJCLE1BQUEsQ0FBTTgxQixlQUFlLHNFQUFpRTtBQUNqSCxJQUFNVSwyQkFBMkIsR0FBRztFQUNoQztFQUNBLENBQUNELHFCQUFxQixHQUFHO0lBQ3JCbkMsWUFBWSxFQUFFLEdBQUc7SUFDakJDLFNBQVMsRUFBRTtFQUNmLENBQUM7RUFDRCxDQUFDUSx1QkFBdUIsR0FBRztJQUN2QlQsWUFBWSxFQUFFcUIsMkJBQTJCO0lBQ3pDcEIsU0FBUyxFQUFFb0I7RUFDZixDQUFDO0VBQ0QsSUFBQXoxQixNQUFBLENBQUk2MUIsc0JBQXNCLE9BQUE3MUIsTUFBQSxDQUFJMDFCLDBCQUEwQixJQUFLO0lBQ3pEdEIsWUFBWSxFQUFFLEVBQUU7SUFDaEJDLFNBQVMsRUFBRSxHQUFHO0lBQ2Q7SUFDQW9DLFlBQVksRUFBRTtFQUNsQixDQUFDO0VBQ0QsQ0FBQ2IsMkJBQTJCLEdBQUc7SUFDM0J4QixZQUFZLEVBQUUsRUFBRTtJQUNoQkMsU0FBUyxFQUFFLEdBQUc7SUFDZDtJQUNBb0MsWUFBWSxFQUFFO0VBQ2xCO0FBQ0osQ0FBQztBQUNELElBQU1uRCxzQkFBc0IsR0FBRztFQUMzQk8sWUFBWTtFQUNaRSxpQkFBaUIsRUFBRXVDLHVCQUF1QjtFQUMxQ3RDLGtCQUFrQixFQUFFcUMsK0JBQStCO0VBQ25EcEMscUJBQXFCLEVBQUUsR0FBRztFQUMxQkUscUJBQXFCLEVBQUVxQywyQkFBMkI7RUFDbEQ7QUFDSjtBQUNBO0FBQ0E7QUFDQTtFQUNJL3RCLE1BQU0sRUFBRUEsQ0FBQ3d0QixTQUFTLEVBQUVDLFVBQVUsS0FBSztJQUMvQixJQUFJLENBQUNBLFVBQVUsRUFBRTtNQUNiLE9BQU8sSUFBSTtJQUNmO0lBQ0EsSUFBTUUsa0JBQWtCLEdBQUdILFNBQVMsQ0FBQ2pGLEdBQUcsR0FBR2tGLFVBQVUsQ0FBQ2xGLEdBQUc7SUFDekQsT0FBT29GLGtCQUFrQixJQUFJWCwyQkFBMkI7RUFDNUQ7QUFDSixDQUFDO0FBQ00sSUFBTTVGLEtBQUssR0FBRztFQUNqQm1DLGNBQWM7RUFDZGEsZ0JBQWdCO0VBQ2hCUztBQUNKLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZLMEQ7QUFDTDtBQUN0RCxNQUFNc0QsV0FBVyxDQUFDO0VBQUFsM0IsWUFBQTtJQUFBSSxlQUFBLGdCQUNOOGhCLE9BQU8sQ0FBQ0UsT0FBTyxDQUFDLElBQUksQ0FBQztFQUFBO0VBQzdCO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJaVEsU0FBU0EsQ0FBQ2xDLEtBQUssRUFBRWdILE1BQU0sRUFBRUMsT0FBTyxFQUFFO0lBQzlCLElBQU1DLGlCQUFpQixHQUFHQSxDQUFBLEtBQU1MLHVEQUFTLENBQUM3RyxLQUFLLEVBQUVpSCxPQUFPLENBQUMsQ0FDcEQ5VixJQUFJLENBQUVnVyxVQUFVLElBQUtILE1BQU0sQ0FBQ0csVUFBVSxDQUFDLENBQUMsQ0FDeENoVyxJQUFJLENBQUMsTUFBTTtNQUNaLE9BQU8sSUFBSTtJQUNmLENBQUMsQ0FBQyxDQUNHMEUsS0FBSyxDQUFFdVIsRUFBRSxJQUFLO01BQ2YsSUFBSUEsRUFBRSxZQUFZTixvREFBVSxFQUFFO1FBQzFCLE9BQU8sS0FBSztNQUNoQjtNQUNBLE1BQU1NLEVBQUU7SUFDWixDQUFDLENBQUM7SUFDRixJQUFJLENBQUMxVSxLQUFLLEdBQUcsSUFBSSxDQUFDQSxLQUFLLENBQUN2QixJQUFJLENBQUMrVixpQkFBaUIsQ0FBQyxDQUFDclIsS0FBSyxDQUFFclksQ0FBQyxJQUFLO01BQ3pEO01BQ0FvUixvRUFBVyxDQUFDcFIsQ0FBQyxFQUFFLGNBQWMsQ0FBQztNQUM5QixPQUFPLEtBQUs7SUFDaEIsQ0FBQyxDQUFDO0lBQ0YsT0FBTyxJQUFJLENBQUNrVixLQUFLO0VBQ3JCO0FBQ0o7QUFDQSxJQUFNdU4sV0FBVyxHQUFHLElBQUk4RyxXQUFXLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDOUJyQztBQUNxQztBQUNEO0FBQ1k7QUFDTDtBQUMzQyxJQUFNTyxLQUFLLEdBQUdBLENBQUNDLFFBQVEsRUFBRUMsT0FBTyxLQUFLLENBQ2pDLEdBQUcsQ0FBQ0EsT0FBTyxhQUFQQSxPQUFPLGNBQVBBLE9BQU8sR0FBSTdwQixRQUFRLEVBQUU4cEIsZ0JBQWdCLENBQUNGLFFBQVEsQ0FBQyxDQUN0RDtBQUNEO0FBQ0EsSUFBTUcsZUFBZSxHQUFHLElBQUs7QUFDN0IsSUFBTUMsY0FBYyxHQUFHO0VBQ25CdkYsYUFBYSxFQUFFLElBQUk7RUFDbkJDLG1CQUFtQixFQUFFLEtBQUs7RUFDMUJDLElBQUksRUFBRTtBQUNWLENBQUM7QUFDRCxJQUFNc0YsUUFBUSxHQUFJM2EsSUFBSSxJQUFLQSxJQUFJLFlBQVk0YSxpQkFBaUI7QUFDNUQsSUFBTUMsY0FBYyxHQUFJQyxNQUFNLElBQUs7RUFDL0IsSUFBSTtJQUFBLElBQUFDLHFCQUFBO0lBQ0EsT0FBTyxFQUFBQSxxQkFBQSxHQUFBRCxNQUFNLENBQUNFLGFBQWEsY0FBQUQscUJBQUEsdUJBQXBCQSxxQkFBQSxDQUFzQnJxQixRQUFRLENBQUN1cUIsVUFBVSxNQUFLLFVBQVU7RUFDbkUsQ0FBQyxDQUNELE9BQU9sdkIsR0FBRyxFQUFFO0lBQ1IsT0FBTyxJQUFJO0VBQ2Y7QUFDSixDQUFDO0FBQ0QsSUFBTW12QixTQUFTLEdBQUluSSxLQUFLLElBQUtBLEtBQUssQ0FBQ2dFLFlBQVksSUFBSSxVQUFVO0FBQzdELElBQU1vRSxPQUFPLEdBQUlDLE9BQU8sSUFBS0EsT0FBTyxZQUFZQyxnQkFBZ0I7QUFDaEUsSUFBTUMsY0FBYyxHQUFHbEIscURBQU8sQ0FBRXJILEtBQUssSUFBSztFQUN0QyxJQUFNd0ksU0FBUyxHQUFHbEIsS0FBSyxDQUFDLEtBQUssRUFBRXRILEtBQUssQ0FBQy9qQixJQUFJLENBQUMsQ0FDckNyRCxNQUFNLENBQUN3dkIsT0FBTyxDQUFDLENBQ2Z4dkIsTUFBTSxDQUFFNnZCLEdBQUcsSUFBSyxDQUFDQSxHQUFHLENBQUNDLFFBQVEsSUFBSUQsR0FBRyxDQUFDRSxPQUFPLEtBQUssTUFBTSxDQUFDO0VBQzdELElBQU1DLFdBQVcsR0FBR0osU0FBUyxDQUFDL3ZCLEdBQUcsQ0FBRWd3QixHQUFHLElBQUssSUFBSTFXLE9BQU8sQ0FBRUUsT0FBTyxJQUFLO0lBQ2hFd1csR0FBRyxDQUFDM3FCLGdCQUFnQixDQUFDLE1BQU0sRUFBRW1VLE9BQU8sQ0FBQztFQUN6QyxDQUFDLENBQUMsQ0FBQztFQUNILE9BQU9GLE9BQU8sQ0FBQzZFLEdBQUcsQ0FBQ2dTLFdBQVcsQ0FBQyxDQUFDelgsSUFBSSxDQUFDLE1BQU1ZLE9BQU8sQ0FBQ0UsT0FBTyxDQUFDLENBQUMsQ0FBQztBQUNqRSxDQUFDLEVBQUVrVyxTQUFTLENBQUM7QUFDYixJQUFNVSx1QkFBdUIsR0FBR0EsQ0FBQ2QsTUFBTSxFQUFFZSxRQUFRLEtBQUs7RUFDbER6ekIsTUFBTSxDQUFDeUksZ0JBQWdCLENBQUMsU0FBUyxFQUFHK2MsS0FBSyxJQUFLO0lBQzFDLElBQUlBLEtBQUssQ0FBQ2tPLE1BQU0sS0FBS2hCLE1BQU0sQ0FBQ0UsYUFBYSxFQUNyQztJQUNKLElBQUk7TUFDQSxJQUFNdndCLE9BQU8sR0FBR0csSUFBSSxDQUFDUyxLQUFLLENBQUN1aUIsS0FBSyxDQUFDNU8sSUFBSSxDQUFDO01BQ3RDLElBQUl2VSxPQUFPLENBQUNnRyxJQUFJLEtBQUssWUFBWSxJQUFJaEYsTUFBTSxDQUFDaEIsT0FBTyxDQUFDK0MsS0FBSyxDQUFDLEdBQUcsQ0FBQyxFQUFFO1FBQzVEcXVCLFFBQVEsQ0FBQyxDQUFDO01BQ2Q7SUFDSixDQUFDLENBQ0QsT0FBTzFCLEVBQUUsRUFBRTtNQUNQN3RCLG1EQUFHLENBQUMsWUFBWSxFQUFFLHFDQUFxQyxFQUFFNnRCLEVBQUUsQ0FBQztJQUNoRTtFQUNKLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxJQUFNNEIsb0JBQW9CLEdBQUczQixxREFBTztFQUFBLElBQUF2M0IsSUFBQSxHQUFBb08saUJBQUEsQ0FBQyxXQUFPOGhCLEtBQUssRUFBSztJQUNsRCxJQUFNd0ksU0FBUyxHQUFHbEIsS0FBSyxDQUFDLHNCQUFzQixFQUFFdEgsS0FBSyxDQUFDL2pCLElBQUksQ0FBQyxDQUFDckQsTUFBTSxDQUFFdEYsV0FBVyxJQUFLO01BQ2hGLElBQU0yMUIsT0FBTyxHQUFHcjVCLEtBQUssQ0FBQ3M1QixJQUFJLENBQUM1MUIsV0FBVyxDQUFDNjFCLFFBQVEsQ0FBQyxDQUFDdndCLE1BQU0sQ0FBQ2d2QixRQUFRLENBQUM7TUFDakUsT0FBTyxFQUFFcUIsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJbkIsY0FBYyxDQUFDbUIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDdEQsQ0FBQyxDQUFDO0lBQ0YsSUFBSVQsU0FBUyxDQUFDdjBCLE1BQU0sS0FBSyxDQUFDLElBQUksRUFBRSxrQkFBa0IsSUFBSW9CLE1BQU0sQ0FBQyxFQUFFO01BQzNELE9BQU8wYyxPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0lBQzVCO0lBQ0EsSUFBTW1YLFNBQVMsR0FBR1osU0FBUyxDQUFDL3ZCLEdBQUcsQ0FBRW5GLFdBQVcsSUFBSyxJQUFJeWUsT0FBTyxDQUFFRSxPQUFPLElBQUs7TUFDdEU7TUFDQSxJQUFJb1gsZ0JBQWdCLENBQUMsQ0FBQ0MsT0FBTyxFQUFFQyxRQUFRLEtBQUs7UUFBQSxJQUFBQyxTQUFBLEVBQUFDLFVBQUE7UUFDeEMsSUFBSSxHQUFBRCxTQUFBLEdBQUNGLE9BQU8sQ0FBQyxDQUFDLENBQUMsY0FBQUUsU0FBQSxlQUFWQSxTQUFBLENBQVlFLFVBQVUsQ0FBQyxDQUFDLENBQUMsS0FDMUIsQ0FBQzlCLFFBQVEsRUFBQTZCLFVBQUEsR0FBQ0gsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFBRyxVQUFBLHVCQUFWQSxVQUFBLENBQVlDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO1VBQ3RDO1FBQ0o7UUFDQSxJQUFNM0IsTUFBTSxHQUFHdUIsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDSSxVQUFVLENBQUMsQ0FBQyxDQUFDO1FBQ3ZDO1FBQ0E7UUFDQWIsdUJBQXVCLENBQUNkLE1BQU0sRUFBRSxNQUFNO1VBQ2xDd0IsUUFBUSxDQUFDSSxVQUFVLENBQUMsQ0FBQztVQUNyQjFYLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDO01BQ04sQ0FBQyxDQUFDLENBQUN3RCxPQUFPLENBQUNuaUIsV0FBVyxFQUFFO1FBQ3BCczJCLFNBQVMsRUFBRTtNQUNmLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQyxDQUFDO0lBQ0gsTUFBTTdYLE9BQU8sQ0FBQzZFLEdBQUcsQ0FBQ3dTLFNBQVMsQ0FBQztFQUNoQyxDQUFDO0VBQUEsaUJBQUFucUIsRUFBQTtJQUFBLE9BQUFuUCxJQUFBLENBQUEyTyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxLQUFFb3pCLFNBQVMsQ0FBQztBQUNiLElBQU0wQixtQkFBbUIsR0FBR0EsQ0FBQ0MsSUFBSSxFQUFFQyxhQUFhLEtBQUs7RUFDakQsSUFBTXpwQixRQUFRLEdBQUcsRUFBRTtFQUNuQixJQUFNMHBCLFVBQVUsR0FBRyxFQUFFO0VBQ3JCRixJQUFJLENBQUMzWixPQUFPLENBQUVrWSxPQUFPLElBQUs7SUFDdEIsSUFBSTBCLGFBQWEsQ0FBQzFCLE9BQU8sRUFBRS9uQixRQUFRLENBQUNBLFFBQVEsQ0FBQ3JNLE1BQU0sR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFO01BQ3ZEcU0sUUFBUSxDQUFDaVEsSUFBSSxDQUFDOFgsT0FBTyxDQUFDO0lBQzFCLENBQUMsTUFDSTtNQUNEMkIsVUFBVSxDQUFDelosSUFBSSxDQUFDOFgsT0FBTyxDQUFDO0lBQzVCO0VBQ0osQ0FBQyxDQUFDO0VBQ0YsT0FBTyxDQUFDL25CLFFBQVEsRUFBRTBwQixVQUFVLENBQUM7QUFDakMsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLHFDQUFxQyxHQUFHQSxDQUFDN0QsU0FBUyxFQUFFOEQsUUFBUSxFQUFFQyxJQUFJLEVBQUVDLGVBQWUsS0FBSztFQUMxRixJQUFNQyx1QkFBdUIsR0FBR2pFLFNBQVMsQ0FBQ2pGLEdBQUc7RUFDN0MsSUFBSWlKLGVBQWUsSUFBSUQsSUFBSSxDQUFDM0YsU0FBUyxFQUFFO0lBQ25DLElBQUkyRixJQUFJLENBQUN2RCxZQUFZLElBQUlSLFNBQVMsQ0FBQ2lDLE9BQU8sQ0FBQ2lDLE9BQU8sQ0FBQ0gsSUFBSSxDQUFDdkQsWUFBWSxDQUFDLEVBQUU7TUFDbkUsT0FBTyxJQUFJO0lBQ2Y7SUFDQSxPQUFPc0QsUUFBUSxDQUFDL0ksR0FBRyxHQUFHa0osdUJBQXVCLElBQUlGLElBQUksQ0FBQzNGLFNBQVM7RUFDbkU7RUFDQSxJQUFJLENBQUM0RixlQUFlLElBQUlELElBQUksQ0FBQzVGLFlBQVksRUFBRTtJQUN2QyxPQUFPOEYsdUJBQXVCLEdBQUdILFFBQVEsQ0FBQzVJLE1BQU0sSUFBSTZJLElBQUksQ0FBQzVGLFlBQVk7RUFDekU7RUFDQTtFQUNBLE9BQU8sSUFBSTtBQUNmLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNZ0csbUJBQW1CLEdBQUdBLENBQUNuRSxTQUFTLEVBQUU4RCxRQUFRLEtBQUs5RCxTQUFTLENBQUNpQyxPQUFPLEtBQUs2QixRQUFRLENBQUM3QixPQUFPLElBQ3ZGNkIsUUFBUSxDQUFDN0IsT0FBTyxDQUFDNVEsUUFBUSxDQUFDMk8sU0FBUyxDQUFDaUMsT0FBTyxDQUFDO0FBQ2hEO0FBQ0EsSUFBTW1DLGFBQWEsR0FBR0EsQ0FBQ0wsSUFBSSxFQUFFL0QsU0FBUyxFQUFFOEQsUUFBUSxLQUFLO0VBQ2pELElBQUlLLG1CQUFtQixDQUFDbkUsU0FBUyxFQUFFOEQsUUFBUSxDQUFDLEVBQUU7SUFDMUMsT0FBTyxJQUFJO0VBQ2Y7RUFDQSxJQUFNRSxlQUFlLEdBQUdGLFFBQVEsQ0FBQzVJLE1BQU0sR0FBRzhFLFNBQVMsQ0FBQzlFLE1BQU0sSUFBSTRJLFFBQVEsQ0FBQy9JLEdBQUcsSUFBSWlGLFNBQVMsQ0FBQzlFLE1BQU07RUFDOUYsSUFBTW1KLGVBQWUsR0FBR1AsUUFBUSxDQUFDL0ksR0FBRyxHQUFHaUYsU0FBUyxDQUFDakYsR0FBRyxJQUFJK0ksUUFBUSxDQUFDNUksTUFBTSxJQUFJOEUsU0FBUyxDQUFDakYsR0FBRztFQUN4RjtFQUNBLElBQU11SixnQkFBZ0IsR0FBSUQsZUFBZSxJQUFJTCxlQUFlLElBQ3ZELENBQUNLLGVBQWUsSUFBSSxDQUFDTCxlQUFnQjtFQUMxQyxJQUFNOUgsSUFBSSxHQUFHLENBQUNvSSxnQkFBZ0IsSUFDMUJULHFDQUFxQyxDQUFDN0QsU0FBUyxFQUFFOEQsUUFBUSxFQUFFQyxJQUFJLEVBQUVDLGVBQWUsQ0FBQztFQUNyRixJQUFJLENBQUM5SCxJQUFJLEVBQUU7SUFDUCxJQUFJb0ksZ0JBQWdCLEVBQUU7TUFDbEJ0RSxTQUFTLENBQUN1RSxJQUFJLENBQUNDLFFBQVEsQ0FBQ3JhLElBQUksQ0FBQztRQUN6QjhYLE9BQU8sRUFBRTZCLFFBQVEsQ0FBQzdCO01BQ3RCLENBQUMsQ0FBQztJQUNOLENBQUMsTUFDSTtNQUNEO01BQ0EsSUFBTXdDLFFBQVEsR0FBR1QsZUFBZSxHQUMxQkQsSUFBSSxDQUFDM0YsU0FBUyxHQUNkMkYsSUFBSSxDQUFDNUYsWUFBWTtNQUN2QixJQUFNdUcsTUFBTSxHQUFHVixlQUFlLEdBQ3hCRixRQUFRLENBQUMvSSxHQUFHLEdBQUdpRixTQUFTLENBQUNqRixHQUFHLEdBQzVCaUYsU0FBUyxDQUFDakYsR0FBRyxHQUFHK0ksUUFBUSxDQUFDNUksTUFBTTtNQUNyQzhFLFNBQVMsQ0FBQ3VFLElBQUksQ0FBQ0ksUUFBUSxDQUFDeGEsSUFBSSxDQUFDO1FBQ3pCc2EsUUFBUTtRQUNSQyxNQUFNO1FBQ056QyxPQUFPLEVBQUU2QixRQUFRLENBQUM3QjtNQUN0QixDQUFDLENBQUM7SUFDTjtFQUNKO0VBQ0EsT0FBTy9GLElBQUk7QUFDZixDQUFDO0FBQ0Q7QUFDQSxJQUFNMEksY0FBYyxHQUFHQSxDQUFDYixJQUFJLEVBQUUvRCxTQUFTLEVBQUU2RSxTQUFTLEtBQUtBLFNBQVMsQ0FDM0R4eUIsR0FBRyxDQUFFeXhCLFFBQVEsSUFBS00sYUFBYSxDQUFDTCxJQUFJLEVBQUUvRCxTQUFTLEVBQUU4RCxRQUFRLENBQUMsQ0FBQyxDQUMzRDNyQixLQUFLLENBQUNvRyxPQUFPLENBQUM7QUFDbkIsSUFBTXVtQixZQUFZLEdBQUdBLENBQUNDLFlBQVksRUFBRW5MLEtBQUssRUFBRW9MLHFCQUFxQixLQUFLO0VBQ2pFLElBQUl4RyxVQUFVLEdBQUd1RyxZQUFZLENBQUN2RyxVQUFVO0VBQ3hDO0VBQ0EsSUFBSSxDQUFDdGtCLFFBQVEsRUFBRTBwQixVQUFVLENBQUMsR0FBR0gsbUJBQW1CLENBQUNqRixVQUFVLEVBQUd3QixTQUFTLElBQUssQ0FBQ3BHLEtBQUssQ0FBQ3FMLDBCQUEwQixJQUN6R2pGLFNBQVMsQ0FBQ2pGLEdBQUcsR0FBR2dLLFlBQVksQ0FBQ0csT0FBTyxJQUNoQ3RMLEtBQUssQ0FBQ3FMLDBCQUEwQixDQUFDO0VBQ3pDRCxxQkFBcUIsQ0FBQ0MsMEJBQTBCLEdBQUdyQixVQUFVO0VBQzdEcEYsVUFBVSxHQUFHdGtCLFFBQVE7RUFDckI7RUFDQSxDQUFDQSxRQUFRLEVBQUUwcEIsVUFBVSxDQUFDLEdBQUdILG1CQUFtQixDQUFDakYsVUFBVSxFQUFHd0IsU0FBUyxJQUFLO0lBQ3BFLElBQU1tRixzQkFBc0IsR0FBR25GLFNBQVMsQ0FBQ2pGLEdBQUcsSUFBSW5CLEtBQUssQ0FBQ21FLGtCQUFrQjtJQUN4RSxJQUFNcUgseUJBQXlCLEdBQUdwRixTQUFTLENBQUNqRixHQUFHLEdBQUduQixLQUFLLENBQUNvRSxxQkFBcUIsSUFDekUrRyxZQUFZLENBQUNNLFVBQVU7SUFDM0IsT0FBT0Ysc0JBQXNCLElBQUlDLHlCQUF5QjtFQUM5RCxDQUFDLENBQUM7RUFDRkoscUJBQXFCLENBQUNNLGFBQWEsR0FBRzFCLFVBQVU7RUFDaERwRixVQUFVLEdBQUd0a0IsUUFBUTtFQUNyQjtFQUNBLElBQU07SUFBRStqQjtFQUFpQixDQUFDLEdBQUdyRSxLQUFLO0VBQ2xDLElBQUlxRSxnQkFBZ0IsRUFBRTtJQUNsQixDQUFDL2pCLFFBQVEsRUFBRTBwQixVQUFVLENBQUMsR0FBR0gsbUJBQW1CLENBQUNqRixVQUFVLEVBQUd3QixTQUFTLElBQUssQ0FBQyxDQUFDK0UsWUFBWSxDQUFDUSxXQUFXLElBQzlGdkYsU0FBUyxDQUFDakYsR0FBRyxHQUNUZ0ssWUFBWSxDQUFDUSxXQUFXLENBQUNySyxNQUFNLEdBQUcrQyxnQkFBZ0IsQ0FBQztJQUMzRCtHLHFCQUFxQixDQUFDTyxXQUFXLEdBQUczQixVQUFVO0lBQzlDcEYsVUFBVSxHQUFHdGtCLFFBQVE7RUFDekI7RUFDQTtFQUNBLElBQUkwZixLQUFLLENBQUNzRSxxQkFBcUIsRUFBRTtJQUM3QixJQUFNc0gsa0JBQWtCLEdBQUcsRUFBRTtJQUFDLElBQUFDLEtBQUEsWUFBQUEsQ0FBQXRFLFFBQUEsRUFBQTRDLElBQUEsRUFDOEM7TUFDeEUsQ0FBQzdwQixRQUFRLEVBQUUwcEIsVUFBVSxDQUFDLEdBQUdILG1CQUFtQixDQUFDakYsVUFBVSxFQUFHd0IsU0FBUztRQUFBLElBQUEwRixxQkFBQSxFQUFBQyxzQkFBQTtRQUFBLE9BQUtmLGNBQWMsQ0FBQ2IsSUFBSSxFQUFFL0QsU0FBUyxHQUFBMEYscUJBQUEsSUFBQUMsc0JBQUEsR0FBRVosWUFBWSxDQUFDRixTQUFTLGNBQUFjLHNCQUFBLHVCQUF0QkEsc0JBQUEsQ0FBeUJ4RSxRQUFRLENBQUMsY0FBQXVFLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxDQUFDO01BQUEsRUFBQztNQUNsSlYscUJBQXFCLENBQUM3RCxRQUFRLENBQUMsR0FBR3lDLFVBQVU7TUFDNUM0QixrQkFBa0IsQ0FBQ3JiLElBQUksQ0FBQyxHQUFHeVosVUFBVSxDQUFDO0lBQzFDLENBQUM7SUFKRCxLQUFLLElBQU0sQ0FBQ3pDLFFBQVEsRUFBRTRDLElBQUksQ0FBQyxJQUFJbnZCLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDK2tCLEtBQUssQ0FBQ3NFLHFCQUFxQixDQUFDO01BQUF1SCxLQUFBLENBQUF0RSxRQUFBLEVBQUE0QyxJQUFBO0lBQUE7SUFLMUV2RixVQUFVLEdBQUdBLFVBQVUsQ0FBQ2hzQixNQUFNLENBQUV3dEIsU0FBUyxJQUFLLENBQUN3RixrQkFBa0IsQ0FBQ3gzQixRQUFRLENBQUNneUIsU0FBUyxDQUFDLENBQUM7RUFDMUY7RUFDQSxJQUFJcEcsS0FBSyxDQUFDcG5CLE1BQU0sRUFBRTtJQUNkLENBQUMwSCxRQUFRLEVBQUUwcEIsVUFBVSxDQUFDLEdBQUdILG1CQUFtQixDQUFDakYsVUFBVSxFQUFFNUUsS0FBSyxDQUFDcG5CLE1BQU0sQ0FBQztJQUN0RXd5QixxQkFBcUIsQ0FBQzVYLE1BQU0sR0FBR3dXLFVBQVU7SUFDekNwRixVQUFVLEdBQUd0a0IsUUFBUTtFQUN6QjtFQUNBLE9BQU9za0IsVUFBVTtBQUNyQixDQUFDO0FBQ0QsTUFBTWtDLFVBQVUsU0FBU3ZZLEtBQUssQ0FBQztFQUMzQjFlLFdBQVdBLENBQUNtd0IsS0FBSyxFQUFFO0lBQ2YsS0FBSyxDQUFDLENBQUM7SUFDUCxJQUFJLENBQUNscUIsSUFBSSxHQUFHLFlBQVk7SUFDeEIsSUFBSSxDQUFDNEIsT0FBTyxpREFBQXZILE1BQUEsQ0FBaUQ2dkIsS0FBSyxDQUFDZ0UsWUFBWSxDQUFFO0VBQ3JGO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNZ0ksUUFBUSxHQUFHQSxDQUFDaE0sS0FBSyxFQUFFaUgsT0FBTyxLQUFLbFYsT0FBTyxDQUFDQyxJQUFJLENBQUMsQ0FDOUMsSUFBSUQsT0FBTyxDQUFFRSxPQUFPLElBQUs1YyxNQUFNLENBQUM2YyxVQUFVLENBQUMsTUFBTUQsT0FBTyxDQUFDLFNBQVMsQ0FBQyxFQUFFeVYsZUFBZSxDQUFDLENBQUMsRUFDdEYzVixPQUFPLENBQUM2RSxHQUFHLENBQUMsQ0FDUnFRLE9BQU8sQ0FBQzdFLGFBQWEsR0FBR21HLGNBQWMsQ0FBQ3ZJLEtBQUssQ0FBQyxHQUFHak8sT0FBTyxDQUFDRSxPQUFPLENBQUMsQ0FBQyxFQUNqRWdWLE9BQU8sQ0FBQzVFLG1CQUFtQixHQUNyQjJHLG9CQUFvQixDQUFDaEosS0FBSyxDQUFDLEdBQzNCak8sT0FBTyxDQUFDRSxPQUFPLENBQUMsQ0FBQyxDQUMxQixDQUFDLENBQ0wsQ0FBQyxDQUFDZCxJQUFJLENBQUUxVyxLQUFLLElBQUs7RUFDZixJQUFJQSxLQUFLLEtBQUssU0FBUyxFQUFFO0lBQ3JCbEIsbURBQUcsQ0FBQyxZQUFZLEVBQUUseUJBQXlCLENBQUM7RUFDaEQ7QUFDSixDQUFDLENBQUM7QUFDRixJQUFNMHlCLGFBQWEsR0FBR0EsQ0FBQ2pNLEtBQUssRUFBRW9MLHFCQUFxQixLQUFLO0VBQ3BELElBQUl4RyxVQUFVLEdBQUcwQyxLQUFLLENBQUN0SCxLQUFLLENBQUNrRSxpQkFBaUIsRUFBRWxFLEtBQUssQ0FBQy9qQixJQUFJLENBQUM7RUFDM0QsSUFBSStqQixLQUFLLENBQUN5RSxVQUFVLEVBQUU7SUFDbEJHLFVBQVUsQ0FBQ3NILE9BQU8sQ0FBQyxDQUFDO0VBQ3hCO0VBQ0EsSUFBSWxNLEtBQUssQ0FBQ21NLE9BQU8sRUFBRTtJQUNmLElBQUlDLElBQUksR0FBRyxJQUFJO0lBQ2YsSUFBTSxDQUFDOXJCLFFBQVEsRUFBRTBwQixVQUFVLENBQUMsR0FBR0gsbUJBQW1CLENBQUNqRixVQUFVLEVBQUd3QixTQUFTLElBQUs7TUFDMUUsSUFBSUEsU0FBUyxLQUFLcEcsS0FBSyxDQUFDbU0sT0FBTyxFQUFFO1FBQzdCQyxJQUFJLEdBQUcsS0FBSztNQUNoQjtNQUNBLE9BQU8sQ0FBQ0EsSUFBSTtJQUNoQixDQUFDLENBQUM7SUFDRmhCLHFCQUFxQixDQUFDZSxPQUFPLEdBQUduQyxVQUFVO0lBQzFDcEYsVUFBVSxHQUFHdGtCLFFBQVE7RUFDekI7RUFDQSxJQUFJMGYsS0FBSyxDQUFDcU0sTUFBTSxFQUFFO0lBQ2QsSUFBSUMsSUFBSSxHQUFHLElBQUk7SUFDZixJQUFNLENBQUNoc0IsU0FBUSxFQUFFMHBCLFdBQVUsQ0FBQyxHQUFHSCxtQkFBbUIsQ0FBQ2pGLFVBQVUsRUFBR3dCLFNBQVMsSUFBSztNQUMxRSxJQUFJQSxTQUFTLEtBQUtwRyxLQUFLLENBQUNxTSxNQUFNLEVBQUU7UUFDNUJDLElBQUksR0FBRyxLQUFLO01BQ2hCO01BQ0EsT0FBT0EsSUFBSTtJQUNmLENBQUMsQ0FBQztJQUNGbEIscUJBQXFCLENBQUNpQixNQUFNLEdBQUdyQyxXQUFVO0lBQ3pDcEYsVUFBVSxHQUFHdGtCLFNBQVE7RUFDekI7RUFDQSxPQUFPc2tCLFVBQVU7QUFDckIsQ0FBQztBQUNELElBQU0ySCxhQUFhLEdBQUlsRSxPQUFPLElBQUtydEIsTUFBTSxDQUFDd3hCLE1BQU0sQ0FBQztFQUM3Q3JMLEdBQUcsRUFBRWtILE9BQU8sQ0FBQ29FLFNBQVM7RUFDdEJuTCxNQUFNLEVBQUUrRyxPQUFPLENBQUNvRSxTQUFTLEdBQUdwRSxPQUFPLENBQUNxRSxZQUFZO0VBQ2hEckUsT0FBTztFQUNQc0MsSUFBSSxFQUFFO0lBQ0ZJLFFBQVEsRUFBRSxFQUFFO0lBQ1pILFFBQVEsRUFBRTtFQUNkO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsSUFBTStCLGVBQWUsR0FBR0EsQ0FBQzNNLEtBQUssRUFBRTRFLFVBQVUsS0FBSztFQUFBLElBQUE1RCxxQkFBQTtFQUMzQyxJQUFNMkssV0FBVyxHQUFHM0wsS0FBSyxDQUFDcUUsZ0JBQWdCLElBQUFyRCxxQkFBQSxHQUNuQ3JqQixRQUFRLENBQUMwakIsYUFBYSxDQUFDLGtCQUFrQixDQUFDLGNBQUFMLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUloc0IsU0FBUyxHQUN4REEsU0FBUztFQUNmLElBQU1pMkIsU0FBUyxHQUFHakwsS0FBSyxDQUFDc0UscUJBQXFCLEdBQ3ZDdHBCLE1BQU0sQ0FBQ3dSLElBQUksQ0FBQ3dULEtBQUssQ0FBQ3NFLHFCQUFxQixDQUFDLENBQUM3ckIsR0FBRyxDQUFFOHVCLFFBQVEsSUFBSyxDQUFDQSxRQUFRLEVBQUVELEtBQUssQ0FBQ0MsUUFBUSxFQUFFdkgsS0FBSyxDQUFDL2pCLElBQUksQ0FBQyxDQUFDLENBQUMsR0FDbkcsRUFBRTtFQUNSLE9BQU9rUCw0REFBTyxDQUFDeU8sT0FBTyxDQUFDLE1BQU07SUFDekIsSUFBSWdULHVCQUF1QixHQUFHLENBQUM7SUFDL0IsSUFBSW5CLFVBQVUsR0FBRyxDQUFDO0lBQ2xCLElBQUl6TCxLQUFLLENBQUMvakIsSUFBSSxZQUFZNHdCLE9BQU8sRUFBRTtNQUMvQixJQUFNQyxXQUFXLEdBQUc5TSxLQUFLLENBQUMvakIsSUFBSSxDQUFDaWxCLHFCQUFxQixDQUFDLENBQUM7TUFDdEQ7TUFDQTBMLHVCQUF1QixHQUFHRSxXQUFXLENBQUMzTCxHQUFHLEdBQUc5ckIsTUFBTSxDQUFDMDNCLE9BQU87TUFDMUR0QixVQUFVLEdBQUdxQixXQUFXLENBQUM5OEIsTUFBTTtJQUNuQztJQUNBLElBQU1nOUIsa0JBQWtCLEdBQUdwSSxVQUFVLENBQUNuc0IsR0FBRyxDQUFDOHpCLGFBQWEsQ0FBQztJQUN4RCxJQUFNVSxtQkFBbUIsR0FBR2pOLEtBQUssQ0FBQ3FFLGdCQUFnQixJQUFJc0gsV0FBVyxHQUMzRFksYUFBYSxDQUFDWixXQUFXLENBQUMsR0FDMUIzMkIsU0FBUztJQUNmLElBQU1rNEIsaUJBQWlCLEdBQUdqQyxTQUFTLENBQUMzaUIsTUFBTSxDQUFDLENBQUM2SixNQUFNLEVBQUE1VyxLQUFBLEtBQW1DO01BQUEsSUFBakMsQ0FBQ2dzQixRQUFRLEVBQUU0RixnQkFBZ0IsQ0FBQyxHQUFBNXhCLEtBQUE7TUFDNUU0VyxNQUFNLENBQUNvVixRQUFRLENBQUMsR0FBRzRGLGdCQUFnQixDQUFDMTBCLEdBQUcsQ0FBQzh6QixhQUFhLENBQUM7TUFDdEQsT0FBT3BhLE1BQU07SUFDakIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0lBQ04sT0FBTztNQUNIbVosT0FBTyxFQUFFc0IsdUJBQXVCO01BQ2hDbkIsVUFBVTtNQUNWN0csVUFBVSxFQUFFb0ksa0JBQWtCO01BQzlCckIsV0FBVyxFQUFFc0IsbUJBQW1CO01BQ2hDaEMsU0FBUyxFQUFFaUM7SUFDZixDQUFDO0VBQ0wsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNEO0FBQ0E7QUFDQSxJQUFNckcsU0FBUztFQUFBLElBQUFqckIsS0FBQSxHQUFBc0MsaUJBQUEsQ0FBRyxXQUFPOGhCLEtBQUssRUFBRWlILE9BQU8sRUFBc0I7SUFBQSxJQUFBbUcsc0JBQUEsRUFBQUMsaUJBQUE7SUFBQSxJQUFwQnJELFVBQVUsR0FBQWoxQixTQUFBLENBQUFkLE1BQUEsUUFBQWMsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBRyxDQUFDLENBQUM7SUFDcERreUIsT0FBTyxHQUFBejBCLGFBQUEsQ0FBQUEsYUFBQSxLQUFRbTFCLGNBQWMsR0FBS1YsT0FBTyxDQUFFO0lBQzNDakgsS0FBSyxDQUFDL2pCLElBQUksR0FBRytqQixLQUFLLENBQUNnRSxZQUFZLElBQUFvSixzQkFBQSxHQUN4Qnp2QixRQUFRLENBQUMwakIsYUFBYSxDQUFDckIsS0FBSyxDQUFDZ0UsWUFBWSxDQUFDLGNBQUFvSixzQkFBQSxjQUFBQSxzQkFBQSxHQUFJenZCLFFBQVEsR0FDdkRBLFFBQVE7SUFDZHRJLE1BQU0sQ0FBQ29MLFdBQVcsQ0FBQ3NRLElBQUksQ0FBQyx3Q0FBd0MsQ0FBQztJQUNqRSxNQUFNaWIsUUFBUSxDQUFDaE0sS0FBSyxFQUFFaUgsT0FBTyxDQUFDO0lBQzlCLElBQU1yQyxVQUFVLEdBQUdxSCxhQUFhLENBQUNqTSxLQUFLLEVBQUVnSyxVQUFVLENBQUM7SUFDbkQsSUFBTW1CLFlBQVksU0FBU3dCLGVBQWUsQ0FBQzNNLEtBQUssRUFBRTRFLFVBQVUsQ0FBQztJQUM3RCxJQUFNMEksT0FBTyxHQUFHcEMsWUFBWSxDQUFDQyxZQUFZLEVBQUVuTCxLQUFLLEVBQUVnSyxVQUFVLENBQUM7SUFDN0QsSUFBTXVELFdBQVcsR0FBRyxDQUFDLENBQUNoZSxvREFBVSxDQUFDLENBQUMsQ0FBQ2llLE9BQU87SUFDMUMsSUFBSUQsV0FBVyxFQUFFO01BQ2IsSUFBTWpMLElBQUksR0FBRzJFLE9BQU8sQ0FBQzNFLElBQUk7TUFDekIsS0FBSyxzT0FBbUMsQ0FBQ25SLElBQUksQ0FBQ3hVLEtBQUEsSUFBYztRQUFBLElBQWI7VUFBRTZmO1FBQUssQ0FBQyxHQUFBN2YsS0FBQTtRQUNuRDZmLElBQUksQ0FBQ3dOLFVBQVUsRUFBRXNELE9BQU8sRUFBRXROLEtBQUssRUFBRXNDLElBQUksQ0FBQztNQUMxQyxDQUFDLENBQUM7SUFDTjtJQUNBanRCLE1BQU0sQ0FBQ29MLFdBQVcsQ0FBQ3NRLElBQUksQ0FBQyxzQ0FBc0MsQ0FBQztJQUMvRCxJQUFNNkksT0FBTyxHQUFHdmtCLE1BQU0sQ0FBQ29MLFdBQVcsQ0FBQ21aLE9BQU8sQ0FBQyxrQ0FBa0MsRUFBRSx3Q0FBd0MsRUFBRSxzQ0FBc0MsQ0FBQztJQUNoS3JnQixtREFBRyxDQUFDLFlBQVksc0JBQUFwSixNQUFBLENBQXNCc0wsSUFBSSxDQUFDZ3lCLEtBQUssRUFBQUosaUJBQUEsR0FBQ3pULE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFL2QsUUFBUSxjQUFBd3hCLGlCQUFBLGNBQUFBLGlCQUFBLEdBQUksQ0FBQyxDQUFDLGNBQUFsOUIsTUFBQSxDQUFXODJCLE9BQU8sQ0FBQzNFLElBQUksYUFBVTtNQUNyR3RDLEtBQUs7TUFDTGlIO0lBQ0osQ0FBQyxDQUFDO0lBQ0Y7SUFDQSxJQUFJLENBQUNxRyxPQUFPLENBQUNyNUIsTUFBTSxFQUFFO01BQ2pCLE1BQU0sSUFBSTZ5QixVQUFVLENBQUM5RyxLQUFLLENBQUM7SUFDL0I7SUFDQSxPQUFPc04sT0FBTyxDQUFDNzBCLEdBQUcsQ0FBRTJ0QixTQUFTLElBQUtBLFNBQVMsQ0FBQ2lDLE9BQU8sQ0FBQztFQUN4RCxDQUFDO0VBQUEsZ0JBNUJLeEIsU0FBU0EsQ0FBQXhVLEdBQUEsRUFBQTRFLEdBQUE7SUFBQSxPQUFBcmIsS0FBQSxDQUFBNkMsS0FBQSxPQUFBMUosU0FBQTtFQUFBO0FBQUEsR0E0QmQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25XNEM7QUFDYztBQUNkO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLElBQU00NEIsbUJBQW1CLEdBQUcsR0FBRztBQUMvQjtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxtQkFBbUIsR0FBRyxHQUFHO0FBQy9CO0FBQ0E7QUFDQTtBQUNBLElBQU1DLHdCQUF3QixHQUFHLEdBQUc7QUFDcEM7QUFDQTtBQUNBO0FBQ0EsSUFBTUMsa0JBQWtCLEdBQUcsRUFBRTtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1oTyxrQkFBa0IsR0FBSWlPLGFBQWEsSUFBSztFQUMxQztBQUNKO0FBQ0E7QUFDQTtFQUNJLElBQU01TSxHQUFHLEdBQUc5ckIsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDMnFCLGFBQWEsTUFBQWh3QixNQUFBLENBQzVDMjlCLGtCQUFrQixHQUFHLENBQUMsVUFDekIsQ0FBQztFQUNQLElBQU1FLGFBQWEsR0FBR0QsYUFBYSxDQUFDemxCLE1BQU0sQ0FBQyxDQUFDMmxCLEdBQUcsRUFBQW4rQixJQUFBO0lBQUEsSUFBRSxDQUFDZ0csSUFBSSxFQUFFOUYsTUFBTSxDQUFDLEdBQUFGLElBQUE7SUFBQSxVQUFBSyxNQUFBLENBQVE4OUIsR0FBRyxRQUFBOTlCLE1BQUEsQ0FBSzJGLElBQUkscUJBQUEzRixNQUFBLENBQWtCSCxNQUFNLGFBQUFHLE1BQUEsQ0FBVTJGLElBQUksb0NBQUEzRixNQUFBLENBQWlDZ3hCLEdBQUc7RUFBQSxDQUFLLEVBQUUsRUFBRSxDQUFDO0VBQ3ZLLElBQU04TSxHQUFHLG1DQUFBOTlCLE1BQUEsQ0FDZ0JWLHFFQUFXLENBQUNtRCxPQUFPLHlCQUFBekMsTUFBQSxDQUNsQzY5QixhQUFhLHNCQUV0QjtFQUNELElBQU1sVyxLQUFLLEdBQUduYSxRQUFRLENBQUM2YSxhQUFhLENBQUMsT0FBTyxDQUFDO0VBQzdDVixLQUFLLENBQUNpQixXQUFXLENBQUNwYixRQUFRLENBQUN1d0IsY0FBYyxDQUFDRCxHQUFHLENBQUMsQ0FBQztFQUMvQyxPQUFPOWlCLDREQUFPLENBQUM2QyxNQUFNLENBQUMsTUFBTTtJQUN4QnJRLFFBQVEsQ0FBQ3d3QixJQUFJLENBQUNwVixXQUFXLENBQUNqQixLQUFLLENBQUM7RUFDcEMsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTStILG9CQUFvQjtFQUFBLElBQUF0a0IsS0FBQSxHQUFBMkMsaUJBQUEsQ0FBRyxXQUFPb3ZCLE9BQU8sRUFBRXBOLG1CQUFtQixFQUFLO0lBQ2pFO0lBQ0E7SUFDQSxJQUFNa08sZ0JBQWdCLEdBQUcsQ0FDckIsR0FBR3p3QixRQUFRLENBQUM4cEIsZ0JBQWdCLENBQUMscUNBQXFDLENBQUMsQ0FDdEU7SUFDRCxJQUFNO01BQUU0RyxPQUFPO01BQUVDLFlBQVk7TUFBRUM7SUFBK0IsQ0FBQyxTQUFTcGpCLDREQUFPLENBQUN5TyxPQUFPLENBQUMsTUFBTTtNQUFBLElBQUFvSCxxQkFBQSxFQUFBb00sc0JBQUE7TUFDMUYsSUFBTWlCLE9BQU8sR0FBR0QsZ0JBQWdCLENBQUMzMUIsR0FBRyxDQUFFNHZCLE9BQU8sS0FBTTtRQUMvQ21HLElBQUksRUFBRSxRQUFRO1FBQ2RyTixHQUFHLEVBQUVrSCxPQUFPLENBQUNuSCxxQkFBcUIsQ0FBQyxDQUFDLENBQUNDLEdBQUc7UUFDeENrSDtNQUNKLENBQUMsQ0FBQyxDQUFDO01BQ0gsSUFBTWlHLFlBQVksR0FBR2hCLE9BQU8sQ0FBQzcwQixHQUFHLENBQUU0dkIsT0FBTyxLQUFNO1FBQzNDbUcsSUFBSSxFQUFFLGFBQWE7UUFDbkJyTixHQUFHLEVBQUVrSCxPQUFPLENBQUNuSCxxQkFBcUIsQ0FBQyxDQUFDLENBQUNDLEdBQUc7UUFDeENrSDtNQUNKLENBQUMsQ0FBQyxDQUFDO01BQ0gsSUFBTWtHLDhCQUE4QixJQUFBdk4scUJBQUEsSUFBQW9NLHNCQUFBLEdBQUd6dkIsUUFBUSxDQUMxQzBqQixhQUFhLENBQUNuQixtQkFBbUIsQ0FBQyxjQUFBa04sc0JBQUEsdUJBREFBLHNCQUFBLENBRWpDbE0scUJBQXFCLENBQUMsQ0FBQyxDQUFDSSxNQUFNLGNBQUFOLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQztNQUN6QyxPQUFPO1FBQUVxTixPQUFPO1FBQUVDLFlBQVk7UUFBRUM7TUFBK0IsQ0FBQztJQUNwRSxDQUFDLENBQUM7SUFDRjtNQUNBO01BQ0EsQ0FBQyxHQUFHRixPQUFPLEVBQUUsR0FBR0MsWUFBWTtNQUN4QjtNQUFBLENBQ0NHLElBQUksQ0FBQyxDQUFDQyxLQUFLLEVBQUVDLE1BQU0sS0FBS0QsS0FBSyxDQUFDdk4sR0FBRyxHQUFHd04sTUFBTSxDQUFDeE4sR0FBRztNQUMvQztNQUFBLENBQ0Mxb0IsR0FBRyxDQUFDLENBQUNtMkIsT0FBTyxFQUFFdnFCLEtBQUssRUFBRXdxQixLQUFLLEtBQUs7UUFDaEM7UUFDQTtRQUNBLElBQUlELE9BQU8sQ0FBQ0osSUFBSSxLQUFLLFFBQVEsRUFBRTtVQUMzQixPQUFPeDVCLFNBQVM7UUFDcEI7UUFDQTtRQUNBO1FBQ0EsSUFBTTg1QixJQUFJLEdBQUdELEtBQUssQ0FBQ3hxQixLQUFLLEdBQUcsQ0FBQyxDQUFDO1FBQzdCO1FBQ0E7UUFDQTtRQUNBLElBQUl5cUIsSUFBSSxLQUFLOTVCLFNBQVMsRUFBRTtVQUNwQixPQUFRdTVCLDhCQUE4QixHQUNsQ0ssT0FBTyxDQUFDek4sR0FBRyxHQUNYME0sd0JBQXdCO1FBQ2hDO1FBQ0E7UUFDQSxJQUFNa0IsTUFBTSxHQUFHRCxJQUFJLENBQUNOLElBQUksS0FBSyxhQUFhLEdBQ3BDYixtQkFBbUIsR0FDbkJDLG1CQUFtQjtRQUN6QjtRQUNBLE9BQU9ueUIsSUFBSSxDQUFDMkwsS0FBSyxDQUFDMG5CLElBQUksQ0FBQzNOLEdBQUcsR0FBR3lOLE9BQU8sQ0FBQ3pOLEdBQUcsR0FBRzROLE1BQU0sQ0FBQztNQUN0RCxDQUFDO01BQ0c7TUFDQTtNQUFBLENBQ0NuMkIsTUFBTSxDQUFFNUksTUFBTSxJQUFLLENBQUMwOUIsMkRBQVcsQ0FBQzE5QixNQUFNLENBQUM7SUFBQztFQUNqRCxDQUFDO0VBQUEsZ0JBdkRLNnZCLG9CQUFvQkEsQ0FBQTVnQixFQUFBLEVBQUFvVCxHQUFBO0lBQUEsT0FBQTlXLEtBQUEsQ0FBQWtELEtBQUEsT0FBQTFKLFNBQUE7RUFBQTtBQUFBLEdBdUR6Qjs7Ozs7Ozs7Ozs7Ozs7O0FDekdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFNaTZCLFFBQVEsR0FBRyxTQUFBQSxDQUFVQyxHQUFHLEVBQUVoakIsSUFBSSxFQUFFaWpCLFNBQVMsRUFBRUMsS0FBSyxFQUFFQyxTQUFTLEVBQUU7RUFDdEUsSUFBSUEsU0FBUyxFQUFFO0lBQ1g7SUFDQUgsR0FBRyxHQUFHRyxTQUFTLENBQUNILEdBQUcsRUFBRWhqQixJQUFJLEVBQUVpakIsU0FBUyxDQUFDO0VBQ3pDLENBQUMsTUFDSTtJQUNELElBQUk3MkIsUUFBUSxHQUFHLEVBQUU7SUFDakI7SUFDQSxJQUFJO01BQ0EsSUFBTWczQixLQUFLLEdBQUd4M0IsSUFBSSxDQUFDUyxLQUFLLENBQUNnM0IsWUFBWSxDQUFDQyxNQUFNLElBQUksSUFBSSxDQUFDLENBQUM5MkIsR0FBRyxDQUFDTSxNQUFNLENBQUM7TUFDakUsSUFBTXkyQixJQUFJLEdBQUczM0IsSUFBSSxDQUFDUyxLQUFLLENBQUNnM0IsWUFBWSxDQUFDRyxLQUFLLElBQUksSUFBSSxDQUFDO01BQ25ELElBQU1DLE1BQU0sR0FBRzczQixJQUFJLENBQUNTLEtBQUssQ0FBQ2czQixZQUFZLENBQUNLLE9BQU8sSUFBSSxJQUFJLENBQUM7TUFDdkR0M0IsUUFBUSxHQUFHLENBQUMsR0FBR2czQixLQUFLLEVBQUUsR0FBR0csSUFBSSxFQUFFLEdBQUdFLE1BQU0sQ0FBQztJQUM3QyxDQUFDLENBQ0QsT0FBT2x5QixDQUFDLEVBQUUsQ0FBRTtJQUNaO0lBQ0EsSUFBSTB4QixTQUFTLElBQUlqakIsSUFBSSxDQUFDMmpCLEVBQUUsSUFBSTNqQixJQUFJLENBQUMyakIsRUFBRSxDQUFDMzdCLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDNUNvRSxRQUFRLEdBQUdBLFFBQVEsQ0FBQ2xJLE1BQU0sQ0FBQzhiLElBQUksQ0FBQzJqQixFQUFFLENBQUM7SUFDdkM7SUFDQXYzQixRQUFRLEdBQUdBLFFBQVEsQ0FBQ0ksR0FBRyxDQUFDLFVBQVVvM0IsR0FBRyxFQUFFO01BQ25DLE9BQU87UUFBRXBuQixFQUFFLEVBQUVvbkI7TUFBSSxDQUFDO0lBQ3RCLENBQUMsQ0FBQztJQUNGQyxJQUFJLENBQUNDLGVBQWUsQ0FBQztNQUNqQjtNQUNBQyxPQUFPLEVBQUUsQ0FBQyxVQUFVLENBQUM7TUFDckJ6NkIsTUFBTSxFQUFFO1FBQ0owNkIsS0FBSyxFQUFFO1VBQ0hDLElBQUksRUFBRTtZQUNGamtCLElBQUksRUFBRSxDQUNGO2NBQ0luVyxJQUFJLEVBQUUsZUFBZTtjQUNyQnE2QixPQUFPLEVBQUU5M0I7WUFDYixDQUFDO1VBRVQ7UUFDSjtNQUNKO0lBQ0osQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVDNEQ7QUFDN0QsSUFBTWc0QixpQkFBaUIsR0FBRyxzQkFBc0I7QUFDaEQsSUFBTUMsZ0JBQWdCLEdBQUl0dEIsY0FBYyxJQUFLO0VBQ3pDLE9BQVFvdEIsd0RBQVEsQ0FBQ3B0QixjQUFjLENBQUMsSUFDNUJoSSxNQUFNLENBQUN1MUIsTUFBTSxDQUFDdnRCLGNBQWMsQ0FBQyxDQUFDekUsS0FBSyxDQUFFaXlCLGFBQWEsSUFBS0osd0RBQVEsQ0FBQ0ksYUFBYSxDQUFDLElBQUlqOEIsd0RBQVEsQ0FBQ2k4QixhQUFhLENBQUNybkIsT0FBTyxDQUFDLENBQUM7QUFDMUgsQ0FBQztBQUNNLElBQU15UyxpQ0FBaUMsR0FBR0EsQ0FBQSxLQUFNO0VBQ25ELElBQU01WSxjQUFjLEdBQUd4TyxtREFBTyxDQUFDbUIsS0FBSyxDQUFDQyxHQUFHLENBQUN5NkIsaUJBQWlCLENBQUM7RUFDM0QsT0FBT0MsZ0JBQWdCLENBQUN0dEIsY0FBYyxDQUFDLEdBQUdBLGNBQWMsR0FBRyxDQUFDLENBQUM7QUFDakUsQ0FBQztBQUNNLElBQU02WSwrQkFBK0IsR0FBSTdZLGNBQWMsSUFBSztFQUMvRHhPLG1EQUFPLENBQUNtQixLQUFLLENBQUM4akIsR0FBRyxDQUFDNFcsaUJBQWlCLEVBQUVydEIsY0FBYyxDQUFDO0FBQ3hELENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWm1FO0FBQy9CO0FBQ3JDLElBQU15dEIsY0FBYyxHQUFHLFVBQVU7QUFDakMsSUFBTUMsYUFBYSxHQUFHO0VBQ2xCLG9CQUFvQixFQUFFO0lBQ2xCeGEsT0FBTyxFQUFFO0VBQ2IsQ0FBQztFQUNEL2lCLE1BQU0sRUFBRTtJQUNKdzlCLEtBQUssRUFBRSxLQUFLO0lBQ1p6YSxPQUFPLEVBQUUsS0FBSztJQUNkcGdCLElBQUksRUFBRTtFQUNWLENBQUM7RUFDRCxlQUFlLEVBQUU7SUFDYjY2QixLQUFLLEVBQUUsSUFBSTtJQUNYemEsT0FBTyxFQUFFLElBQUk7SUFDYnBnQixJQUFJLEVBQUU7RUFDVjtBQUNKLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTTg2QixtQkFBbUIsR0FBR0EsQ0FBQzk2QixJQUFJLEVBQUUrNkIsS0FBSyxFQUFFclEsT0FBTyxLQUFLO0VBQ2xELElBQU0vWCxFQUFFLE1BQUF0WSxNQUFBLENBQU1zZ0MsY0FBYyxFQUFBdGdDLE1BQUEsQ0FBRzJGLElBQUksQ0FBRTtFQUNyQztFQUNBLElBQUlULE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNrTSxpQkFBaUIsSUFBSTNMLElBQUksS0FBSyxlQUFlLEVBQUU7SUFDdEU7SUFDQTtJQUNBO0lBQ0EsSUFBTW1YLElBQUksR0FBR3RQLFFBQVEsQ0FBQ216QixjQUFjLENBQUNyb0IsRUFBRSxDQUFDO0lBQ3hDLElBQUl3RSxJQUFJLGFBQUpBLElBQUksZUFBSkEsSUFBSSxDQUFFK00sVUFBVSxFQUFFO01BQ2xCemdCLG1EQUFHLENBQUMsWUFBWSwrQ0FBQXBKLE1BQUEsQ0FBK0MyRixJQUFJLENBQUUsQ0FBQztNQUN0RW1YLElBQUksQ0FBQytNLFVBQVUsQ0FBQytXLFdBQVcsQ0FBQzlqQixJQUFJLENBQUM7SUFDckM7RUFDSjtFQUNBO0VBQ0EsSUFBTThCLE1BQU0sR0FBR3BSLFFBQVEsQ0FBQzZhLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDNUN6SixNQUFNLENBQUN0RyxFQUFFLEdBQUdBLEVBQUU7RUFDZHNHLE1BQU0sQ0FBQzBKLFNBQVMseUJBQUF0b0IsTUFBQSxDQUF5QnF3QixPQUFPLENBQUN6akIsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFFO0VBQzVEZ1MsTUFBTSxDQUFDWCxPQUFPLENBQUM0aUIsUUFBUSxjQUFBN2dDLE1BQUEsQ0FBYzJGLElBQUksQ0FBRTtFQUMzQ2laLE1BQU0sQ0FBQ1gsT0FBTyxDQUFDdFksSUFBSSxHQUFHQSxJQUFJO0VBQzFCaVosTUFBTSxDQUFDdUwsWUFBWSxDQUFDLGFBQWEsRUFBRSxNQUFNLENBQUM7RUFDMUN0ZixNQUFNLENBQUNDLE9BQU8sQ0FBQzQxQixLQUFLLENBQUMsQ0FBQzFnQixPQUFPLENBQUNyZ0IsSUFBQTtJQUFBLElBQUMsQ0FBQzRTLENBQUMsRUFBRXV1QixDQUFDLENBQUMsR0FBQW5oQyxJQUFBO0lBQUEsT0FBTWlmLE1BQU0sQ0FBQ1gsT0FBTyxDQUFDMUwsQ0FBQyxDQUFDLEdBQUd1dUIsQ0FBQztFQUFBLENBQUMsQ0FBQztFQUNsRSxPQUFPbGlCLE1BQU07QUFDakIsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBLElBQU1taUIsYUFBYSxHQUFHQSxDQUFDOWtCLFFBQVEsRUFBRW9VLE9BQU87RUFBQSxJQUFBMlEsY0FBQTtFQUFBLE9BQUssQ0FBQyxLQUFBQSxjQUFBLEdBQUkzUSxPQUFPLGFBQVBBLE9BQU8sdUJBQVBBLE9BQU8sQ0FBRTliLEtBQUssQ0FBQyxHQUFHLENBQUMsY0FBQXlzQixjQUFBLGNBQUFBLGNBQUEsR0FBSSxFQUFFLENBQUMsRUFBRS9rQixRQUFRLENBQUMsQ0FBQzNULEdBQUcsQ0FBRWdnQixTQUFTLGdCQUFBdG9CLE1BQUEsQ0FBaUJzb0IsU0FBUyxDQUFFLENBQUM7QUFBQTtBQUNuSTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU12TixrQkFBa0IsR0FBRyxTQUFBQSxDQUFDa21CLG1CQUFtQjtFQUFBLElBQUVDLGtCQUFrQixHQUFBdDhCLFNBQUEsQ0FBQWQsTUFBQSxRQUFBYyxTQUFBLFFBQUFDLFNBQUEsR0FBQUQsU0FBQSxNQUFHLENBQUMsQ0FBQztFQUFBLE9BQUtpRyxNQUFNLENBQUNDLE9BQU8sQ0FBQ28yQixrQkFBa0IsQ0FBQyxDQUFDL29CLE1BQU0sQ0FBQyxDQUFDZ3BCLG1CQUFtQixFQUFBLzFCLEtBQUEsS0FBNEI7SUFBQSxJQUFBZzJCLHFCQUFBO0lBQUEsSUFBMUIsQ0FBQ0MsTUFBTSxFQUFFQyxXQUFXLENBQUMsR0FBQWwyQixLQUFBO0lBQzlKLElBQUksQ0FBQzdMLGtGQUFZLENBQUM4aEMsTUFBTSxDQUFDLEVBQUU7TUFDdkIsTUFBTSxJQUFJampCLEtBQUssK0JBQUFwZSxNQUFBLENBQStCcWhDLE1BQU0sQ0FBRSxDQUFDO0lBQzNEO0lBQ0EsSUFBTXhsQixLQUFLLEdBQUd5bEIsV0FBVyxDQUFDbnBCLE1BQU0sQ0FBQyxDQUFDa1YsR0FBRyxFQUFFaHFCLElBQUksS0FBSztNQUM1QyxJQUFNaytCLFlBQVksR0FBR2xVLEdBQUcsQ0FBQzFVLElBQUksQ0FBRTNVLENBQUMsSUFBS0EsQ0FBQyxDQUFDcEUsS0FBSyxLQUFLeUQsSUFBSSxDQUFDekQsS0FBSyxJQUFJb0UsQ0FBQyxDQUFDbkUsTUFBTSxLQUFLd0QsSUFBSSxDQUFDeEQsTUFBTSxDQUFDO01BQ3hGLElBQUksQ0FBQzBoQyxZQUFZLEVBQUU7UUFDZmxVLEdBQUcsQ0FBQ2pOLElBQUksQ0FBQy9jLElBQUksQ0FBQztNQUNsQjtNQUNBLE9BQU9ncUIsR0FBRztJQUNkLENBQUMsRUFBRSxDQUFDLEtBQUErVCxxQkFBQSxHQUFJRCxtQkFBbUIsQ0FBQ0UsTUFBTSxDQUFDLGNBQUFELHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRSxDQUFDLENBQUMsQ0FBQztJQUM1QyxPQUFBLytCLGFBQUEsQ0FBQUEsYUFBQSxLQUNPOCtCLG1CQUFtQjtNQUN0QixDQUFDRSxNQUFNLEdBQUd4bEI7SUFBSztFQUV2QixDQUFDLEVBQUF4WixhQUFBLEtBQU80K0IsbUJBQW1CLENBQUUsQ0FBQztBQUFBO0FBQzlCLElBQU0xUixvQkFBb0IsR0FBRyxtQkFBbUI7QUFDaEQsSUFBTUUsbUJBQW1CLEdBQUcsU0FBQUEsQ0FBQzdRLE1BQU0sRUFBbUI7RUFBQSxJQUFBNGlCLGtCQUFBO0VBQUEsSUFBakIxSyxPQUFPLEdBQUFseUIsU0FBQSxDQUFBZCxNQUFBLFFBQUFjLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQzdDLElBQU02akIsU0FBUyxHQUFHamIsUUFBUSxDQUFDNmEsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUMvQ0ksU0FBUyxDQUFDSCxTQUFTLE1BQUF0b0IsTUFBQSxDQUFNdXZCLG9CQUFvQixPQUFBdnZCLE1BQUEsRUFBQXdoQyxrQkFBQSxHQUFJMUssT0FBTyxDQUFDeE8sU0FBUyxjQUFBa1osa0JBQUEsY0FBQUEsa0JBQUEsR0FBSSxFQUFFLENBQUU7RUFDMUUvWSxTQUFTLENBQUN4SyxPQUFPLENBQUNXLE1BQU0sR0FBRyxNQUFNO0VBQ2pDNkosU0FBUyxDQUFDRyxXQUFXLENBQUNoSyxNQUFNLENBQUM7RUFDN0IsT0FBTzZKLFNBQVM7QUFDcEIsQ0FBQztBQUNELElBQU0rRyxZQUFZLEdBQUcsU0FBQUEsQ0FBQzdwQixJQUFJLEVBQW1CO0VBQUEsSUFBQTg3QixtQkFBQSxFQUFBaDJCLEtBQUEsRUFBQWkyQixhQUFBO0VBQUEsSUFBakI1SyxPQUFPLEdBQUFseUIsU0FBQSxDQUFBZCxNQUFBLFFBQUFjLFNBQUEsUUFBQUMsU0FBQSxHQUFBRCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQ3BDLElBQU0rOEIsWUFBWSxJQUFBRixtQkFBQSxHQUFHbEIsYUFBYSxDQUFDNTZCLElBQUksQ0FBQyxjQUFBODdCLG1CQUFBLGNBQUFBLG1CQUFBLEdBQUksQ0FBQyxDQUFDO0VBQzlDLElBQU14bEIsUUFBUSxJQUFBeFEsS0FBQSxJQUFBaTJCLGFBQUEsR0FBRzVLLE9BQU8sQ0FBQ254QixJQUFJLGNBQUErN0IsYUFBQSxjQUFBQSxhQUFBLEdBQUlDLFlBQVksQ0FBQ2g4QixJQUFJLGNBQUE4RixLQUFBLGNBQUFBLEtBQUEsR0FBSTlGLElBQUk7RUFDMUQsSUFBTWk4QixjQUFjLEdBQUcsQ0FBQyxDQUFDO0VBQ3pCLElBQUlELFlBQVksQ0FBQ25CLEtBQUssS0FBSyxLQUFLLEVBQUU7SUFDOUJvQixjQUFjLENBQUNwQixLQUFLLEdBQUcsT0FBTztFQUNsQztFQUNBLElBQUltQixZQUFZLENBQUM1YixPQUFPLEtBQUssS0FBSyxFQUFFO0lBQ2hDNmIsY0FBYyxDQUFDN2IsT0FBTyxHQUFHLE9BQU87RUFDcEM7RUFDQSxPQUFPMGEsbUJBQW1CLENBQUN4a0IsUUFBUSxFQUFFMmxCLGNBQWMsRUFBRWIsYUFBYSxDQUFDOWtCLFFBQVEsRUFBRTZhLE9BQU8sQ0FBQ3pHLE9BQU8sQ0FBQyxDQUFDO0FBQ2xHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvRmtDO0FBQ25DLElBQU10TSxhQUFhLEdBQUl6TCxFQUFFO0VBQUEsSUFBQXVwQixtQkFBQTtFQUFBLFFBQUFBLG1CQUFBLEdBQUsvZCw0Q0FBTSxDQUFDeUMsT0FBTyxDQUFDOWdCLEdBQUcsQ0FBQzZTLEVBQUUsQ0FBQyxjQUFBdXBCLG1CQUFBLGNBQUFBLG1CQUFBLEdBQUksSUFBSTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7O0FDRHpCO0FBQzVCLElBQU05UyxXQUFXLEdBQUlqUSxNQUFNLElBQUs7RUFDbkNnRiw0Q0FBTSxDQUFDYyxhQUFhLENBQUN4RSxJQUFJLENBQUN0QixNQUFNLENBQUM7QUFDckMsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0htQztBQUNtQjtBQUNFO0FBQ3pEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsTUFBTWtqQixRQUFRLENBQUM7RUFJWHRpQyxXQUFXQSxDQUFDb2YsTUFBTSxFQUFFMUMsSUFBSSxFQUFFO0lBQUF0YyxlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUN0QixJQUFJLENBQUNtaUMsTUFBTSxHQUFHbmpCLE1BQU0sQ0FBQ3hHLEVBQUU7SUFDdkIsSUFBSSxDQUFDMkQsUUFBUSxHQUFHL1csTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDbWEsTUFBTTtJQUNsRCxJQUFJLENBQUMzRCxLQUFLLEdBQUdPLElBQUksQ0FBQ1AsS0FBSyxDQUFDdlQsR0FBRyxDQUFFakYsSUFBSSxJQUFLNUQsS0FBSyxDQUFDczVCLElBQUksQ0FBQzExQixJQUFJLENBQUMsQ0FBQztFQUMzRDtBQUNKO0FBQ0EsSUFBSTYrQixXQUFXLEdBQUcsS0FBSztBQUN2QixJQUFJQyxZQUFZLEdBQUd2Z0IsT0FBTyxDQUFDRSxPQUFPLENBQUMsQ0FBQztBQUNwQyxJQUFNc2dCLGFBQWEsR0FBRyxJQUFJO0FBQzFCLElBQU1DLFVBQVUsR0FBR0EsQ0FBQSxLQUFNO0VBQ3JCLElBQUksQ0FBQ0gsV0FBVyxJQUFJaDlCLE1BQU0sQ0FBQ285QixNQUFNLEVBQUU7SUFDL0JKLFdBQVcsR0FBRyxJQUFJO0lBQ2xCLElBQU1LLGNBQWMsR0FBR3I5QixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNtOUIsT0FBTyxHQUNwRCxDQUNFLFNBQVMsQ0FBRTtJQUFBLENBQ2QsR0FDQyxFQUFFO0lBQ1J0OUIsTUFBTSxDQUFDbzlCLE1BQU0sQ0FBQ2pXLElBQUksQ0FBQztNQUNmb1csS0FBSyxFQUFFdjlCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ3E5QixhQUFhO01BQ2hEQyxRQUFRLEVBQUUsV0FBVztNQUNyQkMsVUFBVSxFQUFFUixhQUFhO01BQ3pCRztJQUNKLENBQUMsQ0FBQztFQUNOO0FBQ0osQ0FBQztBQUNELElBQU1NLGdCQUFnQixHQUFJQyxXQUFXLElBQUs7RUFBQSxJQUFBQyxnQkFBQSxFQUFBQyxxQkFBQSxFQUFBQyxzQkFBQSxFQUFBQyxzQkFBQTtFQUN0QyxDQUFBRixxQkFBQSxJQUFBRCxnQkFBQSxHQUFBNzlCLE1BQU0sQ0FBQ0MsUUFBUSxFQUFDZytCLFVBQVUsY0FBQUgscUJBQUEsY0FBQUEscUJBQUEsR0FBMUJELGdCQUFBLENBQWdCSSxVQUFVLEdBQUssQ0FBQyxDQUFDO0VBQ2pDLENBQUFELHNCQUFBLElBQUFELHNCQUFBLEdBQUEvOUIsTUFBTSxDQUFDQyxRQUFRLENBQUNnK0IsVUFBVSxFQUFDQyxhQUFhLGNBQUFGLHNCQUFBLGNBQUFBLHNCQUFBLEdBQXhDRCxzQkFBQSxDQUEyQkcsYUFBYSxHQUFLLEVBQUU7RUFDL0NsK0IsTUFBTSxDQUFDQyxRQUFRLENBQUNnK0IsVUFBVSxDQUFDQyxhQUFhLENBQUNoakIsSUFBSSxDQUFDLEdBQUcwaUIsV0FBVyxDQUFDO0FBQ2pFLENBQUM7QUFDRDtBQUNBO0FBQ0EsSUFBTXplLFdBQVc7RUFBQSxJQUFBMWtCLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsV0FBT3dZLE9BQU8sRUFBRThjLFdBQVcsRUFBSztJQUNoRCxJQUFJLENBQUNuQixXQUFXLEVBQUU7TUFDZCxPQUFPQyxZQUFZO0lBQ3ZCO0lBQ0EsSUFBSSxDQUFDajlCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUM4bUIsUUFBUSxDQUFDb1gsZUFBZSxFQUFFO01BQ2xELE9BQU9uQixZQUFZO0lBQ3ZCO0lBQ0EsSUFBTW9CLE9BQU8sR0FBR3pCLHFEQUFPLENBQUN2YixPQUFPLENBQUNqZSxHQUFHLENBQUV3VyxNQUFNLElBQUtpakIscUVBQXVCLENBQUNqakIsTUFBTSxFQUFFdWtCLFdBQVcsQ0FBQyxDQUFDLzZCLEdBQUcsQ0FBRThULElBQUksSUFBSyxJQUFJNGxCLFFBQVEsQ0FBQ2xqQixNQUFNLEVBQUUxQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDeEksSUFBSW1uQixPQUFPLENBQUN6L0IsTUFBTSxLQUFLLENBQUMsRUFBRTtNQUN0QixPQUFPcStCLFlBQVk7SUFDdkI7SUFDQUEsWUFBWSxHQUFHQSxZQUFZLENBQ3RCbmhCLElBQUksQ0FBQyxNQUFNLElBQUlZLE9BQU8sQ0FBRUUsT0FBTyxJQUFLO01BQUEsSUFBQTBoQixjQUFBO01BQ3JDLENBQUFBLGNBQUEsR0FBQXQrQixNQUFNLENBQUNvOUIsTUFBTSxjQUFBa0IsY0FBQSxlQUFiQSxjQUFBLENBQWVDLFNBQVMsQ0FBQztRQUFFbGdCLEtBQUssRUFBRWdnQjtNQUFRLENBQUMsRUFBR1QsV0FBVyxJQUFLO1FBQzFERCxnQkFBZ0IsQ0FBQ0MsV0FBVyxDQUFDO1FBQzdCNTlCLE1BQU0sQ0FBQ29WLFNBQVMsQ0FBQzZVLEdBQUcsQ0FBQy9PLElBQUksQ0FBQyxNQUFNO1VBQUEsSUFBQXNqQixlQUFBO1VBQzVCLENBQUFBLGVBQUEsR0FBQXgrQixNQUFNLENBQUNvOUIsTUFBTSxjQUFBb0IsZUFBQSxlQUFiQSxlQUFBLENBQWVDLGNBQWMsQ0FBQyxDQUFDO1VBQy9CN2hCLE9BQU8sQ0FBQyxDQUFDO1FBQ2IsQ0FBQyxDQUFDO01BQ04sQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDLENBQUMsQ0FDRTRELEtBQUssQ0FBQyxNQUFNO01BQ2JqSCxnRUFBVyxDQUFDLElBQUlMLEtBQUssQ0FBQyx5QkFBeUIsQ0FBQyxFQUFFLFlBQVksQ0FBQztJQUNuRSxDQUFDLENBQUM7SUFDRixPQUFPK2pCLFlBQVk7RUFDdkIsQ0FBQztFQUFBLGdCQXpCSzlkLFdBQVdBLENBQUF2VixFQUFBLEVBQUFvVCxHQUFBO0lBQUEsT0FBQXZpQixJQUFBLENBQUEyTyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQXlCaEI7QUFDTSxJQUFNb2hCLEVBQUUsR0FBRztFQUNkcWMsVUFBVTtFQUNWaGUsV0FBVztFQUNYd2U7QUFDSixDQUFDO0FBQ00sSUFBTTkrQixDQUFDLEdBQUc7RUFDYndDLFdBQVcsRUFBRUEsQ0FBQSxLQUFNO0lBQ2YyN0IsV0FBVyxHQUFHLEtBQUs7SUFDbkJDLFlBQVksR0FBR3ZnQixPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0VBQ3BDO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvRTZFO0FBQ1Y7QUFDcUk7QUFDek0sSUFBTXVpQixrQkFBa0IsR0FBSXhvQixLQUFLLElBQUs7RUFDbEMsSUFBTXdsQixNQUFNLEdBQUc4Qyx3REFBZ0IsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEdBQUcsR0FBRyxHQUFHO0VBQ3JEO0VBQ0EsSUFBTUcsV0FBVyxHQUFHcC9CLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzRNLE9BQU8sSUFDbkQvTSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNpL0IsV0FBVyxDQUFDN29CLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO0VBQzlELElBQU04b0IsUUFBUSxHQUFHSCxzREFBYyxDQUFDdm9CLEtBQUssQ0FBQztFQUN0QyxJQUFJMG9CLFFBQVEsRUFBRTtJQUNWLFVBQUF2a0MsTUFBQSxDQUFVcWhDLE1BQU0sRUFBQXJoQyxNQUFBLENBQUdza0MsV0FBVyxDQUFDNW9CLFdBQVcsQ0FBQyxDQUFDLEVBQUExYixNQUFBLENBQUd1a0MsUUFBUSxDQUFDMzNCLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDckU7QUFDSixDQUFDO0FBQ00sSUFBTTQzQiw0QkFBNEIsR0FBSTNvQixLQUFLLElBQUs7RUFDbkQsSUFBSXhWLG1GQUFVLENBQUMsQ0FBQyxFQUFFO0lBQ2QsT0FBTyxVQUFVO0VBQ3JCO0VBQ0EsSUFBSUMsZ0ZBQU8sQ0FBQyxDQUFDLElBQUkwOUIsNERBQW9CLENBQUNub0IsS0FBSyxDQUFDLEVBQUU7SUFDMUMsT0FBTyxVQUFVO0VBQ3JCO0VBQ0EsSUFBTTRvQixrQkFBa0IsR0FBRyxTQUFTO0VBQ3BDLFFBQVFOLHdEQUFnQixDQUFDLENBQUM7SUFDdEIsS0FBSyxHQUFHO01BQ0o7TUFDQTtNQUNBLElBQUlOLHVFQUErQixDQUFDaG9CLEtBQUssQ0FBQyxFQUFFO1FBQ3hDLE9BQU8sVUFBVTtNQUNyQjtNQUNBLElBQUlxb0IseURBQWlCLENBQUNyb0IsS0FBSyxDQUFDLEVBQUU7UUFDMUIsT0FBTyxTQUFTO01BQ3BCO01BQ0EsSUFBSWtvQixzRUFBOEIsQ0FBQ2xvQixLQUFLLENBQUMsRUFBRTtRQUN2QyxPQUFPLFNBQVM7TUFDcEI7TUFDQSxPQUFPNG9CLGtCQUFrQjtJQUM3QixLQUFLLEdBQUc7TUFDSixJQUFJUixtREFBVyxDQUFDcG9CLEtBQUssQ0FBQyxFQUFFO1FBQ3BCLE9BQU8sU0FBUztNQUNwQjtNQUNBLE9BQU80b0Isa0JBQWtCO0lBQzdCLEtBQUssR0FBRztNQUNKLElBQUlSLG1EQUFXLENBQUNwb0IsS0FBSyxDQUFDLEVBQUU7UUFDcEIsT0FBTyxTQUFTO01BQ3BCO01BQ0EsSUFBSWlvQiwyREFBbUIsQ0FBQ2pvQixLQUFLLENBQUMsRUFBRTtRQUM1QixPQUFPLFNBQVM7TUFDcEI7TUFDQSxPQUFPNG9CLGtCQUFrQjtJQUM3QjtNQUNJLE9BQU9BLGtCQUFrQjtFQUNqQztBQUNKLENBQUM7QUFDTSxJQUFNQywwQkFBMEIsR0FBR0EsQ0FBQzdvQixLQUFLLEVBQUUvSCxhQUFhLEVBQUVxRyxNQUFNLEtBQUs7RUFDeEUsSUFBSTlULG1GQUFVLENBQUMsQ0FBQyxJQUFJbkIsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQzhtQixRQUFRLENBQUN5WSxxQkFBcUIsRUFBRTtJQUN2RSxJQUFNQyxPQUFPLEdBQUdQLGtCQUFrQixDQUFDeG9CLEtBQUssQ0FBQztJQUN6QyxJQUFJK29CLE9BQU8sRUFBRTtNQUNULE9BQU87UUFDSEEsT0FBTztRQUNQQyxNQUFNLEVBQUUsTUFBTTtRQUNkdnlCLFFBQVEsRUFBQWpRLGFBQUEsQ0FBQUEsYUFBQTtVQUNKeWlDLElBQUksRUFBRSxDQUFDRixPQUFPO1FBQUMsR0FDWmhCLDZFQUE0QixDQUFDOXZCLGFBQWEsQ0FBQztVQUM5Q3NJLElBQUksRUFBRWpDO1FBQU07TUFFcEIsQ0FBQztJQUNMO0VBQ0o7RUFDQSxPQUFPO0lBQ0g0cUIsV0FBVyxFQUFFUCw0QkFBNEIsQ0FBQzNvQixLQUFLLENBQUM7SUFDaER2SixRQUFRLEVBQUFqUSxhQUFBLENBQUFBLGFBQUEsS0FDRHVoQyw2RUFBNEIsQ0FBQzl2QixhQUFhLENBQUM7TUFDOUNzSSxJQUFJLEVBQUVqQztJQUFNO0VBRXBCLENBQUM7QUFDTCxDQUFDO0FBQ00sSUFBTXBXLENBQUMsR0FBRztFQUFFeWdDO0FBQTZCLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzNFbUQ7QUFDL0Q7QUFDTTtBQUN5QjtBQUMxQjtBQUM4TztBQUNoTztBQUNPO0FBQy9ELElBQU1lLFNBQVMsR0FBR3JnQyxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMrVSxXQUFXLEtBQUssU0FBUztBQUN2RSxJQUFNb3JCLG1CQUFtQixHQUFHckIsd0RBQWdCLENBQUMsQ0FBQyxLQUFLLEdBQUcsSUFBSW9CLFNBQVM7QUFDbkUsSUFBTUUsaUJBQWlCLEdBQUdBLENBQUN0ckIsTUFBTSxFQUFFdXJCLGdCQUFnQixLQUFLO0VBQ3BELFFBQVFOLHlEQUFpQixDQUFDanJCLE1BQU0sQ0FBQztJQUM3QixLQUFLLGlCQUFpQjtNQUNsQixPQUFPLE1BQU07SUFDakIsS0FBSyxpQkFBaUI7TUFDbEIsSUFBSXVyQixnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixJQUFJQSxnQkFBZ0IsRUFDaEIsT0FBTyxNQUFNO01BQ2pCLE9BQU8sTUFBTTtJQUNqQixLQUFLLGlCQUFpQjtNQUNsQixPQUFPLE1BQU07SUFDakIsS0FBSyxlQUFlO01BQ2hCLE9BQU8sTUFBTTtJQUNqQixLQUFLLHVCQUF1QjtNQUN4QixPQUFPLE1BQU07SUFDakIsS0FBSyxrQkFBa0I7TUFDbkIsT0FBTyxNQUFNO0lBQ2pCLEtBQUssdUJBQXVCO01BQ3hCLE9BQU8sTUFBTTtJQUNqQjtNQUNJO01BQ0EsSUFBSXZyQixNQUFNLENBQUNrTSxVQUFVLENBQUMsZ0JBQWdCLENBQUMsRUFBRTtRQUNyQyxJQUFJcWYsZ0JBQWdCLEVBQ2hCLE9BQU8sTUFBTTtRQUNqQixPQUFPLE1BQU07TUFDakI7TUFDQXQ4QixtREFBRyxDQUFDLFlBQVksbURBQUFwSixNQUFBLENBQW1EbWEsTUFBTSxNQUFHLENBQUM7TUFDN0UsT0FBTyxFQUFFO0VBQ2pCO0FBQ0osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNd3JCLHdCQUF3QixHQUFHQSxDQUFBLEtBQU07RUFDbkMsSUFBTUMsSUFBSSxHQUFHMWdDLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ3dnQyxZQUFZLENBQUNsdEIsSUFBSSxDQUFFM1UsQ0FBQyxJQUFLQSxDQUFDLENBQUM0VyxFQUFFLEtBQUt1cEIsd0RBQWdCLENBQUMsQ0FBQyxDQUFDO0VBQzlGLE9BQU95QixJQUFJLGFBQUpBLElBQUksZUFBSkEsSUFBSSxDQUFFdHRCLEVBQUUsR0FBR3N0QixJQUFJLENBQUN0dEIsRUFBRSxDQUFDdlksUUFBUSxDQUFDLENBQUMsR0FBRyxFQUFFO0FBQzdDLENBQUM7QUFDRCxJQUFNK2xDLGNBQWMsR0FBSXJqQixTQUFTLElBQUs7RUFDbEM7RUFDQTtFQUNBLElBQUlvaEIsdUVBQStCLENBQUNwaEIsU0FBUyxDQUFDLEVBQUU7SUFDNUMsT0FBTyxRQUFRO0VBQ25CO0VBQ0E7RUFDQSxJQUFJdWhCLDREQUFvQixDQUFDdmhCLFNBQVMsQ0FBQyxFQUFFO0lBQ2pDLE9BQU8sU0FBUztFQUNwQjtFQUNBO0VBQ0EsT0FBT2tqQix3QkFBd0IsQ0FBQyxDQUFDO0FBQ3JDLENBQUM7QUFDRCxJQUFNSSxtQkFBbUIsR0FBSWxxQixLQUFLLElBQUs7RUFDbkMsUUFBUXNvQix3REFBZ0IsQ0FBQyxDQUFDO0lBQ3RCLEtBQUssR0FBRztNQUNKLElBQUlELHlEQUFpQixDQUFDcm9CLEtBQUssQ0FBQyxFQUFFO1FBQzFCLE9BQU8sUUFBUTtNQUNuQjtNQUNBLElBQUlrb0Isc0VBQThCLENBQUNsb0IsS0FBSyxDQUFDLEVBQUU7UUFDdkMsT0FBTyxRQUFRO01BQ25CO01BQ0EsT0FBTyxRQUFRO0lBQ25CLEtBQUssR0FBRztNQUNKLElBQUlxb0IseURBQWlCLENBQUNyb0IsS0FBSyxDQUFDLEVBQUU7UUFDMUIsT0FBTyxRQUFRO01BQ25CO01BQ0EsT0FBTyxRQUFRO0lBQ25CLEtBQUssR0FBRztNQUNKLElBQUlxb0IseURBQWlCLENBQUNyb0IsS0FBSyxDQUFDLEVBQUU7UUFDMUIsT0FBTyxRQUFRO01BQ25CO01BQ0EsSUFBSWtvQixzRUFBOEIsQ0FBQ2xvQixLQUFLLENBQUMsRUFBRTtRQUN2QyxPQUFPLFFBQVE7TUFDbkI7TUFDQSxPQUFPLFFBQVE7SUFDbkI7TUFDSSxPQUFPLENBQUMsQ0FBQztFQUNqQjtBQUNKLENBQUM7QUFDRCxJQUFNbXFCLDBCQUEwQixHQUFHQSxDQUFDN3JCLE1BQU0sRUFBRTBCLEtBQUssS0FBSztFQUNsRCxJQUFJaW9CLDJEQUFtQixDQUFDam9CLEtBQUssQ0FBQyxFQUFFO0lBQzVCLElBQUl6VixtRkFBVSxDQUFDLENBQUMsRUFBRTtNQUNkLE9BQU8scUNBQXFDO0lBQ2hELENBQUMsTUFDSSxJQUFJQyxtRkFBVSxDQUFDLENBQUMsRUFBRTtNQUNuQixPQUFPLHdDQUF3QztJQUNuRDtFQUNKO0VBQ0EsSUFBSTQ5QixtREFBVyxDQUFDcG9CLEtBQUssQ0FBQyxFQUFFO0lBQ3BCLElBQUl6VixtRkFBVSxDQUFDLENBQUMsRUFBRTtNQUNkLE9BQU9tL0IsU0FBUyxHQUNWLG9DQUFvQyxHQUNwQyx5Q0FBeUM7SUFDbkQsQ0FBQyxNQUNJLElBQUlsL0IsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7TUFDbkIsT0FBT2svQixTQUFTLEdBQ1YsdUNBQXVDLEdBQ3ZDLDRDQUE0QztJQUN0RDtFQUNKO0VBQ0EsSUFBSU4seURBQWlCLENBQUNwcEIsS0FBSyxDQUFDLEVBQUU7SUFDMUIsSUFBSXpWLG1GQUFVLENBQUMsQ0FBQyxFQUFFO01BQ2QsT0FBTyxvQ0FBb0M7SUFDL0MsQ0FBQyxNQUNJLElBQUlDLG1GQUFVLENBQUMsQ0FBQyxFQUFFO01BQ25CLE9BQU8sdUNBQXVDO0lBQ2xEO0VBQ0o7RUFDQSxJQUFJMjlCLDREQUFvQixDQUFDbm9CLEtBQUssQ0FBQyxFQUFFO0lBQzdCLElBQUl6VixtRkFBVSxDQUFDLENBQUMsRUFBRTtNQUNkLE9BQU8sd0JBQXdCO0lBQ25DLENBQUMsTUFDSSxJQUFJQyxtRkFBVSxDQUFDLENBQUMsRUFBRTtNQUNuQixPQUFPLDJCQUEyQjtJQUN0QztFQUNKO0VBQ0EsT0FBTyxFQUFFO0FBQ2IsQ0FBQztBQUNEO0FBQ0EsSUFBTTQvQixVQUFVLEdBQUdBLENBQUEsS0FBTXA3QixNQUFNLENBQUN3UixJQUFJLENBQUMyb0IsbURBQWEsQ0FBQyxDQUFDLENBQUMsQ0FBQ2xoQyxNQUFNLEdBQUcsQ0FBQztBQUNoRTtBQUNBLElBQU1vaUMsVUFBVSxHQUFJQyxVQUFVLElBQUtGLFVBQVUsQ0FBQyxDQUFDLElBQUlFLFVBQVU7QUFDN0Q7QUFDQSxJQUFNQyxjQUFjLEdBQUl0eUIsYUFBYSxLQUFNO0VBQ3ZDbk8sSUFBSSxFQUFFLEtBQUs7RUFDWDBnQyxVQUFVLEVBQUUsZ0JBQWdCO0VBQzVCQyxTQUFTLEVBQUVBLENBQUNuc0IsTUFBTSxFQUFFMEIsS0FBSyxLQUFLNm9CLHFFQUEwQixDQUFDN29CLEtBQUssRUFBRS9ILGFBQWEsRUFBRXlSLDREQUFvQixDQUFDcEwsTUFBTSxDQUFDO0FBQy9HLENBQUMsQ0FBQztBQUNGLElBQU1vc0IsV0FBVyxHQUFJenlCLGFBQWEsS0FBTTtFQUNwQ25PLElBQUksRUFBRSxLQUFLO0VBQ1gwZ0MsVUFBVSxFQUFFLGFBQWE7RUFDekJDLFNBQVMsRUFBRUEsQ0FBQ25zQixNQUFNLEVBQUUwQixLQUFLLEtBQUs7SUFDMUIsSUFBTTJxQixZQUFZLEdBQUc1Qyw2RUFBNEIsQ0FBQzl2QixhQUFhLENBQUM7SUFDaEUsSUFBSTFOLG1GQUFVLENBQUMsQ0FBQyxFQUFFO01BQ2QsT0FBTztRQUNIcWdDLFNBQVMsRUFBRSx5QkFBeUI7UUFDcENDLElBQUksRUFBRSxXQUFXO1FBQ2pCRjtNQUNKLENBQUM7SUFDTDtJQUNBLElBQUluZ0MsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7TUFDZCxPQUFPO1FBQ0hvZ0MsU0FBUyxFQUFFLDBCQUEwQjtRQUNyQ0MsSUFBSSxFQUFFLFdBQVc7UUFDakJGO01BQ0osQ0FBQztJQUNMO0lBQ0E7SUFDQSxJQUFJbGdDLGdGQUFPLENBQUMsQ0FBQyxJQUFJMDlCLDREQUFvQixDQUFDbm9CLEtBQUssQ0FBQyxFQUFFO01BQzFDLE9BQU87UUFDSDRxQixTQUFTLEVBQUUsc0JBQXNCO1FBQ2pDQyxJQUFJLEVBQUUsV0FBVztRQUNqQkY7TUFDSixDQUFDO0lBQ0w7SUFDQTtJQUNBLE9BQU87TUFDSEMsU0FBUyxFQUFFLHNCQUFzQjtNQUNqQ0MsSUFBSSxFQUFFLFdBQVc7TUFDakJGO0lBQ0osQ0FBQztFQUNMO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsSUFBTUcsbUJBQW1CLEdBQUk5cUIsS0FBSyxJQUFLO0VBQ25DLElBQUk3VixnRkFBTyxDQUFDLENBQUMsRUFBRTtJQUNYLElBQUltK0Isd0RBQWdCLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtNQUM1QixJQUFJYyx5REFBaUIsQ0FBQ3BwQixLQUFLLENBQUMsRUFBRTtRQUMxQixPQUFPLFlBQVk7TUFDdkI7TUFDQSxJQUFJb29CLG1EQUFXLENBQUNwb0IsS0FBSyxDQUFDLEVBQUU7UUFDcEIsT0FBTyxZQUFZO01BQ3ZCO0lBQ0o7SUFDQSxJQUFJc29CLHdEQUFnQixDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7TUFDNUIsSUFBSUgsNERBQW9CLENBQUNub0IsS0FBSyxDQUFDLEVBQUU7UUFDN0IsT0FBTyxZQUFZO01BQ3ZCO0lBQ0o7SUFDQSxPQUFPLFlBQVk7RUFDdkI7RUFDQSxJQUFJdlYsZ0ZBQU8sQ0FBQyxDQUFDLEVBQUU7SUFDWCxJQUFJMDlCLDREQUFvQixDQUFDbm9CLEtBQUssQ0FBQyxFQUFFO01BQzdCLE9BQU8sWUFBWTtJQUN2QjtFQUNKO0VBQ0EsT0FBTyxZQUFZO0FBQ3ZCLENBQUM7QUFDRCxJQUFNK3FCLFdBQVcsR0FBSTl5QixhQUFhLEtBQU07RUFDcENuTyxJQUFJLEVBQUUsT0FBTztFQUNiMGdDLFVBQVUsRUFBRSxhQUFhO0VBQ3pCQyxTQUFTLEVBQUVBLENBQUNPLE9BQU8sRUFBRWhyQixLQUFLLEtBQUs7SUFDM0IsSUFBTWlELE1BQU0sR0FBR2dGLGdEQUFNLENBQUN5QyxPQUFPLENBQUM5Z0IsR0FBRyxDQUFDb2hDLE9BQU8sQ0FBQztJQUMxQyxJQUFNMXBCLFNBQVMsR0FBRzJCLE1BQU0sYUFBTkEsTUFBTSxlQUFOQSxNQUFNLENBQUUzQixTQUFTLEdBQzdCO01BQUVBLFNBQVMsRUFBRTJCLE1BQU0sQ0FBQzNCO0lBQVUsQ0FBQyxHQUMvQixDQUFDLENBQUM7SUFDUixPQUFPO01BQ0gycEIsV0FBVyxFQUFFLGNBQWM7TUFDM0JDLE1BQU0sRUFBRSxZQUFZO01BQ3BCaEMsV0FBVyxFQUFFNEIsbUJBQW1CLENBQUM5cUIsS0FBSyxDQUFDO01BQ3ZDbXJCLFVBQVUsRUFBRSxDQUNSO1FBQ0lDLFFBQVEsRUFBRSxDQUFDLENBQUM7UUFDWi9qQixTQUFTLEVBQUE3Z0IsYUFBQSxDQUFBQSxhQUFBLEtBRUY4YSxTQUFTLEdBQ1R5bUIsNkVBQTRCLENBQUM5dkIsYUFBYSxDQUFDO01BRXRELENBQUMsQ0FDSjtNQUNEb3pCLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBRTtJQUNuQixDQUFDO0VBQ0w7QUFDSixDQUFDLENBQUM7QUFDRixJQUFNQyxzQkFBc0IsR0FBR0EsQ0FBQSxLQUFNO0VBQ2pDLElBQUkvZ0MsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7SUFDZCxPQUFPLFFBQVE7RUFDbkI7RUFDQSxJQUFJQyxtRkFBVSxDQUFDLENBQUMsRUFBRTtJQUNkLE9BQU8sUUFBUTtFQUNuQjtFQUNBLE9BQU8sUUFBUTtBQUNuQixDQUFDO0FBQ0QsSUFBTStnQyxtQkFBbUIsR0FBSXZyQixLQUFLLElBQUs7RUFDbkMsSUFBSXNvQix3REFBZ0IsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO0lBQzVCO0lBQ0EsSUFBSUosc0VBQThCLENBQUNsb0IsS0FBSyxDQUFDLEVBQUU7TUFDdkMsT0FBTyxhQUFhO0lBQ3hCO0lBQ0E7SUFDQSxJQUFJb29CLG1EQUFXLENBQUNwb0IsS0FBSyxDQUFDLElBQUlxcEIsb0RBQVksQ0FBQ3JwQixLQUFLLENBQUMsRUFBRTtNQUMzQyxPQUFPLGFBQWE7SUFDeEI7SUFDQTtJQUNBLE9BQU8sYUFBYTtFQUN4QjtFQUNBO0VBQ0EsSUFBSW1vQiw0REFBb0IsQ0FBQ25vQixLQUFLLENBQUMsRUFBRTtJQUM3QixPQUFPLGFBQWE7RUFDeEI7RUFDQTtFQUNBLE9BQU8sYUFBYTtBQUN4QixDQUFDO0FBQ0QsSUFBTXdyQixzQkFBc0IsR0FBR0EsQ0FBQ2x0QixNQUFNLEVBQUVzSSxTQUFTLEtBQUs7RUFDbEQsSUFBSXRJLE1BQU0sS0FBSyxpQkFBaUIsSUFDNUJzSSxTQUFTLENBQUM5SixJQUFJLENBQUV0VixJQUFJLElBQUtBLElBQUksQ0FBQ3pELEtBQUssS0FBSyxHQUFHLElBQUl5RCxJQUFJLENBQUN4RCxNQUFNLEtBQUssR0FBRyxDQUFDLEVBQUU7SUFDckUsT0FBT21HLGdGQUFPLENBQUMsQ0FBQyxHQUNWLDJCQUEyQixHQUMzQixnQ0FBZ0M7RUFDMUM7RUFDQSxPQUFPbkIsU0FBUztBQUNwQixDQUFDO0FBQ0QsSUFBTXlpQyxjQUFjLEdBQUk3a0IsU0FBUyxJQUFLO0VBQ2xDLElBQU04a0IsYUFBYSxHQUFHO0lBQ2xCNWhDLElBQUksRUFBRSxVQUFVO0lBQ2hCMGdDLFVBQVUsRUFBRSxnQkFBZ0I7SUFDNUJDLFNBQVMsRUFBR25zQixNQUFNLEtBQU07TUFDcEIyc0IsV0FBVyxFQUFFSyxzQkFBc0IsQ0FBQyxDQUFDO01BQ3JDdm9CLE1BQU0sRUFBRTJHLDREQUFvQixDQUFDcEwsTUFBTSxDQUFDO01BQ3BDNHFCLFdBQVcsRUFBRXNDLHNCQUFzQixDQUFDbHRCLE1BQU0sRUFBRXNJLFNBQVM7SUFDekQsQ0FBQztFQUNMLENBQUM7RUFDRDtFQUNBO0VBQ0EsSUFBSW9oQix1RUFBK0IsQ0FBQ3BoQixTQUFTLENBQUMsRUFBRTtJQUM1QyxPQUFBcGdCLGFBQUEsQ0FBQUEsYUFBQSxLQUNPa2xDLGFBQWE7TUFDaEJqQixTQUFTLEVBQUduc0IsTUFBTSxJQUFBOVgsYUFBQSxDQUFBQSxhQUFBLEtBQ1hrbEMsYUFBYSxDQUFDakIsU0FBUyxDQUFDbnNCLE1BQU0sQ0FBQztRQUNsQzRxQixXQUFXLEVBQUU7TUFBMEI7SUFDekM7RUFFVjtFQUNBLE9BQU93QyxhQUFhO0FBQ3hCLENBQUM7QUFDRCxJQUFNQyxZQUFZLEdBQUc7RUFDakI3aEMsSUFBSSxFQUFFLFFBQVE7RUFDZDBnQyxVQUFVLEVBQUUsY0FBYztFQUMxQkMsU0FBUyxFQUFHbnNCLE1BQU0sS0FBTTtJQUNwQnN0QixHQUFHLEVBQUVoQyxpQkFBaUIsQ0FBQ3RyQixNQUFNLEVBQUVxckIsbUJBQW1CO0VBQ3RELENBQUM7QUFDTCxDQUFDO0FBQ0QsSUFBTWtDLGdCQUFnQixHQUFHO0VBQ3JCL2hDLElBQUksRUFBRSxZQUFZO0VBQ2xCMGdDLFVBQVUsRUFBRSxrQkFBa0I7RUFDOUJDLFNBQVMsRUFBRUEsQ0FBQ25zQixNQUFNLEVBQUUwQixLQUFLLE1BQU07SUFDM0I4ckIsYUFBYSxFQUFFM0IsMEJBQTBCLENBQUM3ckIsTUFBTSxFQUFFMEIsS0FBSyxDQUFDO0lBQ3hEK3JCLEtBQUssRUFBRTVCLDBCQUEwQixDQUFDN3JCLE1BQU0sRUFBRTBCLEtBQUs7RUFDbkQsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNZ3NCLFdBQVcsR0FBRztFQUNoQmxpQyxJQUFJLEVBQUUsS0FBSztFQUNYMGdDLFVBQVUsRUFBRSxhQUFhO0VBQ3pCQyxTQUFTLEVBQUVBLENBQUNuc0IsTUFBTSxFQUFFMEIsS0FBSyxNQUFNO0lBQzNCa3BCLFdBQVcsRUFBRWdCLG1CQUFtQixDQUFDbHFCLEtBQUs7RUFDMUMsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNaXNCLFlBQVksR0FBSXJsQixTQUFTLElBQUs7RUFDaEMsSUFBTThrQixhQUFhLEdBQUc7SUFDbEI1aEMsSUFBSSxFQUFFLFFBQVE7SUFDZDBnQyxVQUFVLEVBQUU7RUFDaEIsQ0FBQztFQUNEO0VBQ0E7RUFDQSxJQUFJeEMsdUVBQStCLENBQUNwaEIsU0FBUyxDQUFDLEVBQUU7SUFDNUMsT0FBQXBnQixhQUFBLENBQUFBLGFBQUEsS0FDT2tsQyxhQUFhO01BQ2hCakIsU0FBUyxFQUFFQSxDQUFBLE1BQU87UUFDZHlCLE1BQU0sRUFBRTtNQUNaLENBQUM7SUFBQztFQUVWO0VBQ0EsT0FBQTFsQyxhQUFBLENBQUFBLGFBQUEsS0FDT2tsQyxhQUFhO0lBQ2hCakIsU0FBUyxFQUFFQSxDQUFBLE1BQU87TUFDZDBCLFNBQVMsRUFBRTtJQUNmLENBQUM7RUFBQztBQUVWLENBQUM7QUFDRCxJQUFNQyxXQUFXLEdBQUc7RUFDaEJ0aUMsSUFBSSxFQUFFLE9BQU87RUFDYjBnQyxVQUFVLEVBQUUsYUFBYTtFQUN6QkMsU0FBUyxFQUFFQSxDQUFDTyxPQUFPLEVBQUVockIsS0FBSyxNQUFNO0lBQzVCa3BCLFdBQVcsRUFBRXFDLG1CQUFtQixDQUFDdnJCLEtBQUs7RUFDMUMsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNcXNCLGFBQWEsR0FBRztFQUNsQjtFQUNBdmlDLElBQUksRUFBRSxTQUFTO0VBQ2YwZ0MsVUFBVSxFQUFFLGVBQWU7RUFDM0JDLFNBQVMsRUFBRUEsQ0FBQ25zQixNQUFNLEVBQUUwQixLQUFLLE1BQU07SUFDM0Jzc0IsU0FBUyxFQUFFLEtBQUs7SUFDaEJwQixNQUFNLEVBQUUxQiwwREFBZ0IsQ0FBQyxDQUFDO0lBQzFCMEMsTUFBTSxFQUFFekMsMERBQWdCLENBQUNuckIsTUFBTSxFQUFFMEIsS0FBSyxDQUFDO0lBQ3ZDdkosUUFBUSxFQUFFcE4sTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDaU4sUUFBUSxHQUN4Q3BOLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ2lOLFFBQVEsQ0FBQ2lDLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FDL0M7RUFDVixDQUFDO0FBQ0wsQ0FBQztBQUNELElBQU02ekIsa0JBQWtCLEdBQUlDLElBQUksS0FBTTtFQUNsQzFpQyxJQUFJLEVBQUUsS0FBSztFQUNYMGdDLFVBQVUsRUFBRSxvQkFBb0I7RUFDaENDLFNBQVMsRUFBRUEsQ0FBQSxNQUFPO0lBQ2RnQyxjQUFjLEVBQUUsYUFBYTtJQUM3QnhCLFdBQVcsRUFBRSxHQUFHO0lBQ2hCL0IsV0FBVyxFQUFFc0Q7RUFDakIsQ0FBQztBQUNMLENBQUMsQ0FBQztBQUNGO0FBQ0EsSUFBTUUsb0JBQW9CLEdBQUk5bEIsU0FBUyxJQUFLO0VBQ3hDLElBQU1za0IsTUFBTSxHQUFHakIsY0FBYyxDQUFDcmpCLFNBQVMsQ0FBQztFQUN4QyxPQUFPQSxTQUFTLENBQUNuYSxHQUFHLENBQUVqRixJQUFJLEtBQU07SUFDNUJzQyxJQUFJLEVBQUUsSUFBSTtJQUNWMGdDLFVBQVUsRUFBRSxxQkFBcUI7SUFDakNDLFNBQVMsRUFBRUEsQ0FBQSxNQUFPO01BQ2RTLE1BQU07TUFDTjFqQztJQUNKLENBQUM7RUFDTCxDQUFDLENBQUMsQ0FBQztBQUNQLENBQUM7QUFDRCxJQUFNbWxDLGtCQUFrQixHQUFJQyxVQUFVLElBQUtBLFVBQVUsQ0FBQ2hnQyxNQUFNLENBQUVpZ0MsTUFBTSxJQUFLMUQsbURBQWEsQ0FBQyxDQUFDLENBQUMwRCxNQUFNLENBQUMvaUMsSUFBSSxDQUFDLENBQUM7QUFDdEcsSUFBTWdqQyxjQUFjLEdBQUdBLENBQUNsbUIsU0FBUyxFQUFFM08sYUFBYSxFQUFFdTBCLElBQUksRUFBRXI2QixZQUFZLEtBQUs7RUFDckUsSUFBTTQ2QixhQUFhLEdBQUd6RCwyREFBbUIsQ0FBQ24zQixZQUFZLENBQUM7RUFDdkQsSUFBTTY2QixTQUFTLEdBQUdELGFBQWEsQ0FBQyxJQUFJLENBQUMsR0FDL0JMLG9CQUFvQixDQUFDOWxCLFNBQVMsQ0FBQyxHQUMvQixFQUFFO0VBQ1IsSUFBTXFtQixjQUFjLEdBQUcsQ0FDbkIsQ0FBQ0YsYUFBYSxDQUFDLFFBQVEsQ0FBQyxFQUFFZCxZQUFZLENBQUNybEIsU0FBUyxDQUFDLENBQUMsRUFDbEQsQ0FBQ21tQixhQUFhLENBQUMsUUFBUSxDQUFDLEVBQUVwQixZQUFZLENBQUMsRUFDdkMsQ0FBQ29CLGFBQWEsQ0FBQyxZQUFZLENBQUMsRUFBRWxCLGdCQUFnQixDQUFDLEVBQy9DLENBQUNrQixhQUFhLENBQUMsS0FBSyxDQUFDLEVBQUV4QyxjQUFjLENBQUN0eUIsYUFBYSxDQUFDLENBQUMsRUFDckQsQ0FBQzgwQixhQUFhLENBQUMsS0FBSyxDQUFDLEVBQUVmLFdBQVcsQ0FBQyxFQUNuQyxDQUFDZSxhQUFhLENBQUMsVUFBVSxDQUFDLEVBQUV0QixjQUFjLENBQUM3a0IsU0FBUyxDQUFDLENBQUMsRUFDdEQsQ0FBQ21tQixhQUFhLENBQUMsT0FBTyxDQUFDLEVBQUVoQyxXQUFXLENBQUM5eUIsYUFBYSxDQUFDLENBQUMsRUFDcEQsQ0FBQzgwQixhQUFhLENBQUMsS0FBSyxDQUFDLEVBQUVyQyxXQUFXLENBQUN6eUIsYUFBYSxDQUFDLENBQUMsRUFDbEQsQ0FBQzgwQixhQUFhLENBQUMsT0FBTyxDQUFDLEVBQUVYLFdBQVcsQ0FBQyxFQUNyQyxDQUFDVyxhQUFhLENBQUMsU0FBUyxDQUFDLEVBQUVWLGFBQWEsQ0FBQyxFQUN6QyxDQUFDVSxhQUFhLENBQUMsS0FBSyxDQUFDLEVBQUVSLGtCQUFrQixDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUNuRDtFQUNELElBQU1VLFlBQVksR0FBR0QsY0FBYyxDQUM5QnJnQyxNQUFNLENBQUM5SSxJQUFBO0lBQUEsSUFBQyxDQUFDaXBDLGFBQWEsQ0FBQyxHQUFBanBDLElBQUE7SUFBQSxPQUFLdW1DLFVBQVUsQ0FBQzBDLGFBQWEsQ0FBQztFQUFBLEVBQUMsQ0FDdER0Z0MsR0FBRyxDQUFDOEMsS0FBQTtJQUFBLElBQUMsR0FBR3M5QixNQUFNLENBQUMsR0FBQXQ5QixLQUFBO0lBQUEsT0FBS3M5QixNQUFNO0VBQUEsRUFBQztFQUNoQyxJQUFNRCxVQUFVLEdBQUcsQ0FBQyxHQUFHSSxTQUFTLEVBQUUsR0FBR0UsWUFBWSxDQUFDO0VBQ2xELE9BQU85QyxVQUFVLENBQUMsQ0FBQyxHQUFHdUMsa0JBQWtCLENBQUNDLFVBQVUsQ0FBQyxHQUFHQSxVQUFVO0FBQ3JFLENBQUM7QUFDTSxJQUFNTyxJQUFJLEdBQUdBLENBQUM3dUIsTUFBTSxFQUFFc0ksU0FBUyxFQUFFM08sYUFBYSxFQUFFdTBCLElBQUksRUFBRXI2QixZQUFZLEtBQUsyNkIsY0FBYyxDQUFDbG1CLFNBQVMsRUFBRTNPLGFBQWEsRUFBRXUwQixJQUFJLEVBQUVyNkIsWUFBWSxDQUFDLENBQUMxRixHQUFHLENBQUVvZ0MsTUFBTSxLQUFNO0VBQ3hKQSxNQUFNLEVBQUVBLE1BQU0sQ0FBQy9pQyxJQUFJO0VBQ25Cc2pDLE1BQU0sRUFBRVAsTUFBTSxDQUFDcEMsU0FBUyxDQUFDbnNCLE1BQU0sRUFBRXNJLFNBQVM7QUFDOUMsQ0FBQyxDQUFDLENBQUM7QUFDSSxJQUFNMWUsQ0FBQyxHQUFHO0VBQ2I0aEMsd0JBQXdCO0VBQ3hCSSxtQkFBbUI7RUFDbkJOLGlCQUFpQjtFQUNqQjhDLG9CQUFvQjtFQUNwQjVCO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ2xia0c7QUFDNkY7QUFDekwsSUFBTXJCLGdCQUFnQixHQUFHQSxDQUFDbnJCLE1BQU0sRUFBRTBCLEtBQUssS0FBSztFQUMvQyxRQUFRc29CLHdEQUFnQixDQUFDLENBQUM7SUFDdEIsS0FBSyxHQUFHO01BQ0osSUFBSUQseURBQWlCLENBQUNyb0IsS0FBSyxDQUFDLElBQUlzdEIsa0RBQVUsQ0FBQ3R0QixLQUFLLENBQUMsRUFBRTtRQUMvQyxJQUFJOVYsK0VBQU0sQ0FBQyxDQUFDLEVBQUU7VUFDVixPQUFPLE9BQU87UUFDbEIsQ0FBQyxNQUNJLElBQUlPLGdGQUFPLENBQUMsQ0FBQyxFQUFFO1VBQ2hCLE9BQU8sT0FBTztRQUNsQixDQUFDLE1BQ0ksSUFBSUYsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7VUFDbkIsT0FBTyxPQUFPO1FBQ2xCLENBQUMsTUFDSSxJQUFJQyxtRkFBVSxDQUFDLENBQUMsRUFBRTtVQUNuQixPQUFPLE9BQU87UUFDbEI7TUFDSjtNQUNBO01BQ0EsSUFBSTA5QixzRUFBOEIsQ0FBQ2xvQixLQUFLLENBQUMsSUFDckMxQixNQUFNLEtBQUssdUJBQXVCLEVBQUU7UUFDcEMsSUFBSXBVLCtFQUFNLENBQUMsQ0FBQyxFQUFFO1VBQ1YsT0FBTyxPQUFPO1FBQ2xCLENBQUMsTUFDSSxJQUFJTyxnRkFBTyxDQUFDLENBQUMsRUFBRTtVQUNoQixPQUFPLE9BQU87UUFDbEIsQ0FBQyxNQUNJLElBQUlGLG1GQUFVLENBQUMsQ0FBQyxFQUFFO1VBQ25CLE9BQU8sT0FBTztRQUNsQixDQUFDLE1BQ0ksSUFBSUMsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7VUFDbkIsT0FBTyxPQUFPO1FBQ2xCO01BQ0o7TUFDQTtNQUNBLElBQUk0K0IseURBQWlCLENBQUNwcEIsS0FBSyxDQUFDLElBQUkxQixNQUFNLENBQUNsVyxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7UUFDOUQsSUFBSThCLCtFQUFNLENBQUMsQ0FBQyxFQUFFO1VBQ1YsT0FBTyxPQUFPO1FBQ2xCLENBQUMsTUFDSSxJQUFJTyxnRkFBTyxDQUFDLENBQUMsRUFBRTtVQUNoQixPQUFPLE9BQU87UUFDbEIsQ0FBQyxNQUNJLElBQUlGLG1GQUFVLENBQUMsQ0FBQyxFQUFFO1VBQ25CLE9BQU8sT0FBTztRQUNsQixDQUFDLE1BQ0ksSUFBSUMsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7VUFDbkIsT0FBTyxPQUFPO1FBQ2xCO01BQ0o7TUFDQTtJQUNKLEtBQUssR0FBRztNQUNKLElBQUk0OUIsbURBQVcsQ0FBQ3BvQixLQUFLLENBQUMsSUFBSXF0QixvRUFBNEIsQ0FBQ3J0QixLQUFLLENBQUMsRUFBRTtRQUMzRCxJQUFJOVYsK0VBQU0sQ0FBQyxDQUFDLEVBQUU7VUFDVixPQUFPLE9BQU87UUFDbEIsQ0FBQyxNQUNJLElBQUlPLGdGQUFPLENBQUMsQ0FBQyxFQUFFO1VBQ2hCLE9BQU8sT0FBTztRQUNsQixDQUFDLE1BQ0ksSUFBSUYsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7VUFDbkIsT0FBTyxPQUFPO1FBQ2xCLENBQUMsTUFDSSxJQUFJQyxtRkFBVSxDQUFDLENBQUMsRUFBRTtVQUNuQixPQUFPLE9BQU87UUFDbEI7TUFDSjtNQUNBLElBQUkyOUIsNERBQW9CLENBQUNub0IsS0FBSyxDQUFDLEVBQUU7UUFDN0IsSUFBSXZWLGdGQUFPLENBQUMsQ0FBQyxFQUFFO1VBQ1gsT0FBTyxPQUFPO1FBQ2xCLENBQUMsTUFDSSxJQUFJRixtRkFBVSxDQUFDLENBQUMsRUFBRTtVQUNuQixPQUFPLE9BQU87UUFDbEIsQ0FBQyxNQUNJLElBQUlDLG1GQUFVLENBQUMsQ0FBQyxFQUFFO1VBQ25CLE9BQU8sT0FBTztRQUNsQjtNQUNKO01BQ0E7RUFDUjtFQUNBLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQztBQUNNLElBQU1nL0IsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTTtFQUNsQyxRQUFRbEIsd0RBQWdCLENBQUMsQ0FBQztJQUN0QixLQUFLLEdBQUc7TUFDSixJQUFJcCtCLCtFQUFNLENBQUMsQ0FBQyxFQUFFO1FBQ1YsT0FBTyxNQUFNO01BQ2pCLENBQUMsTUFDSSxJQUFJTyxnRkFBTyxDQUFDLENBQUMsRUFBRTtRQUNoQixPQUFPLE1BQU07TUFDakIsQ0FBQyxNQUNJLElBQUlGLG1GQUFVLENBQUMsQ0FBQyxFQUFFO1FBQ25CLE9BQU8sTUFBTTtNQUNqQixDQUFDLE1BQ0ksSUFBSUMsbUZBQVUsQ0FBQyxDQUFDLEVBQUU7UUFDbkIsT0FBTyxNQUFNO01BQ2pCO01BQ0E7SUFDSixLQUFLLEdBQUc7TUFDSixJQUFJTiwrRUFBTSxDQUFDLENBQUMsRUFBRTtRQUNWLE9BQU8sTUFBTTtNQUNqQixDQUFDLE1BQ0ksSUFBSU8sZ0ZBQU8sQ0FBQyxDQUFDLEVBQUU7UUFDaEIsT0FBTyxNQUFNO01BQ2pCLENBQUMsTUFDSSxJQUFJRixtRkFBVSxDQUFDLENBQUMsRUFBRTtRQUNuQixPQUFPLE1BQU07TUFDakIsQ0FBQyxNQUNJLElBQUlDLG1GQUFVLENBQUMsQ0FBQyxFQUFFO1FBQ25CLE9BQU8sTUFBTTtNQUNqQjtNQUNBO0VBQ1I7RUFDQSxPQUFPLENBQUMsQ0FBQztBQUNiLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqSGlFO0FBQ2tCO0FBQ2pCO0FBQ1E7QUFDRjtBQUNyQztBQUN3QjtBQUNUO0FBQ1E7QUFDUDtBQUNJO0FBQ0M7QUFDbUQ7QUFDeEU7QUFDbUM7QUFDdkUsTUFBTXFqQyxZQUFZLENBQUM7RUFNZmhxQyxXQUFXQSxDQUFDb2YsTUFBTSxFQUFFMUMsSUFBSSxFQUFFdEksYUFBYSxFQUFFOUYsWUFBWSxFQUFFO0lBQUFsTyxlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQUFBLGVBQUE7SUFDbkQsSUFBSSxDQUFDNnBDLElBQUksR0FBRzdxQixNQUFNLENBQUN4RyxFQUFFO0lBQ3JCLElBQUksQ0FBQ3N4QixVQUFVLEdBQUc7TUFBRUMsTUFBTSxFQUFFO1FBQUVodUIsS0FBSyxFQUFFTyxJQUFJLENBQUNQO01BQU07SUFBRSxDQUFDO0lBQ25ELElBQUksQ0FBQ3dzQixJQUFJLEdBQUcsSUFBSSxDQUFDeUIsWUFBWSxDQUFDaHJCLE1BQU0sRUFBRTFDLElBQUksQ0FBQztJQUMzQyxJQUFJLENBQUMydEIsUUFBUSxHQUFHO01BQ1pDLEdBQUcsRUFBRTtRQUNEM0IsSUFBSSxFQUFFLElBQUksQ0FBQ0EsSUFBSTtRQUNmdnNCLElBQUksRUFBRTtVQUNGbXVCLFFBQVEsRUFBRSxJQUFJLENBQUM1QjtRQUNuQjtNQUNKO0lBQ0osQ0FBQztJQUNELElBQUksQ0FBQ1csSUFBSSxHQUFHQSxrREFBSSxDQUFDbHFCLE1BQU0sQ0FBQ3hHLEVBQUUsRUFBRThELElBQUksQ0FBQ1AsS0FBSyxFQUFFL0gsYUFBYSxFQUFFLElBQUksQ0FBQ3UwQixJQUFJLEVBQUVyNkIsWUFBWSxDQUFDO0lBQy9FOFEsTUFBTSxDQUFDb3JCLGtCQUFrQixHQUFHOXRCLElBQUksQ0FBQ1AsS0FBSztJQUN0Q3pTLG1EQUFHLENBQUMsWUFBWSxrQkFBQXBKLE1BQUEsQ0FBa0IsSUFBSSxDQUFDMnBDLElBQUksR0FBSSxJQUFJLENBQUNYLElBQUksQ0FBQztFQUM3RDtFQUNBNW9DLE9BQU9BLENBQUEsRUFBRztJQUNOLE9BQU8sSUFBSSxDQUFDdXBDLElBQUksSUFBSSxJQUFJO0VBQzVCO0VBQ0FHLFlBQVlBLENBQUNockIsTUFBTSxFQUFFMUMsSUFBSSxFQUFFO0lBQ3ZCLElBQU1rb0IsV0FBVyxHQUFHcC9CLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzRNLE9BQU87SUFDdkQsSUFBTW1JLFdBQVcsR0FBR2xWLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQytVLFdBQVc7SUFDM0QsSUFBTTZCLFFBQVEsR0FBR0csSUFBSSxDQUFDclUsR0FBRztJQUN6Qix1QkFBQS9ILE1BQUEsQ0FBdUJza0MsV0FBVyxPQUFBdGtDLE1BQUEsQ0FBSW9hLFdBQVcsT0FBQXBhLE1BQUEsQ0FBSWljLFFBQVE7RUFDakU7QUFDSjtBQUNBLElBQU1rdUIscUJBQXFCLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUFsNUIscUJBQUE7RUFDaEMsSUFBSSxDQUFDL0wsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQzhtQixRQUFRLENBQUNrZSxlQUFlLEVBQUU7SUFDbEQsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBTUMsbUJBQW1CLEdBQUcsRUFBRSxHQUFHLEdBQUc7RUFDcEMsSUFBTUMsVUFBVSxHQUFHaC9CLElBQUksQ0FBQytELE1BQU0sQ0FBQyxDQUFDLEdBQUdnN0IsbUJBQW1CO0VBQ3RELElBQU1FLGtCQUFrQixHQUFHMS9CLE1BQU0sQ0FBQ3dSLElBQUksRUFBQXBMLHFCQUFBLEdBQUMvTCxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDMk4sS0FBSyxjQUFBOUIscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxDQUFDLENBQUMsQ0FBQyxDQUFDbk4sTUFBTSxHQUFHLENBQUM7RUFDckYsSUFBTTBtQyxrQkFBa0IsR0FBRzMvQixNQUFNLENBQUN3UixJQUFJLENBQUM4USxrRUFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQ3JwQixNQUFNLEdBQUcsQ0FBQztFQUN0RSxJQUFNMm1DLGFBQWEsR0FBR3ZsQyxNQUFNLENBQUNxRixRQUFRLENBQUNtZ0MsTUFBTSxDQUFDem1DLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQztFQUM1RSxPQUFRc21DLGtCQUFrQixJQUFJQyxrQkFBa0IsSUFBSUYsVUFBVSxJQUFJRyxhQUFhO0FBQ25GLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUUsYUFBYSxHQUFHLEdBQUc7QUFDekI7QUFDQTtBQUNBO0FBQ0EsSUFBTXZJLGFBQWEsR0FBR2wrQiw4RkFBYztBQUNwQyxJQUFJaStCLFlBQVksR0FBR3ZnQixPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0FBQ3BDLElBQUlvZ0IsV0FBVyxHQUFHLEtBQUs7QUFDdkIsSUFBTUcsVUFBVSxHQUFHQSxDQUFDbjlCLE1BQU0sRUFBRThJLFlBQVksS0FBSztFQUFBLElBQUF5ZSxxQkFBQTtFQUN6QyxJQUFJLENBQUN2bkIsTUFBTSxDQUFDeTZCLElBQUksRUFBRTtJQUNkdjJCLG1EQUFHLENBQUMsWUFBWSxFQUFFLGlDQUFpQyxDQUFDO0lBQ3BELE9BQU8sQ0FBQztFQUNaO0VBQ0E4NEIsV0FBVyxHQUFHLElBQUk7RUFDbEIsSUFBTTBJLE9BQU8sR0FBRyxDQUNaO0lBQ0lqbEMsSUFBSSxFQUFFLFVBQVU7SUFDaEJ0QixPQUFPLEVBQUU7TUFDTGtKLElBQUksRUFBRSxRQUFRO01BQ2Q1SCxJQUFJLEVBQUUsU0FBUztNQUNma2xDLE9BQU8sRUFBRTtJQUNiO0VBQ0osQ0FBQyxDQUNKO0VBQ0QsSUFBSXA3Qiw2REFBYSxDQUFDLEtBQUssRUFBRXpCLFlBQVksQ0FBQyxFQUFFO0lBQ3BDNDhCLE9BQU8sQ0FBQ3hxQixJQUFJLENBQUM7TUFDVHphLElBQUksRUFBRSxPQUFPO01BQ2JzakMsTUFBTSxFQUFFO1FBQ0o2QixPQUFPLEVBQUU7TUFDYixDQUFDO01BQ0R6bUMsT0FBTyxFQUFFO1FBQ0xrSixJQUFJLEVBQUUsT0FBTztRQUNiNUgsSUFBSSxFQUFFLE9BQU87UUFDYmtsQyxPQUFPLEVBQUUsRUFBRTtRQUNYRSxnQkFBZ0IsRUFBRTtNQUN0QjtJQUNKLENBQUMsQ0FBQztFQUNOO0VBQ0EsSUFBTUMsUUFBUSxHQUFHMUIscURBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxHQUN6QztJQUNFMkIsY0FBYyxFQUFFLENBQUM7SUFBRTtJQUNuQkMsY0FBYyxFQUFFO01BQ1p6a0IsR0FBRyxFQUFFO1FBQ0RvWixPQUFPLEVBQUUsR0FBRztRQUFFO1FBQ2RwM0IsTUFBTSxFQUFFO01BQ1o7SUFDSixDQUFDO0lBQ0RtaUM7RUFDSixDQUFDLEdBQ0M7SUFBRU8sV0FBVyxFQUFFO0VBQU0sQ0FBQztFQUM1QixJQUFNQyxpQkFBaUIsR0FBR0EsQ0FBQSxLQUFNO0lBQzVCLFFBQVFwOUIsWUFBWSxDQUFDcUosU0FBUztNQUMxQjtNQUNBLEtBQUssS0FBSztRQUNOLE9BQU87VUFDSGcwQixHQUFHLEVBQUU7WUFDREMsTUFBTSxFQUFFLEtBQUs7WUFDYjlwQixPQUFPLEVBQUU7VUFDYjtRQUNKLENBQUM7TUFDTDtNQUNBLEtBQUssT0FBTztRQUNSLE9BQU87VUFDSCtwQixHQUFHLEVBQUU7WUFDREQsTUFBTSxFQUFFLEtBQUs7WUFDYjlwQixPQUFPLEVBQUU7VUFDYjtRQUNKLENBQUM7TUFDTDtNQUNBLEtBQUssT0FBTztNQUNaO1FBQ0ksT0FBTztVQUNIZ3FCLElBQUksRUFBRTtZQUNGRixNQUFNLEVBQUUsS0FBSztZQUNiOXBCLE9BQU8sRUFBRSxHQUFHO1lBQ1ppcUIsZ0JBQWdCLEVBQUU7VUFDdEI7UUFDSixDQUFDO0lBQ1Q7RUFDSixDQUFDO0VBQ0Q7QUFDSjtBQUNBO0FBQ0E7RUFDSSxJQUFNN0MsYUFBYSxHQUFHekQsNERBQW1CLENBQUNuM0IsWUFBWSxDQUFDO0VBQ3ZELElBQU0wOUIsVUFBVSxHQUFHN2dDLE1BQU0sQ0FBQzhnQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU7SUFDakN2SixhQUFhO0lBQ2J1SSxhQUFhO0lBQ2JsQixnQkFBZ0I7SUFDaEJ1QjtFQUNKLENBQUMsQ0FBQztFQUNGLElBQU1ZLGFBQWEsR0FBRzFtQyxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNpTixRQUFRLENBQUNpQyxLQUFLLENBQUMsR0FBRyxDQUFDO0VBQ3JFbTNCLFVBQVUsQ0FBQzVMLEtBQUssR0FBRztJQUNmOEYsSUFBSSxFQUFFO01BQ0ZvRSxHQUFHLEVBQUU7UUFDRGx1QixJQUFJLEVBQUU7VUFDRnhKLFFBQVEsRUFBRXM1QjtRQUNkO01BQ0o7SUFDSjtFQUNKLENBQUM7RUFDRDFtQyxNQUFNLENBQUN5NkIsSUFBSSxDQUFDa00sY0FBYyxHQUFHLENBQUMsQ0FBQztFQUMvQixJQUFJdkMscURBQVksQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFO0lBQ25Db0MsVUFBVSxDQUFDTixpQkFBaUIsR0FBR0EsaUJBQWlCLENBQUMsQ0FBQztFQUN0RDtFQUNBLElBQUk3QiwrREFBc0IsQ0FBQ3Y3QixZQUFZLENBQUMsRUFBRTtJQUN0QyxJQUFNODlCLGlCQUFpQixHQUFHLENBQUMsS0FBSyxFQUFFLElBQUksRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLFFBQVEsQ0FBQyxDQUNqRXJqQyxNQUFNLENBQUNtZ0MsYUFBYTtJQUNyQjtJQUFBLENBQ0N0Z0MsR0FBRyxDQUFFb2dDLE1BQU0sSUFBTUEsTUFBTSxLQUFLLEtBQUssR0FBRyxVQUFVLEdBQUdBLE1BQU8sQ0FBQztJQUM5RGdELFVBQVUsQ0FBQ0ssWUFBWSxHQUFHO01BQ3RCQyxhQUFhLEVBQUUsQ0FDWDtRQUNJcm1DLElBQUksRUFBRSxXQUFXO1FBQ2pCc2pDLE1BQU0sRUFBQTVtQyxhQUFBO1VBQ0Y0cEMsU0FBUyxFQUFFSDtRQUFpQixHQUN4QkEsaUJBQWlCLENBQUM3bkMsUUFBUSxDQUFDLFVBQVUsQ0FBQyxHQUNwQztVQUFFaW9DLFVBQVUsRUFBRTtZQUFFck4sUUFBUUEsd0RBQUFBO1VBQUM7UUFBRSxDQUFDLEdBQzVCLENBQUMsQ0FBQztNQUVoQixDQUFDO0lBRVQsQ0FBQztFQUNMO0VBQ0EsSUFBSStKLGFBQWEsQ0FBQyxRQUFRLENBQUMsRUFBRTtJQUN6QjFqQyxNQUFNLENBQUN5NkIsSUFBSSxDQUFDa00sY0FBYyxDQUFDTSxNQUFNLEdBQUc7TUFDaENDLGNBQWMsRUFBRSxJQUFJO01BQ3BCO01BQ0FDLGlCQUFpQixFQUFFLENBQ2Y7UUFDSXRrQyxHQUFHLEVBQUUsT0FBTztRQUNacWtCLEdBQUdBLENBQUF6c0IsSUFBQSxFQUErQjtVQUFBLElBQTlCO1lBQUVDLEtBQUs7WUFBRUMsTUFBTTtZQUFFeXNDLEdBQUc7WUFBRUM7VUFBSyxDQUFDLEdBQUE1c0MsSUFBQTtVQUM1QixPQUFPNnBDLG1FQUFtQixDQUFDLFFBQVEsRUFBRTVwQyxLQUFLLEVBQUVDLE1BQU0sRUFBRXlzQyxHQUFHLEVBQUVDLElBQUksQ0FBQztRQUNsRTtNQUNKLENBQUM7SUFFVCxDQUFDO0VBQ0w7RUFDQSxJQUFJM0QsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFO0lBQ3hCO0lBQ0ExakMsTUFBTSxDQUFDeTZCLElBQUksQ0FBQ2tNLGNBQWMsQ0FBQ1csS0FBSyxHQUFHO01BQy9CSCxpQkFBaUIsRUFBRSxDQUNmO1FBQ0l0a0MsR0FBRyxFQUFFLE9BQU87UUFDWnFrQixHQUFHLEVBQUVoaEIsS0FBQSxJQUFrQztVQUFBLElBQWpDO1lBQUV4TCxLQUFLO1lBQUVDLE1BQU07WUFBRXlzQyxHQUFHO1lBQUVDO1VBQUssQ0FBQyxHQUFBbmhDLEtBQUE7VUFDOUIsT0FBT28rQixtRUFBbUIsQ0FBQyxPQUFPLEVBQUU1cEMsS0FBSyxFQUFFQyxNQUFNLEVBQUV5c0MsR0FBRyxFQUFFQyxJQUFJLENBQUM7UUFDakU7TUFDSixDQUFDO0lBRVQsQ0FBQztFQUNMO0VBQ0EsSUFBSTNELGFBQWEsQ0FBQyxJQUFJLENBQUMsRUFBRTtJQUNyQjtJQUNBMWpDLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUNrTSxjQUFjLENBQUNZLEVBQUUsR0FBRztNQUM1QkosaUJBQWlCLEVBQUUsQ0FDZjtRQUNJdGtDLEdBQUcsRUFBRSxPQUFPO1FBQ1pxa0IsR0FBR0EsQ0FBQTNnQixLQUFBLEVBQStCO1VBQUEsSUFBOUI7WUFBRTdMLEtBQUs7WUFBRUMsTUFBTTtZQUFFeXNDLEdBQUc7WUFBRUM7VUFBSyxDQUFDLEdBQUE5Z0MsS0FBQTtVQUM1QixPQUFPKzlCLG1FQUFtQixDQUFDLElBQUksRUFBRTVwQyxLQUFLLEVBQUVDLE1BQU0sRUFBRXlzQyxHQUFHLEVBQUVDLElBQUksQ0FBQztRQUM5RDtNQUNKLENBQUM7SUFFVCxDQUFDO0VBQ0w7RUFDQSxJQUFJcEMscUJBQXFCLENBQUMsQ0FBQyxLQUFBMWQscUJBQUEsR0FBSXZuQixNQUFNLENBQUNDLFFBQVEsQ0FBQ3lOLEtBQUssY0FBQTZaLHFCQUFBLGVBQXJCQSxxQkFBQSxDQUF1QnhkLFVBQVUsRUFBRTtJQUM5RC9KLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUMrTSxlQUFlLENBQUMsQ0FDeEI7TUFDSUMsUUFBUSxFQUFFLElBQUk7TUFDZDdWLE9BQU8sRUFBRTtRQUNMemlCLEdBQUcsRUFBRW5QLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzZFLEtBQUssSUFDbENoRixNQUFNLENBQUNxRixRQUFRLENBQUNDLFFBQVEsQ0FBQ3ZHLFFBQVEsQ0FBQyxXQUFXLENBQUMsMkhBRVU7UUFDNUR1VixFQUFFLEVBQUV0VSxNQUFNLENBQUNDLFFBQVEsQ0FBQ3lOLEtBQUssQ0FBQzNEO01BQzlCO0lBQ0osQ0FBQyxDQUNKLENBQUM7RUFDTjtFQUNBLElBQUkyNUIsYUFBYSxDQUFDLEtBQUssQ0FBQyxFQUFFO0lBQ3RCMWpDLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUNrTSxjQUFjLENBQUNlLEdBQUcsR0FBRztNQUM3QlAsaUJBQWlCLEVBQUUsQ0FDZjtRQUNJdGtDLEdBQUcsRUFBRSxhQUFhO1FBQ2xCcWtCLEdBQUdBLENBQUMwVyxXQUFXLEVBQUU7VUFBQSxJQUFBK0oscUJBQUEsRUFBQUMsc0JBQUE7VUFDYjtVQUNBLFFBQUFELHFCQUFBLElBQUFDLHNCQUFBLEdBQU9oSyxXQUFXLENBQUNpSyxRQUFRLGNBQUFELHNCQUFBLHVCQUFwQkEsc0JBQUEsQ0FBc0JFLGFBQWEsY0FBQUgscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxFQUFFO1FBQ3BEO01BQ0osQ0FBQyxDQUNKO01BQ0RJLGdCQUFnQixFQUFHQyxNQUFNLElBQUs7UUFDMUIsT0FBT0EsTUFBTSxHQUFHLElBQUk7TUFDeEI7SUFDSixDQUFDO0VBQ0w7RUFDQSxJQUFJdEUsYUFBYSxDQUFDLE9BQU8sQ0FBQyxFQUFFO0lBQ3hCMWpDLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUNrTSxjQUFjLENBQUNzQixLQUFLLEdBQUc7TUFDL0JmLGNBQWMsRUFBRTtJQUNwQixDQUFDO0VBQ0w7RUFDQSxJQUFJeEQsYUFBYSxDQUFDLFNBQVMsQ0FBQyxFQUFFO0lBQzFCMWpDLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUNrTSxjQUFjLENBQUN1QixPQUFPLEdBQUc7TUFDakNoQixjQUFjLEVBQUU7SUFDcEIsQ0FBQztJQUNEbG5DLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUNDLGVBQWUsQ0FBQztNQUN4QkMsT0FBTyxFQUFFLENBQUMsU0FBUyxDQUFDO01BQ3BCejZCLE1BQU0sRUFBRTtRQUNKMDZCLEtBQUssRUFBRTtVQUNIQyxJQUFJLEVBQUU7WUFDRmlLLEdBQUcsRUFBRTtjQUNEbHVCLElBQUksRUFBRTtnQkFDRnBFLFNBQVMsRUFBRTVPLHlGQUFvQixDQUFDO2NBQ3BDO1lBQ0o7VUFDSjtRQUNKO01BQ0o7SUFDSixDQUFDLENBQUM7RUFDTjtFQUNBNUQsTUFBTSxDQUFDeTZCLElBQUksQ0FBQzBOLFNBQVMsQ0FBQzNCLFVBQVUsQ0FBQztFQUNqQztFQUNBeG1DLE1BQU0sQ0FBQ3k2QixJQUFJLENBQUMyTixPQUFPLENBQUMsUUFBUSxFQUFHeHhCLElBQUksSUFBSztJQUNwQyxJQUFNO01BQUVsYyxLQUFLO01BQUVDLE1BQU07TUFBRTB0QztJQUFXLENBQUMsR0FBR3p4QixJQUFJO0lBQzFDLElBQUksQ0FBQ2xjLEtBQUssSUFBSSxDQUFDQyxNQUFNLElBQUksQ0FBQzB0QyxVQUFVLEVBQUU7TUFDbEM7SUFDSjtJQUNBLElBQU1scUMsSUFBSSxHQUFHN0MsZ0ZBQVksQ0FBQ1osS0FBSyxFQUFFQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzFDLElBQU1pZixNQUFNLEdBQUdpRixxRUFBYSxDQUFDd3BCLFVBQVUsQ0FBQztJQUN4QyxJQUFJLENBQUN6dUIsTUFBTSxFQUFFO01BQ1Q7SUFDSjtJQUNBQSxNQUFNLENBQUN6YixJQUFJLEdBQUdBLElBQUk7SUFDbEI7QUFDUjtBQUNBO0FBQ0E7SUFDUXliLE1BQU0sQ0FBQzB1QixhQUFhLEdBQUcsSUFBSTtFQUMvQixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsSUFBTUMsZUFBZSxHQUFHQSxDQUFDbEssT0FBTyxFQUFFejJCLFVBQVUsS0FBSyxJQUFJOFUsT0FBTyxDQUFFRSxPQUFPLElBQUs7RUFBQSxJQUFBNHJCLFlBQUE7RUFDdEUsQ0FBQUEsWUFBQSxHQUFBeG9DLE1BQU0sQ0FBQ3k2QixJQUFJLGNBQUErTixZQUFBLGVBQVhBLFlBQUEsQ0FBYUMsdUJBQXVCLENBQUNwSyxPQUFPLENBQUNqN0IsR0FBRyxDQUFFc2xDLENBQUMsSUFBS0EsQ0FBQyxDQUFDakUsSUFBSSxDQUFDLENBQUNsaEMsTUFBTSxDQUFDckUsb0RBQVEsQ0FBQyxDQUFDO0VBQ2pGMGQsT0FBTyxDQUFDLENBQUM7RUFDVHloQixPQUFPLENBQUN2akIsT0FBTyxDQUFFUixNQUFNLElBQUs7SUFDeEIsSUFBSXBiLHdEQUFRLENBQUNvYixNQUFNLENBQUNtcUIsSUFBSSxDQUFDLEVBQUU7TUFDdkI3OEIsVUFBVSxDQUFDOFQsSUFBSSxDQUFDLFdBQVcsRUFBRTJFLDZEQUFvQixDQUFDL0YsTUFBTSxDQUFDbXFCLElBQUksQ0FBQyxDQUFDO0lBQ25FO0VBQ0osQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDO0FBQ0Y7QUFDQTtBQUNBLElBQU10bEIsV0FBVztFQUFBLElBQUE3WCxLQUFBLEdBQUF1QixpQkFBQSxDQUFHLFdBQU93WSxPQUFPLEVBQUU4YyxXQUFXLEVBQUs7SUFDaEQsSUFBSSxDQUFDbkIsV0FBVyxFQUFFO01BQ2QsT0FBT0MsWUFBWTtJQUN2QjtJQUNBLElBQUksQ0FBQ2o5QixNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDOG1CLFFBQVEsQ0FBQzJoQixtQkFBbUIsRUFBRTtNQUN0RCxPQUFPMUwsWUFBWTtJQUN2QjtJQUNBLElBQU1vQixPQUFPLFNBQVNsNkIseURBQVMsQ0FBQyxDQUFDLENBQzVCMlgsSUFBSTtNQUFBLElBQUFsVCxLQUFBLEdBQUFDLGlCQUFBLENBQUMsV0FBT0MsWUFBWSxFQUFLO1FBQzlCO1FBQ0EsSUFBTW9ELFVBQVUsU0FBU2c0Qiw4REFBYyxDQUFDLENBQUM7UUFDekMsSUFBTXQxQixhQUFhLEdBQUd1MUIsa0VBQWdCLENBQUNyN0IsWUFBWSxFQUFFb0QsVUFBVSxDQUFDO1FBQ2hFLE9BQU8wd0IscURBQU8sQ0FBQ3ZiLE9BQU8sQ0FBQ2plLEdBQUcsQ0FBRXdXLE1BQU0sSUFBS2lqQixzRUFBdUIsQ0FBQ2pqQixNQUFNLEVBQUV1a0IsV0FBVyxDQUFDLENBQzlFLzZCLEdBQUcsQ0FBRThULElBQUksSUFBSyxJQUFJc3RCLFlBQVksQ0FBQzVxQixNQUFNLEVBQUUxQyxJQUFJLEVBQUV0SSxhQUFhLEVBQUU5RixZQUFZLENBQUMsQ0FBQyxDQUMxRXZGLE1BQU0sQ0FBRStXLE1BQU0sSUFBSyxDQUFDQSxNQUFNLENBQUNwZixPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUNoRCxDQUFDO01BQUEsaUJBQUEwbUIsR0FBQTtRQUFBLE9BQUFoWixLQUFBLENBQUFRLEtBQUEsT0FBQTFKLFNBQUE7TUFBQTtJQUFBLElBQUMsQ0FDRzhnQixLQUFLLENBQUVyWSxDQUFDLElBQUs7TUFDZDtNQUNBakUsbURBQUcsQ0FBQyxZQUFZLEVBQUUsb0NBQW9DLEVBQUVpRSxDQUFDLENBQUM7TUFDMUQsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0lBQ0YsSUFBTVAsVUFBVSxHQUFHeEQsNkVBQVUsQ0FBQzdELEdBQUcsQ0FBQyxDQUFDO0lBQ25DMDhCLFlBQVksR0FBR0EsWUFBWSxDQUFDbmhCLElBQUksQ0FBQyxNQUFNLElBQUlZLE9BQU8sQ0FBRUUsT0FBTyxJQUFLO01BQUEsSUFBQWdzQixhQUFBO01BQzVEdkssT0FBTyxDQUFDdmpCLE9BQU8sQ0FBRVIsTUFBTSxJQUFLO1FBQ3hCLElBQUlwYix3REFBUSxDQUFDb2IsTUFBTSxDQUFDbXFCLElBQUksQ0FBQyxFQUFFO1VBQ3ZCNzhCLFVBQVUsQ0FBQzhULElBQUksQ0FBQyxhQUFhLEVBQUUyRSw2REFBb0IsQ0FBQy9GLE1BQU0sQ0FBQ21xQixJQUFJLENBQUMsQ0FBQztRQUNyRTtNQUNKLENBQUMsQ0FBQztNQUNGLENBQUFtRSxhQUFBLEdBQUE1b0MsTUFBTSxDQUFDeTZCLElBQUksY0FBQW1PLGFBQUEsZUFBWEEsYUFBQSxDQUFhQyxHQUFHLENBQUMzdEIsSUFBSSxDQUFDLE1BQU07UUFBQSxJQUFBNHRCLGFBQUE7UUFDeEIsQ0FBQUEsYUFBQSxHQUFBOW9DLE1BQU0sQ0FBQ3k2QixJQUFJLGNBQUFxTyxhQUFBLGVBQVhBLGFBQUEsQ0FBYTNwQixXQUFXLENBQUM7VUFDckJrZixPQUFPO1VBQ1BrSyxlQUFlLEVBQUVBLENBQUEsS0FBTSxLQUFLQSxlQUFlLENBQUNsSyxPQUFPLEVBQUV6MkIsVUFBVSxDQUFDLENBQUNrVSxJQUFJLENBQUNjLE9BQU87UUFDakYsQ0FBQyxDQUFDO01BQ04sQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDLENBQUM7SUFDSCxPQUFPcWdCLFlBQVk7RUFDdkIsQ0FBQztFQUFBLGdCQXBDSzlkLFdBQVdBLENBQUF2VixFQUFBLEVBQUFvVCxHQUFBO0lBQUEsT0FBQTFWLEtBQUEsQ0FBQThCLEtBQUEsT0FBQTFKLFNBQUE7RUFBQTtBQUFBLEdBb0NoQjtBQUNNLElBQU1xaEIsTUFBTSxHQUFHO0VBQUVvYyxVQUFVO0VBQUVoZTtBQUFZLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVWWTtBQUN4QjtBQUNrQztBQUNoRSxJQUFNb2xCLGdCQUFnQixHQUFHO0VBQzVCeUUsT0FBTyxFQUFFLENBQ0w7SUFDSUMsR0FBRyxFQUFFLEVBQUU7SUFDUEMsU0FBUyxFQUFFO0VBQ2YsQ0FBQyxFQUNEO0lBQ0lELEdBQUcsRUFBRSxFQUFFO0lBQ1BDLFNBQVMsRUFBRTtFQUNmLENBQUMsRUFDRDtJQUNJRCxHQUFHLEVBQUUsR0FBRztJQUNSQyxTQUFTLEVBQUU7RUFDZixDQUFDO0FBRVQsQ0FBQztBQUNNLElBQU1DLHNCQUFzQixHQUFHO0VBQ2xDSCxPQUFPLEVBQUUsQ0FDTDtJQUNJQyxHQUFHLEVBQUUsRUFBRTtJQUNQQyxTQUFTLEVBQUU7RUFDZixDQUFDLEVBQ0Q7SUFDSUQsR0FBRyxFQUFFLEVBQUU7SUFDUEMsU0FBUyxFQUFFO0VBQ2YsQ0FBQyxFQUNEO0lBQ0lELEdBQUcsRUFBRSxHQUFHO0lBQ1JDLFNBQVMsRUFBRTtFQUNmLENBQUM7QUFFVCxDQUFDO0FBQ00sSUFBTUUscUJBQXFCLEdBQUdBLENBQUMxdUMsS0FBSyxFQUFFQyxNQUFNLEtBQUs7RUFDcEQsSUFBTTB1QyxVQUFVLEdBQUcsQ0FBQzN1QyxLQUFLLEVBQUVDLE1BQU0sQ0FBQyxDQUFDK00sSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUM1QyxJQUFJMmhDLFVBQVUsS0FBS25zQyx1RUFBTyxDQUFDcEIsVUFBVSxDQUFDakIsUUFBUSxDQUFDLENBQUMsSUFDNUN3dUMsVUFBVSxLQUFLbnNDLHVFQUFPLENBQUN6QixRQUFRLENBQUNaLFFBQVEsQ0FBQyxDQUFDLEVBQUU7SUFDNUMsT0FBTztNQUNIbXVDLE9BQU8sRUFBRSxDQUNMO1FBQ0lDLEdBQUcsRUFBRSxFQUFFO1FBQ1BDLFNBQVMsRUFBRTtNQUNmLENBQUMsRUFDRDtRQUNJRCxHQUFHLEVBQUUsRUFBRTtRQUNQQyxTQUFTLEVBQUU7TUFDZixDQUFDLEVBQ0Q7UUFDSUQsR0FBRyxFQUFFLEVBQUU7UUFDUEMsU0FBUyxFQUFFO01BQ2YsQ0FBQztJQUVULENBQUM7RUFDTDtFQUNBLElBQUlHLFVBQVUsS0FBS25zQyx1RUFBTyxDQUFDeEIsV0FBVyxDQUFDYixRQUFRLENBQUMsQ0FBQyxJQUM3Q3d1QyxVQUFVLEtBQUtuc0MsdUVBQU8sQ0FBQzFCLFNBQVMsQ0FBQ1gsUUFBUSxDQUFDLENBQUMsSUFDM0N3dUMsVUFBVSxLQUFLbnNDLHVFQUFPLENBQUN0QixHQUFHLENBQUNmLFFBQVEsQ0FBQyxDQUFDLElBQ3JDd3VDLFVBQVUsS0FBS25zQyx1RUFBTyxDQUFDZixnQkFBZ0IsQ0FBQ3RCLFFBQVEsQ0FBQyxDQUFDLElBQ2xEd3VDLFVBQVUsS0FBS25zQyx1RUFBTyxDQUFDYixlQUFlLENBQUN4QixRQUFRLENBQUMsQ0FBQyxFQUFFO0lBQ25ELE9BQU87TUFDSG11QyxPQUFPLEVBQUUsQ0FDTDtRQUNJQyxHQUFHLEVBQUUsRUFBRTtRQUNQQyxTQUFTLEVBQUU7TUFDZixDQUFDLEVBQ0Q7UUFDSUQsR0FBRyxFQUFFLEVBQUU7UUFDUEMsU0FBUyxFQUFFO01BQ2YsQ0FBQyxFQUNEO1FBQ0lELEdBQUcsRUFBRSxFQUFFO1FBQ1BDLFNBQVMsRUFBRTtNQUNmLENBQUM7SUFFVCxDQUFDO0VBQ0w7RUFDQSxPQUFPdnBDLFNBQVM7QUFDcEIsQ0FBQztBQUNNLElBQU0ycEMscUJBQXFCLEdBQUdBLENBQUM1dUMsS0FBSyxFQUFFQyxNQUFNLEtBQUs7RUFDcEQsSUFBTTB1QyxVQUFVLEdBQUcsQ0FBQzN1QyxLQUFLLEVBQUVDLE1BQU0sQ0FBQyxDQUFDK00sSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUM1QyxJQUFJMmhDLFVBQVUsS0FBS25zQyx1RUFBTyxDQUFDcEIsVUFBVSxDQUFDakIsUUFBUSxDQUFDLENBQUMsSUFDNUN3dUMsVUFBVSxLQUFLbnNDLHVFQUFPLENBQUN6QixRQUFRLENBQUNaLFFBQVEsQ0FBQyxDQUFDLEVBQUU7SUFDNUMsT0FBTztNQUNIbXVDLE9BQU8sRUFBRSxDQUNMO1FBQ0lDLEdBQUcsRUFBRSxFQUFFO1FBQ1BDLFNBQVMsRUFBRTtNQUNmLENBQUMsRUFDRDtRQUNJRCxHQUFHLEVBQUUsRUFBRTtRQUNQQyxTQUFTLEVBQUU7TUFDZixDQUFDLEVBQ0Q7UUFDSUQsR0FBRyxFQUFFLEVBQUU7UUFDUEMsU0FBUyxFQUFFO01BQ2YsQ0FBQztJQUVULENBQUM7RUFDTDtFQUNBLElBQUlHLFVBQVUsS0FBS25zQyx1RUFBTyxDQUFDeEIsV0FBVyxDQUFDYixRQUFRLENBQUMsQ0FBQyxJQUM3Q3d1QyxVQUFVLEtBQUtuc0MsdUVBQU8sQ0FBQzFCLFNBQVMsQ0FBQ1gsUUFBUSxDQUFDLENBQUMsSUFDM0N3dUMsVUFBVSxLQUFLbnNDLHVFQUFPLENBQUN0QixHQUFHLENBQUNmLFFBQVEsQ0FBQyxDQUFDLEVBQUU7SUFDdkMsT0FBTztNQUNIbXVDLE9BQU8sRUFBRSxDQUNMO1FBQ0lDLEdBQUcsRUFBRSxFQUFFO1FBQ1BDLFNBQVMsRUFBRTtNQUNmLENBQUMsRUFDRDtRQUNJRCxHQUFHLEVBQUUsRUFBRTtRQUNQQyxTQUFTLEVBQUU7TUFDZixDQUFDLEVBQ0Q7UUFDSUQsR0FBRyxFQUFFLEVBQUU7UUFDUEMsU0FBUyxFQUFFO01BQ2YsQ0FBQztJQUVULENBQUM7RUFDTDtFQUNBLE9BQU92cEMsU0FBUztBQUNwQixDQUFDO0FBQ00sSUFBTTRwQywwQkFBMEIsR0FBR0EsQ0FBQy9GLE1BQU0sRUFBRTlvQyxLQUFLLEVBQUVDLE1BQU0sS0FBSztFQUNqRSxJQUFJNm9DLE1BQU0sS0FBSyxPQUFPLEVBQUU7SUFDcEIsT0FBTzRGLHFCQUFxQixDQUFDMXVDLEtBQUssRUFBRUMsTUFBTSxDQUFDO0VBQy9DO0VBQ0EsT0FBTzJ1QyxxQkFBcUIsQ0FBQzV1QyxLQUFLLEVBQUVDLE1BQU0sQ0FBQztBQUMvQyxDQUFDO0FBQ00sSUFBTTJwQyxtQkFBbUIsR0FBR0EsQ0FBQ2QsTUFBTSxFQUFFOW9DLEtBQUssRUFBRUMsTUFBTSxFQUFFeXNDLEdBQUcsRUFBRW9DLGtCQUFrQixLQUFLO0VBQ25GLElBQU1qRixnQkFBZ0IsR0FBR2YsTUFBTSxLQUFLLFFBQVEsR0FDdEMyRixzQkFBc0IsR0FDdEJJLDBCQUEwQixDQUFDL0YsTUFBTSxFQUFFOW9DLEtBQUssRUFBRUMsTUFBTSxDQUFDO0VBQ3ZELElBQUksQ0FBQzRwQyxnQkFBZ0IsRUFBRTtJQUNuQnJnQyxtREFBRyxDQUFDLFlBQVksS0FBQXBKLE1BQUEsQ0FBSzBvQyxNQUFNLG1DQUFBMW9DLE1BQUEsQ0FBZ0NKLEtBQUssT0FBQUksTUFBQSxDQUFJSCxNQUFNLGdCQUFhLENBQUM7SUFDeEYsT0FBTzZ1QyxrQkFBa0I7RUFDN0I7RUFDQSxJQUFNQyxXQUFXLEdBQUdWLG9GQUFvQixDQUFDM0IsR0FBRyxFQUFFN0MsZ0JBQWdCLENBQUMsQ0FBQ3BtQixNQUFNO0VBQ3RFLElBQUlzckIsV0FBVyxLQUFLRCxrQkFBa0IsRUFBRTtJQUNwQ3RsQyxtREFBRyxDQUFDLFlBQVksS0FBQXBKLE1BQUEsQ0FBSzBvQyxNQUFNLDhCQUFBMW9DLE1BQUEsQ0FBMkJKLEtBQUssT0FBQUksTUFBQSxDQUFJSCxNQUFNLGlCQUFBRyxNQUFBLENBQWNzc0MsR0FBRyxzQkFBQXRzQyxNQUFBLENBQW1CMHVDLGtCQUFrQixVQUFBMXVDLE1BQUEsQ0FBTzJ1QyxXQUFXLENBQUUsQ0FBQztFQUNwSixDQUFDLE1BQ0k7SUFDRHZsQyxtREFBRyxDQUFDLFlBQVksS0FBQXBKLE1BQUEsQ0FBSzBvQyxNQUFNLDhCQUFBMW9DLE1BQUEsQ0FBMkJKLEtBQUssT0FBQUksTUFBQSxDQUFJSCxNQUFNLGlCQUFBRyxNQUFBLENBQWNzc0MsR0FBRyxzQkFBQXRzQyxNQUFBLENBQW1CMnVDLFdBQVcsTUFBRyxDQUFDO0VBQzVIO0VBQ0EsT0FBT0EsV0FBVztBQUN0QixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakowRTtBQUNWO0FBQ0s7QUFDdEUsSUFBTUUsZUFBZSxHQUFHQSxDQUFBLEtBQU07RUFDMUIsUUFBUTFLLHdEQUFnQixDQUFDLENBQUM7SUFDdEIsS0FBSyxHQUFHO01BQ0osT0FBTyxRQUFRO0lBQ25CLEtBQUssR0FBRztNQUNKLE9BQU8sUUFBUTtJQUNuQjtNQUNJLE9BQU8sU0FBUztFQUN4QjtBQUNKLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU0ySyxtQkFBbUIsR0FBRyxTQUFBQSxDQUFBO0VBQUEsSUFBQ3JzQixTQUFTLEdBQUE3ZCxTQUFBLENBQUFkLE1BQUEsUUFBQWMsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBRyxFQUFFO0VBQUEsT0FBS2pGLElBQUEsSUFBb0I7SUFBQSxJQUFuQjtNQUFFb0ksR0FBRztNQUFFOFQ7SUFBTSxDQUFDLEdBQUFsYyxJQUFBO0lBQzNEO0lBQ0E7SUFDQSxJQUFJb0ksR0FBRyxLQUFLLFFBQVEsRUFBRTtNQUNsQixPQUFPO1FBQUVBLEdBQUc7UUFBRThUO01BQU0sQ0FBQztJQUN6QjtJQUNBLElBQU1rekIsYUFBYSxHQUFHbHpCLEtBQUssQ0FBQ3BULE1BQU0sQ0FBQzJDLEtBQUE7TUFBQSxJQUFDLENBQUM0akMsT0FBTyxFQUFFQyxRQUFRLENBQUMsR0FBQTdqQyxLQUFBO01BQUEsT0FBS3FYLFNBQVMsQ0FBQzVMLElBQUksQ0FBRXdhLE1BQU0sSUFBSzJkLE9BQU8sS0FBSzNkLE1BQU0sQ0FBQ3p4QixLQUFLLElBQUlxdkMsUUFBUSxLQUFLNWQsTUFBTSxDQUFDeHhCLE1BQU0sQ0FBQztJQUFBLEVBQUM7SUFDL0ksT0FBTztNQUNIa0ksR0FBRztNQUNIOFQsS0FBSyxFQUFFa3pCO0lBQ1gsQ0FBQztFQUNMLENBQUM7QUFBQTtBQUNELElBQU1HLG1CQUFtQixHQUFHQSxDQUFDanpCLFFBQVEsRUFBRXRXLElBQUksS0FBSztFQUM1QyxJQUFJc1csUUFBUSxDQUFDcEYsSUFBSSxDQUFFOU8sR0FBRyxJQUFLQSxHQUFHLEtBQUtwQyxJQUFJLENBQUMsRUFBRTtJQUN0QyxPQUFPQSxJQUFJO0VBQ2Y7RUFDQSxJQUFJQSxJQUFJLGFBQUpBLElBQUksZUFBSkEsSUFBSSxDQUFFMUIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0lBQzFCLE9BQU8sUUFBUTtFQUNuQjtFQUNBLElBQUkwQixJQUFJLGFBQUpBLElBQUksZUFBSkEsSUFBSSxDQUFFMUIsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO0lBQ2pDLE9BQU8sZUFBZTtFQUMxQjtFQUNBLE9BQU9ZLFNBQVM7QUFDcEIsQ0FBQztBQUNELElBQU1zcUMsMkJBQTJCLEdBQUl0ckMsV0FBVyxJQUFLZ0gsTUFBTSxDQUFDd1IsSUFBSSxDQUFDeFksV0FBVyxDQUFDLENBQUM0RSxNQUFNLENBQUVWLEdBQUcsSUFBS0EsR0FBRyxLQUFLLFFBQVEsQ0FBQztBQUMvRyxJQUFNcW5DLGNBQWMsR0FBR0EsQ0FBQzdlLEVBQUUsRUFBRS9zQixVQUFVLEVBQUVLLFdBQVcsS0FBSztFQUFBLElBQUF3ckMsZ0JBQUE7RUFDcEQsSUFBTUMsU0FBUyxHQUFHSCwyQkFBMkIsQ0FBQ3RyQyxXQUFXLENBQUM7RUFDMUQsSUFBTWtFLEdBQUcsR0FBR21uQyxtQkFBbUIsQ0FBQ0ksU0FBUyxFQUFFL2UsRUFBRSxDQUFDelQsSUFBSSxDQUFDbUIsT0FBTyxDQUFDdFksSUFBSSxDQUFDO0VBQ2hFLElBQUksQ0FBQ29DLEdBQUcsRUFBRTtJQUNOLE9BQU8sRUFBRTtFQUNiO0VBQ0EsSUFBTThULEtBQUssSUFBQXd6QixnQkFBQSxHQUFHeHJDLFdBQVcsQ0FBQ2tFLEdBQUcsQ0FBQyxjQUFBc25DLGdCQUFBLHVCQUFoQkEsZ0JBQUEsQ0FBbUI3ckMsVUFBVSxDQUFDO0VBQzVDLElBQUksQ0FBQ3FZLEtBQUssSUFBSUEsS0FBSyxDQUFDL1gsTUFBTSxHQUFHLENBQUMsRUFBRTtJQUM1QixPQUFPLEVBQUU7RUFDYjtFQUNBLE9BQU8sQ0FDSDtJQUNJaUUsR0FBRztJQUNIOFQ7RUFDSixDQUFDLENBQ0o7QUFDTCxDQUFDO0FBQ0QsSUFBTTB6QixRQUFRLEdBQUdBLENBQUEsS0FBTTtFQUNuQixJQUFNO0lBQUVuMUIsV0FBVztJQUFFbWI7RUFBdUIsQ0FBQyxHQUFHcndCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUk7RUFDM0UsSUFBTWtnQyxTQUFTLEdBQUduckIsV0FBVyxLQUFLLFNBQVM7RUFDM0MsSUFBTW8xQixrQkFBa0IsR0FBR2pLLFNBQVMsSUFBSXJnQyxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDOG1CLFFBQVEsQ0FBQ3VqQixtQkFBbUI7RUFDM0YsT0FBTztJQUNIL3NDLEtBQUssRUFBRTtNQUNIRCxPQUFPLEVBQUU4eUIsc0JBQXNCLEdBQ3pCLENBQUNuekIsdUVBQU8sQ0FBQ3RCLEdBQUcsQ0FBQyxHQUNiLENBQUNzQix1RUFBTyxDQUFDekIsUUFBUSxFQUFFeUIsdUVBQU8sQ0FBQ3RCLEdBQUcsQ0FBQztNQUNyQzhCLE1BQU0sRUFBRTJ5QixzQkFBc0IsR0FDeEIsQ0FBQ256Qix1RUFBTyxDQUFDdEIsR0FBRyxDQUFDLEdBQ2IsQ0FBQ3NCLHVFQUFPLENBQUN6QixRQUFRLEVBQUV5Qix1RUFBTyxDQUFDdEIsR0FBRyxDQUFDO01BQ3JDMEIsTUFBTSxFQUFFK3lCLHNCQUFzQixHQUN4QixDQUFDbnpCLHVFQUFPLENBQUN0QixHQUFHLENBQUMsR0FDYixDQUFDc0IsdUVBQU8sQ0FBQ3pCLFFBQVEsRUFBRXlCLHVFQUFPLENBQUN0QixHQUFHO0lBQ3hDLENBQUM7SUFDRCxlQUFlLEVBQUU7TUFDYjJCLE9BQU8sRUFBRSxDQUFDTCx1RUFBTyxDQUFDMUIsU0FBUyxFQUFFMEIsdUVBQU8sQ0FBQ3hCLFdBQVcsQ0FBQztNQUNqRGdDLE1BQU0sRUFBRSxDQUFDUix1RUFBTyxDQUFDeEIsV0FBVyxDQUFDO01BQzdCNEIsTUFBTSxFQUFFLENBQUNKLHVFQUFPLENBQUN0QixHQUFHO0lBQ3hCLENBQUM7SUFDRCxlQUFlLEVBQUU7TUFDYjJCLE9BQU8sRUFBRSxDQUFDTCx1RUFBTyxDQUFDMUIsU0FBUztJQUMvQixDQUFDO0lBQ0Q2QixNQUFNLEVBQUU7TUFDSkUsT0FBTyxFQUFFOGlDLFNBQVMsR0FDWixDQUFDbmpDLHVFQUFPLENBQUNwQixVQUFVLEVBQUVvQix1RUFBTyxDQUFDekIsUUFBUSxFQUFFeUIsdUVBQU8sQ0FBQ3RCLEdBQUcsQ0FBQyxHQUNuRCxDQUFDc0IsdUVBQU8sQ0FBQ3RCLEdBQUcsQ0FBQztNQUNuQjhCLE1BQU0sRUFBRSxDQUFDUix1RUFBTyxDQUFDdEIsR0FBRyxDQUFDO01BQ3JCMEIsTUFBTSxFQUFFLENBQUNKLHVFQUFPLENBQUN0QixHQUFHO0lBQ3hCLENBQUM7SUFDRDR1QyxPQUFPLEVBQUU7TUFDTGp0QyxPQUFPLEVBQUU4aUMsU0FBUyxHQUNaLENBQUNuakMsdUVBQU8sQ0FBQ3RCLEdBQUcsRUFBRXNCLHVFQUFPLENBQUNmLGdCQUFnQixDQUFDLEdBQ3ZDLENBQUNlLHVFQUFPLENBQUN0QixHQUFHLENBQUM7TUFDbkI4QixNQUFNLEVBQUUyaUMsU0FBUyxHQUNYLENBQUNuakMsdUVBQU8sQ0FBQ3RCLEdBQUcsRUFBRXNCLHVFQUFPLENBQUNmLGdCQUFnQixDQUFDLEdBQ3ZDLENBQUNlLHVFQUFPLENBQUN0QixHQUFHLENBQUM7TUFDbkIwQixNQUFNLEVBQUUraUMsU0FBUyxHQUNYLENBQ0VuakMsdUVBQU8sQ0FBQ2IsZUFBZSxFQUN2QmEsdUVBQU8sQ0FBQ3RCLEdBQUcsRUFDWHNCLHVFQUFPLENBQUNsQixvQkFBb0IsQ0FDL0IsR0FDQyxDQUFDa0IsdUVBQU8sQ0FBQ3RCLEdBQUc7SUFDdEIsQ0FBQztJQUNENnVDLE9BQU8sRUFBRTtNQUNMbHRDLE9BQU8sRUFBRThpQyxTQUFTLEdBQ1osQ0FBQ25qQyx1RUFBTyxDQUFDcEIsVUFBVSxFQUFFb0IsdUVBQU8sQ0FBQ3pCLFFBQVEsRUFBRXlCLHVFQUFPLENBQUN0QixHQUFHLENBQUMsR0FDbkQsQ0FBQ3NCLHVFQUFPLENBQUN0QixHQUFHLENBQUM7TUFDbkI4QixNQUFNLEVBQUUsQ0FBQ1IsdUVBQU8sQ0FBQ3RCLEdBQUcsQ0FBQztNQUNyQjBCLE1BQU0sRUFBRStpQyxTQUFTLEdBQ1gsQ0FDRW5qQyx1RUFBTyxDQUFDdEIsR0FBRyxFQUNYc0IsdUVBQU8sQ0FBQ2xCLG9CQUFvQixFQUM1QmtCLHVFQUFPLENBQUNSLHFCQUFxQixDQUNoQyxHQUNDLENBQUNRLHVFQUFPLENBQUN0QixHQUFHO0lBQ3RCLENBQUM7SUFDRCtCLE9BQU8sRUFBRTtNQUNMSixPQUFPLEVBQUUrc0Msa0JBQWtCLEdBQ3JCLENBQUNwdEMsdUVBQU8sQ0FBQ3pCLFFBQVEsRUFBRXlCLHVFQUFPLENBQUN0QixHQUFHLENBQUMsR0FDL0IsQ0FBQ3NCLHVFQUFPLENBQUN0QixHQUFHLENBQUM7TUFDbkI4QixNQUFNLEVBQUU0c0Msa0JBQWtCLEdBQ3BCLENBQUNwdEMsdUVBQU8sQ0FBQ3pCLFFBQVEsRUFBRXlCLHVFQUFPLENBQUN0QixHQUFHLEVBQUVzQix1RUFBTyxDQUFDeEIsV0FBVyxDQUFDLEdBQ3BELENBQUN3Qix1RUFBTyxDQUFDdEIsR0FBRyxDQUFDO01BQ25CMEIsTUFBTSxFQUFFLENBQUNKLHVFQUFPLENBQUN0QixHQUFHO0lBQ3hCLENBQUM7SUFDRDZCLFFBQVEsRUFBRTtNQUNORixPQUFPLEVBQUUsQ0FBQ0wsdUVBQU8sQ0FBQ3BCLFVBQVUsRUFBRW9CLHVFQUFPLENBQUN0QixHQUFHLEVBQUVzQix1RUFBTyxDQUFDekIsUUFBUTtJQUMvRCxDQUFDO0lBQ0QsbUJBQW1CLEVBQUU7TUFDakI4QixPQUFPLEVBQUUsQ0FBQ0wsdUVBQU8sQ0FBQ3BCLFVBQVUsRUFBRW9CLHVFQUFPLENBQUN0QixHQUFHLEVBQUVzQix1RUFBTyxDQUFDekIsUUFBUTtJQUMvRCxDQUFDO0lBQ0RrcEMsTUFBTSxFQUFFO01BQ0o7TUFDQTtNQUNBcG5DLE9BQU8sRUFBRSxDQUNMakMsZ0ZBQVksQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQ3BCNEIsdUVBQU8sQ0FBQ3hCLFdBQVcsRUFDbkJ3Qix1RUFBTyxDQUFDbkIsT0FBTyxFQUNmVCxnRkFBWSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsRUFDdEI0Qix1RUFBTyxDQUFDMUIsU0FBUztJQUV6QixDQUFDO0lBQ0QsZUFBZSxFQUFFO01BQ2I4QixNQUFNLEVBQUVvc0MsaUVBQXlCLENBQUMsQ0FBQyxHQUM3QixDQUFDeHNDLHVFQUFPLENBQUN2QixZQUFZLEVBQUVMLGdGQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDLEdBQzdDO0lBQ1YsQ0FBQztJQUNELHlCQUF5QixFQUFFO01BQ3ZCZ0MsTUFBTSxFQUFFLENBQUNKLHVFQUFPLENBQUN2QixZQUFZO0lBQ2pDLENBQUM7SUFDRCxnQkFBZ0IsRUFBRTtNQUNkNEIsT0FBTyxFQUFFLENBQ0xMLHVFQUFPLENBQUNOLEtBQUssRUFDYk0sdUVBQU8sQ0FBQ3RCLEdBQUcsRUFDWHNCLHVFQUFPLENBQUNwQixVQUFVLEVBQ2xCb0IsdUVBQU8sQ0FBQ3pCLFFBQVE7SUFFeEIsQ0FBQztJQUNEcUIsYUFBYSxFQUFFO01BQ1hRLE1BQU0sRUFBRSxDQUFDSix1RUFBTyxDQUFDdEIsR0FBRyxDQUFDO01BQ3JCMkIsT0FBTyxFQUFFLENBQUNMLHVFQUFPLENBQUMxQixTQUFTO0lBQy9CLENBQUM7SUFDRCxvQkFBb0IsRUFBRTtNQUNsQjhCLE1BQU0sRUFBRSxDQUFDSix1RUFBTyxDQUFDdEIsR0FBRyxDQUFDO01BQ3JCMkIsT0FBTyxFQUFFLENBQUNMLHVFQUFPLENBQUMxQixTQUFTO0lBQy9CLENBQUM7SUFDRCxhQUFhLEVBQUU7TUFDWDhCLE1BQU0sRUFBRXVELCtFQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMzRCx1RUFBTyxDQUFDdEIsR0FBRyxDQUFDLEdBQUcsRUFBRTtNQUNyQzhCLE1BQU0sRUFBRW1ELCtFQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMzRCx1RUFBTyxDQUFDdEIsR0FBRyxDQUFDLEdBQUcsRUFBRTtNQUNyQzJCLE9BQU8sRUFBRXNELCtFQUFNLENBQUMsQ0FBQyxHQUFHLENBQUMzRCx1RUFBTyxDQUFDdEIsR0FBRyxDQUFDLEdBQUc7SUFDeEM7RUFDSixDQUFDO0FBQ0wsQ0FBQztBQUNNLElBQU1paEMsdUJBQXVCLEdBQUcsU0FBQUEsQ0FBQ3hSLEVBQUUsRUFBK0I7RUFBQSxJQUE3QjhTLFdBQVcsR0FBQXorQixTQUFBLENBQUFkLE1BQUEsUUFBQWMsU0FBQSxRQUFBQyxTQUFBLEdBQUFELFNBQUEsTUFBSVosQ0FBQyxJQUFLLENBQUNBLENBQUMsQ0FBQztFQUNoRSxJQUFNUixVQUFVLEdBQUdxckMsZUFBZSxDQUFDLENBQUM7RUFDcEMsSUFBTWUsa0JBQWtCLEdBQUdSLGNBQWMsQ0FBQzdlLEVBQUUsRUFBRS9zQixVQUFVLEVBQUUrckMsUUFBUSxDQUFDLENBQUMsQ0FBQztFQUNyRSxPQUFPSyxrQkFBa0IsQ0FDcEJ0bkMsR0FBRyxDQUFDd21DLG1CQUFtQixDQUFDdmUsRUFBRSxDQUFDMVUsS0FBSyxDQUFDclksVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUM5QzhFLEdBQUcsQ0FBQys2QixXQUFXLENBQUMsQ0FDaEJsckIsTUFBTSxDQUFDLENBQUNrVixHQUFHLEVBQUV3aUIsR0FBRyxLQUFLeGlCLEdBQUcsQ0FBQ3J0QixNQUFNLENBQUM2dkMsR0FBRyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pMaUU7QUFDNkM7QUFDdEQ7QUFDeEI7QUFDdUQ7QUFDakQ7QUFDdkMsSUFBTUUsY0FBYyxHQUFHLENBQUMsQ0FBQztBQUN6QixJQUFNQyxXQUFXLEdBQUdBLENBQUNoc0MsQ0FBQyxFQUFFaXNDLE1BQU0sS0FBSztFQUFBLElBQUFDLHFCQUFBO0VBQy9CLElBQU1DLEVBQUUsSUFBQUQscUJBQUEsR0FBR0gsY0FBYyxDQUFDRSxNQUFNLENBQUMsY0FBQUMscUJBQUEsY0FBQUEscUJBQUEsR0FDNUJILGNBQWMsQ0FBQ0UsTUFBTSxDQUFDLEdBQUcsSUFBSUcsTUFBTSxJQUFBcHdDLE1BQUEsQ0FBSWl3QyxNQUFNLE1BQUcsQ0FBRTtFQUN2RCxPQUFPanNDLENBQUMsQ0FBQ3lYLE9BQU8sQ0FBQzAwQixFQUFFLEVBQUUsRUFBRSxDQUFDO0FBQzVCLENBQUM7QUFDRCxJQUFNRSxjQUFjLEdBQUcsQ0FBQyxDQUFDO0FBQ3pCLElBQU1DLFdBQVcsR0FBR0EsQ0FBQ3RzQyxDQUFDLEVBQUV1c0MsTUFBTSxLQUFLO0VBQUEsSUFBQUMscUJBQUE7RUFDL0IsSUFBTUwsRUFBRSxJQUFBSyxxQkFBQSxHQUFHSCxjQUFjLENBQUNFLE1BQU0sQ0FBQyxjQUFBQyxxQkFBQSxjQUFBQSxxQkFBQSxHQUM1QkgsY0FBYyxDQUFDRSxNQUFNLENBQUMsR0FBRyxJQUFJSCxNQUFNLEtBQUFwd0MsTUFBQSxDQUFLdXdDLE1BQU0sQ0FBRSxDQUFFO0VBQ3ZELE9BQU92c0MsQ0FBQyxDQUFDeVgsT0FBTyxDQUFDMDBCLEVBQUUsRUFBRSxFQUFFLENBQUM7QUFDNUIsQ0FBQztBQUNELElBQU03b0IsUUFBUSxHQUFHQSxDQUFDekwsS0FBSyxFQUFFeFksSUFBSSxLQUFLbVIsT0FBTyxDQUFDcUgsS0FBSyxDQUFDbEQsSUFBSSxDQUFFM1UsQ0FBQyxJQUFLQSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUtYLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLWCxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNsRyxJQUFNb3RDLDBCQUEwQixHQUFHQSxDQUFBLEtBQU07RUFDckMsSUFBTTtJQUFFcjJCLFdBQVc7SUFBRXJJO0VBQU8sQ0FBQyxHQUFHN00sTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSTtFQUMzRCxPQUFRK1UsV0FBVyxLQUFLLFNBQVMsSUFDN0JBLFdBQVcsS0FBSyxhQUFhLElBQzdCckksTUFBTSxDQUFDc1UsVUFBVSxDQUFDLFdBQVcsQ0FBQztBQUN0QyxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1xcUIsaUJBQWlCLEdBQUlDLENBQUMsSUFBSzlsQyxNQUFNLENBQUNDLE9BQU8sQ0FBQzZsQyxDQUFDLENBQUMsQ0FBQ3g0QixNQUFNLENBQUMsQ0FBQ2dVLElBQUksRUFBRXlrQixJQUFJLEtBQUs7RUFDN0UsSUFBTSxDQUFDN29DLEdBQUcsRUFBRXFrQixHQUFHLENBQUMsR0FBR3drQixJQUFJO0VBQ3ZCLElBQUksQ0FBQ3hrQixHQUFHLEVBQ0osT0FBT0QsSUFBSTtFQUNmLElBQUkvbkIsd0RBQVEsQ0FBQ2dvQixHQUFHLENBQUMsRUFBRTtJQUNmRCxJQUFJLENBQUNwa0IsR0FBRyxDQUFDLEdBQUdxa0IsR0FBRztFQUNuQjtFQUNBLElBQUkzc0IsS0FBSyxDQUFDMkksT0FBTyxDQUFDZ2tCLEdBQUcsQ0FBQyxJQUNsQkEsR0FBRyxDQUFDdG9CLE1BQU0sR0FBRyxDQUFDLElBQ2Rzb0IsR0FBRyxDQUFDdlYsSUFBSSxDQUFDckMsT0FBTyxDQUFDLElBQ2pCNFgsR0FBRyxDQUFDaGUsS0FBSyxDQUFDaEssb0RBQVEsQ0FBQyxFQUFFO0lBQ3JCK25CLElBQUksQ0FBQ3BrQixHQUFHLENBQUMsR0FBR3FrQixHQUFHLENBQUMzakIsTUFBTSxDQUFDK0wsT0FBTyxDQUFDO0VBQ25DO0VBQ0EsT0FBTzJYLElBQUk7QUFDZixDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDQyxJQUFNNUcsb0JBQW9CLEdBQUl2aEIsQ0FBQyxJQUFLc3NDLFdBQVcsQ0FBQ3RzQyxDQUFDLEVBQUUsVUFBVSxDQUFDO0FBQzlELElBQU1pZ0MsV0FBVyxHQUFJcG9CLEtBQUssSUFBS3lMLFFBQVEsQ0FBQ3pMLEtBQUssRUFBRXJiLGdGQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0FBQ3RFLElBQU0wa0MsWUFBWSxHQUFJcnBCLEtBQUssSUFBS3lMLFFBQVEsQ0FBQ3pMLEtBQUssRUFBRXJiLGdGQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZFLElBQU1zakMsbUJBQW1CLEdBQUlqb0IsS0FBSyxJQUFLeUwsUUFBUSxDQUFDekwsS0FBSyxFQUFFcmIsZ0ZBQVksQ0FBQyxHQUFHLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDN0UsSUFBTXlrQyxpQkFBaUIsR0FBSXBwQixLQUFLLElBQUt5TCxRQUFRLENBQUN6TCxLQUFLLEVBQUVyYixnRkFBWSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztBQUM1RSxJQUFNcWpDLCtCQUErQixHQUFJaG9CLEtBQUssSUFBS29wQixpQkFBaUIsQ0FBQ3BwQixLQUFLLENBQUMsSUFBSSxDQUFDaW9CLG1CQUFtQixDQUFDam9CLEtBQUssQ0FBQztBQUMxRyxJQUFNcW9CLGlCQUFpQixHQUFJcm9CLEtBQUssSUFBS29vQixXQUFXLENBQUNwb0IsS0FBSyxDQUFDLElBQUlxcEIsWUFBWSxDQUFDcnBCLEtBQUssQ0FBQztBQUM5RSxJQUFNbW9CLG9CQUFvQixHQUFJbm9CLEtBQUssSUFBS3lMLFFBQVEsQ0FBQ3pMLEtBQUssRUFBRXJiLGdGQUFZLENBQUMsR0FBRyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQzlFLElBQU11akMsOEJBQThCLEdBQUlsb0IsS0FBSyxJQUFLaW9CLG1CQUFtQixDQUFDam9CLEtBQUssQ0FBQyxJQUFJb3BCLGlCQUFpQixDQUFDcHBCLEtBQUssQ0FBQztBQUN4RyxJQUFNcXRCLDRCQUE0QixHQUFJcnRCLEtBQUssSUFBS3lMLFFBQVEsQ0FBQ3pMLEtBQUssRUFBRXJiLGdGQUFZLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZGLElBQU00akMsY0FBYyxHQUFJdm9CLEtBQUssSUFBSztFQUNyQyxJQUFNZzFCLE9BQU8sR0FBR0EsQ0FBQ0MsUUFBUSxFQUFFclMsT0FBTyxLQUFLO0lBQ25DLElBQUlxUyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUlyUyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUlxUyxRQUFRLENBQUMsQ0FBQyxDQUFDLElBQUlyUyxPQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUU7TUFDeEQsT0FBT3FTLFFBQVE7SUFDbkI7SUFDQSxPQUFPclMsT0FBTztFQUNsQixDQUFDO0VBQ0QsT0FBTzVpQixLQUFLLENBQUMvWCxNQUFNLEdBQUcsQ0FBQyxHQUFHK1gsS0FBSyxDQUFDMUQsTUFBTSxDQUFDMDRCLE9BQU8sQ0FBQyxHQUFHLElBQUk7QUFDMUQsQ0FBQztBQUNNLElBQU0xTSxnQkFBZ0IsR0FBR0EsQ0FBQSxLQUFNO0VBQ2xDLFFBQVF2USwrRUFBb0IsQ0FBQyxDQUFDO0lBQzFCLEtBQUssUUFBUTtJQUNiLEtBQUssY0FBYztJQUNuQixLQUFLLGlCQUFpQjtNQUNsQixPQUFPLEdBQUc7SUFDZCxLQUFLLFNBQVM7SUFDZCxLQUFLLFFBQVE7TUFDVCxPQUFPLEdBQUc7SUFDZCxLQUFLLFNBQVM7SUFDZCxLQUFLLFNBQVM7SUFDZCxLQUFLLE1BQU07TUFDUCxPQUFPLEdBQUc7SUFDZDtNQUNJLE9BQU8sR0FBRztFQUNsQjtBQUNKLENBQUM7QUFDTSxJQUFNbWQscUJBQXFCLEdBQUdBLENBQUNDLE9BQU8sRUFBRUMsT0FBTyxLQUFLO0VBQ3ZELElBQU05OEIsR0FBRyxHQUFHN0ksSUFBSSxDQUFDQyxJQUFJLENBQUN5bEMsT0FBTyxDQUFDO0VBQzlCLElBQU03QyxHQUFHLEdBQUc3aUMsSUFBSSxDQUFDMkwsS0FBSyxDQUFDZzZCLE9BQU8sQ0FBQztFQUMvQixPQUFPM2xDLElBQUksQ0FBQzJMLEtBQUssQ0FBQzNMLElBQUksQ0FBQytELE1BQU0sQ0FBQyxDQUFDLElBQUk4K0IsR0FBRyxHQUFHaDZCLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHQSxHQUFHO0FBQzVELENBQUM7QUFDTSxJQUFNbTFCLFlBQVksR0FBSWpELFVBQVU7RUFBQSxJQUFBcDFCLHFCQUFBO0VBQUEsUUFBQUEscUJBQUEsR0FBSy9MLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUM4bUIsUUFBUSxDQUFDbWEsVUFBVSxDQUFDLGNBQUFwMUIscUJBQUEsY0FBQUEscUJBQUEsR0FBSSxLQUFLO0FBQUE7QUFDekYsSUFBTWswQixtQkFBbUIsR0FBSW4zQixZQUFZLElBQU0wNkIsTUFBTSxJQUFLO0VBQzdELFFBQVFBLE1BQU07SUFDVixLQUFLLEtBQUs7TUFDTixPQUFRWSxZQUFZLENBQUMsZ0JBQWdCLENBQUMsS0FDakNqakMsbUZBQVUsQ0FBQyxDQUFDLElBQ1JpakMsWUFBWSxDQUFDLHFCQUFxQixDQUFDLElBQ2hDNzVCLDZEQUFhLENBQUMsT0FBTyxFQUFFekIsWUFBWSxDQUFDLElBQ3BDLENBQUM1SCxtRkFBVSxDQUFDLENBQUUsSUFDbEIsQ0FBQyxDQUFDNCtCLG1EQUFhLENBQUMsQ0FBQyxDQUFDa00sR0FBRyxDQUFDO0lBQ2xDLEtBQUssUUFBUTtNQUNULE9BQVE1SCxZQUFZLENBQUMsY0FBYyxDQUFDLElBQ2hDNzVCLDZEQUFhLENBQUMsUUFBUSxFQUFFekIsWUFBWSxDQUFDO0lBQzdDLEtBQUssSUFBSTtNQUNMLE9BQVFzN0IsWUFBWSxDQUFDLHFCQUFxQixDQUFDLElBQ3ZDNzVCLDZEQUFhLENBQUMsZUFBZSxFQUFFekIsWUFBWSxDQUFDO0lBQ3BELEtBQUssT0FBTztNQUNSLE9BQU9zN0IsWUFBWSxDQUFDLGFBQWEsQ0FBQyxJQUFJdGpDLGdGQUFPLENBQUMsQ0FBQztJQUNuRCxLQUFLLEtBQUs7TUFDTixPQUFRc2pDLFlBQVksQ0FBQyxhQUFhLENBQUMsSUFDL0I3NUIsNkRBQWEsQ0FBQyxPQUFPLEVBQUV6QixZQUFZLENBQUMsSUFDcEMsQ0FBQzVILG1GQUFVLENBQUMsQ0FBQztJQUNyQixLQUFLLE9BQU87TUFDUixPQUFRa2pDLFlBQVksQ0FBQyxhQUFhLENBQUMsSUFDL0I3NUIsNkRBQWEsQ0FBQyxPQUFPLEVBQUV6QixZQUFZLENBQUMsSUFDcEMsQ0FBQy9ILG1GQUFVLENBQUMsQ0FBQyxJQUNiLENBQUNJLG1GQUFVLENBQUMsQ0FBQztJQUNyQixLQUFLLFVBQVU7TUFDWCxPQUFRaWpDLFlBQVksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUNsQzc1Qiw2REFBYSxDQUFDLFVBQVUsRUFBRXpCLFlBQVksQ0FBQztJQUMvQyxLQUFLLFNBQVM7TUFDVixPQUFRczdCLFlBQVksQ0FBQyxlQUFlLENBQUMsSUFDakM3NUIsNkRBQWEsQ0FBQyxTQUFTLEVBQUV6QixZQUFZLENBQUM7SUFDOUMsS0FBSyxZQUFZO01BQ2IsT0FBUXM3QixZQUFZLENBQUMsa0JBQWtCLENBQUMsS0FDbkNsakMsbUZBQVUsQ0FBQyxDQUFDLElBQUlDLG1GQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ3RDLEtBQUssUUFBUTtNQUNULE9BQU9pakMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJbGpDLG1GQUFVLENBQUMsQ0FBQztJQUN2RCxLQUFLLEtBQUs7TUFDTixPQUFRa2pDLFlBQVksQ0FBQyxvQkFBb0IsQ0FBQyxJQUN0Qzc1Qiw2REFBYSxDQUFDLGNBQWMsRUFBRXpCLFlBQVksQ0FBQztJQUNuRCxLQUFLLEtBQUs7TUFDTixPQUFRczdCLFlBQVksQ0FBQyxhQUFhLENBQUMsSUFDL0I3NUIsNkRBQWEsQ0FBQyxPQUFPLEVBQUV6QixZQUFZLENBQUMsSUFDcENqSSwrRUFBTSxDQUFDLENBQUM7RUFDcEI7QUFDSixDQUFDO0FBQ00sSUFBTXdqQyxzQkFBc0IsR0FBSXY3QixZQUFZLElBQUtzN0IsWUFBWSxDQUFDLFdBQVcsQ0FBQyxJQUM3RTtBQUNBQSxZQUFZLENBQUMseUJBQXlCLENBQUMsSUFDdkM3NUIsNkRBQWEsQ0FBQyxXQUFXLEVBQUV6QixZQUFZLENBQUM7QUFDckMsSUFBTTRnQyx5QkFBeUIsR0FBR2hoQyxxREFBSSxDQUFDLE1BQU0xSSxNQUFNLENBQUNxRixRQUFRLENBQUM0Z0IsSUFBSSxDQUFDbG5CLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUM5RjZyQyw2RUFBa0IsQ0FBQztFQUNoQjM3QixHQUFHLEVBQUUsUUFBUTtFQUNiZzZCLEdBQUcsRUFBRTtBQUNULENBQUMsQ0FBQyxJQUNFLENBQUNwb0MsK0VBQU0sQ0FBQyxDQUFDLElBQ1QwcUMsMEJBQTBCLENBQUMsQ0FBQyxJQUM1QixDQUFDdnJDLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzhyQyxRQUFTLENBQUM7QUFDeEMsSUFBTS9MLGlCQUFpQixHQUFJcGhDLENBQUMsSUFBS2dzQyxXQUFXLENBQUNBLFdBQVcsQ0FBQ2hzQyxDQUFDLEVBQUUsVUFBVSxDQUFDLEVBQUUsUUFBUSxDQUFDO0FBQ2xGLElBQU1vdEMsMEJBQTBCLEdBQUlwdEMsQ0FBQyxJQUFLZ3NDLFdBQVcsQ0FBQ2hzQyxDQUFDLEVBQUUsaUJBQWlCLENBQUM7QUFDM0UsSUFBTW1sQyxVQUFVLEdBQUl0dEIsS0FBSyxJQUFLeUwsUUFBUSxDQUFDekwsS0FBSyxFQUFFcmIsZ0ZBQVksQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7QUFDckUsSUFBTTZ3QyxtQkFBbUIsR0FBR25zQyxNQUFNLENBQUNxRixRQUFRLENBQUM0Z0IsSUFBSSxDQUFDbG5CLFFBQVEsQ0FBQyxVQUFVLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BKVDtBQUNuRSxJQUFNc3RDLGFBQWE7RUFBQSxJQUFBNXhDLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsYUFBWTtJQUM5QixJQUFNO01BQUV5akMsZUFBZTtNQUFFQyxXQUFXO01BQUVDO0lBQVEsQ0FBQyxTQUFTSixpRkFBZSxDQUFDLENBQUMsQ0FBQ0ssdUJBQXVCLENBQUMsQ0FBQztJQUNuRyxJQUFJSCxlQUFlLEVBQUU7TUFDakIsT0FBTztRQUNIblQsSUFBSSxFQUFFLFVBQVU7UUFDaEJvVCxXQUFXO1FBQ1hDO01BQ0osQ0FBQztJQUNMO0lBQ0EsT0FBTztNQUNIclQsSUFBSSxFQUFFO0lBQ1YsQ0FBQztFQUNMLENBQUM7RUFBQSxnQkFaS2tULGFBQWFBLENBQUE7SUFBQSxPQUFBNXhDLElBQUEsQ0FBQTJPLEtBQUEsT0FBQTFKLFNBQUE7RUFBQTtBQUFBLEdBWWxCO0FBQ0QsSUFBTXdrQyxjQUFjLEdBQUdBLENBQUEsS0FBTWtJLGlGQUFlLENBQUMsQ0FBQyxDQUFDbGdDLFVBQVUsQ0FBQyxDQUFDO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNd2dDLGNBQWMsR0FBR0EsQ0FBQSxLQUFNTCxhQUFhLENBQUMsQ0FBQyxDQUFDdndCLElBQUksQ0FBRTZ3QixVQUFVLElBQUtBLFVBQVUsQ0FBQ3hULElBQUksS0FBSyxVQUFVLEdBQzFGd1QsVUFBVSxDQUFDSCxPQUFPLENBQUNJLE1BQU0sQ0FBQ0MsYUFBYSxHQUN2QyxJQUFJLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekJvRTtBQUM1QixDQUFDO0FBQ3BELElBQU1DLFNBQVMsR0FBRyxDQUFDLENBQUM7QUFDcEIsSUFBSUMsb0JBQW9CLEdBQUcsQ0FBQztBQUM1QixJQUFNQyxRQUFRLEdBQUc7RUFDYnZJLElBQUksRUFBRSxHQUFHO0VBQ1RwaUMsT0FBTyxFQUFFO0FBQ2IsQ0FBQztBQUNELElBQU00cUMsUUFBUSxHQUFHO0VBQ2J4SSxJQUFJLEVBQUUsR0FBRztFQUNUcGlDLE9BQU8sRUFBRTtBQUNiLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTTZxQyxxQkFBcUIsR0FBSUMsT0FBTyxJQUFLO0VBQ3ZDLElBQU1DLGNBQWMsR0FBR0QsT0FBTztFQUM5QixPQUFRQyxjQUFjLENBQUMva0MsSUFBSSxLQUFLLGVBQWUsS0FDMUMsSUFBSSxJQUFJK2tDLGNBQWMsQ0FBQ2hvQyxLQUFLLElBQUksUUFBUSxJQUFJZ29DLGNBQWMsQ0FBQ2hvQyxLQUFLLENBQUMsSUFDbEUsUUFBUSxJQUFJZ29DLGNBQWMsQ0FBQ2hvQyxLQUFLO0FBQ3hDLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNaW9DLGlCQUFpQixHQUFJRixPQUFPLEtBQU07RUFDcEMvNUIsRUFBRSxFQUFFLHNDQUFzQztFQUMxQy9LLElBQUksRUFBRSxRQUFRO0VBQ2RpbEMsUUFBUSxFQUFFSCxPQUFPLENBQUMvbkMsS0FBSyxDQUFDZ08sRUFBRTtFQUMxQjZCLE1BQU0sRUFBRWs0QixPQUFPLENBQUMvbkMsS0FBSyxDQUFDNlAsTUFBTTtFQUM1QjdQLEtBQUssRUFBRTtJQUNIekssTUFBTSxFQUFFd3lDLE9BQU8sQ0FBQy9uQyxLQUFLLENBQUN6SyxNQUFNO0lBQzVCRCxLQUFLLEVBQUV5eUMsT0FBTyxDQUFDL25DLEtBQUssQ0FBQzFLO0VBQ3pCO0FBQ0osQ0FBQyxDQUFDO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNNnlDLFNBQVMsR0FBR0EsQ0FBQ2xyQyxPQUFPLEVBQUVtckMsa0JBQWtCLEtBQUs7RUFDL0MsSUFBSW5yQyxPQUFPLENBQUM0UyxNQUFNLEVBQUU7SUFBQSxJQUFBdzRCLHFCQUFBO0lBQ2hCLElBQU1scUIsU0FBUyxHQUFHamIsUUFBUSxDQUFDbXpCLGNBQWMsWUFBQTNnQyxNQUFBLENBQVl1SCxPQUFPLENBQUM0UyxNQUFNLENBQUUsQ0FBQztJQUN0RSxRQUFBdzRCLHFCQUFBLEdBQU9scUIsU0FBUyxhQUFUQSxTQUFTLHVCQUFUQSxTQUFTLENBQUV5SSxhQUFhLENBQUMsUUFBUSxDQUFDLGNBQUF5aEIscUJBQUEsY0FBQUEscUJBQUEsR0FBSTl0QyxTQUFTO0VBQzFELENBQUMsTUFDSSxJQUFJMEMsT0FBTyxDQUFDaXJDLFFBQVEsRUFBRTtJQUN2QixJQUFNSSxFQUFFLEdBQUdwbEMsUUFBUSxDQUFDbXpCLGNBQWMsQ0FBQ3A1QixPQUFPLENBQUNpckMsUUFBUSxDQUFDO0lBQ3BELE9BQU9JLEVBQUUsWUFBWWxiLGlCQUFpQixHQUFHa2IsRUFBRSxHQUFHL3RDLFNBQVM7RUFDM0QsQ0FBQyxNQUNJLElBQUk2dEMsa0JBQWtCLEVBQUU7SUFDekIsSUFBTTVaLE9BQU8sR0FBR3RyQixRQUFRLENBQUM4cEIsZ0JBQWdCLENBQUMsUUFBUSxDQUFDO0lBQ25ELE9BQU83M0IsS0FBSyxDQUFDczVCLElBQUksQ0FBQ0QsT0FBTyxDQUFDLENBQUNuZ0IsSUFBSSxDQUFFaWYsTUFBTSxJQUFLQSxNQUFNLENBQUNFLGFBQWEsS0FBSzRhLGtCQUFrQixDQUFDO0VBQzVGO0FBQ0osQ0FBQztBQUNEO0FBQ0EsSUFBTUcsaUJBQWlCLEdBQUcsNkNBQTZDO0FBQ3ZFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxjQUFjLEdBQUlULE9BQU8sSUFBSztFQUNoQyxJQUFNQyxjQUFjLEdBQUdELE9BQU87RUFDOUIsT0FBUSxNQUFNLElBQUlDLGNBQWMsSUFDNUIsT0FBTyxJQUFJQSxjQUFjLElBQ3pCLElBQUksSUFBSUEsY0FBYyxJQUN0QkEsY0FBYyxDQUFDL2tDLElBQUksSUFBSXlrQyxTQUFTLElBQ2hDYSxpQkFBaUIsQ0FBQ2hzQyxJQUFJLENBQUN5ckMsY0FBYyxDQUFDaDZCLEVBQUUsQ0FBQztBQUNqRCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU15NkIsV0FBVyxHQUFHLFNBQUFBLENBQUNoMEIsS0FBSztFQUFBLFNBQUExUyxJQUFBLEdBQUF6SCxTQUFBLENBQUFkLE1BQUEsRUFBS2t2QyxJQUFJLE9BQUF2ekMsS0FBQSxDQUFBNE0sSUFBQSxPQUFBQSxJQUFBLFdBQUFFLElBQUEsTUFBQUEsSUFBQSxHQUFBRixJQUFBLEVBQUFFLElBQUE7SUFBSnltQyxJQUFJLENBQUF6bUMsSUFBQSxRQUFBM0gsU0FBQSxDQUFBMkgsSUFBQTtFQUFBO0VBQUEsT0FBS3ltQyxJQUFJLENBQUM3NkIsTUFBTSxDQUFDLENBQUM5SyxDQUFDLEVBQUU0bEMsR0FBRyxLQUFLO0lBQzVENWxDLENBQUMsQ0FBQzlGLE9BQU8sR0FBRzhGLENBQUMsQ0FBQzlGLE9BQU8sQ0FBQ2tVLE9BQU8sQ0FBQyxJQUFJLEVBQUV3M0IsR0FBRyxDQUFDO0lBQ3hDLE9BQU81bEMsQ0FBQztFQUNaLENBQUMsRUFBRTBSLEtBQUssQ0FBQztBQUFBO0FBQ1Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTW0wQixzQkFBc0IsR0FBSXhvQixLQUFLLElBQUs7RUFDdEMsSUFBSTtJQUNBO0lBQ0E7SUFDQSxJQUFNNU8sSUFBSSxHQUFHcFUsSUFBSSxDQUFDUyxLQUFLLENBQUN1aUIsS0FBSyxDQUFDNU8sSUFBSSxDQUFDO0lBQ25DLElBQU12VSxPQUFPLEdBQUc2cUMscUJBQXFCLENBQUN0MkIsSUFBSSxDQUFDLEdBQ3JDeTJCLGlCQUFpQixDQUFDejJCLElBQUksQ0FBQyxHQUN2QkEsSUFBSTtJQUNWLElBQUlnM0IsY0FBYyxDQUFDdnJDLE9BQU8sQ0FBQyxFQUFFO01BQ3pCLE9BQU9BLE9BQU87SUFDbEI7RUFDSixDQUFDLENBQ0QsT0FBTzB2QixFQUFFLEVBQUU7SUFDUDtFQUFBO0FBRVIsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTWtjLE9BQU8sR0FBR0EsQ0FBQzc2QixFQUFFLEVBQUU5USxNQUFNLEVBQUV1WCxLQUFLLEVBQUVpRCxNQUFNLEtBQUs7RUFDM0MxYSw2RkFBVyxDQUFDO0lBQ1JnUixFQUFFO0lBQ0Z5RyxLQUFLO0lBQ0xpRDtFQUNKLENBQUMsRUFBRXhhLE1BQU0sYUFBTkEsTUFBTSxjQUFOQSxNQUFNLEdBQUl0QyxNQUFNLENBQUM7QUFDeEIsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNa3VDLFNBQVM7RUFBQSxJQUFBenpDLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsV0FBTzJjLEtBQUssRUFBSztJQUMvQixJQUFNbmpCLE9BQU8sR0FBRzJyQyxzQkFBc0IsQ0FBQ3hvQixLQUFLLENBQUM7SUFDN0MsSUFBSSxDQUFDbmpCLE9BQU8sRUFBRTtNQUNWO0lBQ0o7SUFDQSxJQUFNNkYsUUFBUSxHQUFHNGtDLFNBQVMsQ0FBQ3pxQyxPQUFPLENBQUNnRyxJQUFJLENBQUM7SUFDeEMsSUFBSTlOLEtBQUssQ0FBQzJJLE9BQU8sQ0FBQ2dGLFFBQVEsQ0FBQyxJQUFJQSxRQUFRLENBQUN0SixNQUFNLEVBQUU7TUFDNUM7TUFDQTtNQUNBO01BQ0EsSUFBTTJkLE9BQU87TUFDYjtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7TUFDQTtNQUNBclUsUUFBUSxDQUFDK0ssTUFBTSxDQUFDLENBQUNrN0IsSUFBSSxFQUFFam1DLFFBQVEsS0FBS2ltQyxJQUFJLENBQUNyeUIsSUFBSSxDQUFFc3lCLEdBQUcsSUFBSztRQUNuRCxJQUFNQyxPQUFPLEdBQUdubUMsUUFBUSxDQUFDN0YsT0FBTyxDQUFDK0MsS0FBSyxFQUFFZ3BDLEdBQUcsRUFBRWIsU0FBUyxDQUFDbHJDLE9BQU8sRUFBRW1qQixLQUFLLENBQUNrTyxNQUFNLENBQUMsQ0FBQztRQUM5RSxPQUFPMmEsT0FBTyxLQUFLMXVDLFNBQVMsR0FBR3l1QyxHQUFHLEdBQUdDLE9BQU87TUFDaEQsQ0FBQyxDQUFDLEVBQUUzeEIsT0FBTyxDQUFDRSxPQUFPLENBQUMsQ0FBQyxDQUFDO01BQ3RCLE9BQU9MLE9BQU8sQ0FDVFQsSUFBSSxDQUFFd3lCLFFBQVEsSUFBSztRQUNwQkwsT0FBTyxDQUFDNXJDLE9BQU8sQ0FBQytRLEVBQUUsRUFBRW9TLEtBQUssQ0FBQ2tPLE1BQU0sRUFBRSxJQUFJLEVBQUU0YSxRQUFRLENBQUM7TUFDckQsQ0FBQyxDQUFDLENBQ0c5dEIsS0FBSyxDQUFFdVIsRUFBRSxJQUFLO1FBQ2Z4WSxnRUFBVyxDQUFDd1ksRUFBRSxFQUFFLFlBQVksQ0FBQztRQUM3QmtjLE9BQU8sQ0FBQzVyQyxPQUFPLENBQUMrUSxFQUFFLEVBQUVvUyxLQUFLLENBQUNrTyxNQUFNLEVBQUVtYSxXQUFXLENBQUNaLFFBQVEsRUFBRWxiLEVBQUUsQ0FBQ2wzQixRQUFRLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxDQUFDO01BQ2pGLENBQUMsQ0FBQztJQUNOLENBQUMsTUFDSSxJQUFJLE9BQU9xTixRQUFRLEtBQUssVUFBVSxFQUFFO01BQ3JDO01BQ0E7TUFDQTtNQUNBQSxRQUFRO01BQ1I7TUFDQSxDQUFDMlIsS0FBSyxFQUFFaUQsTUFBTSxLQUFLbXhCLE9BQU8sQ0FBQzVyQyxPQUFPLENBQUMrUSxFQUFFLEVBQUVvUyxLQUFLLENBQUNrTyxNQUFNLEVBQUU3WixLQUFLLEVBQUVpRCxNQUFNLENBQUMsRUFBRXphLE9BQU8sQ0FBQytDLEtBQUssRUFBRW1vQyxTQUFTLENBQUNsckMsT0FBTyxFQUFFbWpCLEtBQUssQ0FBQ2tPLE1BQU0sQ0FBQyxDQUFDO0lBQ3pILENBQUMsTUFDSTtNQUNEO01BQ0E7TUFDQXVhLE9BQU8sQ0FBQzVyQyxPQUFPLENBQUMrUSxFQUFFLEVBQUVvUyxLQUFLLENBQUNrTyxNQUFNLEVBQUVtYSxXQUFXLENBQUNiLFFBQVEsRUFBRTNxQyxPQUFPLENBQUNnRyxJQUFJLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDaEY7RUFDSixDQUFDO0VBQUEsZ0JBL0NLNmxDLFNBQVNBLENBQUF0a0MsRUFBQTtJQUFBLE9BQUFuUCxJQUFBLENBQUEyTyxLQUFBLE9BQUExSixTQUFBO0VBQUE7QUFBQSxHQStDZDtBQUNELElBQU02dUMsRUFBRSxHQUFJdnVDLE1BQU0sSUFBSztFQUNuQkEsTUFBTSxDQUFDeUksZ0JBQWdCLENBQUMsU0FBUyxFQUFHK2MsS0FBSyxJQUFLLEtBQUswb0IsU0FBUyxDQUFDMW9CLEtBQUssQ0FBQyxDQUFDO0FBQ3hFLENBQUM7QUFDRCxJQUFNZ3BCLEdBQUcsR0FBSXh1QyxNQUFNLElBQUs7RUFDcEJBLE1BQU0sQ0FBQ3FLLG1CQUFtQixDQUFDLFNBQVMsRUFBR21iLEtBQUssSUFBSyxLQUFLMG9CLFNBQVMsQ0FBQzFvQixLQUFLLENBQUMsQ0FBQztBQUMzRSxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFNaXBCLFFBQVEsR0FBR0EsQ0FBQ3BtQyxJQUFJLEVBQUVvckIsUUFBUSxFQUFFN0IsT0FBTyxLQUFLO0VBQUEsSUFBQThjLGVBQUE7RUFDakQsSUFBSTNCLG9CQUFvQixLQUFLLENBQUMsRUFBRTtJQUFBLElBQUE0QixlQUFBO0lBQzVCSixFQUFFLEVBQUFJLGVBQUEsR0FBQy9jLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFNXhCLE1BQU0sY0FBQTJ1QyxlQUFBLGNBQUFBLGVBQUEsR0FBSTN1QyxNQUFNLENBQUM7RUFDakM7RUFDQSxJQUFNNHVDLFNBQVMsSUFBQUYsZUFBQSxHQUFHNUIsU0FBUyxDQUFDemtDLElBQUksQ0FBQyxjQUFBcW1DLGVBQUEsY0FBQUEsZUFBQSxHQUFJLEVBQUU7RUFDdkMsSUFBSW4wQyxLQUFLLENBQUMySSxPQUFPLENBQUMwckMsU0FBUyxDQUFDLElBQUksQ0FBQ0EsU0FBUyxDQUFDN3ZDLFFBQVEsQ0FBQzAwQixRQUFRLENBQUMsRUFBRTtJQUMzRHFaLFNBQVMsQ0FBQ3prQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUd1bUMsU0FBUyxFQUFFbmIsUUFBUSxDQUFDO0lBQzFDc1osb0JBQW9CLElBQUksQ0FBQztFQUM3QjtBQUNKLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU04QiwwQkFBMEIsR0FBR0EsQ0FBQ3htQyxJQUFJLEVBQUVvckIsUUFBUSxFQUFFN0IsT0FBTyxLQUFLO0VBQ25FLElBQUltYixvQkFBb0IsS0FBSyxDQUFDLEVBQUU7SUFBQSxJQUFBK0IsZ0JBQUE7SUFDNUJQLEVBQUUsRUFBQU8sZ0JBQUEsR0FBQ2xkLE9BQU8sYUFBUEEsT0FBTyx1QkFBUEEsT0FBTyxDQUFFNXhCLE1BQU0sY0FBQTh1QyxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJOXVDLE1BQU0sQ0FBQztFQUNqQztFQUNBOHNDLFNBQVMsQ0FBQ3prQyxJQUFJLENBQUMsR0FBR29yQixRQUFRO0VBQzFCc1osb0JBQW9CLElBQUksQ0FBQztBQUM3QixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1nQyxVQUFVLEdBQUdBLENBQUMxbUMsSUFBSSxFQUFFb3JCLFFBQVEsRUFBRTdCLE9BQU8sS0FBSztFQUNuRCxJQUFNZ2QsU0FBUyxHQUFHOUIsU0FBUyxDQUFDemtDLElBQUksQ0FBQztFQUNqQyxJQUFJdW1DLFNBQVMsS0FBS2p2QyxTQUFTLEVBQUU7SUFDekIsTUFBTSxJQUFJdVosS0FBSyxDQUFDMjBCLFdBQVcsQ0FBQ2IsUUFBUSxFQUFFM2tDLElBQUksQ0FBQyxDQUFDaEcsT0FBTyxDQUFDO0VBQ3hELENBQUMsTUFDSSxJQUFJdXNDLFNBQVMsS0FBS25iLFFBQVEsRUFBRTtJQUM3QnFaLFNBQVMsQ0FBQ3prQyxJQUFJLENBQUMsR0FBRzFJLFNBQVM7SUFDM0JvdEMsb0JBQW9CLElBQUksQ0FBQztFQUM3QixDQUFDLE1BQ0ksSUFBSXh5QyxLQUFLLENBQUMySSxPQUFPLENBQUMwckMsU0FBUyxDQUFDLEVBQUU7SUFDL0IsSUFBSW5iLFFBQVEsS0FBSzl6QixTQUFTLEVBQUU7TUFDeEJtdEMsU0FBUyxDQUFDemtDLElBQUksQ0FBQyxHQUFHLEVBQUU7TUFDcEIwa0Msb0JBQW9CLElBQUk2QixTQUFTLENBQUNod0MsTUFBTTtJQUM1QyxDQUFDLE1BQ0k7TUFDRGt1QyxTQUFTLENBQUN6a0MsSUFBSSxDQUFDLEdBQUd1bUMsU0FBUyxDQUFDcnJDLE1BQU0sQ0FBRXlyQyxFQUFFLElBQUs7UUFDdkMsSUFBTUMsY0FBYyxHQUFHRCxFQUFFLEtBQUt2YixRQUFRO1FBQ3RDLElBQUl3YixjQUFjLEVBQUU7VUFDaEJsQyxvQkFBb0IsSUFBSSxDQUFDO1FBQzdCO1FBQ0EsT0FBTyxDQUFDa0MsY0FBYztNQUMxQixDQUFDLENBQUM7SUFDTjtFQUNKO0VBQ0EsSUFBSWxDLG9CQUFvQixLQUFLLENBQUMsRUFBRTtJQUFBLElBQUFtQyxnQkFBQTtJQUM1QlYsR0FBRyxFQUFBVSxnQkFBQSxHQUFDdGQsT0FBTyxhQUFQQSxPQUFPLHVCQUFQQSxPQUFPLENBQUU1eEIsTUFBTSxjQUFBa3ZDLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUlsdkMsTUFBTSxDQUFDO0VBQ2xDO0FBQ0osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1tbkIsSUFBSSxHQUFHQSxDQUFDeW5CLFNBQVMsRUFBRU8sbUJBQW1CLEtBQUs7RUFDcERQLFNBQVMsQ0FBQzl6QixPQUFPLENBQUVzMEIsVUFBVSxJQUFLQSxVQUFVLENBQUNYLFFBQVEsQ0FBQyxDQUFDO0VBQ3ZEVSxtQkFBbUIsQ0FBQ3IwQixPQUFPLENBQUVzMEIsVUFBVSxJQUFLQSxVQUFVLENBQUNQLDBCQUEwQixDQUFDLENBQUM7QUFDdkYsQ0FBQztBQUNNLElBQU1od0MsQ0FBQyxHQUFHO0VBQUVxdkM7QUFBVSxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVRWTtBQUM0RDtBQUM5QztBQUNmO0FBQ29EO0FBQzdGLElBQU01b0IsU0FBUyxHQUFHdGxCLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQytVLFdBQVcsS0FBSyxTQUFTO0FBQ3ZFLElBQU1xNkIseUJBQXlCLEdBQUcsUUFBUTtBQUMxQyxJQUFNQyxpQkFBaUIsR0FBSUMsS0FBSyxJQUFLO0VBQ2pDLElBQU1DLE1BQU0sR0FBQXZ5QyxhQUFBLEtBQVFzeUMsS0FBSyxDQUFFO0VBQzNCLE9BQU9DLE1BQU0sQ0FBQ0MsVUFBVTtFQUN4QixPQUFPRCxNQUFNLENBQUNFLE1BQU07RUFDcEIsT0FBT0YsTUFBTSxDQUFDRyxXQUFXO0VBQ3pCO0VBQ0EsSUFBSUgsTUFBTSxDQUFDSSxnQkFBZ0IsRUFBRTtJQUN6QkosTUFBTSxDQUFDSyxlQUFlLEdBQUdMLE1BQU0sQ0FBQ0ksZ0JBQWdCO0lBQ2hELE9BQU9KLE1BQU0sQ0FBQ0ksZ0JBQWdCO0VBQ2xDO0VBQ0EsT0FBT0osTUFBTTtBQUNqQixDQUFDO0FBQ0QsSUFBTU0saUJBQWlCLEdBQUlQLEtBQUssSUFBSzFVLHdEQUFRLENBQUMwVSxLQUFLLENBQUMsSUFBSSxpQkFBaUIsSUFBSUEsS0FBSztBQUNsRixJQUFNUSxZQUFZLEdBQUdBLENBQUN2MkIsTUFBTSxFQUFFaTJCLFVBQVUsS0FBSztFQUN6QyxJQUFJTyxnQkFBZ0IsR0FBR3gyQixNQUFNLENBQUNzUyxhQUFhLENBQUMsOEJBQThCLENBQUM7RUFDM0UsSUFBSW1rQixVQUFVLEdBQUd6MkIsTUFBTSxDQUFDc1MsYUFBYSxDQUFDLHVCQUF1QixDQUFDO0VBQzlELElBQUksQ0FBQ2trQixnQkFBZ0IsSUFBSSxDQUFDQyxVQUFVLEVBQUU7SUFDbENELGdCQUFnQixHQUFHNW5DLFFBQVEsQ0FBQzZhLGFBQWEsQ0FBQyxLQUFLLENBQUM7SUFDaERndEIsVUFBVSxHQUFHN25DLFFBQVEsQ0FBQzZhLGFBQWEsQ0FBQyxLQUFLLENBQUM7SUFDMUMrc0IsZ0JBQWdCLENBQUN0M0IsU0FBUyxDQUFDQyxHQUFHLENBQUMsNkJBQTZCLENBQUM7SUFDN0RzM0IsVUFBVSxDQUFDdjNCLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDLHNCQUFzQixDQUFDO0lBQ2hELElBQUk4MkIsVUFBVSxFQUFFO01BQ1pPLGdCQUFnQixDQUFDdDNCLFNBQVMsQ0FBQ0MsR0FBRyxpQ0FBQS9kLE1BQUEsQ0FBaUM2MEMsVUFBVSxDQUFFLENBQUM7TUFDNUVRLFVBQVUsQ0FBQ3YzQixTQUFTLENBQUNDLEdBQUcsMEJBQUEvZCxNQUFBLENBQTBCNjBDLFVBQVUsQ0FBRSxDQUFDO0lBQ25FO0lBQ0FPLGdCQUFnQixDQUFDeHNCLFdBQVcsQ0FBQ3lzQixVQUFVLENBQUM7SUFDeENELGdCQUFnQixDQUFDenRCLEtBQUssQ0FBQzJ0QixNQUFNLEdBQUcsSUFBSTtJQUNwQ0YsZ0JBQWdCLENBQUN6dEIsS0FBSyxDQUFDNHRCLFFBQVEsR0FBRyxVQUFVO0lBQzVDSCxnQkFBZ0IsQ0FBQ3p0QixLQUFLLENBQUM2dEIsS0FBSyxHQUFHLEdBQUc7SUFDbENKLGdCQUFnQixDQUFDenRCLEtBQUssQ0FBQzh0QixRQUFRLEdBQzNCLDZDQUE2QztJQUNqREwsZ0JBQWdCLENBQUN6dEIsS0FBSyxDQUFDK3RCLFFBQVEsR0FBRyxRQUFRO0lBQzFDTCxVQUFVLENBQUMxdEIsS0FBSyxDQUFDNnRCLEtBQUssR0FBRyxHQUFHO0lBQzVCSCxVQUFVLENBQUMxdEIsS0FBSyxDQUFDZ3VCLFVBQVUsR0FBRyx1QkFBdUI7SUFDckQsSUFBSWQsVUFBVSxLQUFLLGVBQWUsRUFBRTtNQUNoQ1EsVUFBVSxDQUFDMXRCLEtBQUssQ0FBQzluQixNQUFNLEdBQUcsT0FBTztJQUNyQztFQUNKO0VBQ0EsT0FBTztJQUFFdTFDLGdCQUFnQjtJQUFFQztFQUFXLENBQUM7QUFDM0MsQ0FBQztBQUNELElBQU1PLG1CQUFtQixHQUFHQSxDQUFDakIsS0FBSyxFQUFFVSxVQUFVLEtBQUs7RUFDL0MsSUFBTVEsVUFBVSxHQUFHbkIsaUJBQWlCLENBQUNDLEtBQUssQ0FBQztFQUMzQzlwQyxNQUFNLENBQUM4Z0MsTUFBTSxDQUFDMEosVUFBVSxDQUFDMXRCLEtBQUssRUFBRWt1QixVQUFVLENBQUM7QUFDL0MsQ0FBQztBQUNELElBQU1DLFNBQVMsR0FBR0EsQ0FBQ0MsTUFBTSxFQUFFWCxnQkFBZ0IsS0FBSztFQUM1QyxJQUFNWSxZQUFZLEdBQUd4b0MsUUFBUSxDQUFDNmEsYUFBYSxDQUFDLEdBQUcsQ0FBQztFQUNoRDJ0QixZQUFZLENBQUM1c0IsSUFBSSxHQUFHMnNCLE1BQU07RUFDMUJDLFlBQVksQ0FBQ3h1QyxNQUFNLEdBQUcsTUFBTTtFQUM1Qnd1QyxZQUFZLENBQUNwdEIsV0FBVyxDQUFDd3NCLGdCQUFnQixDQUFDO0VBQzFDWSxZQUFZLENBQUNydUIsS0FBSyxDQUFDL25CLEtBQUssR0FBRyxNQUFNO0VBQ2pDbzJDLFlBQVksQ0FBQ3J1QixLQUFLLENBQUM5bkIsTUFBTSxHQUFHLE1BQU07RUFDbENtMkMsWUFBWSxDQUFDcnVCLEtBQUssQ0FBQy9CLE9BQU8sR0FBRyxjQUFjO0VBQzNDLE9BQU9vd0IsWUFBWTtBQUN2QixDQUFDO0FBQ0QsSUFBTUMsZ0JBQWdCLEdBQUdBLENBQUNaLFVBQVUsRUFBRUQsZ0JBQWdCLEVBQUU1cUIsU0FBUyxLQUFLO0VBQ2xFNnFCLFVBQVUsQ0FBQzF0QixLQUFLLENBQUM0dEIsUUFBUSxHQUFHLE9BQU87RUFDbkMsSUFBTVcsVUFBVSxHQUFHMW9DLFFBQVEsQ0FBQzZhLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDaEQ2dEIsVUFBVSxDQUFDcDRCLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDLGVBQWUsQ0FBQztFQUN6Q200QixVQUFVLENBQUN2dUIsS0FBSyxDQUFDNHRCLFFBQVEsR0FBRyxVQUFVO0VBQ3RDVyxVQUFVLENBQUN2dUIsS0FBSyxDQUFDL25CLEtBQUssR0FBRyxNQUFNO0VBQy9CczJDLFVBQVUsQ0FBQ3Z1QixLQUFLLENBQUN3SixNQUFNLEdBQUcsR0FBRztFQUM3QixJQUFJM0csU0FBUyxFQUFFO0lBQ1gwckIsVUFBVSxDQUFDdnVCLEtBQUssQ0FBQ3d1QixZQUFZLEdBQUcsbUJBQW1CO0VBQ3ZELENBQUMsTUFDSTtJQUNERCxVQUFVLENBQUN2dUIsS0FBSyxDQUFDd3VCLFlBQVksR0FBRyxtQkFBbUI7RUFDdkQ7RUFDQWYsZ0JBQWdCLENBQUN4c0IsV0FBVyxDQUFDc3RCLFVBQVUsQ0FBQztBQUM1QyxDQUFDO0FBQ0QsSUFBTUUsYUFBYSxHQUFHQSxDQUFDeDNCLE1BQU0sRUFBRXkyQixVQUFVLEVBQUVELGdCQUFnQixLQUFLO0VBQzVEQyxVQUFVLENBQUMxdEIsS0FBSyxDQUFDNHRCLFFBQVEsR0FBRyxVQUFVO0VBQ3RDMzJCLE1BQU0sQ0FBQytJLEtBQUssQ0FBQzR0QixRQUFRLEdBQUcsVUFBVTtFQUNsQyxJQUFNYyxRQUFRLEdBQUloQixVQUFVLElBQUtyNkIsd0RBQU8sQ0FDbkN5TyxPQUFPLENBQUMsTUFBTTRyQixVQUFVLENBQUN0a0IscUJBQXFCLENBQUMsQ0FBQyxDQUFDLENBQ2pEL1AsSUFBSSxDQUFFczFCLElBQUksSUFBS3Q3Qix3REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07SUFDckMsSUFBTTA0QixnQkFBZ0IsR0FBR0QsSUFBSSxDQUFDejJDLE1BQU07SUFDcEMsSUFBTTIyQyxZQUFZLEdBQUd0eEMsTUFBTSxDQUFDaU8sV0FBVztJQUN2QztJQUNBLElBQU1zakMsMEJBQTBCLEdBQUduckMsSUFBSSxDQUFDMkwsS0FBSyxDQUFFcS9CLElBQUksQ0FBQ25sQixNQUFNLElBQUlxbEIsWUFBWSxHQUFHRCxnQkFBZ0IsQ0FBQyxHQUFJLEdBQUcsQ0FBQztJQUN0R2xCLFVBQVUsQ0FBQzF0QixLQUFLLENBQUMrdUIsbUJBQW1CLE1BQUExMkMsTUFBQSxDQUFNeTJDLDBCQUEwQixNQUFHO0VBQzNFLENBQUMsQ0FBQyxDQUFDO0VBQ0gsSUFBTUUsV0FBVyxHQUFJN3JDLE9BQU8sSUFBS0EsT0FBTyxDQUNuQ3JDLE1BQU0sQ0FBRWdjLEtBQUssSUFBS0EsS0FBSyxDQUFDQyxjQUFjLENBQUMsQ0FDdkMxRSxPQUFPLENBQUMsTUFBTTtJQUNmOWEsTUFBTSxDQUFDeUksZ0JBQWdCLENBQUMsUUFBUSxFQUFFLE1BQU0sS0FBSzBvQyxRQUFRLENBQUNoQixVQUFVLENBQUMsRUFBRTtNQUMvRHVCLE9BQU8sRUFBRTtJQUNiLENBQUMsQ0FBQztJQUNGLEtBQUtQLFFBQVEsQ0FBQ2hCLFVBQVUsQ0FBQztFQUM3QixDQUFDLENBQUM7RUFDRixJQUFNOXdCLFFBQVEsR0FBRyxJQUFJUyxvQkFBb0IsQ0FBQzJ4QixXQUFXLEVBQUU7SUFDbkQxeEIsVUFBVSxFQUFFO0VBQ2hCLENBQUMsQ0FBQztFQUNGVixRQUFRLENBQUNlLE9BQU8sQ0FBQzh2QixnQkFBZ0IsQ0FBQztBQUN0QyxDQUFDO0FBQ0QsSUFBTXlCLGVBQWU7RUFBQSxJQUFBbDNDLElBQUEsR0FBQW9PLGlCQUFBLENBQUcsV0FBTzRtQyxLQUFLLEVBQUUvMUIsTUFBTSxFQUFLO0lBQzdDLElBQU07TUFBRXcyQixnQkFBZ0I7TUFBRUM7SUFBVyxDQUFDLEdBQUdGLFlBQVksQ0FBQ3YyQixNQUFNLEVBQUUrMUIsS0FBSyxDQUFDRSxVQUFVLENBQUM7SUFDL0UsSUFBTWlDLHVCQUF1QixHQUFHLFFBQVE7SUFDeEMsT0FBTzk3Qix3REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07TUFDeEIrM0IsbUJBQW1CLENBQUNqQixLQUFLLEVBQUVVLFVBQVUsQ0FBQztNQUN0QyxJQUFJVixLQUFLLENBQUNFLFVBQVUsS0FBSyxVQUFVLEVBQUU7UUFDakN1QixhQUFhLENBQUN4M0IsTUFBTSxFQUFFeTJCLFVBQVUsRUFBRUQsZ0JBQWdCLENBQUM7TUFDdkQ7TUFDQTtNQUNBLElBQUlULEtBQUssQ0FBQ0UsVUFBVSxLQUFLLE9BQU8sRUFBRTtRQUM5QmoyQixNQUFNLENBQUMrSSxLQUFLLENBQUM0dEIsUUFBUSxHQUFHLFVBQVU7UUFDbENGLFVBQVUsQ0FBQzF0QixLQUFLLENBQUM0dEIsUUFBUSxHQUFHLE9BQU87UUFDbkMsSUFBSVosS0FBSyxDQUFDTSxlQUFlLEVBQUU7VUFDdkJHLGdCQUFnQixDQUFDenRCLEtBQUssQ0FBQ3N0QixlQUFlLEdBQUdOLEtBQUssQ0FBQ00sZUFBZTtRQUNsRTtNQUNKO01BQ0EsSUFBSU4sS0FBSyxDQUFDRSxVQUFVLEtBQUssZUFBZSxFQUFFO1FBQ3RDajJCLE1BQU0sQ0FBQytJLEtBQUssQ0FBQzluQixNQUFNLEdBQUcsTUFBTTtRQUM1QitlLE1BQU0sQ0FBQytJLEtBQUssQ0FBQ3lNLFlBQVksR0FBRyxNQUFNO1FBQ2xDeFYsTUFBTSxDQUFDK0ksS0FBSyxDQUFDNHRCLFFBQVEsR0FBRyxVQUFVO1FBQ2xDMzJCLE1BQU0sQ0FBQytJLEtBQUssQ0FBQy9uQixLQUFLLEdBQUcsTUFBTTtRQUMzQixLQUFLNHBCLDhFQUFpQixDQUFDNUssTUFBTSxFQUFFazRCLHVCQUF1QixDQUFDO1FBQ3ZELEtBQUt2c0IsMkZBQThCLENBQUM2cUIsZ0JBQWdCLEVBQUU1cUIsU0FBUyxDQUFDO1FBQ2hFLEtBQUt5ckIsZ0JBQWdCLENBQUNaLFVBQVUsRUFBRUQsZ0JBQWdCLEVBQUU1cUIsU0FBUyxDQUFDO1FBQzlELElBQUltcUIsS0FBSyxDQUFDRyxNQUFNLEVBQUU7VUFDZCxJQUFNaUMsTUFBTSxHQUFHakIsU0FBUyxDQUFDbkIsS0FBSyxDQUFDRyxNQUFNLEVBQUVNLGdCQUFnQixDQUFDO1VBQ3hEeDJCLE1BQU0sQ0FBQ3dMLFlBQVksQ0FBQzJzQixNQUFNLEVBQUVuNEIsTUFBTSxDQUFDeUwsVUFBVSxDQUFDO1FBQ2xEO1FBQ0EsSUFBSXNxQixLQUFLLENBQUNJLFdBQVcsRUFBRTtVQUNuQixJQUFNaUMsS0FBSyxHQUFHeHBDLFFBQVEsQ0FBQzZhLGFBQWEsQ0FBQyxPQUFPLENBQUM7VUFDN0MydUIsS0FBSyxDQUFDQyxRQUFRLEdBQUcsSUFBSTtVQUNyQkQsS0FBSyxDQUFDRSxLQUFLLEdBQUcsSUFBSTtVQUNsQkYsS0FBSyxDQUFDRyxXQUFXLEdBQUcsSUFBSTtVQUN4QkgsS0FBSyxDQUFDSSxHQUFHLEdBQUd6QyxLQUFLLENBQUNJLFdBQVc7VUFDN0JpQyxLQUFLLENBQUNydkIsS0FBSyxDQUFDNnRCLEtBQUssR0FBRyxhQUFhO1VBQ2pDd0IsS0FBSyxDQUFDcnZCLEtBQUssQ0FBQzR0QixRQUFRLEdBQUcsT0FBTztVQUM5QnlCLEtBQUssQ0FBQ3J2QixLQUFLLENBQUM5bkIsTUFBTSxHQUFHLE1BQU07VUFDM0JtM0MsS0FBSyxDQUFDcnZCLEtBQUssQ0FBQzB2QixTQUFTLEdBQUcsdUJBQXVCO1VBQy9DaEMsVUFBVSxDQUFDenNCLFdBQVcsQ0FBQ291QixLQUFLLENBQUM7VUFDN0IsSUFBSU0sTUFBTSxHQUFHLEtBQUs7VUFDbEJOLEtBQUssQ0FBQ08sT0FBTyxHQUFHLE1BQU9ELE1BQU0sR0FBRyxJQUFLO1VBQ3JDLElBQU0veUIsUUFBUSxHQUFHLElBQUlTLG9CQUFvQixDQUFFbGEsT0FBTyxJQUFLO1lBQ25EQSxPQUFPLENBQUNrVixPQUFPLENBQUV5RSxLQUFLLElBQUs7Y0FDdkIsSUFBSUEsS0FBSyxDQUFDQyxjQUFjLElBQ3BCLENBQUM0eUIsTUFBTSxJQUNQTixLQUFLLENBQUNRLE1BQU0sRUFBRTtnQkFDZCxLQUFLUixLQUFLLENBQUNTLElBQUksQ0FBQyxDQUFDO2NBQ3JCLENBQUMsTUFDSTtnQkFDRFQsS0FBSyxDQUFDVSxLQUFLLENBQUMsQ0FBQztjQUNqQjtZQUNKLENBQUMsQ0FBQztVQUNOLENBQUMsRUFBRTtZQUFFQyxJQUFJLEVBQUUsSUFBSTtZQUFFMXlCLFVBQVUsRUFBRSxLQUFLO1lBQUUyeUIsU0FBUyxFQUFFO1VBQUksQ0FBQyxDQUFDO1VBQ3JEcnpCLFFBQVEsQ0FBQ2UsT0FBTyxDQUFDOHZCLGdCQUFnQixDQUFDO1VBQ2xDLElBQU10MkIsTUFBTSxHQUFHaUYsb0VBQWEsQ0FBQ25GLE1BQU0sQ0FBQ3RHLEVBQUUsQ0FBQztVQUN2QyxJQUFNdS9CLHlCQUF5QixHQUFHLENBQUEvNEIsTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUVtSixrQkFBa0IsTUFBS3dzQix5QkFBeUI7VUFDMUYsSUFBSW9ELHlCQUF5QixFQUFFO1lBQzNCLEtBQUt0RCxtRkFBd0IsQ0FBQyxDQUFDO1lBQy9CeUMsS0FBSyxDQUFDYyxZQUFZLEdBQUcsWUFBWTtjQUM3QixJQUFNQyxPQUFPLEdBQUd6c0MsSUFBSSxDQUFDZ3lCLEtBQUssQ0FBQyxHQUFHLElBQUkwWixLQUFLLENBQUNnQixXQUFXLEdBQUdoQixLQUFLLENBQUN0ckMsUUFBUSxDQUFDLENBQUM7Y0FDdEU4b0MsOEVBQW1CLENBQUM1MUIsTUFBTSxDQUFDdEcsRUFBRSxFQUFFeS9CLE9BQU8sQ0FBQztZQUMzQyxDQUFDO1VBQ0w7UUFDSjtNQUNKLENBQUMsTUFDSTtRQUNEbjVCLE1BQU0sQ0FBQ3dMLFlBQVksQ0FBQ2dyQixnQkFBZ0IsRUFBRXgyQixNQUFNLENBQUN5TCxVQUFVLENBQUM7TUFDNUQ7SUFDSixDQUFDLENBQUM7RUFDTixDQUFDO0VBQUEsZ0JBckVLd3NCLGVBQWVBLENBQUEvbkMsRUFBQSxFQUFBb1QsR0FBQTtJQUFBLE9BQUF2aUIsSUFBQSxDQUFBMk8sS0FBQSxPQUFBMUosU0FBQTtFQUFBO0FBQUEsR0FxRXBCO0FBQ0QsSUFBTXluQixJQUFJLEdBQUlzbkIsUUFBUSxJQUFLO0VBQ3ZCQSxRQUFRLENBQUMsWUFBWTtJQUFBLElBQUF2b0MsS0FBQSxHQUFBMkMsaUJBQUEsQ0FBRSxXQUFPNG1DLEtBQUssRUFBRXJCLEdBQUcsRUFBRTFiLE1BQU0sRUFBSztNQUNqRCxJQUFJLENBQUNzZCxpQkFBaUIsQ0FBQ1AsS0FBSyxDQUFDLEVBQUU7UUFDM0IsT0FBTy95QixPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO01BQzVCO01BQ0EsSUFBTWxELE1BQU0sR0FBR2daLE1BQU0sYUFBTkEsTUFBTSx1QkFBTkEsTUFBTSxDQUFFOVIsT0FBTyxDQUFDLGFBQWEsQ0FBQztNQUM3QyxJQUFJbEgsTUFBTSxFQUFFO1FBQ1IsT0FBT2k0QixlQUFlLENBQUNsQyxLQUFLLEVBQUUvMUIsTUFBTSxDQUFDO01BQ3pDO0lBQ0osQ0FBQztJQUFBLGlCQUFBa0ksR0FBQSxFQUFBMEosR0FBQSxFQUFBYyxHQUFBO01BQUEsT0FBQWxtQixLQUFBLENBQUFrRCxLQUFBLE9BQUExSixTQUFBO0lBQUE7RUFBQSxJQUFDO0FBQ04sQ0FBQztBQUNNLElBQU1iLENBQUMsR0FBRztFQUNiOHlDLGVBQWU7RUFDZm5DO0FBQ0osQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pMbUQ7QUFDWDtBQUN6QyxJQUFNdUQsa0JBQWtCLEdBQUl0RCxLQUFLLElBQUs7RUFDbEMsT0FBUTFVLHdEQUFRLENBQUMwVSxLQUFLLENBQUMsS0FDbEJBLEtBQUssQ0FBQy8wQyxLQUFLLEtBQUtpRixTQUFTLElBQ3RCVCx3REFBUSxDQUFDdXdDLEtBQUssQ0FBQy8wQyxLQUFLLENBQUMsSUFDckIsT0FBTyswQyxLQUFLLENBQUMvMEMsS0FBSyxLQUFLLFFBQVEsQ0FBQyxLQUNuQyswQyxLQUFLLENBQUM5MEMsTUFBTSxLQUFLZ0YsU0FBUyxJQUN2QlQsd0RBQVEsQ0FBQ3V3QyxLQUFLLENBQUM5MEMsTUFBTSxDQUFDLElBQ3RCLE9BQU84MEMsS0FBSyxDQUFDOTBDLE1BQU0sS0FBSyxRQUFRLENBQUM7QUFDN0MsQ0FBQztBQUNELElBQU1xNEMsU0FBUyxHQUFJcDBDLE1BQU0sSUFBSztFQUFBLElBQUFxMEMsU0FBQTtFQUMxQixJQUFNQyxZQUFZLEdBQUcsNENBQTRDO0VBQ2pFLElBQU1DLFdBQVcsR0FBRyxJQUFJO0VBQ3hCLElBQU1sZSxPQUFPLEdBQUdpZSxZQUFZLENBQUNFLElBQUksQ0FBQzF2QyxNQUFNLENBQUM5RSxNQUFNLENBQUMsQ0FBQztFQUNqRCxJQUFJLENBQUNxMkIsT0FBTyxFQUFFO0lBQ1YsT0FBTyxFQUFFO0VBQ2I7RUFDQSxJQUFNck8sTUFBTSxHQUFHcU8sT0FBTyxDQUFDLENBQUMsQ0FBQztFQUN6QixJQUFNdU0sSUFBSSxJQUFBeVIsU0FBQSxHQUFHaGUsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFBZ2UsU0FBQSxjQUFBQSxTQUFBLEdBQUlFLFdBQVc7RUFDdEMsSUFBSSxDQUFDdnNCLE1BQU0sRUFBRTtJQUNULE9BQU8sRUFBRTtFQUNiO0VBQ0EsT0FBT0EsTUFBTSxHQUFHNGEsSUFBSTtBQUN4QixDQUFDO0FBQ0QsSUFBTTZSLE1BQU0sR0FBR0EsQ0FBQzVELEtBQUssRUFBRS9jLE1BQU0sRUFBRTRnQixlQUFlLEVBQUU1NUIsTUFBTSxLQUFLO0VBQ3ZELElBQUksQ0FBQ3E1QixrQkFBa0IsQ0FBQ3RELEtBQUssQ0FBQyxJQUFJLENBQUMvMUIsTUFBTSxFQUFFO0lBQ3ZDLE9BQU9nRCxPQUFPLENBQUNFLE9BQU8sQ0FBQyxDQUFDO0VBQzVCO0VBQ0EsSUFBTTh5QixNQUFNLEdBQUcsQ0FBQyxDQUFDO0VBQ2pCLElBQUlELEtBQUssQ0FBQy8wQyxLQUFLLEVBQUU7SUFDYmcxQyxNQUFNLENBQUNoMUMsS0FBSyxHQUFHczRDLFNBQVMsQ0FBQ3ZELEtBQUssQ0FBQy8wQyxLQUFLLENBQUM7RUFDekM7RUFDQSxJQUFJKzBDLEtBQUssQ0FBQzkwQyxNQUFNLEVBQUU7SUFDZCswQyxNQUFNLENBQUMvMEMsTUFBTSxHQUFHcTRDLFNBQVMsQ0FBQ3ZELEtBQUssQ0FBQzkwQyxNQUFNLENBQUM7RUFDM0M7RUFDQSxPQUFPbWIsd0RBQU8sQ0FBQzZDLE1BQU0sQ0FBQyxNQUFNO0lBQ3hCaFQsTUFBTSxDQUFDOGdDLE1BQU0sQ0FBQy9ULE1BQU0sQ0FBQ2pRLEtBQUssRUFBRWl0QixNQUFNLENBQUM7SUFDbkMsSUFBSTRELGVBQWUsRUFBRTtNQUNqQjN0QyxNQUFNLENBQUM4Z0MsTUFBTSxDQUFDNk0sZUFBZSxDQUFDN3dCLEtBQUssRUFBRWl0QixNQUFNLENBQUM7SUFDaEQ7SUFDQWgyQixNQUFNLENBQUMrSSxLQUFLLENBQUM4d0IsU0FBUyxHQUFHLE1BQU07RUFDbkMsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNEO0FBQ0EsSUFBTUMsdUJBQXVCLEdBQUk5NUIsTUFBTSxJQUFLO0VBQ3hDLEtBQUs1RCx3REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07SUFDdEJlLE1BQU0sQ0FBQ2QsU0FBUyxDQUFDN1UsTUFBTSxDQUFDLG9CQUFvQixDQUFDO0VBQ2pELENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxJQUFNb2pCLElBQUksR0FBSXNuQixRQUFRLElBQUs7RUFDdkJBLFFBQVEsQ0FBQyxRQUFRLEVBQUUsQ0FBQ2dCLEtBQUssRUFBRXJCLEdBQUcsRUFBRTFiLE1BQU0sS0FBSztJQUN2QyxJQUFJQSxNQUFNLElBQUkrYyxLQUFLLEVBQUU7TUFBQSxJQUFBZ0UsZUFBQSxFQUFBQyxnQkFBQTtNQUNqQixJQUFNaDZCLE1BQU0sSUFBQSs1QixlQUFBLEdBQUcvZ0IsTUFBTSxDQUFDOVIsT0FBTyxDQUFDLGFBQWEsQ0FBQyxjQUFBNnlCLGVBQUEsY0FBQUEsZUFBQSxHQUFJOXpDLFNBQVM7TUFDekQsSUFBSStaLE1BQU0sRUFBRTtRQUNSODVCLHVCQUF1QixDQUFDOTVCLE1BQU0sQ0FBQztNQUNuQztNQUNBLElBQU00NUIsZUFBZSxJQUFBSSxnQkFBQSxHQUFHaGhCLE1BQU0sQ0FBQzlSLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxjQUFBOHlCLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUkvekMsU0FBUztNQUN4RSxPQUFPMHpDLE1BQU0sQ0FBQzVELEtBQUssRUFBRS9jLE1BQU0sRUFBRTRnQixlQUFlLEVBQUU1NUIsTUFBTSxDQUFDO0lBQ3pEO0VBQ0osQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNNLElBQU03YSxDQUFDLEdBQUc7RUFBRXcwQyxNQUFNO0VBQUVMO0FBQVUsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5REk7QUFDRDtBQUN6QyxJQUFNVyxPQUFPLEdBQUdBLENBQUNDLFVBQVUsRUFBRWw2QixNQUFNLEtBQUs1RCx3REFBTyxDQUFDNkMsTUFBTSxDQUFDLE1BQU07RUFDekRlLE1BQU0sQ0FBQ2QsU0FBUyxDQUFDQyxHQUFHLGFBQUEvZCxNQUFBLENBQWE4NEMsVUFBVSxDQUFFLENBQUM7QUFDbEQsQ0FBQyxDQUFDO0FBQ0YsSUFBTXpzQixJQUFJLEdBQUlzbkIsUUFBUSxJQUFLO0VBQ3ZCQSxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUNnQixLQUFLLEVBQUVyQixHQUFHLEVBQUUxYixNQUFNLEtBQUs7SUFDckMsSUFBTWhaLE1BQU0sR0FBR2daLE1BQU0sYUFBTkEsTUFBTSx1QkFBTkEsTUFBTSxDQUFFOVIsT0FBTyxDQUFDLGFBQWEsQ0FBQztJQUM3QyxJQUFJbEgsTUFBTSxJQUFJeGEsd0RBQVEsQ0FBQ3V3QyxLQUFLLENBQUMsRUFBRTtNQUMzQixLQUFLa0UsT0FBTyxDQUFDbEUsS0FBSyxFQUFFLzFCLE1BQU0sQ0FBQztJQUMvQjtFQUNKLENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWjZGO0FBQ3pEO0FBQ0o7QUFDcUI7QUFDSztBQUNBO0FBQzNELElBQU1tNkIsdUJBQXVCLEdBQUk5Z0MsR0FBRyxJQUFLO0VBQ3JDLElBQU0rZ0MsV0FBVyxHQUFHbnVDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDbU4sR0FBRyxDQUFDLENBQUMzUCxHQUFHLENBQUVtYyxLQUFLLElBQUs7SUFDbkQsSUFBTSxDQUFDMWMsR0FBRyxFQUFFdUMsS0FBSyxDQUFDLEdBQUdtYSxLQUFLO0lBQzFCLE9BQU9obEIsS0FBSyxDQUFDMkksT0FBTyxDQUFDa0MsS0FBSyxDQUFDLEdBQ3JCQSxLQUFLLENBQUNoQyxHQUFHLENBQUUyd0MsV0FBVyxPQUFBajVDLE1BQUEsQ0FBUStILEdBQUcsT0FBQS9ILE1BQUEsQ0FBSWk1QyxXQUFXLENBQUUsQ0FBQyxNQUFBajVDLE1BQUEsQ0FDaEQrSCxHQUFHLE9BQUEvSCxNQUFBLENBQUlzSyxLQUFLLENBQUU7RUFDM0IsQ0FBQyxDQUFDO0VBQ0YsSUFBTTR1QyxXQUFXLEdBQUd6NUMsS0FBSyxDQUFDMDVDLFNBQVMsQ0FBQ241QyxNQUFNLENBQUNzTyxLQUFLLENBQUMsRUFBRSxFQUFFMHFDLFdBQVcsQ0FBQztFQUNqRSxPQUFPRSxXQUFXLENBQUN0c0MsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNoQyxDQUFDO0FBQ0QsSUFBTWczQiw0QkFBNEIsR0FBR2gyQixxREFBSSxDQUFFa0csYUFBYSxJQUFLNDhCLHdFQUFpQixDQUFDO0VBQzNFcDdCLElBQUksRUFBRXhCLGFBQWEsQ0FBQ3dCLElBQUk7RUFDeEI4akMsR0FBRyxFQUFFdGxDLGFBQWEsQ0FBQ08sR0FBRztFQUN0QmdsQyxHQUFHLEVBQUV2bEMsYUFBYSxDQUFDeE8sT0FBTztFQUMxQmcwQyxHQUFHLEVBQUV4bEMsYUFBYSxDQUFDeWxDLEVBQUU7RUFDckJDLEdBQUcsRUFBRTFsQyxhQUFhLENBQUMybEMsQ0FBQztFQUNwQkMsR0FBRyxFQUFFNWxDLGFBQWEsQ0FBQ3ZCLENBQUM7RUFDcEJvbkMsR0FBRyxFQUFFN2xDLGFBQWEsQ0FBQzhsQyxFQUFFO0VBQ3JCQyxHQUFHLEVBQUUvbEMsYUFBYSxDQUFDOEcsRUFBRTtFQUNyQmsvQixHQUFHLEVBQUUsQ0FBQ2htQyxhQUFhLENBQUMwRixFQUFFLEVBQUUxRixhQUFhLENBQUNpbUMsRUFBRSxFQUFFam1DLGFBQWEsQ0FBQ2ttQyxFQUFFLENBQUMsQ0FBQ3B0QyxJQUFJLENBQUMsR0FBRyxDQUFDO0VBQ3JFOEssU0FBUyxFQUFFNUQsYUFBYSxDQUFDNEQ7QUFDN0IsQ0FBQyxDQUFDLENBQUM7QUFDSCxJQUFNdWlDLHNCQUFzQixHQUFHcnNDLHFEQUFJLENBQUVrRyxhQUFhLElBQUtpbEMsdUJBQXVCLENBQUNuViw0QkFBNEIsQ0FBQzl2QixhQUFhLENBQUMsQ0FBQyxDQUFDO0FBQzVILElBQU11MUIsZ0JBQWdCLEdBQUdBLENBQUNyN0IsWUFBWSxFQUFFb0QsVUFBVSxLQUFLO0VBQ25ELElBQU07SUFBRS9MO0VBQUssQ0FBQyxHQUFHSCxNQUFNLENBQUNDLFFBQVEsQ0FBQ0MsTUFBTTtFQUN2QyxJQUFNME8sYUFBYSxHQUFHL0MsNEdBQWtCLENBQUM7SUFDckNHLE1BQU0sRUFBRW9lLG9FQUFrQixDQUFDcGUsTUFBTTtJQUNqQ0Msd0JBQXdCLEVBQUVnYyxrRUFBaUIsQ0FBQyxDQUFDO0lBQzdDbmYsWUFBWTtJQUNab0Q7RUFDSixDQUFDLENBQUM7RUFDRjtFQUNBL0wsSUFBSSxDQUFDNjBDLHFCQUFxQixHQUFHRCxzQkFBc0IsQ0FBQ25tQyxhQUFhLENBQUM7RUFDbEU7RUFDQXpPLElBQUksQ0FBQzgwQyxlQUFlLEdBQUdybUMsYUFBYTtFQUNwQzFLLG1EQUFHLENBQUMsWUFBWSxFQUFFLHVCQUF1QixFQUFFMEssYUFBYSxDQUFDO0VBQ3pELE9BQU9BLGFBQWE7QUFDeEIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0M0RztBQUM1RTtBQUNzQjtBQUN2RCxJQUFNOUosUUFBUSxHQUFHOUUsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDNkUsS0FBSyxHQUM1QyxzQ0FBc0MsR0FDdEMsNkJBQTZCO0FBQ25DO0FBQ0EsSUFBTW13QyxhQUFhLEdBQUcsQ0FBQyxDQUFDO0FBQ3hCLElBQU1DLFlBQVksR0FBRzFzQyxxREFBSSxDQUFDLE1BQU07RUFDNUIvQyxNQUFNLENBQUNDLE9BQU8sQ0FBQ3V2QyxhQUFhLENBQUMsQ0FBQ3I2QixPQUFPLENBQUNyZ0IsSUFBQSxJQUFrQjtJQUFBLElBQWpCLENBQUNvSSxHQUFHLEVBQUV1QyxLQUFLLENBQUMsR0FBQTNLLElBQUE7SUFDL0MsSUFBTW1mLE1BQU0sR0FBR2lGLG9FQUFhLENBQUNoYyxHQUFHLENBQUM7SUFDakMsSUFBSSxFQUFDK1csTUFBTSxhQUFOQSxNQUFNLGVBQU5BLE1BQU0sQ0FBRXk3QixVQUFVLEtBQUksQ0FBQ3o3QixNQUFNLENBQUMwN0IsVUFBVSxFQUFFO01BQzNDO0lBQ0o7SUFDQSxJQUFNO01BQUVELFVBQVU7TUFBRUM7SUFBVyxDQUFDLEdBQUcxN0IsTUFBTTtJQUN6QyxJQUFNMjdCLFFBQVEsR0FBR253QyxLQUFLLGFBQUxBLEtBQUssY0FBTEEsS0FBSyxHQUFJLENBQUM7SUFDM0IsS0FBS3NCLEtBQUssQ0FBQzVCLFFBQVEsRUFBRTtNQUNqQjZCLE1BQU0sRUFBRSxNQUFNO01BQ2RDLElBQUksRUFBRXBFLElBQUksQ0FBQ0MsU0FBUyxDQUFDO1FBQ2pCNjRCLEtBQUssRUFBRSx3Q0FBd0M7UUFDL0MzMkIsVUFBVSxFQUFFLENBQ1I7VUFBRWxFLElBQUksRUFBRSxZQUFZO1VBQUUyRSxLQUFLLEVBQUVpd0M7UUFBVyxDQUFDLEVBQ3pDO1VBQUU1MEMsSUFBSSxFQUFFLFlBQVk7VUFBRTJFLEtBQUssRUFBRWt3QztRQUFXLENBQUMsRUFDekM7VUFBRTcwQyxJQUFJLEVBQUUsVUFBVTtVQUFFMkUsS0FBSyxFQUFFbXdDO1FBQVMsQ0FBQyxFQUNyQztVQUNJOTBDLElBQUksRUFBRSxZQUFZO1VBQ2xCMkUsS0FBSyxFQUFFcEYsTUFBTSxDQUFDQyxRQUFRLENBQUNDLE1BQU0sQ0FBQ3dOLEtBQUssQ0FBQzNEO1FBQ3hDLENBQUM7TUFFVCxDQUFDLENBQUM7TUFDRmxELFNBQVMsRUFBRSxJQUFJO01BQ2ZDLEtBQUssRUFBRSxVQUFVO01BQ2pCQyxJQUFJLEVBQUU7SUFDVixDQUFDLENBQUM7RUFDTixDQUFDLENBQUM7QUFDTixDQUFDLENBQUM7QUFDRixJQUFNc29DLHdCQUF3QixHQUFHM21DLHFEQUFJLGNBQUFHLGlCQUFBLENBQUMsYUFBWTtFQUM5QyxVQUFVcXNDLCtGQUF3QixDQUFDLENBQUMsRUFBRTtJQUNsQ2wxQyxNQUFNLENBQUN5SSxnQkFBZ0IsQ0FBQyxrQkFBa0IsRUFBRTJzQyxZQUFZLEVBQUU7TUFDdEQxc0MsSUFBSSxFQUFFO0lBQ1YsQ0FBQyxDQUFDO0lBQ0Y7SUFDQTFJLE1BQU0sQ0FBQ3lJLGdCQUFnQixDQUFDLFVBQVUsRUFBRTJzQyxZQUFZLEVBQUU7TUFBRTFzQyxJQUFJLEVBQUU7SUFBSyxDQUFDLENBQUM7RUFDckU7QUFDSixDQUFDLEVBQUM7QUFDRixJQUFNNG1DLG1CQUFtQixHQUFHQSxDQUFDcjZCLE1BQU0sRUFBRXVnQyxlQUFlLEtBQUs7RUFDckRMLGFBQWEsQ0FBQ2xnQyxNQUFNLENBQUMsR0FBR3VnQyxlQUFlO0FBQzNDLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQy9DRCxpRUFBZSxzSkFBc0osRSIsInNvdXJjZXMiOlsid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9hZC1zaXplcy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvYnJlYWtwb2ludC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvY29uc3RhbnRzL3ByZWJpZC10aW1lb3V0LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9nZW8vY291bnRyeS1jb2RlLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9nZW8vZ2VvLXV0aWxzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9nZW8vZ2V0LWxvY2FsZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvbWVzc2VuZ2VyL3Bvc3QtbWVzc2FnZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvcGVybXV0aXZlLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9zZW5kLWNvbW1lcmNpYWwtbWV0cmljcy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvdGFyZ2V0aW5nL2J1aWxkLXBhZ2UtdGFyZ2V0aW5nLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy90YXJnZXRpbmcvY29udGVudC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvdGFyZ2V0aW5nL3BlcnNvbmFsaXNlZC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvdGFyZ2V0aW5nL3BpY2stdGFyZ2V0aW5nLXZhbHVlcy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvdGFyZ2V0aW5nL3Nlc3Npb24udHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL2NvcmUvc3JjL3RhcmdldGluZy9zaGFyZWQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL2NvcmUvc3JjL3RhcmdldGluZy90ZWFkcy1lbGlnaWJpbGl0eS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvdGFyZ2V0aW5nL3ZpZXdwb3J0LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9kZWZpbmUvQWR2ZXJ0LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9kZWZpbmUvY3JlYXRlLWFkdmVydC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvZGVmaW5lL2RlZmluZS1zbG90LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9kZWZpbmUvaW5pdC1zbG90LWlhcy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvZGlzcGxheS9sYXp5LWxvYWQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2Rpc3BsYXkvbG9hZC1hZHZlcnQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2Rpc3BsYXkvcmVxdWVzdC1iaWRzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9ldmVudHMvZW1wdHktYWR2ZXJ0LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9ldmVudHMvcmVuZGVyLWFkdmVydC1sYWJlbC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvZXhwZXJpbWVudHMvYWItdGVzdHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2V4cGVyaW1lbnRzL2FiLXVybC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvZXhwZXJpbWVudHMvYWIudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2V4cGVyaW1lbnRzL3Rlc3RzL2FkbWlyYWwtYWRibG9ja2VyLXJlY292ZXJ5LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9leHBlcmltZW50cy90ZXN0cy9wcmViaWQ5NDYudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvc2hhcmVkL3JlbG9hZC1wYWdlLW9uLWNvbnNlbnQtY2hhbmdlLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L3NoYXJlZC9zZXQtYWR0ZXN0LWNvb2tpZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9zaGFyZWQvc2V0LWFkdGVzdC1pbi1sYWJlbHMtY29va2llLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbnNlcnQvZmlsbC1keW5hbWljLWFkdmVydC1zbG90LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbnNlcnQvc3BhY2VmaW5kZXIvYXJ0aWNsZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5zZXJ0L3NwYWNlZmluZGVyL2NhcnJvdC10cmFmZmljLWRyaXZlci50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5zZXJ0L3NwYWNlZmluZGVyL3J1bGVzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbnNlcnQvc3BhY2VmaW5kZXIvc3BhY2UtZmlsbGVyLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbnNlcnQvc3BhY2VmaW5kZXIvc3BhY2VmaW5kZXIudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luc2VydC9zdGlja3ktaW5saW5lcy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL19fdmVuZG9yL3B1Ym1hdGljLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvYWItbG9jYWxzdG9yYWdlLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvY3JlYXRlLWFkLXNsb3QudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9kZnAvZ2V0LWFkdmVydC1ieS1pZC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2RmcC9xdWV1ZS1hZHZlcnQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9oZWFkZXItYmlkZGluZy9hOS9hOS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2hlYWRlci1iaWRkaW5nL3ByZWJpZC9hcHBuZXh1cy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2hlYWRlci1iaWRkaW5nL3ByZWJpZC9iaWQtY29uZmlnLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvaGVhZGVyLWJpZGRpbmcvcHJlYmlkL21hZ25pdGUudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9oZWFkZXItYmlkZGluZy9wcmViaWQvcHJlYmlkLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvaGVhZGVyLWJpZGRpbmcvcHJlYmlkL3ByaWNlLWNvbmZpZy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL2hlYWRlci1iaWRkaW5nL3Nsb3QtY29uZmlnLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvaGVhZGVyLWJpZGRpbmcvdXRpbHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9pZGVudGl0eS9hcGkudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvYmFja2dyb3VuZC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL21lc3Nlbmdlci9yZXNpemUudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvdHlwZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL3BhZ2UtdGFyZ2V0aW5nLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvdmlkZW8tcHJvZ3Jlc3MtcmVwb3J0aW5nLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3N0YXRpYy9zdmcvaWNvbi9jcm9zcy5zdmciXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgYnJlYWtwb2ludHMsIGlzQnJlYWtwb2ludCB9IGZyb20gJy4vYnJlYWtwb2ludCc7XG4vKipcbiAqIFN0b3JlIGFkIHNpemVzIGluIGEgd2F5IHRoYXQgaXMgY29tcGF0aWJsZSB3aXRoIGdvb2dsZS10YWcgYnV0IGFsc28gYWNjZXNzaWJsZSB2aWFcbiAqIG1vcmUgc2VtYW50aWMgYHdpZHRoYC9gaGVpZ2h0YCBwcm9wZXJ0aWVzIGFuZCBrZWVwIHRoaW5ncyByZWFkb25seS5cbiAqXG4gKiBleGFtcGxlOlxuICogY29uc3Qgc2l6ZSA9IG5ldyBBZFNpemUoWzMwMCwgMjUwXSk7XG4gKlxuICogc2l6ZS53aWR0aCA9PT0gMzAwOyAvLyB0cnVlXG4gKiBzaXplWzBdID09PSAzMDA7IC8vIHRydWVcbiAqXG4gKiBzaXplLmhlaWdodCA9PT0gMjUwOyAvLyB0cnVlXG4gKiBzaXplWzFdID09PSAyNTA7IC8vIHRydWVcbiAqXG4gKiBzaXplWzBdID0gMjAwOyAvLyB0aHJvd3MgZXJyb3JcbiAqIHNpemUud2lkdGggPSAyMDA7IC8vIHRocm93cyBlcnJvclxuICpcbiAqL1xuY2xhc3MgQWRTaXplIGV4dGVuZHMgQXJyYXkge1xuICAgIFswXTtcbiAgICBbMV07XG4gICAgY29uc3RydWN0b3IoW3dpZHRoLCBoZWlnaHRdKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXNbMF0gPSB3aWR0aDtcbiAgICAgICAgdGhpc1sxXSA9IGhlaWdodDtcbiAgICB9XG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndpZHRoID09PSAwICYmIHRoaXMuaGVpZ2h0ID09PSAwXG4gICAgICAgICAgICA/ICdmbHVpZCdcbiAgICAgICAgICAgIDogYCR7dGhpcy53aWR0aH0sJHt0aGlzLmhlaWdodH1gO1xuICAgIH1cbiAgICB0b0FycmF5KCkge1xuICAgICAgICByZXR1cm4gW3RoaXNbMF0sIHRoaXNbMV1dO1xuICAgIH1cbiAgICAvLyBUaGUgYWR2ZXJ0IHNpemUgaXMgbm90IHJlZmxlY3RpdmUgb2YgdGhlIGFjdHVhbCBzaXplIG9mIHRoZSBhZHZlcnQuXG4gICAgLy8gRm9yIGV4YW1wbGUsIGZsdWlkIGFkcyBhbmQgR3VhcmRpYW4gbWVyY2ggYWRzIGFyZSBsYXJnZXIgdGhhbiB0aGUgZGltZW5zaW9uc1xuICAgIGlzUHJveHkoKSB7XG4gICAgICAgIGNvbnN0IGlzT3V0T2ZQYWdlID0gdGhpcy53aWR0aCA9PT0gMSAmJiB0aGlzLmhlaWdodCA9PT0gMTtcbiAgICAgICAgY29uc3QgaXNFbXB0eSA9IHRoaXMud2lkdGggPT09IDIgJiYgdGhpcy5oZWlnaHQgPT09IDI7XG4gICAgICAgIGNvbnN0IGlzRmx1aWQgPSB0aGlzLnRvU3RyaW5nKCkgPT09ICdmbHVpZCc7XG4gICAgICAgIGNvbnN0IGlzTWVyY2ggPSB0aGlzLndpZHRoID09PSA4ODtcbiAgICAgICAgY29uc3QgaXNTcG9uc29yTG9nbyA9IHRoaXMud2lkdGggPT09IDMgJiYgdGhpcy5oZWlnaHQgPT09IDM7XG4gICAgICAgIHJldHVybiBpc091dE9mUGFnZSB8fCBpc0VtcHR5IHx8IGlzRmx1aWQgfHwgaXNNZXJjaCB8fCBpc1Nwb25zb3JMb2dvO1xuICAgIH1cbiAgICBnZXQgd2lkdGgoKSB7XG4gICAgICAgIHJldHVybiB0aGlzWzBdO1xuICAgIH1cbiAgICBnZXQgaGVpZ2h0KCkge1xuICAgICAgICByZXR1cm4gdGhpc1sxXTtcbiAgICB9XG59XG5jb25zdCBjcmVhdGVBZFNpemUgPSAod2lkdGgsIGhlaWdodCkgPT4ge1xuICAgIHJldHVybiBuZXcgQWRTaXplKFt3aWR0aCwgaGVpZ2h0XSk7XG59O1xuY29uc3QgbmFtZWRTdGFuZGFyZEFkU2l6ZXMgPSB7XG4gICAgYmlsbGJvYXJkOiBjcmVhdGVBZFNpemUoOTcwLCAyNTApLFxuICAgIGhhbGZQYWdlOiBjcmVhdGVBZFNpemUoMzAwLCA2MDApLFxuICAgIGxlYWRlcmJvYXJkOiBjcmVhdGVBZFNpemUoNzI4LCA5MCksXG4gICAgbW9iaWxlc3RpY2t5OiBjcmVhdGVBZFNpemUoMzIwLCA1MCksXG4gICAgbXB1OiBjcmVhdGVBZFNpemUoMzAwLCAyNTApLFxuICAgIHBvcnRyYWl0OiBjcmVhdGVBZFNpemUoMzAwLCAxMDUwKSxcbiAgICBza3lzY3JhcGVyOiBjcmVhdGVBZFNpemUoMTYwLCA2MDApLFxuICAgIGNhc2NhZGU6IGNyZWF0ZUFkU2l6ZSg5NDAsIDIzMCksXG4gICAgcG9ydHJhaXRJbnRlcnN0aXRpYWw6IGNyZWF0ZUFkU2l6ZSgzMjAsIDQ4MCksXG59O1xuY29uc3Qgc3RhbmRhcmRBZFNpemVzID0ge1xuICAgICc5NzB4MjUwJzogbmFtZWRTdGFuZGFyZEFkU2l6ZXMuYmlsbGJvYXJkLFxuICAgICczMDB4NjAwJzogbmFtZWRTdGFuZGFyZEFkU2l6ZXMuaGFsZlBhZ2UsXG4gICAgJzcyOHg5MCc6IG5hbWVkU3RhbmRhcmRBZFNpemVzLmxlYWRlcmJvYXJkLFxuICAgICczMDB4MjUwJzogbmFtZWRTdGFuZGFyZEFkU2l6ZXMubXB1LFxuICAgICczMDB4MTA1MCc6IG5hbWVkU3RhbmRhcmRBZFNpemVzLnBvcnRyYWl0LFxuICAgICcxNjB4NjAwJzogbmFtZWRTdGFuZGFyZEFkU2l6ZXMuc2t5c2NyYXBlcixcbn07XG5jb25zdCBvdXRzdHJlYW1TaXplcyA9IHtcbiAgICBvdXRzdHJlYW1EZXNrdG9wOiBjcmVhdGVBZFNpemUoNjIwLCAzNTApLFxuICAgIG91dHN0cmVhbUdvb2dsZURlc2t0b3A6IGNyZWF0ZUFkU2l6ZSg1NTAsIDMxMCksXG4gICAgb3V0c3RyZWFtTW9iaWxlOiBjcmVhdGVBZFNpemUoMzAwLCAxOTcpLFxufTtcbi8qKlxuICogQWQgc2l6ZXMgY29tbW9ubHkgYXNzb2NpYXRlZCB3aXRoIHRoaXJkIHBhcnRpZXNcbiAqL1xuY29uc3QgcHJvcHJpZXRhcnlBZFNpemVzID0ge1xuICAgIGZsdWlkOiBjcmVhdGVBZFNpemUoMCwgMCksXG4gICAgZ29vZ2xlQ2FyZDogY3JlYXRlQWRTaXplKDMwMCwgMjc0KSxcbiAgICBvdXRPZlBhZ2U6IGNyZWF0ZUFkU2l6ZSgxLCAxKSxcbiAgICBwdWJtYXRpY0ludGVyc2Nyb2xsZXI6IGNyZWF0ZUFkU2l6ZSgzNzEsIDY2MCksIC8vIHB1Ym1hdGljIG9ubHkgbW9iaWxlIHNpemVcbn07XG4vKipcbiAqIEFkIHNpemVzIGFzc29jaWF0ZWQgd2l0aCBpbi1ob3VzZSBmb3JtYXRzXG4gKi9cbmNvbnN0IGd1YXJkaWFuUHJvcHJpZXRhcnlBZFNpemVzID0ge1xuICAgIGVtcHR5OiBjcmVhdGVBZFNpemUoMiwgMiksXG4gICAgZmFicmljOiBjcmVhdGVBZFNpemUoODgsIDcxKSxcbiAgICBtZXJjaGFuZGlzaW5nOiBjcmVhdGVBZFNpemUoODgsIDg4KSxcbiAgICBtZXJjaGFuZGlzaW5nSGlnaDogY3JlYXRlQWRTaXplKDg4LCA4NyksXG4gICAgbWVyY2hhbmRpc2luZ0hpZ2hBZEZlYXR1cmU6IGNyZWF0ZUFkU2l6ZSg4OCwgODkpLFxuICAgIC8qKlxuICAgICAqIFRoaXMgaXMgYSBwcm94eSBzaXplIChub3QgdGhlIHRydWUgc2l6ZSBvZiB0aGUgcmVuZGVyZWQgY3JlYXRpdmUpXG4gICAgICogdGhhdCBjYW4gYmUgdXNlZCB0byBlbnN1cmUgdGhhdCBubyBvdGhlciBoaWdoIHByaW9yaXR5IGxpbmUgaXRlbXNcbiAgICAgKiBmaWxsIGEgY2VydGFpbiBzbG90LlxuICAgICAqL1xuICAgIHNwb25zb3JMb2dvOiBjcmVhdGVBZFNpemUoMywgMyksXG59O1xuY29uc3QgYWRTaXplcyA9IHtcbiAgICAuLi5uYW1lZFN0YW5kYXJkQWRTaXplcyxcbiAgICAuLi5zdGFuZGFyZEFkU2l6ZXMsXG4gICAgLi4ub3V0c3RyZWFtU2l6ZXMsXG4gICAgLi4ucHJvcHJpZXRhcnlBZFNpemVzLFxuICAgIC4uLmd1YXJkaWFuUHJvcHJpZXRhcnlBZFNpemVzLFxufTtcbi8qKlxuICogbWFyazogNDMyYjNhNDYtOTBjMS00NTczLTkwZDMtMjQwMGI1MWFmOGQwXG4gKiBTb21lIG9mIHRoZXNlIG1heSBvciBtYXkgbm90IG5lZWQgdG8gYmUgc3luY2VkIGZvciB3aXRoIHRoZSBzaXplcyBpbiAuL2NyZWF0ZS1hZC1zbG90LnRzXG4gKiB0aGVzZSB3ZXJlIG9yaWdpbmFsbHkgZnJvbSBEQ1IsIGNyZWF0ZS1hZC1zbG90LnRzIG9uZXMgd2VyZSBpbiBmcm9udGVuZC5cbiAqXG4gKiBOb3RlOlxuICogSWYgYSBicmVha3BvaW50IGlzIG5vdCBkZWZpbmVkIGluIGEgc2l6ZSBtYXBwaW5nIGZvciBhIHNsb3QsIHRoYXQgYnJlYWtwb2ludCB3aWxsIHVzZSB0aGUgc2l6ZXNcbiAqIG9mIHRoZSBuZXh0IGJyZWFrcG9pbnQgZG93biB0aGF0IGhhcyBhIHNpemUgbWFwcGluZy4gRm9yIGV4YW1wbGUsIGlmIG9ubHkgXCJtb2JpbGVcIiBhbmQgXCJwaGFibGV0XCIgc2l6ZXNcbiAqIGFyZSBkZWZpbmVkIGZvciBhIHNsb3QsIGFsbCBicmVha3BvaW50cyBsYXJnZXIgdGhhbiBcInBoYWJsZXRcIiB3aWxsIHVzZSB0aGUgbWFwcGluZyBmb3IgXCJwaGFibGV0XCIuXG4gKlxuICogSW4gYW5vdGhlciBleGFtcGxlLCBpZiBhIHNsb3QgaGFzIG9ubHkgXCJ0YWJsZXRcIiBhcyBhIHNpemUgbWFwcGluZyBkZWZpbmVkLFxuICogdGhlbiBcImRlc2t0b3BcIiB3aWxsIHVzZSB0aGUgc2l6ZSBtYXBwaW5nIGZvciBcInRhYmxldFwiLiBcIm1vYmlsZVwiIGFuZCBcInBoYWJsZXRcIlxuICogd2lsbCBoYXZlIG5vIHNpemUgbWFwcGluZy4gVGhpcyB0eXBlIG9mIGV4YW1wbGUgbWF5IGJlIHVzZWQgaW4gY2FzZXMgd2hlcmVcbiAqIHdlIG9ubHkgd2FudCB0aGUgc2xvdCB0byBhcHBlYXIgb24gdGhlIFwidGFibGV0XCIgc2l6ZSBvciBncmVhdGVyLlxuICoqL1xuY29uc3Qgc2xvdFNpemVNYXBwaW5ncyA9IHtcbiAgICBpbmxpbmU6IHtcbiAgICAgICAgbW9iaWxlOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLm91dHN0cmVhbU1vYmlsZSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5nb29nbGVDYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgXSxcbiAgICAgICAgZGVza3RvcDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5tcHUsXG4gICAgICAgICAgICBhZFNpemVzLmdvb2dsZUNhcmQsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgcmlnaHQ6IHtcbiAgICAgICAgbW9iaWxlOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLm1wdSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZ29vZ2xlQ2FyZCxcbiAgICAgICAgICAgIGFkU2l6ZXMuaGFsZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgY29tbWVudHM6IHtcbiAgICAgICAgbW9iaWxlOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLm91dHN0cmVhbU1vYmlsZSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5nb29nbGVDYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgXSxcbiAgICAgICAgZGVza3RvcDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5tcHUsXG4gICAgICAgICAgICBhZFNpemVzLmdvb2dsZUNhcmQsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgJ2NvbW1lbnRzLWV4cGFuZGVkJzoge1xuICAgICAgICBtb2JpbGU6IFthZFNpemVzLm1wdSwgYWRTaXplcy5lbXB0eV0sXG4gICAgICAgIGRlc2t0b3A6IFtcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0T2ZQYWdlLFxuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5nb29nbGVDYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgICAgIGFkU2l6ZXMuc2t5c2NyYXBlcixcbiAgICAgICAgICAgIGFkU2l6ZXMuaGFsZlBhZ2UsXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICAndG9wLWFib3ZlLW5hdic6IHtcbiAgICAgICAgbW9iaWxlOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLmZhYnJpYyxcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0c3RyZWFtTW9iaWxlLFxuICAgICAgICAgICAgYWRTaXplcy5tcHUsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgICAgICB0YWJsZXQ6IFtcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0T2ZQYWdlLFxuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZmFicmljLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgICAgIGFkU2l6ZXMubGVhZGVyYm9hcmQsXG4gICAgICAgIF0sXG4gICAgICAgIGRlc2t0b3A6IFtcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0T2ZQYWdlLFxuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMubGVhZGVyYm9hcmQsXG4gICAgICAgICAgICBjcmVhdGVBZFNpemUoOTQwLCAyMzApLFxuICAgICAgICAgICAgY3JlYXRlQWRTaXplKDkwMCwgMjUwKSxcbiAgICAgICAgICAgIGFkU2l6ZXMuYmlsbGJvYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5mYWJyaWMsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgJ2Zyb250cy1iYW5uZXInOiB7XG4gICAgICAgIHRhYmxldDogW2FkU2l6ZXMuZW1wdHksIGFkU2l6ZXMubGVhZGVyYm9hcmRdLFxuICAgICAgICBkZXNrdG9wOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLmJpbGxib2FyZCxcbiAgICAgICAgICAgIGFkU2l6ZXMubWVyY2hhbmRpc2luZ0hpZ2gsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgbW9zdHBvcDoge1xuICAgICAgICBtb2JpbGU6IFtcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0T2ZQYWdlLFxuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5nb29nbGVDYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgXSxcbiAgICAgICAgcGhhYmxldDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5vdXRzdHJlYW1Nb2JpbGUsXG4gICAgICAgICAgICBhZFNpemVzLm1wdSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZ29vZ2xlQ2FyZCxcbiAgICAgICAgICAgIGFkU2l6ZXMuaGFsZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICBdLFxuICAgICAgICB0YWJsZXQ6IFtcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0T2ZQYWdlLFxuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5nb29nbGVDYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5oYWxmUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZmx1aWQsXG4gICAgICAgIF0sXG4gICAgICAgIGRlc2t0b3A6IFtcbiAgICAgICAgICAgIGFkU2l6ZXMub3V0T2ZQYWdlLFxuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5nb29nbGVDYXJkLFxuICAgICAgICAgICAgYWRTaXplcy5oYWxmUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZmx1aWQsXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICAnbGl2ZWJsb2ctdG9wJzoge1xuICAgICAgICBtb2JpbGU6IFthZFNpemVzLm91dE9mUGFnZSwgYWRTaXplcy5lbXB0eSwgYWRTaXplcy5tcHUsIGFkU2l6ZXMuZmx1aWRdLFxuICAgICAgICB0YWJsZXQ6IFtdLFxuICAgICAgICBkZXNrdG9wOiBbXSxcbiAgICB9LFxuICAgICdtZXJjaGFuZGlzaW5nLWhpZ2gnOiB7XG4gICAgICAgIG1vYmlsZTogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5tZXJjaGFuZGlzaW5nSGlnaCxcbiAgICAgICAgICAgIGFkU2l6ZXMuZmx1aWQsXG4gICAgICAgICAgICBhZFNpemVzLm1wdSxcbiAgICAgICAgXSxcbiAgICAgICAgdGFibGV0OiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLm1lcmNoYW5kaXNpbmdIaWdoLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgXSxcbiAgICAgICAgZGVza3RvcDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5tZXJjaGFuZGlzaW5nSGlnaCxcbiAgICAgICAgICAgIGFkU2l6ZXMuZmx1aWQsXG4gICAgICAgICAgICBhZFNpemVzLmJpbGxib2FyZCxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgIG1lcmNoYW5kaXNpbmc6IHtcbiAgICAgICAgbW9iaWxlOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dE9mUGFnZSxcbiAgICAgICAgICAgIGFkU2l6ZXMuZW1wdHksXG4gICAgICAgICAgICBhZFNpemVzLm1lcmNoYW5kaXNpbmcsXG4gICAgICAgICAgICBhZFNpemVzLmZsdWlkLFxuICAgICAgICAgICAgYWRTaXplcy5tcHUsXG4gICAgICAgIF0sXG4gICAgICAgIHRhYmxldDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5tZXJjaGFuZGlzaW5nLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgXSxcbiAgICAgICAgZGVza3RvcDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5tZXJjaGFuZGlzaW5nLFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgICAgIGFkU2l6ZXMuYmlsbGJvYXJkLFxuICAgICAgICBdLFxuICAgIH0sXG4gICAgc3VydmV5OiB7XG4gICAgICAgIGRlc2t0b3A6IFthZFNpemVzLm91dE9mUGFnZV0sXG4gICAgfSxcbiAgICBjYXJyb3Q6IHtcbiAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5mbHVpZF0sXG4gICAgfSxcbiAgICAnbW9iaWxlLXN0aWNreSc6IHtcbiAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5tb2JpbGVzdGlja3ksIGFkU2l6ZXMuZW1wdHksIGNyZWF0ZUFkU2l6ZSgzMDAsIDUwKV0sXG4gICAgfSxcbiAgICAnY3Jvc3N3b3JkLWJhbm5lci1tb2JpbGUnOiB7XG4gICAgICAgIG1vYmlsZTogW2FkU2l6ZXMubW9iaWxlc3RpY2t5XSxcbiAgICB9LFxuICAgICdmb290YmFsbC1yaWdodCc6IHtcbiAgICAgICAgZGVza3RvcDogW1xuICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgYWRTaXplcy5za3lzY3JhcGVyLFxuICAgICAgICAgICAgYWRTaXplcy5oYWxmUGFnZSxcbiAgICAgICAgXSxcbiAgICB9LFxuICAgICdhcnRpY2xlLWVuZCc6IHtcbiAgICAgICAgbW9iaWxlOiBbXSwgLy8gTWFwcGluZ3MgYXJlIGR5bmFtaWNhbGx5IGFkZGVkIGZvciB0aGlzIHNsb3QgdXNpbmcgYWRkaXRpb25hbFNpemVzXG4gICAgfSxcbiAgICBleGNsdXNpb246IHtcbiAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5lbXB0eV0sXG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBAZGVwcmVjYXRlZCBVc2UgYHNsb3RTaXplTWFwcGluZ3NbJ3Nwb25zb3ItbG9nbyddYCBpbnN0ZWFkXG4gICAgICovXG4gICAgZXh0ZXJuYWw6IHtcbiAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5vdXRPZlBhZ2UsIGFkU2l6ZXMuZW1wdHksIGFkU2l6ZXMuZmx1aWQsIGFkU2l6ZXMubXB1XSxcbiAgICB9LFxuICAgICdzcG9uc29yLWxvZ28nOiB7XG4gICAgICAgIG1vYmlsZTogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRPZlBhZ2UsXG4gICAgICAgICAgICBhZFNpemVzLmVtcHR5LFxuICAgICAgICAgICAgYWRTaXplcy5mbHVpZCxcbiAgICAgICAgICAgIGFkU2l6ZXMuc3BvbnNvckxvZ28sXG4gICAgICAgIF0sXG4gICAgfSxcbiAgICBpbnRlcmFjdGl2ZToge1xuICAgICAgICAvLyBNYXBwaW5ncyBhcmUgZHluYW1pY2FsbHkgYWRkZWQgZm9yIHRoaXMgc2xvdCB1c2luZyBkYXRhIGF0dHJpYnV0ZXNcbiAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5vdXRPZlBhZ2UsIGFkU2l6ZXMuZW1wdHldLFxuICAgICAgICB0YWJsZXQ6IFthZFNpemVzLm91dE9mUGFnZSwgYWRTaXplcy5lbXB0eV0sXG4gICAgICAgIGRlc2t0b3A6IFthZFNpemVzLm91dE9mUGFnZSwgYWRTaXplcy5lbXB0eV0sXG4gICAgfSxcbn07XG5jb25zdCBnZXRBZFNpemUgPSAoc2l6ZSkgPT4gYWRTaXplc1tzaXplXTtcbi8qKlxuICogRmluZHMgdGhlIGFkIHNpemVzIHRoYXQgd2lsbCBiZSB1c2VkIGZvciBhIGJyZWFrcG9pbnQgZ2l2ZW4gYSBzaXplIG1hcHBpbmdcbiAqXG4gKiBJZiBhZCBzaXplcyBhcmUgZGVmaW5lZCBpbiB0aGUgc2l6ZSBtYXBwaW5nIGZvciB0aGUgc3BlY2lmaWVkIGJyZWFrcG9pbnQsIHdlIHVzZSB0aGF0LlxuICogSWYgbm8gc2l6ZXMgYXJlIGRlZmluZWQgZm9yIHRoZSBicmVha3BvaW50LCB1c2UgdGhlIG5leHQgc21hbGxlc3QgYnJlYWtwb2ludCB3aXRoIGRlZmluZWQgYWQgc2l6ZXMuXG4gKiBJZiBubyBzbWFsbGVyIGJyZWFrcG9pbnRzIGhhdmUgZGVmaW5lZCBhZCBzaXplcywgcmV0dXJuIGFuIGVtcHR5IGFycmF5XG4gKlxuICogRXhhbXBsZTpcbiAqIEZvciB0aGUgZm9sbG93aW5nIHNsb3RTaXplTWFwcGluZ3M6XG4gKiAgICAgaW5saW5lOiB7XG4gKiAgICAgICAgIHBoYWJsZXQ6IFthZFNpemVzLm1wdV0sXG4gKiAgICAgICAgIGRlc2t0b3A6IFthZFNpemVzLmJpbGxib2FyZF1cbiAqICAgICB9XG4gKiB0aGUgYXBwbGllZCBzaXplcyBmb3IgZWFjaCBicmVha3BvaW50IGZvciB0aGUgXCJpbmxpbmVcIiBzbG90IHdpbGwgYmU6XG4gKiAgICAgbW9iaWxlOiBbXVxuICogICAgIHBoYWJsZXQ6IFthZFNpemVzLm1wdV1cbiAqICAgICB0YWJsZXQ6IFthZFNpemVzLm1wdV1cbiAqICAgICBkZXNrdG9wOiBbYWRTaXplcy5iaWxsYm9hcmRdXG4gKlxuICogU2VlIGFkLXNpemVzLnRlc3QudHMgZm9yIG1vcmUgZXhhbXBsZXNcbiAqL1xuY29uc3QgZmluZEFwcGxpZWRTaXplc0ZvckJyZWFrcG9pbnQgPSAoc2l6ZU1hcHBpbmdzLCBicmVha3BvaW50KSA9PiB7XG4gICAgaWYgKCFpc0JyZWFrcG9pbnQoYnJlYWtwb2ludCkpIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBsZXQgYnJlYWtwb2ludEluZGV4ID0gYnJlYWtwb2ludHMuZmluZEluZGV4KChiKSA9PiBiID09PSBicmVha3BvaW50KTtcbiAgICB3aGlsZSAoYnJlYWtwb2ludEluZGV4ID49IDApIHtcbiAgICAgICAgY29uc3QgYnJlYWtwb2ludFRvVHJ5ID0gYnJlYWtwb2ludHNbYnJlYWtwb2ludEluZGV4XTtcbiAgICAgICAgY29uc3Qgc2l6ZU1hcHBpbmcgPSBzaXplTWFwcGluZ3NbYnJlYWtwb2ludFRvVHJ5XTtcbiAgICAgICAgaWYgKHNpemVNYXBwaW5nPy5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiBzaXplTWFwcGluZztcbiAgICAgICAgfVxuICAgICAgICBicmVha3BvaW50SW5kZXgtLTtcbiAgICB9XG4gICAgLy8gVGhlcmUgYXJlIG5vIHNpemUgbWFwcGluZ3MgZGVmaW5lZCBmb3IgYW55IHNpemUgc21hbGxlciB0aGFuIHRoZSBicmVha3BvaW50XG4gICAgcmV0dXJuIFtdO1xufTtcbi8vIEV4cG9ydCBmb3IgdGVzdGluZ1xuZXhwb3J0IGNvbnN0IF8gPSB7IGNyZWF0ZUFkU2l6ZSB9O1xuZXhwb3J0IHsgQWRTaXplLCBhZFNpemVzLCBzdGFuZGFyZEFkU2l6ZXMsIG91dHN0cmVhbVNpemVzLCBnZXRBZFNpemUsIHNsb3RTaXplTWFwcGluZ3MsIGNyZWF0ZUFkU2l6ZSwgZmluZEFwcGxpZWRTaXplc0ZvckJyZWFrcG9pbnQsIH07XG4iLCIvKipcbiAqIEJyZWFrcG9pbnRzIG9yZGVyZWQgZnJvbSBzbWFsbGVzdCB0byBsYXJnZXN0XG4gKi9cbmNvbnN0IGJyZWFrcG9pbnRzID0gWydtb2JpbGUnLCAncGhhYmxldCcsICd0YWJsZXQnLCAnZGVza3RvcCcsICd3aWRlJ107XG5jb25zdCBpc0JyZWFrcG9pbnQgPSAocykgPT4gYnJlYWtwb2ludHMuaW5jbHVkZXMocyk7XG5leHBvcnQgeyBicmVha3BvaW50cywgaXNCcmVha3BvaW50IH07XG4iLCIvKipcbiAqIFVuaXQ6IG1pbGxpc2Vjb25kc1xuICovXG5leHBvcnQgY29uc3QgUFJFQklEX1RJTUVPVVQgPSAxNTAwO1xuIiwiaW1wb3J0IHsgZ2V0Q29va2llLCBpc1N0cmluZywgc3RvcmFnZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmNvbnN0IGVkaXRpb25Ub0NvdW50cnlDb2RlTWFwID0ge1xuICAgIFVLOiAnR0InLFxuICAgIFVTOiAnVVMnLFxuICAgIEFVOiAnQVUnLFxufTtcbmNvbnN0IGVkaXRpb25Ub0NvdW50cnlDb2RlID0gKGVkaXRpb25LZXkgPSAnVUsnKSA9PiBlZGl0aW9uVG9Db3VudHJ5Q29kZU1hcFtlZGl0aW9uS2V5XTtcbmNvbnN0IGNvdW50cnlDb29raWVOYW1lID0gJ0dVX2dlb19jb3VudHJ5JztcbmNvbnN0IGNvdW50cnlPdmVycmlkZU5hbWUgPSAnZ3UuZ2VvLm92ZXJyaWRlJztcbi8qXG4gICBUaGlzIG1ldGhvZCBjYW4gYmUgdXNlZCBhcyBhIG5vbiBhc3luYyB3YXkgb2YgZ2V0dGluZyB0aGUgY291bnRyeSBjb2RlXG4gICBhZnRlciBpbml0IGhhcyBiZWVuIGNhbGxlZC4gUmV0dXJuaW5nIGxvY2FsZSBzaG91bGQgY292ZXIgYWxsL21vc3RcbiAgIG9mIHRoZSBjYXNlcyBidXQgaWYgYSByYWNlIGNvbmRpdGlvbiBoYXBwZW4gb3IgdGhlIGNvb2tpZSBpcyBub3Qgc2V0LFxuICAgd2Uga2VlcCBmYWxsYmFja3MgdG8gY29va2llIG9yIGdlbyBmcm9tIGVkaXRpb24uXG4qL1xuY29uc3QgZ2V0Q291bnRyeUNvZGUgPSAoKSA9PiB7XG4gICAgY29uc3QgcGFnZUVkaXRpb24gPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuZWRpdGlvbjtcbiAgICBjb25zdCBtYXliZUNvdW50cnlPdmVycmlkZSA9IHN0b3JhZ2UubG9jYWwuZ2V0KGNvdW50cnlPdmVycmlkZU5hbWUpO1xuICAgIGNvbnN0IGNvdW50cnlPdmVycmlkZSA9IGlzU3RyaW5nKG1heWJlQ291bnRyeU92ZXJyaWRlKVxuICAgICAgICA/IG1heWJlQ291bnRyeU92ZXJyaWRlXG4gICAgICAgIDogbnVsbDtcbiAgICByZXR1cm4gKGNvdW50cnlPdmVycmlkZSA/P1xuICAgICAgICBnZXRDb29raWUoe1xuICAgICAgICAgICAgbmFtZTogY291bnRyeUNvb2tpZU5hbWUsXG4gICAgICAgICAgICBzaG91bGRNZW1vaXplOiB0cnVlLFxuICAgICAgICB9KSA/P1xuICAgICAgICBlZGl0aW9uVG9Db3VudHJ5Q29kZShwYWdlRWRpdGlvbikpO1xufTtcbmV4cG9ydCB7IGdldENvdW50cnlDb2RlIH07XG4iLCJpbXBvcnQgeyBnZXRDb3VudHJ5Q29kZSB9IGZyb20gJy4vY291bnRyeS1jb2RlJztcbi8vIGNhY2hlIHRoZSB1c2VycyBsb2NhdGlvbiBzbyB3ZSBvbmx5IGhhdmUgdG8gbG9vayBpdCB1cCBvbmNlXG5sZXQgZ2VvO1xuY29uc3QgY3VycmVudEdlb0xvY2F0aW9uID0gKCkgPT4ge1xuICAgIGdlbyA9IGdlbyA/PyBnZXRDb3VudHJ5Q29kZSgpO1xuICAgIHJldHVybiBnZW87XG59O1xuZXhwb3J0IGNvbnN0IGlzSW5VayA9ICgpID0+IGN1cnJlbnRHZW9Mb2NhdGlvbigpID09PSAnR0InO1xuZXhwb3J0IGNvbnN0IGlzSW5Vc2EgPSAoKSA9PiBjdXJyZW50R2VvTG9jYXRpb24oKSA9PT0gJ1VTJztcbmV4cG9ydCBjb25zdCBpc0luQ2FuYWRhID0gKCkgPT4gY3VycmVudEdlb0xvY2F0aW9uKCkgPT09ICdDQSc7XG5leHBvcnQgY29uc3QgaXNJbkF1c3RyYWxpYSA9ICgpID0+IGN1cnJlbnRHZW9Mb2NhdGlvbigpID09PSAnQVUnO1xuZXhwb3J0IGNvbnN0IGlzSW5OZXdaZWFsYW5kID0gKCkgPT4gY3VycmVudEdlb0xvY2F0aW9uKCkgPT09ICdOWic7XG5leHBvcnQgY29uc3QgaXNJblVzT3JDYSA9ICgpID0+IGlzSW5Vc2EoKSB8fCBpc0luQ2FuYWRhKCk7XG5leHBvcnQgY29uc3QgaXNJbkF1T3JOeiA9ICgpID0+IGlzSW5BdXN0cmFsaWEoKSB8fCBpc0luTmV3WmVhbGFuZCgpO1xuZXhwb3J0IGNvbnN0IGlzSW5Sb3cgPSAoKSA9PiAhaXNJblVrKCkgJiYgIWlzSW5Vc09yQ2EoKSAmJiAhaXNJbkF1T3JOeigpO1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgcmVzZXRNb2R1bGU6ICgpID0+IHtcbiAgICAgICAgZ2VvID0gdW5kZWZpbmVkO1xuICAgIH0sXG59O1xuIiwiaW1wb3J0IHsgZ2V0Q29va2llLCBpc1N0cmluZywgc3RvcmFnZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmNvbnN0IEtFWSA9ICdHVV9nZW9fY291bnRyeSc7XG5jb25zdCBLRVlfT1ZFUlJJREUgPSAnZ3UuZ2VvLm92ZXJyaWRlJztcbmNvbnN0IENPVU5UUllfUkVHRVggPSAvXltBLVpdezJ9JC87XG4vLyBiZXN0IGd1ZXNzIHRoYXQgd2UgaGF2ZSBhIHZhbGlkIGNvZGUsIHdpdGhvdXQgYWN0dWFsbHkgc2hpcHBpbmcgdGhlIGVudGlyZSBsaXN0XG5jb25zdCBpc1ZhbGlkQ291bnRyeUNvZGUgPSAoY291bnRyeSkgPT4gaXNTdHJpbmcoY291bnRyeSkgJiYgQ09VTlRSWV9SRUdFWC50ZXN0KGNvdW50cnkpO1xuLy8gd2UnbGwgY2FjaGUgYW55IHN1Y2Nlc3NmdWwgbG9va3VwcyBzbyB3ZSBvbmx5IGhhdmUgdG8gZG8gdGhpcyBvbmNlXG5sZXQgbG9jYWxlO1xuY29uc3QgZWRpdGlvblRvR2VvbG9jYXRpb25NYXAgPSB7XG4gICAgVUs6ICdHQicsXG4gICAgVVM6ICdVUycsXG4gICAgQVU6ICdBVScsXG59O1xuY29uc3QgZWRpdGlvblRvR2VvbG9jYXRpb24gPSAoZWRpdGlvbktleSkgPT4gZWRpdGlvblRvR2VvbG9jYXRpb25NYXBbZWRpdGlvbktleV07XG4vLyBqdXN0IHVzZWQgZm9yIHRlc3RzXG5leHBvcnQgY29uc3QgX19yZXNldENhY2hlZFZhbHVlID0gKCkgPT4gKGxvY2FsZSA9IHVuZGVmaW5lZCk7XG4vKipcbiAqIEZldGNoZXMgdGhlIHVzZXIncyBjdXJyZW50IGxvY2F0aW9uIGFzIGFuIElTTyAzMTY2LTEgYWxwaGEtMiBzdHJpbmcgZS5nLiAnR0InLCAnQVUnIGV0Y1xuICogTm90ZTogVGhpcyBoYXMgYmVlbiBjb3BpZWQgZnJvbSBndWFyZGlhbi1saWJzIGFuZCBtYWRlIHN5bmNyb25vdXMgYnkgb21taXRpbmcgdGhlIGNhbGwgdG9cbiAqIHRoZSBnZW9sb2NhdGlvbiBBUElcbiAqL1xuZXhwb3J0IGNvbnN0IGdldExvY2FsZSA9ICgpID0+IHtcbiAgICBpZiAobG9jYWxlKVxuICAgICAgICByZXR1cm4gbG9jYWxlO1xuICAgIC8vIHJldHVybiBvdmVycmlkZGVuIGdlbyBmcm9tIGxvY2FsU3RvcmFnZSwgdXNlZCBmb3IgY2hhbmdpbmcgZ2VvIG9ubHkgZm9yIGRldmVsb3BtZW50IHB1cnBvc2VzXG4gICAgY29uc3QgZ2VvT3ZlcnJpZGUgPSBzdG9yYWdlLmxvY2FsLmdldChLRVlfT1ZFUlJJREUpO1xuICAgIGlmIChpc1ZhbGlkQ291bnRyeUNvZGUoZ2VvT3ZlcnJpZGUpKSB7XG4gICAgICAgIHJldHVybiAobG9jYWxlID0gZ2VvT3ZlcnJpZGUpO1xuICAgIH1cbiAgICAvLyByZXR1cm4gbG9jYWxlIGZyb20gY29va2llIGlmIGl0IGV4aXN0c1xuICAgIGNvbnN0IHN0b3JlZCA9IGdldENvb2tpZSh7IG5hbWU6IEtFWSB9KTtcbiAgICBpZiAoc3RvcmVkICYmIGlzVmFsaWRDb3VudHJ5Q29kZShzdG9yZWQpKSB7XG4gICAgICAgIHJldHVybiAobG9jYWxlID0gc3RvcmVkKTtcbiAgICB9XG4gICAgLy8gcmV0dXJuIGxvY2FsZSBmcm9tIGVkaXRpb25cbiAgICBjb25zdCBlZGl0aW9uQ291bnRyeUNvZGUgPSBlZGl0aW9uVG9HZW9sb2NhdGlvbih3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuZWRpdGlvbik7XG4gICAgcmV0dXJuIChsb2NhbGUgPSBlZGl0aW9uQ291bnRyeUNvZGUpO1xufTtcbiIsImV4cG9ydCBjb25zdCBwb3N0TWVzc2FnZSA9IChtZXNzYWdlLCB0YXJnZXQsIHRhcmdldE9yaWdpbiA9ICcqJykgPT4ge1xuICAgIHRhcmdldC5wb3N0TWVzc2FnZShKU09OLnN0cmluZ2lmeShtZXNzYWdlKSwgeyB0YXJnZXRPcmlnaW4gfSk7XG59O1xuIiwiaW1wb3J0IHsgc3RvcmFnZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmNvbnN0IFBFUk1VVElWRV9LRVkgPSBgX3BhcG5zYDtcbmNvbnN0IFBFUk1VVElWRV9QRlBfS0VZID0gYF9wZGZwc2A7XG5jb25zdCBnZXRTZWdtZW50cyA9IChrZXkpID0+IHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCByYXdTZWdtZW50cyA9IHN0b3JhZ2UubG9jYWwuZ2V0UmF3KGtleSk7XG4gICAgICAgIGNvbnN0IHNlZ21lbnRzID0gcmF3U2VnbWVudHNcbiAgICAgICAgICAgID8gSlNPTi5wYXJzZShyYXdTZWdtZW50cylcbiAgICAgICAgICAgIDogbnVsbDtcbiAgICAgICAgaWYgKCFBcnJheS5pc0FycmF5KHNlZ21lbnRzKSlcbiAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgcmV0dXJuIHNlZ21lbnRzXG4gICAgICAgICAgICAuc2xpY2UoMCwgMjUwKVxuICAgICAgICAgICAgLm1hcCgocykgPT4gTnVtYmVyLnBhcnNlSW50KHMsIDEwKSlcbiAgICAgICAgICAgIC5maWx0ZXIoKG4pID0+IHR5cGVvZiBuID09PSAnbnVtYmVyJyAmJiAhTnVtYmVyLmlzTmFOKG4pKVxuICAgICAgICAgICAgLm1hcChTdHJpbmcpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG59O1xuY29uc3QgZ2V0UGVybXV0aXZlU2VnbWVudHMgPSAoKSA9PiBnZXRTZWdtZW50cyhQRVJNVVRJVkVfS0VZKTtcbmNvbnN0IGdldFBlcm11dGl2ZVBGUFNlZ21lbnRzID0gKCkgPT4gZ2V0U2VnbWVudHMoUEVSTVVUSVZFX1BGUF9LRVkpO1xuY29uc3QgY2xlYXJQZXJtdXRpdmVTZWdtZW50cyA9ICgpID0+IHtcbiAgICBzdG9yYWdlLmxvY2FsLnJlbW92ZShQRVJNVVRJVkVfS0VZKTtcbiAgICBzdG9yYWdlLmxvY2FsLnJlbW92ZShQRVJNVVRJVkVfUEZQX0tFWSk7XG59O1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgUEVSTVVUSVZFX0tFWSxcbiAgICBQRVJNVVRJVkVfUEZQX0tFWSxcbiAgICBnZXRTZWdtZW50cyxcbn07XG5leHBvcnQgeyBnZXRQZXJtdXRpdmVTZWdtZW50cywgZ2V0UGVybXV0aXZlUEZQU2VnbWVudHMsIGNsZWFyUGVybXV0aXZlU2VnbWVudHMsIH07XG4iLCJpbXBvcnQgeyBnZXRNZWFzdXJlcywgaXNOb25OdWxsYWJsZSwgbG9nLCBvbkNvbnNlbnQgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBFdmVudFRpbWVyIH0gZnJvbSAnLi9ldmVudC10aW1lcic7XG52YXIgRW5kcG9pbnRzO1xuKGZ1bmN0aW9uIChFbmRwb2ludHMpIHtcbiAgICBFbmRwb2ludHNbXCJDT0RFXCJdID0gXCIvL3BlcmZvcm1hbmNlLWV2ZW50cy5jb2RlLmRldi1ndWFyZGlhbmFwaXMuY29tL2NvbW1lcmNpYWwtbWV0cmljc1wiO1xuICAgIEVuZHBvaW50c1tcIlBST0RcIl0gPSBcIi8vcGVyZm9ybWFuY2UtZXZlbnRzLmd1YXJkaWFuYXBpcy5jb20vY29tbWVyY2lhbC1tZXRyaWNzXCI7XG59KShFbmRwb2ludHMgfHwgKEVuZHBvaW50cyA9IHt9KSk7XG5sZXQgY29tbWVyY2lhbE1ldHJpY3NQYXlsb2FkID0ge1xuICAgIHBhZ2Vfdmlld19pZDogdW5kZWZpbmVkLFxuICAgIGJyb3dzZXJfaWQ6IHVuZGVmaW5lZCxcbiAgICBwbGF0Zm9ybTogJ05FWFRfR0VOJyxcbiAgICBtZXRyaWNzOiBbXSxcbiAgICBwcm9wZXJ0aWVzOiBbXSxcbn07XG5sZXQgZGV2UHJvcGVydGllcyA9IFtdO1xubGV0IGFkQmxvY2tlclByb3BlcnRpZXMgPSBbXTtcbmxldCBlbmRwb2ludDtcbmNvbnN0IHNldEVuZHBvaW50ID0gKGlzRGV2KSA9PiAoZW5kcG9pbnQgPSBpc0RldiA/IEVuZHBvaW50cy5DT0RFIDogRW5kcG9pbnRzLlBST0QpO1xuY29uc3Qgc2V0RGV2UHJvcGVydGllcyA9IChpc0RldikgPT4gKGRldlByb3BlcnRpZXMgPSBpc0RldlxuICAgID8gW3sgbmFtZTogJ2lzRGV2JywgdmFsdWU6IHdpbmRvdy5sb2NhdGlvbi5ob3N0bmFtZSB9XVxuICAgIDogW10pO1xuY29uc3Qgc2V0QWRCbG9ja2VyUHJvcGVydGllcyA9IChhZEJsb2NrZXJJblVzZSkgPT4ge1xuICAgIGFkQmxvY2tlclByb3BlcnRpZXMgPVxuICAgICAgICBhZEJsb2NrZXJJblVzZSAhPT0gdW5kZWZpbmVkXG4gICAgICAgICAgICA/IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG5hbWU6ICdhZEJsb2NrZXJJblVzZScsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiBhZEJsb2NrZXJJblVzZS50b1N0cmluZygpLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdXG4gICAgICAgICAgICA6IFtdO1xufTtcbmNvbnN0IHRyYW5zZm9ybVRvT2JqZWN0RW50cmllcyA9IChldmVudFRpbWVyUHJvcGVydGllcykgPT4ge1xuICAgIC8vIFRyYW5zZm9ybXMgb2JqZWN0IHtrZXk6IHZhbHVlfSBwYWlycyBpbnRvIGFuIGFycmF5IG9mIFtrZXksIHZhbHVlXSBhcnJheXNcbiAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMoZXZlbnRUaW1lclByb3BlcnRpZXMpO1xufTtcbmNvbnN0IG1hcEV2ZW50VGltZXJQcm9wZXJ0aWVzVG9TdHJpbmcgPSAocHJvcGVydGllcykgPT4ge1xuICAgIHJldHVybiBwcm9wZXJ0aWVzLm1hcCgoW25hbWUsIHZhbHVlXSkgPT4gKHtcbiAgICAgICAgbmFtZTogU3RyaW5nKG5hbWUpLFxuICAgICAgICB2YWx1ZTogU3RyaW5nKHZhbHVlKSxcbiAgICB9KSk7XG59O1xuY29uc3Qgcm91bmRUaW1lU3RhbXAgPSAoZXZlbnRzLCBtZWFzdXJlcykgPT4ge1xuICAgIGNvbnN0IHJvdW5kZWRFdmVudHMgPSBldmVudHMubWFwKCh7IG5hbWUsIHRzIH0pID0+ICh7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIHZhbHVlOiBNYXRoLmNlaWwodHMpLFxuICAgIH0pKTtcbiAgICBjb25zdCByb3VuZGVkTWVhc3VyZXMgPSBtZWFzdXJlcy5tYXAoKHsgbmFtZSwgZHVyYXRpb24gfSkgPT4gKHtcbiAgICAgICAgbmFtZSxcbiAgICAgICAgdmFsdWU6IE1hdGguY2VpbChkdXJhdGlvbiksXG4gICAgfSkpO1xuICAgIHJldHVybiBbLi4ucm91bmRlZEV2ZW50cywgLi4ucm91bmRlZE1lYXN1cmVzXTtcbn07XG5mdW5jdGlvbiBzZW5kTWV0cmljcygpIHtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCAnQWJvdXQgdG8gc2VuZCBjb21tZXJjaWFsIG1ldHJpY3MnLCBjb21tZXJjaWFsTWV0cmljc1BheWxvYWQpO1xuICAgIHZvaWQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgICAgbWV0aG9kOiAnUE9TVCcsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGNvbW1lcmNpYWxNZXRyaWNzUGF5bG9hZCksXG4gICAgICAgIGtlZXBhbGl2ZTogdHJ1ZSxcbiAgICAgICAgY2FjaGU6ICduby1zdG9yZScsXG4gICAgICAgIG1vZGU6ICduby1jb3JzJyxcbiAgICB9KTtcbn1cbi8qKlxuICogR2F0aGVyIGhvdyBtYW55IHRpbWVzIHRoZSB1c2VyIGhhcyBleHBlcmllbmNlZCB0aGUg4oCcb2ZmbGluZeKAnSBldmVudFxuICogQHNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvV2luZG93L29mZmxpbmVfZXZlbnRcbiAqXG4gKiBUaGlzIHZhbHVlIHNob3VsZCBiZSBmZXRjaGVkIGFzIGxhdGUgYXMgcG9zc2libGUgaW4gdGhlIHBhZ2UgbGlmZWN5Y2xlLFxuICogdG8gZ2V0IGFuIGFjY3VyYXRlIHZhbHVlLlxuICpcbiAqIFJlbGV2YW50IGZvciBhbiBAZ3VhcmRpYW4vb3Blbi1qb3VybmFsaXNtIGludmVzdGlnYXRpb24uXG4gKi9cbmNvbnN0IGdldE9mZmxpbmVDb3VudCA9ICgpID0+IHR5cGVvZiB3aW5kb3cuZ3VhcmRpYW4ub2ZmbGluZUNvdW50ID09PSAnbnVtYmVyJ1xuICAgID8gW1xuICAgICAgICB7XG4gICAgICAgICAgICBuYW1lOiAnb2ZmbGluZUNvdW50JyxcbiAgICAgICAgICAgIHZhbHVlOiB3aW5kb3cuZ3VhcmRpYW4ub2ZmbGluZUNvdW50LFxuICAgICAgICB9LFxuICAgIF1cbiAgICA6IFtdO1xuLyoqXG4gKiBNZWFzdXJlcyBhZGRlZCB3aXRoIEBndWFyZGlhbi9saWJz4oCZcyBgc3RhcnRQZXJmb3JtYW5jZU1lYXN1cmVgXG4gKlxuICogQWxsb3dzIGZvciBtb3JlIGdyYW51bGFyIG1vbml0b3Jpbmcgb2Ygd2ViIHBhZ2UgcGVyZm9ybWFuY2UuXG4gKi9cbmNvbnN0IGdldFBlcmZvcm1hbmNlTWVhc3VyZXMgPSAoLi4udGVhbXMpID0+IGdldE1lYXN1cmVzKHRlYW1zKS5tYXAoKHsgZGV0YWlsOiB7IHN1YnNjcmlwdGlvbiwgbmFtZSwgYWN0aW9uIH0sIGR1cmF0aW9uIH0pID0+ICh7XG4gICAgbmFtZTogW3N1YnNjcmlwdGlvbiwgbmFtZSwgYWN0aW9uXS5maWx0ZXIoaXNOb25OdWxsYWJsZSkuam9pbignXycpLFxuICAgIHZhbHVlOiBkdXJhdGlvbixcbn0pKTtcbmZ1bmN0aW9uIGdhdGhlck1ldHJpY3NPblBhZ2VVbmxvYWQoKSB7XG4gICAgLy8gQXNzZW1ibGUgY29tbWVyY2lhbCBwcm9wZXJ0aWVzIGFuZCBtZXRyaWNzXG4gICAgY29uc3QgZXZlbnRUaW1lciA9IEV2ZW50VGltZXIuZ2V0KCk7XG4gICAgY29uc3QgdHJhbnNmb3JtZWRFbnRyaWVzID0gdHJhbnNmb3JtVG9PYmplY3RFbnRyaWVzKGV2ZW50VGltZXIucHJvcGVydGllcyk7XG4gICAgY29uc3QgZmlsdGVyZWRFdmVudFRpbWVyUHJvcGVydGllcyA9IHRyYW5zZm9ybWVkRW50cmllcy5maWx0ZXIoKGl0ZW0pID0+IHR5cGVvZiBpdGVtWzFdICE9PSAndW5kZWZpbmVkJyk7XG4gICAgY29uc3QgbWFwcGVkRXZlbnRUaW1lclByb3BlcnRpZXMgPSBtYXBFdmVudFRpbWVyUHJvcGVydGllc1RvU3RyaW5nKGZpbHRlcmVkRXZlbnRUaW1lclByb3BlcnRpZXMpO1xuICAgIGNvbnN0IHByb3BlcnRpZXMgPSBtYXBwZWRFdmVudFRpbWVyUHJvcGVydGllc1xuICAgICAgICAuY29uY2F0KGRldlByb3BlcnRpZXMpXG4gICAgICAgIC5jb25jYXQoYWRCbG9ja2VyUHJvcGVydGllcyk7XG4gICAgY29tbWVyY2lhbE1ldHJpY3NQYXlsb2FkLnByb3BlcnRpZXMgPSBwcm9wZXJ0aWVzO1xuICAgIGNvbnN0IG1ldHJpY3MgPSByb3VuZFRpbWVTdGFtcChldmVudFRpbWVyLm1hcmtzLCBldmVudFRpbWVyLm1lYXN1cmVzKVxuICAgICAgICAuY29uY2F0KGdldE9mZmxpbmVDb3VudCgpKVxuICAgICAgICAuY29uY2F0KGdldFBlcmZvcm1hbmNlTWVhc3VyZXMoJ2RvdGNvbScpKTtcbiAgICBjb21tZXJjaWFsTWV0cmljc1BheWxvYWQubWV0cmljcyA9IG1ldHJpY3M7XG4gICAgc2VuZE1ldHJpY3MoKTtcbn1cbmNvbnN0IGxpc3RlbmVyID0gKGUpID0+IHtcbiAgICBpZiAod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zaG91bGRTZW5kQ29tbWVyY2lhbE1ldHJpY3MpIHtcbiAgICAgICAgc3dpdGNoIChlLnR5cGUpIHtcbiAgICAgICAgICAgIGNhc2UgJ3Zpc2liaWxpdHljaGFuZ2UnOlxuICAgICAgICAgICAgICAgIGlmIChkb2N1bWVudC52aXNpYmlsaXR5U3RhdGUgPT09ICdoaWRkZW4nKSB7XG4gICAgICAgICAgICAgICAgICAgIGdhdGhlck1ldHJpY3NPblBhZ2VVbmxvYWQoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgY2FzZSAncGFnZWhpZGUnOlxuICAgICAgICAgICAgICAgIGdhdGhlck1ldHJpY3NPblBhZ2VVbmxvYWQoKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICB9XG59O1xuY29uc3QgYWRkVmlzaWJpbGl0eUxpc3RlbmVycyA9ICgpID0+IHtcbiAgICAvLyBSZXBvcnQgYWxsIGF2YWlsYWJsZSBtZXRyaWNzIHdoZW4gdGhlIHBhZ2UgaXMgdW5sb2FkZWQgb3IgaW4gYmFja2dyb3VuZC5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIGxpc3RlbmVyLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgLy8gU2FmYXJpIGRvZXMgbm90IHJlbGlhYmx5IGZpcmUgdGhlIGB2aXNpYmlsaXR5Y2hhbmdlYCBvbiBwYWdlIHVubG9hZC5cbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcigncGFnZWhpZGUnLCBsaXN0ZW5lciwgeyBvbmNlOiB0cnVlIH0pO1xufTtcbmNvbnN0IGNoZWNrQ29uc2VudCA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBjb25zZW50U3RhdGUgPSBhd2FpdCBvbkNvbnNlbnQoKTtcbiAgICBpZiAoY29uc2VudFN0YXRlLnRjZnYyKSB7XG4gICAgICAgIC8vIFRDRnYyIG1vZGUgLSBjaGVjayBmb3IgY29uc2VudFxuICAgICAgICBjb25zdCBjb25zZW50cyA9IGNvbnNlbnRTdGF0ZS50Y2Z2Mi5jb25zZW50cztcbiAgICAgICAgY29uc3QgUkVRVUlSRURfQ09OU0VOVFMgPSBbNywgOF07XG4gICAgICAgIHJldHVybiBSRVFVSVJFRF9DT05TRU5UUy5ldmVyeSgoY29uc2VudCkgPT4gY29uc2VudHNbY29uc2VudF0pO1xuICAgIH1cbiAgICAvLyBub24tVENGdjIgbW9kZSAtIGRvbid0IGNoZWNrIGZvciBjb25zZW50XG4gICAgcmV0dXJuIHRydWU7XG59O1xuLyoqXG4gKiBBIG1ldGhvZCB0byBhc3luY2hyb25vdXNseSBzZW5kIG1ldHJpY3MgYWZ0ZXIgaW5pdGlhbGl6YXRpb24uXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGJ5cGFzc0NvbW1lcmNpYWxNZXRyaWNzU2FtcGxpbmcoKSB7XG4gICAgaWYgKCF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLmNvbW1lcmNpYWxNZXRyaWNzSW5pdGlhbGlzZWQpIHtcbiAgICAgICAgY29uc29sZS53YXJuKCdpbml0Q29tbWVyY2lhbE1ldHJpY3Mgbm90IHlldCBpbml0aWFsaXNlZCcpO1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGNvbnNlbnRlZCA9IGF3YWl0IGNoZWNrQ29uc2VudCgpO1xuICAgIGlmIChjb25zZW50ZWQpIHtcbiAgICAgICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zaG91bGRTZW5kQ29tbWVyY2lhbE1ldHJpY3MgPSB0cnVlO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgXCJNZXRyaWNzIHdvbid0IGJlIHNlbnQgYmVjYXVzZSBjb25zZW50IHdhc24ndCBnaXZlblwiKTtcbiAgICB9XG59XG4vKipcbiAqIEEgbWV0aG9kIHRvIGluaXRpYWxpc2UgbWV0cmljcy5cbiAqIE5vdGU6IHRoaXMgaXMgaW5pdGlhbGlzZWQgaW4gdGhlIGZyb250ZW5kL0RDUiBidW5kbGVzLCBub3QgdGhlIGNvbW1lcmNpYWwgYnVuZGxlLlxuICogQHBhcmFtIGluaXQucGFnZVZpZXdJZCAtIGlkZW50aWZpZXMgdGhlIHBhZ2Ugdmlldy4gVXN1YWxseSBhdmFpbGFibGUgb24gYGd1YXJkaWFuLmNvbmZpZy5vcGhhbi5wYWdlVmlld0lkYC4gRGVmYXVsdHMgdG8gYG51bGxgXG4gKiBAcGFyYW0gaW5pdC5icm93c2VySWQgLSBpZGVudGlmaWVzIHRoZSBicm93c2VyLiBVc3VhbGx5IGF2YWlsYWJsZSB2aWEgYGdldENvb2tpZSh7IG5hbWU6ICdid2lkJyB9KWAuIERlZmF1bHRzIHRvIGBudWxsYFxuICogQHBhcmFtIGluaXQuaXNEZXYgLSB1c2VkIHRvIGRldGVybWluZSB3aGV0aGVyIHRvIHVzZSBDT0RFIG9yIFBST0QgZW5kcG9pbnRzLlxuICogQHBhcmFtIGluaXQuYWRCbG9ja2VySW5Vc2UgLSBpbmRpY2F0ZXMgd2hldGhlciBvciBub3QgYW4gYWRibG9ja2VyIGlzIGJlaW5nIHVzZWQuXG4gKiBAcGFyYW0gaW5pdC5zYW1wbGluZyAtIHJhdGUgYXQgd2hpY2ggdG8gc2FtcGxlIGNvbW1lcmNpYWwgbWV0cmljcyAtIHRoZSBkZWZhdWx0IGlzIHRvIHNlbmQgZm9yIDElIG9mIHBhZ2V2aWV3c1xuICovXG5hc3luYyBmdW5jdGlvbiBpbml0Q29tbWVyY2lhbE1ldHJpY3MoeyBwYWdlVmlld0lkLCBicm93c2VySWQsIGlzRGV2LCBhZEJsb2NrZXJJblVzZSwgc2FtcGxpbmcgPSAxIC8gMTAwLCB9KSB7XG4gICAgY29tbWVyY2lhbE1ldHJpY3NQYXlsb2FkLnBhZ2Vfdmlld19pZCA9IHBhZ2VWaWV3SWQ7XG4gICAgY29tbWVyY2lhbE1ldHJpY3NQYXlsb2FkLmJyb3dzZXJfaWQgPSBicm93c2VySWQ7XG4gICAgc2V0RW5kcG9pbnQoaXNEZXYpO1xuICAgIHNldERldlByb3BlcnRpZXMoaXNEZXYpO1xuICAgIHNldEFkQmxvY2tlclByb3BlcnRpZXMoYWRCbG9ja2VySW5Vc2UpO1xuICAgIGFkZFZpc2liaWxpdHlMaXN0ZW5lcnMoKTtcbiAgICBpZiAod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5jb21tZXJjaWFsTWV0cmljc0luaXRpYWxpc2VkKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5jb21tZXJjaWFsTWV0cmljc0luaXRpYWxpc2VkID0gdHJ1ZTtcbiAgICBjb25zdCB1c2VySXNJblNhbXBsaW5nR3JvdXAgPSBNYXRoLnJhbmRvbSgpIDw9IHNhbXBsaW5nO1xuICAgIGlmIChpc0RldiB8fCB1c2VySXNJblNhbXBsaW5nR3JvdXApIHtcbiAgICAgICAgY29uc3QgY29uc2VudGVkID0gYXdhaXQgY2hlY2tDb25zZW50KCk7XG4gICAgICAgIGlmIChjb25zZW50ZWQpIHtcbiAgICAgICAgICAgIHdpbmRvdy5ndWFyZGlhbi5jb25maWcuc2hvdWxkU2VuZENvbW1lcmNpYWxNZXRyaWNzID0gdHJ1ZTtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsIFwiTWV0cmljcyB3b24ndCBiZSBzZW50IGJlY2F1c2UgY29uc2VudCB3YXNuJ3QgZ2l2ZW5cIik7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbmV4cG9ydCBjb25zdCBfID0ge1xuICAgIEVuZHBvaW50cyxcbiAgICBzZXRFbmRwb2ludCxcbiAgICBtYXBFdmVudFRpbWVyUHJvcGVydGllc1RvU3RyaW5nLFxuICAgIHJvdW5kVGltZVN0YW1wLFxuICAgIHRyYW5zZm9ybVRvT2JqZWN0RW50cmllcyxcbiAgICByZXNldDogKCkgPT4ge1xuICAgICAgICB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLmNvbW1lcmNpYWxNZXRyaWNzSW5pdGlhbGlzZWQgPSBmYWxzZTtcbiAgICAgICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zaG91bGRTZW5kQ29tbWVyY2lhbE1ldHJpY3MgPSBmYWxzZTtcbiAgICAgICAgY29tbWVyY2lhbE1ldHJpY3NQYXlsb2FkID0ge1xuICAgICAgICAgICAgcGFnZV92aWV3X2lkOiB1bmRlZmluZWQsXG4gICAgICAgICAgICBicm93c2VyX2lkOiB1bmRlZmluZWQsXG4gICAgICAgICAgICBwbGF0Zm9ybTogJ05FWFRfR0VOJyxcbiAgICAgICAgICAgIG1ldHJpY3M6IFtdLFxuICAgICAgICAgICAgcHJvcGVydGllczogW10sXG4gICAgICAgIH07XG4gICAgICAgIHJlbW92ZUV2ZW50TGlzdGVuZXIoJ3Zpc2liaWxpdHljaGFuZ2UnLCBsaXN0ZW5lcik7XG4gICAgICAgIHJlbW92ZUV2ZW50TGlzdGVuZXIoJ3BhZ2VoaWRlJywgbGlzdGVuZXIpO1xuICAgIH0sXG59O1xuZXhwb3J0IHsgYnlwYXNzQ29tbWVyY2lhbE1ldHJpY3NTYW1wbGluZywgaW5pdENvbW1lcmNpYWxNZXRyaWNzLCBjaGVja0NvbnNlbnQgfTtcbiIsImltcG9ydCB7IGNtcCwgZ2V0Q29uc2VudEZvciwgZ2V0Q29va2llLCBpc1N0cmluZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IHN1cHBvcnRzUGVyZm9ybWFuY2VBUEkgfSBmcm9tICcuLi9ldmVudC10aW1lcic7XG5pbXBvcnQgeyBnZXRMb2NhbGUgfSBmcm9tICcuLi9nZW8vZ2V0LWxvY2FsZSc7XG5pbXBvcnQgeyBnZXRDb250ZW50VGFyZ2V0aW5nIH0gZnJvbSAnLi9jb250ZW50JztcbmltcG9ydCB7IGdldFBlcnNvbmFsaXNlZFRhcmdldGluZyB9IGZyb20gJy4vcGVyc29uYWxpc2VkJztcbmltcG9ydCB7IGdldFNlc3Npb25UYXJnZXRpbmcgfSBmcm9tICcuL3Nlc3Npb24nO1xuaW1wb3J0IHsgZ2V0TG9jYWxIb3VyLCBnZXRTaGFyZWRUYXJnZXRpbmcgfSBmcm9tICcuL3NoYXJlZCc7XG5pbXBvcnQgeyBnZXRWaWV3cG9ydFRhcmdldGluZyB9IGZyb20gJy4vdmlld3BvcnQnO1xuY29uc3QgZmlsdGVyVmFsdWVzID0gKHBhZ2VUYXJnZXRzKSA9PiB7XG4gICAgY29uc3QgZmlsdGVyZWQgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGtleSBpbiBwYWdlVGFyZ2V0cykge1xuICAgICAgICBjb25zdCB2YWx1ZSA9IHBhZ2VUYXJnZXRzW2tleV07XG4gICAgICAgIGlmIChpc1N0cmluZyh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGZpbHRlcmVkW2tleV0gPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KHZhbHVlKSAmJlxuICAgICAgICAgICAgdmFsdWUubGVuZ3RoID4gMCAmJlxuICAgICAgICAgICAgdmFsdWUuZXZlcnkoaXNTdHJpbmcpKSB7XG4gICAgICAgICAgICBmaWx0ZXJlZFtrZXldID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGZpbHRlcmVkO1xufTtcbmNvbnN0IGxhc3RQZXJmb3JtYW5jZUVudHJ5SXNOYXZpZ2F0aW9uVHlwZSA9ICgpID0+IHtcbiAgICBpZiAoIXN1cHBvcnRzUGVyZm9ybWFuY2VBUEkoKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IG5hdmlnYXRpb25FdmVudHMgPSBwZXJmb3JtYW5jZS5nZXRFbnRyaWVzQnlUeXBlKCduYXZpZ2F0aW9uJyk7XG4gICAgY29uc3QgbGFzdE5hdmlnYXRpb25FdmVudCA9IG5hdmlnYXRpb25FdmVudHNbbmF2aWdhdGlvbkV2ZW50cy5sZW5ndGggLSAxXTtcbiAgICAvLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUGVyZm9ybWFuY2VFbnRyeS9lbnRyeVR5cGUjbmF2aWdhdGlvblxuICAgIHJldHVybiBsYXN0TmF2aWdhdGlvbkV2ZW50Py5lbnRyeVR5cGUgPT09ICduYXZpZ2F0aW9uJztcbn07XG5jb25zdCByZWZlcnJlck1hdGNoZXNIb3N0ID0gKHJlZmVycmVyKSA9PiB7XG4gICAgaWYgKCFyZWZlcnJlcikge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHJlZmVycmVyVXJsID0gbmV3IFVSTChyZWZlcnJlcik7XG4gICAgcmV0dXJuIHJlZmVycmVyVXJsLmhvc3RuYW1lID09PSB3aW5kb3cubG9jYXRpb24uaG9zdG5hbWU7XG59O1xuLy8gQSBjb25zZW50bGVzcyBmcmllbmRseSB3YXkgb2YgZGV0ZXJtaW5pbmcgaWYgdGhpcyBpcyB0aGUgdXNlcnMgZmlyc3QgdmlzaXQgdG8gdGhlIHBhZ2VcbmNvbnN0IGlzRmlyc3RWaXNpdCA9IChyZWZlcnJlcikgPT4ge1xuICAgIGlmIChzdXBwb3J0c1BlcmZvcm1hbmNlQVBJKCkgJiYgIWxhc3RQZXJmb3JtYW5jZUVudHJ5SXNOYXZpZ2F0aW9uVHlwZSgpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgcmV0dXJuICFyZWZlcnJlck1hdGNoZXNIb3N0KHJlZmVycmVyKTtcbn07XG5jb25zdCBidWlsZFBhZ2VUYXJnZXRpbmcgPSAoeyBhZEZyZWUsIGNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucywgY29uc2VudFN0YXRlLCBpc1NpZ25lZEluID0gZmFsc2UsIHlvdXR1YmUgPSBmYWxzZSwgfSkgPT4ge1xuICAgIGNvbnN0IHsgcGFnZSwgaXNEb3Rjb21SZW5kZXJpbmcgfSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWc7XG4gICAgY29uc3QgYWRGcmVlVGFyZ2V0aW5nID0gYWRGcmVlID8geyBhZjogJ3QnIH0gOiB7fTtcbiAgICBjb25zdCBzaGFyZWRBZFRhcmdldGluZyA9IHBhZ2Uuc2hhcmVkQWRUYXJnZXRpbmdcbiAgICAgICAgPyBnZXRTaGFyZWRUYXJnZXRpbmcocGFnZS5zaGFyZWRBZFRhcmdldGluZylcbiAgICAgICAgOiB7fTtcbiAgICBjb25zdCBjb250ZW50VGFyZ2V0aW5nID0gZ2V0Q29udGVudFRhcmdldGluZyh7XG4gICAgICAgIHdlYlB1YmxpY2F0aW9uRGF0ZTogcGFnZS53ZWJQdWJsaWNhdGlvbkRhdGUsXG4gICAgICAgIGVsaWdpYmxlRm9yRENSOiBwYWdlLmRjckNvdWxkUmVuZGVyLFxuICAgICAgICBwYXRoOiBgLyR7cGFnZS5wYWdlSWR9YCxcbiAgICAgICAgcmVuZGVyaW5nUGxhdGZvcm06IGlzRG90Y29tUmVuZGVyaW5nXG4gICAgICAgICAgICA/ICdkb3Rjb20tcmVuZGVyaW5nJ1xuICAgICAgICAgICAgOiAnZG90Y29tLXBsYXRmb3JtJyxcbiAgICAgICAgc2VjdGlvbjogcGFnZS5zZWN0aW9uLFxuICAgICAgICBzZW5zaXRpdmU6IHBhZ2UuaXNTZW5zaXRpdmUsXG4gICAgICAgIHZpZGVvTGVuZ3RoOiBwYWdlLnZpZGVvRHVyYXRpb24sXG4gICAgICAgIGtleXdvcmRzOiBzaGFyZWRBZFRhcmdldGluZy5rID8/IFtdLFxuICAgIH0pO1xuICAgIGNvbnN0IHJlZmVycmVyID0gZG9jdW1lbnQucmVmZXJyZXIgfHwgJyc7XG4gICAgY29uc3Qgc2Vzc2lvblRhcmdldGluZyA9IGdldFNlc3Npb25UYXJnZXRpbmcoe1xuICAgICAgICBhZFRlc3Q6IGdldENvb2tpZSh7IG5hbWU6ICdhZHRlc3QnLCBzaG91bGRNZW1vaXplOiB0cnVlIH0pLFxuICAgICAgICBjb3VudHJ5Q29kZTogZ2V0TG9jYWxlKCksXG4gICAgICAgIGxvY2FsSG91cjogZ2V0TG9jYWxIb3VyKCksXG4gICAgICAgIGlzU2lnbmVkSW4sXG4gICAgICAgIHBhZ2VWaWV3SWQ6IHdpbmRvdy5ndWFyZGlhbi5jb25maWcub3BoYW4ucGFnZVZpZXdJZCxcbiAgICAgICAgcGFydGljaXBhdGlvbnM6IHtcbiAgICAgICAgICAgIGNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucyxcbiAgICAgICAgICAgIHNlcnZlclNpZGVQYXJ0aWNpcGF0aW9uczogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy50ZXN0cyA/PyB7fSxcbiAgICAgICAgfSxcbiAgICAgICAgcmVmZXJyZXIsXG4gICAgfSk7XG4gICAgY29uc3QgZ2V0Vmlld3BvcnQgPSAoKSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB3aWR0aDogd2luZG93LmlubmVyV2lkdGggfHwgZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aCB8fCAwLFxuICAgICAgICAgICAgaGVpZ2h0OiB3aW5kb3cuaW5uZXJIZWlnaHQgfHwgZG9jdW1lbnQuYm9keS5jbGllbnRIZWlnaHQgfHwgMCxcbiAgICAgICAgfTtcbiAgICB9O1xuICAgIGNvbnN0IHZpZXdwb3J0VGFyZ2V0aW5nID0gZ2V0Vmlld3BvcnRUYXJnZXRpbmcoe1xuICAgICAgICB2aWV3UG9ydFdpZHRoOiBnZXRWaWV3cG9ydCgpLndpZHRoLFxuICAgICAgICBjbXBCYW5uZXJXaWxsU2hvdzogIWNtcC5oYXNJbml0aWFsaXNlZCgpIHx8IGNtcC53aWxsU2hvd1ByaXZhY3lNZXNzYWdlU3luYygpLFxuICAgIH0pO1xuICAgIGNvbnN0IHBlcnNvbmFsaXNlZFRhcmdldGluZyA9IGdldFBlcnNvbmFsaXNlZFRhcmdldGluZyh7XG4gICAgICAgIHN0YXRlOiBjb25zZW50U3RhdGUsXG4gICAgICAgIHlvdXR1YmUsXG4gICAgfSk7XG4gICAgY29uc3QgY29uc2VudGxlc3NUYXJnZXRpbmcgPSB7fTtcbiAgICBpZiAoIWdldENvbnNlbnRGb3IoJ2dvb2dsZXRhZycsIGNvbnNlbnRTdGF0ZSkpIHtcbiAgICAgICAgY29uc2VudGxlc3NUYXJnZXRpbmcuZmlyc3R2aXNpdCA9IGlzRmlyc3RWaXNpdChyZWZlcnJlcikgPyAndCcgOiAnZic7XG4gICAgfVxuICAgIGNvbnN0IHBhZ2VUYXJnZXRzID0ge1xuICAgICAgICAuLi5wZXJzb25hbGlzZWRUYXJnZXRpbmcsXG4gICAgICAgIC4uLnNoYXJlZEFkVGFyZ2V0aW5nLFxuICAgICAgICAuLi5hZEZyZWVUYXJnZXRpbmcsXG4gICAgICAgIC4uLmNvbnRlbnRUYXJnZXRpbmcsXG4gICAgICAgIC4uLnNlc3Npb25UYXJnZXRpbmcsXG4gICAgICAgIC4uLnZpZXdwb3J0VGFyZ2V0aW5nLFxuICAgICAgICAuLi5jb25zZW50bGVzc1RhcmdldGluZyxcbiAgICB9O1xuICAgIC8vIGZpbHRlciAhKHN0cmluZyB8IHN0cmluZ1tdKSBhbmQgZW1wdHkgdmFsdWVzXG4gICAgY29uc3QgcGFnZVRhcmdldGluZyA9IGZpbHRlclZhbHVlcyhwYWdlVGFyZ2V0cyk7XG4gICAgcmV0dXJuIHBhZ2VUYXJnZXRpbmc7XG59O1xuZXhwb3J0IHsgYnVpbGRQYWdlVGFyZ2V0aW5nLCBmaWx0ZXJWYWx1ZXMsIGdldExvY2FsSG91ciB9O1xuIiwiaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG4vKiAtLSBUeXBlcyAtLSAqL1xuY29uc3QgdmlkZW9MZW5ndGhzID0gW1xuICAgICcyNScsIC8vIFRPRE86IGNvbmZpcm0gdGhpcyBpcyBhIHJlYWwgdmFsdWVcbiAgICAnMzAnLFxuICAgICc2MCcsXG4gICAgJzkwJyxcbiAgICAnMTIwJyxcbiAgICAnMTUwJyxcbiAgICAnMTgwJyxcbiAgICAnMjEwJyxcbiAgICAnMjQwJyxcbiAgICAnMjcwJyxcbiAgICAnMzAwJyxcbl07XG4vKiAtLSBNZXRob2RzIC0tICovXG5jb25zdCBnZXRWaWRlb0xlbmd0aCA9ICh2aWRlb0xlbmd0aCkgPT4ge1xuICAgIGNvbnN0IGluZGV4ID0gTWF0aC5taW4oTWF0aC5jZWlsKHZpZGVvTGVuZ3RoIC8gMzApLCAxMCk7XG4gICAgcmV0dXJuIHZpZGVvTGVuZ3Roc1tpbmRleF0gPz8gbnVsbDtcbn07XG5jb25zdCBnZXRVcmxLZXl3b3JkcyA9ICh1cmwpID0+IHtcbiAgICBjb25zdCBsYXN0U2VnbWVudCA9IHVybFxuICAgICAgICAuc3BsaXQoJy8nKVxuICAgICAgICAuZmlsdGVyKEJvb2xlYW4pIC8vIFRoaXMgaGFuZGxlcyBhIHRyYWlsaW5nIHNsYXNoXG4gICAgICAgIC5zbGljZSgtMSlbMF07XG4gICAgcmV0dXJuIGlzU3RyaW5nKGxhc3RTZWdtZW50KSA/IGxhc3RTZWdtZW50LnNwbGl0KCctJykuZmlsdGVyKEJvb2xlYW4pIDogW107XG59O1xuY29uc3QgY29uY2F0VW5pcXVlID0gKGEsIGIpID0+IFtcbiAgICAuLi5uZXcgU2V0KFsuLi5hLCAuLi5iXSksXG5dO1xuLy8gXCIwXCIgbWVhbnMgY29udGVudCA8IDIgaG91cnMgb2xkXG4vLyBcIjFcIiBtZWFucyBjb250ZW50IGJldHdlZW4gMiBob3VycyBhbmQgMjQgaG91cnMgb2xkLlxuLy8gXCIyXCIgbWVhbnMgY29udGVudCBiZXR3ZWVuIDI0IGhvdXJzIGFuZCAzIGRheXMgb2xkXG4vLyBcIjNcIiBtZWFucyBjb250ZW50IGJldHdlZW4gMyBhbmQgNyBkYXlzIG9sZFxuLy8gXCI0XCIgbWVhbnMgY29udGVudCBiZXR3ZWVuIDcgZGF5cyBhbmQgMSBtb250aCBvbGRcbi8vIFwiNVwiIG1lYW5zIGNvbnRlbnQgYmV0d2VlbiAxIGFuZCAxMCBtb250aHMgb2xkXG4vLyBcIjZcIiBtZWFucyBjb250ZW50IGJldHdlZW4gMTAgYW5kIDE0IG1vbnRocyBvbGRcbi8vIFwiN1wiIG1lYW5zIGNvbnRlbnQgbW9yZSB0aGFuIDE0IG1vbnRocyBvbGRcbmNvbnN0IGNhbGN1bGF0ZVJlY2VudGx5UHVibGlzaGVkQnVja2V0ID0gKHdlYlB1YmxpY2F0aW9uRGF0ZSkgPT4ge1xuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgY29uc3QgaG91cnNTaW5jZVB1YmxpY2F0aW9uID0gKG5vdyAtIHdlYlB1YmxpY2F0aW9uRGF0ZSkgLyAxMDAwIC8gNjAgLyA2MDtcbiAgICBjb25zdCBkYXlzU2luY2VQdWJsaWNhdGlvbiA9IGhvdXJzU2luY2VQdWJsaWNhdGlvbiAvIDI0O1xuICAgIGNvbnN0IG1vbnRoc1NpbmNlUHVibGljYXRpb24gPSBkYXlzU2luY2VQdWJsaWNhdGlvbiAvIDMwOyAvLyBuZWFyIGVub3VnaCBmb3Igb3VyIHB1cnBvc2VzXG4gICAgaWYgKGhvdXJzU2luY2VQdWJsaWNhdGlvbiA8IDIpXG4gICAgICAgIHJldHVybiAnMCc7XG4gICAgaWYgKGhvdXJzU2luY2VQdWJsaWNhdGlvbiA8IDI0KVxuICAgICAgICByZXR1cm4gJzEnO1xuICAgIGlmIChkYXlzU2luY2VQdWJsaWNhdGlvbiA8IDMpXG4gICAgICAgIHJldHVybiAnMic7XG4gICAgaWYgKGRheXNTaW5jZVB1YmxpY2F0aW9uIDwgNylcbiAgICAgICAgcmV0dXJuICczJztcbiAgICBpZiAoZGF5c1NpbmNlUHVibGljYXRpb24gPCAzMClcbiAgICAgICAgcmV0dXJuICc0JztcbiAgICBpZiAobW9udGhzU2luY2VQdWJsaWNhdGlvbiA8IDEwKVxuICAgICAgICByZXR1cm4gJzUnO1xuICAgIGlmIChtb250aHNTaW5jZVB1YmxpY2F0aW9uIDwgMTQpXG4gICAgICAgIHJldHVybiAnNic7XG4gICAgcmV0dXJuICc3Jztcbn07XG5jb25zdCBnZXRDb250ZW50VGFyZ2V0aW5nID0gKHsgZWxpZ2libGVGb3JEQ1IsIHBhdGgsIHJlbmRlcmluZ1BsYXRmb3JtLCBzZWN0aW9uLCBzZW5zaXRpdmUsIHZpZGVvTGVuZ3RoLCB3ZWJQdWJsaWNhdGlvbkRhdGUsIGtleXdvcmRzLCB9KSA9PiB7XG4gICAgY29uc3QgdXJsa3cgPSBnZXRVcmxLZXl3b3JkcyhwYXRoKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBkY3JlOiBlbGlnaWJsZUZvckRDUiA/ICd0JyA6ICdmJyxcbiAgICAgICAgcmM6IGNhbGN1bGF0ZVJlY2VudGx5UHVibGlzaGVkQnVja2V0KHdlYlB1YmxpY2F0aW9uRGF0ZSksXG4gICAgICAgIHJwOiByZW5kZXJpbmdQbGF0Zm9ybSxcbiAgICAgICAgczogc2VjdGlvbixcbiAgICAgICAgc2Vuczogc2Vuc2l0aXZlID8gJ3QnIDogJ2YnLFxuICAgICAgICB1cmxrdyxcbiAgICAgICAgdmw6IHZpZGVvTGVuZ3RoID8gZ2V0VmlkZW9MZW5ndGgodmlkZW9MZW5ndGgpIDogbnVsbCxcbiAgICAgICAgYWxsa3c6IGNvbmNhdFVuaXF1ZSh1cmxrdywga2V5d29yZHMpLFxuICAgIH07XG59O1xuZXhwb3J0IHsgZ2V0Q29udGVudFRhcmdldGluZyB9O1xuIiwiaW1wb3J0IHsgc3RvcmFnZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGNsZWFyUGVybXV0aXZlU2VnbWVudHMsIGdldFBlcm11dGl2ZVBGUFNlZ21lbnRzLCBnZXRQZXJtdXRpdmVTZWdtZW50cywgfSBmcm9tICcuLi9wZXJtdXRpdmUnO1xuLyogLS0gVHlwZXMgLS0gKi9cbmNvbnN0IGZyZXF1ZW5jeSA9IFtcbiAgICAnMCcsXG4gICAgJzEnLFxuICAgICcyJyxcbiAgICAnMycsXG4gICAgJzQnLFxuICAgICc1JyxcbiAgICAnNi05JyxcbiAgICAnMTAtMTUnLFxuICAgICcxNi0xOScsXG4gICAgJzIwLTI5JyxcbiAgICAnMzBwbHVzJyxcbl07XG5jb25zdCBBTVRHUlBfU1RPUkFHRV9LRVkgPSAnZ3UuYWRNYW5hZ2VyR3JvdXAnO1xuY29uc3QgYWRNYW5hZ2VyR3JvdXBzID0gW1xuICAgICcxJyxcbiAgICAnMicsXG4gICAgJzMnLFxuICAgICc0JyxcbiAgICAnNScsXG4gICAgJzYnLFxuICAgICc3JyxcbiAgICAnOCcsXG4gICAgJzknLFxuICAgICcxMCcsXG4gICAgJzExJyxcbiAgICAnMTInLFxuXTtcbi8qIC0tIE1ldGhvZHMgLS0gKi9cbmNvbnN0IGdldFJhd1dpdGhDb25zZW50ID0gKGtleSwgc3RhdGUpID0+IHtcbiAgICBpZiAoc3RhdGUudGNmdjIpIHtcbiAgICAgICAgaWYgKHN0YXRlLnRjZnYyLmNvbnNlbnRzWycxJ10pXG4gICAgICAgICAgICByZXR1cm4gc3RvcmFnZS5sb2NhbC5nZXRSYXcoa2V5KTtcbiAgICB9XG4gICAgaWYgKHN0YXRlLnVzbmF0KSB7XG4gICAgICAgIGlmICghc3RhdGUudXNuYXQuZG9Ob3RTZWxsKVxuICAgICAgICAgICAgcmV0dXJuIHN0b3JhZ2UubG9jYWwuZ2V0UmF3KGtleSk7XG4gICAgfVxuICAgIGlmIChzdGF0ZS5hdXMpIHtcbiAgICAgICAgaWYgKHN0YXRlLmF1cy5wZXJzb25hbGlzZWRBZHZlcnRpc2luZylcbiAgICAgICAgICAgIHJldHVybiBzdG9yYWdlLmxvY2FsLmdldFJhdyhrZXkpO1xuICAgIH1cbiAgICByZXR1cm4gbnVsbDtcbn07XG5jb25zdCBnZXRGcmVxdWVuY3lWYWx1ZSA9IChzdGF0ZSkgPT4ge1xuICAgIGNvbnN0IHJhd1ZhbHVlID0gZ2V0UmF3V2l0aENvbnNlbnQoJ2d1LmFscmVhZHlWaXNpdGVkJywgc3RhdGUpO1xuICAgIGlmICghcmF3VmFsdWUpXG4gICAgICAgIHJldHVybiAnMCc7XG4gICAgY29uc3QgdmlzaXRDb3VudCA9IHBhcnNlSW50KHJhd1ZhbHVlLCAxMCk7XG4gICAgaWYgKHZpc2l0Q291bnQgPD0gNSkge1xuICAgICAgICByZXR1cm4gZnJlcXVlbmN5W3Zpc2l0Q291bnRdID8/ICcwJztcbiAgICB9XG4gICAgZWxzZSBpZiAodmlzaXRDb3VudCA+PSA2ICYmIHZpc2l0Q291bnQgPD0gOSkge1xuICAgICAgICByZXR1cm4gJzYtOSc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHZpc2l0Q291bnQgPj0gMTAgJiYgdmlzaXRDb3VudCA8PSAxNSkge1xuICAgICAgICByZXR1cm4gJzEwLTE1JztcbiAgICB9XG4gICAgZWxzZSBpZiAodmlzaXRDb3VudCA+PSAxNiAmJiB2aXNpdENvdW50IDw9IDE5KSB7XG4gICAgICAgIHJldHVybiAnMTYtMTknO1xuICAgIH1cbiAgICBlbHNlIGlmICh2aXNpdENvdW50ID49IDIwICYmIHZpc2l0Q291bnQgPD0gMjkpIHtcbiAgICAgICAgcmV0dXJuICcyMC0yOSc7XG4gICAgfVxuICAgIGVsc2UgaWYgKHZpc2l0Q291bnQgPj0gMzApIHtcbiAgICAgICAgcmV0dXJuICczMHBsdXMnO1xuICAgIH1cbiAgICByZXR1cm4gJzAnO1xufTtcbmNvbnN0IGdldENNUFRhcmdldGluZyA9IChzdGF0ZSkgPT4ge1xuICAgIGlmIChzdGF0ZS50Y2Z2Mikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgY21wX2ludGVyYWN0aW9uOiBzdGF0ZS50Y2Z2Mi5ldmVudFN0YXR1cyxcbiAgICAgICAgICAgIHBhOiBzdGF0ZS5jYW5UYXJnZXQgPyAndCcgOiAnZicsXG4gICAgICAgICAgICBjb25zZW50X3RjZnYyOiBzdGF0ZS5jYW5UYXJnZXQgPyAndCcgOiAnZicsXG4gICAgICAgICAgICByZHA6ICduYScsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmIChzdGF0ZS51c25hdCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgY29uc2VudF90Y2Z2MjogJ25hJyxcbiAgICAgICAgICAgIHJkcDogIXN0YXRlLmNhblRhcmdldCA/ICd0JyA6ICdmJyxcbiAgICAgICAgICAgIHBhOiBzdGF0ZS5jYW5UYXJnZXQgPyAndCcgOiAnZicsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmIChzdGF0ZS5hdXMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGNvbnNlbnRfdGNmdjI6ICduYScsXG4gICAgICAgICAgICByZHA6ICduYScsXG4gICAgICAgICAgICBwYTogc3RhdGUuY2FuVGFyZ2V0ID8gJ3QnIDogJ2YnLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBjbXBfaW50ZXJhY3Rpb246ICduYScsXG4gICAgICAgIGNvbnNlbnRfdGNmdjI6ICduYScsXG4gICAgICAgIHJkcDogJ25hJyxcbiAgICAgICAgcGE6ICdmJyxcbiAgICB9O1xufTtcbmNvbnN0IGlzQWRNYW5hZ2VyR3JvdXAgPSAocykgPT4gYWRNYW5hZ2VyR3JvdXBzLnNvbWUoKGcpID0+IGcgPT09IHMpO1xuY29uc3QgY3JlYXRlQWRNYW5hZ2VyR3JvdXAgPSAoKSA9PiB7XG4gICAgY29uc3QgaW5kZXggPSBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiBhZE1hbmFnZXJHcm91cHMubGVuZ3RoKTtcbiAgICBjb25zdCBncm91cCA9IGFkTWFuYWdlckdyb3Vwc1tpbmRleF0gPz8gJzEyJztcbiAgICBzdG9yYWdlLmxvY2FsLnNldFJhdyhBTVRHUlBfU1RPUkFHRV9LRVksIGdyb3VwKTtcbiAgICByZXR1cm4gZ3JvdXA7XG59O1xuY29uc3QgZ2V0QWRNYW5hZ2VyR3JvdXAgPSAoc3RhdGUpID0+IHtcbiAgICBpZiAoIXN0YXRlLmZyYW1ld29yaykge1xuICAgICAgICBzdG9yYWdlLmxvY2FsLnJlbW92ZShBTVRHUlBfU1RPUkFHRV9LRVkpO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gICAgaWYgKHN0YXRlLnRjZnYyICYmICFzdGF0ZS5jYW5UYXJnZXQpIHtcbiAgICAgICAgc3RvcmFnZS5sb2NhbC5yZW1vdmUoQU1UR1JQX1NUT1JBR0VfS0VZKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIGNvbnN0IGV4aXN0aW5nR3JvdXAgPSBzdG9yYWdlLmxvY2FsLmdldFJhdyhBTVRHUlBfU1RPUkFHRV9LRVkpO1xuICAgIHJldHVybiBpc0FkTWFuYWdlckdyb3VwKGV4aXN0aW5nR3JvdXApXG4gICAgICAgID8gZXhpc3RpbmdHcm91cFxuICAgICAgICA6IGNyZWF0ZUFkTWFuYWdlckdyb3VwKCk7XG59O1xuY29uc3QgZ2V0UGVybXV0aXZlV2l0aFN0YXRlID0gKHN0YXRlLCB5b3V0dWJlKSA9PiB7XG4gICAgaWYgKHN0YXRlLmNhblRhcmdldCkge1xuICAgICAgICByZXR1cm4geW91dHViZSA/IGdldFBlcm11dGl2ZVBGUFNlZ21lbnRzKCkgOiBnZXRQZXJtdXRpdmVTZWdtZW50cygpO1xuICAgIH1cbiAgICBjbGVhclBlcm11dGl2ZVNlZ21lbnRzKCk7XG4gICAgcmV0dXJuIFtdO1xufTtcbmNvbnN0IGdldFBlcnNvbmFsaXNlZFRhcmdldGluZyA9ICh7IHN0YXRlLCB5b3V0dWJlLCB9KSA9PiAoe1xuICAgIGFtdGdycDogZ2V0QWRNYW5hZ2VyR3JvdXAoc3RhdGUpLFxuICAgIGZyOiBnZXRGcmVxdWVuY3lWYWx1ZShzdGF0ZSksXG4gICAgcGVybXV0aXZlOiBnZXRQZXJtdXRpdmVXaXRoU3RhdGUoc3RhdGUsIHlvdXR1YmUpLFxuICAgIC4uLmdldENNUFRhcmdldGluZyhzdGF0ZSksXG59KTtcbmV4cG9ydCB7IGdldFBlcnNvbmFsaXNlZFRhcmdldGluZyB9O1xuIiwiaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5jb25zdCBpc1RhcmdldGluZ1N0cmluZyA9IChzdHJpbmcpID0+IGlzU3RyaW5nKHN0cmluZykgJiYgc3RyaW5nICE9PSAnJztcbmNvbnN0IGlzVGFyZ2V0aW5nQXJyYXkgPSAoYXJyYXkpID0+IEFycmF5LmlzQXJyYXkoYXJyYXkpICYmIGFycmF5LmZpbHRlcihpc1RhcmdldGluZ1N0cmluZykubGVuZ3RoID4gMDtcbmNvbnN0IGlzVmFsaWRUYXJnZXRpbmcgPSAodmFsdWUpID0+IHtcbiAgICBpZiAoaXNUYXJnZXRpbmdTdHJpbmcodmFsdWUpKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoaXNUYXJnZXRpbmdBcnJheSh2YWx1ZSkpXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIHJldHVybiBmYWxzZTtcbn07XG4vKipcbiAqIFBpY2tzIG9ubHkga2V5cyB3aXRoIHRhcmdldGluZyB2YWx1ZXMgZnJvbSBhbiBvYmplY3QuXG4gKiBBIHRhcmdldGluZyB2YWx1ZXMgaXMgZGVmaW5lZCBhcyBlaXRoZXI6XG4gKiAtIGEgbm9uLWVtcHR5IHN0cmluZ1xuICogLSBhbiBhcnJheSBvZiBub24tZW1wdHkgc3RyaW5nc1xuICpcbiAqIElmIHlvdSBvYmplY3QgaXMgcmVhZC1vbmx5LCB5b3UgY2FuIHNhZmVseSBhY2Nlc3MgcHJvcGVydGllcyBvbiB0aGUgcmVzdWx0LlxuICogRm9yIGV4YW1wbGU6XG4gKlxuICogYGBgdHNcbiAqIGRpcnR5ID0ge1xuICogICB2YWxpZDogJ3JlYWwnLFxuICogICBpbnZhbGlkOiB1bmRlZmluZWQsXG4gKiB9IGFzIGNvbnN0O1xuICpcbiAqIGNsZWFuID0gcGlja0RlZmluZWRWYWx1ZXMoZGlydHkpO1xuICpcbiAqIC8vIEB0cy1leHBlY3QtZXJyb3IgLS0geW91IGNhbuKAmXQgYWNjZXNzIHRoaXMgcHJvcGVydHlcbiAqIGNsZWFuLmludmFsaWRcbiAqIGBgYFxuICovXG5leHBvcnQgY29uc3QgcGlja1RhcmdldGluZ1ZhbHVlcyA9IChvYmopID0+IHtcbiAgICBjb25zdCBpbml0aWFsVmFsdWUgPSB7fTtcbiAgICByZXR1cm4gT2JqZWN0LmVudHJpZXMob2JqKS5yZWR1Y2UoKHZhbGlkLCBba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgaWYgKGlzVmFsaWRUYXJnZXRpbmcodmFsdWUpKSB7XG4gICAgICAgICAgICAvLyBAdHMtZXhwZWN0LWVycm9yIC0tIGlzVmFsaWRUYXJnZXRpbmcgY2hlY2tzIHRoaXNcbiAgICAgICAgICAgIHZhbGlkW2tleV0gPSBBcnJheS5pc0FycmF5KHZhbHVlKVxuICAgICAgICAgICAgICAgID8gdmFsdWUuZmlsdGVyKGlzVGFyZ2V0aW5nU3RyaW5nKVxuICAgICAgICAgICAgICAgIDogdmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHZhbGlkO1xuICAgIH0sIGluaXRpYWxWYWx1ZSk7XG59O1xuIiwiaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG4vKiAtLSBUeXBlcyAtLSAqL1xuY29uc3QgcmVmZXJyZXJzID0gW1xuICAgIHtcbiAgICAgICAgaWQ6ICdmYWNlYm9vaycsXG4gICAgICAgIG1hdGNoOiAnZmFjZWJvb2suY29tJyxcbiAgICB9LFxuICAgIHtcbiAgICAgICAgaWQ6ICdnb29nbGUnLFxuICAgICAgICBtYXRjaDogJ3d3dy5nb29nbGUnLFxuICAgIH0sXG4gICAge1xuICAgICAgICBpZDogJ3R3aXR0ZXInLFxuICAgICAgICBtYXRjaDogJy90LmNvLycsXG4gICAgfSxcbiAgICB7XG4gICAgICAgIGlkOiAncmVkZGl0JyxcbiAgICAgICAgbWF0Y2g6ICdyZWRkaXQuY29tJyxcbiAgICB9LFxuXTtcbi8qIC0tIE1ldGhvZHMgLS0gKi9cbmNvbnN0IGdldFJlZmVycmVyID0gKHJlZmVycmVyKSA9PiB7XG4gICAgaWYgKHJlZmVycmVyID09PSAnJylcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgY29uc3QgbWF0Y2hlZFJlZiA9IHJlZmVycmVycy5maW5kKChyZWZlcnJlclR5cGUpID0+IHJlZmVycmVyLmluY2x1ZGVzKHJlZmVycmVyVHlwZS5tYXRjaCkpID8/IG51bGw7XG4gICAgcmV0dXJuIG1hdGNoZWRSZWYgPyBtYXRjaGVkUmVmLmlkIDogbnVsbDtcbn07XG5jb25zdCBleHBlcmltZW50c1RhcmdldGluZyA9ICh7IGNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucywgc2VydmVyU2lkZVBhcnRpY2lwYXRpb25zLCB9KSA9PiB7XG4gICAgY29uc3QgdGVzdFRvUGFyYW1zID0gKHRlc3ROYW1lLCB2YXJpYW50KSA9PiB7XG4gICAgICAgIGlmICh2YXJpYW50ID09PSAnbm90aW50ZXN0JylcbiAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAvLyBHQU0ga2V5LXZhbHVlIHBhaXJzIGFjY2VwdCB2YWx1ZSBzdHJpbmdzIHVwIHRvIDQwIGNoYXJhY3RlcnMgbG9uZ1xuICAgICAgICByZXR1cm4gYCR7dGVzdE5hbWV9LSR7dmFyaWFudH1gLnN1YnN0cmluZygwLCA0MCk7XG4gICAgfTtcbiAgICBjb25zdCBjbGllbnRTaWRlRXhwZXJpbWVudCA9IE9iamVjdC5lbnRyaWVzKGNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucylcbiAgICAgICAgLm1hcCgodGVzdCkgPT4ge1xuICAgICAgICBjb25zdCBbbmFtZSwgdmFyaWFudF0gPSB0ZXN0O1xuICAgICAgICByZXR1cm4gdGVzdFRvUGFyYW1zKG5hbWUsIHZhcmlhbnQudmFyaWFudCk7XG4gICAgfSlcbiAgICAgICAgLmZpbHRlcihpc1N0cmluZyk7XG4gICAgY29uc3Qgc2VydmVyU2lkZUV4cGVyaW1lbnRzID0gT2JqZWN0LmVudHJpZXMoc2VydmVyU2lkZVBhcnRpY2lwYXRpb25zKVxuICAgICAgICAubWFwKCh0ZXN0KSA9PiB0ZXN0VG9QYXJhbXMoLi4udGVzdCkpXG4gICAgICAgIC5maWx0ZXIoaXNTdHJpbmcpO1xuICAgIGlmIChjbGllbnRTaWRlRXhwZXJpbWVudC5sZW5ndGggKyBzZXJ2ZXJTaWRlRXhwZXJpbWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICByZXR1cm4gWy4uLmNsaWVudFNpZGVFeHBlcmltZW50LCAuLi5zZXJ2ZXJTaWRlRXhwZXJpbWVudHNdO1xufTtcbmNvbnN0IGdldFNlc3Npb25UYXJnZXRpbmcgPSAoeyBhZFRlc3QsIGNvdW50cnlDb2RlLCBsb2NhbEhvdXIsIGlzU2lnbmVkSW4sIHBhZ2VWaWV3SWQsIHBhcnRpY2lwYXRpb25zLCByZWZlcnJlciwgfSkgPT4gKHtcbiAgICBhYjogZXhwZXJpbWVudHNUYXJnZXRpbmcocGFydGljaXBhdGlvbnMpLFxuICAgIGF0OiBhZFRlc3QsXG4gICAgY2M6IGNvdW50cnlDb2RlLFxuICAgIGxoOiBsb2NhbEhvdXIsXG4gICAgcHY6IHBhZ2VWaWV3SWQsXG4gICAgcmVmOiBnZXRSZWZlcnJlcihyZWZlcnJlciksXG4gICAgc2k6IGlzU2lnbmVkSW4gPyAndCcgOiAnZicsXG59KTtcbmV4cG9ydCB7IGdldFNlc3Npb25UYXJnZXRpbmcsIGV4cGVyaW1lbnRzVGFyZ2V0aW5nIH07XG4iLCJpbXBvcnQgeyBwaWNrVGFyZ2V0aW5nVmFsdWVzIH0gZnJvbSAnLi9waWNrLXRhcmdldGluZy12YWx1ZXMnO1xuY29uc3Qgc3VyZ2VzID0ge1xuICAgIDA6ICcwJyxcbiAgICA1MDogJzUnLFxuICAgIDEwMDogJzQnLFxuICAgIDIwMDogJzMnLFxuICAgIDMwMDogJzInLFxuICAgIDQwMDogJzEnLFxufTtcbi8qIC0tIE1ldGhvZHMgLS0gKi9cbmNvbnN0IGdldFN1cmdpbmdQYXJhbSA9IChzdXJnaW5nKSA9PiB7XG4gICAgaWYgKHN1cmdpbmcgPCA1MCB8fCBpc05hTihzdXJnaW5nKSlcbiAgICAgICAgcmV0dXJuIFsnMCddO1xuICAgIGNvbnN0IHRocmVzaG9sZHMgPSBbNDAwLCAzMDAsIDIwMCwgMTAwLCA1MF07XG4gICAgcmV0dXJuIHRocmVzaG9sZHMuZmlsdGVyKChuKSA9PiBuIDw9IHN1cmdpbmcpLm1hcCgocykgPT4gc3VyZ2VzW3NdKTtcbn07XG4vKiAtLSBUYXJnZXRpbmcgLS0gKi9cbmNvbnN0IGdldExvY2FsSG91ciA9ICgpID0+IHtcbiAgICByZXR1cm4gbmV3IERhdGUoKS5nZXRIb3VycygpLnRvU3RyaW5nKCk7XG59O1xuLyoqXG4gKiBXaGF0IGdvZXMgaW4gY29tZXMgb3V0XG4gKi9cbmNvbnN0IGdldFNoYXJlZFRhcmdldGluZyA9IChzaGFyZWQpID0+IHBpY2tUYXJnZXRpbmdWYWx1ZXMoc2hhcmVkKTtcbmV4cG9ydCBjb25zdCBfID0ge1xuICAgIGdldFN1cmdpbmdQYXJhbSxcbn07XG5leHBvcnQgeyBnZXRTaGFyZWRUYXJnZXRpbmcsIGdldExvY2FsSG91ciB9O1xuIiwiY29uc3QgYWxsb3dlZENvbnRlbnRUeXBlcyA9IFsnQXJ0aWNsZScsICdMaXZlQmxvZyddO1xuY29uc3QgaXNFbGlnaWJsZUZvclRlYWRzID0gKHNsb3RJZCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGVudFR5cGUsIGlzU2Vuc2l0aXZlIH0gPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2U7XG4gICAgLy8gVGhpcyBJQVMgdmFsdWUgaXMgcmV0dXJuZWQgd2hlbiBhIHBhZ2UgaXMgdGhvdWdodCB0byBjb250YWluIGNvbnRlbnQgd2hpY2ggaXMgbm90IGJyYW5kIHNhZmVcbiAgICBjb25zdCBpc0JyYW5kU2FmZSA9ICF3aW5kb3cuZ29vZ2xldGFnXG4gICAgICAgIC5wdWJhZHMoKVxuICAgICAgICAuZ2V0VGFyZ2V0aW5nKCdpYXMta3cnKVxuICAgICAgICAuaW5jbHVkZXMoJ0lBU18xNjQyNV9LVycpO1xuICAgIGlmIChzbG90SWQgPT09ICdkZnAtYWQtLWlubGluZTEnICYmXG4gICAgICAgIGFsbG93ZWRDb250ZW50VHlwZXMuaW5jbHVkZXMoY29udGVudFR5cGUpICYmXG4gICAgICAgICFpc1NlbnNpdGl2ZSAmJlxuICAgICAgICBpc0JyYW5kU2FmZSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xufTtcbmV4cG9ydCB7IGlzRWxpZ2libGVGb3JUZWFkcyB9O1xuIiwiLyogLS0gTWV0aG9kcyAtLSAqL1xuY29uc3QgZmluZEJyZWFrcG9pbnQgPSAod2lkdGgpID0+IHtcbiAgICBpZiAod2lkdGggPj0gOTgwKVxuICAgICAgICByZXR1cm4gJ2Rlc2t0b3AnO1xuICAgIGlmICh3aWR0aCA+PSA2NjApXG4gICAgICAgIHJldHVybiAndGFibGV0JztcbiAgICByZXR1cm4gJ21vYmlsZSc7XG59O1xuY29uc3QgZ2V0Vmlld3BvcnRUYXJnZXRpbmcgPSAoeyB2aWV3UG9ydFdpZHRoLCBjbXBCYW5uZXJXaWxsU2hvdywgfSkgPT4ge1xuICAgIC8vIERvbuKAmXQgc2hvdyBpbnNraW4gaWYgaWYgYSBwcml2YWN5IG1lc3NhZ2Ugd2lsbCBiZSBzaG93biBvciBvbiBwcmV2aWV3XG4gICAgY29uc3QgaXNQcmV2aWV3ID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzUHJldmlldztcbiAgICBjb25zdCBpbnNraW4gPSBjbXBCYW5uZXJXaWxsU2hvdyB8fCBpc1ByZXZpZXcgPyAnZicgOiAndCc7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYnA6IGZpbmRCcmVha3BvaW50KHZpZXdQb3J0V2lkdGgpLFxuICAgICAgICBza2luc2l6ZTogdmlld1BvcnRXaWR0aCA+PSAxNTYwID8gJ2wnIDogJ3MnLFxuICAgICAgICBpbnNraW4sXG4gICAgfTtcbn07XG5leHBvcnQgeyBnZXRWaWV3cG9ydFRhcmdldGluZyB9O1xuIiwiaW1wb3J0IHsgY3JlYXRlQWRTaXplLCBmaW5kQXBwbGllZFNpemVzRm9yQnJlYWtwb2ludCwgc2xvdFNpemVNYXBwaW5ncywgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2FkLXNpemVzJztcbmltcG9ydCB7IGJyZWFrcG9pbnRzIGFzIHNvdXJjZUJyZWFrcG9pbnRzIH0gZnJvbSAnQGd1YXJkaWFuL3NvdXJjZS9mb3VuZGF0aW9ucyc7XG5pbXBvcnQgeyBjb25jYXRTaXplTWFwcGluZ3MgfSBmcm9tICcuLi9saWIvY3JlYXRlLWFkLXNsb3QnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vbGliL2Zhc3Rkb20tcHJvbWlzZSc7XG5pbXBvcnQgeyBidWlsZEdvb2dsZXRhZ1NpemVNYXBwaW5nLCBkZWZpbmVTbG90IH0gZnJvbSAnLi9kZWZpbmUtc2xvdCc7XG5jb25zdCBzdHJpbmdUb1R1cGxlID0gKHNpemUpID0+IHtcbiAgICBjb25zdCBkaW1lbnNpb25zID0gc2l6ZS5zcGxpdCgnLCcsIDIpLm1hcChOdW1iZXIpO1xuICAgIC8vIFJldHVybiBhbiBvdXRPZlBhZ2UgdHVwbGUgaWYgdGhlIHN0cmluZyBpcyBub3QgYFtudW1iZXIsIG51bWJlcl1gXG4gICAgaWYgKGRpbWVuc2lvbnMubGVuZ3RoICE9PSAyIHx8XG4gICAgICAgICFkaW1lbnNpb25zWzBdIHx8XG4gICAgICAgICFkaW1lbnNpb25zWzFdIHx8XG4gICAgICAgIGRpbWVuc2lvbnMuc29tZSgobikgPT4gaXNOYU4obikpKSB7XG4gICAgICAgIHJldHVybiBbMCwgMF07XG4gICAgfVxuICAgIHJldHVybiBbZGltZW5zaW9uc1swXSwgZGltZW5zaW9uc1sxXV07XG59O1xuLyoqXG4gKiBBIGJyZWFrcG9pbnQgY2FuIGhhdmUgdmFyaW91cyBzaXplcyBhc3NpZ25lZCB0byBpdC4gWW91IGNhbiBhc3NpZ24gZWl0aGVyIG9uXG4gKiBzZXQgb2Ygc2l6ZXMgb3IgbXVsdGlwbGUuXG4gKlxuICogT25lIHNpemUgICAgICAgLSBgZGF0YS1tb2JpbGU9XCIzMDAsNTBcImBcbiAqIE11bHRpcGxlIHNpemVzIC0gYGRhdGEtbW9iaWxlPVwiMzAwLDUwfDMyMCw1MFwiYFxuICovXG5jb25zdCBjcmVhdGVTaXplTWFwcGluZyA9IChhdHRyKSA9PiBhdHRyLnNwbGl0KCd8JykubWFwKChzaXplKSA9PiBjcmVhdGVBZFNpemUoLi4uc3RyaW5nVG9UdXBsZShzaXplKSkpO1xuLyoqXG4gKiBDb252ZXJ0IGEgYnJlYWtwb2ludCBuYW1lIHRvIGEgZm9ybSBzdWl0YWJsZSBmb3IgdXNlIGFzIGFuIGF0dHJpYnV0ZVxuICogUmVnZXggbWF0Y2hlcyBhIGxvd2VyY2FzZSBsZXR0ZXIgZm9sbG93ZWQgYnkgYW4gdXBwZXJjYXNlIGxldHRlclxuICpcbiAqIGUuZy4gYG1vYmlsZUxhbmRzY2FwZWAgPT4gYG1vYmlsZS1sYW5kc2NhcGVgXG4gKi9cbmNvbnN0IGJyZWFrcG9pbnROYW1lVG9BdHRyaWJ1dGUgPSAoYnJlYWtwb2ludE5hbWUpID0+IGJyZWFrcG9pbnROYW1lLnJlcGxhY2UoLyhbYS16XSkoW0EtWl0pL2csICckMS0kMicpLnRvTG93ZXJDYXNlKCk7XG4vKipcbiAqIEV4dHJhY3QgdGhlIGFkIHNpemVzIGZyb20gdGhlIGJyZWFrcG9pbnQgZGF0YSBhdHRyaWJ1dGVzIG9mIGFuIGFkIHNsb3RcbiAqXG4gKiBAcGFyYW0gYWR2ZXJ0Tm9kZSBUaGUgYWQgc2xvdCBIVE1MIGVsZW1lbnQgdGhhdCBjb250YWlucyB0aGUgYnJlYWtwb2ludCBhdHRyaWJ1dGVzXG4gKiBAcmV0dXJucyBBIG1hcHBpbmcgZnJvbSB0aGUgYnJlYWtwb2ludHMgc3VwcG9ydGVkIGJ5IHRoZSBzbG90IHRvIGFuIGFycmF5IG9mIGFkIHNpemVzXG4gKi9cbmNvbnN0IGdldFNsb3RTaXplTWFwcGluZ3NGcm9tRGF0YUF0dHJzID0gKGFkdmVydE5vZGUpID0+IE9iamVjdC5lbnRyaWVzKHNvdXJjZUJyZWFrcG9pbnRzKS5yZWR1Y2UoKHNpemVzLCBbYnJlYWtwb2ludE5hbWVdKSA9PiB7XG4gICAgY29uc3QgZGF0YSA9IGFkdmVydE5vZGUuZ2V0QXR0cmlidXRlKGBkYXRhLSR7YnJlYWtwb2ludE5hbWVUb0F0dHJpYnV0ZShicmVha3BvaW50TmFtZSl9YCk7XG4gICAgaWYgKGRhdGEpIHtcbiAgICAgICAgc2l6ZXNbYnJlYWtwb2ludE5hbWVdID0gY3JlYXRlU2l6ZU1hcHBpbmcoZGF0YSk7XG4gICAgfVxuICAgIHJldHVybiBzaXplcztcbn0sIHt9KTtcbmNvbnN0IGlzU2xvdE5hbWUgPSAoc2xvdE5hbWUpID0+IHtcbiAgICByZXR1cm4gc2xvdE5hbWUgaW4gc2xvdFNpemVNYXBwaW5ncztcbn07XG5jb25zdCBnZXRTbG90U2l6ZU1hcHBpbmcgPSAobmFtZSkgPT4ge1xuICAgIGxldCBzbG90TmFtZTtcbiAgICBpZiAobmFtZS5pbmNsdWRlcygnaW5saW5lJykpIHtcbiAgICAgICAgc2xvdE5hbWUgPSAnaW5saW5lJztcbiAgICB9XG4gICAgZWxzZSBpZiAobmFtZS5pbmNsdWRlcygnZnJvbnRzLWJhbm5lcicpKSB7XG4gICAgICAgIHNsb3ROYW1lID0gJ2Zyb250cy1iYW5uZXInO1xuICAgIH1cbiAgICBlbHNlIGlmIChuYW1lLmluY2x1ZGVzKCdleHRlcm5hbCcpKSB7XG4gICAgICAgIHNsb3ROYW1lID0gJ2V4dGVybmFsJztcbiAgICB9XG4gICAgZWxzZSBpZiAobmFtZS5pbmNsdWRlcygnY29tbWVudHMtZXhwYW5kZWQnKSkge1xuICAgICAgICBzbG90TmFtZSA9ICdjb21tZW50cy1leHBhbmRlZCc7XG4gICAgfVxuICAgIGVsc2UgaWYgKG5hbWUuaW5jbHVkZXMoJ2ludGVyYWN0aXZlJykpIHtcbiAgICAgICAgc2xvdE5hbWUgPSAnaW50ZXJhY3RpdmUnO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc2xvdE5hbWUgPSBuYW1lO1xuICAgIH1cbiAgICBpZiAoaXNTbG90TmFtZShzbG90TmFtZSkpIHtcbiAgICAgICAgcmV0dXJuIHNsb3RTaXplTWFwcGluZ3Nbc2xvdE5hbWVdO1xuICAgIH1cbiAgICByZXR1cm4ge307XG59O1xuLyoqXG4gKiBGaW5kcyB0aGUgc21hbGxlc3QgcG9zc2libGUga25vd24gYWQgc2l6ZSB0aGF0IGNhbiBmaWxsIGEgc2xvdFxuICogVXNlZnVsIGZvciBtaW5pbWlzaW5nIENMUy5cbiAqL1xuY29uc3QgZmluZFNtYWxsZXN0QWRIZWlnaHRGb3JTbG90ID0gKHNsb3QsIGJyZWFrcG9pbnQpID0+IHtcbiAgICBjb25zdCBzaXplcyA9IGdldFNsb3RTaXplTWFwcGluZyhzbG90KTtcbiAgICBpZiAoIU9iamVjdC5rZXlzKHNpemVzKS5sZW5ndGgpXG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIGNvbnN0IHNpemVzRm9yQnJlYWtwb2ludCA9IGZpbmRBcHBsaWVkU2l6ZXNGb3JCcmVha3BvaW50KHNpemVzLCBicmVha3BvaW50KTtcbiAgICBjb25zdCBoZWlnaHRzID0gc2l6ZXNGb3JCcmVha3BvaW50XG4gICAgICAgIC5maWx0ZXIoKHNpemUpID0+ICFzaXplLmlzUHJveHkoKSlcbiAgICAgICAgLm1hcCgoeyBoZWlnaHQgfSkgPT4gaGVpZ2h0KTtcbiAgICBpZiAoIWhlaWdodHMubGVuZ3RoKVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICByZXR1cm4gTWF0aC5taW4oLi4uaGVpZ2h0cyk7XG59O1xuY29uc3QgaXNTaXplTWFwcGluZ0VtcHR5ID0gKHNpemVNYXBwaW5nKSA9PiB7XG4gICAgcmV0dXJuIChPYmplY3Qua2V5cyhzaXplTWFwcGluZykubGVuZ3RoID09PSAwIHx8XG4gICAgICAgIE9iamVjdC5lbnRyaWVzKHNpemVNYXBwaW5nKS5ldmVyeSgoWywgbWFwcGluZ10pID0+IG1hcHBpbmcubGVuZ3RoID09PSAwKSk7XG59O1xuY2xhc3MgQWR2ZXJ0IHtcbiAgICBpZDtcbiAgICBub2RlO1xuICAgIHNpemVzO1xuICAgIGhlYWRlckJpZGRpbmdTaXplcyA9IG51bGw7XG4gICAgc2l6ZSA9IG51bGw7XG4gICAgc2xvdDtcbiAgICBpc0VtcHR5ID0gbnVsbDtcbiAgICBpc1JlbmRlcmVkID0gZmFsc2U7XG4gICAgc2hvdWxkUmVmcmVzaCA9IGZhbHNlO1xuICAgIHdoZW5TbG90UmVhZHk7XG4gICAgZXh0cmFOb2RlQ2xhc3NlcyA9IFtdO1xuICAgIGhhc1ByZWJpZFNpemUgPSBmYWxzZTtcbiAgICBoZWFkZXJCaWRkaW5nQmlkUmVxdWVzdCA9IG51bGw7XG4gICAgbGluZUl0ZW1JZCA9IG51bGw7XG4gICAgY3JlYXRpdmVJZCA9IG51bGw7XG4gICAgY3JlYXRpdmVUZW1wbGF0ZUlkID0gbnVsbDtcbiAgICB0ZXN0Z3JvdXA7IC8vT3pvbmUgdGVzdGdyb3VwIHByb3BlcnR5XG4gICAgY29uc3RydWN0b3IoYWRTbG90Tm9kZSwgYWRkaXRpb25hbFNpemVNYXBwaW5nID0ge30sIHNsb3RUYXJnZXRpbmcgPSB7fSkge1xuICAgICAgICB0aGlzLmlkID0gYWRTbG90Tm9kZS5pZDtcbiAgICAgICAgdGhpcy5ub2RlID0gYWRTbG90Tm9kZTtcbiAgICAgICAgdGhpcy5zaXplcyA9IHRoaXMuZ2VuZXJhdGVTaXplTWFwcGluZyhhZGRpdGlvbmFsU2l6ZU1hcHBpbmcpO1xuICAgICAgICBjb25zdCBzbG90RGVmaW5pdGlvbiA9IGRlZmluZVNsb3QoYWRTbG90Tm9kZSwgdGhpcy5zaXplcywgc2xvdFRhcmdldGluZyk7XG4gICAgICAgIHRoaXMuc2xvdCA9IHNsb3REZWZpbml0aW9uLnNsb3Q7XG4gICAgICAgIHRoaXMud2hlblNsb3RSZWFkeSA9IHNsb3REZWZpbml0aW9uLnNsb3RSZWFkeTtcbiAgICAgICAgdGhpcy50ZXN0Z3JvdXAgPSBzbG90RGVmaW5pdGlvbi5zbG90LmdldFRhcmdldGluZygndGVzdGdyb3VwJylbMF07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIENhbGwgdGhpcyBtZXRob2Qgb25jZSB0aGUgYWQgaGFzIGJlZW4gcmVuZGVyZWQsIGl0IHdpbGwgc2V0IHRoZVxuICAgICAqIGBpc1JlbmRlcmVkYCBmbGFnIHRvIHRydWUsIHdoaWNoIGlzIHVzZWQgdG8gZGV0ZXJtaW5lIHdoZXRoZXIgdG8gbG9hZFxuICAgICAqIG9yIHJlZnJlc2ggdGhlIGFkXG4gICAgICpcbiAgICAgKiBAcGFyYW0gaXNSZW5kZXJlZCB3YXMgYW4gYWR2ZXJ0IHJlbmRlcmVkXG4gICAgICovXG4gICAgZmluaXNoZWRSZW5kZXJpbmcoaXNSZW5kZXJlZCkge1xuICAgICAgICB0aGlzLmlzUmVuZGVyZWQgPSBpc1JlbmRlcmVkO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBVcGRhdGUgdGhlIFwiZXh0cmFcIiBjbGFzc2VzIGZvciB0aGlzIHNsb3QgZS5nLiBgYWQtc2xvdC0tb3V0c3RyZWFtYCwgc28gdGhhdCB0aGUgYmFzZSBjbGFzc2VzXG4gICAgICogbGlrZSBgYWQtc2xvdGAgZXRjLiBhcmUgbmV2ZXIgcmVtb3ZlZFxuICAgICAqXG4gICAgICogQHBhcmFtIG5ld0NsYXNzZXMgQW4gYXJyYXkgb2YgY2xhc3NlcyB0byBzZXQgb24gdGhlIHNsb3RcbiAgICAgKiovXG4gICAgYXN5bmMgdXBkYXRlRXh0cmFTbG90Q2xhc3NlcyguLi5uZXdDbGFzc2VzKSB7XG4gICAgICAgIGNvbnN0IGNsYXNzZXNUb1JlbW92ZSA9IHRoaXMuZXh0cmFOb2RlQ2xhc3Nlcy5maWx0ZXIoKGMpID0+ICFuZXdDbGFzc2VzLmluY2x1ZGVzKGMpKTtcbiAgICAgICAgYXdhaXQgZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICAgICAgdGhpcy5ub2RlLmNsYXNzTGlzdC5yZW1vdmUoLi4uY2xhc3Nlc1RvUmVtb3ZlKTtcbiAgICAgICAgICAgIHRoaXMubm9kZS5jbGFzc0xpc3QuYWRkKC4uLm5ld0NsYXNzZXMpO1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5leHRyYU5vZGVDbGFzc2VzID0gbmV3Q2xhc3NlcztcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ29tYmluZSB0aGUgc2l6ZSBtYXBwaW5nIGZyb20gdGhlIG1hcHBpbmdzIGluIGNvbW1lcmNpYWwgd2l0aFxuICAgICAqIGFueSBhZGRpdGlvbmFsIHNpemUgbWFwcGluZ3MsIGlmIG5vbmUgYXJlIGZvdW5kIGNoZWNrIGRhdGEtYXR0cmlidXRlcywgaWYgc3RpbGxcbiAgICAgKiBub25lIGFyZSBmb3VuZCB0aHJvd3MgYW4gZXJyb3JcbiAgICAgKlxuICAgICAqIEBwYXJhbSBhZGRpdGlvbmFsU2l6ZU1hcHBpbmcgQSBtYXBwaW5nIG9mIGJyZWFrcG9pbnRzIHRvIGFkIHNpemVzXG4gICAgICogQHJldHVybnMgQSBtYXBwaW5nIG9mIGJyZWFrcG9pbnRzIHRvIGFkIHNpemVzXG4gICAgICovXG4gICAgZ2VuZXJhdGVTaXplTWFwcGluZyhhZGRpdGlvbmFsU2l6ZU1hcHBpbmcpIHtcbiAgICAgICAgLy8gVHJ5IHRvIHVzZSBkZWZpbmVkIHNpemUgbWFwcGluZ3MgaWYgYXZhaWxhYmxlXG4gICAgICAgIGNvbnN0IGRlZmF1bHRTaXplTWFwcGluZ0ZvclNsb3QgPSB0aGlzLm5vZGUuZGF0YXNldC5uYW1lXG4gICAgICAgICAgICA/IGdldFNsb3RTaXplTWFwcGluZyh0aGlzLm5vZGUuZGF0YXNldC5uYW1lKVxuICAgICAgICAgICAgOiB7fTtcbiAgICAgICAgLy8gRGF0YSBhdHRyaWJ1dGUgc2l6ZSBtYXBwaW5ncyBhcmUgdXNlZCBpbiBpbnRlcmFjdGl2ZXMgZS5nLiBodHRwczovL3d3dy50aGVndWFyZGlhbi5jb20vZWR1Y2F0aW9uL25nLWludGVyYWN0aXZlLzIwMjEvc2VwLzExL3RoZS1iZXN0LXVrLXVuaXZlcnNpdGllcy0yMDIyLXJhbmtpbmdzXG4gICAgICAgIGNvbnN0IGRhdGFBdHRyU2l6ZU1hcHBpbmcgPSBnZXRTbG90U2l6ZU1hcHBpbmdzRnJvbURhdGFBdHRycyh0aGlzLm5vZGUpO1xuICAgICAgICBsZXQgc2l6ZU1hcHBpbmcgPSBjb25jYXRTaXplTWFwcGluZ3MoZGVmYXVsdFNpemVNYXBwaW5nRm9yU2xvdCwgYWRkaXRpb25hbFNpemVNYXBwaW5nKTtcbiAgICAgICAgc2l6ZU1hcHBpbmcgPSBjb25jYXRTaXplTWFwcGluZ3Moc2l6ZU1hcHBpbmcsIGRhdGFBdHRyU2l6ZU1hcHBpbmcpO1xuICAgICAgICAvLyBJZiB0aGUgc2l6ZSBtYXBwaW5nIGlzIHN0aWxsIGVtcHR5LCB0aHJvdyBhbiBlcnJvciBhcyB0aGlzIHNob3VsZCBuZXZlciBoYXBwZW5cbiAgICAgICAgaWYgKGlzU2l6ZU1hcHBpbmdFbXB0eShzaXplTWFwcGluZykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgVHJpZWQgdG8gcmVuZGVyIGFkIHNsb3QgJyR7dGhpcy5ub2RlLmRhdGFzZXQubmFtZSA/PyAnJ30nIHdpdGhvdXQgYW55IHNpemUgbWFwcGluZ3NgKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc2l6ZU1hcHBpbmc7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFVwZGF0ZSB0aGUgc2l6ZSBtYXBwaW5nIGZvciB0aGlzIHNsb3QsIHlvdSB3aWxsIG5lZWQgdG8gY2FsbFxuICAgICAqIHJlZnJlc2hBZHZlcnQgdG8gdXBkYXRlIHRoZSBhZCBpbW1lZGlhdGVseVxuICAgICAqXG4gICAgICogQHBhcmFtIGFkZGl0aW9uYWxTaXplTWFwcGluZyBBIG1hcHBpbmcgb2YgYnJlYWtwb2ludHMgdG8gYWQgc2l6ZXNcbiAgICAgKiovXG4gICAgdXBkYXRlU2l6ZU1hcHBpbmcoYWRkaXRpb25hbFNpemVNYXBwaW5nKSB7XG4gICAgICAgIGNvbnN0IHNpemVNYXBwaW5nID0gdGhpcy5nZW5lcmF0ZVNpemVNYXBwaW5nKGFkZGl0aW9uYWxTaXplTWFwcGluZyk7XG4gICAgICAgIHRoaXMuc2l6ZXMgPSBzaXplTWFwcGluZztcbiAgICAgICAgY29uc3QgZ29vZ2xldGFnU2l6ZU1hcHBpbmcgPSBidWlsZEdvb2dsZXRhZ1NpemVNYXBwaW5nKHNpemVNYXBwaW5nKTtcbiAgICAgICAgaWYgKGdvb2dsZXRhZ1NpemVNYXBwaW5nKSB7XG4gICAgICAgICAgICB0aGlzLnNsb3QuZGVmaW5lU2l6ZU1hcHBpbmcoZ29vZ2xldGFnU2l6ZU1hcHBpbmcpO1xuICAgICAgICB9XG4gICAgfVxufVxuY29uc3QgaXNBZFNpemUgPSAoc2l6ZSkgPT4ge1xuICAgIHJldHVybiBzaXplICE9PSBudWxsICYmIHNpemUgIT09ICdmbHVpZCc7XG59O1xuZXhwb3J0IHsgQWR2ZXJ0LCBmaW5kU21hbGxlc3RBZEhlaWdodEZvclNsb3QsIGlzQWRTaXplIH07XG5leHBvcnQgY29uc3QgXyA9IHtcbiAgICBnZXRTbG90U2l6ZU1hcHBpbmcsXG59O1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgcmVwb3J0RXJyb3IgfSBmcm9tICcuLi9saWIvZXJyb3IvcmVwb3J0LWVycm9yJztcbmltcG9ydCB7IEFkdmVydCB9IGZyb20gJy4vQWR2ZXJ0JztcbmltcG9ydCB7IERlZmluZVNsb3RFcnJvciB9IGZyb20gJy4vZGVmaW5lLXNsb3QnO1xuY29uc3QgY3JlYXRlQWR2ZXJ0ID0gKGFkU2xvdCwgYWRkaXRpb25hbFNpemVzLCBzbG90VGFyZ2V0aW5nKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgYWR2ZXJ0ID0gbmV3IEFkdmVydChhZFNsb3QsIGFkZGl0aW9uYWxTaXplcywgc2xvdFRhcmdldGluZyk7XG4gICAgICAgIHJldHVybiBhZHZlcnQ7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBEZWZpbmVTbG90RXJyb3IpIHtcbiAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGVycm9yLm1lc3NhZ2UsIHtcbiAgICAgICAgICAgICAgICBhZFNsb3RJZDogYWRTbG90LmlkLFxuICAgICAgICAgICAgICAgIHNpemVNYXBwaW5nOiBlcnJvci5zaXplTWFwcGluZyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKGVycm9yLnJlcG9ydCkge1xuICAgICAgICAgICAgICAgIHJlcG9ydEVycm9yKGVycm9yLCAnY29tbWVyY2lhbCcsIHt9LCB7XG4gICAgICAgICAgICAgICAgICAgIGFkU2xvdElkOiBhZFNsb3QuaWQsXG4gICAgICAgICAgICAgICAgICAgIHNpemVNYXBwaW5nOiBlcnJvci5zaXplTWFwcGluZyxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogU3RyaW5nKGVycm9yKSk7XG4gICAgICAgICAgICAvLyBUaGUgRHVja0R1Y2tHbyBicm93c2VyIGJsb2NrcyBhZHMgZnJvbSBsb2FkaW5nIGJ5IGRlZmF1bHQsIHNvIGl0IGNhdXNlcyBhIGxvdCBvZiBub2lzZSBpbiBTZW50cnkuXG4gICAgICAgICAgICAvLyBXZSBmaWx0ZXIgdGhlc2UgZXJyb3JzIG91dCBoZXJlIC0gRHVja0R1Y2tHbyBpcyBpbiB0aGUgdXNlciBhZ2VudCBzdHJpbmcgaWYgc29tZW9uZSBpcyB1c2luZyB0aGVcbiAgICAgICAgICAgIC8vIGRlc2t0b3AgYnJvd3NlciwgYW5kIERkZyBpcyBwcmVzZW50IGZvciB0aG9zZSB1c2luZyB0aGUgbW9iaWxlIGJyb3dzZXIsIHNvIHdlIGZpbHRlciBvdXQgYm90aC5cbiAgICAgICAgICAgIGlmICghbmF2aWdhdG9yLnVzZXJBZ2VudC5pbmNsdWRlcygnRHVja0R1Y2tHbycpICYmXG4gICAgICAgICAgICAgICAgIW5hdmlnYXRvci51c2VyQWdlbnQuaW5jbHVkZXMoJ0RkZycpKSB7XG4gICAgICAgICAgICAgICAgcmVwb3J0RXJyb3IoZXJyb3IsICdjb21tZXJjaWFsJywge30sIHtcbiAgICAgICAgICAgICAgICAgICAgYWRTbG90SWQ6IGFkU2xvdC5pZCxcbiAgICAgICAgICAgICAgICAgICAgYWRkaXRpb25hbFNpemVzOiBhZGRpdGlvbmFsU2l6ZXMsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxufTtcbmV4cG9ydCB7IGNyZWF0ZUFkdmVydCB9O1xuIiwiaW1wb3J0IHsgRXZlbnRUaW1lciB9IGZyb20gJ0BndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUvZXZlbnQtdGltZXInO1xuaW1wb3J0IHsgaXNFbGlnaWJsZUZvclRlYWRzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS90YXJnZXRpbmcvdGVhZHMtZWxpZ2liaWxpdHknO1xuaW1wb3J0IHsgYnJlYWtwb2ludHMgYXMgc291cmNlQnJlYWtwb2ludHMgfSBmcm9tICdAZ3VhcmRpYW4vc291cmNlL2ZvdW5kYXRpb25zJztcbmltcG9ydCB7IG9uY2UgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgZ2V0VXJsVmFycyB9IGZyb20gJy4uL2xpYi91cmwnO1xuaW1wb3J0IHsgaW5pdFNsb3RJYXMgfSBmcm9tICcuL2luaXQtc2xvdC1pYXMnO1xuY29uc3QgYnJlYWtwb2ludFZpZXdwb3J0cyA9IHtcbiAgICBtb2JpbGU6IFswLCAwXSwgLy8gdGhpcyBpcyB3aWR0aCAwIHRvIGNvdmVyIGFsbCB3aWR0aHMgdW50aWwgdGhlIG5leHQgYnJlYWtwb2ludCBpZiBhbnlcbiAgICBwaGFibGV0OiBbc291cmNlQnJlYWtwb2ludHMucGhhYmxldCwgMF0sXG4gICAgdGFibGV0OiBbc291cmNlQnJlYWtwb2ludHMudGFibGV0LCAwXSxcbiAgICBkZXNrdG9wOiBbc291cmNlQnJlYWtwb2ludHMuZGVza3RvcCwgMF0sXG4gICAgd2lkZTogW3NvdXJjZUJyZWFrcG9pbnRzLndpZGUsIDBdLFxufTtcbmNvbnN0IGFkVW5pdCA9IG9uY2UoKCkgPT4ge1xuICAgIGNvbnN0IHVybFZhcnMgPSBnZXRVcmxWYXJzKCk7XG4gICAgcmV0dXJuIHVybFZhcnNbJ2FkLXVuaXQnXVxuICAgICAgICA/IGAvJHt3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuZGZwQWNjb3VudElkfS8ke1N0cmluZyh1cmxWYXJzWydhZC11bml0J10pfWBcbiAgICAgICAgOiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuYWRVbml0O1xufSk7XG5jb25zdCBpc0JyZWFrcG9pbnQgPSAoYnJlYWtwb2ludCkgPT4gYnJlYWtwb2ludCBpbiBicmVha3BvaW50Vmlld3BvcnRzO1xuY29uc3QgdG9Hb29nbGVUYWdTaXplID0gKHNpemUpID0+IHtcbiAgICAvLyBub3QgdXNpbmcgd2lkdGggYW5kIGhlaWdodCBoZXJlIGFzIHRvIG1haW50YWluIGNvbXBhdGliaWxpdHkgd2l0aCBwbGFpbiBhcnJheXNcbiAgICByZXR1cm4gc2l6ZVswXSA9PT0gMCAmJiBzaXplWzFdID09PSAwID8gJ2ZsdWlkJyA6IFtzaXplWzBdLCBzaXplWzFdXTtcbn07XG4vKipcbiAqICBUZXN0IGEga25vd24gZ29vZCBzaXplIG1hcHBpbmcsIGlmIHRoaXMgZmFpbHMgd2UgY2FuJ3QgZGVmaW5lIHNsb3RzIVxuICogIFRoaXMgY2FuIGhhcHBlbiBpZiBnb29nbGV0YWcgaGFzIGJlZW4gc2hpbW1lZCBieSBhbiBhZGJsb2NrZXJcbiAqL1xuY29uc3QgY2FuRGVmaW5lU2xvdCA9IG9uY2UoKCkgPT4ge1xuICAgIGNvbnN0IHRlc3RNYXBwaW5nID0gd2luZG93Lmdvb2dsZXRhZ1xuICAgICAgICAuc2l6ZU1hcHBpbmcoKVxuICAgICAgICAuYWRkU2l6ZShbMCwgMF0sIFtbMzAwLCAyNTBdXSlcbiAgICAgICAgLmJ1aWxkKCk7XG4gICAgcmV0dXJuICEhdGVzdE1hcHBpbmc7XG59KTtcbi8qKlxuICogQnVpbGRzIGEgZ29vZ2xldGFnIHNpemUgbWFwcGluZyBiYXNlZCBvbiB0aGUgYnJlYWtwb2ludHMgYW5kIGFkIHNpemVzIGZyb21cbiAqIHRoZSBkZWZpbmVkIHNpemUgbWFwcGluZyBhbmQgdGhlIHZpZXdwb3J0IHNpemVzIGZyb20gc291cmNlLWZvdW5kYXRpb25zLlxuICovXG5jb25zdCBidWlsZEdvb2dsZXRhZ1NpemVNYXBwaW5nID0gKHNpemVNYXBwaW5nKSA9PiB7XG4gICAgY29uc3QgbWFwcGluZyA9IHdpbmRvdy5nb29nbGV0YWcuc2l6ZU1hcHBpbmcoKTtcbiAgICBPYmplY3QuZW50cmllcyhzaXplTWFwcGluZykuZm9yRWFjaCgoW2JyZWFrcG9pbnQsIHNpemVzXSkgPT4ge1xuICAgICAgICBpZiAoaXNCcmVha3BvaW50KGJyZWFrcG9pbnQpKSB7XG4gICAgICAgICAgICBtYXBwaW5nLmFkZFNpemUoYnJlYWtwb2ludFZpZXdwb3J0c1ticmVha3BvaW50XSwgc2l6ZXMubWFwKHRvR29vZ2xlVGFnU2l6ZSkpO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIG1hcHBpbmcuYnVpbGQoKTtcbn07XG5jb25zdCBpc011bHRpU2l6ZSA9IChzaXplKSA9PiB7XG4gICAgcmV0dXJuIEFycmF5LmlzQXJyYXkoc2l6ZSkgJiYgISFzaXplLmxlbmd0aDtcbn07XG5jb25zdCBpc1NpemVJbkFycmF5ID0gKHNpemUsIHNpemVzKSA9PiB7XG4gICAgaWYgKHNpemUgPT09ICdmbHVpZCcpIHtcbiAgICAgICAgcmV0dXJuIHNpemVzLmluY2x1ZGVzKCdmbHVpZCcpO1xuICAgIH1cbiAgICBlbHNlIGlmIChBcnJheS5pc0FycmF5KHNpemUpKSB7XG4gICAgICAgIHJldHVybiAhIXNpemVzLmZpbmQoKGl0ZW0pID0+IGl0ZW1bMF0gPT09IHNpemVbMF0gJiYgaXRlbVsxXSA9PT0gc2l6ZVsxXSk7XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn07XG4vKipcbiAqIFRha2UgYWxsIHRoZSBzaXplcyBpbiBhIHNpemUgbWFwcGluZyBhbmQgcmVkdWNlIHRvIGEgc2luZ2xlIGFycmF5IG9mIHNpemVzLCBmb3IgdXNlIGluIGBkZWZpbmVTbG90YFxuICpcbiAqIEB0b2RvIHRoaXMgaXMgcG9zc2libHkgcmVkdW5kYW50IGFzIHRoZXNlIGFyZSBvbmx5IHVzZWQgaWYgYSBzaXplIG1hcHBpbmcgaXMgbm90IGRlZmluZWQgd2hpY2ggd2UgYWx3YXlzIHByb3ZpZGUuXG4gKiBAcGFyYW0gc2l6ZU1hcHBpbmcgZ29vZ2xldGFnIHNpemUgbWFwcGluZ1xuICogQHJldHVybnMgYWxsIHRoZSBzaXplcyB0aGF0IHdlcmUgcHJlc2VudCBpbiB0aGUgc2l6ZSBtYXBwaW5nXG4gKi9cbmNvbnN0IGNvbGxlY3RTaXplcyA9IChzaXplTWFwcGluZykgPT4ge1xuICAgIGNvbnN0IHNpemVzID0gW107XG4gICAgLy8gYXMgd2UncmUgdXNpbmcgc2l6ZU1hcHBpbmcsIHB1bGwgb3V0IGFsbCB0aGUgYWQgc2l6ZXMsIGFzIGFuIGFycmF5IG9mIGFycmF5c1xuICAgIHNpemVNYXBwaW5nPy5mb3JFYWNoKChbLCBzaXplc0ZvckJyZWFrcG9pbnRdKSA9PiB7XG4gICAgICAgIGlmIChpc011bHRpU2l6ZShzaXplc0ZvckJyZWFrcG9pbnQpKSB7XG4gICAgICAgICAgICBzaXplc0ZvckJyZWFrcG9pbnQuZm9yRWFjaCgoc2l6ZSkgPT4ge1xuICAgICAgICAgICAgICAgIGlmICghaXNTaXplSW5BcnJheShzaXplLCBzaXplcykpIHtcbiAgICAgICAgICAgICAgICAgICAgc2l6ZXMucHVzaChzaXplKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBzaXplcztcbn07XG5jb25zdCBpc0VsaWdpYmxlRm9yT3V0c3RyZWFtID0gKHNsb3RUYXJnZXQpID0+IHR5cGVvZiBzbG90VGFyZ2V0ID09PSAnc3RyaW5nJyAmJlxuICAgIChzbG90VGFyZ2V0ID09PSAnaW5saW5lMScgfHwgc2xvdFRhcmdldCA9PT0gJ3RvcC1hYm92ZS1uYXYnKTtcbmNvbnN0IGFsbG93U2FmZUZyYW1lVG9FeHBhbmQgPSAoc2xvdCkgPT4ge1xuICAgIHNsb3Quc2V0U2FmZUZyYW1lQ29uZmlnKHtcbiAgICAgICAgYWxsb3dPdmVybGF5RXhwYW5zaW9uOiBmYWxzZSxcbiAgICAgICAgYWxsb3dQdXNoRXhwYW5zaW9uOiB0cnVlLFxuICAgICAgICBzYW5kYm94OiB0cnVlLFxuICAgIH0pO1xuICAgIHJldHVybiBzbG90O1xufTtcbmNsYXNzIERlZmluZVNsb3RFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBzaXplTWFwcGluZztcbiAgICByZXBvcnQ7XG4gICAgY29uc3RydWN0b3IobWVzc2FnZSwgc2l6ZU1hcHBpbmcsIHJlcG9ydCA9IHRydWUpIHtcbiAgICAgICAgc3VwZXIobWVzc2FnZSk7XG4gICAgICAgIHRoaXMubmFtZSA9ICdEZWZpbmVTbG90RXJyb3InO1xuICAgICAgICB0aGlzLnNpemVNYXBwaW5nID0gSlNPTi5zdHJpbmdpZnkoc2l6ZU1hcHBpbmcpO1xuICAgICAgICB0aGlzLnJlcG9ydCA9IHJlcG9ydDtcbiAgICB9XG59XG5jb25zdCBkZWZpbmVTbG90ID0gKGFkU2xvdE5vZGUsIHNpemVNYXBwaW5nLCBzbG90VGFyZ2V0aW5nID0ge30pID0+IHtcbiAgICBjb25zdCBzbG90VGFyZ2V0ID0gYWRTbG90Tm9kZS5nZXRBdHRyaWJ1dGUoJ2RhdGEtbmFtZScpO1xuICAgIEV2ZW50VGltZXIuZ2V0KCkubWFyaygnZGVmaW5lU2xvdFN0YXJ0Jywgc2xvdFRhcmdldCk7XG4gICAgY29uc3QgaWQgPSBhZFNsb3ROb2RlLmlkO1xuICAgIGNvbnN0IGdvb2dsZXRhZ1NpemVNYXBwaW5nID0gYnVpbGRHb29nbGV0YWdTaXplTWFwcGluZyhzaXplTWFwcGluZyk7XG4gICAgaWYgKCFnb29nbGV0YWdTaXplTWFwcGluZykge1xuICAgICAgICBpZiAoY2FuRGVmaW5lU2xvdCgpKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRGVmaW5lU2xvdEVycm9yKCdnb29nbGV0YWcuc2l6ZU1hcHBpbmcgZGlkIG5vdCByZXR1cm4gYSBzaXplIG1hcHBpbmcnLCBzaXplTWFwcGluZyk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRGVmaW5lU2xvdEVycm9yKCdDb3VsZCBub3QgZGVmaW5lIHNsb3QuIGdvb2dsZXRhZy5zaXplTWFwcGluZyBoYXMgYmVlbiBzaGltbWVkLicsIHNpemVNYXBwaW5nLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qgc2l6ZXMgPSBjb2xsZWN0U2l6ZXMoZ29vZ2xldGFnU2l6ZU1hcHBpbmcpO1xuICAgIGxldCBzbG90O1xuICAgIGlmIChhZFNsb3ROb2RlLmdldEF0dHJpYnV0ZSgnZGF0YS1vdXQtb2YtcGFnZScpKSB7XG4gICAgICAgIHNsb3QgPSB3aW5kb3cuZ29vZ2xldGFnLmRlZmluZU91dE9mUGFnZVNsb3QoYWRVbml0KCksIGlkKTtcbiAgICAgICAgc2xvdD8uZGVmaW5lU2l6ZU1hcHBpbmcoZ29vZ2xldGFnU2l6ZU1hcHBpbmcpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgc2xvdCA9IHdpbmRvdy5nb29nbGV0YWcuZGVmaW5lU2xvdChhZFVuaXQoKSwgc2l6ZXMsIGlkKTtcbiAgICAgICAgc2xvdD8uZGVmaW5lU2l6ZU1hcHBpbmcoZ29vZ2xldGFnU2l6ZU1hcHBpbmcpO1xuICAgICAgICBpZiAoc2xvdCAmJiBpc0VsaWdpYmxlRm9yT3V0c3RyZWFtKHNsb3RUYXJnZXQpKSB7XG4gICAgICAgICAgICBhbGxvd1NhZmVGcmFtZVRvRXhwYW5kKHNsb3QpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmICghc2xvdCkge1xuICAgICAgICB0aHJvdyBuZXcgRGVmaW5lU2xvdEVycm9yKGBnb29nbGV0YWcuZGVmaW5lU2xvdCBkaWQgbm90IHJldHVybiBhIHNsb3RgLCBzaXplTWFwcGluZyk7XG4gICAgfVxuICAgIGNvbnN0IHNsb3RSZWFkeSA9IGluaXRTbG90SWFzKGlkLCBzbG90KTtcbiAgICB2b2lkIHNsb3RSZWFkeS50aGVuKCgpID0+IHtcbiAgICAgICAgRXZlbnRUaW1lci5nZXQoKS5tYXJrKCdkZWZpbmVTbG90RW5kJywgc2xvdFRhcmdldCk7XG4gICAgICAgIEV2ZW50VGltZXIuZ2V0KCkubWFyaygnc2xvdFJlYWR5Jywgc2xvdFRhcmdldCk7XG4gICAgICAgIC8vIHdhaXQgdW50aWwgSUFTIGhhcyBpbml0aWFsaXNlZCBiZWZvcmUgY2hlY2tpbmcgdGVhZHMgZWxpZ2liaWxpdHlcbiAgICAgICAgY29uc3QgaXNUZWFkc0VsaWdpYmxlID0gaXNFbGlnaWJsZUZvclRlYWRzKGlkKTtcbiAgICAgICAgaWYgKGlzVGVhZHNFbGlnaWJsZSkge1xuICAgICAgICAgICAgc2xvdC5zZXRUYXJnZXRpbmcoJ3RlYWRzRWxpZ2libGUnLCAndHJ1ZScpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgc2xvdC5zZXRUYXJnZXRpbmcoJ3RlYWRzRWxpZ2libGUnLCAnZmFsc2UnKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIGNvbnN0IGlzYm4gPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNibjtcbiAgICBpZiAoc2xvdFRhcmdldCA9PT0gaXNibikge1xuICAgICAgICBzbG90LnNldFRhcmdldGluZygnaXNibicsIGlzYm4pO1xuICAgIH1cbiAgICBjb25zdCBmYWJyaWNLZXlWYWx1ZXMgPSBuZXcgTWFwKFtcbiAgICAgICAgWyd0b3AtYWJvdmUtbmF2JywgJ2ZhYnJpYzEnXSxcbiAgICAgICAgWydtZXJjaGFuZGlzaW5nLWhpZ2gnLCAnZmFicmljMiddLFxuICAgICAgICBbJ21lcmNoYW5kaXNpbmcnLCAnZmFicmljMyddLFxuICAgIF0pO1xuICAgIGNvbnN0IHNsb3RGYWJyaWMgPSBmYWJyaWNLZXlWYWx1ZXMuZ2V0KHNsb3RUYXJnZXQpO1xuICAgIGlmIChzbG90RmFicmljKSB7XG4gICAgICAgIHNsb3Quc2V0VGFyZ2V0aW5nKCdzbG90LWZhYnJpYycsIHNsb3RGYWJyaWMpO1xuICAgIH1cbiAgICBPYmplY3QuZW50cmllcyhzbG90VGFyZ2V0aW5nKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgc2xvdC5zZXRUYXJnZXRpbmcoa2V5LCB2YWx1ZSk7XG4gICAgfSk7XG4gICAgc2xvdC5hZGRTZXJ2aWNlKHdpbmRvdy5nb29nbGV0YWcucHViYWRzKCkpXG4gICAgICAgIC5zZXRUYXJnZXRpbmcoJ3Nsb3QnLCBzbG90VGFyZ2V0KVxuICAgICAgICAuc2V0VGFyZ2V0aW5nKCd0ZXN0Z3JvdXAnLCBTdHJpbmcoTWF0aC5mbG9vcigxMDAgKiBNYXRoLnJhbmRvbSgpKSkpO1xuICAgIHJldHVybiB7XG4gICAgICAgIHNsb3QsXG4gICAgICAgIHNsb3RSZWFkeSxcbiAgICB9O1xufTtcbmV4cG9ydCB7IGJ1aWxkR29vZ2xldGFnU2l6ZU1hcHBpbmcsIGNvbGxlY3RTaXplcywgZGVmaW5lU2xvdCwgY2FuRGVmaW5lU2xvdCwgRGVmaW5lU2xvdEVycm9yLCB9O1xuIiwiaW1wb3J0IHsgb25jZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBnZXRVcmxWYXJzIH0gZnJvbSAnLi4vbGliL3VybCc7XG5jb25zdCBhZFVuaXQgPSBvbmNlKCgpID0+IHtcbiAgICBjb25zdCB1cmxWYXJzID0gZ2V0VXJsVmFycygpO1xuICAgIHJldHVybiB1cmxWYXJzWydhZC11bml0J11cbiAgICAgICAgPyBgLyR7d2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmRmcEFjY291bnRJZH0vJHtTdHJpbmcodXJsVmFyc1snYWQtdW5pdCddKX1gXG4gICAgICAgIDogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmFkVW5pdDtcbn0pO1xuY29uc3QgdGltZW91dCA9IGFzeW5jIChwcm9taXNlLCBtcykgPT4ge1xuICAgIGxldCB0aW1lb3V0SWQ7XG4gICAgcmV0dXJuIFByb21pc2UucmFjZShbXG4gICAgICAgIHByb21pc2UsXG4gICAgICAgIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgICAgICB0aW1lb3V0SWQgPSB3aW5kb3cuc2V0VGltZW91dChyZXNvbHZlLCBtcyk7XG4gICAgICAgIH0pLFxuICAgIF0pLnRoZW4oKHJlc3VsdCkgPT4ge1xuICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSk7XG59O1xuLyoqXG4gKiBGb3IgZWFjaCBhZCBzbG90IGRlZmluZWQsIHdlIHJlcXVlc3QgaW5mb3JtYXRpb24gZnJvbSBJQVMsIGJhc2VkXG4gKiBvbiBzbG90IG5hbWUsIGFkIHVuaXQgYW5kIHNpemVzLiBXZSB0aGVuIGFkZCB0aGlzIHRhcmdldGluZyB0byB0aGVcbiAqIHNsb3QgcHJpb3IgdG8gcmVxdWVzdGluZyBpdCBmcm9tIERGUC5cbiAqXG4gKiBXZSBjcmVhdGUgYSB0aW1lciwgc3VjaCB0aGF0IGlmIHRoZSB0aW1lb3V0IHJlc29sdmVzIGJlZm9yZSB0aGUgcmVxdWVzdFxuICogdG8gSUFTIHJldHVybnMsIHRoZW4gdGhlIHNsb3QgaXMgZGVmaW5lZCB3aXRob3V0IHRoZSBhZGRpdGlvbmFsIElBUyBkYXRhLlxuICogVG8gc2VlIGRlYnVnZ2luZyBvdXRwdXQgZnJvbSBJQVMgYWRkIHRoZSBVUkwgcGFyYW0gYCZpYXNkZWJ1Zz10cnVlYCB0byB0aGUgcGFnZSBVUkxcbiAqXG4gKiB0aGlzIHNob3VsZCBhbGwgaGF2ZSBiZWVuIGluc3RhbnRpYXRlZCBieSBsaWIvdGhpcmQtcGFydHktdGFncy9pYXMuanNcbiAqXG4gKiBAcGFyYW0gaWQgLSB0aGUgc2xvdCBpZFxuICogQHBhcmFtIHNsb3QgLSB0aGUgZ29vZ2xldGFnIHNsb3Qgb2JqZWN0XG4gKiBAcmV0dXJucyBhIHByb21pc2UgdGhhdCByZXNvbHZlcyB3aGVuIHRoZSBJQVMgZGF0YSBpcyByZXR1cm5lZCBvciB0aGUgdGltZW91dCByZXNvbHZlc1xuICoqL1xuY29uc3QgaW5pdFNsb3RJYXMgPSAoaWQsIHNsb3QpID0+IHRpbWVvdXQobmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICB3aW5kb3cuX19pYXNQRVQgPSB3aW5kb3cuX19pYXNQRVQgPz8ge307XG4gICAgY29uc3QgaWFzUEVUID0gd2luZG93Ll9faWFzUEVUO1xuICAgIGlhc1BFVC5xdWV1ZSA9IGlhc1BFVC5xdWV1ZSA/PyBbXTtcbiAgICBpYXNQRVQucHViSWQgPSAnMTAyNDknO1xuICAgIC8vIG5lZWQgdG8gcmVvcmdhbml6ZSB0aGUgdHlwZSBkdWUgdG8gaHR0cHM6Ly9naXRodWIuY29tL21pY3Jvc29mdC9UeXBlU2NyaXB0L2lzc3Vlcy8zMzU5MVxuICAgIGNvbnN0IHNsb3RTaXplcyA9IHNsb3QuZ2V0U2l6ZXMoKTtcbiAgICAvLyBJQVMgT3B0aW1pemF0aW9uIFRhcmdldGluZ1xuICAgIGNvbnN0IGlhc1BFVFNsb3RzID0gW1xuICAgICAgICB7XG4gICAgICAgICAgICBhZFNsb3RJZDogaWQsXG4gICAgICAgICAgICBzaXplOiBzbG90U2l6ZXNcbiAgICAgICAgICAgICAgICAuZmlsdGVyKChzaXplKSA9PiBzaXplICE9PSAnZmx1aWQnKVxuICAgICAgICAgICAgICAgIC5tYXAoKHNpemUpID0+IFtzaXplLmdldFdpZHRoKCksIHNpemUuZ2V0SGVpZ2h0KCldKSxcbiAgICAgICAgICAgIGFkVW5pdFBhdGg6IGFkVW5pdCgpLCAvLyB3aHkgZG8gd2UgaGF2ZSB0aGlzIG1ldGhvZCBhbmQgbm90IGp1c3Qgc2xvdC5nZXRBZFVuaXRQYXRoKCk/XG4gICAgICAgIH0sXG4gICAgXTtcbiAgICBjb25zdCBpYXNEYXRhQ2FsbGJhY2sgPSAodGFyZ2V0aW5nSlNPTikgPT4ge1xuICAgICAgICAvKiAgVGhlcmUgaXMgYSBuYW1lLWNsYXNoIHdpdGggdGhlIGBmcmAgdGFyZ2V0aW5nIHJldHVybmVkIGJ5IElBU1xuICAgICAgICBhbmQgdGhlIGBmcmAgcGFyYW1hdGVyIHdlIGFscmVhZHkgdXNlIGZvciBmcmVxdWVuY3kuIFRoZXJlZm9yZVxuICAgICAgICB3ZSBhcHBseSB0aGUgdGFyZ2V0aW5nIHRvIHRoZSBzbG90IG91cnNlbHZlcyBhbmQgcmVuYW1lIHRoZSBJQVNcbiAgICAgICAgZnIgcGFyYW1ldGVyIHRvIGBmcmFgIChnaXZlbiB0aGF0LCBoZXJlLCBpdCByZWxhdGVzIHRvIGZyYXVkKS5cbiAgICAqL1xuICAgICAgICBjb25zdCB0YXJnZXRpbmcgPSBKU09OLnBhcnNlKHRhcmdldGluZ0pTT04pO1xuICAgICAgICAvLyBicmFuZCBzYWZldHkgaXMgb24gYSBwYWdlIGxldmVsXG4gICAgICAgIE9iamVjdC5rZXlzKHRhcmdldGluZy5icmFuZFNhZmV0eSkuZm9yRWFjaCgoa2V5KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBicmFuZFNhZmV0eVZhbHVlID0gdGFyZ2V0aW5nLmJyYW5kU2FmZXR5W2tleV07XG4gICAgICAgICAgICBpZiAoYnJhbmRTYWZldHlWYWx1ZSkge1xuICAgICAgICAgICAgICAgIHdpbmRvdy5nb29nbGV0YWdcbiAgICAgICAgICAgICAgICAgICAgLnB1YmFkcygpXG4gICAgICAgICAgICAgICAgICAgIC5zZXRUYXJnZXRpbmcoa2V5LCBicmFuZFNhZmV0eVZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGlmICh0YXJnZXRpbmcuZnIpIHtcbiAgICAgICAgICAgIHdpbmRvdy5nb29nbGV0YWcucHViYWRzKCkuc2V0VGFyZ2V0aW5nKCdmcmEnLCB0YXJnZXRpbmcuZnIpO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0YXJnZXRpbmcuY3VzdG9tPy5bJ2lhcy1rdyddKSB7XG4gICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnXG4gICAgICAgICAgICAgICAgLnB1YmFkcygpXG4gICAgICAgICAgICAgICAgLnNldFRhcmdldGluZygnaWFzLWt3JywgdGFyZ2V0aW5nLmN1c3RvbVsnaWFzLWt3J10pO1xuICAgICAgICB9XG4gICAgICAgIC8vIHZpZXdhYmlsaXR5IHRhcmdldGluZyBpcyBvbiBhIHNsb3QgbGV2ZWxcbiAgICAgICAgY29uc3QgaWdub3JlZEtleXMgPSBbJ3B1YiddO1xuICAgICAgICBjb25zdCBzbG90VGFyZ2V0aW5nID0gdGFyZ2V0aW5nLnNsb3RzW2lkXTtcbiAgICAgICAgaWYgKHNsb3RUYXJnZXRpbmcpIHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKHNsb3RUYXJnZXRpbmcpXG4gICAgICAgICAgICAgICAgLmZpbHRlcigoeCkgPT4gIWlnbm9yZWRLZXlzLmluY2x1ZGVzKHgpKVxuICAgICAgICAgICAgICAgIC5mb3JFYWNoKChrZXkpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXRpbmdTbG90ID0gdGFyZ2V0aW5nLnNsb3RzW2lkXTtcbiAgICAgICAgICAgICAgICBpZiAodGFyZ2V0aW5nU2xvdCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCB0YXJnZXRpbmdWYWx1ZSA9IHRhcmdldGluZ1Nsb3Rba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHRhcmdldGluZ1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzbG90LnNldFRhcmdldGluZyhrZXksIHRhcmdldGluZ1ZhbHVlKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJlc29sdmUoKTtcbiAgICB9O1xuICAgIGlhc1BFVC5xdWV1ZS5wdXNoKHtcbiAgICAgICAgYWRTbG90czogaWFzUEVUU2xvdHMsXG4gICAgICAgIGRhdGFIYW5kbGVyOiBpYXNEYXRhQ2FsbGJhY2ssXG4gICAgfSk7XG59KSwgMTAwMCk7XG5leHBvcnQgeyBpbml0U2xvdElhcyB9O1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgb25jZSB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBnZXRDdXJyZW50QnJlYWtwb2ludCB9IGZyb20gJy4uL2xpYi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuaW1wb3J0IHsgZGZwRW52IH0gZnJvbSAnLi4vbGliL2RmcC9kZnAtZW52JztcbmltcG9ydCB7IGdldEFkdmVydEJ5SWQgfSBmcm9tICcuLi9saWIvZGZwL2dldC1hZHZlcnQtYnktaWQnO1xuaW1wb3J0IHsgbG9hZEFkdmVydCwgcmVmcmVzaEFkdmVydCB9IGZyb20gJy4vbG9hZC1hZHZlcnQnO1xuaW1wb3J0IHsgcmVxdWVzdEJpZHNGb3JBZCB9IGZyb20gJy4vcmVxdWVzdC1iaWRzJztcbmNvbnN0IGRpc3BsYXlBZCA9IChhZHZlcnRJZCkgPT4ge1xuICAgIGNvbnN0IGFkdmVydCA9IGdldEFkdmVydEJ5SWQoYWR2ZXJ0SWQpO1xuICAgIGlmIChhZHZlcnQpIHtcbiAgICAgICAgaWYgKGFkdmVydC5pc1JlbmRlcmVkKSB7XG4gICAgICAgICAgICByZWZyZXNoQWR2ZXJ0KGFkdmVydCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBsb2FkQWR2ZXJ0KGFkdmVydCk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuY29uc3QgcmVxdWVzdEJpZHMgPSAoYWR2ZXJ0SWQpID0+IHtcbiAgICBjb25zdCBhZHZlcnQgPSBnZXRBZHZlcnRCeUlkKGFkdmVydElkKTtcbiAgICBpZiAoYWR2ZXJ0KSB7XG4gICAgICAgIHZvaWQgcmVxdWVzdEJpZHNGb3JBZChhZHZlcnQpO1xuICAgIH1cbn07XG5jb25zdCBvbkludGVyc2VjdERpc3BsYXlBZCA9IChlbnRyaWVzLCBvYnNlcnZlcikgPT4ge1xuICAgIGNvbnN0IGFkdmVydElkcyA9IFtdO1xuICAgIGVudHJpZXNcbiAgICAgICAgLmZpbHRlcigoZW50cnkpID0+ICEoJ2lzSW50ZXJzZWN0aW5nJyBpbiBlbnRyeSkgfHwgZW50cnkuaXNJbnRlcnNlY3RpbmcpXG4gICAgICAgIC5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnZGlzcGxheSBvYnNlcnZlciB0cmlnZ2VyZWQgZm9yOiAnLCBlbnRyeS50YXJnZXQuaWQpO1xuICAgICAgICBvYnNlcnZlci51bm9ic2VydmUoZW50cnkudGFyZ2V0KTtcbiAgICAgICAgZGlzcGxheUFkKGVudHJ5LnRhcmdldC5pZCk7XG4gICAgICAgIGFkdmVydElkcy5wdXNoKGVudHJ5LnRhcmdldC5pZCk7XG4gICAgfSk7XG4gICAgZGZwRW52LmFkdmVydHNUb0xvYWQgPSBkZnBFbnYuYWR2ZXJ0c1RvTG9hZC5maWx0ZXIoKGFkdmVydCkgPT4gIWFkdmVydElkcy5pbmNsdWRlcyhhZHZlcnQuaWQpKTtcbn07XG5jb25zdCBvbkludGVyc2VjdFByZWJpZCA9IChlbnRyaWVzLCBvYnNlcnZlcikgPT4ge1xuICAgIGNvbnN0IGFkdmVydElkcyA9IFtdO1xuICAgIGVudHJpZXNcbiAgICAgICAgLmZpbHRlcigoZW50cnkpID0+ICEoJ2lzSW50ZXJzZWN0aW5nJyBpbiBlbnRyeSkgfHwgZW50cnkuaXNJbnRlcnNlY3RpbmcpXG4gICAgICAgIC5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAncHJlYmlkIG9ic2VydmVyIHRyaWdnZXJlZCBmb3I6ICcsIGVudHJ5LnRhcmdldC5pZCk7XG4gICAgICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbnRyeS50YXJnZXQpO1xuICAgICAgICByZXF1ZXN0QmlkcyhlbnRyeS50YXJnZXQuaWQpO1xuICAgICAgICBhZHZlcnRJZHMucHVzaChlbnRyeS50YXJnZXQuaWQpO1xuICAgIH0pO1xufTtcbmNvbnN0IGdldERpc3BsYXlBZE9ic2VydmVyID0gb25jZSgoaXNFYWdlclByZWJpZCkgPT4ge1xuICAgIHJldHVybiBuZXcgd2luZG93LkludGVyc2VjdGlvbk9ic2VydmVyKG9uSW50ZXJzZWN0RGlzcGxheUFkLCB7XG4gICAgICAgIHJvb3RNYXJnaW46IGlzRWFnZXJQcmViaWQgPyAnMTAlIDBweCcgOiAnMjAlIDBweCcsXG4gICAgfSk7XG59KTtcbmNvbnN0IGdldFByZWJpZE9ic2VydmVyID0gb25jZSgoKSA9PiB7XG4gICAgcmV0dXJuIG5ldyB3aW5kb3cuSW50ZXJzZWN0aW9uT2JzZXJ2ZXIob25JbnRlcnNlY3RQcmViaWQsIHtcbiAgICAgICAgcm9vdE1hcmdpbjogJzUwJSAwcHgnLFxuICAgIH0pO1xufSk7XG4vKipcbiAqIE9ubHkgbG9hZCBQcmViaWQgZWFnZXJseSBvbiBkZXNrdG9wIGFuZCBhYm92ZVxuICovXG5jb25zdCBzaG91bGRSdW5FYWdlclByZWJpZCA9ICgpID0+IFsnZGVza3RvcCcsICd3aWRlJ10uaW5jbHVkZXMoZ2V0Q3VycmVudEJyZWFrcG9pbnQoKSk7XG5leHBvcnQgY29uc3QgZW5hYmxlTGF6eUxvYWQgPSAoYWR2ZXJ0KSA9PiB7XG4gICAgaWYgKGRmcEVudi5sYXp5TG9hZE9ic2VydmUpIHtcbiAgICAgICAgY29uc3QgaXNFYWdlclByZWJpZCA9IHNob3VsZFJ1bkVhZ2VyUHJlYmlkKCk7XG4gICAgICAgIGdldERpc3BsYXlBZE9ic2VydmVyKGlzRWFnZXJQcmViaWQpLm9ic2VydmUoYWR2ZXJ0Lm5vZGUpO1xuICAgICAgICBpZiAoaXNFYWdlclByZWJpZCkge1xuICAgICAgICAgICAgZ2V0UHJlYmlkT2JzZXJ2ZXIoKS5vYnNlcnZlKGFkdmVydC5ub2RlKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgZGlzcGxheUFkKGFkdmVydC5pZCk7XG4gICAgfVxufTtcbiIsImltcG9ydCB7IEV2ZW50VGltZXIgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2V2ZW50LXRpbWVyJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJ2Zhc3Rkb20nO1xuaW1wb3J0IHsgc3RyaXBEZnBBZFByZWZpeEZyb20gfSBmcm9tICcuLi9saWIvaGVhZGVyLWJpZGRpbmcvdXRpbHMnO1xuaW1wb3J0IHsgcmVmcmVzaEJpZHNGb3JBZCwgcmVxdWVzdEJpZHNGb3JBZCB9IGZyb20gJy4vcmVxdWVzdC1iaWRzJztcbmNvbnN0IGV2ZW50VGltZXIgPSBFdmVudFRpbWVyLmdldCgpO1xuZXhwb3J0IGNvbnN0IGxvYWRBZHZlcnQgPSAoYWR2ZXJ0KSA9PiB7XG4gICAgY29uc3QgYWROYW1lID0gc3RyaXBEZnBBZFByZWZpeEZyb20oYWR2ZXJ0LmlkKTtcbiAgICBldmVudFRpbWVyLm1hcmsoJ2FkUmVuZGVyU3RhcnQnLCBhZE5hbWUpO1xuICAgIC8vIFRPRE8gY2FuIHNsb3RSZWFkeSBjb21lIGFmdGVyIGhlYWRlciBiaWRkaW5nP1xuICAgIC8vIElmIHNvLCB0aGUgY2FsbGJhY2tzIHB1c2hlZCBvbnRvIHRoZSBpYXMgcXVldWUgaW4gZGVmaW5lLXNsb3QuanNcbiAgICAvLyBjb3VsZCBiZSBydW4gaW4gcGFyYWxsZWwgd2l0aCB0aGUgY2FsbHMgdG8gcmVxdWVzdEJpZHMgYmVsb3csIHJlZHVjaW5nIHRoZVxuICAgIC8vIHRvdGFsIHRpbWUgdG8gZGlzcGxheSB0aGUgYWQuXG4gICAgdm9pZCBhZHZlcnQud2hlblNsb3RSZWFkeVxuICAgICAgICAuY2F0Y2goKCkgPT4ge1xuICAgICAgICAvLyBUaGUgZGlzcGxheSBuZWVkcyB0byBiZSBjYWxsZWQsIGV2ZW4gaW4gdGhlIGV2ZW50IG9mIGFuIGVycm9yLlxuICAgIH0pXG4gICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgZXZlbnRUaW1lci5tYXJrKCdwcmVwYXJlU2xvdFN0YXJ0JywgYWROYW1lKTtcbiAgICAgICAgLy8gSWYgdGhlIGFkdmVydCBoYXMgYWxyZWFkeSBoYWQgYmlkcyByZXF1ZXN0ZWQsIHRoZW4gd2UgZG9uJ3QgbmVlZCB0byByZXF1ZXN0IHRoZW0gYWdhaW4uXG4gICAgICAgIGlmIChhZHZlcnQuaGVhZGVyQmlkZGluZ0JpZFJlcXVlc3QpIHtcbiAgICAgICAgICAgIHJldHVybiBhZHZlcnQuaGVhZGVyQmlkZGluZ0JpZFJlcXVlc3Q7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlcXVlc3RCaWRzRm9yQWQoYWR2ZXJ0KTtcbiAgICB9KVxuICAgICAgICAudGhlbigoKSA9PiB7XG4gICAgICAgIGV2ZW50VGltZXIubWFyaygncHJlcGFyZVNsb3RFbmQnLCBhZE5hbWUpO1xuICAgICAgICBldmVudFRpbWVyLm1hcmsoJ2ZldGNoQWRTdGFydCcsIGFkTmFtZSk7XG4gICAgICAgIHdpbmRvdy5nb29nbGV0YWcuZGlzcGxheShhZHZlcnQuaWQpO1xuICAgIH0pO1xufTtcbmV4cG9ydCBjb25zdCByZWZyZXNoQWR2ZXJ0ID0gKGFkdmVydCkgPT4ge1xuICAgIC8vIGFkdmVydC5zaXplIGNvbnRhaW5zIHRoZSBlZmZlY3RpdmUgc2l6ZSBiZWluZyBkaXNwbGF5ZWQgcHJpb3IgdG8gcmVmcmVzaGluZ1xuICAgIHZvaWQgYWR2ZXJ0LndoZW5TbG90UmVhZHlcbiAgICAgICAgLnRoZW4oKCkgPT4gZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICBpZiAoYWR2ZXJ0LmlkLmluY2x1ZGVzKCdmcm9udHMtYmFubmVyJykpIHtcbiAgICAgICAgICAgIGFkdmVydC5ub2RlXG4gICAgICAgICAgICAgICAgLmNsb3Nlc3QoJy5hZC1zbG90LWNvbnRhaW5lcicpXG4gICAgICAgICAgICAgICAgPy5jbGFzc0xpc3QucmVtb3ZlKCdhZC1zbG90LS1mdWxsLXdpZHRoJyk7XG4gICAgICAgIH1cbiAgICB9KSlcbiAgICAgICAgLnRoZW4oKCkgPT4ge1xuICAgICAgICByZXR1cm4gcmVmcmVzaEJpZHNGb3JBZChhZHZlcnQpO1xuICAgIH0pXG4gICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgYWR2ZXJ0LnNsb3Quc2V0VGFyZ2V0aW5nKCdyZWZyZXNoZWQnLCAndHJ1ZScpO1xuICAgICAgICAvLyBzbG90cyB0aGF0IGhhdmUgcmVmcmVzaGVkIGFyZSBub3QgZWxpZ2libGUgZm9yIHRlYWRzXG4gICAgICAgIGFkdmVydC5zbG90LnNldFRhcmdldGluZygndGVhZHNFbGlnaWJsZScsICdmYWxzZScpO1xuICAgICAgICBpZiAoYWR2ZXJ0LmlkID09PSAnZGZwLWFkLS10b3AtYWJvdmUtbmF2Jykge1xuICAgICAgICAgICAgLy8gZm9yY2UgdGhlIHNsb3Qgc2l6ZXMgdG8gYmUgdGhlIHNhbWUgYXMgYWR2ZXJ0LnNpemUgKGN1cnJlbnQpXG4gICAgICAgICAgICAvLyBvbmx5IHdoZW4gYWR2ZXJ0LnNpemUgaXMgYW4gYXJyYXkgKGZvcmdldCAnZmx1aWQnIGFuZCBvdGhlciBzcGVjaWFscylcbiAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGFkdmVydC5zaXplKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG1hcHBpbmcgPSB3aW5kb3cuZ29vZ2xldGFnLnNpemVNYXBwaW5nKCk7XG4gICAgICAgICAgICAgICAgbWFwcGluZy5hZGRTaXplKFswLCAwXSwgYWR2ZXJ0LnNpemUpO1xuICAgICAgICAgICAgICAgIGFkdmVydC5zbG90LmRlZmluZVNpemVNYXBwaW5nKG1hcHBpbmcuYnVpbGQoKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgd2luZG93Lmdvb2dsZXRhZy5wdWJhZHMoKS5yZWZyZXNoKFthZHZlcnQuc2xvdF0pO1xuICAgIH0pO1xufTtcbiIsImltcG9ydCB7IGE5IH0gZnJvbSAnLi4vbGliL2hlYWRlci1iaWRkaW5nL2E5L2E5JztcbmltcG9ydCB7IHByZWJpZCB9IGZyb20gJy4uL2xpYi9oZWFkZXItYmlkZGluZy9wcmViaWQvcHJlYmlkJztcbmNvbnN0IHJldGFpbkFkU2l6ZU9uUmVmcmVzaCA9IChhZHZlcnRTaXplLCBoYlNsb3QpID0+IHtcbiAgICAvLyBPbmx5IHRvcC1hYm92ZS1uYXYgYW5kIGZyb250cy1iYW5uZXIgYWRzIGFyZSBjdXJyZW50bHkgYXBwbGljYWJsZSBmb3IgdGhlaXIgYWQgc2l6ZSBub3QgY2hhbmdpbmdcbiAgICBpZiAoaGJTbG90LmtleSAhPT0gJ3RvcC1hYm92ZS1uYXYnICYmXG4gICAgICAgICFoYlNsb3Qua2V5LnN0YXJ0c1dpdGgoJ2Zyb250cy1iYW5uZXInKSkge1xuICAgICAgICByZXR1cm4gW2hiU2xvdF07XG4gICAgfVxuICAgIC8vIE5vIHBvaW50IGZvcmNpbmcgYSBzaXplLCBhcyB0aGVyZSBpcyBhbHJlYWR5IG9ubHkgb25lIHBvc3NpYmxlIChtb2JpbGUvdGFibGV0KS5cbiAgICAvLyBTZWUgcHJlYmlkL3Nsb3QtY29uZmlnLmpzXG4gICAgaWYgKGhiU2xvdC5zaXplcy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgcmV0dXJuIFtoYlNsb3RdO1xuICAgIH1cbiAgICAvLyBJZiBhZHZlcnQuc2l6ZSBpcyBub3QgYW4gYXJyYXksIHRoZXJlIGlzIG5vIHBvaW50IGhhdmluZyB0aGlzIGhiU2xvdFxuICAgIGlmICghQXJyYXkuaXNBcnJheShhZHZlcnRTaXplKSkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIC8vIEZvcmNlIHRoZSByZWZyZXNoZWQgYWR2ZXJ0IHRvIGJlIHRoZSBzYW1lIHNpemUgYXMgdGhlIGZpcnN0XG4gICAgcmV0dXJuIFtcbiAgICAgICAge1xuICAgICAgICAgICAgLi4uaGJTbG90LFxuICAgICAgICAgICAgc2l6ZXM6IFtbYWR2ZXJ0U2l6ZVswXSwgYWR2ZXJ0U2l6ZVsxXV1dLFxuICAgICAgICB9LFxuICAgIF07XG59O1xuLyoqXG4gKiBUaGlzIGlzIHVzZWQgdG8gcmVxdWVzdCBiaWRzIGZvciBtdWx0aXBsZSBhZHZlcnRzLCBpdCdzIHBvc3NpYmxlIGZvciBhZHZlcnRzIHRvIGJlXG4gKiBwYXNzZWQgaW4gdGhhdCBoYXZlIGFscmVhZHkgaGFkIGJpZHMgcmVxdWVzdGVkLCB0aGlzIGNhbiBoYXBwZW4gaWYgdGhleSdyZSBhbHJlYWR5IGluXG4gKiB0aGUgdmlld3BvcnQsIGl0IHdpbGwgb25seSByZXF1ZXN0IGJpZHMgZm9yIGFkdmVydHMgdGhhdCBoYXZlbid0IGFscmVhZHkgaGFkIGJpZHMgcmVxdWVzdGVkLlxuICovXG5jb25zdCByZXF1ZXN0Qmlkc0ZvckFkcyA9IGFzeW5jIChhZHZlcnRzKSA9PiB7XG4gICAgY29uc3QgYWRzVG9SZXF1ZXN0Qmlkc0ZvciA9IGFkdmVydHMuZmlsdGVyKChhZHZlcnQpID0+ICFhZHZlcnQuaGVhZGVyQmlkZGluZ0JpZFJlcXVlc3QpO1xuICAgIGNvbnN0IHByb21pc2UgPSBQcm9taXNlLmFsbChbXG4gICAgICAgIHByZWJpZC5yZXF1ZXN0QmlkcyhhZHNUb1JlcXVlc3RCaWRzRm9yKSxcbiAgICAgICAgYTkucmVxdWVzdEJpZHMoYWRzVG9SZXF1ZXN0Qmlkc0ZvciksXG4gICAgXSk7XG4gICAgYWRzVG9SZXF1ZXN0Qmlkc0Zvci5mb3JFYWNoKChhZHZlcnQpID0+IHtcbiAgICAgICAgYWR2ZXJ0LmhlYWRlckJpZGRpbmdCaWRSZXF1ZXN0ID0gcHJvbWlzZTtcbiAgICB9KTtcbiAgICBhd2FpdCBwcm9taXNlO1xufTtcbi8qKlxuICogVGhpcyBpcyB1c2VkIHRvIHJlcXVlc3QgYmlkcyBmb3IgYSBzaW5nbGUgYWR2ZXJ0LiBUaGlzIHNob3VsZCBvbmx5IGJlIGNhbGxlZCBpZlxuICogYW4gYWQgaXMgYWxyZWFkeSBpbiB0aGUgdmlld3BvcnQgYW5kIGxvYWQtYWR2ZXJ0IGlzIGludm9rZWQgaW1tZWRpYXRlbHksIGJlZm9yZVxuICogc3BhY2UtZmluZGVyIGlzIGZpbmlzaGVkIGFuZCBwcmViaWQgaXMgY2FsbGVkIGZvciBhbGwgZHluYW1pYyBzbG90cy5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlcXVlc3RCaWRzRm9yQWQgPSBhc3luYyAoYWR2ZXJ0KSA9PiB7XG4gICAgYWR2ZXJ0LmhlYWRlckJpZGRpbmdCaWRSZXF1ZXN0ID0gcmVxdWVzdEJpZHNGb3JBZHMoW2FkdmVydF0pO1xuICAgIGF3YWl0IGFkdmVydC5oZWFkZXJCaWRkaW5nQmlkUmVxdWVzdDtcbn07XG4vKipcbiAqIFRoaXMgaXMgdXNlZCB0byByZWZyZXNoIGJpZHMgZm9yIGEgc2luZ2xlIGFkdmVydC4gcmV0YWluVG9wQWJvdmVOYXZTbG90U2l6ZSBpc1xuICogdXNlZCB0byBmb3JjZSB0aGUgcmVmcmVzaGVkIGFkdmVydCB0byBiZSB0aGUgc2FtZSBzaXplIGFzIHRoZSBmaXJzdFxuICovXG5leHBvcnQgY29uc3QgcmVmcmVzaEJpZHNGb3JBZCA9IGFzeW5jIChhZHZlcnQpID0+IHtcbiAgICBjb25zdCBwcmViaWRQcm9taXNlID0gcHJlYmlkLnJlcXVlc3RCaWRzKFthZHZlcnRdLCAocHJlYmlkU2xvdCkgPT4gcmV0YWluQWRTaXplT25SZWZyZXNoKGFkdmVydC5zaXplLCBwcmViaWRTbG90KSk7XG4gICAgY29uc3QgYTlQcm9taXNlID0gYTkucmVxdWVzdEJpZHMoW2FkdmVydF0sIChhOVNsb3QpID0+IHJldGFpbkFkU2l6ZU9uUmVmcmVzaChhZHZlcnQuc2l6ZSwgYTlTbG90KSk7XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoW3ByZWJpZFByb21pc2UsIGE5UHJvbWlzZV0pO1xufTtcbiIsImltcG9ydCB7IGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJ2Zhc3Rkb20nO1xuaW1wb3J0IHsgZGZwRW52IH0gZnJvbSAnLi4vbGliL2RmcC9kZnAtZW52JztcbmNvbnN0IHJlbW92ZUZyb21EZnBFbnYgPSAoYWR2ZXJ0KSA9PiB7XG4gICAgZGZwRW52LmFkdmVydHMuZGVsZXRlKGFkdmVydC5pZCk7XG4gICAgZGZwRW52LmFkdmVydHNUb0xvYWQgPSBkZnBFbnYuYWR2ZXJ0c1RvTG9hZC5maWx0ZXIoKF8pID0+IF8gIT09IGFkdmVydCk7XG59O1xuLyoqXG4gKiBGaW5kIHRoZSBoaWdoZXN0IGVsZW1lbnQgcmVzcG9uc2libGUgZm9yIHRoZSBhZHZlcnQuXG4gKlxuICogU29tZXRpbWVzIGFuIGFkdmVydCBoYXMgYW4gYWR2ZXJ0IGNvbnRhaW5lciBhcyBhIGRpcmVjdCBwYXJlbnRcbiAqIFNvbWV0aW1lcyB0aGF0IGNvbnRhaW5lciBoYXMgYSB0b3AtbGV2ZWwgY29udGFpbmVyIGFuY2VzdG9yXG4gKi9cbmNvbnN0IGZpbmRFbGVtZW50VG9SZW1vdmUgPSAoYWR2ZXJ0Tm9kZSkgPT4ge1xuICAgIGNvbnN0IHBhcmVudCA9IGFkdmVydE5vZGUucGFyZW50RWxlbWVudDtcbiAgICBjb25zdCBpc0FkQ29udGFpbmVyID0gcGFyZW50IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQgJiZcbiAgICAgICAgcGFyZW50LmNsYXNzTGlzdC5jb250YWlucygnYWQtc2xvdC1jb250YWluZXInKTtcbiAgICBpZiAoIWlzQWRDb250YWluZXIpIHtcbiAgICAgICAgcmV0dXJuIGFkdmVydE5vZGU7XG4gICAgfVxuICAgIGNvbnN0IHRvcExldmVsQ29udGFpbmVyID0gcGFyZW50LmNsb3Nlc3QoJy50b3AtZnJvbnRzLWJhbm5lci1hZC1jb250YWluZXIsIC50b3AtYmFubmVyLWFkLWNvbnRhaW5lcicpO1xuICAgIGlmICghdG9wTGV2ZWxDb250YWluZXIpIHtcbiAgICAgICAgcmV0dXJuIHBhcmVudDtcbiAgICB9XG4gICAgcmV0dXJuIHRvcExldmVsQ29udGFpbmVyO1xufTtcbmNvbnN0IHJlbW92ZVNsb3RGcm9tRG9tID0gKHNsb3RFbGVtZW50KSA9PiB7XG4gICAgY29uc3QgZWxlbWVudFRvUmVtb3ZlID0gZmluZEVsZW1lbnRUb1JlbW92ZShzbG90RWxlbWVudCk7XG4gICAgZWxlbWVudFRvUmVtb3ZlLnN0eWxlLmRpc3BsYXkgPSAnbm9uZSc7XG59O1xuY29uc3QgZW1wdHlBZHZlcnQgPSAoYWR2ZXJ0KSA9PiB7XG4gICAgbG9nKCdjb21tZXJjaWFsJywgYFJlbW92aW5nIGVtcHR5IGFkdmVydDogJHthZHZlcnQuaWR9YCk7XG4gICAgZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLmRlc3Ryb3lTbG90cyhbYWR2ZXJ0LnNsb3RdKTtcbiAgICAgICAgcmVtb3ZlU2xvdEZyb21Eb20oYWR2ZXJ0Lm5vZGUpO1xuICAgICAgICByZW1vdmVGcm9tRGZwRW52KGFkdmVydCk7XG4gICAgfSk7XG59O1xuZXhwb3J0IHsgZW1wdHlBZHZlcnQsIHJlbW92ZVNsb3RGcm9tRG9tIH07XG5leHBvcnQgY29uc3QgXyA9IHtcbiAgICBmaW5kRWxlbWVudFRvUmVtb3ZlLFxufTtcbiIsImltcG9ydCB7IGdldENvb2tpZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCBjcm9zc0ljb24gZnJvbSAnLi4vLi4vc3RhdGljL3N2Zy9pY29uL2Nyb3NzLnN2Zyc7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi9saWIvZmFzdGRvbS1wcm9taXNlJztcbmNvbnN0IHRlbXBsYXRlc1dpdGhvdXRMYWJlbHMgPSBbXG4gICAgMTAwNzcyMDcsIC8vIENBUElfTVVMVElQTEVfSE9TVEVEXG4gICAgMTAwNjkxNjcsIC8vIENBUElfTVVMVElQTEVfUEFJREZPUlxuICAgIDEyMzE3MDM3LCAvLyBFVkVOVFNfTVVMVElQTEVcbiAgICAxMDA3MDQ4NywgLy8gQ0FQSV9TSU5HTEVfUEFJREZPUlxuICAgIDEwMDYzMjg3LCAvLyBNQU5VQUxfTVVMVElQTEVcbl07XG5jb25zdCBzaG91bGRSZW5kZXJMYWJlbCA9IChhZFNsb3ROb2RlLCBjcmVhdGl2ZVRlbXBsYXRlSWQpID0+IHtcbiAgICBpZiAoY3JlYXRpdmVUZW1wbGF0ZUlkICYmXG4gICAgICAgIHRlbXBsYXRlc1dpdGhvdXRMYWJlbHMuaW5jbHVkZXMoY3JlYXRpdmVUZW1wbGF0ZUlkKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmIChhZFNsb3ROb2RlLmNsYXNzTGlzdC5jb250YWlucygnYWQtc2xvdC0tZnJhbWUnKSB8fFxuICAgICAgICBhZFNsb3ROb2RlLmNsYXNzTGlzdC5jb250YWlucygnYWQtc2xvdC0tZ2MnKSB8fFxuICAgICAgICBhZFNsb3ROb2RlLmNsYXNzTGlzdC5jb250YWlucygndS1oJykgfHxcbiAgICAgICAgLy8gc2V0IGZvciBvdXQtb2YtcGFnZSAoMXgxKSBhbmQgZW1wdHkgKDJ4MikgYWRzXG4gICAgICAgIGFkU2xvdE5vZGUuY2xhc3NMaXN0LmNvbnRhaW5zKCdhZC1zbG90LS1jb2xsYXBzZScpIHx8XG4gICAgICAgIGFkU2xvdE5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsJykgPT09ICdmYWxzZScpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5jb25zdCBzaG91bGRSZW5kZXJDbG9zZUJ1dHRvbiA9IChhZFNsb3ROb2RlKSA9PiBhZFNsb3ROb2RlLmNsYXNzTGlzdC5jb250YWlucygnYWQtc2xvdC0tbW9iaWxlLXN0aWNreScpO1xuY29uc3QgY3JlYXRlQWRDbG9zZURpdiA9ICgpID0+IHtcbiAgICBjb25zdCBidXR0b25FbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuICAgIGJ1dHRvbkVsLmNsYXNzTmFtZSA9ICdhZC1zbG90X19jbG9zZS1idXR0b24nO1xuICAgIGJ1dHRvbkVsLmlubmVySFRNTCA9IGNyb3NzSWNvbjtcbiAgICBidXR0b25FbC5vbmNsaWNrID0gKCkgPT4ge1xuICAgICAgICBjb25zdCBjb250YWluZXIgPSBidXR0b25FbC5jbG9zZXN0KCcubW9iaWxlc3RpY2t5LWNvbnRhaW5lcicpO1xuICAgICAgICBpZiAoY29udGFpbmVyKVxuICAgICAgICAgICAgY29udGFpbmVyLnJlbW92ZSgpO1xuICAgIH07XG4gICAgY29uc3QgY2xvc2VEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBjbG9zZURpdi5zdHlsZS5jc3NUZXh0ID0gJ3Bvc2l0aW9uOiByZWxhdGl2ZTtwYWRkaW5nOiAwO2hlaWdodDogMCc7XG4gICAgY2xvc2VEaXYuYXBwZW5kQ2hpbGQoYnV0dG9uRWwpO1xuICAgIHJldHVybiBjbG9zZURpdjtcbn07XG5jb25zdCBzaG91bGRSZW5kZXJBZFRlc3RMYWJlbCA9IChhZFNsb3ROb2RlKSA9PiAhIWdldENvb2tpZSh7XG4gICAgbmFtZTogJ2FkdGVzdEluTGFiZWxzJyxcbiAgICBzaG91bGRNZW1vaXplOiB0cnVlLFxufSkgJiYgIWFkU2xvdE5vZGUuY2xhc3NMaXN0LmNvbnRhaW5zKCdhZC1zbG90LS1za3knKTtcbi8vIElmIGBhZHRlc3RgIGNvb2tpZSBpcyBzZXQsIGRpc3BsYXkgaXRzIHZhbHVlIGluIHRoZSBhZCBsYWJlbFxuY29uc3QgY3JlYXRlQWRUZXN0TGFiZWwgPSAoc2hvdWxkUmVuZGVyLCBhZFRlc3ROYW1lKSA9PiB7XG4gICAgbGV0IGFkVGVzdExhYmVsID0gJyc7XG4gICAgaWYgKHNob3VsZFJlbmRlciAmJiBhZFRlc3ROYW1lKSB7XG4gICAgICAgIGFkVGVzdExhYmVsICs9IGAgWz9hZHRlc3Q9JHthZFRlc3ROYW1lfV0gYDtcbiAgICB9XG4gICAgcmV0dXJuIGFkVGVzdExhYmVsO1xufTtcbmNvbnN0IGNyZWF0ZUFkVGVzdENvb2tpZVJlbW92YWxMaW5rID0gKCkgPT4ge1xuICAgIGNvbnN0IGFkVGVzdENvb2tpZVJlbW92YWxMaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgYWRUZXN0Q29va2llUmVtb3ZhbExpbmsuc3R5bGUuY3NzVGV4dCA9XG4gICAgICAgICdwb3NpdGlvbjogcmVsYXRpdmU7cGFkZGluZzogMDt0ZXh0LWFsaWduOiBsZWZ0O2JveC1zaXppbmc6IGJvcmRlci1ib3g7ZGlzcGxheTogYmxvY2s7d2lkdGg6IDA7aGVpZ2h0OiAwJztcbiAgICBjb25zdCB1cmwgPSBuZXcgVVJMKHdpbmRvdy5sb2NhdGlvbi5ocmVmKTtcbiAgICB1cmwuc2VhcmNoUGFyYW1zLnNldCgnYWR0ZXN0JywgJ2NsZWFyJyk7XG4gICAgY29uc3QgY2xlYXJMaW5rID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYScpO1xuICAgIGNsZWFyTGluay5jbGFzc05hbWUgPSAnYWQtc2xvdF9fYWR0ZXN0LWNvb2tpZS1jbGVhci1saW5rJztcbiAgICBjbGVhckxpbmsuaHJlZiA9IHVybC5ocmVmO1xuICAgIGNsZWFyTGluay5pbm5lckhUTUwgPSAnY2xlYXInO1xuICAgIGFkVGVzdENvb2tpZVJlbW92YWxMaW5rLmFwcGVuZENoaWxkKGNsZWFyTGluayk7XG4gICAgcmV0dXJuIGFkVGVzdENvb2tpZVJlbW92YWxMaW5rO1xufTtcbmNvbnN0IHJlbmRlckFkdmVydExhYmVsID0gKGFkU2xvdE5vZGUsIGNyZWF0aXZlVGVtcGxhdGVJZCkgPT4ge1xuICAgIHJldHVybiBmYXN0ZG9tLm1lYXN1cmUoKCkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkUmVuZGVyTGFiZWwoYWRTbG90Tm9kZSwgY3JlYXRpdmVUZW1wbGF0ZUlkKSkge1xuICAgICAgICAgICAgY29uc3QgcmVuZGVyQWRUZXN0TGFiZWwgPSBzaG91bGRSZW5kZXJBZFRlc3RMYWJlbChhZFNsb3ROb2RlKTtcbiAgICAgICAgICAgIGNvbnN0IGFkVGVzdENsZWFyRXhpc3RzID0gYWRTbG90Tm9kZS5wYXJlbnROb2RlPy5maXJzdEVsZW1lbnRDaGlsZFxuICAgICAgICAgICAgICAgID8uZmlyc3RFbGVtZW50Q2hpbGQgaW5zdGFuY2VvZiBIVE1MQW5jaG9yRWxlbWVudDtcbiAgICAgICAgICAgIGNvbnN0IGFkVGVzdENvb2tpZU5hbWUgPSBnZXRDb29raWUoe1xuICAgICAgICAgICAgICAgIG5hbWU6ICdhZHRlc3QnLFxuICAgICAgICAgICAgICAgIHNob3VsZE1lbW9pemU6IHRydWUsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGNvbnN0IGFkTGFiZWxDb250ZW50ID0gYEFkdmVydGlzZW1lbnQke2NyZWF0ZUFkVGVzdExhYmVsKHJlbmRlckFkVGVzdExhYmVsLCBhZFRlc3RDb29raWVOYW1lKX1gO1xuICAgICAgICAgICAgcmV0dXJuIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgICAgICBhZFNsb3ROb2RlLnNldEF0dHJpYnV0ZSgnZGF0YS1sYWJlbC1zaG93JywgJ3RydWUnKTtcbiAgICAgICAgICAgICAgICBhZFNsb3ROb2RlLnNldEF0dHJpYnV0ZSgnYWQtbGFiZWwtdGV4dCcsIGFkTGFiZWxDb250ZW50KTtcbiAgICAgICAgICAgICAgICAvLyBSZW1vdmUgdGhpcyBvbmNlIG5ldyBgYWQtc2xvdC1jb250YWluZXItLWNlbnRyZS1zbG90YCBjbGFzcyBpcyBpbiBwbGFjZVxuICAgICAgICAgICAgICAgIGlmIChhZFNsb3ROb2RlLnBhcmVudEVsZW1lbnQ/LmNsYXNzTGlzdC5jb250YWlucygnYWQtc2xvdC1jb250YWluZXInKSAmJlxuICAgICAgICAgICAgICAgICAgICBhZFNsb3ROb2RlLmlkID09PSAnZGZwLWFkLS10b3AtYWJvdmUtbmF2Jykge1xuICAgICAgICAgICAgICAgICAgICBhZFNsb3ROb2RlLnBhcmVudEVsZW1lbnQuc2V0QXR0cmlidXRlKCd0b3AtYWJvdmUtbmF2LWFkLXJlbmRlcmVkJywgJ3RydWUnKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLy8gXFxSZW1vdmUgdGhpc1xuICAgICAgICAgICAgICAgIGlmIChzaG91bGRSZW5kZXJDbG9zZUJ1dHRvbihhZFNsb3ROb2RlKSkge1xuICAgICAgICAgICAgICAgICAgICBhZFNsb3ROb2RlLmluc2VydEJlZm9yZShjcmVhdGVBZENsb3NlRGl2KCksIGFkU2xvdE5vZGUuZmlyc3RDaGlsZCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChyZW5kZXJBZFRlc3RMYWJlbCAmJlxuICAgICAgICAgICAgICAgICAgICBhZFRlc3RDb29raWVOYW1lICYmXG4gICAgICAgICAgICAgICAgICAgICFhZFRlc3RDbGVhckV4aXN0cykge1xuICAgICAgICAgICAgICAgICAgICBhZFNsb3ROb2RlLnBhcmVudE5vZGU/Lmluc2VydEJlZm9yZShjcmVhdGVBZFRlc3RDb29raWVSZW1vdmFsTGluaygpLCBhZFNsb3ROb2RlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfSk7XG59O1xuY29uc3QgcmVuZGVyU3RpY2t5U2Nyb2xsRm9yTW9yZUxhYmVsID0gKGFkU2xvdE5vZGUsIGlzR2FsbGVyeSkgPT4gZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgIGNvbnN0IHNjcm9sbEZvck1vcmVMYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIHNjcm9sbEZvck1vcmVMYWJlbC5jbGFzc0xpc3QuYWRkKCdhZC1zbG90X19zY3JvbGwnKTtcbiAgICBzY3JvbGxGb3JNb3JlTGFiZWwuaW5uZXJIVE1MID0gJ1Njcm9sbCBmb3IgTW9yZSc7XG4gICAgc2Nyb2xsRm9yTW9yZUxhYmVsLnNldEF0dHJpYnV0ZSgncm9sZScsICdidXR0b24nKTtcbiAgICBzY3JvbGxGb3JNb3JlTGFiZWwub25jbGljayA9IChldmVudCkgPT4ge1xuICAgICAgICBhZFNsb3ROb2RlLnNjcm9sbEludG9WaWV3KHtcbiAgICAgICAgICAgIGJlaGF2aW9yOiAnc21vb3RoJyxcbiAgICAgICAgICAgIGJsb2NrOiAnc3RhcnQnLFxuICAgICAgICB9KTtcbiAgICAgICAgZXZlbnQucHJldmVudERlZmF1bHQoKTtcbiAgICB9O1xuICAgIGlmIChpc0dhbGxlcnkpIHtcbiAgICAgICAgc2Nyb2xsRm9yTW9yZUxhYmVsLmNsYXNzTGlzdC5hZGQoJ2FkLXNsb3QtLWRhcmsnKTtcbiAgICB9XG4gICAgYWRTbG90Tm9kZS5hcHBlbmRDaGlsZChzY3JvbGxGb3JNb3JlTGFiZWwpO1xufSk7XG5leHBvcnQgeyByZW5kZXJBZHZlcnRMYWJlbCwgcmVuZGVyU3RpY2t5U2Nyb2xsRm9yTW9yZUxhYmVsLCBzaG91bGRSZW5kZXJMYWJlbCwgdGVtcGxhdGVzV2l0aG91dExhYmVscywgfTtcbiIsImltcG9ydCB7IGFkbWlyYWxBZGJsb2NrUmVjb3ZlcnkgfSBmcm9tICcuL3Rlc3RzL2FkbWlyYWwtYWRibG9ja2VyLXJlY292ZXJ5JztcbmltcG9ydCB7IHByZWJpZDk0NiB9IGZyb20gJy4vdGVzdHMvcHJlYmlkOTQ2Jztcbi8qKlxuICogWW91IG9ubHkgbmVlZCB0byBhZGQgdGVzdHMgdG8gdGhpcyBmaWxlIGlmIHRoZSBjb2RlIHlvdSBhcmUgdGVzdGluZyBpcyBoZXJlIGluXG4gKiB0aGUgY29tbWVyY2lhbCBjb2RlLiBBbnkgdGVzdCBoZXJlIGFsc28gbmVlZHMgdG8gYmUgaW4gYm90aCBEQ1IgYW5kIEZyb250ZW5kLFxuICogYnV0IGFueSB0ZXN0cyBpbiBEQ1IgYW5kIEZyb250ZW5kIGRvIG5vdCBuZWVkIHRvIG5lY2Vzc2FyaWx5IGJlIGFkZGVkIGhlcmUuXG4gKi9cbmV4cG9ydCBjb25zdCBjb25jdXJyZW50VGVzdHMgPSBbXG4gICAgLy8gb25lIHRlc3QgcGVyIGxpbmVcbiAgICBwcmViaWQ5NDYsXG4gICAgYWRtaXJhbEFkYmxvY2tSZWNvdmVyeSxcbl07XG4iLCJleHBvcnQgY29uc3QgZ2V0Rm9yY2VkUGFydGljaXBhdGlvbnNGcm9tVXJsID0gKCkgPT4ge1xuICAgIGlmICh3aW5kb3cubG9jYXRpb24uaGFzaC5zdGFydHNXaXRoKCcjYWInKSkge1xuICAgICAgICBjb25zdCB0b2tlbnMgPSB3aW5kb3cubG9jYXRpb24uaGFzaC5yZXBsYWNlKCcjYWItJywgJycpLnNwbGl0KCcsJyk7XG4gICAgICAgIHJldHVybiB0b2tlbnMucmVkdWNlKChvYmosIHRva2VuKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBbdGVzdElkLCB2YXJpYW50SWRdID0gdG9rZW4uc3BsaXQoJz0nKTtcbiAgICAgICAgICAgIGlmICh0ZXN0SWQpIHtcbiAgICAgICAgICAgICAgICBpZiAodmFyaWFudElkKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAuLi5vYmosXG4gICAgICAgICAgICAgICAgICAgICAgICBbdGVzdElkXToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhcmlhbnQ6IHZhcmlhbnRJZCxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIC4uLm9iaixcbiAgICAgICAgICAgICAgICAgICAgW3Rlc3RJZF06IHVuZGVmaW5lZCxcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIG9iajtcbiAgICAgICAgfSwge30pO1xuICAgIH1cbiAgICByZXR1cm4ge307XG59O1xuIiwiaW1wb3J0IHsgQUIgfSBmcm9tICdAZ3VhcmRpYW4vYWItY29yZSc7XG5pbXBvcnQgeyBnZXRDb29raWUsIGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGdldFBhcnRpY2lwYXRpb25zRnJvbUxvY2FsU3RvcmFnZSwgc2V0UGFydGljaXBhdGlvbnNJbkxvY2FsU3RvcmFnZSwgfSBmcm9tICcuLi9saWIvYWItbG9jYWxzdG9yYWdlJztcbmltcG9ydCB7IGNvbmN1cnJlbnRUZXN0cyB9IGZyb20gJy4vYWItdGVzdHMnO1xuaW1wb3J0IHsgZ2V0Rm9yY2VkUGFydGljaXBhdGlvbnNGcm9tVXJsIH0gZnJvbSAnLi9hYi11cmwnO1xuY29uc3QgbXZ0TWluVmFsdWUgPSAxO1xuY29uc3QgbXZ0TWF4VmFsdWUgPSAxXzAwMF8wMDA7XG4vKiogUGFyc2UgYSB2YWxpZCBNVlQgSUQgYmV0d2VlbiAxIGFuZCAxLDAwMCwwMDAgb3IgdW5kZWZpbmVkIGlmIGl0IGZhaWxzICovXG5jb25zdCBwYXJzZU12dElkID0gKGlkKSA9PiB7XG4gICAgaWYgKCFpZClcbiAgICAgICAgcmV0dXJuOyAvLyBudWxsIG9yIGVtcHR5IHN0cmluZ1xuICAgIGNvbnN0IG51bWJlciA9IE51bWJlcihpZCk7XG4gICAgaWYgKE51bWJlci5pc05hTihudW1iZXIpKVxuICAgICAgICByZXR1cm47XG4gICAgaWYgKG51bWJlciA8IG12dE1pblZhbHVlKVxuICAgICAgICByZXR1cm47XG4gICAgaWYgKG51bWJlciA+IG12dE1heFZhbHVlKVxuICAgICAgICByZXR1cm47XG4gICAgcmV0dXJuIG51bWJlcjtcbn07XG5jb25zdCBnZXRNdnRJZCA9ICgpID0+IHBhcnNlTXZ0SWQoZ2V0Q29va2llKHtcbiAgICBuYW1lOiAnR1VfbXZ0X2lkJyxcbiAgICBzaG91bGRNZW1vaXplOiB0cnVlLFxufSkpO1xuY29uc3QgbXZ0SWQgPSBnZXRNdnRJZCgpO1xuY29uc3QgYWJUZXN0U3dpdGNoZXMgPSBPYmplY3QuZW50cmllcyh3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzKS5yZWR1Y2UoKHByZXYsIFtrZXksIHZhbF0pID0+ICh7IC4uLnByZXYsIFtrZXldOiB2YWwgfSksIHt9KTtcbmNvbnN0IGluaXQgPSAoKSA9PiB7XG4gICAgY29uc3QgZm9yY2VkVGVzdFZhcmlhbnRzID0ge1xuICAgICAgICAuLi5nZXRQYXJ0aWNpcGF0aW9uc0Zyb21Mb2NhbFN0b3JhZ2UoKSxcbiAgICAgICAgLi4uZ2V0Rm9yY2VkUGFydGljaXBhdGlvbnNGcm9tVXJsKCksXG4gICAgfTtcbiAgICBzZXRQYXJ0aWNpcGF0aW9uc0luTG9jYWxTdG9yYWdlKGZvcmNlZFRlc3RWYXJpYW50cyk7XG4gICAgY29uc3Qgb3BoYW5FdmVudHMgPSBbXTtcbiAgICAvLyBJZiBvcGhhbiBpcyBub3QgYXZhaWxhYmxlLCBzdG9yZSB0aGUgZXZlbnRzIGluIGFuIGFycmF5IGFuZCByZXBsYXkgdGhlbSB3aGVuIG9waGFuIGlzIGF2YWlsYWJsZVxuICAgIGNvbnN0IG9waGFuUmVjb3JkID0gKGV2ZW50KSA9PiB7XG4gICAgICAgIG9waGFuRXZlbnRzLnB1c2goZXZlbnQpO1xuICAgICAgICBpZiAod2luZG93Lmd1YXJkaWFuLm9waGFuKSB7XG4gICAgICAgICAgICBvcGhhbkV2ZW50cy5mb3JFYWNoKChlKSA9PiB3aW5kb3cuZ3VhcmRpYW4ub3BoYW4/LnJlY29yZChlKSk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IGFiID0gbmV3IEFCKHtcbiAgICAgICAgbXZ0SWQ6IG12dElkID8/IC0xLFxuICAgICAgICBtdnRNYXhWYWx1ZSxcbiAgICAgICAgcGFnZUlzU2Vuc2l0aXZlOiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNTZW5zaXRpdmUsXG4gICAgICAgIGFiVGVzdFN3aXRjaGVzLFxuICAgICAgICBhcnJheU9mVGVzdE9iamVjdHM6IGNvbmN1cnJlbnRUZXN0cyxcbiAgICAgICAgZm9yY2VkVGVzdFZhcmlhbnRzLFxuICAgICAgICBvcGhhblJlY29yZCxcbiAgICAgICAgc2VydmVyU2lkZVRlc3RzOiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnRlc3RzID8/IHt9LFxuICAgICAgICBlcnJvclJlcG9ydGVyOiAoZXJyb3IpID0+IHtcbiAgICAgICAgICAgIGNvbnNvbGUubG9nKCdBQiB0ZXN0cyBlcnJvcjonLCBlcnJvcik7XG4gICAgICAgIH0sXG4gICAgfSk7XG4gICAgY29uc3QgYWxsUnVubmFibGVUZXN0cyA9IGFiLmFsbFJ1bm5hYmxlVGVzdHMoY29uY3VycmVudFRlc3RzKTtcbiAgICBhYi50cmFja0FCVGVzdHMoYWxsUnVubmFibGVUZXN0cyk7XG4gICAgYWIucmVnaXN0ZXJJbXByZXNzaW9uRXZlbnRzKGFsbFJ1bm5hYmxlVGVzdHMpO1xuICAgIGFiLnJlZ2lzdGVyQ29tcGxldGVFdmVudHMoYWxsUnVubmFibGVUZXN0cyk7XG4gICAgbG9nKCdjb21tZXJjaWFsJywgJ0FCIHRlc3RzIGluaXRpYWxpc2VkJyk7XG4gICAgcmV0dXJuIGFiO1xufTtcbmV4cG9ydCBjb25zdCBnZXRQYXJ0aWNpcGF0aW9ucyA9ICgpID0+IHtcbiAgICBjb25zdCBhYiA9IGluaXQoKTtcbiAgICBjb25zdCBydW5uYWJsZVRlc3RzID0gYWIuYWxsUnVubmFibGVUZXN0cyhjb25jdXJyZW50VGVzdHMpO1xuICAgIGNvbnN0IHBhcnRpY2lwYXRpb25zID0gcnVubmFibGVUZXN0cy5yZWR1Y2UoKGFjYywgdGVzdCkgPT4ge1xuICAgICAgICBhY2NbdGVzdC5pZF0gPSB7IHZhcmlhbnQ6IHRlc3QudmFyaWFudFRvUnVuLmlkIH07XG4gICAgICAgIHJldHVybiBhY2M7XG4gICAgfSwge30pO1xuICAgIHJldHVybiBwYXJ0aWNpcGF0aW9ucztcbn07XG5leHBvcnQgY29uc3QgaXNVc2VySW5WYXJpYW50ID0gKHRlc3QsIHZhcmlhbnRJZCkgPT4ge1xuICAgIGNvbnN0IGFiID0gaW5pdCgpO1xuICAgIHJldHVybiBhYi5pc1VzZXJJblZhcmlhbnQodGVzdC5pZCwgdmFyaWFudElkKTtcbn07XG5leHBvcnQgY29uc3QgZ2V0VmFyaWFudCA9ICh0ZXN0KSA9PiB7XG4gICAgY29uc3QgcGFydGljaXBhdGlvbnMgPSBnZXRQYXJ0aWNpcGF0aW9ucygpO1xuICAgIHJldHVybiBwYXJ0aWNpcGF0aW9uc1t0ZXN0LmlkXT8udmFyaWFudDtcbn07XG4iLCJleHBvcnQgY29uc3QgYWRtaXJhbEFkYmxvY2tSZWNvdmVyeSA9IHtcbiAgICBpZDogJ0FkbWlyYWxBZGJsb2NrUmVjb3ZlcnknLFxuICAgIGF1dGhvcjogJ0Bjb21tZXJjaWFsLWRldicsXG4gICAgc3RhcnQ6ICcyMDI1LTA4LTEzJyxcbiAgICBleHBpcnk6ICcyMDI1LTA5LTE3JyxcbiAgICBhdWRpZW5jZTogMTAwIC8gMTAwLFxuICAgIGF1ZGllbmNlT2Zmc2V0OiAwIC8gMTAwLFxuICAgIGF1ZGllbmNlQ3JpdGVyaWE6ICcnLFxuICAgIHN1Y2Nlc3NNZWFzdXJlOiAnJyxcbiAgICBkZXNjcmlwdGlvbjogJ1Rlc3QgdGhlIEFkbWlyYWwgYWQgYmxvY2tlciBkZXRlY3Rpb24gaW50ZWdyYXRpb24gYWhlYWQgb2YgZ28tbGl2ZScsXG4gICAgdmFyaWFudHM6IFtcbiAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICdjb250cm9sJyxcbiAgICAgICAgICAgIHRlc3Q6ICgpID0+IHtcbiAgICAgICAgICAgICAgICAvKiBuby1vcCAqL1xuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgLyoqXG4gICAgICAgICAqIHZhcmlhbnQtZGV0ZWN0IHdpbGwgcnVuIHRoZSBBZG1pcmFsIHNjcmlwdCBidXQgd2lsbCBub3QgbGF1bmNoXG4gICAgICAgICAqIHRoZSByZWNvdmVyeSBtb2RhbCBmb3IgdXNlcnMgd2l0aCBhZCBibG9ja2Vyc1xuICAgICAgICAgKi9cbiAgICAgICAge1xuICAgICAgICAgICAgaWQ6ICd2YXJpYW50LWRldGVjdCcsXG4gICAgICAgICAgICB0ZXN0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgLyogbm8tb3AgKi9cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiB2YXJpYW50LXJlY292ZXIgd2lsbCBydW4gdGhlIEFkbWlyYWwgc2NyaXB0IGFuZCBsYXVuY2ggdGhlXG4gICAgICAgICAqIHJlY292ZXJ5IG1vZGFsIGZvciB1c2VycyB3aXRoIGFkIGJsb2NrZXJzXG4gICAgICAgICAqL1xuICAgICAgICB7XG4gICAgICAgICAgICBpZDogJ3ZhcmlhbnQtcmVjb3ZlcicsXG4gICAgICAgICAgICB0ZXN0OiAoKSA9PiB7XG4gICAgICAgICAgICAgICAgLyogbm8tb3AgKi9cbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgXSxcbiAgICBjYW5SdW46ICgpID0+IHRydWUsXG59O1xuIiwiZXhwb3J0IGNvbnN0IHByZWJpZDk0NiA9IHtcbiAgICBpZDogJ1ByZWJpZDk0NicsXG4gICAgYXV0aG9yOiAnQGNvbW1lcmNpYWwtZGV2JyxcbiAgICBzdGFydDogJzIwMjUtMDgtMTInLFxuICAgIGV4cGlyeTogJzIwMjUtMDgtMjknLFxuICAgIGF1ZGllbmNlOiA1IC8gMTAwLFxuICAgIGF1ZGllbmNlT2Zmc2V0OiAwIC8gMTAwLFxuICAgIGF1ZGllbmNlQ3JpdGVyaWE6ICcnLFxuICAgIHN1Y2Nlc3NNZWFzdXJlOiAnJyxcbiAgICBkZXNjcmlwdGlvbjogJ1Rlc3QgdjkuNDYuMCBvZiBQcmViaWQgYWhlYWQgb2YgZ2VuZXJhbCB1cGdyYWRlJyxcbiAgICB2YXJpYW50czogW1xuICAgICAgICB7XG4gICAgICAgICAgICBpZDogJ2NvbnRyb2wnLFxuICAgICAgICAgICAgdGVzdDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIC8qIG5vLW9wICovXG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBpZDogJ3ZhcmlhbnQnLFxuICAgICAgICAgICAgdGVzdDogKCkgPT4ge1xuICAgICAgICAgICAgICAgIC8qIG5vLW9wICovXG4gICAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgIF0sXG4gICAgY2FuUnVuOiAoKSA9PiB0cnVlLFxufTtcbiIsImltcG9ydCB7IG9uQ29uc2VudENoYW5nZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmxldCBpbml0aWFsQ29uc2VudFN0YXRlO1xuLyoqXG4gKiBJZiBjb25zZW50IGhhcyBiZWVuIHNldCwgYW5kIGlmIGNvbnNlbnQgdGhlbiBjaGFuZ2VzLCByZWxvYWQgdGhlIHBhZ2Ugc28gdGhlIGNvcnJlY3RcbiAqIHN0YXRlIGlzIHJlZmxlY3RlZCBpbiB0aGUgcmVuZGVyZWQgcGFnZVxuICovXG5jb25zdCByZWxvYWRQYWdlT25Db25zZW50Q2hhbmdlID0gKCkgPT4ge1xuICAgIG9uQ29uc2VudENoYW5nZSgoY29uc2VudCkgPT4ge1xuICAgICAgICBpZiAoaW5pdGlhbENvbnNlbnRTdGF0ZSA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBpbml0aWFsQ29uc2VudFN0YXRlID0gY29uc2VudDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaW5pdGlhbENvbnNlbnRTdGF0ZS5jYW5UYXJnZXQgIT09IGNvbnNlbnQuY2FuVGFyZ2V0KSB7XG4gICAgICAgICAgICB3aW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgICAgIH1cbiAgICB9LCB0cnVlKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuZXhwb3J0IHsgcmVsb2FkUGFnZU9uQ29uc2VudENoYW5nZSB9O1xuIiwiaW1wb3J0IHsgcmVtb3ZlQ29va2llLCBzZXRDb29raWUgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBnZXRVcmxWYXJzIH0gZnJvbSAnLi4vLi4vbGliL3VybCc7XG4vKipcbiAqIFNldCBvciByZW1vdmUgYWR0ZXN0IGNvb2tpZS5cbiAqIFRoaXMgaXMgdXNlZCBhcyBhIGN1c3RvbSB0YXJnZXRpbmcgcGFyYW1ldGVyIGluIEdvb2dsZSBBZCBNYW5hZ2VyXG4gKiBpbiBvcmRlciB0byB0ZXN0IGluZGl2aWR1YWwgbGluZSBpdGVtc1xuICogQHJldHVybnMgUHJvbWlzZVxuICovXG5jb25zdCBpbml0ID0gKCkgPT4ge1xuICAgIGNvbnN0IHF1ZXJ5UGFyYW1zID0gZ2V0VXJsVmFycygpO1xuICAgIGlmIChxdWVyeVBhcmFtcy5hZHRlc3QgPT09ICdjbGVhcicpIHtcbiAgICAgICAgcmVtb3ZlQ29va2llKHsgbmFtZTogJ2FkdGVzdCcgfSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKHF1ZXJ5UGFyYW1zLmFkdGVzdCkge1xuICAgICAgICBzZXRDb29raWUoe1xuICAgICAgICAgICAgbmFtZTogJ2FkdGVzdCcsXG4gICAgICAgICAgICB2YWx1ZTogZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5UGFyYW1zLmFkdGVzdCksXG4gICAgICAgICAgICBkYXlzVG9MaXZlOiAxMCxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbn07XG5leHBvcnQgeyBpbml0IH07XG4iLCJpbXBvcnQgeyByZW1vdmVDb29raWUsIHNldENvb2tpZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGdldFVybFZhcnMgfSBmcm9tICcuLi8uLi9saWIvdXJsJztcbi8qKlxuICogTm90IHRvIGJlIGNvbmZ1c2VkIHdpdGggc2V0LWFkdGVzdC1jb29raWUudHMhXG4gKiBTZXQgb3IgcmVtb3ZlIGBhZHRlc3RJbkxhYmVsc2AgY29va2llXG4gKiBUaGlzIGlzIHVzZWQgd2hlbiBkZXRlcm1pbmluZyB3aGV0aGVyIG9yIG5vdCB0byBkaXNwbGF5IHRoZSB2YWx1ZSBvZiB0aGUgYGFkdGVzdGAgY29va2llIGluIGFkIGxhYmVsc1xuICogQHJldHVybnMgUHJvbWlzZVxuICovXG5jb25zdCBpbml0ID0gKCkgPT4ge1xuICAgIGNvbnN0IHF1ZXJ5UGFyYW1zID0gZ2V0VXJsVmFycygpO1xuICAgIGlmIChxdWVyeVBhcmFtcy5hZHRlc3RJbkxhYmVscyA9PT0gJ2NsZWFyJykge1xuICAgICAgICByZW1vdmVDb29raWUoeyBuYW1lOiAnYWR0ZXN0SW5MYWJlbHMnIH0pO1xuICAgIH1cbiAgICBlbHNlIGlmIChxdWVyeVBhcmFtcy5hZHRlc3RJbkxhYmVscykge1xuICAgICAgICBzZXRDb29raWUoe1xuICAgICAgICAgICAgbmFtZTogJ2FkdGVzdEluTGFiZWxzJyxcbiAgICAgICAgICAgIHZhbHVlOiAndHJ1ZScsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuZXhwb3J0IHsgaW5pdCB9O1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgY3JlYXRlQWR2ZXJ0IH0gZnJvbSAnLi4vZGVmaW5lL2NyZWF0ZS1hZHZlcnQnO1xuaW1wb3J0IHsgZW5hYmxlTGF6eUxvYWQgfSBmcm9tICcuLi9kaXNwbGF5L2xhenktbG9hZCc7XG5pbXBvcnQgeyBsb2FkQWR2ZXJ0IH0gZnJvbSAnLi4vZGlzcGxheS9sb2FkLWFkdmVydCc7XG5pbXBvcnQgeyBkZnBFbnYgfSBmcm9tICcuLi9saWIvZGZwL2RmcC1lbnYnO1xuaW1wb3J0IHsgcXVldWVBZHZlcnQgfSBmcm9tICcuLi9saWIvZGZwL3F1ZXVlLWFkdmVydCc7XG5pbXBvcnQgeyByZXBvcnRFcnJvciB9IGZyb20gJy4uL2xpYi9lcnJvci9yZXBvcnQtZXJyb3InO1xuY29uc3QgZGlzcGxheUFkID0gKGFkdmVydCwgZm9yY2VEaXNwbGF5KSA9PiB7XG4gICAgaWYgKGRmcEVudi5zaG91bGRMYXp5TG9hZCgpICYmICFmb3JjZURpc3BsYXkpIHtcbiAgICAgICAgcXVldWVBZHZlcnQoYWR2ZXJ0KTtcbiAgICAgICAgZW5hYmxlTGF6eUxvYWQoYWR2ZXJ0KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGxvYWRBZHZlcnQoYWR2ZXJ0KTtcbiAgICB9XG59O1xuY29uc3QgZmlsbER5bmFtaWNBZFNsb3QgPSAoYWRTbG90LCBmb3JjZURpc3BsYXksIGFkZGl0aW9uYWxTaXplcywgc2xvdFRhcmdldGluZykgPT4ge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLmNtZC5wdXNoKCgpID0+IHtcbiAgICAgICAgICAgIC8vIERvbid0IHJlY3JlYXRlIGFuIGFkdmVydCBpZiBvbmUgaGFzIGFscmVhZHkgYmVlbiBjcmVhdGVkIGZvciB0aGlzIHNsb3RcbiAgICAgICAgICAgIGlmIChkZnBFbnYuYWR2ZXJ0cy5oYXMoYWRTbG90LmlkKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGVycm9yTWVzc2FnZSA9IGBBdHRlbXB0aW5nIHRvIGFkZCBzbG90IHdpdGggZXhpc2l0aW5nIGlkICR7YWRTbG90LmlkfWA7XG4gICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgZXJyb3JNZXNzYWdlKTtcbiAgICAgICAgICAgICAgICByZXBvcnRFcnJvcihFcnJvcihlcnJvck1lc3NhZ2UpLCAnY29tbWVyY2lhbCcsIHtcbiAgICAgICAgICAgICAgICAgICAgc2xvdElkOiBhZFNsb3QuaWQsXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgYWR2ZXJ0ID0gY3JlYXRlQWR2ZXJ0KGFkU2xvdCwgYWRkaXRpb25hbFNpemVzLCBzbG90VGFyZ2V0aW5nKTtcbiAgICAgICAgICAgIGlmIChhZHZlcnQgPT09IG51bGwpXG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgZGZwRW52LmFkdmVydHMuc2V0KGFkdmVydC5pZCwgYWR2ZXJ0KTtcbiAgICAgICAgICAgIGRpc3BsYXlBZChhZHZlcnQsIGZvcmNlRGlzcGxheSk7XG4gICAgICAgICAgICByZXNvbHZlKGFkdmVydCk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IGZpbGxEeW5hbWljQWRTbG90IH07XG4iLCJpbXBvcnQgeyBhZFNpemVzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBjb21tZXJjaWFsRmVhdHVyZXMgfSBmcm9tICcuLi8uLi9saWIvY29tbWVyY2lhbC1mZWF0dXJlcyc7XG5pbXBvcnQgeyBhZFNsb3RDb250YWluZXJDbGFzcywgY3JlYXRlQWRTbG90LCB3cmFwU2xvdEluQ29udGFpbmVyLCB9IGZyb20gJy4uLy4uL2xpYi9jcmVhdGUtYWQtc2xvdCc7XG5pbXBvcnQgeyBnZXRDdXJyZW50QnJlYWtwb2ludCB9IGZyb20gJy4uLy4uL2xpYi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vLi4vbGliL2Zhc3Rkb20tcHJvbWlzZSc7XG5pbXBvcnQgeyBjb21wdXRlU3RpY2t5SGVpZ2h0cywgaW5zZXJ0SGVpZ2h0U3R5bGVzIH0gZnJvbSAnLi4vc3RpY2t5LWlubGluZXMnO1xuaW1wb3J0IHsgaW5pdENhcnJvdCB9IGZyb20gJy4vY2Fycm90LXRyYWZmaWMtZHJpdmVyJztcbmltcG9ydCB7IHJ1bGVzIH0gZnJvbSAnLi9ydWxlcyc7XG5pbXBvcnQgeyBzcGFjZUZpbGxlciB9IGZyb20gJy4vc3BhY2UtZmlsbGVyJztcbmNvbnN0IGFydGljbGVCb2R5U2VsZWN0b3IgPSAnLmFydGljbGUtYm9keS1jb21tZXJjaWFsLXNlbGVjdG9yJztcbmNvbnN0IGlzUGFpZENvbnRlbnQgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNQYWlkQ29udGVudDtcbi8qKlxuICogR2V0IHRoZSBjbGFzc25hbWUgZm9yIGFuIGFkIHNsb3QgY29udGFpbmVyXG4gKlxuICogV2UgYWRkIDIgdG8gdGhlIGluZGV4IGJlY2F1c2UgdGhlc2UgYXJlIGFsd2F5cyBhZHMgYWRkZWQgaW4gdGhlIHNlY29uZCBwYXNzLlxuICpcbiAqIGUuZy4gdGhlIDB0aCBjb250YWluZXIgaW5zZXJ0ZWQgaW4gcGFzcyAyIHdpbGwgaGF2ZSBzdWZmaXggYC0yYCB0byBtYXRjaCBgaW5saW5lMmBcbiAqXG4gKiBAcGFyYW0gaSBJbmRleCBvZiB3aW5uaW5nIHBhcmFncmFwaFxuICogQHJldHVybnMgVGhlIGNsYXNzbmFtZSBmb3IgY29udGFpbmVyXG4gKi9cbmNvbnN0IGdldFN0aWNreUNvbnRhaW5lckNsYXNzbmFtZSA9IChpKSA9PiBgJHthZFNsb3RDb250YWluZXJDbGFzc30tJHtpICsgMn1gO1xuY29uc3QgaW5zZXJ0U2xvdEF0UGFyYSA9IGFzeW5jIChwYXJhLCBuYW1lLCB0eXBlLCBjbGFzc2VzLCBjb250YWluZXJPcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCBhZCA9IGNyZWF0ZUFkU2xvdCh0eXBlLCB7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIGNsYXNzZXMsXG4gICAgfSk7XG4gICAgY29uc3Qgbm9kZSA9IHdyYXBTbG90SW5Db250YWluZXIoYWQsIGNvbnRhaW5lck9wdGlvbnMpO1xuICAgIGF3YWl0IGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgaWYgKHBhcmEucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgcGFyYS5wYXJlbnROb2RlLmluc2VydEJlZm9yZShub2RlLCBwYXJhKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBhZDtcbn07XG4vKipcbiAqIERlY2lkZSB3aGV0aGVyIHdlIGhhdmUgZW5vdWdoIHNwYWNlIHRvIGFkZCBhZGRpdGlvbmFsIHNpemVzIGZvciBhIGdpdmVuIGFkdmVydC5cbiAqIFRoaXMgZnVuY3Rpb24gZW5zdXJlcyB3ZSBkb24ndCBpbnNlcnQgbGFyZ2UgaGVpZ2h0IGFkcyBhdCB0aGUgYm90dG9tIG9mIGFydGljbGVzLFxuICogd2hlbiB0aGVyZSdzIG5vdCBlbm91Z2ggcm9vbS5cbiAqXG4gKiBUaGlzIHByZXZlbnRzIGFkdmVydHMgYXQgdGhlIGJvdHRvbSBvZiBhcnRpY2xlcyBwdXNoaW5nIGRvd24gY29udGVudC5cbiAqL1xuY29uc3QgZGVjaWRlQWRkaXRpb25hbFNpemVzID0gYXN5bmMgKHdpbm5pbmdQYXJhLCBzaXplcywgaXNMYXN0SW5saW5lKSA9PiB7XG4gICAgLy8gSWYgdGhpcyBhZCBpc24ndCB0aGUgbGFzdCBpbmxpbmUgdGhlbiByZXR1cm4gYWxsIGFkZGl0aW9uYWwgc2l6ZXNcbiAgICBpZiAoIWlzTGFzdElubGluZSkge1xuICAgICAgICByZXR1cm4gc2l6ZXM7XG4gICAgfVxuICAgIC8vIENvbXB1dGUgdGhlIHZlcnRpY2FsIGRpc3RhbmNlIGZyb20gdGhlIFRPUCBvZiB0aGUgd2lubmluZyBwYXJhIHRvIHRoZSBCT1RUT00gb2YgdGhlIGFydGljbGUgYm9keVxuICAgIGNvbnN0IGRpc3RhbmNlRnJvbUJvdHRvbSA9IGF3YWl0IGZhc3Rkb20ubWVhc3VyZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHBhcmFUb3AgPSB3aW5uaW5nUGFyYS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKS50b3A7XG4gICAgICAgIGNvbnN0IGFydGljbGVCb2R5Qm90dG9tID0gZG9jdW1lbnRcbiAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKGFydGljbGVCb2R5U2VsZWN0b3IpXG4gICAgICAgICAgICA/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmJvdHRvbTtcbiAgICAgICAgcmV0dXJuIGFydGljbGVCb2R5Qm90dG9tXG4gICAgICAgICAgICA/IE1hdGguYWJzKHBhcmFUb3AgLSBhcnRpY2xlQm9keUJvdHRvbSlcbiAgICAgICAgICAgIDogdW5kZWZpbmVkO1xuICAgIH0pO1xuICAgIC8vIFJldHVybiBhbGwgb2YgdGhlIHNpemVzIHRoYXQgd2lsbCBmaXQgaW4gdGhlIGRpc3RhbmNlIHRvIGJvdHRvbVxuICAgIHJldHVybiBzaXplcy5maWx0ZXIoKGFkU2l6ZSkgPT4gZGlzdGFuY2VGcm9tQm90dG9tID8gZGlzdGFuY2VGcm9tQm90dG9tID49IGFkU2l6ZS5oZWlnaHQgOiBmYWxzZSk7XG59O1xuY29uc3QgYWRkRGVza3RvcElubGluZTEgPSAoZmlsbFNsb3QpID0+IHtcbiAgICAvLyB0aGVzZSBhcmUgYWRkZWQgaGVyZSBhbmQgbm90IGluIHNpemUgbWFwcGluZ3MgYmVjYXVzZSB0aGUgaW5saW5lW2ldIG5hbWVcbiAgICAvLyBpcyBhbHNvIHVzZWQgb24gZnJvbnRzLCB3aGVyZSB3ZSBkb24ndCB3YW50IG91dHN0cmVhbSBvciB0YWxsIGFkc1xuICAgIGNvbnN0IGFkZGl0aW9uYWxTaXplcyA9IHtcbiAgICAgICAgcGhhYmxldDogW2FkU2l6ZXMub3V0c3RyZWFtRGVza3RvcCwgYWRTaXplcy5vdXRzdHJlYW1Hb29nbGVEZXNrdG9wXSxcbiAgICAgICAgZGVza3RvcDogW2FkU2l6ZXMub3V0c3RyZWFtRGVza3RvcCwgYWRTaXplcy5vdXRzdHJlYW1Hb29nbGVEZXNrdG9wXSxcbiAgICB9O1xuICAgIGNvbnN0IGluc2VydEFkID0gYXN5bmMgKHBhcmFzKSA9PiB7XG4gICAgICAgIGNvbnN0IHNsb3RzID0gcGFyYXMuc2xpY2UoMCwgMSkubWFwKGFzeW5jIChwYXJhKSA9PiB7XG4gICAgICAgICAgICBjb25zdCBuYW1lID0gJ2lubGluZTEnO1xuICAgICAgICAgICAgY29uc3Qgc2xvdCA9IGF3YWl0IGluc2VydFNsb3RBdFBhcmEocGFyYSwgbmFtZSwgJ2lubGluZScsICdpbmxpbmUnKTtcbiAgICAgICAgICAgIGF3YWl0IGZpbGxTbG90KG5hbWUsIHNsb3QsIGFkZGl0aW9uYWxTaXplcyk7XG4gICAgICAgIH0pO1xuICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChzbG90cyk7XG4gICAgfTtcbiAgICByZXR1cm4gc3BhY2VGaWxsZXIuZmlsbFNwYWNlKHJ1bGVzLmRlc2t0b3BJbmxpbmUxLCBpbnNlcnRBZCwge1xuICAgICAgICB3YWl0Rm9ySW1hZ2VzOiB0cnVlLFxuICAgICAgICB3YWl0Rm9ySW50ZXJhY3RpdmVzOiB0cnVlLFxuICAgICAgICBwYXNzOiAnaW5saW5lMScsXG4gICAgfSk7XG59O1xuLyoqXG4gKiBJbnNlcnRzIGFsbCBpbmxpbmUgYWRzIG9uIGRlc2t0b3AgZXhjZXB0IGZvciBpbmxpbmUxLlxuICovXG5jb25zdCBhZGREZXNrdG9wUmlnaHRSYWlsQWRzID0gKGZpbGxTbG90LCBpc0NvbnNlbnRsZXNzKSA9PiB7XG4gICAgY29uc3QgaW5zZXJ0QWRzID0gYXN5bmMgKHBhcmFzKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0aWNreUNvbnRhaW5lckhlaWdodHMgPSBhd2FpdCBjb21wdXRlU3RpY2t5SGVpZ2h0cyhwYXJhcywgYXJ0aWNsZUJvZHlTZWxlY3Rvcik7XG4gICAgICAgIHZvaWQgaW5zZXJ0SGVpZ2h0U3R5bGVzKHN0aWNreUNvbnRhaW5lckhlaWdodHMubWFwKChoZWlnaHQsIGluZGV4KSA9PiBbXG4gICAgICAgICAgICBnZXRTdGlja3lDb250YWluZXJDbGFzc25hbWUoaW5kZXgpLFxuICAgICAgICAgICAgaGVpZ2h0LFxuICAgICAgICBdKSk7XG4gICAgICAgIGNvbnN0IHNsb3RzID0gcGFyYXMuc2xpY2UoMCwgcGFyYXMubGVuZ3RoKS5tYXAoYXN5bmMgKHBhcmEsIGkpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGlzTGFzdElubGluZSA9IGkgPT09IHBhcmFzLmxlbmd0aCAtIDE7XG4gICAgICAgICAgICBjb25zdCBjb250YWluZXJDbGFzc2VzID0gZ2V0U3RpY2t5Q29udGFpbmVyQ2xhc3NuYW1lKGkpICtcbiAgICAgICAgICAgICAgICAnIG9mZnNldC1yaWdodCBhZC1zbG90LS1vZmZzZXQtcmlnaHQgYWQtc2xvdC1jb250YWluZXItLW9mZnNldC1yaWdodCc7XG4gICAgICAgICAgICBjb25zdCBjb250YWluZXJPcHRpb25zID0ge1xuICAgICAgICAgICAgICAgIHN0aWNreTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU6IGNvbnRhaW5lckNsYXNzZXMsXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgLy8gdGhlc2UgYXJlIGFkZGVkIGhlcmUgYW5kIG5vdCBpbiBzaXplIG1hcHBpbmdzIGJlY2F1c2UgdGhlIGlubGluZVtpXSBuYW1lXG4gICAgICAgICAgICAvLyBpcyBhbHNvIHVzZWQgb24gZnJvbnRzLCB3aGVyZSB3ZSBkb24ndCB3YW50IG91dHN0cmVhbSBvciB0YWxsIGFkc1xuICAgICAgICAgICAgY29uc3QgYWRkaXRpb25hbFNpemVzID0ge1xuICAgICAgICAgICAgICAgIGRlc2t0b3A6IGF3YWl0IGRlY2lkZUFkZGl0aW9uYWxTaXplcyhwYXJhLCBbYWRTaXplcy5oYWxmUGFnZSwgYWRTaXplcy5za3lzY3JhcGVyXSwgaXNMYXN0SW5saW5lKSxcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBjb25zdCBzbG90ID0gYXdhaXQgaW5zZXJ0U2xvdEF0UGFyYShwYXJhLCBgaW5saW5lJHtpICsgMn1gLCAnaW5saW5lJywgJ2lubGluZScsIGNvbnRhaW5lck9wdGlvbnMpO1xuICAgICAgICAgICAgcmV0dXJuIGZpbGxTbG90KGBpbmxpbmUke2kgKyAyfWAsIHNsb3QsIGFkZGl0aW9uYWxTaXplcyk7XG4gICAgICAgIH0pO1xuICAgICAgICBhd2FpdCBQcm9taXNlLmFsbChzbG90cyk7XG4gICAgfTtcbiAgICByZXR1cm4gc3BhY2VGaWxsZXIuZmlsbFNwYWNlKHJ1bGVzLmRlc2t0b3BSaWdodFJhaWwoaXNDb25zZW50bGVzcyksIGluc2VydEFkcywge1xuICAgICAgICB3YWl0Rm9ySW1hZ2VzOiB0cnVlLFxuICAgICAgICB3YWl0Rm9ySW50ZXJhY3RpdmVzOiB0cnVlLFxuICAgICAgICBwYXNzOiAnc3Vic2VxdWVudC1pbmxpbmVzJyxcbiAgICB9KTtcbn07XG5jb25zdCBhZGRpdGlvbmFsTW9iaWxlQW5kVGFibGV0SW5saW5lU2l6ZXMgPSAoaW5kZXgpID0+IHtcbiAgICBpZiAoaW5kZXggPT09IDEpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIG1vYmlsZTogW2FkU2l6ZXMucG9ydHJhaXRJbnRlcnN0aXRpYWxdLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBlbHNlIGlmIChpbmRleCA9PT0gMikge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgbW9iaWxlOiBbXG4gICAgICAgICAgICAgICAgYWRTaXplcy5wb3J0cmFpdEludGVyc3RpdGlhbCxcbiAgICAgICAgICAgICAgICBhZFNpemVzLnB1Ym1hdGljSW50ZXJzY3JvbGxlcixcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB1bmRlZmluZWQ7XG59O1xuY29uc3QgYWRkTW9iaWxlQW5kVGFibGV0SW5saW5lQWRzID0gKGZpbGxTbG90LCBjdXJyZW50QnJlYWtwb2ludCkgPT4ge1xuICAgIGNvbnN0IGluc2VydEFkcyA9IGFzeW5jIChwYXJhcykgPT4ge1xuICAgICAgICBjb25zdCBzbG90cyA9IHBhcmFzLm1hcChhc3luYyAocGFyYSwgaSkgPT4ge1xuICAgICAgICAgICAgLy9Nb2JpbGUgdG9wLWFib3ZlLW5hdiBpcyB0aGUgZmlyc3QgYWQgaW4gdGhlIGJvZHkgYW5kIHRoZSBpbmxpbmUxIGlzIHRoZSBzZWNvbmQgYWQgaW4gdGhlIGJvZHkuXG4gICAgICAgICAgICAvL1RhYmxldCB0b3AtYWJvdmUtbmF2IGlzIGFib3ZlIHRoZSB3ZWJzaXRlJ3MgbmF2aWdhdGlvbiBhbmQgdGhlIGlubGluZTEgaXMgdGhlIGZpcnN0IGFkIGluIHRoZSBib2R5LlxuICAgICAgICAgICAgY29uc3QgbmFtZSA9IGN1cnJlbnRCcmVha3BvaW50ID09PSAnbW9iaWxlJyAmJiBpID09PSAwXG4gICAgICAgICAgICAgICAgPyAndG9wLWFib3ZlLW5hdidcbiAgICAgICAgICAgICAgICA6IGN1cnJlbnRCcmVha3BvaW50ID09PSAndGFibGV0J1xuICAgICAgICAgICAgICAgICAgICA/IGBpbmxpbmUke2kgKyAxfWBcbiAgICAgICAgICAgICAgICAgICAgOiBgaW5saW5lJHtpfWA7XG4gICAgICAgICAgICBjb25zdCB0eXBlID0gY3VycmVudEJyZWFrcG9pbnQgPT09ICdtb2JpbGUnICYmIGkgPT09IDBcbiAgICAgICAgICAgICAgICA/ICd0b3AtYWJvdmUtbmF2J1xuICAgICAgICAgICAgICAgIDogJ2lubGluZSc7XG4gICAgICAgICAgICBjb25zdCBzbG90ID0gYXdhaXQgaW5zZXJ0U2xvdEF0UGFyYShwYXJhLCBuYW1lLCB0eXBlLCAnaW5saW5lJyk7XG4gICAgICAgICAgICByZXR1cm4gZmlsbFNsb3QobmFtZSwgc2xvdCwgYWRkaXRpb25hbE1vYmlsZUFuZFRhYmxldElubGluZVNpemVzKGkpKTtcbiAgICAgICAgfSk7XG4gICAgICAgIGF3YWl0IFByb21pc2UuYWxsKHNsb3RzKTtcbiAgICB9O1xuICAgIHJldHVybiBzcGFjZUZpbGxlci5maWxsU3BhY2UocnVsZXMubW9iaWxlQW5kVGFibGV0SW5saW5lcywgaW5zZXJ0QWRzLCB7XG4gICAgICAgIHdhaXRGb3JJbWFnZXM6IHRydWUsXG4gICAgICAgIHdhaXRGb3JJbnRlcmFjdGl2ZXM6IHRydWUsXG4gICAgICAgIHBhc3M6ICdtb2JpbGUtaW5saW5lcycsXG4gICAgfSk7XG59O1xuLyoqXG4gKiBBZGQgaW5saW5lIHNsb3RzIHRvIHRoZSBhcnRpY2xlIGJvZHlcbiAqIEBwYXJhbSBmaWxsU2xvdCBBIGZ1bmN0aW9uIHRvIGNhbGwgdGhhdCB3aWxsIGZpbGwgdGhlIHNsb3Qgd2hlbiBlYWNoIGFkIHNsb3QgaGFzIGJlZW4gaW5zZXJ0ZWQsXG4gKiB0aGVzZSBjb3VsZCBiZSBnb29nbGUgZGlzcGxheSBhZHMgb3Igb3B0IG9wdCBjb25zZW50bGVzcyBhZHMuXG4gKi9cbmNvbnN0IGFkZElubGluZUFkcyA9IChmaWxsU2xvdCwgaXNDb25zZW50bGVzcykgPT4ge1xuICAgIGNvbnN0IGN1cnJlbnRCcmVha3BvaW50ID0gZ2V0Q3VycmVudEJyZWFrcG9pbnQoKTtcbiAgICBpZiAoWydtb2JpbGUnLCAndGFibGV0J10uaW5jbHVkZXMoY3VycmVudEJyZWFrcG9pbnQpKSB7XG4gICAgICAgIHJldHVybiBhZGRNb2JpbGVBbmRUYWJsZXRJbmxpbmVBZHMoZmlsbFNsb3QsIGN1cnJlbnRCcmVha3BvaW50KTtcbiAgICB9XG4gICAgaWYgKGlzUGFpZENvbnRlbnQpIHtcbiAgICAgICAgcmV0dXJuIGFkZERlc2t0b3BSaWdodFJhaWxBZHMoZmlsbFNsb3QsIGlzQ29uc2VudGxlc3MpO1xuICAgIH1cbiAgICByZXR1cm4gYWRkRGVza3RvcElubGluZTEoZmlsbFNsb3QpLnRoZW4oKCkgPT4gYWRkRGVza3RvcFJpZ2h0UmFpbEFkcyhmaWxsU2xvdCwgaXNDb25zZW50bGVzcykpO1xufTtcbi8qKlxuICogSW5pdCBhbGwgdGhlIGFydGljbGUgYm9keSBhZHZlcnRzLCBpbmNsdWRpbmcgYGNhcnJvdGBcbiAqIEBwYXJhbSBmaWxsQWRTbG90IGEgZnVuY3Rpb24gdG8gZmlsbCB0aGUgYWQgc2xvdHNcbiAqL1xuY29uc3QgaW5pdCA9IGFzeW5jIChmaWxsQWRTbG90KSA9PiB7XG4gICAgaWYgKCFjb21tZXJjaWFsRmVhdHVyZXMuYXJ0aWNsZUJvZHlBZHZlcnRzKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgYXdhaXQgYWRkSW5saW5lQWRzKGZpbGxBZFNsb3QsIGZhbHNlKTtcbiAgICBhd2FpdCBpbml0Q2Fycm90KCk7XG59O1xuZXhwb3J0IHsgaW5pdCwgYWRkSW5saW5lQWRzIH07XG4iLCJpbXBvcnQgeyBjb21tZXJjaWFsRmVhdHVyZXMgfSBmcm9tICcuLi8uLi9saWIvY29tbWVyY2lhbC1mZWF0dXJlcyc7XG5pbXBvcnQgeyBjcmVhdGVBZFNsb3QgfSBmcm9tICcuLi8uLi9saWIvY3JlYXRlLWFkLXNsb3QnO1xuaW1wb3J0IHsgZ2V0Q3VycmVudFR3ZWFrcG9pbnQgfSBmcm9tICcuLi8uLi9saWIvZGV0ZWN0L2RldGVjdC1icmVha3BvaW50JztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uLy4uL2xpYi9mYXN0ZG9tLXByb21pc2UnO1xuaW1wb3J0IHsgZmlsbER5bmFtaWNBZFNsb3QgfSBmcm9tICcuLi9maWxsLWR5bmFtaWMtYWR2ZXJ0LXNsb3QnO1xuaW1wb3J0IHsgc3BhY2VGaWxsZXIgfSBmcm9tICcuL3NwYWNlLWZpbGxlcic7XG5jb25zdCBib2R5U2VsZWN0b3IgPSAnLmFydGljbGUtYm9keS1jb21tZXJjaWFsLXNlbGVjdG9yJztcbmNvbnN0IHdpZGVSdWxlcyA9IHtcbiAgICBib2R5U2VsZWN0b3IsXG4gICAgY2FuZGlkYXRlU2VsZWN0b3I6ICc6c2NvcGUgPiBwJyxcbiAgICBtaW5EaXN0YW5jZUZyb21Ub3A6IDUwMCxcbiAgICBtaW5EaXN0YW5jZUZyb21Cb3R0b206IDQwMCxcbiAgICBjbGVhckNvbnRlbnRNZXRhOiAwLFxuICAgIG9wcG9uZW50U2VsZWN0b3JSdWxlczoge1xuICAgICAgICAnLmVsZW1lbnQtcmljaC1saW5rJzoge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAxMDAsXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IDQwMCxcbiAgICAgICAgfSxcbiAgICAgICAgJy5lbGVtZW50LWltYWdlJzoge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiA0NDAsXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IDQ0MCxcbiAgICAgICAgfSxcbiAgICAgICAgJy5wbGF5ZXInOiB7XG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206IDUwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiA1MCxcbiAgICAgICAgfSxcbiAgICAgICAgJzpzY29wZSA+IGgxJzoge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiA1MCxcbiAgICAgICAgICAgIG1hcmdpblRvcDogNTAsXG4gICAgICAgIH0sXG4gICAgICAgICc6c2NvcGUgPiBoMic6IHtcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogNTAsXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IDUwLFxuICAgICAgICB9LFxuICAgICAgICAnOnNjb3BlID4gKjpub3QocCk6bm90KGgyKTpub3QoYmxvY2txdW90ZSk6bm90KCNzaWduLWluLWdhdGUpJzoge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiA1MCxcbiAgICAgICAgICAgIG1hcmdpblRvcDogNTAsXG4gICAgICAgIH0sXG4gICAgICAgICcuYWQtc2xvdCc6IHtcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogMTAwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiAxMDAsXG4gICAgICAgIH0sXG4gICAgICAgICcuZWxlbWVudC1wdWxscXVvdGUnOiB7XG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206IDQwMCxcbiAgICAgICAgICAgIG1hcmdpblRvcDogNDAwLFxuICAgICAgICB9LFxuICAgICAgICAvLyBEb24ndCBwbGFjZSBjYXJyb3QgYWRzIG5lYXIgbmV3c2xldHRlciBzaWduLXVwIGJsb2Nrc1xuICAgICAgICAnOnNjb3BlID4gZmlndXJlW2RhdGEtc3BhY2VmaW5kZXItcm9sZT1cImlubGluZVwiXSc6IHtcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogNDAwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiA0MDAsXG4gICAgICAgIH0sXG4gICAgfSxcbiAgICBmcm9tQm90dG9tOiB0cnVlLFxufTtcbi8vIGFueXRoaW5nIGJlbG93IGxlZnRDb2wgKDExNDApIDogZGVza3RvcCwgdGFibGV0LCAuLi4sIG1vYmlsZVxuY29uc3QgZGVza3RvcFJ1bGVzID0ge1xuICAgIC4uLndpZGVSdWxlcyxcbiAgICBvcHBvbmVudFNlbGVjdG9yUnVsZXM6IHtcbiAgICAgICAgLi4ud2lkZVJ1bGVzLm9wcG9uZW50U2VsZWN0b3JSdWxlcyxcbiAgICAgICAgJy5lbGVtZW50LXJpY2gtbGluayc6IHtcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogNDAwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiA0MDAsXG4gICAgICAgIH0sXG4gICAgICAgICcuYWQtc2xvdCc6IHtcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogNDAwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiA0MDAsXG4gICAgICAgIH0sXG4gICAgfSxcbn07XG5jb25zdCBpbnNlcnRTbG90ID0gKHBhcmFzKSA9PiB7XG4gICAgY29uc3Qgc2xvdCA9IGNyZWF0ZUFkU2xvdCgnY2Fycm90Jyk7XG4gICAgY29uc3QgY2FuZGlkYXRlcyA9IHBhcmFzLnNsaWNlKDEpO1xuICAgIHJldHVybiBmYXN0ZG9tXG4gICAgICAgIC5tdXRhdGUoKCkgPT4ge1xuICAgICAgICBpZiAoY2FuZGlkYXRlc1swXT8ucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgY2FuZGlkYXRlc1swXS5wYXJlbnROb2RlLmluc2VydEJlZm9yZShzbG90LCBjYW5kaWRhdGVzWzBdKTtcbiAgICAgICAgfVxuICAgIH0pXG4gICAgICAgIC50aGVuKCgpID0+IHZvaWQgZmlsbER5bmFtaWNBZFNsb3Qoc2xvdCwgdHJ1ZSkpO1xufTtcbmNvbnN0IGdldFJ1bGVzID0gKCkgPT4ge1xuICAgIHN3aXRjaCAoZ2V0Q3VycmVudFR3ZWFrcG9pbnQoKSkge1xuICAgICAgICBjYXNlICdsZWZ0Q29sJzpcbiAgICAgICAgY2FzZSAnd2lkZSc6XG4gICAgICAgICAgICByZXR1cm4gd2lkZVJ1bGVzO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgcmV0dXJuIGRlc2t0b3BSdWxlcztcbiAgICB9XG59O1xuZXhwb3J0IGNvbnN0IGluaXRDYXJyb3QgPSAoKSA9PiB7XG4gICAgaWYgKGNvbW1lcmNpYWxGZWF0dXJlcy5jYXJyb3RUcmFmZmljRHJpdmVyKSB7XG4gICAgICAgIHJldHVybiBzcGFjZUZpbGxlci5maWxsU3BhY2UoZ2V0UnVsZXMoKSwgaW5zZXJ0U2xvdCwge1xuICAgICAgICAgICAgd2FpdEZvckltYWdlczogdHJ1ZSxcbiAgICAgICAgICAgIHdhaXRGb3JJbnRlcmFjdGl2ZXM6IHRydWUsXG4gICAgICAgICAgICBwYXNzOiAnY2Fycm90JyxcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmFsc2UpO1xufTtcbiIsImltcG9ydCB7IGFkU2l6ZXMgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2FkLXNpemVzJztcbmltcG9ydCB7IGFkU2xvdENvbnRhaW5lckNsYXNzIH0gZnJvbSAnLi4vLi4vbGliL2NyZWF0ZS1hZC1zbG90JztcbmNvbnN0IGJvZHlTZWxlY3RvciA9ICcuYXJ0aWNsZS1ib2R5LWNvbW1lcmNpYWwtc2VsZWN0b3InO1xuY29uc3QgYWRTbG90Q29udGFpbmVyU2VsZWN0b3IgPSBgLiR7YWRTbG90Q29udGFpbmVyQ2xhc3N9YDtcbmNvbnN0IGhpZ2hWYWx1ZVNlY3Rpb25zID0gW1xuICAgICdidXNpbmVzcycsXG4gICAgJ2Vudmlyb25tZW50JyxcbiAgICAnbXVzaWMnLFxuICAgICdtb25leScsXG4gICAgJ2FydGFuZGRlc2lnbicsXG4gICAgJ3NjaWVuY2UnLFxuICAgICdzdGFnZScsXG4gICAgJ3RyYXZlbCcsXG4gICAgJ3dlbGxuZXNzJyxcbiAgICAnZ2FtZXMnLFxuXTtcbmNvbnN0IGlzSW5IaWdoVmFsdWVTZWN0aW9uID0gaGlnaFZhbHVlU2VjdGlvbnMuaW5jbHVkZXMod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNlY3Rpb24pO1xuLyoqXG4gKiBBcyBlc3RpbWF0aW9uIG9mIHRoZSBoZWlnaHQgb2YgdGhlIG1vc3Qgdmlld2VkIGlzbGFuZC5cbiAqIFRoaXMgYXBwZWFycyBmcm9tIGRlc2t0b3AgYnJlYWtwb2ludHMgb24gdGhlIHJpZ2h0LWhhbmQgc2lkZS5cbiAqIEtub3dpbmcgdGhlIGhlaWdodCBvZiB0aGUgZWxlbWVudCBpcyB1c2VmdWwgd2hlblxuICogY2FsY3VsYXRpbmcgd2hlcmUgdG8gcGxhY2UgYWRzIGluIHRoZSByaWdodCBjb2x1bW4uXG4gKi9cbmNvbnN0IE1PU1RfVklFV0VEX0hFSUdIVCA9IDYwMDtcbmNvbnN0IGlzSW1tZXJzaXZlID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzSW1tZXJzaXZlO1xuY29uc3QgaGFzSW1hZ2VzID0gISF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UubGlnaHRib3hJbWFnZXM/LmltYWdlcy5sZW5ndGg7XG5jb25zdCBoYXNWaWRlbyA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5oYXNZb3VUdWJlQXRvbTtcbmNvbnN0IGlzUGFpZENvbnRlbnQgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNQYWlkQ29udGVudDtcbmNvbnN0IGhhc1Nob3djYXNlTWFpbkVsZW1lbnQgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaGFzU2hvd2Nhc2VNYWluRWxlbWVudDtcbmNvbnN0IG1pbkRpc3RhbmNlQmV0d2VlblJpZ2h0UmFpbEFkcyA9IDUwMDtcbmNvbnN0IG1pbkRpc3RhbmNlQmV0d2VlbklubGluZUFkcyA9IGlzSW5IaWdoVmFsdWVTZWN0aW9uID8gNTAwIDogNzUwO1xuY29uc3QgY2FuZGlkYXRlU2VsZWN0b3IgPSAnOnNjb3BlID4gcCwgW2RhdGEtc3BhY2VmaW5kZXItcm9sZT1cIm5lc3RlZFwiXSA+IHAnO1xuY29uc3QgbGVmdENvbHVtbk9wcG9uZW50U2VsZWN0b3IgPSBbJ3JpY2hMaW5rJywgJ3RodW1ibmFpbCddXG4gICAgLm1hcCgocm9sZSkgPT4gYDpzY29wZSA+IFtkYXRhLXNwYWNlZmluZGVyLXJvbGU9XCIke3JvbGV9XCJdYClcbiAgICAuam9pbignLCcpO1xuY29uc3QgcmlnaHRDb2x1bW5PcHBvbmVudFNlbGVjdG9yID0gJzpzY29wZSA+IFtkYXRhLXNwYWNlZmluZGVyLXJvbGU9XCJpbW1lcnNpdmVcIl0nO1xuY29uc3QgaW5saW5lT3Bwb25lbnRTZWxlY3RvciA9IFsnaW5saW5lJywgJ3N1cHBvcnRpbmcnLCAnc2hvd2Nhc2UnLCAnaGFsZldpZHRoJ11cbiAgICAubWFwKChyb2xlKSA9PiBgOnNjb3BlID4gW2RhdGEtc3BhY2VmaW5kZXItcm9sZT1cIiR7cm9sZX1cIl0sIFtkYXRhLXNwYWNlZmluZGVyLXJvbGU9XCJuZXN0ZWRcIl0gPiBbZGF0YS1zcGFjZWZpbmRlci1yb2xlPVwiJHtyb2xlfVwiXWApXG4gICAgLmpvaW4oJywnKTtcbmNvbnN0IGhlYWRpbmdTZWxlY3RvciA9IGA6c2NvcGUgPiBoMiwgW2RhdGEtc3BhY2VmaW5kZXItcm9sZT1cIm5lc3RlZFwiXSA+IGgyLCA6c2NvcGUgPiBoMywgW2RhdGEtc3BhY2VmaW5kZXItcm9sZT1cIm5lc3RlZFwiXSA+IGgzYDtcbmNvbnN0IGRlc2t0b3BJbmxpbmUxID0ge1xuICAgIGJvZHlTZWxlY3RvcixcbiAgICBjYW5kaWRhdGVTZWxlY3RvcixcbiAgICBtaW5EaXN0YW5jZUZyb21Ub3A6IGlzSW1tZXJzaXZlID8gNzAwIDogMzAwLFxuICAgIG1pbkRpc3RhbmNlRnJvbUJvdHRvbTogMzAwLFxuICAgIG9wcG9uZW50U2VsZWN0b3JSdWxlczoge1xuICAgICAgICAvLyBkb24ndCBwbGFjZSBhZHMgcmlnaHQgYWZ0ZXIgYSBoZWFkaW5nXG4gICAgICAgIFtoZWFkaW5nU2VsZWN0b3JdOiB7XG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206IDE1MCxcbiAgICAgICAgICAgIG1hcmdpblRvcDogaXNJbkhpZ2hWYWx1ZVNlY3Rpb24gPyAwIDogMTkwLFxuICAgICAgICB9LFxuICAgICAgICBbYWRTbG90Q29udGFpbmVyU2VsZWN0b3JdOiB7XG4gICAgICAgICAgICBtYXJnaW5Cb3R0b206IDUwMCxcbiAgICAgICAgICAgIG1hcmdpblRvcDogNTAwLFxuICAgICAgICB9LFxuICAgICAgICBbaW5saW5lT3Bwb25lbnRTZWxlY3Rvcl06IHtcbiAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogMzUsXG4gICAgICAgICAgICBtYXJnaW5Ub3A6IDIwMCxcbiAgICAgICAgfSxcbiAgICAgICAgW2xlZnRDb2x1bW5PcHBvbmVudFNlbGVjdG9yXToge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiA1MCxcbiAgICAgICAgICAgIG1hcmdpblRvcDogMTAwLFxuICAgICAgICB9LFxuICAgICAgICBbcmlnaHRDb2x1bW5PcHBvbmVudFNlbGVjdG9yXToge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiAxNTAsXG4gICAgICAgIH0sXG4gICAgICAgIFsnW2RhdGEtc3BhY2VmaW5kZXItcm9sZT1cInN1cHBvcnRpbmdcIl0nXToge1xuICAgICAgICAgICAgbWFyZ2luQm90dG9tOiAwLFxuICAgICAgICAgICAgbWFyZ2luVG9wOiAxMDAsXG4gICAgICAgIH0sXG4gICAgfSxcbn07XG5jb25zdCBkZXNrdG9wUmlnaHRSYWlsTWluQWJvdmUgPSAoaXNDb25zZW50bGVzcykgPT4ge1xuICAgIGNvbnN0IGJhc2UgPSAxMDAwO1xuICAgIC8qKlxuICAgICAqIEluIHNwZWNpYWwgY2FzZXMsIGlubGluZTIgY2FuIG92ZXJsYXAgdGhlIFwiTW9zdCB2aWV3ZWRcIiBpc2xhbmQsIHNvXG4gICAgICogd2UgbmVlZCB0byBtYWtlIGFuIGFkanVzdG1lbnQgdG8gbW92ZSB0aGUgaW5saW5lMiBmdXJ0aGVyIGRvd24gdGhlIHBhZ2VcbiAgICAgKi9cbiAgICBpZiAoaXNQYWlkQ29udGVudCB8fCAoIWhhc0ltYWdlcyAmJiAhaGFzVmlkZW8pIHx8IGlzQ29uc2VudGxlc3MpIHtcbiAgICAgICAgcmV0dXJuIGJhc2UgKyBNT1NUX1ZJRVdFRF9IRUlHSFQ7XG4gICAgfVxuICAgIGlmIChoYXNTaG93Y2FzZU1haW5FbGVtZW50IHx8ICghaGFzSW1hZ2VzICYmIGhhc1ZpZGVvKSkge1xuICAgICAgICByZXR1cm4gYmFzZSArIDI1MDtcbiAgICB9XG4gICAgcmV0dXJuIGJhc2U7XG59O1xuY29uc3QgZGVza3RvcFJpZ2h0UmFpbCA9IChpc0NvbnNlbnRsZXNzKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYm9keVNlbGVjdG9yLFxuICAgICAgICBjYW5kaWRhdGVTZWxlY3RvcixcbiAgICAgICAgbWluRGlzdGFuY2VGcm9tVG9wOiBkZXNrdG9wUmlnaHRSYWlsTWluQWJvdmUoaXNDb25zZW50bGVzcyksXG4gICAgICAgIG1pbkRpc3RhbmNlRnJvbUJvdHRvbTogMzAwLFxuICAgICAgICBvcHBvbmVudFNlbGVjdG9yUnVsZXM6IHtcbiAgICAgICAgICAgIFthZFNsb3RDb250YWluZXJTZWxlY3Rvcl06IHtcbiAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IDUwMCxcbiAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDUwMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBbcmlnaHRDb2x1bW5PcHBvbmVudFNlbGVjdG9yXToge1xuICAgICAgICAgICAgICAgIG1hcmdpbkJvdHRvbTogMCxcbiAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDYwMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBGaWx0ZXIgb3V0IGFueSBjYW5kaWRhdGVzIHRoYXQgYXJlIHRvbyBjbG9zZSB0byB0aGUgbGFzdCB3aW5uZXJcbiAgICAgICAgICogc2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9ndWFyZGlhbi9jb21tZXJjaWFsL3RyZWUvbWFpbi9kb2NzL3NwYWNlZmluZGVyI2F2b2lkaW5nLW90aGVyLXdpbm5pbmctY2FuZGlkYXRlc1xuICAgICAgICAgKiBmb3IgbW9yZSBpbmZvcm1hdGlvblxuICAgICAgICAgKiovXG4gICAgICAgIGZpbHRlcjogKGNhbmRpZGF0ZSwgbGFzdFdpbm5lcikgPT4ge1xuICAgICAgICAgICAgaWYgKCFsYXN0V2lubmVyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBsYXJnZXN0U2l6ZUZvclNsb3QgPSBhZFNpemVzLmhhbGZQYWdlLmhlaWdodDtcbiAgICAgICAgICAgIGNvbnN0IGRpc3RhbmNlQmV0d2VlbkFkcyA9IGNhbmRpZGF0ZS50b3AgLSBsYXN0V2lubmVyLnRvcCAtIGxhcmdlc3RTaXplRm9yU2xvdDtcbiAgICAgICAgICAgIHJldHVybiBkaXN0YW5jZUJldHdlZW5BZHMgPj0gbWluRGlzdGFuY2VCZXR3ZWVuUmlnaHRSYWlsQWRzO1xuICAgICAgICB9LFxuICAgIH07XG59O1xuY29uc3QgbW9iaWxlTWluRGlzdGFuY2VGcm9tQXJ0aWNsZVRvcCA9IDIwMDtcbmNvbnN0IG1vYmlsZUNhbmRpZGF0ZVNlbGVjdG9yID0gJzpzY29wZSA+IHAsIDpzY29wZSA+IGgyLCA6c2NvcGUgPiBbZGF0YS1zcGFjZWZpbmRlci10eXBlJD1cIk51bWJlcmVkVGl0bGVCbG9ja0VsZW1lbnRcIl0sIFtkYXRhLXNwYWNlZmluZGVyLXJvbGU9XCJuZXN0ZWRcIl0gPiBwJztcbmNvbnN0IG1vYmlsZUhlYWRpbmdTZWxlY3RvciA9IGAke2hlYWRpbmdTZWxlY3Rvcn0sIDpzY29wZSA+IFtkYXRhLXNwYWNlZmluZGVyLXR5cGUkPVwiTnVtYmVyZWRUaXRsZUJsb2NrRWxlbWVudFwiXWA7XG5jb25zdCBtb2JpbGVPcHBvbmVudFNlbGVjdG9yUnVsZXMgPSB7XG4gICAgLy8gZG9uJ3QgcGxhY2UgYWRzIHJpZ2h0IGFmdGVyIGEgaGVhZGluZ1xuICAgIFttb2JpbGVIZWFkaW5nU2VsZWN0b3JdOiB7XG4gICAgICAgIG1hcmdpbkJvdHRvbTogMTAwLFxuICAgICAgICBtYXJnaW5Ub3A6IDAsXG4gICAgfSxcbiAgICBbYWRTbG90Q29udGFpbmVyU2VsZWN0b3JdOiB7XG4gICAgICAgIG1hcmdpbkJvdHRvbTogbWluRGlzdGFuY2VCZXR3ZWVuSW5saW5lQWRzLFxuICAgICAgICBtYXJnaW5Ub3A6IG1pbkRpc3RhbmNlQmV0d2VlbklubGluZUFkcyxcbiAgICB9LFxuICAgIFtgJHtpbmxpbmVPcHBvbmVudFNlbGVjdG9yfSwke2xlZnRDb2x1bW5PcHBvbmVudFNlbGVjdG9yfWBdOiB7XG4gICAgICAgIG1hcmdpbkJvdHRvbTogMzUsXG4gICAgICAgIG1hcmdpblRvcDogMjAwLFxuICAgICAgICAvLyBVc3VhbGx5IHdlIGRvbid0IHdhbnQgYW4gYWQgcmlnaHQgYmVmb3JlIHZpZGVvcywgZW1iZWRzIGFuZCBhdG9tcyBldGMuIHNvIHRoYXQgd2UgZG9uJ3QgYnJlYWsgdXAgcmVsYXRlZCBjb250ZW50IHRvbyBtdWNoLiBCdXQgaWYgd2UgaGF2ZSBhIGhlYWRpbmcgYWJvdmUsIGFueXRoaW5nIGFib3ZlIHRoZSBoZWFkaW5nIHdvbid0IGJlIHJlbGF0ZWQgdG8gdGhlIGN1cnJlbnQgY29udGVudCwgc28gd2UgY2FuIHBsYWNlIGFuIGFkIHRoZXJlLlxuICAgICAgICBieXBhc3NNaW5Ub3A6ICdoMixbZGF0YS1zcGFjZWZpbmRlci10eXBlJD1cIk51bWJlcmVkVGl0bGVCbG9ja0VsZW1lbnRcIl0nLFxuICAgIH0sXG4gICAgW3JpZ2h0Q29sdW1uT3Bwb25lbnRTZWxlY3Rvcl06IHtcbiAgICAgICAgbWFyZ2luQm90dG9tOiAzNSxcbiAgICAgICAgbWFyZ2luVG9wOiAyMDAsXG4gICAgICAgIC8vIFVzdWFsbHkgd2UgZG9uJ3Qgd2FudCBhbiBhZCByaWdodCBiZWZvcmUgdmlkZW9zLCBlbWJlZHMgYW5kIGF0b21zIGV0Yy4gc28gdGhhdCB3ZSBkb24ndCBicmVhayB1cCByZWxhdGVkIGNvbnRlbnQgdG9vIG11Y2guIEJ1dCBpZiB3ZSBoYXZlIGEgaGVhZGluZyBhYm92ZSwgYW55dGhpbmcgYWJvdmUgdGhlIGhlYWRpbmcgd29uJ3QgYmUgcmVsYXRlZCB0byB0aGUgY3VycmVudCBjb250ZW50LCBzbyB3ZSBjYW4gcGxhY2UgYW4gYWQgdGhlcmUuXG4gICAgICAgIGJ5cGFzc01pblRvcDogJ2gyLFtkYXRhLXNwYWNlZmluZGVyLXR5cGUkPVwiTnVtYmVyZWRUaXRsZUJsb2NrRWxlbWVudFwiXScsXG4gICAgfSxcbn07XG5jb25zdCBtb2JpbGVBbmRUYWJsZXRJbmxpbmVzID0ge1xuICAgIGJvZHlTZWxlY3RvcixcbiAgICBjYW5kaWRhdGVTZWxlY3RvcjogbW9iaWxlQ2FuZGlkYXRlU2VsZWN0b3IsXG4gICAgbWluRGlzdGFuY2VGcm9tVG9wOiBtb2JpbGVNaW5EaXN0YW5jZUZyb21BcnRpY2xlVG9wLFxuICAgIG1pbkRpc3RhbmNlRnJvbUJvdHRvbTogMjAwLFxuICAgIG9wcG9uZW50U2VsZWN0b3JSdWxlczogbW9iaWxlT3Bwb25lbnRTZWxlY3RvclJ1bGVzLFxuICAgIC8qKlxuICAgICAqIEZpbHRlciBvdXQgYW55IGNhbmRpZGF0ZXMgdGhhdCBhcmUgdG9vIGNsb3NlIHRvIHRoZSBsYXN0IHdpbm5lclxuICAgICAqIHNlZSBodHRwczovL2dpdGh1Yi5jb20vZ3VhcmRpYW4vY29tbWVyY2lhbC90cmVlL21haW4vZG9jcy9zcGFjZWZpbmRlciNhdm9pZGluZy1vdGhlci13aW5uaW5nLWNhbmRpZGF0ZXNcbiAgICAgKiBmb3IgbW9yZSBpbmZvcm1hdGlvblxuICAgICAqKi9cbiAgICBmaWx0ZXI6IChjYW5kaWRhdGUsIGxhc3RXaW5uZXIpID0+IHtcbiAgICAgICAgaWYgKCFsYXN0V2lubmVyKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBkaXN0YW5jZUJldHdlZW5BZHMgPSBjYW5kaWRhdGUudG9wIC0gbGFzdFdpbm5lci50b3A7XG4gICAgICAgIHJldHVybiBkaXN0YW5jZUJldHdlZW5BZHMgPj0gbWluRGlzdGFuY2VCZXR3ZWVuSW5saW5lQWRzO1xuICAgIH0sXG59O1xuZXhwb3J0IGNvbnN0IHJ1bGVzID0ge1xuICAgIGRlc2t0b3BJbmxpbmUxLFxuICAgIGRlc2t0b3BSaWdodFJhaWwsXG4gICAgbW9iaWxlQW5kVGFibGV0SW5saW5lcyxcbn07XG4iLCJpbXBvcnQgeyByZXBvcnRFcnJvciB9IGZyb20gJy4uLy4uL2xpYi9lcnJvci9yZXBvcnQtZXJyb3InO1xuaW1wb3J0IHsgZmluZFNwYWNlLCBTcGFjZUVycm9yIH0gZnJvbSAnLi9zcGFjZWZpbmRlcic7XG5jbGFzcyBTcGFjZUZpbGxlciB7XG4gICAgcXVldWUgPSBQcm9taXNlLnJlc29sdmUodHJ1ZSk7XG4gICAgLyoqXG4gICAgICogQSBzYWZlciB3YXkgb2YgdXNpbmcgc3BhY2VmaW5kZXIuXG4gICAgICogR2l2ZW4gYSBzZXQgb2Ygc3BhY2VmaW5kZXIgcnVsZXMsIGFwcGxpZXMgYSB3cml0ZXIgdG8gdGhlIGZpcnN0IG1hdGNoaW5nIHBhcmFncmFwaC5cbiAgICAgKiBVc2VzIGZhc3Rkb20gdG8gYXZvaWQgbGF5b3V0LXRocmFzaGluZywgYnV0IHF1ZXVlcyB1cCBhc3luY2hyb25vdXMgd3JpdGVzIHRvIGF2b2lkIHJhY2UgY29uZGl0aW9ucy4gV2UgZG9uJ3RcbiAgICAgKiBzZWVrIGEgc2xvdCBmb3IgYSBuZXcgY29tcG9uZW50IHVudGlsIGFsbCB0aGUgb3RoZXIgY29tcG9uZW50IHdyaXRlcyBoYXZlIGZpbmlzaGVkLlxuICAgICAqL1xuICAgIGZpbGxTcGFjZShydWxlcywgd3JpdGVyLCBvcHRpb25zKSB7XG4gICAgICAgIGNvbnN0IGluc2VydE5leHRDb250ZW50ID0gKCkgPT4gZmluZFNwYWNlKHJ1bGVzLCBvcHRpb25zKVxuICAgICAgICAgICAgLnRoZW4oKHBhcmFncmFwaHMpID0+IHdyaXRlcihwYXJhZ3JhcGhzKSlcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9KVxuICAgICAgICAgICAgLmNhdGNoKChleCkgPT4ge1xuICAgICAgICAgICAgaWYgKGV4IGluc3RhbmNlb2YgU3BhY2VFcnJvcikge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHRocm93IGV4O1xuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5xdWV1ZSA9IHRoaXMucXVldWUudGhlbihpbnNlcnROZXh0Q29udGVudCkuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgICAgIC8vIGUuZy4gaWYgd3JpdGVyIGZhaWxzXG4gICAgICAgICAgICByZXBvcnRFcnJvcihlLCAnc3BhY2UtZmlsbGVyJyk7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGhpcy5xdWV1ZTtcbiAgICB9XG59XG5jb25zdCBzcGFjZUZpbGxlciA9IG5ldyBTcGFjZUZpbGxlcigpO1xuZXhwb3J0IHsgc3BhY2VGaWxsZXIgfTtcbiIsIi8vIHRvdGFsX2hvdXJzX3NwZW50X21haW50YWluaW5nX3RoaXMgPSA4MS41XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBtZW1vaXplIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uLy4uL2xpYi9mYXN0ZG9tLXByb21pc2UnO1xuaW1wb3J0IHsgZ2V0VXJsVmFycyB9IGZyb20gJy4uLy4uL2xpYi91cmwnO1xuY29uc3QgcXVlcnkgPSAoc2VsZWN0b3IsIGNvbnRleHQpID0+IFtcbiAgICAuLi4oY29udGV4dCA/PyBkb2N1bWVudCkucXVlcnlTZWxlY3RvckFsbChzZWxlY3RvciksXG5dO1xuLyoqIG1heGltdW0gdGltZSAoaW4gbXMpIHRvIHdhaXQgZm9yIGltYWdlcyB0byBiZSBsb2FkZWQgKi9cbmNvbnN0IExPQURJTkdfVElNRU9VVCA9IDVfMDAwO1xuY29uc3QgZGVmYXVsdE9wdGlvbnMgPSB7XG4gICAgd2FpdEZvckltYWdlczogdHJ1ZSxcbiAgICB3YWl0Rm9ySW50ZXJhY3RpdmVzOiBmYWxzZSxcbiAgICBwYXNzOiAnaW5saW5lMScsXG59O1xuY29uc3QgaXNJZnJhbWUgPSAobm9kZSkgPT4gbm9kZSBpbnN0YW5jZW9mIEhUTUxJRnJhbWVFbGVtZW50O1xuY29uc3QgaXNJZnJhbWVMb2FkZWQgPSAoaWZyYW1lKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgcmV0dXJuIGlmcmFtZS5jb250ZW50V2luZG93Py5kb2N1bWVudC5yZWFkeVN0YXRlID09PSAnY29tcGxldGUnO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn07XG5jb25zdCBnZXRGdW5jSWQgPSAocnVsZXMpID0+IHJ1bGVzLmJvZHlTZWxlY3RvciB8fCAnZG9jdW1lbnQnO1xuY29uc3QgaXNJbWFnZSA9IChlbGVtZW50KSA9PiBlbGVtZW50IGluc3RhbmNlb2YgSFRNTEltYWdlRWxlbWVudDtcbmNvbnN0IG9uSW1hZ2VzTG9hZGVkID0gbWVtb2l6ZSgocnVsZXMpID0+IHtcbiAgICBjb25zdCBub3RMb2FkZWQgPSBxdWVyeSgnaW1nJywgcnVsZXMuYm9keSlcbiAgICAgICAgLmZpbHRlcihpc0ltYWdlKVxuICAgICAgICAuZmlsdGVyKChpbWcpID0+ICFpbWcuY29tcGxldGUgJiYgaW1nLmxvYWRpbmcgIT09ICdsYXp5Jyk7XG4gICAgY29uc3QgaW1nUHJvbWlzZXMgPSBub3RMb2FkZWQubWFwKChpbWcpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIGltZy5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgcmVzb2x2ZSk7XG4gICAgfSkpO1xuICAgIHJldHVybiBQcm9taXNlLmFsbChpbWdQcm9taXNlcykudGhlbigoKSA9PiBQcm9taXNlLnJlc29sdmUoKSk7XG59LCBnZXRGdW5jSWQpO1xuY29uc3Qgd2FpdEZvclNldEhlaWdodE1lc3NhZ2UgPSAoaWZyYW1lLCBjYWxsYmFjaykgPT4ge1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGV2ZW50KSA9PiB7XG4gICAgICAgIGlmIChldmVudC5zb3VyY2UgIT09IGlmcmFtZS5jb250ZW50V2luZG93KVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgY29uc3QgbWVzc2FnZSA9IEpTT04ucGFyc2UoZXZlbnQuZGF0YSk7XG4gICAgICAgICAgICBpZiAobWVzc2FnZS50eXBlID09PSAnc2V0LWhlaWdodCcgJiYgTnVtYmVyKG1lc3NhZ2UudmFsdWUpID4gMCkge1xuICAgICAgICAgICAgICAgIGNhbGxiYWNrKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnVW5wYXJzYWJsZSBtZXNzYWdlIHNlbnQgZnJvbSBpZnJhbWUnLCBleCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5jb25zdCBvbkludGVyYWN0aXZlc0xvYWRlZCA9IG1lbW9pemUoYXN5bmMgKHJ1bGVzKSA9PiB7XG4gICAgY29uc3Qgbm90TG9hZGVkID0gcXVlcnkoJy5lbGVtZW50LWludGVyYWN0aXZlJywgcnVsZXMuYm9keSkuZmlsdGVyKChpbnRlcmFjdGl2ZSkgPT4ge1xuICAgICAgICBjb25zdCBpZnJhbWVzID0gQXJyYXkuZnJvbShpbnRlcmFjdGl2ZS5jaGlsZHJlbikuZmlsdGVyKGlzSWZyYW1lKTtcbiAgICAgICAgcmV0dXJuICEoaWZyYW1lc1swXSAmJiBpc0lmcmFtZUxvYWRlZChpZnJhbWVzWzBdKSk7XG4gICAgfSk7XG4gICAgaWYgKG5vdExvYWRlZC5sZW5ndGggPT09IDAgfHwgISgnTXV0YXRpb25PYnNlcnZlcicgaW4gd2luZG93KSkge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIGNvbnN0IG11dGF0aW9ucyA9IG5vdExvYWRlZC5tYXAoKGludGVyYWN0aXZlKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICAvLyBMaXN0ZW4gZm9yIHdoZW4gaWZyYW1lcyBhcmUgYWRkZWQgYXMgY2hpbGRyZW4gdG8gaW50ZXJhY3RpdmVzXG4gICAgICAgIG5ldyBNdXRhdGlvbk9ic2VydmVyKChyZWNvcmRzLCBpbnN0YW5jZSkgPT4ge1xuICAgICAgICAgICAgaWYgKCFyZWNvcmRzWzBdPy5hZGRlZE5vZGVzWzBdIHx8XG4gICAgICAgICAgICAgICAgIWlzSWZyYW1lKHJlY29yZHNbMF0/LmFkZGVkTm9kZXNbMF0pKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgaWZyYW1lID0gcmVjb3Jkc1swXS5hZGRlZE5vZGVzWzBdO1xuICAgICAgICAgICAgLy8gTGlzdGVuIGZvciB3aGVuIHRoZSBpZnJhbWVzIGFyZSByZXNpemVkXG4gICAgICAgICAgICAvLyBUaGlzIGlzIGEgc2lnbiB0aGV5IGhhdmUgZnVsbHkgbG9hZGVkIGFuZCBzcGFjZWZpbmRlciBjYW4gcHJvY2VlZFxuICAgICAgICAgICAgd2FpdEZvclNldEhlaWdodE1lc3NhZ2UoaWZyYW1lLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgaW5zdGFuY2UuZGlzY29ubmVjdCgpO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KS5vYnNlcnZlKGludGVyYWN0aXZlLCB7XG4gICAgICAgICAgICBjaGlsZExpc3Q6IHRydWUsXG4gICAgICAgIH0pO1xuICAgIH0pKTtcbiAgICBhd2FpdCBQcm9taXNlLmFsbChtdXRhdGlvbnMpO1xufSwgZ2V0RnVuY0lkKTtcbmNvbnN0IHBhcnRpdGlvbkNhbmRpZGF0ZXMgPSAobGlzdCwgZmlsdGVyRWxlbWVudCkgPT4ge1xuICAgIGNvbnN0IGZpbHRlcmVkID0gW107XG4gICAgY29uc3QgZXhjbHVzaW9ucyA9IFtdO1xuICAgIGxpc3QuZm9yRWFjaCgoZWxlbWVudCkgPT4ge1xuICAgICAgICBpZiAoZmlsdGVyRWxlbWVudChlbGVtZW50LCBmaWx0ZXJlZFtmaWx0ZXJlZC5sZW5ndGggLSAxXSkpIHtcbiAgICAgICAgICAgIGZpbHRlcmVkLnB1c2goZWxlbWVudCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBleGNsdXNpb25zLnB1c2goZWxlbWVudCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gW2ZpbHRlcmVkLCBleGNsdXNpb25zXTtcbn07XG4vKipcbiAqIENoZWNrIGlmIHRoZSB0b3Agb2YgdGhlIGNhbmRpZGF0ZSBpcyBmYXIgZW5vdWdoIGZyb20gdGhlIG9wcG9uZW50XG4gKlxuICogVGhlIGNhbmRpZGF0ZSBpcyB0aGUgZWxlbWVudCB3aGVyZSB3ZSB3b3VsZCBsaWtlIHRvIGluc2VydCBhbiBhZCBhYm92ZS4gQ2FuZGlkYXRlcyBzYXRpc2Z5IHRoZSBgc2VsZWN0b3JgIHJ1bGUuXG4gKlxuICogT3Bwb25lbnRzIGFyZSBvdGhlciBlbGVtZW50cyBpbiB0aGUgYXJ0aWNsZSB0aGF0IGFyZSBpbiB0aGUgc3BhY2VmaW5kZXIgcnVsZXNldFxuICogZm9yIHRoZSBjdXJyZW50IHBhc3MuIFRoaXMgaW5jbHVkZXMgc2xvdHMgaW5zZXJ0ZWQgYnkgYSBwcmV2aW91cyBwYXNzIGJ1dCBub3RcbiAqIHRob3NlIGluIHRoZSBjdXJyZW50IHBhc3MgYXMgdGhleSdyZSBhbGwgaW5zZXJ0ZWQgYXQgdGhlIGVuZC5cbiAqXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCXG4gKiAgICAgICAgICAgICAgICAgICAgIE9wcG9uZW50IEJlbG93ICAgICAgICAgICAgICAgICAgICAg4pSCICAgICAgICAgICAgIE9wcG9uZW50IEFib3ZlXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCXG4gKiAgICAgICAgICAgICAgICAgIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAgVG9wIG9mIGNvbnRhaW5lciDilIIgICAgICAgICAg4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSAICBUb3Agb2YgY29udGFpbmVyXG4gKiAgICAgICAgICAgICAgICAgICAg4payICAgICAgICAgICAgICDilrIgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgIOKWsiAgICAgICAgICAgICAg4payXG4gKiAgICAgICAgICAgICAgICAgICAg4pSCICAgICAgICAgICAgICDilIIgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgIOKUgiAgICAgICAgICAgICAg4pSCIG9wcG9uZW50LnRvcFxuICogICAgICAgICAgICAgICAgICAgIOKUgiDilIzilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJAg4pSCICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgICDilIIg4pSM4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSQIOKWvCAgIChpbnNlcnRpb24gcG9pbnQpXG4gKiAgICAgICAgICAgICAgICAgICAg4pSCIOKUgiAgICAgICAgICDilIIgfGNhbmRpZGF0ZS5ib3R0b20gICAg4pSCICAgICAgICAgICAg4pSCIOKUgiAgICAgICAgICDilIJcbiAqICAgICAgICAgICAgICAgICAgICDilIIg4pSCIENhbmRpZGF0ZeKUgiDilIIgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgIOKUgiDilIIgT3Bwb25lbnQgfFxuICogICAgICAgb3Bwb25lbnQudG9wIOKUgiDilIIgICAgICAgICAg4pSCIOKUgiAgICAgICAgICAgICAgICAgICAgY2FuZGlkYXRlLnRvcOKUgiDilIIgICAgICAgICAg4pSCXG4gKiAgICAgICAgICAgICAgICAgICAg4pSCIOKUlOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUmCDilrwgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgIOKUgiDilJTilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilJhcbiAqICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgIOKUgiAgICAgICAgICAg4payXG4gKiAgICAgICAgICAgICAgICAgICAg4pSCIOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgCAgICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgICDilIIgICAgICAgICAgIOKUgiBtYXJnaW5Cb3R0b21cbiAqICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgIOKWsiAgICAgICAgICAgICAgICAgICAgICAg4pSCICAgICAgICAgICAg4pSCICAgICAgICAgICDilrxcbiAqICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgIOKUgiBtYXJnaW5Ub3AgICAgICAgICAgICAg4pSCICAgICAgICAgICAg4pSCICDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIDilIBcbiAqICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgIOKWvCAgICAgICAgICAgICAgICAgICAgICAg4pSCICAgICAgICAgICAg4pSCXG4gKiAoaW5zZXJ0aW9uIHBvaW50KSAg4pa8IOKUjOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUgOKUkCAgICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAgICDilrwg4pSM4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSQXG4gKiAgICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAg4pSCICAgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgICAg4pSCICAgICAgICAgIOKUglxuICogICAgICAgICAgICAgICAgICAgICAg4pSCIE9wcG9uZW50IHwgICAgICAgICAgICAgICAgICAgICAg4pSCICAgICAgICAgICAgICDilIIgQ2FuZGlkYXRl4pSCXG4gKiAgICAgICAgICAgICAgICAgICAgICDilIIgICAgICAgICAg4pSCICAgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgICAg4pSCICAgICAgICAgIOKUglxuICogICAgICAgICAgICAgICAgICAgICAg4pSU4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSYICAgICAgICAgICAgICAgICAgICAgIOKUgiAgICAgICAgICAgICAg4pSU4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSA4pSYXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCXG4gKiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAg4pSCXG4gKi9cbmNvbnN0IGlzVG9wT2ZDYW5kaWRhdGVGYXJFbm91Z2hGcm9tT3Bwb25lbnQgPSAoY2FuZGlkYXRlLCBvcHBvbmVudCwgcnVsZSwgaXNPcHBvbmVudEJlbG93KSA9PiB7XG4gICAgY29uc3QgcG90ZW50aWFsSW5zZXJ0UG9zaXRpb24gPSBjYW5kaWRhdGUudG9wO1xuICAgIGlmIChpc09wcG9uZW50QmVsb3cgJiYgcnVsZS5tYXJnaW5Ub3ApIHtcbiAgICAgICAgaWYgKHJ1bGUuYnlwYXNzTWluVG9wICYmIGNhbmRpZGF0ZS5lbGVtZW50Lm1hdGNoZXMocnVsZS5ieXBhc3NNaW5Ub3ApKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3Bwb25lbnQudG9wIC0gcG90ZW50aWFsSW5zZXJ0UG9zaXRpb24gPj0gcnVsZS5tYXJnaW5Ub3A7XG4gICAgfVxuICAgIGlmICghaXNPcHBvbmVudEJlbG93ICYmIHJ1bGUubWFyZ2luQm90dG9tKSB7XG4gICAgICAgIHJldHVybiBwb3RlbnRpYWxJbnNlcnRQb3NpdGlvbiAtIG9wcG9uZW50LmJvdHRvbSA+PSBydWxlLm1hcmdpbkJvdHRvbTtcbiAgICB9XG4gICAgLy8gaWYgbm8gcnVsZSBpcyBzZXQgKG9yIHRoZXkncmUgMCksIHJldHVybiB0cnVlXG4gICAgcmV0dXJuIHRydWU7XG59O1xuLyoqXG4gKiBDaGVjayBpZiAxIC0gdGhlIGNhbmRpZGF0ZSBpcyB0aGUgc2FtZSBhcyB0aGUgb3Bwb25lbnQgb3IgMi0gaWYgdGhlIG9wcG9uZW50IGNvbnRhaW5zIHRoZSBjYW5kaWRhdGVcbiAqXG4gKiAxIGNhbiBoYXBwZW4gd2hlbiB0aGUgY2FuZGlkYXRlIGFuZCBvcHBvbmVudCBzZWxlY3RvcnMgb3ZlcmxhcFxuICogMiBjYW4gaGFwcGVuIHdoZW4gdGhlcmUgYXJlIG5lc3RlZCBjYW5kaWRhdGVzLCBpdCBtYXkgdHJ5IHQgYXZvaWQgaXQncyBvd24gYW5jZXN0b3JcbiAqL1xuY29uc3QgYnlwYXNzVGVzdENhbmRpZGF0ZSA9IChjYW5kaWRhdGUsIG9wcG9uZW50KSA9PiBjYW5kaWRhdGUuZWxlbWVudCA9PT0gb3Bwb25lbnQuZWxlbWVudCB8fFxuICAgIG9wcG9uZW50LmVsZW1lbnQuY29udGFpbnMoY2FuZGlkYXRlLmVsZW1lbnQpO1xuLy8gdGVzdCBvbmUgZWxlbWVudCB2cyBhbm90aGVyIGZvciB0aGUgZ2l2ZW4gcnVsZXNcbmNvbnN0IHRlc3RDYW5kaWRhdGUgPSAocnVsZSwgY2FuZGlkYXRlLCBvcHBvbmVudCkgPT4ge1xuICAgIGlmIChieXBhc3NUZXN0Q2FuZGlkYXRlKGNhbmRpZGF0ZSwgb3Bwb25lbnQpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBjb25zdCBpc09wcG9uZW50QmVsb3cgPSBvcHBvbmVudC5ib3R0b20gPiBjYW5kaWRhdGUuYm90dG9tICYmIG9wcG9uZW50LnRvcCA+PSBjYW5kaWRhdGUuYm90dG9tO1xuICAgIGNvbnN0IGlzT3Bwb25lbnRBYm92ZSA9IG9wcG9uZW50LnRvcCA8IGNhbmRpZGF0ZS50b3AgJiYgb3Bwb25lbnQuYm90dG9tIDw9IGNhbmRpZGF0ZS50b3A7XG4gICAgLy8gdGhpcyBjYW4gaGFwcGVuIHdoZW4gdGhlIGFuIG9wcG9uZW50IGxpa2UgYW4gaW1hZ2Ugb3IgaW50ZXJhY3RpdmUgaXMgZmxvYXRlZCByaWdodFxuICAgIGNvbnN0IG9wcG9uZW50T3ZlcmxhcHMgPSAoaXNPcHBvbmVudEFib3ZlICYmIGlzT3Bwb25lbnRCZWxvdykgfHxcbiAgICAgICAgKCFpc09wcG9uZW50QWJvdmUgJiYgIWlzT3Bwb25lbnRCZWxvdyk7XG4gICAgY29uc3QgcGFzcyA9ICFvcHBvbmVudE92ZXJsYXBzICYmXG4gICAgICAgIGlzVG9wT2ZDYW5kaWRhdGVGYXJFbm91Z2hGcm9tT3Bwb25lbnQoY2FuZGlkYXRlLCBvcHBvbmVudCwgcnVsZSwgaXNPcHBvbmVudEJlbG93KTtcbiAgICBpZiAoIXBhc3MpIHtcbiAgICAgICAgaWYgKG9wcG9uZW50T3ZlcmxhcHMpIHtcbiAgICAgICAgICAgIGNhbmRpZGF0ZS5tZXRhLm92ZXJsYXBzLnB1c2goe1xuICAgICAgICAgICAgICAgIGVsZW1lbnQ6IG9wcG9uZW50LmVsZW1lbnQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIC8vIGlmIHRoZSB0ZXN0IGZhaWxzLCBhZGQgZGVidWcgaW5mb3JtYXRpb24gdG8gdGhlIGNhbmRpZGF0ZSBtZXRhZGF0YVxuICAgICAgICAgICAgY29uc3QgcmVxdWlyZWQgPSBpc09wcG9uZW50QmVsb3dcbiAgICAgICAgICAgICAgICA/IHJ1bGUubWFyZ2luVG9wXG4gICAgICAgICAgICAgICAgOiBydWxlLm1hcmdpbkJvdHRvbTtcbiAgICAgICAgICAgIGNvbnN0IGFjdHVhbCA9IGlzT3Bwb25lbnRCZWxvd1xuICAgICAgICAgICAgICAgID8gb3Bwb25lbnQudG9wIC0gY2FuZGlkYXRlLnRvcFxuICAgICAgICAgICAgICAgIDogY2FuZGlkYXRlLnRvcCAtIG9wcG9uZW50LmJvdHRvbTtcbiAgICAgICAgICAgIGNhbmRpZGF0ZS5tZXRhLnRvb0Nsb3NlLnB1c2goe1xuICAgICAgICAgICAgICAgIHJlcXVpcmVkLFxuICAgICAgICAgICAgICAgIGFjdHVhbCxcbiAgICAgICAgICAgICAgICBlbGVtZW50OiBvcHBvbmVudC5lbGVtZW50LFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHBhc3M7XG59O1xuLy8gdGVzdCBvbmUgZWxlbWVudCB2cyBhbiBhcnJheSBvZiBvdGhlciBlbGVtZW50cyBmb3IgdGhlIGdpdmVuIHJ1bGVcbmNvbnN0IHRlc3RDYW5kaWRhdGVzID0gKHJ1bGUsIGNhbmRpZGF0ZSwgb3Bwb25lbnRzKSA9PiBvcHBvbmVudHNcbiAgICAubWFwKChvcHBvbmVudCkgPT4gdGVzdENhbmRpZGF0ZShydWxlLCBjYW5kaWRhdGUsIG9wcG9uZW50KSlcbiAgICAuZXZlcnkoQm9vbGVhbik7XG5jb25zdCBlbmZvcmNlUnVsZXMgPSAobWVhc3VyZW1lbnRzLCBydWxlcywgc3BhY2VmaW5kZXJFeGNsdXNpb25zKSA9PiB7XG4gICAgbGV0IGNhbmRpZGF0ZXMgPSBtZWFzdXJlbWVudHMuY2FuZGlkYXRlcztcbiAgICAvLyBlbmZvcmNlIGFic29sdXRlTWluRGlzdGFuY2VGcm9tVG9wIHJ1bGVcbiAgICBsZXQgW2ZpbHRlcmVkLCBleGNsdXNpb25zXSA9IHBhcnRpdGlvbkNhbmRpZGF0ZXMoY2FuZGlkYXRlcywgKGNhbmRpZGF0ZSkgPT4gIXJ1bGVzLmFic29sdXRlTWluRGlzdGFuY2VGcm9tVG9wIHx8XG4gICAgICAgIGNhbmRpZGF0ZS50b3AgKyBtZWFzdXJlbWVudHMuYm9keVRvcCA+PVxuICAgICAgICAgICAgcnVsZXMuYWJzb2x1dGVNaW5EaXN0YW5jZUZyb21Ub3ApO1xuICAgIHNwYWNlZmluZGVyRXhjbHVzaW9ucy5hYnNvbHV0ZU1pbkRpc3RhbmNlRnJvbVRvcCA9IGV4Y2x1c2lvbnM7XG4gICAgY2FuZGlkYXRlcyA9IGZpbHRlcmVkO1xuICAgIC8vIGVuZm9yY2UgbWluQWJvdmUgYW5kIG1pbkJlbG93IHJ1bGVzXG4gICAgW2ZpbHRlcmVkLCBleGNsdXNpb25zXSA9IHBhcnRpdGlvbkNhbmRpZGF0ZXMoY2FuZGlkYXRlcywgKGNhbmRpZGF0ZSkgPT4ge1xuICAgICAgICBjb25zdCBmYXJFbm91Z2hGcm9tVG9wT2ZCb2R5ID0gY2FuZGlkYXRlLnRvcCA+PSBydWxlcy5taW5EaXN0YW5jZUZyb21Ub3A7XG4gICAgICAgIGNvbnN0IGZhckVub3VnaEZyb21Cb3R0b21PZkJvZHkgPSBjYW5kaWRhdGUudG9wICsgcnVsZXMubWluRGlzdGFuY2VGcm9tQm90dG9tIDw9XG4gICAgICAgICAgICBtZWFzdXJlbWVudHMuYm9keUhlaWdodDtcbiAgICAgICAgcmV0dXJuIGZhckVub3VnaEZyb21Ub3BPZkJvZHkgJiYgZmFyRW5vdWdoRnJvbUJvdHRvbU9mQm9keTtcbiAgICB9KTtcbiAgICBzcGFjZWZpbmRlckV4Y2x1c2lvbnMuYWJvdmVBbmRCZWxvdyA9IGV4Y2x1c2lvbnM7XG4gICAgY2FuZGlkYXRlcyA9IGZpbHRlcmVkO1xuICAgIC8vIGVuZm9yY2UgY29udGVudCBtZXRhIHJ1bGVcbiAgICBjb25zdCB7IGNsZWFyQ29udGVudE1ldGEgfSA9IHJ1bGVzO1xuICAgIGlmIChjbGVhckNvbnRlbnRNZXRhKSB7XG4gICAgICAgIFtmaWx0ZXJlZCwgZXhjbHVzaW9uc10gPSBwYXJ0aXRpb25DYW5kaWRhdGVzKGNhbmRpZGF0ZXMsIChjYW5kaWRhdGUpID0+ICEhbWVhc3VyZW1lbnRzLmNvbnRlbnRNZXRhICYmXG4gICAgICAgICAgICBjYW5kaWRhdGUudG9wID5cbiAgICAgICAgICAgICAgICBtZWFzdXJlbWVudHMuY29udGVudE1ldGEuYm90dG9tICsgY2xlYXJDb250ZW50TWV0YSk7XG4gICAgICAgIHNwYWNlZmluZGVyRXhjbHVzaW9ucy5jb250ZW50TWV0YSA9IGV4Y2x1c2lvbnM7XG4gICAgICAgIGNhbmRpZGF0ZXMgPSBmaWx0ZXJlZDtcbiAgICB9XG4gICAgLy8gZW5mb3JjZSBzZWxlY3RvciBydWxlc1xuICAgIGlmIChydWxlcy5vcHBvbmVudFNlbGVjdG9yUnVsZXMpIHtcbiAgICAgICAgY29uc3Qgc2VsZWN0b3JFeGNsdXNpb25zID0gW107XG4gICAgICAgIGZvciAoY29uc3QgW3NlbGVjdG9yLCBydWxlXSBvZiBPYmplY3QuZW50cmllcyhydWxlcy5vcHBvbmVudFNlbGVjdG9yUnVsZXMpKSB7XG4gICAgICAgICAgICBbZmlsdGVyZWQsIGV4Y2x1c2lvbnNdID0gcGFydGl0aW9uQ2FuZGlkYXRlcyhjYW5kaWRhdGVzLCAoY2FuZGlkYXRlKSA9PiB0ZXN0Q2FuZGlkYXRlcyhydWxlLCBjYW5kaWRhdGUsIG1lYXN1cmVtZW50cy5vcHBvbmVudHM/LltzZWxlY3Rvcl0gPz8gW10pKTtcbiAgICAgICAgICAgIHNwYWNlZmluZGVyRXhjbHVzaW9uc1tzZWxlY3Rvcl0gPSBleGNsdXNpb25zO1xuICAgICAgICAgICAgc2VsZWN0b3JFeGNsdXNpb25zLnB1c2goLi4uZXhjbHVzaW9ucyk7XG4gICAgICAgIH1cbiAgICAgICAgY2FuZGlkYXRlcyA9IGNhbmRpZGF0ZXMuZmlsdGVyKChjYW5kaWRhdGUpID0+ICFzZWxlY3RvckV4Y2x1c2lvbnMuaW5jbHVkZXMoY2FuZGlkYXRlKSk7XG4gICAgfVxuICAgIGlmIChydWxlcy5maWx0ZXIpIHtcbiAgICAgICAgW2ZpbHRlcmVkLCBleGNsdXNpb25zXSA9IHBhcnRpdGlvbkNhbmRpZGF0ZXMoY2FuZGlkYXRlcywgcnVsZXMuZmlsdGVyKTtcbiAgICAgICAgc3BhY2VmaW5kZXJFeGNsdXNpb25zLmN1c3RvbSA9IGV4Y2x1c2lvbnM7XG4gICAgICAgIGNhbmRpZGF0ZXMgPSBmaWx0ZXJlZDtcbiAgICB9XG4gICAgcmV0dXJuIGNhbmRpZGF0ZXM7XG59O1xuY2xhc3MgU3BhY2VFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihydWxlcykge1xuICAgICAgICBzdXBlcigpO1xuICAgICAgICB0aGlzLm5hbWUgPSAnU3BhY2VFcnJvcic7XG4gICAgICAgIHRoaXMubWVzc2FnZSA9IGBUaGVyZSBpcyBubyBzcGFjZSBsZWZ0IG1hdGNoaW5nIHJ1bGVzIGZyb20gJHtydWxlcy5ib2R5U2VsZWN0b3J9YDtcbiAgICB9XG59XG4vKipcbiAqIFdhaXQgZm9yIHRoZSBwYWdlIHRvIGJlIHJlYWR5IChpbWFnZXMgbG9hZGVkLCBpbnRlcmFjdGl2ZXMgbG9hZGVkKVxuICogb3IgZm9yIExPQURJTkdfVElNRU9VVCB0byBlbGFwc2UsIHdoaWNoZXZlciBjb21lcyBmaXJzdC5cbiAqIEBwYXJhbSAge1NwYWNlZmluZGVyUnVsZXN9IHJ1bGVzXG4gKiBAcGFyYW0gIHtTcGFjZWZpbmRlck9wdGlvbnN9IG9wdGlvbnNcbiAqL1xuY29uc3QgZ2V0UmVhZHkgPSAocnVsZXMsIG9wdGlvbnMpID0+IFByb21pc2UucmFjZShbXG4gICAgbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHJlc29sdmUoJ3RpbWVvdXQnKSwgTE9BRElOR19USU1FT1VUKSksXG4gICAgUHJvbWlzZS5hbGwoW1xuICAgICAgICBvcHRpb25zLndhaXRGb3JJbWFnZXMgPyBvbkltYWdlc0xvYWRlZChydWxlcykgOiBQcm9taXNlLnJlc29sdmUoKSxcbiAgICAgICAgb3B0aW9ucy53YWl0Rm9ySW50ZXJhY3RpdmVzXG4gICAgICAgICAgICA/IG9uSW50ZXJhY3RpdmVzTG9hZGVkKHJ1bGVzKVxuICAgICAgICAgICAgOiBQcm9taXNlLnJlc29sdmUoKSxcbiAgICBdKSxcbl0pLnRoZW4oKHZhbHVlKSA9PiB7XG4gICAgaWYgKHZhbHVlID09PSAndGltZW91dCcpIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ1NwYWNlZmluZGVyIHRpbWVvdXQgaGl0Jyk7XG4gICAgfVxufSk7XG5jb25zdCBnZXRDYW5kaWRhdGVzID0gKHJ1bGVzLCBzcGFjZWZpbmRlckV4Y2x1c2lvbnMpID0+IHtcbiAgICBsZXQgY2FuZGlkYXRlcyA9IHF1ZXJ5KHJ1bGVzLmNhbmRpZGF0ZVNlbGVjdG9yLCBydWxlcy5ib2R5KTtcbiAgICBpZiAocnVsZXMuZnJvbUJvdHRvbSkge1xuICAgICAgICBjYW5kaWRhdGVzLnJldmVyc2UoKTtcbiAgICB9XG4gICAgaWYgKHJ1bGVzLnN0YXJ0QXQpIHtcbiAgICAgICAgbGV0IGRyb3AgPSB0cnVlO1xuICAgICAgICBjb25zdCBbZmlsdGVyZWQsIGV4Y2x1c2lvbnNdID0gcGFydGl0aW9uQ2FuZGlkYXRlcyhjYW5kaWRhdGVzLCAoY2FuZGlkYXRlKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2FuZGlkYXRlID09PSBydWxlcy5zdGFydEF0KSB7XG4gICAgICAgICAgICAgICAgZHJvcCA9IGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuICFkcm9wO1xuICAgICAgICB9KTtcbiAgICAgICAgc3BhY2VmaW5kZXJFeGNsdXNpb25zLnN0YXJ0QXQgPSBleGNsdXNpb25zO1xuICAgICAgICBjYW5kaWRhdGVzID0gZmlsdGVyZWQ7XG4gICAgfVxuICAgIGlmIChydWxlcy5zdG9wQXQpIHtcbiAgICAgICAgbGV0IGtlZXAgPSB0cnVlO1xuICAgICAgICBjb25zdCBbZmlsdGVyZWQsIGV4Y2x1c2lvbnNdID0gcGFydGl0aW9uQ2FuZGlkYXRlcyhjYW5kaWRhdGVzLCAoY2FuZGlkYXRlKSA9PiB7XG4gICAgICAgICAgICBpZiAoY2FuZGlkYXRlID09PSBydWxlcy5zdG9wQXQpIHtcbiAgICAgICAgICAgICAgICBrZWVwID0gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4ga2VlcDtcbiAgICAgICAgfSk7XG4gICAgICAgIHNwYWNlZmluZGVyRXhjbHVzaW9ucy5zdG9wQXQgPSBleGNsdXNpb25zO1xuICAgICAgICBjYW5kaWRhdGVzID0gZmlsdGVyZWQ7XG4gICAgfVxuICAgIHJldHVybiBjYW5kaWRhdGVzO1xufTtcbmNvbnN0IGdldERpbWVuc2lvbnMgPSAoZWxlbWVudCkgPT4gT2JqZWN0LmZyZWV6ZSh7XG4gICAgdG9wOiBlbGVtZW50Lm9mZnNldFRvcCxcbiAgICBib3R0b206IGVsZW1lbnQub2Zmc2V0VG9wICsgZWxlbWVudC5vZmZzZXRIZWlnaHQsXG4gICAgZWxlbWVudCxcbiAgICBtZXRhOiB7XG4gICAgICAgIHRvb0Nsb3NlOiBbXSxcbiAgICAgICAgb3ZlcmxhcHM6IFtdLFxuICAgIH0sXG59KTtcbmNvbnN0IGdldE1lYXN1cmVtZW50cyA9IChydWxlcywgY2FuZGlkYXRlcykgPT4ge1xuICAgIGNvbnN0IGNvbnRlbnRNZXRhID0gcnVsZXMuY2xlYXJDb250ZW50TWV0YVxuICAgICAgICA/IChkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuanMtY29udGVudC1tZXRhJykgPz8gdW5kZWZpbmVkKVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICBjb25zdCBvcHBvbmVudHMgPSBydWxlcy5vcHBvbmVudFNlbGVjdG9yUnVsZXNcbiAgICAgICAgPyBPYmplY3Qua2V5cyhydWxlcy5vcHBvbmVudFNlbGVjdG9yUnVsZXMpLm1hcCgoc2VsZWN0b3IpID0+IFtzZWxlY3RvciwgcXVlcnkoc2VsZWN0b3IsIHJ1bGVzLmJvZHkpXSlcbiAgICAgICAgOiBbXTtcbiAgICByZXR1cm4gZmFzdGRvbS5tZWFzdXJlKCgpID0+IHtcbiAgICAgICAgbGV0IGJvZHlEaXN0YW5jZVRvVG9wT2ZQYWdlID0gMDtcbiAgICAgICAgbGV0IGJvZHlIZWlnaHQgPSAwO1xuICAgICAgICBpZiAocnVsZXMuYm9keSBpbnN0YW5jZW9mIEVsZW1lbnQpIHtcbiAgICAgICAgICAgIGNvbnN0IGJvZHlFbGVtZW50ID0gcnVsZXMuYm9keS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgIC8vIGJvZHlFbGVtZW50IGlzIHJlbGF0aXZlIHRvIHRoZSB2aWV3cG9ydCwgc28gd2UgbmVlZCB0byBhZGQgc2Nyb2xsIHBvc2l0aW9uIHRvIGdldCB0aGUgZGlzdGFuY2VcbiAgICAgICAgICAgIGJvZHlEaXN0YW5jZVRvVG9wT2ZQYWdlID0gYm9keUVsZW1lbnQudG9wICsgd2luZG93LnNjcm9sbFk7XG4gICAgICAgICAgICBib2R5SGVpZ2h0ID0gYm9keUVsZW1lbnQuaGVpZ2h0O1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGNhbmRpZGF0ZXNXaXRoRGltcyA9IGNhbmRpZGF0ZXMubWFwKGdldERpbWVuc2lvbnMpO1xuICAgICAgICBjb25zdCBjb250ZW50TWV0YVdpdGhEaW1zID0gcnVsZXMuY2xlYXJDb250ZW50TWV0YSAmJiBjb250ZW50TWV0YVxuICAgICAgICAgICAgPyBnZXREaW1lbnNpb25zKGNvbnRlbnRNZXRhKVxuICAgICAgICAgICAgOiB1bmRlZmluZWQ7XG4gICAgICAgIGNvbnN0IG9wcG9uZW50c1dpdGhEaW1zID0gb3Bwb25lbnRzLnJlZHVjZSgocmVzdWx0LCBbc2VsZWN0b3IsIHNlbGVjdGVkRWxlbWVudHNdKSA9PiB7XG4gICAgICAgICAgICByZXN1bHRbc2VsZWN0b3JdID0gc2VsZWN0ZWRFbGVtZW50cy5tYXAoZ2V0RGltZW5zaW9ucyk7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9LCB7fSk7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBib2R5VG9wOiBib2R5RGlzdGFuY2VUb1RvcE9mUGFnZSxcbiAgICAgICAgICAgIGJvZHlIZWlnaHQsXG4gICAgICAgICAgICBjYW5kaWRhdGVzOiBjYW5kaWRhdGVzV2l0aERpbXMsXG4gICAgICAgICAgICBjb250ZW50TWV0YTogY29udGVudE1ldGFXaXRoRGltcyxcbiAgICAgICAgICAgIG9wcG9uZW50czogb3Bwb25lbnRzV2l0aERpbXMsXG4gICAgICAgIH07XG4gICAgfSk7XG59O1xuLy8gUmF0aGVyIHRoYW4gY2FsbGluZyB0aGlzIGRpcmVjdGx5LCB1c2Ugc3BhY2VGaWxsZXIgdG8gaW5qZWN0IGNvbnRlbnQgaW50byB0aGUgcGFnZS5cbi8vIFNwYWNlRmlsbGVyIHdpbGwgc2FmZWx5IHF1ZXVlIHVwIGFsbCB0aGUgdmFyaW91cyBhc3luY2hyb25vdXMgRE9NIGFjdGlvbnMgdG8gYXZvaWQgYW55IHJhY2UgY29uZGl0aW9ucy5cbmNvbnN0IGZpbmRTcGFjZSA9IGFzeW5jIChydWxlcywgb3B0aW9ucywgZXhjbHVzaW9ucyA9IHt9KSA9PiB7XG4gICAgb3B0aW9ucyA9IHsgLi4uZGVmYXVsdE9wdGlvbnMsIC4uLm9wdGlvbnMgfTtcbiAgICBydWxlcy5ib2R5ID0gcnVsZXMuYm9keVNlbGVjdG9yXG4gICAgICAgID8gKGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IocnVsZXMuYm9keVNlbGVjdG9yKSA/PyBkb2N1bWVudClcbiAgICAgICAgOiBkb2N1bWVudDtcbiAgICB3aW5kb3cucGVyZm9ybWFuY2UubWFyaygnY29tbWVyY2lhbDpzcGFjZWZpbmRlcjpmaW5kU3BhY2U6c3RhcnQnKTtcbiAgICBhd2FpdCBnZXRSZWFkeShydWxlcywgb3B0aW9ucyk7XG4gICAgY29uc3QgY2FuZGlkYXRlcyA9IGdldENhbmRpZGF0ZXMocnVsZXMsIGV4Y2x1c2lvbnMpO1xuICAgIGNvbnN0IG1lYXN1cmVtZW50cyA9IGF3YWl0IGdldE1lYXN1cmVtZW50cyhydWxlcywgY2FuZGlkYXRlcyk7XG4gICAgY29uc3Qgd2lubmVycyA9IGVuZm9yY2VSdWxlcyhtZWFzdXJlbWVudHMsIHJ1bGVzLCBleGNsdXNpb25zKTtcbiAgICBjb25zdCBlbmFibGVEZWJ1ZyA9ICEhZ2V0VXJsVmFycygpLnNmZGVidWc7XG4gICAgaWYgKGVuYWJsZURlYnVnKSB7XG4gICAgICAgIGNvbnN0IHBhc3MgPSBvcHRpb25zLnBhc3M7XG4gICAgICAgIHZvaWQgaW1wb3J0KCcuL3NwYWNlZmluZGVyLWRlYnVnLXRvb2xzJykudGhlbigoeyBpbml0IH0pID0+IHtcbiAgICAgICAgICAgIGluaXQoZXhjbHVzaW9ucywgd2lubmVycywgcnVsZXMsIHBhc3MpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgd2luZG93LnBlcmZvcm1hbmNlLm1hcmsoJ2NvbW1lcmNpYWw6c3BhY2VmaW5kZXI6ZmluZFNwYWNlOmVuZCcpO1xuICAgIGNvbnN0IG1lYXN1cmUgPSB3aW5kb3cucGVyZm9ybWFuY2UubWVhc3VyZSgnY29tbWVyY2lhbDpzcGFjZWZpbmRlcjpmaW5kU3BhY2UnLCAnY29tbWVyY2lhbDpzcGFjZWZpbmRlcjpmaW5kU3BhY2U6c3RhcnQnLCAnY29tbWVyY2lhbDpzcGFjZWZpbmRlcjpmaW5kU3BhY2U6ZW5kJyk7XG4gICAgbG9nKCdjb21tZXJjaWFsJywgYFNwYWNlZmluZGVyIHRvb2sgJHtNYXRoLnJvdW5kKG1lYXN1cmU/LmR1cmF0aW9uID8/IDApfW1zIGZvciAnJHtvcHRpb25zLnBhc3N9JyBwYXNzYCwge1xuICAgICAgICBydWxlcyxcbiAgICAgICAgb3B0aW9ucyxcbiAgICB9KTtcbiAgICAvLyBUT0RPIElzIHRoaXMgcmVhbGx5IGFuIGVycm9yIGNvbmRpdGlvbj9cbiAgICBpZiAoIXdpbm5lcnMubGVuZ3RoKSB7XG4gICAgICAgIHRocm93IG5ldyBTcGFjZUVycm9yKHJ1bGVzKTtcbiAgICB9XG4gICAgcmV0dXJuIHdpbm5lcnMubWFwKChjYW5kaWRhdGUpID0+IGNhbmRpZGF0ZS5lbGVtZW50KTtcbn07XG5leHBvcnQgeyBmaW5kU3BhY2UsIFNwYWNlRXJyb3IgfTtcbiIsImltcG9ydCB7IGlzVW5kZWZpbmVkIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgYnJlYWtwb2ludHMgfSBmcm9tICdAZ3VhcmRpYW4vc291cmNlL2ZvdW5kYXRpb25zJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uL2xpYi9mYXN0ZG9tLXByb21pc2UnO1xuLyoqXG4gKiBUaGUgbWluaW11bSBidWZmZXIgYmV0d2VlbiB0d28gYWR2ZXJ0cyAoYWthIHdpbm5pbmcgcGFyYWdyYXBocykgaW4gdGhlIHJpZ2h0IGNvbHVtblxuICovXG5jb25zdCBQQVJBR1JBUEhfQlVGRkVSX1BYID0gNjAwO1xuLyoqXG4gKiBUaGUgbWluaW11bSBidWZmZXIgYmV0d2VlbiBhIHJpZ2h0IGNvbHVtbiBhZHZlcnQgYW5kIGFuIGltbWVyc2l2ZSBlbGVtZW50XG4gKi9cbmNvbnN0IElNTUVSU0lWRV9CVUZGRVJfUFggPSAxMDA7XG4vKipcbiAqIFRoZSBtaW5pbXVtIGJ1ZmZlciBiZXR3ZWVuIGEgcmlnaHQgY29sdW1uIGFkdmVydCBhbmQgdGhlIGJvdHRvbSBvZiB0aGUgYXJ0aWNsZSBib2R5XG4gKi9cbmNvbnN0IEFSVElDTEVfQk9UVE9NX0JVRkZFUl9QWCA9IDEwMDtcbi8qKlxuICogVGhlIGhlaWdodCBvZiB0aGUgbGFicyBoZWFkZXIgb24gcGFpZCBjb250ZW50IHBhZ2VzXG4gKi9cbmNvbnN0IExBQlNfSEVBREVSX0hFSUdIVCA9IDU1O1xuLyoqXG4gKiBBZGQgYSBzdHlsZXNoZWV0IHRvIHRoZSBkb2N1bWVudCB0aGF0IGFkZHMgaGVpZ2h0IHByb3BlcnRpZXMgZm9yIGEgZ2l2ZW4gc2V0IG9mIGNsYXNzIG5hbWVzXG4gKlxuICogTm90ZSB0aGVzZSBhcmUgb25seSBhYm92ZSBvbiBkZXNrdG9wIGFuZCBhYm92ZVxuICpcbiAqIEBwYXJhbSBoZWlnaHRNYXBwaW5nIFRoZSBtYXBwaW5nIGZyb20gY2xhc3MgbmFtZSB0byBoZWlnaHQgdmFsdWUgaW4gcGl4ZWxzXG4gKi9cbmNvbnN0IGluc2VydEhlaWdodFN0eWxlcyA9IChoZWlnaHRNYXBwaW5nKSA9PiB7XG4gICAgLyoqXG4gICAgICogUGFpZCBjb250ZW50IGhhcyBhIGJhbm5lciBhdCB0aGUgdG9wIG9mIHRoZSBwYWdlLiBXZSBkb24ndCB3YW50IHRoaXNcbiAgICAgKiBiYW5uZXIgdG8gb3ZlcmxhcCB0aGUgYWR2ZXJ0LiBBZGRzIGV4dHJhIHBhZGRpbmcgZm9yIHZpc3VhbCBiZW5lZml0XG4gICAgICovXG4gICAgY29uc3QgdG9wID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzUGFpZENvbnRlbnRcbiAgICAgICAgPyBgJHtMQUJTX0hFQURFUl9IRUlHSFQgKyA2fXB4YFxuICAgICAgICA6IDA7XG4gICAgY29uc3QgaGVpZ2h0Q2xhc3NlcyA9IGhlaWdodE1hcHBpbmcucmVkdWNlKChjc3MsIFtuYW1lLCBoZWlnaHRdKSA9PiBgJHtjc3N9IC4ke25hbWV9IHsgbWluLWhlaWdodDogJHtoZWlnaHR9cHg7IH0gLiR7bmFtZX0gPiAqIHsgcG9zaXRpb246IHN0aWNreTsgdG9wOiAke3RvcH07IH1gLCAnJyk7XG4gICAgY29uc3QgY3NzID0gYFxuICAgICAgICBAbWVkaWEgKG1pbi13aWR0aDogJHticmVha3BvaW50cy5kZXNrdG9wfXB4KSB7XG4gICAgICAgICAgICAke2hlaWdodENsYXNzZXN9XG4gICAgICAgIH1cbiAgICBgO1xuICAgIGNvbnN0IHN0eWxlID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc3R5bGUnKTtcbiAgICBzdHlsZS5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShjc3MpKTtcbiAgICByZXR1cm4gZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICBkb2N1bWVudC5oZWFkLmFwcGVuZENoaWxkKHN0eWxlKTtcbiAgICB9KTtcbn07XG4vKipcbiAqIENvbXB1dGUgdGhlIGRpc3RhbmNlIGJldHdlZW4gZWFjaCB3aW5uaW5nIHBhcmFncmFwaCBhbmQgc3Vic2VxdWVudCBwYXJhZ3JhcGgsXG4gKiB0YWtpbmcgaW50byBhY2NvdW50IGVsZW1lbnRzIHRoYXQgZXh0ZW5kIGludG8gdGhlIHJpZ2h0IGNvbHVtblxuICovXG5jb25zdCBjb21wdXRlU3RpY2t5SGVpZ2h0cyA9IGFzeW5jICh3aW5uZXJzLCBhcnRpY2xlQm9keVNlbGVjdG9yKSA9PiB7XG4gICAgLy8gSW1tZXJzaXZlIGZpZ3VyZXMgY2FuIGV4dGVuZCBpbnRvIHRoZSByaWdodCBjb2x1bW5cbiAgICAvLyBUaGVyZWZvcmUgd2UgaGF2ZSB0byB0YWtlIHRoZW0gaW50byBhY2NvdW50IHdoZW4gd2UgY2FuIGNvbXB1dGUgaG93IGZhciBhbiBhZCBjYW4gYmUgc3RpY2t5IGZvclxuICAgIGNvbnN0IGltbWVyc2l2ZUZpZ3VyZXMgPSBbXG4gICAgICAgIC4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ1tkYXRhLXNwYWNlZmluZGVyLXJvbGU9XCJpbW1lcnNpdmVcIl0nKSxcbiAgICBdO1xuICAgIGNvbnN0IHsgZmlndXJlcywgd2lubmluZ1BhcmFzLCBhcnRpY2xlQm9keUVsZW1lbnRIZWlnaHRCb3R0b20gfSA9IGF3YWl0IGZhc3Rkb20ubWVhc3VyZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IGZpZ3VyZXMgPSBpbW1lcnNpdmVGaWd1cmVzLm1hcCgoZWxlbWVudCkgPT4gKHtcbiAgICAgICAgICAgIGtpbmQ6ICdmaWd1cmUnLFxuICAgICAgICAgICAgdG9wOiBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnRvcCxcbiAgICAgICAgICAgIGVsZW1lbnQsXG4gICAgICAgIH0pKTtcbiAgICAgICAgY29uc3Qgd2lubmluZ1BhcmFzID0gd2lubmVycy5tYXAoKGVsZW1lbnQpID0+ICh7XG4gICAgICAgICAgICBraW5kOiAnd2lubmluZ1BhcmEnLFxuICAgICAgICAgICAgdG9wOiBlbGVtZW50LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLnRvcCxcbiAgICAgICAgICAgIGVsZW1lbnQsXG4gICAgICAgIH0pKTtcbiAgICAgICAgY29uc3QgYXJ0aWNsZUJvZHlFbGVtZW50SGVpZ2h0Qm90dG9tID0gZG9jdW1lbnRcbiAgICAgICAgICAgIC5xdWVyeVNlbGVjdG9yKGFydGljbGVCb2R5U2VsZWN0b3IpXG4gICAgICAgICAgICA/LmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpLmJvdHRvbSA/PyAwO1xuICAgICAgICByZXR1cm4geyBmaWd1cmVzLCB3aW5uaW5nUGFyYXMsIGFydGljbGVCb2R5RWxlbWVudEhlaWdodEJvdHRvbSB9O1xuICAgIH0pO1xuICAgIHJldHVybiAoXG4gICAgLy8gQ29uY2F0IHRoZSBzZXQgb2YgZmlndXJlcyBhbmQgd2lubmluZyBwYXJhZ3JhcGhzIGluIHRoZSBhcnRpY2xlXG4gICAgWy4uLmZpZ3VyZXMsIC4uLndpbm5pbmdQYXJhc11cbiAgICAgICAgLy8gU29ydCBzbyB0aGV5IGFwcGVhciBpbiBvcmRlciBvZiB0aGVpciB0b3AgY29vcmRpbmF0ZXNcbiAgICAgICAgLnNvcnQoKGZpcnN0LCBzZWNvbmQpID0+IGZpcnN0LnRvcCAtIHNlY29uZC50b3ApXG4gICAgICAgIC8vIFN0ZXAgdGhyb3VnaCBlYWNoIG9uZSBieSBvbmUsIG1lYXN1cmluZyB0aGUgaGVpZ2h0IHdlIGNhbiBtYWtlIHRoZSBjb250YWluZXIgb2YgdGhlIGFkIHNsb3RcbiAgICAgICAgLm1hcCgoY3VycmVudCwgaW5kZXgsIGl0ZW1zKSA9PiB7XG4gICAgICAgIC8vIFdlIGRvbid0IGNhcmUgYWJvdXQgY29tcHV0aW5nIHRoZSBkaXN0YW5jZSAqZnJvbSogZmlndXJlc1xuICAgICAgICAvLyBUaGVzZSB3aWxsIGJlIGZpbHRlcmVkIG91dCBpbiB0aGUgbmV4dCBzdGVwXG4gICAgICAgIGlmIChjdXJyZW50LmtpbmQgPT09ICdmaWd1cmUnKSB7XG4gICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICB9XG4gICAgICAgIC8vIFJldHJpZXZlIHRoZSBuZXh0IGVsZW1lbnQgdG8gd2hpY2ggd2UnbGwgZXh0ZW5kIHRoZSBjb250YWluZXIgaGVpZ2h0XG4gICAgICAgIC8vIFRoaXMgY2FuIGJlIHVuZGVmaW5lZCBpZiB0aGVyZSBpcyBubyBuZXh0IGl0ZW1cbiAgICAgICAgY29uc3QgbmV4dCA9IGl0ZW1zW2luZGV4ICsgMV07XG4gICAgICAgIC8vIElmIHRoZXJlIGlzIG5vIGBuZXh0YCBlbGVtZW50IHdlJ3ZlIHJlYWNoZWQgdGhlIGZpbmFsIGVsZW1lbnQgaW4gdGhlIGFydGljbGUgYm9keVxuICAgICAgICAvLyBJbiB0aGlzIGNhc2Ugd2Ugd2FudCB0byBtYWtlIHRoZSBzdGlja3kgZGlzdGFuY2UgZXh0ZW5kIHVudGlsIHRoZSBib3R0b20gb2YgdGhlIGFydGljbGUgYm9keSxcbiAgICAgICAgLy8gbWludXMgYSBzbWFsbCBjb25zdGFudCBidWZmZXJcbiAgICAgICAgaWYgKG5leHQgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIChhcnRpY2xlQm9keUVsZW1lbnRIZWlnaHRCb3R0b20gLVxuICAgICAgICAgICAgICAgIGN1cnJlbnQudG9wIC1cbiAgICAgICAgICAgICAgICBBUlRJQ0xFX0JPVFRPTV9CVUZGRVJfUFgpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENob29zZSBoZWlnaHQgb2YgYnVmZmVyIGRlcGVuZGluZyBvbiB0aGUga2luZCBvZiBlbGVtZW50IHdlJ3JlIG1lYXN1cmluZyB0b1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXh0LmtpbmQgPT09ICd3aW5uaW5nUGFyYSdcbiAgICAgICAgICAgID8gUEFSQUdSQVBIX0JVRkZFUl9QWFxuICAgICAgICAgICAgOiBJTU1FUlNJVkVfQlVGRkVSX1BYO1xuICAgICAgICAvLyBDb21wdXRlIHRoZSBkaXN0YW5jZSBmcm9tIHRoZSB0b3Agb2YgdGhlIGN1cnJlbnQgZWxlbWVudCB0byB0aGUgdG9wIG9mIHRoZSBuZXh0IGVsZW1lbnQsIG1pbnVzIHRoZSBidWZmZXJcbiAgICAgICAgcmV0dXJuIE1hdGguZmxvb3IobmV4dC50b3AgLSBjdXJyZW50LnRvcCAtIGJ1ZmZlcik7XG4gICAgfSlcbiAgICAgICAgLy8gUmVtb3ZlIHRoZSBmaWd1cmVzIG1hcmtlZCBhcyB1bmRlZmluZWRcbiAgICAgICAgLy8gSW4gZWZmZWN0IGtlZXBpbmcgb25seSB0aGUgaGVpZ2h0cyBmb3Igd2lubmluZyBwYXJhZ3JhcGhzXG4gICAgICAgIC5maWx0ZXIoKGhlaWdodCkgPT4gIWlzVW5kZWZpbmVkKGhlaWdodCkpKTtcbn07XG5leHBvcnQgeyBjb21wdXRlU3RpY2t5SGVpZ2h0cywgaW5zZXJ0SGVpZ2h0U3R5bGVzIH07XG4iLCIvKipcbiAqIFB1Ym1hdGljIGN1c3RvbSBvdmVycmlkZSBzY3JpcHRcbiAqXG4gKiBGcm9tIHtATGluayBodHRwczovL2dpc3QuZ2l0aHViLmNvbS9hYmhpbmF2c2luaGEwMDEvZGU0NmJkNGFjNGYwMmQ5OGViNTBjMWY0Zjk5NTU0NWV9XG4gKi9cbmV4cG9ydCBjb25zdCBwdWJtYXRpYyA9IGZ1bmN0aW9uIChiaWQsIGRhdGEsIGFjRW5hYmxlZCwgdXRpbHMsIGRlZmF1bHRGbikge1xuICAgIGlmIChkZWZhdWx0Rm4pIHtcbiAgICAgICAgLy8ga2VlcCB0aGlzIHRvIG1vdmUgdG8gZGVmYXVsdCBmdW5jdGlvbiBvbmNlIHN1cHBvcnRlZCBieSBSVEQgc3VibW9kdWxlXG4gICAgICAgIGJpZCA9IGRlZmF1bHRGbihiaWQsIGRhdGEsIGFjRW5hYmxlZCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBsZXQgc2VnbWVudHMgPSBbXTtcbiAgICAgICAgLy8gYWRkIGFsbCB1c2VyIHNlZ21lbnRzXG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCBwc2VncyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLl9wc2VncyB8fCAnW10nKS5tYXAoU3RyaW5nKTtcbiAgICAgICAgICAgIGNvbnN0IHBwYW0gPSBKU09OLnBhcnNlKGxvY2FsU3RvcmFnZS5fcHBhbSB8fCAnW10nKTtcbiAgICAgICAgICAgIGNvbnN0IHBjcnBycyA9IEpTT04ucGFyc2UobG9jYWxTdG9yYWdlLl9wY3JwcnMgfHwgJ1tdJyk7XG4gICAgICAgICAgICBzZWdtZW50cyA9IFsuLi5wc2VncywgLi4ucHBhbSwgLi4ucGNycHJzXTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkgeyB9XG4gICAgICAgIC8vIGFkZCBBQyBzcGVjaWZpYyBzZWdtZW50cyAodGhlc2Ugd291bGQgdHlwaWNhbGx5IGdvIHRvIGEgc2VwYXJhdGUga2V5LXZhbHVlLCBidXQgbm90IHN1cmUgaWYgd2UgY2FuIGhhdmUgMiBsaXN0cyBvZiBzZWdtZW50cyBoZXJlPylcbiAgICAgICAgaWYgKGFjRW5hYmxlZCAmJiBkYXRhLmFjICYmIGRhdGEuYWMubGVuZ3RoID4gMCkge1xuICAgICAgICAgICAgc2VnbWVudHMgPSBzZWdtZW50cy5jb25jYXQoZGF0YS5hYyk7XG4gICAgICAgIH1cbiAgICAgICAgc2VnbWVudHMgPSBzZWdtZW50cy5tYXAoZnVuY3Rpb24gKHNlZykge1xuICAgICAgICAgICAgcmV0dXJuIHsgaWQ6IHNlZyB9O1xuICAgICAgICB9KTtcbiAgICAgICAgcGJqcy5zZXRCaWRkZXJDb25maWcoe1xuICAgICAgICAgICAgLy8gTm90ZSB0aGlzIHdpbGwgcmVwbGFjZSBleGlzdGluZyBiaWRkZXIgRlBEIGNvbmZpZyB0aWxsIG1lcmdlIGlzIHN1cHBvcnRlZC5cbiAgICAgICAgICAgIGJpZGRlcnM6IFsncHVibWF0aWMnXSxcbiAgICAgICAgICAgIGNvbmZpZzoge1xuICAgICAgICAgICAgICAgIG9ydGIyOiB7XG4gICAgICAgICAgICAgICAgICAgIHVzZXI6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGRhdGE6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIG5hbWU6ICdwZXJtdXRpdmUuY29tJyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc2VnbWVudDogc2VnbWVudHMsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbn07XG4iLCJpbXBvcnQgeyBpc09iamVjdCwgaXNTdHJpbmcsIHN0b3JhZ2UgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5jb25zdCBwYXJ0aWNpcGF0aW9uc0tleSA9ICdndS5hYi5wYXJ0aWNpcGF0aW9ucyc7XG5jb25zdCBpc1BhcnRpY2lwYXRpb25zID0gKHBhcnRpY2lwYXRpb25zKSA9PiB7XG4gICAgcmV0dXJuIChpc09iamVjdChwYXJ0aWNpcGF0aW9ucykgJiZcbiAgICAgICAgT2JqZWN0LnZhbHVlcyhwYXJ0aWNpcGF0aW9ucykuZXZlcnkoKHBhcnRpY2lwYXRpb24pID0+IGlzT2JqZWN0KHBhcnRpY2lwYXRpb24pICYmIGlzU3RyaW5nKHBhcnRpY2lwYXRpb24udmFyaWFudCkpKTtcbn07XG5leHBvcnQgY29uc3QgZ2V0UGFydGljaXBhdGlvbnNGcm9tTG9jYWxTdG9yYWdlID0gKCkgPT4ge1xuICAgIGNvbnN0IHBhcnRpY2lwYXRpb25zID0gc3RvcmFnZS5sb2NhbC5nZXQocGFydGljaXBhdGlvbnNLZXkpO1xuICAgIHJldHVybiBpc1BhcnRpY2lwYXRpb25zKHBhcnRpY2lwYXRpb25zKSA/IHBhcnRpY2lwYXRpb25zIDoge307XG59O1xuZXhwb3J0IGNvbnN0IHNldFBhcnRpY2lwYXRpb25zSW5Mb2NhbFN0b3JhZ2UgPSAocGFydGljaXBhdGlvbnMpID0+IHtcbiAgICBzdG9yYWdlLmxvY2FsLnNldChwYXJ0aWNpcGF0aW9uc0tleSwgcGFydGljaXBhdGlvbnMpO1xufTtcbiIsImltcG9ydCB7IGlzQnJlYWtwb2ludCB9IGZyb20gJ0BndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUvYnJlYWtwb2ludCc7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5jb25zdCBhZFNsb3RJZFByZWZpeCA9ICdkZnAtYWQtLSc7XG5jb25zdCBhZFNsb3RDb25maWdzID0ge1xuICAgICdtZXJjaGFuZGlzaW5nLWhpZ2gnOiB7XG4gICAgICAgIHJlZnJlc2g6IGZhbHNlLFxuICAgIH0sXG4gICAgY2Fycm90OiB7XG4gICAgICAgIGxhYmVsOiBmYWxzZSxcbiAgICAgICAgcmVmcmVzaDogZmFsc2UsXG4gICAgICAgIG5hbWU6ICdjYXJyb3QnLFxuICAgIH0sXG4gICAgJ21vYmlsZS1zdGlja3knOiB7XG4gICAgICAgIGxhYmVsOiB0cnVlLFxuICAgICAgICByZWZyZXNoOiB0cnVlLFxuICAgICAgICBuYW1lOiAnbW9iaWxlLXN0aWNreScsXG4gICAgfSxcbn07XG4vKipcbiAgUmV0dXJucyBhbiBhZFNsb3QgSFRNTEVsZW1lbnQgd2hpY2ggaXMgdGhlIG1haW4gREZQIHNsb3QuXG5cbiAgSW5zZXJ0IHRoYXQgZWxlbWVudCBhcyBzaWJsaW5ncyBhdCB0aGUgcGxhY2UgeW91IHdhbnQgYWR2ZXJ0cyB0byBhcHBlYXIuXG5cbiAgTm90ZSB0aGF0IGZvciB0aGUgREZQIHNsb3QgdG8gYmUgZmlsbGVkIGJ5IEdUUCwgeW91J2xsIGhhdmUgdG9cbiAgdXNlIGFkZFNsb3QgZnJvbSBmaWxsLWR5bmFtaWMtYWR2ZXJ0LXNsb3QudHNcbiovXG5jb25zdCBjcmVhdGVBZFNsb3RFbGVtZW50ID0gKG5hbWUsIGF0dHJzLCBjbGFzc2VzKSA9PiB7XG4gICAgY29uc3QgaWQgPSBgJHthZFNsb3RJZFByZWZpeH0ke25hbWV9YDtcbiAgICAvLyAzNTYyZGMwNy03OGU5LTQ1MDctYjkyMi03OGI5NzlkNGM1Y2JcbiAgICBpZiAod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5pc0RvdGNvbVJlbmRlcmluZyAmJiBuYW1lID09PSAndG9wLWFib3ZlLW5hdicpIHtcbiAgICAgICAgLy8gVGhpcyBpcyB0byBwcmV2ZW50IGEgcHJvYmxlbSB0aGF0IGFwcGVhcmVkIHdpdGggRENSLlxuICAgICAgICAvLyBXZSBhcmUgc2ltcGx5IG1ha2luZyBzdXJlIHRoYXQgaWYgd2UgYXJlIGFib3V0IHRvXG4gICAgICAgIC8vIGludHJvZHVjZSBkZnAtYWQtLXRvcC1hYm92ZS1uYXYgdGhlbiB0aGVyZSBpc24ndCBhbHJlYWR5IG9uZS5cbiAgICAgICAgY29uc3Qgbm9kZSA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGlkKTtcbiAgICAgICAgaWYgKG5vZGU/LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGB3YXJuaW5nOiBjbGVhbmluZyB1cCBkb20gbm9kZSBpZDogZGZwLWFkLS0ke25hbWV9YCk7XG4gICAgICAgICAgICBub2RlLnBhcmVudE5vZGUucmVtb3ZlQ2hpbGQobm9kZSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gVGhlICdtYWluJyBhZFNsb3RcbiAgICBjb25zdCBhZFNsb3QgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBhZFNsb3QuaWQgPSBpZDtcbiAgICBhZFNsb3QuY2xhc3NOYW1lID0gYGpzLWFkLXNsb3QgYWQtc2xvdCAke2NsYXNzZXMuam9pbignICcpfWA7XG4gICAgYWRTbG90LmRhdGFzZXQubGlua05hbWUgPSBgYWQgc2xvdCAke25hbWV9YDtcbiAgICBhZFNsb3QuZGF0YXNldC5uYW1lID0gbmFtZTtcbiAgICBhZFNsb3Quc2V0QXR0cmlidXRlKCdhcmlhLWhpZGRlbicsICd0cnVlJyk7XG4gICAgT2JqZWN0LmVudHJpZXMoYXR0cnMpLmZvckVhY2goKFtrLCB2XSkgPT4gKGFkU2xvdC5kYXRhc2V0W2tdID0gdikpO1xuICAgIHJldHVybiBhZFNsb3Q7XG59O1xuLyoqXG4gKiBTcGxpdCBjbGFzcyBuYW1lcyBhbmQgcHJlZml4IGFsbCB3aXRoIGFkLXNsb3QtLSR7Y2xhc3NOYW1lfVxuICovXG5jb25zdCBjcmVhdGVDbGFzc2VzID0gKHNsb3ROYW1lLCBjbGFzc2VzKSA9PiBbLi4uKGNsYXNzZXM/LnNwbGl0KCcgJykgPz8gW10pLCBzbG90TmFtZV0ubWFwKChjbGFzc05hbWUpID0+IGBhZC1zbG90LS0ke2NsYXNzTmFtZX1gKTtcbi8qKlxuICogR2l2ZW4gZGVmYXVsdCBzaXplIG1hcHBpbmdzIGFuZCBhZGRpdGlvbmFsIHNpemUgbWFwcGluZ3MgZnJvbVxuICogdGhlIGNyZWF0ZUFkU2xvdCBvcHRpb25zIHBhcmFtZXRlci5cbiAqXG4gKiAxLiBDaGVjayB0aGF0IHRoZSBvcHRpb25zIHNpemUgbWFwcGluZ3MgdXNlIGtub3duIGRldmljZSBuYW1lc1xuICogMi4gSWYgc28gY29uY2F0IHRoZSBzaXplIG1hcHBpbmdzXG4gKi9cbmNvbnN0IGNvbmNhdFNpemVNYXBwaW5ncyA9IChkZWZhdWx0U2l6ZU1hcHBpbmdzLCBvcHRpb25TaXplTWFwcGluZ3MgPSB7fSkgPT4gT2JqZWN0LmVudHJpZXMob3B0aW9uU2l6ZU1hcHBpbmdzKS5yZWR1Y2UoKGNvbWJpbmVkU2l6ZU1hcHBpbmcsIFtkZXZpY2UsIG9wdGlvblNpemVzXSkgPT4ge1xuICAgIGlmICghaXNCcmVha3BvaW50KGRldmljZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBVbmtub3duIGRldmljZSBicmVha3BvaW50OiAke2RldmljZX1gKTtcbiAgICB9XG4gICAgY29uc3Qgc2l6ZXMgPSBvcHRpb25TaXplcy5yZWR1Y2UoKGFjYywgc2l6ZSkgPT4ge1xuICAgICAgICBjb25zdCBleGlzdGluZ1NpemUgPSBhY2MuZmluZCgocykgPT4gcy53aWR0aCA9PT0gc2l6ZS53aWR0aCAmJiBzLmhlaWdodCA9PT0gc2l6ZS5oZWlnaHQpO1xuICAgICAgICBpZiAoIWV4aXN0aW5nU2l6ZSkge1xuICAgICAgICAgICAgYWNjLnB1c2goc2l6ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjYztcbiAgICB9LCBbLi4uKGNvbWJpbmVkU2l6ZU1hcHBpbmdbZGV2aWNlXSA/PyBbXSldKTtcbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5jb21iaW5lZFNpemVNYXBwaW5nLFxuICAgICAgICBbZGV2aWNlXTogc2l6ZXMsXG4gICAgfTtcbn0sIHsgLi4uZGVmYXVsdFNpemVNYXBwaW5ncyB9KTtcbmNvbnN0IGFkU2xvdENvbnRhaW5lckNsYXNzID0gJ2FkLXNsb3QtY29udGFpbmVyJztcbmNvbnN0IHdyYXBTbG90SW5Db250YWluZXIgPSAoYWRTbG90LCBvcHRpb25zID0ge30pID0+IHtcbiAgICBjb25zdCBjb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBjb250YWluZXIuY2xhc3NOYW1lID0gYCR7YWRTbG90Q29udGFpbmVyQ2xhc3N9ICR7b3B0aW9ucy5jbGFzc05hbWUgPz8gJyd9YDtcbiAgICBjb250YWluZXIuZGF0YXNldC5hZFNsb3QgPSAndHJ1ZSc7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGFkU2xvdCk7XG4gICAgcmV0dXJuIGNvbnRhaW5lcjtcbn07XG5jb25zdCBjcmVhdGVBZFNsb3QgPSAobmFtZSwgb3B0aW9ucyA9IHt9KSA9PiB7XG4gICAgY29uc3QgYWRTbG90Q29uZmlnID0gYWRTbG90Q29uZmlnc1tuYW1lXSA/PyB7fTtcbiAgICBjb25zdCBzbG90TmFtZSA9IG9wdGlvbnMubmFtZSA/PyBhZFNsb3RDb25maWcubmFtZSA/PyBuYW1lO1xuICAgIGNvbnN0IGRhdGFBdHRyaWJ1dGVzID0ge307XG4gICAgaWYgKGFkU2xvdENvbmZpZy5sYWJlbCA9PT0gZmFsc2UpIHtcbiAgICAgICAgZGF0YUF0dHJpYnV0ZXMubGFiZWwgPSAnZmFsc2UnO1xuICAgIH1cbiAgICBpZiAoYWRTbG90Q29uZmlnLnJlZnJlc2ggPT09IGZhbHNlKSB7XG4gICAgICAgIGRhdGFBdHRyaWJ1dGVzLnJlZnJlc2ggPSAnZmFsc2UnO1xuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlQWRTbG90RWxlbWVudChzbG90TmFtZSwgZGF0YUF0dHJpYnV0ZXMsIGNyZWF0ZUNsYXNzZXMoc2xvdE5hbWUsIG9wdGlvbnMuY2xhc3NlcykpO1xufTtcbmV4cG9ydCB7IGFkU2xvdENvbnRhaW5lckNsYXNzLCBjb25jYXRTaXplTWFwcGluZ3MsIGNyZWF0ZUFkU2xvdCwgd3JhcFNsb3RJbkNvbnRhaW5lciwgfTtcbiIsImltcG9ydCB7IGRmcEVudiB9IGZyb20gJy4vZGZwLWVudic7XG5jb25zdCBnZXRBZHZlcnRCeUlkID0gKGlkKSA9PiBkZnBFbnYuYWR2ZXJ0cy5nZXQoaWQpID8/IG51bGw7XG5leHBvcnQgeyBnZXRBZHZlcnRCeUlkIH07XG4iLCJpbXBvcnQgeyBkZnBFbnYgfSBmcm9tICcuL2RmcC1lbnYnO1xuZXhwb3J0IGNvbnN0IHF1ZXVlQWR2ZXJ0ID0gKGFkdmVydCkgPT4ge1xuICAgIGRmcEVudi5hZHZlcnRzVG9Mb2FkLnB1c2goYWR2ZXJ0KTtcbn07XG4iLCJpbXBvcnQgeyBmbGF0dGVuIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IHJlcG9ydEVycm9yIH0gZnJvbSAnLi4vLi4vZXJyb3IvcmVwb3J0LWVycm9yJztcbmltcG9ydCB7IGdldEhlYWRlckJpZGRpbmdBZFNsb3RzIH0gZnJvbSAnLi4vc2xvdC1jb25maWcnO1xuLypcbiAqIEFtYXpvbidzIGhlYWRlciBiaWRkaW5nIGphdmFzY3JpcHQgbGlicmFyeVxuICogaHR0cHM6Ly9hbXMuYW1hem9uLmNvbS93ZWJwdWJsaXNoZXIvdWFtL2RvY3Mvd2ViLWludGVncmF0aW9uLWRvY3VtZW50YXRpb24vaW50ZWdyYXRpb24tZ3VpZGUvamF2YXNjcmlwdC1ndWlkZS9kaXNwbGF5Lmh0bWxcbiAqL1xuY2xhc3MgQTlBZFVuaXQge1xuICAgIHNsb3RJRDtcbiAgICBzbG90TmFtZTtcbiAgICBzaXplcztcbiAgICBjb25zdHJ1Y3RvcihhZHZlcnQsIHNsb3QpIHtcbiAgICAgICAgdGhpcy5zbG90SUQgPSBhZHZlcnQuaWQ7XG4gICAgICAgIHRoaXMuc2xvdE5hbWUgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuYWRVbml0O1xuICAgICAgICB0aGlzLnNpemVzID0gc2xvdC5zaXplcy5tYXAoKHNpemUpID0+IEFycmF5LmZyb20oc2l6ZSkpO1xuICAgIH1cbn1cbmxldCBpbml0aWFsaXNlZCA9IGZhbHNlO1xubGV0IHJlcXVlc3RRdWV1ZSA9IFByb21pc2UucmVzb2x2ZSgpO1xuY29uc3QgYmlkZGVyVGltZW91dCA9IDE1MDA7XG5jb25zdCBpbml0aWFsaXNlID0gKCkgPT4ge1xuICAgIGlmICghaW5pdGlhbGlzZWQgJiYgd2luZG93LmFwc3RhZykge1xuICAgICAgICBpbml0aWFsaXNlZCA9IHRydWU7XG4gICAgICAgIGNvbnN0IGJsb2NrZWRCaWRkZXJzID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzRnJvbnRcbiAgICAgICAgICAgID8gW1xuICAgICAgICAgICAgICAgICcxbHN4amI0JywgLy8gR3VtR3VtLCBhcyB0aGV5IGhhdmUgYmVlbiBzaG93aW5nIHdvbmt5IGZvcm1hdHMgb24gZnJvbnRzXG4gICAgICAgICAgICBdXG4gICAgICAgICAgICA6IFtdO1xuICAgICAgICB3aW5kb3cuYXBzdGFnLmluaXQoe1xuICAgICAgICAgICAgcHViSUQ6IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5hOVB1Ymxpc2hlcklkLFxuICAgICAgICAgICAgYWRTZXJ2ZXI6ICdnb29nbGV0YWcnLFxuICAgICAgICAgICAgYmlkVGltZW91dDogYmlkZGVyVGltZW91dCxcbiAgICAgICAgICAgIGJsb2NrZWRCaWRkZXJzLFxuICAgICAgICB9KTtcbiAgICB9XG59O1xuY29uc3QgbG9nQTlCaWRSZXNwb25zZSA9IChiaWRSZXNwb25zZSkgPT4ge1xuICAgIHdpbmRvdy5ndWFyZGlhbi5jb21tZXJjaWFsID8/PSB7fTtcbiAgICB3aW5kb3cuZ3VhcmRpYW4uY29tbWVyY2lhbC5hOVdpbm5pbmdCaWRzID8/PSBbXTtcbiAgICB3aW5kb3cuZ3VhcmRpYW4uY29tbWVyY2lhbC5hOVdpbm5pbmdCaWRzLnB1c2goLi4uYmlkUmVzcG9uc2UpO1xufTtcbi8vIHNsb3RGbGF0TWFwIGFsbG93cyB5b3UgdG8gZHluYW1pY2FsbHkgaW50ZXJmZXJlIHdpdGggdGhlIFByZWJpZFNsb3QgZGVmaW5pdGlvblxuLy8gZm9yIHRoaXMgZ2l2ZW4gcmVxdWVzdCBmb3IgYmlkcy5cbmNvbnN0IHJlcXVlc3RCaWRzID0gYXN5bmMgKGFkdmVydHMsIHNsb3RGbGF0TWFwKSA9PiB7XG4gICAgaWYgKCFpbml0aWFsaXNlZCkge1xuICAgICAgICByZXR1cm4gcmVxdWVzdFF1ZXVlO1xuICAgIH1cbiAgICBpZiAoIXdpbmRvdy5ndWFyZGlhbi5jb25maWcuc3dpdGNoZXMuYTlIZWFkZXJCaWRkaW5nKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0UXVldWU7XG4gICAgfVxuICAgIGNvbnN0IGFkVW5pdHMgPSBmbGF0dGVuKGFkdmVydHMubWFwKChhZHZlcnQpID0+IGdldEhlYWRlckJpZGRpbmdBZFNsb3RzKGFkdmVydCwgc2xvdEZsYXRNYXApLm1hcCgoc2xvdCkgPT4gbmV3IEE5QWRVbml0KGFkdmVydCwgc2xvdCkpKSk7XG4gICAgaWYgKGFkVW5pdHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0UXVldWU7XG4gICAgfVxuICAgIHJlcXVlc3RRdWV1ZSA9IHJlcXVlc3RRdWV1ZVxuICAgICAgICAudGhlbigoKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSkgPT4ge1xuICAgICAgICB3aW5kb3cuYXBzdGFnPy5mZXRjaEJpZHMoeyBzbG90czogYWRVbml0cyB9LCAoYmlkUmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIGxvZ0E5QmlkUmVzcG9uc2UoYmlkUmVzcG9uc2UpO1xuICAgICAgICAgICAgd2luZG93Lmdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgd2luZG93LmFwc3RhZz8uc2V0RGlzcGxheUJpZHMoKTtcbiAgICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfSkpXG4gICAgICAgIC5jYXRjaCgoKSA9PiB7XG4gICAgICAgIHJlcG9ydEVycm9yKG5ldyBFcnJvcignYTkgaGVhZGVyIGJpZGRpbmcgZXJyb3InKSwgJ2NvbW1lcmNpYWwnKTtcbiAgICB9KTtcbiAgICByZXR1cm4gcmVxdWVzdFF1ZXVlO1xufTtcbmV4cG9ydCBjb25zdCBhOSA9IHtcbiAgICBpbml0aWFsaXNlLFxuICAgIHJlcXVlc3RCaWRzLFxuICAgIGxvZ0E5QmlkUmVzcG9uc2UsXG59O1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgcmVzZXRNb2R1bGU6ICgpID0+IHtcbiAgICAgICAgaW5pdGlhbGlzZWQgPSBmYWxzZTtcbiAgICAgICAgcmVxdWVzdFF1ZXVlID0gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfSxcbn07XG4iLCJpbXBvcnQgeyBpc0luQXVPck56LCBpc0luUm93IH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9nZW8vZ2VvLXV0aWxzJztcbmltcG9ydCB7IGJ1aWxkQXBwTmV4dXNUYXJnZXRpbmdPYmplY3QgfSBmcm9tICcuLi8uLi9wYWdlLXRhcmdldGluZyc7XG5pbXBvcnQgeyBjb250YWluc0JpbGxib2FyZE5vdExlYWRlcmJvYXJkLCBjb250YWluc0xlYWRlcmJvYXJkLCBjb250YWluc0xlYWRlcmJvYXJkT3JCaWxsYm9hcmQsIGNvbnRhaW5zTW9iaWxlU3RpY2t5LCBjb250YWluc01wdSwgY29udGFpbnNNcHVPckRtcHUsIGdldEJyZWFrcG9pbnRLZXksIGdldExhcmdlc3RTaXplLCB9IGZyb20gJy4uL3V0aWxzJztcbmNvbnN0IGdldEFwcE5leHVzSW52Q29kZSA9IChzaXplcykgPT4ge1xuICAgIGNvbnN0IGRldmljZSA9IGdldEJyZWFrcG9pbnRLZXkoKSA9PT0gJ00nID8gJ00nIDogJ0QnO1xuICAgIC8vIHNlY3Rpb24gaXMgb3B0aW9uYWwgYW5kIG1ha2VzIGl0IHRocm91Z2ggdG8gdGhlIGNvbmZpZyBvYmplY3QgYXMgYW4gZW1wdHkgc3RyaW5nLi4uIE9UTFxuICAgIGNvbnN0IHNlY3Rpb25OYW1lID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNlY3Rpb24gfHxcbiAgICAgICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNlY3Rpb25OYW1lLnJlcGxhY2UoLyAvZywgJy0nKTtcbiAgICBjb25zdCBzbG90U2l6ZSA9IGdldExhcmdlc3RTaXplKHNpemVzKTtcbiAgICBpZiAoc2xvdFNpemUpIHtcbiAgICAgICAgcmV0dXJuIGAke2RldmljZX0ke3NlY3Rpb25OYW1lLnRvTG93ZXJDYXNlKCl9JHtzbG90U2l6ZS5qb2luKCd4Jyl9YDtcbiAgICB9XG59O1xuZXhwb3J0IGNvbnN0IGdldEFwcE5leHVzRGlyZWN0UGxhY2VtZW50SWQgPSAoc2l6ZXMpID0+IHtcbiAgICBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgIHJldHVybiAnMTEwMTY0MzQnO1xuICAgIH1cbiAgICBpZiAoaXNJblJvdygpICYmIGNvbnRhaW5zTW9iaWxlU3RpY2t5KHNpemVzKSkge1xuICAgICAgICByZXR1cm4gJzMxNTEyNTczJztcbiAgICB9XG4gICAgY29uc3QgZGVmYXVsdFBsYWNlbWVudElkID0gJzkyNTE3NTInO1xuICAgIHN3aXRjaCAoZ2V0QnJlYWtwb2ludEtleSgpKSB7XG4gICAgICAgIGNhc2UgJ0QnOlxuICAgICAgICAgICAgLy8gVGhlIG9ubHkgcHJlYmlkIGNvbXBhdGlibGUgc2l6ZSBmb3IgZnJvbnRzLWJhbm5lci1hZHMgYW5kIHRoZSBtZXJjaGFuZGlzaW5nLWhpZ2ggaXMgdGhlIGJpbGxib2FyZCAoOTcweDI1MClcbiAgICAgICAgICAgIC8vIFRoaXMgY2hlY2sgaXMgdG8gZGlzdGluZ3Vpc2ggZnJvbSB0aGUgdG9wLWFib3ZlLW5hdiB3aGljaCBpbmNsdWRlcyBhIGxlYWRlcmJvYXJkXG4gICAgICAgICAgICBpZiAoY29udGFpbnNCaWxsYm9hcmROb3RMZWFkZXJib2FyZChzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJzMwMDE3NTExJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjb250YWluc01wdU9yRG1wdShzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJzkyNTE3NTInO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTGVhZGVyYm9hcmRPckJpbGxib2FyZChzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJzk5MjY2NzgnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRQbGFjZW1lbnRJZDtcbiAgICAgICAgY2FzZSAnTSc6XG4gICAgICAgICAgICBpZiAoY29udGFpbnNNcHUoc2l6ZXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICc0Mjk4MTkxJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0UGxhY2VtZW50SWQ7XG4gICAgICAgIGNhc2UgJ1QnOlxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTXB1KHNpemVzKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAnNDM3MTY0MSc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoY29udGFpbnNMZWFkZXJib2FyZChzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJzQzNzE2NDAnO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGRlZmF1bHRQbGFjZW1lbnRJZDtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJldHVybiBkZWZhdWx0UGxhY2VtZW50SWQ7XG4gICAgfVxufTtcbmV4cG9ydCBjb25zdCBnZXRBcHBOZXh1c0RpcmVjdEJpZFBhcmFtcyA9IChzaXplcywgcGFnZVRhcmdldGluZywgc2xvdElkKSA9PiB7XG4gICAgaWYgKGlzSW5BdU9yTnooKSAmJiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLnByZWJpZEFwcG5leHVzSW52Y29kZSkge1xuICAgICAgICBjb25zdCBpbnZDb2RlID0gZ2V0QXBwTmV4dXNJbnZDb2RlKHNpemVzKTtcbiAgICAgICAgaWYgKGludkNvZGUpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgaW52Q29kZSxcbiAgICAgICAgICAgICAgICBtZW1iZXI6ICc3MDEyJyxcbiAgICAgICAgICAgICAgICBrZXl3b3Jkczoge1xuICAgICAgICAgICAgICAgICAgICBpbnZjOiBbaW52Q29kZV0sXG4gICAgICAgICAgICAgICAgICAgIC4uLmJ1aWxkQXBwTmV4dXNUYXJnZXRpbmdPYmplY3QocGFnZVRhcmdldGluZyksXG4gICAgICAgICAgICAgICAgICAgIHNsb3Q6IHNsb3RJZCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBwbGFjZW1lbnRJZDogZ2V0QXBwTmV4dXNEaXJlY3RQbGFjZW1lbnRJZChzaXplcyksXG4gICAgICAgIGtleXdvcmRzOiB7XG4gICAgICAgICAgICAuLi5idWlsZEFwcE5leHVzVGFyZ2V0aW5nT2JqZWN0KHBhZ2VUYXJnZXRpbmcpLFxuICAgICAgICAgICAgc2xvdDogc2xvdElkLFxuICAgICAgICB9LFxuICAgIH07XG59O1xuZXhwb3J0IGNvbnN0IF8gPSB7IGdldEFwcE5leHVzRGlyZWN0UGxhY2VtZW50SWQgfTtcbiIsImltcG9ydCB7IGlzSW5BdU9yTnosIGlzSW5Sb3csIGlzSW5Vc2EsIGlzSW5Vc09yQ2EsIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9nZW8vZ2VvLXV0aWxzJztcbmltcG9ydCB7IGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGRmcEVudiB9IGZyb20gJy4uLy4uL2RmcC9kZnAtZW52JztcbmltcG9ydCB7IGJ1aWxkQXBwTmV4dXNUYXJnZXRpbmdPYmplY3QgfSBmcm9tICcuLi8uLi9wYWdlLXRhcmdldGluZyc7XG5pbXBvcnQgeyBwYlRlc3ROYW1lTWFwIH0gZnJvbSAnLi4vLi4vdXJsJztcbmltcG9ydCB7IGNvbnRhaW5zQmlsbGJvYXJkLCBjb250YWluc0JpbGxib2FyZE5vdExlYWRlcmJvYXJkLCBjb250YWluc0RtcHUsIGNvbnRhaW5zTGVhZGVyYm9hcmQsIGNvbnRhaW5zTGVhZGVyYm9hcmRPckJpbGxib2FyZCwgY29udGFpbnNNb2JpbGVTdGlja3ksIGNvbnRhaW5zTXB1LCBjb250YWluc01wdU9yRG1wdSwgZ2V0QnJlYWtwb2ludEtleSwgc2hvdWxkSW5jbHVkZUJpZGRlciwgc3RyaXBEZnBBZFByZWZpeEZyb20sIHN0cmlwTW9iaWxlU3VmZml4LCB9IGZyb20gJy4uL3V0aWxzJztcbmltcG9ydCB7IGdldEFwcE5leHVzRGlyZWN0QmlkUGFyYW1zIH0gZnJvbSAnLi9hcHBuZXh1cyc7XG5pbXBvcnQgeyBnZXRNYWduaXRlU2l0ZUlkLCBnZXRNYWduaXRlWm9uZUlkIH0gZnJvbSAnLi9tYWduaXRlJztcbmNvbnN0IGlzQXJ0aWNsZSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5jb250ZW50VHlwZSA9PT0gJ0FydGljbGUnO1xuY29uc3QgaXNEZXNrdG9wQW5kQXJ0aWNsZSA9IGdldEJyZWFrcG9pbnRLZXkoKSA9PT0gJ0QnICYmIGlzQXJ0aWNsZTtcbmNvbnN0IGdldFRydXN0WEFkVW5pdElkID0gKHNsb3RJZCwgaXNEZXNrdG9wQXJ0aWNsZSkgPT4ge1xuICAgIHN3aXRjaCAoc3RyaXBNb2JpbGVTdWZmaXgoc2xvdElkKSkge1xuICAgICAgICBjYXNlICdkZnAtYWQtLWlubGluZTEnOlxuICAgICAgICAgICAgcmV0dXJuICcyOTYwJztcbiAgICAgICAgY2FzZSAnZGZwLWFkLS1pbmxpbmUyJzpcbiAgICAgICAgICAgIGlmIChpc0Rlc2t0b3BBcnRpY2xlKVxuICAgICAgICAgICAgICAgIHJldHVybiAnMzgyNic7XG4gICAgICAgICAgICByZXR1cm4gJzM4MjcnO1xuICAgICAgICBjYXNlICdkZnAtYWQtLWlubGluZTMnOlxuICAgICAgICAgICAgaWYgKGlzRGVza3RvcEFydGljbGUpXG4gICAgICAgICAgICAgICAgcmV0dXJuICczODI4JztcbiAgICAgICAgICAgIHJldHVybiAnMzgyOSc7XG4gICAgICAgIGNhc2UgJ2RmcC1hZC0taW5saW5lNCc6XG4gICAgICAgICAgICBpZiAoaXNEZXNrdG9wQXJ0aWNsZSlcbiAgICAgICAgICAgICAgICByZXR1cm4gJzM4MzAnO1xuICAgICAgICAgICAgcmV0dXJuICczODMxJztcbiAgICAgICAgY2FzZSAnZGZwLWFkLS1pbmxpbmU1JzpcbiAgICAgICAgICAgIGlmIChpc0Rlc2t0b3BBcnRpY2xlKVxuICAgICAgICAgICAgICAgIHJldHVybiAnMzgzMic7XG4gICAgICAgICAgICByZXR1cm4gJzM4MzMnO1xuICAgICAgICBjYXNlICdkZnAtYWQtLWlubGluZTYnOlxuICAgICAgICAgICAgaWYgKGlzRGVza3RvcEFydGljbGUpXG4gICAgICAgICAgICAgICAgcmV0dXJuICczODM0JztcbiAgICAgICAgICAgIHJldHVybiAnMzgzNSc7XG4gICAgICAgIGNhc2UgJ2RmcC1hZC0taW5saW5lNyc6XG4gICAgICAgICAgICBpZiAoaXNEZXNrdG9wQXJ0aWNsZSlcbiAgICAgICAgICAgICAgICByZXR1cm4gJzM4MzYnO1xuICAgICAgICAgICAgcmV0dXJuICczODM3JztcbiAgICAgICAgY2FzZSAnZGZwLWFkLS1pbmxpbmU4JzpcbiAgICAgICAgICAgIGlmIChpc0Rlc2t0b3BBcnRpY2xlKVxuICAgICAgICAgICAgICAgIHJldHVybiAnMzgzOCc7XG4gICAgICAgICAgICByZXR1cm4gJzM4MzknO1xuICAgICAgICBjYXNlICdkZnAtYWQtLWlubGluZTknOlxuICAgICAgICAgICAgaWYgKGlzRGVza3RvcEFydGljbGUpXG4gICAgICAgICAgICAgICAgcmV0dXJuICczODQwJztcbiAgICAgICAgICAgIHJldHVybiAnMzg0MSc7XG4gICAgICAgIGNhc2UgJ2RmcC1hZC0tbW9zdHBvcCc6XG4gICAgICAgICAgICByZXR1cm4gJzI5NjEnO1xuICAgICAgICBjYXNlICdkZnAtYWQtLXJpZ2h0JzpcbiAgICAgICAgICAgIHJldHVybiAnMjk2Mic7XG4gICAgICAgIGNhc2UgJ2RmcC1hZC0tdG9wLWFib3ZlLW5hdic6XG4gICAgICAgICAgICByZXR1cm4gJzI5NjMnO1xuICAgICAgICBjYXNlICdkZnAtYWQtLWNvbW1lbnRzJzpcbiAgICAgICAgICAgIHJldHVybiAnMzg0MCc7XG4gICAgICAgIGNhc2UgJ2RmcC1hZC0tbW9iaWxlLXN0aWNreSc6XG4gICAgICAgICAgICByZXR1cm4gJzg1MTknO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgLy8gZm9yIGlubGluZTEwIGFuZCBvbndhcmRzIGp1c3QgdXNlIHNhbWUgSURzIGFzIGlubGluZTlcbiAgICAgICAgICAgIGlmIChzbG90SWQuc3RhcnRzV2l0aCgnZGZwLWFkLS1pbmxpbmUnKSkge1xuICAgICAgICAgICAgICAgIGlmIChpc0Rlc2t0b3BBcnRpY2xlKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gJzM4NDAnO1xuICAgICAgICAgICAgICAgIHJldHVybiAnMzg0MSc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBgUFJFQklEOiBGYWlsZWQgdG8gZ2V0IFRydXN0WCBhZCB1bml0IGZvciBzbG90ICR7c2xvdElkfS5gKTtcbiAgICAgICAgICAgIHJldHVybiAnJztcbiAgICB9XG59O1xuLyoqXG4gKiBXZSBzdG9yZSBhIG1hcHBpbmcgb2Ygc2VjdGlvbnMgdG8gSW5kZXggc2l0ZSBpZHMgc2VydmVyLXNpZGUsIHdoZXJlIGVhY2ggaXNcbiAqIHNwbGl0IG91dCBieSBicmVha3BvaW50LiBUaGVzZSBhcmUgdHJhbnNmZXJyZWQgdG8gdGhlIGNsaWVudCB2aWEgdGhlIHdpbmRvdyxcbiAqIGFuZCByZWFkIGhlcmVcbiAqXG4gKiBUaGlzIGFwcGVhcnMgdG8gYmUgYW4gb2xkIG1ldGhvZCBvZiBhc3NpZ25pbmcgc2l0ZSBpZHMsIHdpdGggdGhlIG5ld2VyIG1ldGhvZFxuICogYmVpbmcgdG8gYXNzaWduIHRoZW0gYWNjb3JkaW5nIHRvIGFkIHNpemUgKEBzZWUgZ2V0SW5kZXhTaXRlSWQpXG4gKi9cbmNvbnN0IGdldEluZGV4U2l0ZUlkRnJvbUNvbmZpZyA9ICgpID0+IHtcbiAgICBjb25zdCBzaXRlID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnBiSW5kZXhTaXRlcy5maW5kKChzKSA9PiBzLmJwID09PSBnZXRCcmVha3BvaW50S2V5KCkpO1xuICAgIHJldHVybiBzaXRlPy5pZCA/IHNpdGUuaWQudG9TdHJpbmcoKSA6ICcnO1xufTtcbmNvbnN0IGdldEluZGV4U2l0ZUlkID0gKHNsb3RTaXplcykgPT4ge1xuICAgIC8vIFRoZSBvbmx5IHByZWJpZCBjb21wYXRpYmxlIHNpemUgZm9yIGZyb250cy1iYW5uZXItYWRzIGFuZCB0aGUgbWVyY2hhbmRpc2luZy1oaWdoIGlzIHRoZSBiaWxsYm9hcmQgKDk3MHgyNTApXG4gICAgLy8gVGhpcyBjaGVjayBpcyB0byBkaXN0aW5ndWlzaCBmcm9tIHRoZSB0b3AtYWJvdmUtbmF2IHNsb3QsIHdoaWNoIGluY2x1ZGVzIGEgbGVhZGVyYm9hcmRcbiAgICBpZiAoY29udGFpbnNCaWxsYm9hcmROb3RMZWFkZXJib2FyZChzbG90U2l6ZXMpKSB7XG4gICAgICAgIHJldHVybiAnOTgzODQyJztcbiAgICB9XG4gICAgLy8gUmV0dXJuIGEgc3BlY2lmaWMgc2l0ZSBpZCBmb3IgdGhlIG1vYmlsZSBzdGlja3kgc2xvdFxuICAgIGlmIChjb250YWluc01vYmlsZVN0aWNreShzbG90U2l6ZXMpKSB7XG4gICAgICAgIHJldHVybiAnMTA0Nzg2OSc7XG4gICAgfVxuICAgIC8vIEZhbGwgYmFjayB0byByZWFkaW5nIHRoZSBzaXRlIGlkIGZyb20gdGhlIHdpbmRvd1xuICAgIHJldHVybiBnZXRJbmRleFNpdGVJZEZyb21Db25maWcoKTtcbn07XG5jb25zdCBnZXRYYXhpc1BsYWNlbWVudElkID0gKHNpemVzKSA9PiB7XG4gICAgc3dpdGNoIChnZXRCcmVha3BvaW50S2V5KCkpIHtcbiAgICAgICAgY2FzZSAnRCc6XG4gICAgICAgICAgICBpZiAoY29udGFpbnNNcHVPckRtcHUoc2l6ZXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDIwOTQzNjY1O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTGVhZGVyYm9hcmRPckJpbGxib2FyZChzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gMjA5NDM2NjY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gMjA5NDM2Njg7XG4gICAgICAgIGNhc2UgJ00nOlxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTXB1T3JEbXB1KHNpemVzKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAyMDk0MzY2OTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiAyMDk0MzY3MDtcbiAgICAgICAgY2FzZSAnVCc6XG4gICAgICAgICAgICBpZiAoY29udGFpbnNNcHVPckRtcHUoc2l6ZXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDIwOTQzNjcxO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTGVhZGVyYm9hcmRPckJpbGxib2FyZChzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gMjA5NDM2NzI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gMjA5NDM2NzQ7XG4gICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICByZXR1cm4gLTE7XG4gICAgfVxufTtcbmNvbnN0IGdldFRyaXBsZUxpZnRJbnZlbnRvcnlDb2RlID0gKHNsb3RJZCwgc2l6ZXMpID0+IHtcbiAgICBpZiAoY29udGFpbnNMZWFkZXJib2FyZChzaXplcykpIHtcbiAgICAgICAgaWYgKGlzSW5Vc09yQ2EoKSkge1xuICAgICAgICAgICAgcmV0dXJuICd0aGVndWFyZGlhbl90b3BiYW5uZXJfNzI4eDkwX3ByZWJpZCc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgICAgICByZXR1cm4gJ3RoZWd1YXJkaWFuX3RvcGJhbm5lcl83Mjh4OTBfcHJlYmlkX0FVJztcbiAgICAgICAgfVxuICAgIH1cbiAgICBpZiAoY29udGFpbnNNcHUoc2l6ZXMpKSB7XG4gICAgICAgIGlmIChpc0luVXNPckNhKCkpIHtcbiAgICAgICAgICAgIHJldHVybiBpc0FydGljbGVcbiAgICAgICAgICAgICAgICA/ICd0aGVndWFyZGlhbl9hcnRpY2xlXzMwMHgyNTBfcHJlYmlkJ1xuICAgICAgICAgICAgICAgIDogJ3RoZWd1YXJkaWFuX3NlY3Rpb25mcm9udF8zMDB4MjUwX3ByZWJpZCc7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgICAgICByZXR1cm4gaXNBcnRpY2xlXG4gICAgICAgICAgICAgICAgPyAndGhlZ3VhcmRpYW5fYXJ0aWNsZV8zMDB4MjUwX3ByZWJpZF9BVSdcbiAgICAgICAgICAgICAgICA6ICd0aGVndWFyZGlhbl9zZWN0aW9uZnJvbnRfMzAweDI1MF9wcmViaWRfQVUnO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChjb250YWluc0JpbGxib2FyZChzaXplcykpIHtcbiAgICAgICAgaWYgKGlzSW5Vc09yQ2EoKSkge1xuICAgICAgICAgICAgcmV0dXJuICd0aGVndWFyZGlhbl9hcnRpY2xlXzk3MHgyNTBfcHJlYmlkJztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChpc0luQXVPck56KCkpIHtcbiAgICAgICAgICAgIHJldHVybiAndGhlZ3VhcmRpYW5fYXJ0aWNsZV85NzB4MjUwX3ByZWJpZF9BVSc7XG4gICAgICAgIH1cbiAgICB9XG4gICAgaWYgKGNvbnRhaW5zTW9iaWxlU3RpY2t5KHNpemVzKSkge1xuICAgICAgICBpZiAoaXNJblVzT3JDYSgpKSB7XG4gICAgICAgICAgICByZXR1cm4gJ3RoZWd1YXJkaWFuXzMyMHg1MF9IRFgnO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzSW5BdU9yTnooKSkge1xuICAgICAgICAgICAgcmV0dXJuICd0aGVndWFyZGlhbl8zMjB4NTBfSERYX0FVJztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gJyc7XG59O1xuLy8gSXMgcGJ0ZXN0IGJlaW5nIHVzZWQ/XG5jb25zdCBpc1BiVGVzdE9uID0gKCkgPT4gT2JqZWN0LmtleXMocGJUZXN0TmFtZU1hcCgpKS5sZW5ndGggPiAwO1xuLy8gSGVscGVyIGZvciBjb25kaXRpb25zXG5jb25zdCBpblBiVGVzdE9yID0gKGxpdmVDbGF1c2UpID0+IGlzUGJUZXN0T24oKSB8fCBsaXZlQ2xhdXNlO1xuLyogQmlkZGVycyAqL1xuY29uc3QgYXBwTmV4dXNCaWRkZXIgPSAocGFnZVRhcmdldGluZykgPT4gKHtcbiAgICBuYW1lOiAnYW5kJyxcbiAgICBzd2l0Y2hOYW1lOiAncHJlYmlkQXBwbmV4dXMnLFxuICAgIGJpZFBhcmFtczogKHNsb3RJZCwgc2l6ZXMpID0+IGdldEFwcE5leHVzRGlyZWN0QmlkUGFyYW1zKHNpemVzLCBwYWdlVGFyZ2V0aW5nLCBzdHJpcERmcEFkUHJlZml4RnJvbShzbG90SWQpKSxcbn0pO1xuY29uc3Qgb3BlbnhCaWRkZXIgPSAocGFnZVRhcmdldGluZykgPT4gKHtcbiAgICBuYW1lOiAnb3hkJyxcbiAgICBzd2l0Y2hOYW1lOiAncHJlYmlkT3BlbngnLFxuICAgIGJpZFBhcmFtczogKHNsb3RJZCwgc2l6ZXMpID0+IHtcbiAgICAgICAgY29uc3QgY3VzdG9tUGFyYW1zID0gYnVpbGRBcHBOZXh1c1RhcmdldGluZ09iamVjdChwYWdlVGFyZ2V0aW5nKTtcbiAgICAgICAgaWYgKGlzSW5Vc09yQ2EoKSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICBkZWxEb21haW46ICdndWFyZGlhbi11cy1kLm9wZW54Lm5ldCcsXG4gICAgICAgICAgICAgICAgdW5pdDogJzU0MDI3OTU0NCcsXG4gICAgICAgICAgICAgICAgY3VzdG9tUGFyYW1zLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgIGRlbERvbWFpbjogJ2d1YXJkaWFuLWF1cy1kLm9wZW54Lm5ldCcsXG4gICAgICAgICAgICAgICAgdW5pdDogJzU0MDI3OTU0MicsXG4gICAgICAgICAgICAgICAgY3VzdG9tUGFyYW1zLFxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICAvLyBST1cgaGFzIGEgdW5pcXVlIHVuaXQgSUQgZm9yIG1vYmlsZS1zdGlja3lcbiAgICAgICAgaWYgKGlzSW5Sb3coKSAmJiBjb250YWluc01vYmlsZVN0aWNreShzaXplcykpIHtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgZGVsRG9tYWluOiAnZ3VhcmRpYW4tZC5vcGVueC5uZXQnLFxuICAgICAgICAgICAgICAgIHVuaXQ6ICc1NjA0MjkzODQnLFxuICAgICAgICAgICAgICAgIGN1c3RvbVBhcmFtcyxcbiAgICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgICAgLy8gVUsgYW5kIFJPV1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgZGVsRG9tYWluOiAnZ3VhcmRpYW4tZC5vcGVueC5uZXQnLFxuICAgICAgICAgICAgdW5pdDogJzU0MDI3OTU0MScsXG4gICAgICAgICAgICBjdXN0b21QYXJhbXMsXG4gICAgICAgIH07XG4gICAgfSxcbn0pO1xuY29uc3QgZ2V0T3pvbmVQbGFjZW1lbnRJZCA9IChzaXplcykgPT4ge1xuICAgIGlmIChpc0luVXNhKCkpIHtcbiAgICAgICAgaWYgKGdldEJyZWFrcG9pbnRLZXkoKSA9PT0gJ0QnKSB7XG4gICAgICAgICAgICBpZiAoY29udGFpbnNCaWxsYm9hcmQoc2l6ZXMpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuICczNTAwMDEwOTEyJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChjb250YWluc01wdShzaXplcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gJzM1MDAwMTA5MTEnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChnZXRCcmVha3BvaW50S2V5KCkgPT09ICdNJykge1xuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTW9iaWxlU3RpY2t5KHNpemVzKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiAnMzUwMDAxNDIxNyc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICcxNDIwNDM2MzA4JztcbiAgICB9XG4gICAgaWYgKGlzSW5Sb3coKSkge1xuICAgICAgICBpZiAoY29udGFpbnNNb2JpbGVTdGlja3koc2l6ZXMpKSB7XG4gICAgICAgICAgICByZXR1cm4gJzE1MDAwMDAyNjAnO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiAnMDQyMDQyMDUwMCc7XG59O1xuY29uc3Qgb3pvbmVCaWRkZXIgPSAocGFnZVRhcmdldGluZykgPT4gKHtcbiAgICBuYW1lOiAnb3pvbmUnLFxuICAgIHN3aXRjaE5hbWU6ICdwcmViaWRPem9uZScsXG4gICAgYmlkUGFyYW1zOiAoX3Nsb3RJZCwgc2l6ZXMpID0+IHtcbiAgICAgICAgY29uc3QgYWR2ZXJ0ID0gZGZwRW52LmFkdmVydHMuZ2V0KF9zbG90SWQpO1xuICAgICAgICBjb25zdCB0ZXN0Z3JvdXAgPSBhZHZlcnQ/LnRlc3Rncm91cFxuICAgICAgICAgICAgPyB7IHRlc3Rncm91cDogYWR2ZXJ0LnRlc3Rncm91cCB9XG4gICAgICAgICAgICA6IHt9O1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgcHVibGlzaGVySWQ6ICdPWk9ORUdNRzAwMDEnLFxuICAgICAgICAgICAgc2l0ZUlkOiAnNDIwNDIwNDIwOScsXG4gICAgICAgICAgICBwbGFjZW1lbnRJZDogZ2V0T3pvbmVQbGFjZW1lbnRJZChzaXplcyksXG4gICAgICAgICAgICBjdXN0b21EYXRhOiBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBzZXR0aW5nczoge30sXG4gICAgICAgICAgICAgICAgICAgIHRhcmdldGluZzoge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQXNzaWducyBhIHJhbmRvbSBpbnRlZ2VyIGJldHdlZW4gMCBhbmQgOTlcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLnRlc3Rncm91cCxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLmJ1aWxkQXBwTmV4dXNUYXJnZXRpbmdPYmplY3QocGFnZVRhcmdldGluZyksXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBvem9uZURhdGE6IHt9LCAvLyBUT0RPOiBjb25maXJtIGlmIHdlIG5lZWQgdG8gc2VuZCBhbnlcbiAgICAgICAgfTtcbiAgICB9LFxufSk7XG5jb25zdCBnZXRQdWJtYXRpY1B1Ymxpc2hlcklkID0gKCkgPT4ge1xuICAgIGlmIChpc0luVXNPckNhKCkpIHtcbiAgICAgICAgcmV0dXJuICcxNTcyMDYnO1xuICAgIH1cbiAgICBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgIHJldHVybiAnMTU3MjAzJztcbiAgICB9XG4gICAgcmV0dXJuICcxNTcyMDcnO1xufTtcbmNvbnN0IGdldEthcmdvUGxhY2VtZW50SWQgPSAoc2l6ZXMpID0+IHtcbiAgICBpZiAoZ2V0QnJlYWtwb2ludEtleSgpID09PSAnRCcpIHtcbiAgICAgICAgLy8gdG9wLWFib3ZlLW5hdiBvbiBkZXNrdG9wLCBmcm9udHMtYmFubmVycyBpbiB0aGUgZnV0dXJlXG4gICAgICAgIGlmIChjb250YWluc0xlYWRlcmJvYXJkT3JCaWxsYm9hcmQoc2l6ZXMpKSB7XG4gICAgICAgICAgICByZXR1cm4gJ195ZmxnOVM3YzJ4JztcbiAgICAgICAgfVxuICAgICAgICAvLyByaWdodCBoYW5kIHNsb3RzIG9uIGRlc2t0b3AsIGFrYSByaWdodCwgaW5saW5lMisgb3IgbW9zdHBvcFxuICAgICAgICBpZiAoY29udGFpbnNNcHUoc2l6ZXMpICYmIGNvbnRhaW5zRG1wdShzaXplcykpIHtcbiAgICAgICAgICAgIHJldHVybiAnX3pPcGVFQXlmaXonO1xuICAgICAgICB9XG4gICAgICAgIC8vIG90aGVyIE1QVXMgb24gZGVza3RvcCAoaW5saW5lMSlcbiAgICAgICAgcmV0dXJuICdfcURCYkJYWXR6QSc7XG4gICAgfVxuICAgIC8vIG1vYmlsZS1zdGlja3kgb24gbW9iaWxlXG4gICAgaWYgKGNvbnRhaW5zTW9iaWxlU3RpY2t5KHNpemVzKSkge1xuICAgICAgICByZXR1cm4gJ19vZHN6UExuMmhLJztcbiAgICB9XG4gICAgLy8gTVBVcyBvbiBtb2JpbGUgYWthIHRvcC1hYm92ZS1uYXYsIGlubGluZSBvbiBtb2JpbGUgYW5kIHRhYmxldFxuICAgIHJldHVybiAnX3k5TElORXNiZmgnO1xufTtcbmNvbnN0IGdldFB1Ym1hdGljUGxhY2VtZW50SWQgPSAoc2xvdElkLCBzbG90U2l6ZXMpID0+IHtcbiAgICBpZiAoc2xvdElkID09PSAnZGZwLWFkLS1pbmxpbmUyJyAmJlxuICAgICAgICBzbG90U2l6ZXMuZmluZCgoc2l6ZSkgPT4gc2l6ZS53aWR0aCA9PT0gMzcxICYmIHNpemUuaGVpZ2h0ID09PSA2NjApKSB7XG4gICAgICAgIHJldHVybiBpc0luVXNhKClcbiAgICAgICAgICAgID8gJ3NlZW50aGlzX2d1YXJkaWFuX213ZWJfdXMnXG4gICAgICAgICAgICA6ICdzZWVudGhpc19ndWFyZGlhbl8zNzF4NjYwX213ZWInO1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbmNvbnN0IHB1Ym1hdGljQmlkZGVyID0gKHNsb3RTaXplcykgPT4ge1xuICAgIGNvbnN0IGRlZmF1bHRQYXJhbXMgPSB7XG4gICAgICAgIG5hbWU6ICdwdWJtYXRpYycsXG4gICAgICAgIHN3aXRjaE5hbWU6ICdwcmViaWRQdWJtYXRpYycsXG4gICAgICAgIGJpZFBhcmFtczogKHNsb3RJZCkgPT4gKHtcbiAgICAgICAgICAgIHB1Ymxpc2hlcklkOiBnZXRQdWJtYXRpY1B1Ymxpc2hlcklkKCksXG4gICAgICAgICAgICBhZFNsb3Q6IHN0cmlwRGZwQWRQcmVmaXhGcm9tKHNsb3RJZCksXG4gICAgICAgICAgICBwbGFjZW1lbnRJZDogZ2V0UHVibWF0aWNQbGFjZW1lbnRJZChzbG90SWQsIHNsb3RTaXplcyksXG4gICAgICAgIH0pLFxuICAgIH07XG4gICAgLy8gVGhlIG9ubHkgcHJlYmlkIGNvbXBhdGlibGUgc2l6ZSBmb3IgZnJvbnRzLWJhbm5lci1hZHMgYW5kIHRoZSBtZXJjaGFuZGlzaW5nLWhpZ2ggaXMgdGhlIGJpbGxib2FyZCAoOTcweDI1MClcbiAgICAvLyBUaGlzIGNoZWNrIGlzIHRvIGRpc3Rpbmd1aXNoIGZyb20gdGhlIHRvcC1hYm92ZS1uYXYgd2hpY2gsIGluY2x1ZGVzIGEgbGVhZGVyYm9hcmRcbiAgICBpZiAoY29udGFpbnNCaWxsYm9hcmROb3RMZWFkZXJib2FyZChzbG90U2l6ZXMpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAuLi5kZWZhdWx0UGFyYW1zLFxuICAgICAgICAgICAgYmlkUGFyYW1zOiAoc2xvdElkKSA9PiAoe1xuICAgICAgICAgICAgICAgIC4uLmRlZmF1bHRQYXJhbXMuYmlkUGFyYW1zKHNsb3RJZCksXG4gICAgICAgICAgICAgICAgcGxhY2VtZW50SWQ6ICd0aGVndWFyZGlhbl85NzB4MjUwX29ubHknLFxuICAgICAgICAgICAgfSksXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiBkZWZhdWx0UGFyYW1zO1xufTtcbmNvbnN0IHRydXN0WEJpZGRlciA9IHtcbiAgICBuYW1lOiAndHJ1c3R4JyxcbiAgICBzd2l0Y2hOYW1lOiAncHJlYmlkVHJ1c3R4JyxcbiAgICBiaWRQYXJhbXM6IChzbG90SWQpID0+ICh7XG4gICAgICAgIHVpZDogZ2V0VHJ1c3RYQWRVbml0SWQoc2xvdElkLCBpc0Rlc2t0b3BBbmRBcnRpY2xlKSxcbiAgICB9KSxcbn07XG5jb25zdCB0cmlwbGVMaWZ0QmlkZGVyID0ge1xuICAgIG5hbWU6ICd0cmlwbGVsaWZ0JyxcbiAgICBzd2l0Y2hOYW1lOiAncHJlYmlkVHJpcGxlbGlmdCcsXG4gICAgYmlkUGFyYW1zOiAoc2xvdElkLCBzaXplcykgPT4gKHtcbiAgICAgICAgaW52ZW50b3J5Q29kZTogZ2V0VHJpcGxlTGlmdEludmVudG9yeUNvZGUoc2xvdElkLCBzaXplcyksXG4gICAgICAgIHRhZ2lkOiBnZXRUcmlwbGVMaWZ0SW52ZW50b3J5Q29kZShzbG90SWQsIHNpemVzKSxcbiAgICB9KSxcbn07XG5jb25zdCB4YXhpc0JpZGRlciA9IHtcbiAgICBuYW1lOiAneGhiJyxcbiAgICBzd2l0Y2hOYW1lOiAncHJlYmlkWGF4aXMnLFxuICAgIGJpZFBhcmFtczogKHNsb3RJZCwgc2l6ZXMpID0+ICh7XG4gICAgICAgIHBsYWNlbWVudElkOiBnZXRYYXhpc1BsYWNlbWVudElkKHNpemVzKSxcbiAgICB9KSxcbn07XG5jb25zdCBjcml0ZW9CaWRkZXIgPSAoc2xvdFNpemVzKSA9PiB7XG4gICAgY29uc3QgZGVmYXVsdFBhcmFtcyA9IHtcbiAgICAgICAgbmFtZTogJ2NyaXRlbycsXG4gICAgICAgIHN3aXRjaE5hbWU6ICdwcmViaWRDcml0ZW8nLFxuICAgIH07XG4gICAgLy8gVGhlIG9ubHkgcHJlYmlkIGNvbXBhdGlibGUgc2l6ZSBmb3IgZnJvbnRzLWJhbm5lci1hZHMgYW5kIHRoZSBtZXJjaGFuZGlzaW5nLWhpZ2ggaXMgdGhlIGJpbGxib2FyZCAoOTcweDI1MClcbiAgICAvLyBUaGlzIGNoZWNrIGlzIHRvIGRpc3Rpbmd1aXNoIGZyb20gdGhlIHRvcC1hYm92ZS1uYXYgc2xvdCwgd2hpY2ggaW5jbHVkZXMgYSBsZWFkZXJib2FyZFxuICAgIGlmIChjb250YWluc0JpbGxib2FyZE5vdExlYWRlcmJvYXJkKHNsb3RTaXplcykpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLmRlZmF1bHRQYXJhbXMsXG4gICAgICAgICAgICBiaWRQYXJhbXM6ICgpID0+ICh7XG4gICAgICAgICAgICAgICAgem9uZUlkOiAxNzU5MzU0LFxuICAgICAgICAgICAgfSksXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIC4uLmRlZmF1bHRQYXJhbXMsXG4gICAgICAgIGJpZFBhcmFtczogKCkgPT4gKHtcbiAgICAgICAgICAgIG5ldHdvcmtJZDogMzM3LFxuICAgICAgICB9KSxcbiAgICB9O1xufTtcbmNvbnN0IGthcmdvQmlkZGVyID0ge1xuICAgIG5hbWU6ICdrYXJnbycsXG4gICAgc3dpdGNoTmFtZTogJ3ByZWJpZEthcmdvJyxcbiAgICBiaWRQYXJhbXM6IChfc2xvdElkLCBzaXplcykgPT4gKHtcbiAgICAgICAgcGxhY2VtZW50SWQ6IGdldEthcmdvUGxhY2VtZW50SWQoc2l6ZXMpLFxuICAgIH0pLFxufTtcbmNvbnN0IG1hZ25pdGVCaWRkZXIgPSB7XG4gICAgLy9SdWJpY29uIGlzIHRoZSBvbGQgbmFtZSBmb3IgTWFnbml0ZSBidXQgaXQgaXMgc3RpbGwgdXNlZCBmb3IgdGhlIGludGVncmF0aW9uXG4gICAgbmFtZTogJ3J1Ymljb24nLFxuICAgIHN3aXRjaE5hbWU6ICdwcmViaWRNYWduaXRlJyxcbiAgICBiaWRQYXJhbXM6IChzbG90SWQsIHNpemVzKSA9PiAoe1xuICAgICAgICBhY2NvdW50SWQ6IDI2NjQ0LFxuICAgICAgICBzaXRlSWQ6IGdldE1hZ25pdGVTaXRlSWQoKSxcbiAgICAgICAgem9uZUlkOiBnZXRNYWduaXRlWm9uZUlkKHNsb3RJZCwgc2l6ZXMpLFxuICAgICAgICBrZXl3b3Jkczogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmtleXdvcmRzXG4gICAgICAgICAgICA/IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5rZXl3b3Jkcy5zcGxpdCgnLCcpXG4gICAgICAgICAgICA6IFtdLFxuICAgIH0pLFxufTtcbmNvbnN0IHRoZVRyYWRlRGVza0JpZGRlciA9IChncGlkKSA9PiAoe1xuICAgIG5hbWU6ICd0dGQnLFxuICAgIHN3aXRjaE5hbWU6ICdwcmViaWRUaGVUcmFkZURlc2snLFxuICAgIGJpZFBhcmFtczogKCkgPT4gKHtcbiAgICAgICAgc3VwcGx5U291cmNlSWQ6ICd0aGVndWFyZGlhbicsXG4gICAgICAgIHB1Ymxpc2hlcklkOiAnMScsXG4gICAgICAgIHBsYWNlbWVudElkOiBncGlkLFxuICAgIH0pLFxufSk7XG4vLyBUaGVyZSdzIGFuIElYIGJpZGRlciBmb3IgZXZlcnkgc2l6ZSB0aGF0IHRoZSBzbG90IGNhbiB0YWtlXG5jb25zdCBpbmRleEV4Y2hhbmdlQmlkZGVycyA9IChzbG90U2l6ZXMpID0+IHtcbiAgICBjb25zdCBzaXRlSWQgPSBnZXRJbmRleFNpdGVJZChzbG90U2l6ZXMpO1xuICAgIHJldHVybiBzbG90U2l6ZXMubWFwKChzaXplKSA9PiAoe1xuICAgICAgICBuYW1lOiAnaXgnLFxuICAgICAgICBzd2l0Y2hOYW1lOiAncHJlYmlkSW5kZXhFeGNoYW5nZScsXG4gICAgICAgIGJpZFBhcmFtczogKCkgPT4gKHtcbiAgICAgICAgICAgIHNpdGVJZCxcbiAgICAgICAgICAgIHNpemUsXG4gICAgICAgIH0pLFxuICAgIH0pKTtcbn07XG5jb25zdCBiaWRkZXJzQmVpbmdUZXN0ZWQgPSAoYWxsQmlkZGVycykgPT4gYWxsQmlkZGVycy5maWx0ZXIoKGJpZGRlcikgPT4gcGJUZXN0TmFtZU1hcCgpW2JpZGRlci5uYW1lXSk7XG5jb25zdCBjdXJyZW50QmlkZGVycyA9IChzbG90U2l6ZXMsIHBhZ2VUYXJnZXRpbmcsIGdwaWQsIGNvbnNlbnRTdGF0ZSkgPT4ge1xuICAgIGNvbnN0IHNob3VsZEluY2x1ZGUgPSBzaG91bGRJbmNsdWRlQmlkZGVyKGNvbnNlbnRTdGF0ZSk7XG4gICAgY29uc3QgaXhCaWRkZXJzID0gc2hvdWxkSW5jbHVkZSgnaXgnKVxuICAgICAgICA/IGluZGV4RXhjaGFuZ2VCaWRkZXJzKHNsb3RTaXplcylcbiAgICAgICAgOiBbXTtcbiAgICBjb25zdCBiaWRkZXJzVG9DaGVjayA9IFtcbiAgICAgICAgW3Nob3VsZEluY2x1ZGUoJ2NyaXRlbycpLCBjcml0ZW9CaWRkZXIoc2xvdFNpemVzKV0sXG4gICAgICAgIFtzaG91bGRJbmNsdWRlKCd0cnVzdHgnKSwgdHJ1c3RYQmlkZGVyXSxcbiAgICAgICAgW3Nob3VsZEluY2x1ZGUoJ3RyaXBsZWxpZnQnKSwgdHJpcGxlTGlmdEJpZGRlcl0sXG4gICAgICAgIFtzaG91bGRJbmNsdWRlKCdhbmQnKSwgYXBwTmV4dXNCaWRkZXIocGFnZVRhcmdldGluZyldLFxuICAgICAgICBbc2hvdWxkSW5jbHVkZSgneGhiJyksIHhheGlzQmlkZGVyXSxcbiAgICAgICAgW3Nob3VsZEluY2x1ZGUoJ3B1Ym1hdGljJyksIHB1Ym1hdGljQmlkZGVyKHNsb3RTaXplcyldLFxuICAgICAgICBbc2hvdWxkSW5jbHVkZSgnb3pvbmUnKSwgb3pvbmVCaWRkZXIocGFnZVRhcmdldGluZyldLFxuICAgICAgICBbc2hvdWxkSW5jbHVkZSgnb3hkJyksIG9wZW54QmlkZGVyKHBhZ2VUYXJnZXRpbmcpXSxcbiAgICAgICAgW3Nob3VsZEluY2x1ZGUoJ2thcmdvJyksIGthcmdvQmlkZGVyXSxcbiAgICAgICAgW3Nob3VsZEluY2x1ZGUoJ3J1Ymljb24nKSwgbWFnbml0ZUJpZGRlcl0sXG4gICAgICAgIFtzaG91bGRJbmNsdWRlKCd0dGQnKSwgdGhlVHJhZGVEZXNrQmlkZGVyKGdwaWQpXSxcbiAgICBdO1xuICAgIGNvbnN0IG90aGVyQmlkZGVycyA9IGJpZGRlcnNUb0NoZWNrXG4gICAgICAgIC5maWx0ZXIoKFtzaG91bGRJbmNsdWRlXSkgPT4gaW5QYlRlc3RPcihzaG91bGRJbmNsdWRlKSlcbiAgICAgICAgLm1hcCgoWywgYmlkZGVyXSkgPT4gYmlkZGVyKTtcbiAgICBjb25zdCBhbGxCaWRkZXJzID0gWy4uLml4QmlkZGVycywgLi4ub3RoZXJCaWRkZXJzXTtcbiAgICByZXR1cm4gaXNQYlRlc3RPbigpID8gYmlkZGVyc0JlaW5nVGVzdGVkKGFsbEJpZGRlcnMpIDogYWxsQmlkZGVycztcbn07XG5leHBvcnQgY29uc3QgYmlkcyA9IChzbG90SWQsIHNsb3RTaXplcywgcGFnZVRhcmdldGluZywgZ3BpZCwgY29uc2VudFN0YXRlKSA9PiBjdXJyZW50QmlkZGVycyhzbG90U2l6ZXMsIHBhZ2VUYXJnZXRpbmcsIGdwaWQsIGNvbnNlbnRTdGF0ZSkubWFwKChiaWRkZXIpID0+ICh7XG4gICAgYmlkZGVyOiBiaWRkZXIubmFtZSxcbiAgICBwYXJhbXM6IGJpZGRlci5iaWRQYXJhbXMoc2xvdElkLCBzbG90U2l6ZXMpLFxufSkpO1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgZ2V0SW5kZXhTaXRlSWRGcm9tQ29uZmlnLFxuICAgIGdldFhheGlzUGxhY2VtZW50SWQsXG4gICAgZ2V0VHJ1c3RYQWRVbml0SWQsXG4gICAgaW5kZXhFeGNoYW5nZUJpZGRlcnMsXG4gICAgZ2V0T3pvbmVQbGFjZW1lbnRJZCxcbn07XG4iLCJpbXBvcnQgeyBpc0luQXVPck56LCBpc0luUm93LCBpc0luVWssIGlzSW5Vc09yQ2EsIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9nZW8vZ2VvLXV0aWxzJztcbmltcG9ydCB7IGNvbnRhaW5zQmlsbGJvYXJkLCBjb250YWluc0xlYWRlcmJvYXJkT3JCaWxsYm9hcmQsIGNvbnRhaW5zTW9iaWxlU3RpY2t5LCBjb250YWluc01wdSwgY29udGFpbnNNcHVPckRtcHUsIGNvbnRhaW5zUG9ydHJhaXRJbnRlcnN0aXRpYWwsIGNvbnRhaW5zV1MsIGdldEJyZWFrcG9pbnRLZXksIH0gZnJvbSAnLi4vdXRpbHMnO1xuZXhwb3J0IGNvbnN0IGdldE1hZ25pdGVab25lSWQgPSAoc2xvdElkLCBzaXplcykgPT4ge1xuICAgIHN3aXRjaCAoZ2V0QnJlYWtwb2ludEtleSgpKSB7XG4gICAgICAgIGNhc2UgJ0QnOlxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTXB1T3JEbXB1KHNpemVzKSB8fCBjb250YWluc1dTKHNpemVzKSkge1xuICAgICAgICAgICAgICAgIGlmIChpc0luVWsoKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQyNjc4MDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNJblJvdygpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAzNDI2ODIyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChpc0luVXNPckNhKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDM0NzE0MjI7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5BdU9yTnooKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQ3MTQ1MjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyB0b3AtYWJvdmUtbmF2IG9uIGRlc2t0b3BcbiAgICAgICAgICAgIGlmIChjb250YWluc0xlYWRlcmJvYXJkT3JCaWxsYm9hcmQoc2l6ZXMpICYmXG4gICAgICAgICAgICAgICAgc2xvdElkID09PSAnZGZwLWFkLS10b3AtYWJvdmUtbmF2Jykge1xuICAgICAgICAgICAgICAgIGlmIChpc0luVWsoKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQyNjc4NjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNJblJvdygpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAzNDI2ODI4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChpc0luVXNPckNhKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDM0NzE0Mjg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5BdU9yTnooKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQ3MTQ1ODtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBGcm9udHMtYmFubmVycyBvbiBkZXNrdG9wXG4gICAgICAgICAgICBpZiAoY29udGFpbnNCaWxsYm9hcmQoc2l6ZXMpICYmIHNsb3RJZC5pbmNsdWRlcygnZnJvbnRzLWJhbm5lcicpKSB7XG4gICAgICAgICAgICAgICAgaWYgKGlzSW5VaygpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAzNDI2NzkwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChpc0luUm93KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDM0MjY4MzQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5Vc09yQ2EoKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQ3MTQzNDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAzNDcxNDYyO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdNJzpcbiAgICAgICAgICAgIGlmIChjb250YWluc01wdShzaXplcykgfHwgY29udGFpbnNQb3J0cmFpdEludGVyc3RpdGlhbChzaXplcykpIHtcbiAgICAgICAgICAgICAgICBpZiAoaXNJblVrKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDM0MjY3Nzg7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5Sb3coKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQyNjgzNjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNJblVzT3JDYSgpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAzNDcxNDM2O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChpc0luQXVPck56KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDM0NzE0NjQ7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGNvbnRhaW5zTW9iaWxlU3RpY2t5KHNpemVzKSkge1xuICAgICAgICAgICAgICAgIGlmIChpc0luUm93KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIDM0Nzc1NjA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5Vc09yQ2EoKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gMzQ3MTQ0MDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAzNDcxNDY4O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gLTE7XG59O1xuZXhwb3J0IGNvbnN0IGdldE1hZ25pdGVTaXRlSWQgPSAoKSA9PiB7XG4gICAgc3dpdGNoIChnZXRCcmVha3BvaW50S2V5KCkpIHtcbiAgICAgICAgY2FzZSAnRCc6XG4gICAgICAgICAgICBpZiAoaXNJblVrKCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gNTQ5MzU4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNJblJvdygpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDU0OTQ5NjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5Vc09yQ2EoKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiA1NTQyNDQ7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc0luQXVPck56KCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gNTU0MjU2O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ00nOlxuICAgICAgICAgICAgaWYgKGlzSW5VaygpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDU0OTM3NDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGlzSW5Sb3coKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiA1NDk0OTg7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc0luVXNPckNhKCkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gNTU0MjQ4O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoaXNJbkF1T3JOeigpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDU1NDI1ODtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gLTE7XG59O1xuIiwiaW1wb3J0IHsgY3JlYXRlQWRTaXplIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBQUkVCSURfVElNRU9VVCB9IGZyb20gJ0BndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUvY29uc3RhbnRzL3ByZWJpZC10aW1lb3V0JztcbmltcG9ydCB7IEV2ZW50VGltZXIgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2V2ZW50LXRpbWVyJztcbmltcG9ydCB7IGdldFBlcm11dGl2ZVNlZ21lbnRzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9wZXJtdXRpdmUnO1xuaW1wb3J0IHsgZ2V0Q29uc2VudEZvciwgaXNTdHJpbmcsIGxvZywgb25Db25zZW50IH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgZmxhdHRlbiB9IGZyb20gJ2xvZGFzaC1lcyc7XG5pbXBvcnQgeyBnZXRQYXJ0aWNpcGF0aW9ucyB9IGZyb20gJy4uLy4uLy4uL2V4cGVyaW1lbnRzL2FiJztcbmltcG9ydCB7IHB1Ym1hdGljIH0gZnJvbSAnLi4vLi4vX192ZW5kb3IvcHVibWF0aWMnO1xuaW1wb3J0IHsgZ2V0QWR2ZXJ0QnlJZCB9IGZyb20gJy4uLy4uL2RmcC9nZXQtYWR2ZXJ0LWJ5LWlkJztcbmltcG9ydCB7IGlzVXNlckxvZ2dlZEluIH0gZnJvbSAnLi4vLi4vaWRlbnRpdHkvYXBpJztcbmltcG9ydCB7IGdldFBhZ2VUYXJnZXRpbmcgfSBmcm9tICcuLi8uLi9wYWdlLXRhcmdldGluZyc7XG5pbXBvcnQgeyBnZXRIZWFkZXJCaWRkaW5nQWRTbG90cyB9IGZyb20gJy4uL3Nsb3QtY29uZmlnJztcbmltcG9ydCB7IGlzU3dpdGNoZWRPbiwgc2hvdWxkSW5jbHVkZUJpZGRlciwgc2hvdWxkSW5jbHVkZVBlcm11dGl2ZSwgc3RyaXBEZnBBZFByZWZpeEZyb20sIH0gZnJvbSAnLi4vdXRpbHMnO1xuaW1wb3J0IHsgYmlkcyB9IGZyb20gJy4vYmlkLWNvbmZpZyc7XG5pbXBvcnQgeyBvdmVycmlkZVByaWNlQnVja2V0LCBwcmljZUdyYW51bGFyaXR5IH0gZnJvbSAnLi9wcmljZS1jb25maWcnO1xuY2xhc3MgUHJlYmlkQWRVbml0IHtcbiAgICBjb2RlO1xuICAgIGJpZHM7XG4gICAgbWVkaWFUeXBlcztcbiAgICBncGlkO1xuICAgIG9ydGIySW1wO1xuICAgIGNvbnN0cnVjdG9yKGFkdmVydCwgc2xvdCwgcGFnZVRhcmdldGluZywgY29uc2VudFN0YXRlKSB7XG4gICAgICAgIHRoaXMuY29kZSA9IGFkdmVydC5pZDtcbiAgICAgICAgdGhpcy5tZWRpYVR5cGVzID0geyBiYW5uZXI6IHsgc2l6ZXM6IHNsb3Quc2l6ZXMgfSB9O1xuICAgICAgICB0aGlzLmdwaWQgPSB0aGlzLmdlbmVyYXRlR3BpZChhZHZlcnQsIHNsb3QpO1xuICAgICAgICB0aGlzLm9ydGIySW1wID0ge1xuICAgICAgICAgICAgZXh0OiB7XG4gICAgICAgICAgICAgICAgZ3BpZDogdGhpcy5ncGlkLFxuICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAgcGJhZHNsb3Q6IHRoaXMuZ3BpZCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfTtcbiAgICAgICAgdGhpcy5iaWRzID0gYmlkcyhhZHZlcnQuaWQsIHNsb3Quc2l6ZXMsIHBhZ2VUYXJnZXRpbmcsIHRoaXMuZ3BpZCwgY29uc2VudFN0YXRlKTtcbiAgICAgICAgYWR2ZXJ0LmhlYWRlckJpZGRpbmdTaXplcyA9IHNsb3Quc2l6ZXM7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGBQcmViaWRBZFVuaXQgJHt0aGlzLmNvZGV9YCwgdGhpcy5iaWRzKTtcbiAgICB9XG4gICAgaXNFbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29kZSA9PSBudWxsO1xuICAgIH1cbiAgICBnZW5lcmF0ZUdwaWQoYWR2ZXJ0LCBzbG90KSB7XG4gICAgICAgIGNvbnN0IHNlY3Rpb25OYW1lID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNlY3Rpb247XG4gICAgICAgIGNvbnN0IGNvbnRlbnRUeXBlID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmNvbnRlbnRUeXBlO1xuICAgICAgICBjb25zdCBzbG90TmFtZSA9IHNsb3Qua2V5O1xuICAgICAgICByZXR1cm4gYC81OTY2NjA0Ny9ndS8ke3NlY3Rpb25OYW1lfS8ke2NvbnRlbnRUeXBlfS8ke3Nsb3ROYW1lfWA7XG4gICAgfVxufVxuY29uc3Qgc2hvdWxkRW5hYmxlQW5hbHl0aWNzID0gKCkgPT4ge1xuICAgIGlmICghd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlcy5wcmViaWRBbmFseXRpY3MpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBjb25zdCBhbmFseXRpY3NTYW1wbGVSYXRlID0gMTAgLyAxMDA7XG4gICAgY29uc3QgaXNJblNhbXBsZSA9IE1hdGgucmFuZG9tKCkgPCBhbmFseXRpY3NTYW1wbGVSYXRlO1xuICAgIGNvbnN0IGlzSW5TZXJ2ZXJTaWRlVGVzdCA9IE9iamVjdC5rZXlzKHdpbmRvdy5ndWFyZGlhbi5jb25maWcudGVzdHMgPz8ge30pLmxlbmd0aCA+IDA7XG4gICAgY29uc3QgaXNJbkNsaWVudFNpZGVUZXN0ID0gT2JqZWN0LmtleXMoZ2V0UGFydGljaXBhdGlvbnMoKSkubGVuZ3RoID4gMDtcbiAgICBjb25zdCBoYXNRdWVyeVBhcmFtID0gd2luZG93LmxvY2F0aW9uLnNlYXJjaC5pbmNsdWRlcygncGJqcy1hbmFseXRpY3M9dHJ1ZScpO1xuICAgIHJldHVybiAoaXNJblNlcnZlclNpZGVUZXN0IHx8IGlzSW5DbGllbnRTaWRlVGVzdCB8fCBpc0luU2FtcGxlIHx8IGhhc1F1ZXJ5UGFyYW0pO1xufTtcbi8qKlxuICogUHJlYmlkIHN1cHBvcnRzIGFuIGFkZGl0aW9uYWwgdGltZW91dCBidWZmZXIgdG8gYWNjb3VudCBmb3Igbm9pc2luZXNzIGluXG4gKiB0aW1pbmcgSmF2YVNjcmlwdCBvbiB0aGUgcGFnZS4gVGhpcyB2YWx1ZSBpcyBwYXNzZWQgdG8gdGhlIFByZWJpZCBjb25maWdcbiAqIGFuZCBpcyBhZGp1c3RhYmxlIHZpYSB0aGlzIGNvbnN0YW50XG4gKi9cbmNvbnN0IHRpbWVvdXRCdWZmZXIgPSA0MDA7XG4vKipcbiAqIFRoZSBhbW91bnQgb2YgdGltZSByZXNlcnZlZCBmb3IgdGhlIGF1Y3Rpb25cbiAqL1xuY29uc3QgYmlkZGVyVGltZW91dCA9IFBSRUJJRF9USU1FT1VUO1xubGV0IHJlcXVlc3RRdWV1ZSA9IFByb21pc2UucmVzb2x2ZSgpO1xubGV0IGluaXRpYWxpc2VkID0gZmFsc2U7XG5jb25zdCBpbml0aWFsaXNlID0gKHdpbmRvdywgY29uc2VudFN0YXRlKSA9PiB7XG4gICAgaWYgKCF3aW5kb3cucGJqcykge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnd2luZG93LnBianMgbm90IGZvdW5kIG9uIHdpbmRvdycpO1xuICAgICAgICByZXR1cm47IC8vIFdlIGNvdWxkbuKAmXQgaW5pdGlhbGlzZVxuICAgIH1cbiAgICBpbml0aWFsaXNlZCA9IHRydWU7XG4gICAgY29uc3QgdXNlcklkcyA9IFtcbiAgICAgICAge1xuICAgICAgICAgICAgbmFtZTogJ3NoYXJlZElkJyxcbiAgICAgICAgICAgIHN0b3JhZ2U6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnY29va2llJyxcbiAgICAgICAgICAgICAgICBuYW1lOiAnX3B1YmNpZCcsXG4gICAgICAgICAgICAgICAgZXhwaXJlczogMzY1LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICBdO1xuICAgIGlmIChnZXRDb25zZW50Rm9yKCdpZDUnLCBjb25zZW50U3RhdGUpKSB7XG4gICAgICAgIHVzZXJJZHMucHVzaCh7XG4gICAgICAgICAgICBuYW1lOiAnaWQ1SWQnLFxuICAgICAgICAgICAgcGFyYW1zOiB7XG4gICAgICAgICAgICAgICAgcGFydG5lcjogMTgyLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHN0b3JhZ2U6IHtcbiAgICAgICAgICAgICAgICB0eXBlOiAnaHRtbDUnLFxuICAgICAgICAgICAgICAgIG5hbWU6ICdpZDVpZCcsXG4gICAgICAgICAgICAgICAgZXhwaXJlczogOTAsXG4gICAgICAgICAgICAgICAgcmVmcmVzaEluU2Vjb25kczogNzIwMCxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCB1c2VyU3luYyA9IGlzU3dpdGNoZWRPbigncHJlYmlkVXNlclN5bmMnKVxuICAgICAgICA/IHtcbiAgICAgICAgICAgIHN5bmNzUGVyQmlkZGVyOiAwLCAvLyBhbGxvdyBhbGwgc3luY3NcbiAgICAgICAgICAgIGZpbHRlclNldHRpbmdzOiB7XG4gICAgICAgICAgICAgICAgYWxsOiB7XG4gICAgICAgICAgICAgICAgICAgIGJpZGRlcnM6ICcqJywgLy8gYWxsb3cgYWxsIGJpZGRlcnMgdG8gc3luYyBieSBpZnJhbWUgb3IgaW1hZ2UgYmVhY29uc1xuICAgICAgICAgICAgICAgICAgICBmaWx0ZXI6ICdpbmNsdWRlJyxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHVzZXJJZHMsXG4gICAgICAgIH1cbiAgICAgICAgOiB7IHN5bmNFbmFibGVkOiBmYWxzZSB9O1xuICAgIGNvbnN0IGNvbnNlbnRNYW5hZ2VtZW50ID0gKCkgPT4ge1xuICAgICAgICBzd2l0Y2ggKGNvbnNlbnRTdGF0ZS5mcmFtZXdvcmspIHtcbiAgICAgICAgICAgIC8qKiBAc2VlIGh0dHBzOi8vZG9jcy5wcmViaWQub3JnL2Rldi1kb2NzL21vZHVsZXMvY29uc2VudE1hbmFnZW1lbnRVc3AuaHRtbCAqL1xuICAgICAgICAgICAgY2FzZSAnYXVzJzpcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICB1c3A6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNtcEFwaTogJ2lhYicsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aW1lb3V0OiAxNTAwLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAvKiogQHNlZSBodHRwczovL2RvY3MucHJlYmlkLm9yZy9kZXYtZG9jcy9tb2R1bGVzL2NvbnNlbnRNYW5hZ2VtZW50R3BwLmh0bWwgKi9cbiAgICAgICAgICAgIGNhc2UgJ3VzbmF0JzpcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBncHA6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNtcEFwaTogJ2lhYicsXG4gICAgICAgICAgICAgICAgICAgICAgICB0aW1lb3V0OiAxNTAwLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAvKiogQHNlZSBodHRwczovL2RvY3MucHJlYmlkLm9yZy9kZXYtZG9jcy9tb2R1bGVzL2NvbnNlbnRNYW5hZ2VtZW50VGNmLmh0bWwgKi9cbiAgICAgICAgICAgIGNhc2UgJ3RjZnYyJzpcbiAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgZ2Rwcjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgY21wQXBpOiAnaWFiJyxcbiAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVvdXQ6IDIwMCxcbiAgICAgICAgICAgICAgICAgICAgICAgIGRlZmF1bHRHZHByU2NvcGU6IHRydWUsXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgLyoqIEhlbHBlciBmdW5jdGlvbiB0byBkZWNpZGUgaWYgYSBiaWRkZXIgc2hvdWxkIGJlIGluY2x1ZGVkLlxuICAgICAqIEl0IGlzIGEgY3VycmllZCBmdW5jdGlvbiBwcmVwYXJlZCB3aXRoIHRoZSBjb25zZW50IHN0YXRlXG4gICAgICogYXQgdGhlIHRpbWUgb2YgaW5pdGlhbGlzYXRpb24gdG8gYXZvaWQgdW5uZWNlc3NhcnkgcmVwZXRpdGlvblxuICAgICAqIG9mIGNvbnNlbnQgc3RhdGUgdGhyb3VnaG91dCAqL1xuICAgIGNvbnN0IHNob3VsZEluY2x1ZGUgPSBzaG91bGRJbmNsdWRlQmlkZGVyKGNvbnNlbnRTdGF0ZSk7XG4gICAgY29uc3QgcGJqc0NvbmZpZyA9IE9iamVjdC5hc3NpZ24oe30sIHtcbiAgICAgICAgYmlkZGVyVGltZW91dCxcbiAgICAgICAgdGltZW91dEJ1ZmZlcixcbiAgICAgICAgcHJpY2VHcmFudWxhcml0eSxcbiAgICAgICAgdXNlclN5bmMsXG4gICAgfSk7XG4gICAgY29uc3Qga2V5d29yZHNBcnJheSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5rZXl3b3Jkcy5zcGxpdCgnLCcpO1xuICAgIHBianNDb25maWcub3J0YjIgPSB7XG4gICAgICAgIHNpdGU6IHtcbiAgICAgICAgICAgIGV4dDoge1xuICAgICAgICAgICAgICAgIGRhdGE6IHtcbiAgICAgICAgICAgICAgICAgICAga2V5d29yZHM6IGtleXdvcmRzQXJyYXksXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgfTtcbiAgICB3aW5kb3cucGJqcy5iaWRkZXJTZXR0aW5ncyA9IHt9O1xuICAgIGlmIChpc1N3aXRjaGVkT24oJ2NvbnNlbnRNYW5hZ2VtZW50JykpIHtcbiAgICAgICAgcGJqc0NvbmZpZy5jb25zZW50TWFuYWdlbWVudCA9IGNvbnNlbnRNYW5hZ2VtZW50KCk7XG4gICAgfVxuICAgIGlmIChzaG91bGRJbmNsdWRlUGVybXV0aXZlKGNvbnNlbnRTdGF0ZSkpIHtcbiAgICAgICAgY29uc3QgaW5jbHVkZWRBY0JpZGRlcnMgPSBbJ2FuZCcsICdpeCcsICdvem9uZScsICdwdWJtYXRpYycsICd0cnVzdHgnXVxuICAgICAgICAgICAgLmZpbHRlcihzaG91bGRJbmNsdWRlKVxuICAgICAgICAgICAgLy8gXCJhbmRcIiBpcyB0aGUgYWxpYXMgZm9yIHRoZSBjdXN0b20gR3VhcmRpYW4gXCJhcHBuZXh1c1wiIGRpcmVjdCBiaWRkZXJcbiAgICAgICAgICAgIC5tYXAoKGJpZGRlcikgPT4gKGJpZGRlciA9PT0gJ2FuZCcgPyAnYXBwbmV4dXMnIDogYmlkZGVyKSk7XG4gICAgICAgIHBianNDb25maWcucmVhbFRpbWVEYXRhID0ge1xuICAgICAgICAgICAgZGF0YVByb3ZpZGVyczogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ3Blcm11dGl2ZScsXG4gICAgICAgICAgICAgICAgICAgIHBhcmFtczoge1xuICAgICAgICAgICAgICAgICAgICAgICAgYWNCaWRkZXJzOiBpbmNsdWRlZEFjQmlkZGVycyxcbiAgICAgICAgICAgICAgICAgICAgICAgIC4uLihpbmNsdWRlZEFjQmlkZGVycy5pbmNsdWRlcygncHVibWF0aWMnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgID8geyBvdmVyd3JpdGVzOiB7IHB1Ym1hdGljIH0gfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIDoge30pLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoc2hvdWxkSW5jbHVkZSgnY3JpdGVvJykpIHtcbiAgICAgICAgd2luZG93LnBianMuYmlkZGVyU2V0dGluZ3MuY3JpdGVvID0ge1xuICAgICAgICAgICAgc3RvcmFnZUFsbG93ZWQ6IHRydWUsXG4gICAgICAgICAgICAvLyBVc2UgYSBjdXN0b20gcHJpY2UgZ3JhbnVsYXJpdHksIHdoaWNoIGlzIGJhc2VkIHVwb24gdGhlIHNpemUgb2YgdGhlIHNsb3QgYmVpbmcgYXVjdGlvbmVkXG4gICAgICAgICAgICBhZHNlcnZlclRhcmdldGluZzogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAga2V5OiAnaGJfcGInLFxuICAgICAgICAgICAgICAgICAgICB2YWwoeyB3aWR0aCwgaGVpZ2h0LCBjcG0sIHBiQ2cgfSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG92ZXJyaWRlUHJpY2VCdWNrZXQoJ2NyaXRlbycsIHdpZHRoLCBoZWlnaHQsIGNwbSwgcGJDZyk7XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmIChzaG91bGRJbmNsdWRlKCdvem9uZScpKSB7XG4gICAgICAgIC8vIFVzZSBhIGN1c3RvbSBwcmljZSBncmFudWxhcml0eSwgd2hpY2ggaXMgYmFzZWQgdXBvbiB0aGUgc2l6ZSBvZiB0aGUgc2xvdCBiZWluZyBhdWN0aW9uZWRcbiAgICAgICAgd2luZG93LnBianMuYmlkZGVyU2V0dGluZ3Mub3pvbmUgPSB7XG4gICAgICAgICAgICBhZHNlcnZlclRhcmdldGluZzogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAga2V5OiAnaGJfcGInLFxuICAgICAgICAgICAgICAgICAgICB2YWw6ICh7IHdpZHRoLCBoZWlnaHQsIGNwbSwgcGJDZyB9KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gb3ZlcnJpZGVQcmljZUJ1Y2tldCgnb3pvbmUnLCB3aWR0aCwgaGVpZ2h0LCBjcG0sIHBiQ2cpO1xuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoc2hvdWxkSW5jbHVkZSgnaXgnKSkge1xuICAgICAgICAvLyBVc2UgYSBjdXN0b20gcHJpY2UgZ3JhbnVsYXJpdHksIHdoaWNoIGlzIGJhc2VkIHVwb24gdGhlIHNpemUgb2YgdGhlIHNsb3QgYmVpbmcgYXVjdGlvbmVkXG4gICAgICAgIHdpbmRvdy5wYmpzLmJpZGRlclNldHRpbmdzLml4ID0ge1xuICAgICAgICAgICAgYWRzZXJ2ZXJUYXJnZXRpbmc6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIGtleTogJ2hiX3BiJyxcbiAgICAgICAgICAgICAgICAgICAgdmFsKHsgd2lkdGgsIGhlaWdodCwgY3BtLCBwYkNnIH0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBvdmVycmlkZVByaWNlQnVja2V0KCdpeCcsIHdpZHRoLCBoZWlnaHQsIGNwbSwgcGJDZyk7XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmIChzaG91bGRFbmFibGVBbmFseXRpY3MoKSAmJiB3aW5kb3cuZ3VhcmRpYW4ub3BoYW4/LnBhZ2VWaWV3SWQpIHtcbiAgICAgICAgd2luZG93LnBianMuZW5hYmxlQW5hbHl0aWNzKFtcbiAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICBwcm92aWRlcjogJ2d1JyxcbiAgICAgICAgICAgICAgICBvcHRpb25zOiB7XG4gICAgICAgICAgICAgICAgICAgIHVybDogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzRGV2IHx8XG4gICAgICAgICAgICAgICAgICAgICAgICB3aW5kb3cubG9jYXRpb24uaG9zdG5hbWUuaW5jbHVkZXMoJ2xvY2FsaG9zdCcpXG4gICAgICAgICAgICAgICAgICAgICAgICA/IGAvL3BlcmZvcm1hbmNlLWV2ZW50cy5jb2RlLmRldi1ndWFyZGlhbmFwaXMuY29tL2hlYWRlci1iaWRkaW5nYFxuICAgICAgICAgICAgICAgICAgICAgICAgOiBgLy9wZXJmb3JtYW5jZS1ldmVudHMuZ3VhcmRpYW5hcGlzLmNvbS9oZWFkZXItYmlkZGluZ2AsXG4gICAgICAgICAgICAgICAgICAgIHB2OiB3aW5kb3cuZ3VhcmRpYW4ub3BoYW4ucGFnZVZpZXdJZCxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgfSxcbiAgICAgICAgXSk7XG4gICAgfVxuICAgIGlmIChzaG91bGRJbmNsdWRlKCd4aGInKSkge1xuICAgICAgICB3aW5kb3cucGJqcy5iaWRkZXJTZXR0aW5ncy54aGIgPSB7XG4gICAgICAgICAgICBhZHNlcnZlclRhcmdldGluZzogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAga2V5OiAnaGJfYnV5ZXJfaWQnLFxuICAgICAgICAgICAgICAgICAgICB2YWwoYmlkUmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRPRE86IHNob3VsZCB3ZSByZXR1cm4gbnVsbCBvciBhbiBlbXB0eSBzdHJpbmc/XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gYmlkUmVzcG9uc2UuYXBwbmV4dXM/LmJ1eWVyTWVtYmVySWQgPz8gJyc7XG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgICAgICBiaWRDcG1BZGp1c3RtZW50OiAoYmlkQ3BtKSA9PiB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGJpZENwbSAqIDEuMDU7XG4gICAgICAgICAgICB9LFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoc2hvdWxkSW5jbHVkZSgna2FyZ28nKSkge1xuICAgICAgICB3aW5kb3cucGJqcy5iaWRkZXJTZXR0aW5ncy5rYXJnbyA9IHtcbiAgICAgICAgICAgIHN0b3JhZ2VBbGxvd2VkOiB0cnVlLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoc2hvdWxkSW5jbHVkZSgncnViaWNvbicpKSB7XG4gICAgICAgIHdpbmRvdy5wYmpzLmJpZGRlclNldHRpbmdzLm1hZ25pdGUgPSB7XG4gICAgICAgICAgICBzdG9yYWdlQWxsb3dlZDogdHJ1ZSxcbiAgICAgICAgfTtcbiAgICAgICAgd2luZG93LnBianMuc2V0QmlkZGVyQ29uZmlnKHtcbiAgICAgICAgICAgIGJpZGRlcnM6IFsncnViaWNvbiddLFxuICAgICAgICAgICAgY29uZmlnOiB7XG4gICAgICAgICAgICAgICAgb3J0YjI6IHtcbiAgICAgICAgICAgICAgICAgICAgdXNlcjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgZXh0OiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZGF0YToge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwZXJtdXRpdmU6IGdldFBlcm11dGl2ZVNlZ21lbnRzKCksXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICB3aW5kb3cucGJqcy5zZXRDb25maWcocGJqc0NvbmZpZyk7XG4gICAgLy8gQWRqdXN0IHNsb3Qgc2l6ZSB3aGVuIHByZWJpZCBhZCBsb2Fkc1xuICAgIHdpbmRvdy5wYmpzLm9uRXZlbnQoJ2JpZFdvbicsIChkYXRhKSA9PiB7XG4gICAgICAgIGNvbnN0IHsgd2lkdGgsIGhlaWdodCwgYWRVbml0Q29kZSB9ID0gZGF0YTtcbiAgICAgICAgaWYgKCF3aWR0aCB8fCAhaGVpZ2h0IHx8ICFhZFVuaXRDb2RlKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3Qgc2l6ZSA9IGNyZWF0ZUFkU2l6ZSh3aWR0aCwgaGVpZ2h0KTsgLy8gZWcuIFszMDAsIDI1MF1cbiAgICAgICAgY29uc3QgYWR2ZXJ0ID0gZ2V0QWR2ZXJ0QnlJZChhZFVuaXRDb2RlKTtcbiAgICAgICAgaWYgKCFhZHZlcnQpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBhZHZlcnQuc2l6ZSA9IHNpemU7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB3aGVuIGhhc1ByZWJpZFNpemUgaXMgdHJ1ZSB3ZSB1c2Ugc2l6ZVxuICAgICAgICAgKiBzZXQgaGVyZSB3aGVuIGFkanVzdGluZyB0aGUgc2xvdCBzaXplLlxuICAgICAgICAgKiAqL1xuICAgICAgICBhZHZlcnQuaGFzUHJlYmlkU2l6ZSA9IHRydWU7XG4gICAgfSk7XG59O1xuY29uc3QgYmlkc0JhY2tIYW5kbGVyID0gKGFkVW5pdHMsIGV2ZW50VGltZXIpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgd2luZG93LnBianM/LnNldFRhcmdldGluZ0ZvckdQVEFzeW5jKGFkVW5pdHMubWFwKCh1KSA9PiB1LmNvZGUpLmZpbHRlcihpc1N0cmluZykpO1xuICAgIHJlc29sdmUoKTtcbiAgICBhZFVuaXRzLmZvckVhY2goKGFkVW5pdCkgPT4ge1xuICAgICAgICBpZiAoaXNTdHJpbmcoYWRVbml0LmNvZGUpKSB7XG4gICAgICAgICAgICBldmVudFRpbWVyLm1hcmsoJ3ByZWJpZEVuZCcsIHN0cmlwRGZwQWRQcmVmaXhGcm9tKGFkVW5pdC5jb2RlKSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn0pO1xuLy8gc2xvdEZsYXRNYXAgYWxsb3dzIHlvdSB0byBkeW5hbWljYWxseSBpbnRlcmZlcmUgd2l0aCB0aGUgUHJlYmlkU2xvdCBkZWZpbml0aW9uXG4vLyBmb3IgdGhpcyBnaXZlbiByZXF1ZXN0IGZvciBiaWRzLlxuY29uc3QgcmVxdWVzdEJpZHMgPSBhc3luYyAoYWR2ZXJ0cywgc2xvdEZsYXRNYXApID0+IHtcbiAgICBpZiAoIWluaXRpYWxpc2VkKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0UXVldWU7XG4gICAgfVxuICAgIGlmICghd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlcy5wcmViaWRIZWFkZXJCaWRkaW5nKSB7XG4gICAgICAgIHJldHVybiByZXF1ZXN0UXVldWU7XG4gICAgfVxuICAgIGNvbnN0IGFkVW5pdHMgPSBhd2FpdCBvbkNvbnNlbnQoKVxuICAgICAgICAudGhlbihhc3luYyAoY29uc2VudFN0YXRlKSA9PiB7XG4gICAgICAgIC8vIGNhbGN1bGF0ZSB0aGlzIG9uY2UgYmVmb3JlIG1hcHBpbmcgb3ZlclxuICAgICAgICBjb25zdCBpc1NpZ25lZEluID0gYXdhaXQgaXNVc2VyTG9nZ2VkSW4oKTtcbiAgICAgICAgY29uc3QgcGFnZVRhcmdldGluZyA9IGdldFBhZ2VUYXJnZXRpbmcoY29uc2VudFN0YXRlLCBpc1NpZ25lZEluKTtcbiAgICAgICAgcmV0dXJuIGZsYXR0ZW4oYWR2ZXJ0cy5tYXAoKGFkdmVydCkgPT4gZ2V0SGVhZGVyQmlkZGluZ0FkU2xvdHMoYWR2ZXJ0LCBzbG90RmxhdE1hcClcbiAgICAgICAgICAgIC5tYXAoKHNsb3QpID0+IG5ldyBQcmViaWRBZFVuaXQoYWR2ZXJ0LCBzbG90LCBwYWdlVGFyZ2V0aW5nLCBjb25zZW50U3RhdGUpKVxuICAgICAgICAgICAgLmZpbHRlcigoYWRVbml0KSA9PiAhYWRVbml0LmlzRW1wdHkoKSkpKTtcbiAgICB9KVxuICAgICAgICAuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgLy8gc2lsZW50bHkgZmFpbFxuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnRmFpbGVkIHRvIGV4ZWN1dGUgcHJlYmlkIG9uQ29uc2VudCcsIGUpO1xuICAgICAgICByZXR1cm4gW107XG4gICAgfSk7XG4gICAgY29uc3QgZXZlbnRUaW1lciA9IEV2ZW50VGltZXIuZ2V0KCk7XG4gICAgcmVxdWVzdFF1ZXVlID0gcmVxdWVzdFF1ZXVlLnRoZW4oKCkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgYWRVbml0cy5mb3JFYWNoKChhZFVuaXQpID0+IHtcbiAgICAgICAgICAgIGlmIChpc1N0cmluZyhhZFVuaXQuY29kZSkpIHtcbiAgICAgICAgICAgICAgICBldmVudFRpbWVyLm1hcmsoJ3ByZWJpZFN0YXJ0Jywgc3RyaXBEZnBBZFByZWZpeEZyb20oYWRVbml0LmNvZGUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIHdpbmRvdy5wYmpzPy5xdWUucHVzaCgoKSA9PiB7XG4gICAgICAgICAgICB3aW5kb3cucGJqcz8ucmVxdWVzdEJpZHMoe1xuICAgICAgICAgICAgICAgIGFkVW5pdHMsXG4gICAgICAgICAgICAgICAgYmlkc0JhY2tIYW5kbGVyOiAoKSA9PiB2b2lkIGJpZHNCYWNrSGFuZGxlcihhZFVuaXRzLCBldmVudFRpbWVyKS50aGVuKHJlc29sdmUpLFxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0pKTtcbiAgICByZXR1cm4gcmVxdWVzdFF1ZXVlO1xufTtcbmV4cG9ydCBjb25zdCBwcmViaWQgPSB7IGluaXRpYWxpc2UsIHJlcXVlc3RCaWRzIH07XG4iLCJpbXBvcnQgeyBhZFNpemVzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBnZXRQcmljZUJ1Y2tldFN0cmluZywgfSBmcm9tICdwcmViaWQuanMvc3JjL2NwbUJ1Y2tldE1hbmFnZXInO1xuZXhwb3J0IGNvbnN0IHByaWNlR3JhbnVsYXJpdHkgPSB7XG4gICAgYnVja2V0czogW1xuICAgICAgICB7XG4gICAgICAgICAgICBtYXg6IDEwLFxuICAgICAgICAgICAgaW5jcmVtZW50OiAwLjAxLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBtYXg6IDE1LFxuICAgICAgICAgICAgaW5jcmVtZW50OiAwLjEsXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAgIG1heDogMTAwLFxuICAgICAgICAgICAgaW5jcmVtZW50OiAxLFxuICAgICAgICB9LFxuICAgIF0sXG59O1xuZXhwb3J0IGNvbnN0IGNyaXRlb1ByaWNlR3JhbnVsYXJpdHkgPSB7XG4gICAgYnVja2V0czogW1xuICAgICAgICB7XG4gICAgICAgICAgICBtYXg6IDEyLFxuICAgICAgICAgICAgaW5jcmVtZW50OiAwLjAxLFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBtYXg6IDIwLFxuICAgICAgICAgICAgaW5jcmVtZW50OiAwLjA1LFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgICBtYXg6IDUwMCxcbiAgICAgICAgICAgIGluY3JlbWVudDogMSxcbiAgICAgICAgfSxcbiAgICBdLFxufTtcbmV4cG9ydCBjb25zdCBvem9uZVByaWNlR3JhbnVsYXJpdHkgPSAod2lkdGgsIGhlaWdodCkgPT4ge1xuICAgIGNvbnN0IHNpemVTdHJpbmcgPSBbd2lkdGgsIGhlaWdodF0uam9pbignLCcpO1xuICAgIGlmIChzaXplU3RyaW5nID09PSBhZFNpemVzLnNreXNjcmFwZXIudG9TdHJpbmcoKSB8fFxuICAgICAgICBzaXplU3RyaW5nID09PSBhZFNpemVzLmhhbGZQYWdlLnRvU3RyaW5nKCkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG1heDogMTAsXG4gICAgICAgICAgICAgICAgICAgIGluY3JlbWVudDogMC4wMSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4OiAxNSxcbiAgICAgICAgICAgICAgICAgICAgaW5jcmVtZW50OiAwLjEsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG1heDogNTAsXG4gICAgICAgICAgICAgICAgICAgIGluY3JlbWVudDogMSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgXSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHNpemVTdHJpbmcgPT09IGFkU2l6ZXMubGVhZGVyYm9hcmQudG9TdHJpbmcoKSB8fFxuICAgICAgICBzaXplU3RyaW5nID09PSBhZFNpemVzLmJpbGxib2FyZC50b1N0cmluZygpIHx8XG4gICAgICAgIHNpemVTdHJpbmcgPT09IGFkU2l6ZXMubXB1LnRvU3RyaW5nKCkgfHxcbiAgICAgICAgc2l6ZVN0cmluZyA9PT0gYWRTaXplcy5vdXRzdHJlYW1EZXNrdG9wLnRvU3RyaW5nKCkgfHxcbiAgICAgICAgc2l6ZVN0cmluZyA9PT0gYWRTaXplcy5vdXRzdHJlYW1Nb2JpbGUudG9TdHJpbmcoKSkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgYnVja2V0czogW1xuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4OiAxMixcbiAgICAgICAgICAgICAgICAgICAgaW5jcmVtZW50OiAwLjAxLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBtYXg6IDIwLFxuICAgICAgICAgICAgICAgICAgICBpbmNyZW1lbnQ6IDAuMSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4OiA1MCxcbiAgICAgICAgICAgICAgICAgICAgaW5jcmVtZW50OiAxLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbmV4cG9ydCBjb25zdCBpbmRleFByaWNlR3JhbnVsYXJpdHkgPSAod2lkdGgsIGhlaWdodCkgPT4ge1xuICAgIGNvbnN0IHNpemVTdHJpbmcgPSBbd2lkdGgsIGhlaWdodF0uam9pbignLCcpO1xuICAgIGlmIChzaXplU3RyaW5nID09PSBhZFNpemVzLnNreXNjcmFwZXIudG9TdHJpbmcoKSB8fFxuICAgICAgICBzaXplU3RyaW5nID09PSBhZFNpemVzLmhhbGZQYWdlLnRvU3RyaW5nKCkpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIGJ1Y2tldHM6IFtcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG1heDogMTAsXG4gICAgICAgICAgICAgICAgICAgIGluY3JlbWVudDogMC4wMSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4OiAxNSxcbiAgICAgICAgICAgICAgICAgICAgaW5jcmVtZW50OiAwLjA1LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBtYXg6IDUwLFxuICAgICAgICAgICAgICAgICAgICBpbmNyZW1lbnQ6IDEsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH07XG4gICAgfVxuICAgIGlmIChzaXplU3RyaW5nID09PSBhZFNpemVzLmxlYWRlcmJvYXJkLnRvU3RyaW5nKCkgfHxcbiAgICAgICAgc2l6ZVN0cmluZyA9PT0gYWRTaXplcy5iaWxsYm9hcmQudG9TdHJpbmcoKSB8fFxuICAgICAgICBzaXplU3RyaW5nID09PSBhZFNpemVzLm1wdS50b1N0cmluZygpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBidWNrZXRzOiBbXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBtYXg6IDEyLFxuICAgICAgICAgICAgICAgICAgICBpbmNyZW1lbnQ6IDAuMDEsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgIG1heDogMjAsXG4gICAgICAgICAgICAgICAgICAgIGluY3JlbWVudDogMC4wNSxcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIHtcbiAgICAgICAgICAgICAgICAgICAgbWF4OiA1MCxcbiAgICAgICAgICAgICAgICAgICAgaW5jcmVtZW50OiAxLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBdLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufTtcbmV4cG9ydCBjb25zdCBnZXRQcmljZUdyYW51bGFyaXR5Rm9yU2l6ZSA9IChiaWRkZXIsIHdpZHRoLCBoZWlnaHQpID0+IHtcbiAgICBpZiAoYmlkZGVyID09PSAnb3pvbmUnKSB7XG4gICAgICAgIHJldHVybiBvem9uZVByaWNlR3JhbnVsYXJpdHkod2lkdGgsIGhlaWdodCk7XG4gICAgfVxuICAgIHJldHVybiBpbmRleFByaWNlR3JhbnVsYXJpdHkod2lkdGgsIGhlaWdodCk7XG59O1xuZXhwb3J0IGNvbnN0IG92ZXJyaWRlUHJpY2VCdWNrZXQgPSAoYmlkZGVyLCB3aWR0aCwgaGVpZ2h0LCBjcG0sIGRlZmF1bHRQcmljZUJ1Y2tldCkgPT4ge1xuICAgIGNvbnN0IHByaWNlR3JhbnVsYXJpdHkgPSBiaWRkZXIgPT09ICdjcml0ZW8nXG4gICAgICAgID8gY3JpdGVvUHJpY2VHcmFudWxhcml0eVxuICAgICAgICA6IGdldFByaWNlR3JhbnVsYXJpdHlGb3JTaXplKGJpZGRlciwgd2lkdGgsIGhlaWdodCk7XG4gICAgaWYgKCFwcmljZUdyYW51bGFyaXR5KSB7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGAke2JpZGRlcn0gcHJpY2UgZ3JhbnVsYXJpdHkgZm9yIHNpemUgKCR7d2lkdGh9eCR7aGVpZ2h0fSkgbm90IGZvdW5kYCk7XG4gICAgICAgIHJldHVybiBkZWZhdWx0UHJpY2VCdWNrZXQ7XG4gICAgfVxuICAgIGNvbnN0IHByaWNlQnVja2V0ID0gZ2V0UHJpY2VCdWNrZXRTdHJpbmcoY3BtLCBwcmljZUdyYW51bGFyaXR5KS5jdXN0b207XG4gICAgaWYgKHByaWNlQnVja2V0ICE9PSBkZWZhdWx0UHJpY2VCdWNrZXQpIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYCR7YmlkZGVyfSBwcmljZSBidWNrZXQgZm9yIHNpemUgKCR7d2lkdGh9eCR7aGVpZ2h0fSkgd2l0aCBjcG0gJHtjcG19IG92ZXJyaWRlbiBmcm9tICR7ZGVmYXVsdFByaWNlQnVja2V0fSB0byAke3ByaWNlQnVja2V0fWApO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYCR7YmlkZGVyfSBwcmljZSBidWNrZXQgZm9yIHNpemUgKCR7d2lkdGh9eCR7aGVpZ2h0fSkgd2l0aCBjcG0gJHtjcG19IG5vdCBvdmVycmlkZW4gKCR7cHJpY2VCdWNrZXR9KWApO1xuICAgIH1cbiAgICByZXR1cm4gcHJpY2VCdWNrZXQ7XG59O1xuIiwiaW1wb3J0IHsgYWRTaXplcywgY3JlYXRlQWRTaXplIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBpc0luVWsgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2dlby9nZW8tdXRpbHMnO1xuaW1wb3J0IHsgZ2V0QnJlYWtwb2ludEtleSwgc2hvdWxkSW5jbHVkZU1vYmlsZVN0aWNreSB9IGZyb20gJy4vdXRpbHMnO1xuY29uc3QgZ2V0SGJCcmVha3BvaW50ID0gKCkgPT4ge1xuICAgIHN3aXRjaCAoZ2V0QnJlYWtwb2ludEtleSgpKSB7XG4gICAgICAgIGNhc2UgJ00nOlxuICAgICAgICAgICAgcmV0dXJuICdtb2JpbGUnO1xuICAgICAgICBjYXNlICdUJzpcbiAgICAgICAgICAgIHJldHVybiAndGFibGV0JztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJldHVybiAnZGVza3RvcCc7XG4gICAgfVxufTtcbi8qKlxuICogUmVtb3ZlIGFueSBoZWFkZXIgYmlkZGluZyBzaXplcyB0aGF0IGRvIG5vdCBhcHBlYXIgaW4gdGhlIHNldFxuICogb2Ygc2xvdCBzaXplcyBmb3IgdGhlIGN1cnJlbnQgYnJlYWtwb2ludFxuICpcbiAqIE5PVEUgd2UgY3VycmVudGx5IG9ubHkgcGVyZm9ybSB0aGlzIGZpbHRlcmluZyBvbiBgaW5saW5lYCBzbG90c1xuICogKHRoaXMgZG9lcyBub3QgaW5jbHVkZSBpbmxpbmUxKVxuICovXG5jb25zdCBmaWx0ZXJCeVNpemVNYXBwaW5nID0gKHNsb3RTaXplcyA9IFtdKSA9PiAoeyBrZXksIHNpemVzIH0pID0+IHtcbiAgICAvLyBGb3Igbm93LCBvbmx5IGFwcGx5IGZpbHRlcmluZyB0byBpbmxpbmUgaGVhZGVyIGJpZGRpbmcgc2xvdHNcbiAgICAvLyBJbiB0aGUgZnV0dXJlIHdlIG1heSB3YW50IHRvIGV4cGFuZCB0aGlzIHRvIGFsbCBzbG90c1xuICAgIGlmIChrZXkgIT09ICdpbmxpbmUnKSB7XG4gICAgICAgIHJldHVybiB7IGtleSwgc2l6ZXMgfTtcbiAgICB9XG4gICAgY29uc3QgZmlsdGVyZWRTaXplcyA9IHNpemVzLmZpbHRlcigoW2hiV2lkdGgsIGhiSGVpZ2h0XSkgPT4gc2xvdFNpemVzLnNvbWUoKGFkU2l6ZSkgPT4gaGJXaWR0aCA9PT0gYWRTaXplLndpZHRoICYmIGhiSGVpZ2h0ID09PSBhZFNpemUuaGVpZ2h0KSk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAga2V5LFxuICAgICAgICBzaXplczogZmlsdGVyZWRTaXplcyxcbiAgICB9O1xufTtcbmNvbnN0IGdldEhlYWRlckJpZGRpbmdLZXkgPSAoc2xvdE5hbWUsIG5hbWUpID0+IHtcbiAgICBpZiAoc2xvdE5hbWUuc29tZSgoa2V5KSA9PiBrZXkgPT09IG5hbWUpKSB7XG4gICAgICAgIHJldHVybiBuYW1lO1xuICAgIH1cbiAgICBpZiAobmFtZT8uaW5jbHVkZXMoJ2lubGluZScpKSB7XG4gICAgICAgIHJldHVybiAnaW5saW5lJztcbiAgICB9XG4gICAgaWYgKG5hbWU/LmluY2x1ZGVzKCdmcm9udHMtYmFubmVyJykpIHtcbiAgICAgICAgcmV0dXJuICdmcm9udHMtYmFubmVyJztcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG5jb25zdCBnZXRTbG90TmFtZXNGcm9tU2l6ZU1hcHBpbmcgPSAoc2l6ZU1hcHBpbmcpID0+IE9iamVjdC5rZXlzKHNpemVNYXBwaW5nKS5maWx0ZXIoKGtleSkgPT4ga2V5ICE9PSAnaW5saW5lJyk7XG5jb25zdCBmaWx0ZXJCeUFkdmVydCA9IChhZCwgYnJlYWtwb2ludCwgc2l6ZU1hcHBpbmcpID0+IHtcbiAgICBjb25zdCBzbG90TmFtZXMgPSBnZXRTbG90TmFtZXNGcm9tU2l6ZU1hcHBpbmcoc2l6ZU1hcHBpbmcpO1xuICAgIGNvbnN0IGtleSA9IGdldEhlYWRlckJpZGRpbmdLZXkoc2xvdE5hbWVzLCBhZC5ub2RlLmRhdGFzZXQubmFtZSk7XG4gICAgaWYgKCFrZXkpIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICBjb25zdCBzaXplcyA9IHNpemVNYXBwaW5nW2tleV0/LlticmVha3BvaW50XTtcbiAgICBpZiAoIXNpemVzIHx8IHNpemVzLmxlbmd0aCA8IDEpIHtcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIH1cbiAgICByZXR1cm4gW1xuICAgICAgICB7XG4gICAgICAgICAgICBrZXksXG4gICAgICAgICAgICBzaXplcyxcbiAgICAgICAgfSxcbiAgICBdO1xufTtcbmNvbnN0IGdldFNsb3RzID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGVudFR5cGUsIGhhc1Nob3djYXNlTWFpbkVsZW1lbnQgfSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZTtcbiAgICBjb25zdCBpc0FydGljbGUgPSBjb250ZW50VHlwZSA9PT0gJ0FydGljbGUnO1xuICAgIGNvbnN0IGhhc0V4dGVuZGVkTW9zdFBvcCA9IGlzQXJ0aWNsZSAmJiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLmV4dGVuZGVkTW9zdFBvcHVsYXI7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcmlnaHQ6IHtcbiAgICAgICAgICAgIGRlc2t0b3A6IGhhc1Nob3djYXNlTWFpbkVsZW1lbnRcbiAgICAgICAgICAgICAgICA/IFthZFNpemVzLm1wdV1cbiAgICAgICAgICAgICAgICA6IFthZFNpemVzLmhhbGZQYWdlLCBhZFNpemVzLm1wdV0sXG4gICAgICAgICAgICB0YWJsZXQ6IGhhc1Nob3djYXNlTWFpbkVsZW1lbnRcbiAgICAgICAgICAgICAgICA/IFthZFNpemVzLm1wdV1cbiAgICAgICAgICAgICAgICA6IFthZFNpemVzLmhhbGZQYWdlLCBhZFNpemVzLm1wdV0sXG4gICAgICAgICAgICBtb2JpbGU6IGhhc1Nob3djYXNlTWFpbkVsZW1lbnRcbiAgICAgICAgICAgICAgICA/IFthZFNpemVzLm1wdV1cbiAgICAgICAgICAgICAgICA6IFthZFNpemVzLmhhbGZQYWdlLCBhZFNpemVzLm1wdV0sXG4gICAgICAgIH0sXG4gICAgICAgICd0b3AtYWJvdmUtbmF2Jzoge1xuICAgICAgICAgICAgZGVza3RvcDogW2FkU2l6ZXMuYmlsbGJvYXJkLCBhZFNpemVzLmxlYWRlcmJvYXJkXSxcbiAgICAgICAgICAgIHRhYmxldDogW2FkU2l6ZXMubGVhZGVyYm9hcmRdLFxuICAgICAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5tcHVdLFxuICAgICAgICB9LFxuICAgICAgICAnZnJvbnRzLWJhbm5lcic6IHtcbiAgICAgICAgICAgIGRlc2t0b3A6IFthZFNpemVzLmJpbGxib2FyZF0sXG4gICAgICAgIH0sXG4gICAgICAgIGlubGluZToge1xuICAgICAgICAgICAgZGVza3RvcDogaXNBcnRpY2xlXG4gICAgICAgICAgICAgICAgPyBbYWRTaXplcy5za3lzY3JhcGVyLCBhZFNpemVzLmhhbGZQYWdlLCBhZFNpemVzLm1wdV1cbiAgICAgICAgICAgICAgICA6IFthZFNpemVzLm1wdV0sXG4gICAgICAgICAgICB0YWJsZXQ6IFthZFNpemVzLm1wdV0sXG4gICAgICAgICAgICBtb2JpbGU6IFthZFNpemVzLm1wdV0sXG4gICAgICAgIH0sXG4gICAgICAgIGlubGluZTE6IHtcbiAgICAgICAgICAgIGRlc2t0b3A6IGlzQXJ0aWNsZVxuICAgICAgICAgICAgICAgID8gW2FkU2l6ZXMubXB1LCBhZFNpemVzLm91dHN0cmVhbURlc2t0b3BdXG4gICAgICAgICAgICAgICAgOiBbYWRTaXplcy5tcHVdLFxuICAgICAgICAgICAgdGFibGV0OiBpc0FydGljbGVcbiAgICAgICAgICAgICAgICA/IFthZFNpemVzLm1wdSwgYWRTaXplcy5vdXRzdHJlYW1EZXNrdG9wXVxuICAgICAgICAgICAgICAgIDogW2FkU2l6ZXMubXB1XSxcbiAgICAgICAgICAgIG1vYmlsZTogaXNBcnRpY2xlXG4gICAgICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAgICAgIGFkU2l6ZXMub3V0c3RyZWFtTW9iaWxlLFxuICAgICAgICAgICAgICAgICAgICBhZFNpemVzLm1wdSxcbiAgICAgICAgICAgICAgICAgICAgYWRTaXplcy5wb3J0cmFpdEludGVyc3RpdGlhbCxcbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbYWRTaXplcy5tcHVdLFxuICAgICAgICB9LFxuICAgICAgICBpbmxpbmUyOiB7XG4gICAgICAgICAgICBkZXNrdG9wOiBpc0FydGljbGVcbiAgICAgICAgICAgICAgICA/IFthZFNpemVzLnNreXNjcmFwZXIsIGFkU2l6ZXMuaGFsZlBhZ2UsIGFkU2l6ZXMubXB1XVxuICAgICAgICAgICAgICAgIDogW2FkU2l6ZXMubXB1XSxcbiAgICAgICAgICAgIHRhYmxldDogW2FkU2l6ZXMubXB1XSxcbiAgICAgICAgICAgIG1vYmlsZTogaXNBcnRpY2xlXG4gICAgICAgICAgICAgICAgPyBbXG4gICAgICAgICAgICAgICAgICAgIGFkU2l6ZXMubXB1LFxuICAgICAgICAgICAgICAgICAgICBhZFNpemVzLnBvcnRyYWl0SW50ZXJzdGl0aWFsLFxuICAgICAgICAgICAgICAgICAgICBhZFNpemVzLnB1Ym1hdGljSW50ZXJzY3JvbGxlcixcbiAgICAgICAgICAgICAgICBdXG4gICAgICAgICAgICAgICAgOiBbYWRTaXplcy5tcHVdLFxuICAgICAgICB9LFxuICAgICAgICBtb3N0cG9wOiB7XG4gICAgICAgICAgICBkZXNrdG9wOiBoYXNFeHRlbmRlZE1vc3RQb3BcbiAgICAgICAgICAgICAgICA/IFthZFNpemVzLmhhbGZQYWdlLCBhZFNpemVzLm1wdV1cbiAgICAgICAgICAgICAgICA6IFthZFNpemVzLm1wdV0sXG4gICAgICAgICAgICB0YWJsZXQ6IGhhc0V4dGVuZGVkTW9zdFBvcFxuICAgICAgICAgICAgICAgID8gW2FkU2l6ZXMuaGFsZlBhZ2UsIGFkU2l6ZXMubXB1LCBhZFNpemVzLmxlYWRlcmJvYXJkXVxuICAgICAgICAgICAgICAgIDogW2FkU2l6ZXMubXB1XSxcbiAgICAgICAgICAgIG1vYmlsZTogW2FkU2l6ZXMubXB1XSxcbiAgICAgICAgfSxcbiAgICAgICAgY29tbWVudHM6IHtcbiAgICAgICAgICAgIGRlc2t0b3A6IFthZFNpemVzLnNreXNjcmFwZXIsIGFkU2l6ZXMubXB1LCBhZFNpemVzLmhhbGZQYWdlXSxcbiAgICAgICAgfSxcbiAgICAgICAgJ2NvbW1lbnRzLWV4cGFuZGVkJzoge1xuICAgICAgICAgICAgZGVza3RvcDogW2FkU2l6ZXMuc2t5c2NyYXBlciwgYWRTaXplcy5tcHUsIGFkU2l6ZXMuaGFsZlBhZ2VdLFxuICAgICAgICB9LFxuICAgICAgICBiYW5uZXI6IHtcbiAgICAgICAgICAgIC8vIEJhbm5lciBzbG90cyBhcHBlYXIgb24gaW50ZXJhY3RpdmVzLCBsaWtlIG9uXG4gICAgICAgICAgICAvLyBodHRwczovL3d3dy50aGVndWFyZGlhbi5jb20vdXMtbmV3cy9uZy1pbnRlcmFjdGl2ZS8yMDE4L25vdi8wNi9taWR0ZXJtLWVsZWN0aW9ucy0yMDE4LWxpdmUtcmVzdWx0cy1sYXRlc3Qtd2lubmVycy1hbmQtc2VhdHNcbiAgICAgICAgICAgIGRlc2t0b3A6IFtcbiAgICAgICAgICAgICAgICBjcmVhdGVBZFNpemUoODgsIDcwKSxcbiAgICAgICAgICAgICAgICBhZFNpemVzLmxlYWRlcmJvYXJkLFxuICAgICAgICAgICAgICAgIGFkU2l6ZXMuY2FzY2FkZSxcbiAgICAgICAgICAgICAgICBjcmVhdGVBZFNpemUoOTAwLCAyNTApLFxuICAgICAgICAgICAgICAgIGFkU2l6ZXMuYmlsbGJvYXJkLFxuICAgICAgICAgICAgXSxcbiAgICAgICAgfSxcbiAgICAgICAgJ21vYmlsZS1zdGlja3knOiB7XG4gICAgICAgICAgICBtb2JpbGU6IHNob3VsZEluY2x1ZGVNb2JpbGVTdGlja3koKVxuICAgICAgICAgICAgICAgID8gW2FkU2l6ZXMubW9iaWxlc3RpY2t5LCBjcmVhdGVBZFNpemUoMzAwLCA1MCldXG4gICAgICAgICAgICAgICAgOiBbXSxcbiAgICAgICAgfSxcbiAgICAgICAgJ2Nyb3Nzd29yZC1iYW5uZXItbW9iaWxlJzoge1xuICAgICAgICAgICAgbW9iaWxlOiBbYWRTaXplcy5tb2JpbGVzdGlja3ldLFxuICAgICAgICB9LFxuICAgICAgICAnZm9vdGJhbGwtcmlnaHQnOiB7XG4gICAgICAgICAgICBkZXNrdG9wOiBbXG4gICAgICAgICAgICAgICAgYWRTaXplcy5lbXB0eSxcbiAgICAgICAgICAgICAgICBhZFNpemVzLm1wdSxcbiAgICAgICAgICAgICAgICBhZFNpemVzLnNreXNjcmFwZXIsXG4gICAgICAgICAgICAgICAgYWRTaXplcy5oYWxmUGFnZSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH0sXG4gICAgICAgIG1lcmNoYW5kaXNpbmc6IHtcbiAgICAgICAgICAgIG1vYmlsZTogW2FkU2l6ZXMubXB1XSxcbiAgICAgICAgICAgIGRlc2t0b3A6IFthZFNpemVzLmJpbGxib2FyZF0sXG4gICAgICAgIH0sXG4gICAgICAgICdtZXJjaGFuZGlzaW5nLWhpZ2gnOiB7XG4gICAgICAgICAgICBtb2JpbGU6IFthZFNpemVzLm1wdV0sXG4gICAgICAgICAgICBkZXNrdG9wOiBbYWRTaXplcy5iaWxsYm9hcmRdLFxuICAgICAgICB9LFxuICAgICAgICAnYXJ0aWNsZS1lbmQnOiB7XG4gICAgICAgICAgICBtb2JpbGU6IGlzSW5VaygpID8gW2FkU2l6ZXMubXB1XSA6IFtdLFxuICAgICAgICAgICAgdGFibGV0OiBpc0luVWsoKSA/IFthZFNpemVzLm1wdV0gOiBbXSxcbiAgICAgICAgICAgIGRlc2t0b3A6IGlzSW5VaygpID8gW2FkU2l6ZXMubXB1XSA6IFtdLFxuICAgICAgICB9LFxuICAgIH07XG59O1xuZXhwb3J0IGNvbnN0IGdldEhlYWRlckJpZGRpbmdBZFNsb3RzID0gKGFkLCBzbG90RmxhdE1hcCA9IChzKSA9PiBbc10pID0+IHtcbiAgICBjb25zdCBicmVha3BvaW50ID0gZ2V0SGJCcmVha3BvaW50KCk7XG4gICAgY29uc3QgaGVhZGVyQmlkZGluZ1Nsb3RzID0gZmlsdGVyQnlBZHZlcnQoYWQsIGJyZWFrcG9pbnQsIGdldFNsb3RzKCkpO1xuICAgIHJldHVybiBoZWFkZXJCaWRkaW5nU2xvdHNcbiAgICAgICAgLm1hcChmaWx0ZXJCeVNpemVNYXBwaW5nKGFkLnNpemVzW2JyZWFrcG9pbnRdKSlcbiAgICAgICAgLm1hcChzbG90RmxhdE1hcClcbiAgICAgICAgLnJlZHVjZSgoYWNjLCBlbHQpID0+IGFjYy5jb25jYXQoZWx0KSwgW10pOyAvLyB0aGUgXCJmbGF0XCIgaW4gXCJmbGF0TWFwXCJcbn07XG4iLCJpbXBvcnQgeyBjcmVhdGVBZFNpemUgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2FkLXNpemVzJztcbmltcG9ydCB7IGlzSW5BdU9yTnosIGlzSW5DYW5hZGEsIGlzSW5VaywgaXNJblVzYSwgaXNJblVzT3JDYSwgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2dlby9nZW8tdXRpbHMnO1xuaW1wb3J0IHsgZ2V0Q29uc2VudEZvciwgaXNTdHJpbmcgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBvbmNlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGdldEN1cnJlbnRUd2Vha3BvaW50LCBtYXRjaGVzQnJlYWtwb2ludHMsIH0gZnJvbSAnLi4vZGV0ZWN0L2RldGVjdC1icmVha3BvaW50JztcbmltcG9ydCB7IHBiVGVzdE5hbWVNYXAgfSBmcm9tICcuLi91cmwnO1xuY29uc3QgU1VGRklYX1JFR0VYUFMgPSB7fTtcbmNvbnN0IHN0cmlwU3VmZml4ID0gKHMsIHN1ZmZpeCkgPT4ge1xuICAgIGNvbnN0IHJlID0gU1VGRklYX1JFR0VYUFNbc3VmZml4XSA/P1xuICAgICAgICAoU1VGRklYX1JFR0VYUFNbc3VmZml4XSA9IG5ldyBSZWdFeHAoYCR7c3VmZml4fSRgKSk7XG4gICAgcmV0dXJuIHMucmVwbGFjZShyZSwgJycpO1xufTtcbmNvbnN0IFBSRUZJWF9SRUdFWFBTID0ge307XG5jb25zdCBzdHJpcFByZWZpeCA9IChzLCBwcmVmaXgpID0+IHtcbiAgICBjb25zdCByZSA9IFBSRUZJWF9SRUdFWFBTW3ByZWZpeF0gPz9cbiAgICAgICAgKFBSRUZJWF9SRUdFWFBTW3ByZWZpeF0gPSBuZXcgUmVnRXhwKGBeJHtwcmVmaXh9YCkpO1xuICAgIHJldHVybiBzLnJlcGxhY2UocmUsICcnKTtcbn07XG5jb25zdCBjb250YWlucyA9IChzaXplcywgc2l6ZSkgPT4gQm9vbGVhbihzaXplcy5maW5kKChzKSA9PiBzWzBdID09PSBzaXplWzBdICYmIHNbMV0gPT09IHNpemVbMV0pKTtcbmNvbnN0IGlzVmFsaWRQYWdlRm9yTW9iaWxlU3RpY2t5ID0gKCkgPT4ge1xuICAgIGNvbnN0IHsgY29udGVudFR5cGUsIHBhZ2VJZCB9ID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlO1xuICAgIHJldHVybiAoY29udGVudFR5cGUgPT09ICdBcnRpY2xlJyB8fFxuICAgICAgICBjb250ZW50VHlwZSA9PT0gJ0ludGVyYWN0aXZlJyB8fFxuICAgICAgICBwYWdlSWQuc3RhcnRzV2l0aCgnZm9vdGJhbGwvJykpO1xufTtcbi8qKlxuICogQ2xlYW5zIGFuIG9iamVjdCBmb3IgdGFyZ2V0dGluZy4gUmVtb3ZlcyBlbXB0eSBzdHJpbmdzIGFuZCBvdGhlciBmYWxzeSB2YWx1ZXMuXG4gKiBAcGFyYW0gbyBvYmplY3Qgd2l0aCBmYWxzeSB2YWx1ZXNcbiAqIEByZXR1cm5zIHtSZWNvcmQ8c3RyaW5nLCBzdHJpbmcgfCBzdHJpbmdbXT59IG9iamVjdCB3aXRoIG9ubHkgbm9uLWVtcHR5IHN0cmluZ3MsIG9yIGFycmF5cyBvZiBub24tZW1wdHkgc3RyaW5ncy5cbiAqL1xuZXhwb3J0IGNvbnN0IHJlbW92ZUZhbHN5VmFsdWVzID0gKG8pID0+IE9iamVjdC5lbnRyaWVzKG8pLnJlZHVjZSgocHJldiwgY3VycikgPT4ge1xuICAgIGNvbnN0IFtrZXksIHZhbF0gPSBjdXJyO1xuICAgIGlmICghdmFsKVxuICAgICAgICByZXR1cm4gcHJldjtcbiAgICBpZiAoaXNTdHJpbmcodmFsKSkge1xuICAgICAgICBwcmV2W2tleV0gPSB2YWw7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KHZhbCkgJiZcbiAgICAgICAgdmFsLmxlbmd0aCA+IDAgJiZcbiAgICAgICAgdmFsLnNvbWUoQm9vbGVhbikgJiZcbiAgICAgICAgdmFsLmV2ZXJ5KGlzU3RyaW5nKSkge1xuICAgICAgICBwcmV2W2tleV0gPSB2YWwuZmlsdGVyKEJvb2xlYW4pO1xuICAgIH1cbiAgICByZXR1cm4gcHJldjtcbn0sIHt9KTtcbmV4cG9ydCBjb25zdCBzdHJpcERmcEFkUHJlZml4RnJvbSA9IChzKSA9PiBzdHJpcFByZWZpeChzLCAnZGZwLWFkLS0nKTtcbmV4cG9ydCBjb25zdCBjb250YWluc01wdSA9IChzaXplcykgPT4gY29udGFpbnMoc2l6ZXMsIGNyZWF0ZUFkU2l6ZSgzMDAsIDI1MCkpO1xuZXhwb3J0IGNvbnN0IGNvbnRhaW5zRG1wdSA9IChzaXplcykgPT4gY29udGFpbnMoc2l6ZXMsIGNyZWF0ZUFkU2l6ZSgzMDAsIDYwMCkpO1xuZXhwb3J0IGNvbnN0IGNvbnRhaW5zTGVhZGVyYm9hcmQgPSAoc2l6ZXMpID0+IGNvbnRhaW5zKHNpemVzLCBjcmVhdGVBZFNpemUoNzI4LCA5MCkpO1xuZXhwb3J0IGNvbnN0IGNvbnRhaW5zQmlsbGJvYXJkID0gKHNpemVzKSA9PiBjb250YWlucyhzaXplcywgY3JlYXRlQWRTaXplKDk3MCwgMjUwKSk7XG5leHBvcnQgY29uc3QgY29udGFpbnNCaWxsYm9hcmROb3RMZWFkZXJib2FyZCA9IChzaXplcykgPT4gY29udGFpbnNCaWxsYm9hcmQoc2l6ZXMpICYmICFjb250YWluc0xlYWRlcmJvYXJkKHNpemVzKTtcbmV4cG9ydCBjb25zdCBjb250YWluc01wdU9yRG1wdSA9IChzaXplcykgPT4gY29udGFpbnNNcHUoc2l6ZXMpIHx8IGNvbnRhaW5zRG1wdShzaXplcyk7XG5leHBvcnQgY29uc3QgY29udGFpbnNNb2JpbGVTdGlja3kgPSAoc2l6ZXMpID0+IGNvbnRhaW5zKHNpemVzLCBjcmVhdGVBZFNpemUoMzIwLCA1MCkpO1xuZXhwb3J0IGNvbnN0IGNvbnRhaW5zTGVhZGVyYm9hcmRPckJpbGxib2FyZCA9IChzaXplcykgPT4gY29udGFpbnNMZWFkZXJib2FyZChzaXplcykgfHwgY29udGFpbnNCaWxsYm9hcmQoc2l6ZXMpO1xuZXhwb3J0IGNvbnN0IGNvbnRhaW5zUG9ydHJhaXRJbnRlcnN0aXRpYWwgPSAoc2l6ZXMpID0+IGNvbnRhaW5zKHNpemVzLCBjcmVhdGVBZFNpemUoMzIwLCA0ODApKTtcbmV4cG9ydCBjb25zdCBnZXRMYXJnZXN0U2l6ZSA9IChzaXplcykgPT4ge1xuICAgIGNvbnN0IHJlZHVjZXIgPSAocHJldmlvdXMsIGN1cnJlbnQpID0+IHtcbiAgICAgICAgaWYgKHByZXZpb3VzWzBdID49IGN1cnJlbnRbMF0gJiYgcHJldmlvdXNbMV0gPj0gY3VycmVudFsxXSkge1xuICAgICAgICAgICAgcmV0dXJuIHByZXZpb3VzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjdXJyZW50O1xuICAgIH07XG4gICAgcmV0dXJuIHNpemVzLmxlbmd0aCA+IDAgPyBzaXplcy5yZWR1Y2UocmVkdWNlcikgOiBudWxsO1xufTtcbmV4cG9ydCBjb25zdCBnZXRCcmVha3BvaW50S2V5ID0gKCkgPT4ge1xuICAgIHN3aXRjaCAoZ2V0Q3VycmVudFR3ZWFrcG9pbnQoKSkge1xuICAgICAgICBjYXNlICdtb2JpbGUnOlxuICAgICAgICBjYXNlICdtb2JpbGVNZWRpdW0nOlxuICAgICAgICBjYXNlICdtb2JpbGVMYW5kc2NhcGUnOlxuICAgICAgICAgICAgcmV0dXJuICdNJztcbiAgICAgICAgY2FzZSAncGhhYmxldCc6XG4gICAgICAgIGNhc2UgJ3RhYmxldCc6XG4gICAgICAgICAgICByZXR1cm4gJ1QnO1xuICAgICAgICBjYXNlICdkZXNrdG9wJzpcbiAgICAgICAgY2FzZSAnbGVmdENvbCc6XG4gICAgICAgIGNhc2UgJ3dpZGUnOlxuICAgICAgICAgICAgcmV0dXJuICdEJztcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHJldHVybiAnTSc7XG4gICAgfVxufTtcbmV4cG9ydCBjb25zdCBnZXRSYW5kb21JbnRJbmNsdXNpdmUgPSAobWluaW11bSwgbWF4aW11bSkgPT4ge1xuICAgIGNvbnN0IG1pbiA9IE1hdGguY2VpbChtaW5pbXVtKTtcbiAgICBjb25zdCBtYXggPSBNYXRoLmZsb29yKG1heGltdW0pO1xuICAgIHJldHVybiBNYXRoLmZsb29yKE1hdGgucmFuZG9tKCkgKiAobWF4IC0gbWluICsgMSkpICsgbWluO1xufTtcbmV4cG9ydCBjb25zdCBpc1N3aXRjaGVkT24gPSAoc3dpdGNoTmFtZSkgPT4gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlc1tzd2l0Y2hOYW1lXSA/PyBmYWxzZTtcbmV4cG9ydCBjb25zdCBzaG91bGRJbmNsdWRlQmlkZGVyID0gKGNvbnNlbnRTdGF0ZSkgPT4gKGJpZGRlcikgPT4ge1xuICAgIHN3aXRjaCAoYmlkZGVyKSB7XG4gICAgICAgIGNhc2UgJ2FuZCc6XG4gICAgICAgICAgICByZXR1cm4gKGlzU3dpdGNoZWRPbigncHJlYmlkQXBwbmV4dXMnKSAmJlxuICAgICAgICAgICAgICAgIChpc0luQXVPck56KCkgfHxcbiAgICAgICAgICAgICAgICAgICAgKGlzU3dpdGNoZWRPbigncHJlYmlkQXBwbmV4dXNVa1JvdycpICYmXG4gICAgICAgICAgICAgICAgICAgICAgICBnZXRDb25zZW50Rm9yKCd4YW5kcicsIGNvbnNlbnRTdGF0ZSkgJiZcbiAgICAgICAgICAgICAgICAgICAgICAgICFpc0luVXNPckNhKCkpIHx8XG4gICAgICAgICAgICAgICAgICAgICEhcGJUZXN0TmFtZU1hcCgpLmFuZCkpO1xuICAgICAgICBjYXNlICdjcml0ZW8nOlxuICAgICAgICAgICAgcmV0dXJuIChpc1N3aXRjaGVkT24oJ3ByZWJpZENyaXRlbycpICYmXG4gICAgICAgICAgICAgICAgZ2V0Q29uc2VudEZvcignY3JpdGVvJywgY29uc2VudFN0YXRlKSk7XG4gICAgICAgIGNhc2UgJ2l4JzpcbiAgICAgICAgICAgIHJldHVybiAoaXNTd2l0Y2hlZE9uKCdwcmViaWRJbmRleEV4Y2hhbmdlJykgJiZcbiAgICAgICAgICAgICAgICBnZXRDb25zZW50Rm9yKCdpbmRleEV4Y2hhbmdlJywgY29uc2VudFN0YXRlKSk7XG4gICAgICAgIGNhc2UgJ2thcmdvJzpcbiAgICAgICAgICAgIHJldHVybiBpc1N3aXRjaGVkT24oJ3ByZWJpZEthcmdvJykgJiYgaXNJblVzYSgpO1xuICAgICAgICBjYXNlICdveGQnOlxuICAgICAgICAgICAgcmV0dXJuIChpc1N3aXRjaGVkT24oJ3ByZWJpZE9wZW54JykgJiZcbiAgICAgICAgICAgICAgICBnZXRDb25zZW50Rm9yKCdvcGVuWCcsIGNvbnNlbnRTdGF0ZSkgJiZcbiAgICAgICAgICAgICAgICAhaXNJblVzT3JDYSgpKTtcbiAgICAgICAgY2FzZSAnb3pvbmUnOlxuICAgICAgICAgICAgcmV0dXJuIChpc1N3aXRjaGVkT24oJ3ByZWJpZE96b25lJykgJiZcbiAgICAgICAgICAgICAgICBnZXRDb25zZW50Rm9yKCdvem9uZScsIGNvbnNlbnRTdGF0ZSkgJiZcbiAgICAgICAgICAgICAgICAhaXNJbkNhbmFkYSgpICYmXG4gICAgICAgICAgICAgICAgIWlzSW5BdU9yTnooKSk7XG4gICAgICAgIGNhc2UgJ3B1Ym1hdGljJzpcbiAgICAgICAgICAgIHJldHVybiAoaXNTd2l0Y2hlZE9uKCdwcmViaWRQdWJtYXRpYycpICYmXG4gICAgICAgICAgICAgICAgZ2V0Q29uc2VudEZvcigncHVibWF0aWMnLCBjb25zZW50U3RhdGUpKTtcbiAgICAgICAgY2FzZSAncnViaWNvbic6XG4gICAgICAgICAgICByZXR1cm4gKGlzU3dpdGNoZWRPbigncHJlYmlkTWFnbml0ZScpICYmXG4gICAgICAgICAgICAgICAgZ2V0Q29uc2VudEZvcignbWFnbml0ZScsIGNvbnNlbnRTdGF0ZSkpO1xuICAgICAgICBjYXNlICd0cmlwbGVsaWZ0JzpcbiAgICAgICAgICAgIHJldHVybiAoaXNTd2l0Y2hlZE9uKCdwcmViaWRUcmlwbGVsaWZ0JykgJiZcbiAgICAgICAgICAgICAgICAoaXNJblVzT3JDYSgpIHx8IGlzSW5BdU9yTnooKSkpO1xuICAgICAgICBjYXNlICd0cnVzdHgnOlxuICAgICAgICAgICAgcmV0dXJuIGlzU3dpdGNoZWRPbigncHJlYmlkVHJ1c3R4JykgJiYgaXNJblVzT3JDYSgpO1xuICAgICAgICBjYXNlICd0dGQnOlxuICAgICAgICAgICAgcmV0dXJuIChpc1N3aXRjaGVkT24oJ3ByZWJpZFRoZVRyYWRlRGVzaycpICYmXG4gICAgICAgICAgICAgICAgZ2V0Q29uc2VudEZvcigndGhlVHJhZGVEZXNrJywgY29uc2VudFN0YXRlKSk7XG4gICAgICAgIGNhc2UgJ3hoYic6XG4gICAgICAgICAgICByZXR1cm4gKGlzU3dpdGNoZWRPbigncHJlYmlkWGF4aXMnKSAmJlxuICAgICAgICAgICAgICAgIGdldENvbnNlbnRGb3IoJ3hhbmRyJywgY29uc2VudFN0YXRlKSAmJlxuICAgICAgICAgICAgICAgIGlzSW5VaygpKTtcbiAgICB9XG59O1xuZXhwb3J0IGNvbnN0IHNob3VsZEluY2x1ZGVQZXJtdXRpdmUgPSAoY29uc2VudFN0YXRlKSA9PiBpc1N3aXRjaGVkT24oJ3Blcm11dGl2ZScpICYmXG4gICAgLyoqIHRoaXMgc3dpdGNoIHNwZWNpZmljYWxseSBjb250cm9scyB3aGV0aGVyIG9yIG5vdCB0aGUgUGVybXV0aXZlIEF1ZGllbmNlIENvbm5lY3RvciBjYW4gcnVuIHdpdGggUHJlYmlkICovXG4gICAgaXNTd2l0Y2hlZE9uKCdwcmViaWRQZXJtdXRpdmVBdWRpZW5jZScpICYmXG4gICAgZ2V0Q29uc2VudEZvcigncGVybXV0aXZlJywgY29uc2VudFN0YXRlKTtcbmV4cG9ydCBjb25zdCBzaG91bGRJbmNsdWRlTW9iaWxlU3RpY2t5ID0gb25jZSgoKSA9PiB3aW5kb3cubG9jYXRpb24uaGFzaC5pbmNsdWRlcygnI21vYmlsZS1zdGlja3knKSB8fFxuICAgIChtYXRjaGVzQnJlYWtwb2ludHMoe1xuICAgICAgICBtaW46ICdtb2JpbGUnLFxuICAgICAgICBtYXg6ICdtb2JpbGVMYW5kc2NhcGUnLFxuICAgIH0pICYmXG4gICAgICAgICFpc0luVWsoKSAmJlxuICAgICAgICBpc1ZhbGlkUGFnZUZvck1vYmlsZVN0aWNreSgpICYmXG4gICAgICAgICF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNIb3N0ZWQpKTtcbmV4cG9ydCBjb25zdCBzdHJpcE1vYmlsZVN1ZmZpeCA9IChzKSA9PiBzdHJpcFN1ZmZpeChzdHJpcFN1ZmZpeChzLCAnLS1tb2JpbGUnKSwgJ01vYmlsZScpO1xuZXhwb3J0IGNvbnN0IHN0cmlwVHJhaWxpbmdOdW1iZXJzQWJvdmUxID0gKHMpID0+IHN0cmlwU3VmZml4KHMsICcoWzItOV18XFxcXGR7Mix9KScpO1xuZXhwb3J0IGNvbnN0IGNvbnRhaW5zV1MgPSAoc2l6ZXMpID0+IGNvbnRhaW5zKHNpemVzLCBjcmVhdGVBZFNpemUoMTYwLCA2MDApKTtcbmV4cG9ydCBjb25zdCBzaG91bGRJbmNsdWRlT25seUE5ID0gd2luZG93LmxvY2F0aW9uLmhhc2guaW5jbHVkZXMoJyNvbmx5LWE5Jyk7XG4iLCJpbXBvcnQgeyBnZXRJZGVudGl0eUF1dGggfSBmcm9tICdAZ3VhcmRpYW4vaWRlbnRpdHktYXV0aC1mcm9udGVuZCc7XG5jb25zdCBnZXRBdXRoU3RhdHVzID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCBhY2Nlc3NUb2tlbiwgaWRUb2tlbiB9ID0gYXdhaXQgZ2V0SWRlbnRpdHlBdXRoKCkuaXNTaWduZWRJbldpdGhBdXRoU3RhdGUoKTtcbiAgICBpZiAoaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBraW5kOiAnU2lnbmVkSW4nLFxuICAgICAgICAgICAgYWNjZXNzVG9rZW4sXG4gICAgICAgICAgICBpZFRva2VuLFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBraW5kOiAnU2lnbmVkT3V0JyxcbiAgICB9O1xufTtcbmNvbnN0IGlzVXNlckxvZ2dlZEluID0gKCkgPT4gZ2V0SWRlbnRpdHlBdXRoKCkuaXNTaWduZWRJbigpO1xuLyoqXG4gKiBHZXQgdGhlIHVzZXIncyBHb29nbGUgVGFnIElEXG4gKlxuICogUmV0dXJucyB0aGUgdmFsdWUgZnJvbSB0aGUgSUQgdG9rZW4gYGdvb2dsZV90YWdfaWRgIGNsYWltXG4gKiBAcmV0dXJucyBvbmUgb2Y6XG4gKiAtIHN0cmluZyBpZiB0aGUgdXNlciBzaWduZWQgaW4gd2l0aCBPa3RhXG4gKiAtIG51bGwgaWYgdGhlIHVzZXIgaXMgc2lnbmVkIG91dFxuICovXG5jb25zdCBnZXRHb29nbGVUYWdJZCA9ICgpID0+IGdldEF1dGhTdGF0dXMoKS50aGVuKChhdXRoU3RhdHVzKSA9PiBhdXRoU3RhdHVzLmtpbmQgPT09ICdTaWduZWRJbidcbiAgICA/IGF1dGhTdGF0dXMuaWRUb2tlbi5jbGFpbXMuZ29vZ2xlX3RhZ19pZFxuICAgIDogbnVsbCk7XG5leHBvcnQgeyBnZXRBdXRoU3RhdHVzLCBpc1VzZXJMb2dnZWRJbiwgZ2V0R29vZ2xlVGFnSWQgfTtcbiIsImltcG9ydCB7IHBvc3RNZXNzYWdlIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9tZXNzZW5nZXIvcG9zdC1tZXNzYWdlJztcbmltcG9ydCB7IHJlcG9ydEVycm9yIH0gZnJvbSAnLi9lcnJvci9yZXBvcnQtZXJyb3InOyAvLyBLZWVwIHRoaXMgaW1wb3J0IHJlbGF0aXZlIG90aGVyd2lzZSBGcm9udGVuZCB3aWxsIG5vdCBiZSBhYmxlIHRvIGltcG9ydCB0aGlzIG1vZHVsZS4gVE9ETzogbW92ZSBhbGwgaW1wb3J0cyB0byByZWxhdGl2ZSBpbXBvcnRzXG5jb25zdCBMSVNURU5FUlMgPSB7fTtcbmxldCBSRUdJU1RFUkVEX0xJU1RFTkVSUyA9IDA7XG5jb25zdCBlcnJvcjQwNSA9IHtcbiAgICBjb2RlOiA0MDUsXG4gICAgbWVzc2FnZTogJ1NlcnZpY2UgJSUgbm90IGltcGxlbWVudGVkJyxcbn07XG5jb25zdCBlcnJvcjUwMCA9IHtcbiAgICBjb2RlOiA1MDAsXG4gICAgbWVzc2FnZTogJ0ludGVybmFsIHNlcnZlciBlcnJvclxcblxcbiUlJyxcbn07XG4vKipcbiAqIERldGVybWluZSBpZiBhbiB1bmtub3duIHBheWxvYWQgaGFzIHRoZSBzaGFwZSBvZiBhIHByb2dyYW1tYXRpYyBtZXNzYWdlXG4gKlxuICogQHBhcmFtIHBheWxvYWQgVGhlIHVua25vd24gbWVzc2FnZSBwYXlsb2FkXG4gKi9cbmNvbnN0IGlzUHJvZ3JhbW1hdGljTWVzc2FnZSA9IChwYXlsb2FkKSA9PiB7XG4gICAgY29uc3QgcGF5bG9hZFRvQ2hlY2sgPSBwYXlsb2FkO1xuICAgIHJldHVybiAocGF5bG9hZFRvQ2hlY2sudHlwZSA9PT0gJ3NldC1hZC1oZWlnaHQnICYmXG4gICAgICAgICgnaWQnIGluIHBheWxvYWRUb0NoZWNrLnZhbHVlIHx8ICdzbG90SWQnIGluIHBheWxvYWRUb0NoZWNrLnZhbHVlKSAmJlxuICAgICAgICAnaGVpZ2h0JyBpbiBwYXlsb2FkVG9DaGVjay52YWx1ZSk7XG59O1xuLyoqXG4gKiBDb252ZXJ0IGEgbGVnYWN5IHByb2dyYW1tYXRpYyBtZXNzYWdlIHRvIGEgc3RhbmRhcmQgbWVzc2FnZVxuICpcbiAqIE5vdGUgdGhhdCB0aGlzIG9ubHkgYXBwbGllcyB0byBzcGVjaWZpYyByZXNpemUgcHJvZ3JhbW1hdGljIG1lc3NhZ2VzXG4gKiAodGhlc2UgaW5jbHVkZSBzcGVjaWZpYyB3aWR0aCBhbmQgaGVpZ2h0IHZhbHVlcylcbiAqL1xuY29uc3QgdG9TdGFuZGFyZE1lc3NhZ2UgPSAocGF5bG9hZCkgPT4gKHtcbiAgICBpZDogJ2FhYWEwMDAwLWJiMTEtY2MyMi1kZDMzLWVlZWVlZTQ0NDQ0NCcsXG4gICAgdHlwZTogJ3Jlc2l6ZScsXG4gICAgaWZyYW1lSWQ6IHBheWxvYWQudmFsdWUuaWQsXG4gICAgc2xvdElkOiBwYXlsb2FkLnZhbHVlLnNsb3RJZCxcbiAgICB2YWx1ZToge1xuICAgICAgICBoZWlnaHQ6IHBheWxvYWQudmFsdWUuaGVpZ2h0LFxuICAgICAgICB3aWR0aDogcGF5bG9hZC52YWx1ZS53aWR0aCxcbiAgICB9LFxufSk7XG4vKipcbiAqIFJldHJpZXZlIGEgcmVmZXJlbmNlIHRvIHRoZSBjYWxsaW5nIGlGcmFtZVxuICpcbiAqIEF0dGVtcHRzIHRoZSBmb2xsb3dpbmcgc3RyYXRlZ2llcyB0byBmaW5kIHRoZSBjb3JyZWN0IGlmcmFtZTpcbiAqIC0gdXNpbmcgdGhlIHNsb3RJZCBmcm9tIHRoZSBpbmNvbWluZyBtZXNzYWdlXG4gKiAtIHVzaW5nIHRoZSBpZnJhbWVJZCBmcm9tIHRoZSBpbmNvbWluZyBtZXNzYWdlXG4gKiAtIGNoZWNraW5nIG1lc3NhZ2UgZXZlbnQuc291cmNlIChpLmUuIHdpbmRvdykgYWdhaW5zdCBhbGwgcGFnZSBsZXZlbCBpZnJhbWUgY29udGVudFdpbmRvd3NcbiAqXG4gKiBMaXN0ZW5lcnMgY2FuIHRoZW4gdXNlIHRoZSBpRnJhbWUgdG8gZGV0ZXJtaW5lIHRoZSBzbG90IG1ha2luZyB0aGUgcG9zdE1lc3NhZ2UgY2FsbFxuICovXG5jb25zdCBnZXRJZnJhbWUgPSAobWVzc2FnZSwgbWVzc2FnZUV2ZW50U291cmNlKSA9PiB7XG4gICAgaWYgKG1lc3NhZ2Uuc2xvdElkKSB7XG4gICAgICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKGBkZnAtYWQtLSR7bWVzc2FnZS5zbG90SWR9YCk7XG4gICAgICAgIHJldHVybiBjb250YWluZXI/LnF1ZXJ5U2VsZWN0b3IoJ2lmcmFtZScpID8/IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgZWxzZSBpZiAobWVzc2FnZS5pZnJhbWVJZCkge1xuICAgICAgICBjb25zdCBlbCA9IGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKG1lc3NhZ2UuaWZyYW1lSWQpO1xuICAgICAgICByZXR1cm4gZWwgaW5zdGFuY2VvZiBIVE1MSUZyYW1lRWxlbWVudCA/IGVsIDogdW5kZWZpbmVkO1xuICAgIH1cbiAgICBlbHNlIGlmIChtZXNzYWdlRXZlbnRTb3VyY2UpIHtcbiAgICAgICAgY29uc3QgaWZyYW1lcyA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoJ2lmcmFtZScpO1xuICAgICAgICByZXR1cm4gQXJyYXkuZnJvbShpZnJhbWVzKS5maW5kKChpZnJhbWUpID0+IGlmcmFtZS5jb250ZW50V2luZG93ID09PSBtZXNzYWdlRXZlbnRTb3VyY2UpO1xuICAgIH1cbn07XG4vLyBSZWdleCBmb3IgdGVzdGluZyB2YWxpZGl0eSBvZiBtZXNzYWdlIGlkc1xuY29uc3QgdmFsaWRNZXNzYWdlUmVnZXggPSAvXlthLWYwLTldezh9LShbYS1mMC05XXs0fS0pezN9W2EtZjAtOV17MTJ9JC87XG4vKipcbiAqIE5hcnJvdyBhbiBgdW5rbm93bmAgcGF5bG9hZCB0byB0aGUgc3RhbmRhcmQgbWVzc2FnZSBmb3JtYXRcbiAqXG4gKiBVbnRpbCBERlAgcHJvdmlkZXMgYSB3YXkgZm9yIHVzIHRvIGlkZW50aWZ5IHdpdGggMTAwJSBjZXJ0YWludHkgb3VyXG4gKiBpbi1ob3VzZSBjcmVhdGl2ZXMsIHdlIGFyZSBsZWZ0IHdpdGggZG9pbmcgc29tZSBiYXNpYyB0ZXN0c1xuICogc3VjaCBhcyB2YWxpZGF0aW5nIHRoZSBhbmF0b215IG9mIHRoZSBwYXlsb2FkIGFuZCB3aGl0ZWxpc3RpbmdcbiAqIGV2ZW50IHR5cGVcbiAqL1xuY29uc3QgaXNWYWxpZFBheWxvYWQgPSAocGF5bG9hZCkgPT4ge1xuICAgIGNvbnN0IHBheWxvYWRUb0NoZWNrID0gcGF5bG9hZDtcbiAgICByZXR1cm4gKCd0eXBlJyBpbiBwYXlsb2FkVG9DaGVjayAmJlxuICAgICAgICAndmFsdWUnIGluIHBheWxvYWRUb0NoZWNrICYmXG4gICAgICAgICdpZCcgaW4gcGF5bG9hZFRvQ2hlY2sgJiZcbiAgICAgICAgcGF5bG9hZFRvQ2hlY2sudHlwZSBpbiBMSVNURU5FUlMgJiZcbiAgICAgICAgdmFsaWRNZXNzYWdlUmVnZXgudGVzdChwYXlsb2FkVG9DaGVjay5pZCkpO1xufTtcbi8qKlxuICogQ2hlYXAgc3RyaW5nIGZvcm1hdHRpbmcgZnVuY3Rpb25cbiAqXG4gKiBAcGFyYW0gZXJyb3IgQW4gb2JqZWN0IGB7IGNvZGUsIG1lc3NhZ2UgfWAuIGBtZXNzYWdlYCBpcyBhIHN0cmluZyB3aGVyZSBzdWNjZXNzaXZlXG4gKiBvY2N1cnJlbmNlcyBvZiAlJSB3aWxsIGJlIHJlcGxhY2VkIGJ5IHRoZSBmb2xsb3dpbmcgYXJndW1lbnRzXG4gKiBAcGFyYW0gYXJncyBBcmd1bWVudHMgdGhhdCB3aWxsIHJlcGxhY2UgJSVcbiAqXG4gKiBAZXhhbXBsZVxuICogZm9ybWF0RXJyb3IoeyBtZXNzYWdlOiBcIiUlLCB5b3UgYXJlIHNvICUlXCIgfSwgXCJSZWdpc1wiLCBcImxvdmVseVwiKVxuICogPT4geyBtZXNzYWdlOiBcIlJlZ2lzLCB5b3UgYXJlIHNvIGxvdmVseVwiIH1cbiAqL1xuY29uc3QgZm9ybWF0RXJyb3IgPSAoZXJyb3IsIC4uLmFyZ3MpID0+IGFyZ3MucmVkdWNlKChlLCBhcmcpID0+IHtcbiAgICBlLm1lc3NhZ2UgPSBlLm1lc3NhZ2UucmVwbGFjZSgnJSUnLCBhcmcpO1xuICAgIHJldHVybiBlO1xufSwgZXJyb3IpO1xuLyoqXG4gKiBDb252ZXJ0IGEgcG9zdGVkIG1lc3NhZ2UgdG8gb3VyIFN0YW5kYXJkTWVzc2FnZSBmb3JtYXRcbiAqXG4gKiBAcGFyYW0gZXZlbnQgVGhlIG1lc3NhZ2UgZXZlbnQgcmVjZWl2ZWQgb24gdGhlIHdpbmRvd1xuICogQHJldHVybnMgQSBtZXNzYWdlIHdpdGggdGhlIGBTdGFuZGFyZE1lc3NhZ2VgIGZvcm1hdCwgb3IgbnVsbCBpZiB0aGUgY29udmVyc2lvbiB3YXMgdW5zdWNjZXNzZnVsXG4gKi9cbmNvbnN0IGV2ZW50VG9TdGFuZGFyZE1lc3NhZ2UgPSAoZXZlbnQpID0+IHtcbiAgICB0cnkge1xuICAgICAgICAvLyBDdXJyZW50bHkgYWxsIG5vbi1zdHJpbmcgbWVzc2FnZXMgYXJlIGRpc2NhcmRlZCBoZXJlIHNpbmNlIHBhcnNpbmcgdGhyb3dzIGFuIGVycm9yXG4gICAgICAgIC8vIFRPRE8gUmV2aWV3IHdoZXRoZXIgdGhpcyBpcyB0aGUgZGVzaXJlZCBvdXRjb21lXG4gICAgICAgIGNvbnN0IGRhdGEgPSBKU09OLnBhcnNlKGV2ZW50LmRhdGEpO1xuICAgICAgICBjb25zdCBtZXNzYWdlID0gaXNQcm9ncmFtbWF0aWNNZXNzYWdlKGRhdGEpXG4gICAgICAgICAgICA/IHRvU3RhbmRhcmRNZXNzYWdlKGRhdGEpXG4gICAgICAgICAgICA6IGRhdGE7XG4gICAgICAgIGlmIChpc1ZhbGlkUGF5bG9hZChtZXNzYWdlKSkge1xuICAgICAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGV4KSB7XG4gICAgICAgIC8vIERvIG5vdGhpbmdcbiAgICB9XG59O1xuLyoqXG4gKiBSZXNwb25kIHRvIHRoZSBvcmlnaW5hbCBpZnJhbWUgd2l0aCB0aGUgcmVzdWx0IG9mIGNhbGxpbmcgdGhlXG4gKiBwZXJzaXN0ZW50IGxpc3RlbmVyIC8gbGlzdGVuZXIgY2hhaW5cbiAqL1xuY29uc3QgcmVzcG9uZCA9IChpZCwgdGFyZ2V0LCBlcnJvciwgcmVzdWx0KSA9PiB7XG4gICAgcG9zdE1lc3NhZ2Uoe1xuICAgICAgICBpZCxcbiAgICAgICAgZXJyb3IsXG4gICAgICAgIHJlc3VsdCxcbiAgICB9LCB0YXJnZXQgPz8gd2luZG93KTtcbn07XG4vKipcbiAqIENhbGxiYWNrIHRoYXQgaXMgZmlyZWQgd2hlbiBhbiBhcmJpdHJhcnkgbWVzc2FnZSBpcyByZWNlaXZlZCBvbiB0aGUgd2luZG93XG4gKlxuICogQHBhcmFtIGV2ZW50IFRoZSBtZXNzYWdlIGV2ZW50IHJlY2VpdmVkIG9uIHRoZSB3aW5kb3dcbiAqL1xuY29uc3Qgb25NZXNzYWdlID0gYXN5bmMgKGV2ZW50KSA9PiB7XG4gICAgY29uc3QgbWVzc2FnZSA9IGV2ZW50VG9TdGFuZGFyZE1lc3NhZ2UoZXZlbnQpO1xuICAgIGlmICghbWVzc2FnZSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGxpc3RlbmVyID0gTElTVEVORVJTW21lc3NhZ2UudHlwZV07XG4gICAgaWYgKEFycmF5LmlzQXJyYXkobGlzdGVuZXIpICYmIGxpc3RlbmVyLmxlbmd0aCkge1xuICAgICAgICAvLyBCZWNhdXNlIGFueSBsaXN0ZW5lciBjYW4gaGF2ZSBzaWRlLWVmZmVjdHMgKGJ5IHVucmVnaXN0ZXJpbmcgaXRzZWxmKSxcbiAgICAgICAgLy8gd2UgcnVuIHRoZSBwcm9taXNlIGNoYWluIG9uIGEgY29weSBvZiB0aGUgYExJU1RFTkVSU2AgYXJyYXkuXG4gICAgICAgIC8vIEhhdCB0aXAgQHBpdWNjaW9cbiAgICAgICAgY29uc3QgcHJvbWlzZSA9IFxuICAgICAgICAvLyBXZSBvZmZlciwgYnV0IGRvbid0IGltcG9zZSwgdGhlIHBvc3NpYmlsaXR5IHRoYXQgYSBsaXN0ZW5lciByZXR1cm5zXG4gICAgICAgIC8vIGEgdmFsdWUgdGhhdCBtdXN0IGJlIHNlbnQgYmFjayB0byB0aGUgY2FsbGluZyBmcmFtZS4gVG8gZG8gdGhpcyxcbiAgICAgICAgLy8gd2UgcGFzcyB0aGUgY3VtdWxhdGVkIHJldHVybmVkIHZhbHVlIGFzIGEgc2Vjb25kIGFyZ3VtZW50IHRvIGVhY2hcbiAgICAgICAgLy8gbGlzdGVuZXIuIE5vdGljZSB3ZSBkb24ndCB0cnkgc29tZSBjbGV2ZXIgd2F5IHRvIGNvbXBvc2UgdGhlIHJlc3VsdFxuICAgICAgICAvLyB2YWx1ZSBvdXJzZWx2ZXMsIHRoaXMgd291bGQgb25seSBtYWtlIHRoZSBzb2x1dGlvbiBtb3JlIGNvbXBsZXguXG4gICAgICAgIC8vIFRoYXQgbWVhbnMgYSBsaXN0ZW5lciBjYW4gaWdub3JlIHRoZSBjdW11bGF0ZWQgcmV0dXJuIHZhbHVlIGFuZFxuICAgICAgICAvLyByZXR1cm4gc29tZXRoaW5nIGVsc2UgZW50aXJlbHnigJRsaWZlIGlzIHVuZmFpci5cbiAgICAgICAgLy8gV2UgZG9uJ3Qga25vdyB3aGF0IGVhY2ggY2FsbGFjayB3aWxsIGJlIG1hZGUgb2YsIHdlIGRvbid0IHdhbnQgdG8uXG4gICAgICAgIC8vIEFuZCBzbyB3ZSB3cmFwIGVhY2ggY2FsbCBpbiBhIHByb21pc2UgY2hhaW4sIGluIGNhc2Ugb25lIGRyb3BzIHRoZVxuICAgICAgICAvLyBvY2Nhc2lvbmFsIGZhc3Rkb20gYm9tYiBpbiB0aGUgbWlkZGxlLlxuICAgICAgICBsaXN0ZW5lci5yZWR1Y2UoKGZ1bmMsIGxpc3RlbmVyKSA9PiBmdW5jLnRoZW4oKHJldCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgdGhpc1JldCA9IGxpc3RlbmVyKG1lc3NhZ2UudmFsdWUsIHJldCwgZ2V0SWZyYW1lKG1lc3NhZ2UsIGV2ZW50LnNvdXJjZSkpO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXNSZXQgPT09IHVuZGVmaW5lZCA/IHJldCA6IHRoaXNSZXQ7XG4gICAgICAgIH0pLCBQcm9taXNlLnJlc29sdmUoKSk7XG4gICAgICAgIHJldHVybiBwcm9taXNlXG4gICAgICAgICAgICAudGhlbigocmVzcG9uc2UpID0+IHtcbiAgICAgICAgICAgIHJlc3BvbmQobWVzc2FnZS5pZCwgZXZlbnQuc291cmNlLCBudWxsLCByZXNwb25zZSk7XG4gICAgICAgIH0pXG4gICAgICAgICAgICAuY2F0Y2goKGV4KSA9PiB7XG4gICAgICAgICAgICByZXBvcnRFcnJvcihleCwgJ25hdGl2ZS1hZHMnKTtcbiAgICAgICAgICAgIHJlc3BvbmQobWVzc2FnZS5pZCwgZXZlbnQuc291cmNlLCBmb3JtYXRFcnJvcihlcnJvcjUwMCwgZXgudG9TdHJpbmcoKSksIG51bGwpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSBpZiAodHlwZW9mIGxpc3RlbmVyID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIFdlIGZvdW5kIGEgcGVyc2lzdGVudCBsaXN0ZW5lciwgdG8gd2hpY2ggd2UganVzdCBkZWxlZ2F0ZVxuICAgICAgICAvLyByZXNwb25zaWJpbGl0eSB0byB3cml0ZSBzb21ldGhpbmcuIEFueXRoaW5nLiBSZWFsbHkuXG4gICAgICAgIC8vIFRoZSBsaXN0ZW5lciB3cml0ZXMgc29tZXRoaW5nIGJ5IGJlaW5nIGdpdmVuIHRoZSBgcmVzcG9uZGAgZnVuY3Rpb24gYXMgdGhlIHNwZWNcbiAgICAgICAgbGlzdGVuZXIoXG4gICAgICAgIC8vIFRPRE8gY2hhbmdlIHRoZSBhcmd1bWVudHMgZXhwZWN0ZWQgYnkgcGVyc2lzdGVudCBsaXN0ZW5lcnMgdG8gYXZvaWQgdGhpc1xuICAgICAgICAoZXJyb3IsIHJlc3VsdCkgPT4gcmVzcG9uZChtZXNzYWdlLmlkLCBldmVudC5zb3VyY2UsIGVycm9yLCByZXN1bHQpLCBtZXNzYWdlLnZhbHVlLCBnZXRJZnJhbWUobWVzc2FnZSwgZXZlbnQuc291cmNlKSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICAvLyBJZiB0aGVyZSBpcyBubyByb3V0aW5lIGF0dGFjaGVkIHRvIHRoaXMgZXZlbnQgdHlwZSwgd2UganVzdCBhbnN3ZXJcbiAgICAgICAgLy8gd2l0aCBhbiBlcnJvciBjb2RlXG4gICAgICAgIHJlc3BvbmQobWVzc2FnZS5pZCwgZXZlbnQuc291cmNlLCBmb3JtYXRFcnJvcihlcnJvcjQwNSwgbWVzc2FnZS50eXBlKSwgbnVsbCk7XG4gICAgfVxufTtcbmNvbnN0IG9uID0gKHdpbmRvdykgPT4ge1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKGV2ZW50KSA9PiB2b2lkIG9uTWVzc2FnZShldmVudCkpO1xufTtcbmNvbnN0IG9mZiA9ICh3aW5kb3cpID0+IHtcbiAgICB3aW5kb3cucmVtb3ZlRXZlbnRMaXN0ZW5lcignbWVzc2FnZScsIChldmVudCkgPT4gdm9pZCBvbk1lc3NhZ2UoZXZlbnQpKTtcbn07XG4vKipcbiAqIFJlZ2lzdGVyIGEgbGlzdGVuZXIgZm9yIGEgZ2l2ZW4gdHlwZSBvZiBpZnJhbWUgbWVzc2FnZVxuICpcbiAqIEBwYXJhbSB0eXBlIFRoZSBgdHlwZWAgb2YgbWVzc2FnZSB0byByZWdpc3RlciBhZ2FpbnN0XG4gKiBAcGFyYW0gY2FsbGJhY2sgVGhlIGxpc3RlbmVyIGNhbGxiYWNrIHRvIHJlZ2lzdGVyIHRoYXQgd2lsbCByZWNlaXZlIG1lc3NhZ2VzIG9mIHRoZSBnaXZlbiB0eXBlXG4gKiBAcGFyYW0gb3B0aW9ucyBPcHRpb25zIGZvciB0aGUgdGFyZ2V0IHdpbmRvd1xuICovXG5leHBvcnQgY29uc3QgcmVnaXN0ZXIgPSAodHlwZSwgY2FsbGJhY2ssIG9wdGlvbnMpID0+IHtcbiAgICBpZiAoUkVHSVNURVJFRF9MSVNURU5FUlMgPT09IDApIHtcbiAgICAgICAgb24ob3B0aW9ucz8ud2luZG93ID8/IHdpbmRvdyk7XG4gICAgfVxuICAgIGNvbnN0IGxpc3RlbmVycyA9IExJU1RFTkVSU1t0eXBlXSA/PyBbXTtcbiAgICBpZiAoQXJyYXkuaXNBcnJheShsaXN0ZW5lcnMpICYmICFsaXN0ZW5lcnMuaW5jbHVkZXMoY2FsbGJhY2spKSB7XG4gICAgICAgIExJU1RFTkVSU1t0eXBlXSA9IFsuLi5saXN0ZW5lcnMsIGNhbGxiYWNrXTtcbiAgICAgICAgUkVHSVNURVJFRF9MSVNURU5FUlMgKz0gMTtcbiAgICB9XG59O1xuLyoqXG4gKiBSZWdpc3RlciBhIHBlcnNpc3RlbnQgbGlzdGVuZXIgZm9yIGEgZ2l2ZW4gdHlwZSBvZiBpZnJhbWUgbWVzc2FnZVxuICpcbiAqIEBwYXJhbSB0eXBlIFRoZSBgdHlwZWAgb2YgbWVzc2FnZSB0byByZWdpc3RlciBhZ2FpbnN0XG4gKiBAcGFyYW0gY2FsbGJhY2sgVGhlIHBlcnNpc3RlbnQgbGlzdGVuZXIgY2FsbGJhY2sgdG8gcmVnaXN0ZXIgdGhhdCB3aWxsIHJlY2VpdmUgbWVzc2FnZXMgb2YgdGhlIGdpdmVuIHR5cGVcbiAqIEBwYXJhbSBvcHRpb25zIE9wdGlvbnMgZm9yIHRoZSB0YXJnZXQgd2luZG93IGFuZCB3aGV0aGVyIHRoZSBjYWxsYmFjayBpcyBwZXJzaXN0ZW50XG4gKi9cbmV4cG9ydCBjb25zdCByZWdpc3RlclBlcnNpc3RlbnRMaXN0ZW5lciA9ICh0eXBlLCBjYWxsYmFjaywgb3B0aW9ucykgPT4ge1xuICAgIGlmIChSRUdJU1RFUkVEX0xJU1RFTkVSUyA9PT0gMCkge1xuICAgICAgICBvbihvcHRpb25zPy53aW5kb3cgPz8gd2luZG93KTtcbiAgICB9XG4gICAgTElTVEVORVJTW3R5cGVdID0gY2FsbGJhY2s7XG4gICAgUkVHSVNURVJFRF9MSVNURU5FUlMgKz0gMTtcbn07XG4vKipcbiAqIFVucmVnaXN0ZXIgYSBjYWxsYmFjayBmb3IgYSBnaXZlbiB0eXBlXG4gKlxuICogQHBhcmFtIHR5cGUgVGhlIHR5cGUgb2YgbWVzc2FnZSB0byB1bnJlZ2lzdGVyIGFnYWluc3QuIEFuIGlmcmFtZSB3aWxsIHNlbmRcbiAqIG1lc3NhZ2VzIGFubm90YXRlZCB3aXRoIHRoZSB0eXBlXG4gKiBAcGFyYW0gY2FsbGJhY2sgT3B0aW9uYWxseSBpbmNsdWRlIHRoZSBvcmlnaW5hbCBjYWxsYmFjay4gSWYgdGhpcyBpcyBpbmNsdWRlZFxuICogZm9yIGEgcGVyc2lzdGVudCBjYWxsYmFjayB0aGlzIGZ1bmN0aW9uIHdpbGwgYmUgdW5yZWdpc3RlcmVkLiBJZiBpdCdzXG4gKiBpbmNsdWRlZCBmb3IgYSBub24tcGVyc2lzdGVudCBjYWxsYmFjayBvbmx5IHRoZSBtYXRjaGluZyBjYWxsYmFjayBpcyByZW1vdmVkLFxuICogb3RoZXJ3aXNlIGFsbCBjYWxsYmFja3MgZm9yIHRoYXQgdHlwZSB3aWxsIGJlIHVucmVnaXN0ZXJlZFxuICogQHBhcmFtIG9wdGlvbnMgT3B0aW9uIGZvciB0aGUgdGFyZ2V0IHdpbmRvd1xuICovXG5leHBvcnQgY29uc3QgdW5yZWdpc3RlciA9ICh0eXBlLCBjYWxsYmFjaywgb3B0aW9ucykgPT4ge1xuICAgIGNvbnN0IGxpc3RlbmVycyA9IExJU1RFTkVSU1t0eXBlXTtcbiAgICBpZiAobGlzdGVuZXJzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGZvcm1hdEVycm9yKGVycm9yNDA1LCB0eXBlKS5tZXNzYWdlKTtcbiAgICB9XG4gICAgZWxzZSBpZiAobGlzdGVuZXJzID09PSBjYWxsYmFjaykge1xuICAgICAgICBMSVNURU5FUlNbdHlwZV0gPSB1bmRlZmluZWQ7XG4gICAgICAgIFJFR0lTVEVSRURfTElTVEVORVJTIC09IDE7XG4gICAgfVxuICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkobGlzdGVuZXJzKSkge1xuICAgICAgICBpZiAoY2FsbGJhY2sgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgTElTVEVORVJTW3R5cGVdID0gW107XG4gICAgICAgICAgICBSRUdJU1RFUkVEX0xJU1RFTkVSUyAtPSBsaXN0ZW5lcnMubGVuZ3RoO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgTElTVEVORVJTW3R5cGVdID0gbGlzdGVuZXJzLmZpbHRlcigoY2IpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBjYWxsYmFja3NFcXVhbCA9IGNiID09PSBjYWxsYmFjaztcbiAgICAgICAgICAgICAgICBpZiAoY2FsbGJhY2tzRXF1YWwpIHtcbiAgICAgICAgICAgICAgICAgICAgUkVHSVNURVJFRF9MSVNURU5FUlMgLT0gMTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuICFjYWxsYmFja3NFcXVhbDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfVxuICAgIGlmIChSRUdJU1RFUkVEX0xJU1RFTkVSUyA9PT0gMCkge1xuICAgICAgICBvZmYob3B0aW9ucz8ud2luZG93ID8/IHdpbmRvdyk7XG4gICAgfVxufTtcbi8qKlxuICogSW5pdGlhbGl6ZSBhbiBhcnJheSBvZiBsaXN0ZW5lciBjYWxsYmFja3MgaW4gYSBiYXRjaFxuICpcbiAqIEBwYXJhbSBsaXN0ZW5lcnMgVGhlIGxpc3RlbmVyIHJlZ2lzdHJhdGlvbiBmdW5jdGlvbnNcbiAqIEBwYXJhbSBwZXJzaXN0ZW50TGlzdGVuZXJzIFRoZSBwZXJzaXN0ZW50IGxpc3RlbmVyIHJlZ2lzdHJhdGlvbiBmdW5jdGlvbnNcbiAqL1xuZXhwb3J0IGNvbnN0IGluaXQgPSAobGlzdGVuZXJzLCBwZXJzaXN0ZW50TGlzdGVuZXJzKSA9PiB7XG4gICAgbGlzdGVuZXJzLmZvckVhY2goKG1vZHVsZUluaXQpID0+IG1vZHVsZUluaXQocmVnaXN0ZXIpKTtcbiAgICBwZXJzaXN0ZW50TGlzdGVuZXJzLmZvckVhY2goKG1vZHVsZUluaXQpID0+IG1vZHVsZUluaXQocmVnaXN0ZXJQZXJzaXN0ZW50TGlzdGVuZXIpKTtcbn07XG5leHBvcnQgY29uc3QgXyA9IHsgb25NZXNzYWdlIH07XG4iLCJpbXBvcnQgeyBpc09iamVjdCB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IHJlbmRlckFkdmVydExhYmVsLCByZW5kZXJTdGlja3lTY3JvbGxGb3JNb3JlTGFiZWwsIH0gZnJvbSAnLi4vLi4vZXZlbnRzL3JlbmRlci1hZHZlcnQtbGFiZWwnO1xuaW1wb3J0IHsgZ2V0QWR2ZXJ0QnlJZCB9IGZyb20gJy4uL2RmcC9nZXQtYWR2ZXJ0LWJ5LWlkJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uL2Zhc3Rkb20tcHJvbWlzZSc7XG5pbXBvcnQgeyBzZW5kUHJvZ3Jlc3NPblVubG9hZE9uY2UsIHVwZGF0ZVZpZGVvUHJvZ3Jlc3MsIH0gZnJvbSAnLi4vdmlkZW8tcHJvZ3Jlc3MtcmVwb3J0aW5nJztcbmNvbnN0IGlzR2FsbGVyeSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5jb250ZW50VHlwZSA9PT0gJ0dhbGxlcnknO1xuY29uc3QgSU5URVJTQ1JPTExFUl9URU1QTEFURV9JRCA9IDExODg1NjY3O1xuY29uc3QgZ2V0U3R5bGVzRnJvbVNwZWMgPSAoc3BlY3MpID0+IHtcbiAgICBjb25zdCBzdHlsZXMgPSB7IC4uLnNwZWNzIH07XG4gICAgZGVsZXRlIHN0eWxlcy5zY3JvbGxUeXBlO1xuICAgIGRlbGV0ZSBzdHlsZXMuY3RhVXJsO1xuICAgIGRlbGV0ZSBzdHlsZXMudmlkZW9Tb3VyY2U7XG4gICAgLy8gbmF0aXZlIHRlbXBsYXRlcyBhcmUgc29tZXRpbWVzIHVzaW5nIHRoZSBicml0aXNoIHNwZWxsaW5nIG9mIGJhY2tncm91bmQtY29sb3IgZm9yIHNvbWUgcmVhc29uXG4gICAgaWYgKHN0eWxlcy5iYWNrZ3JvdW5kQ29sb3VyKSB7XG4gICAgICAgIHN0eWxlcy5iYWNrZ3JvdW5kQ29sb3IgPSBzdHlsZXMuYmFja2dyb3VuZENvbG91cjtcbiAgICAgICAgZGVsZXRlIHN0eWxlcy5iYWNrZ3JvdW5kQ29sb3VyO1xuICAgIH1cbiAgICByZXR1cm4gc3R5bGVzO1xufTtcbmNvbnN0IGlzQmFja2dyb3VuZFNwZWNzID0gKHNwZWNzKSA9PiBpc09iamVjdChzcGVjcykgJiYgJ2JhY2tncm91bmRJbWFnZScgaW4gc3BlY3M7XG5jb25zdCBjcmVhdGVQYXJlbnQgPSAoYWRTbG90LCBzY3JvbGxUeXBlKSA9PiB7XG4gICAgbGV0IGJhY2tncm91bmRQYXJlbnQgPSBhZFNsb3QucXVlcnlTZWxlY3RvcignLmNyZWF0aXZlX19iYWNrZ3JvdW5kLXBhcmVudCcpO1xuICAgIGxldCBiYWNrZ3JvdW5kID0gYWRTbG90LnF1ZXJ5U2VsZWN0b3IoJy5jcmVhdGl2ZV9fYmFja2dyb3VuZCcpO1xuICAgIGlmICghYmFja2dyb3VuZFBhcmVudCB8fCAhYmFja2dyb3VuZCkge1xuICAgICAgICBiYWNrZ3JvdW5kUGFyZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgIGJhY2tncm91bmQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgYmFja2dyb3VuZFBhcmVudC5jbGFzc0xpc3QuYWRkKCdjcmVhdGl2ZV9fYmFja2dyb3VuZC1wYXJlbnQnKTtcbiAgICAgICAgYmFja2dyb3VuZC5jbGFzc0xpc3QuYWRkKCdjcmVhdGl2ZV9fYmFja2dyb3VuZCcpO1xuICAgICAgICBpZiAoc2Nyb2xsVHlwZSkge1xuICAgICAgICAgICAgYmFja2dyb3VuZFBhcmVudC5jbGFzc0xpc3QuYWRkKGBjcmVhdGl2ZV9fYmFja2dyb3VuZC1wYXJlbnQtLSR7c2Nyb2xsVHlwZX1gKTtcbiAgICAgICAgICAgIGJhY2tncm91bmQuY2xhc3NMaXN0LmFkZChgY3JlYXRpdmVfX2JhY2tncm91bmQtLSR7c2Nyb2xsVHlwZX1gKTtcbiAgICAgICAgfVxuICAgICAgICBiYWNrZ3JvdW5kUGFyZW50LmFwcGVuZENoaWxkKGJhY2tncm91bmQpO1xuICAgICAgICBiYWNrZ3JvdW5kUGFyZW50LnN0eWxlLnpJbmRleCA9ICctMSc7XG4gICAgICAgIGJhY2tncm91bmRQYXJlbnQuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnO1xuICAgICAgICBiYWNrZ3JvdW5kUGFyZW50LnN0eWxlLmluc2V0ID0gJzAnO1xuICAgICAgICBiYWNrZ3JvdW5kUGFyZW50LnN0eWxlLmNsaXBQYXRoID1cbiAgICAgICAgICAgICdwb2x5Z29uKDAlIDAlLCAxMDAlIDAlLCAxMDAlIDEwMCUsIDAlIDEwMCUpJztcbiAgICAgICAgYmFja2dyb3VuZFBhcmVudC5zdHlsZS5vdmVyZmxvdyA9ICdoaWRkZW4nO1xuICAgICAgICBiYWNrZ3JvdW5kLnN0eWxlLmluc2V0ID0gJzAnO1xuICAgICAgICBiYWNrZ3JvdW5kLnN0eWxlLnRyYW5zaXRpb24gPSAnYmFja2dyb3VuZCAxMDBtcyBlYXNlJztcbiAgICAgICAgaWYgKHNjcm9sbFR5cGUgPT09ICdpbnRlcnNjcm9sbGVyJykge1xuICAgICAgICAgICAgYmFja2dyb3VuZC5zdHlsZS5oZWlnaHQgPSAnMTAwdmgnO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiB7IGJhY2tncm91bmRQYXJlbnQsIGJhY2tncm91bmQgfTtcbn07XG5jb25zdCBzZXRCYWNrZ3JvdW5kU3R5bGVzID0gKHNwZWNzLCBiYWNrZ3JvdW5kKSA9PiB7XG4gICAgY29uc3Qgc3BlY1N0eWxlcyA9IGdldFN0eWxlc0Zyb21TcGVjKHNwZWNzKTtcbiAgICBPYmplY3QuYXNzaWduKGJhY2tncm91bmQuc3R5bGUsIHNwZWNTdHlsZXMpO1xufTtcbmNvbnN0IHNldEN0YVVSTCA9IChjdGFVUkwsIGJhY2tncm91bmRQYXJlbnQpID0+IHtcbiAgICBjb25zdCBjdGFVUkxBbmNob3IgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdhJyk7XG4gICAgY3RhVVJMQW5jaG9yLmhyZWYgPSBjdGFVUkw7XG4gICAgY3RhVVJMQW5jaG9yLnRhcmdldCA9ICdfbmV3JztcbiAgICBjdGFVUkxBbmNob3IuYXBwZW5kQ2hpbGQoYmFja2dyb3VuZFBhcmVudCk7XG4gICAgY3RhVVJMQW5jaG9yLnN0eWxlLndpZHRoID0gJzEwMCUnO1xuICAgIGN0YVVSTEFuY2hvci5zdHlsZS5oZWlnaHQgPSAnMTAwJSc7XG4gICAgY3RhVVJMQW5jaG9yLnN0eWxlLmRpc3BsYXkgPSAnaW5saW5lLWJsb2NrJztcbiAgICByZXR1cm4gY3RhVVJMQW5jaG9yO1xufTtcbmNvbnN0IHJlbmRlckJvdHRvbUxpbmUgPSAoYmFja2dyb3VuZCwgYmFja2dyb3VuZFBhcmVudCwgaXNHYWxsZXJ5KSA9PiB7XG4gICAgYmFja2dyb3VuZC5zdHlsZS5wb3NpdGlvbiA9ICdmaXhlZCc7XG4gICAgY29uc3QgYm90dG9tTGluZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGJvdHRvbUxpbmUuY2xhc3NMaXN0LmFkZCgnYWQtc2xvdF9fbGluZScpO1xuICAgIGJvdHRvbUxpbmUuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnO1xuICAgIGJvdHRvbUxpbmUuc3R5bGUud2lkdGggPSAnMTAwJSc7XG4gICAgYm90dG9tTGluZS5zdHlsZS5ib3R0b20gPSAnMCc7XG4gICAgaWYgKGlzR2FsbGVyeSkge1xuICAgICAgICBib3R0b21MaW5lLnN0eWxlLmJvcmRlckJvdHRvbSA9ICcxcHggc29saWQgIzMzMzMzMyc7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBib3R0b21MaW5lLnN0eWxlLmJvcmRlckJvdHRvbSA9ICcxcHggc29saWQgI2RjZGNkYyc7XG4gICAgfVxuICAgIGJhY2tncm91bmRQYXJlbnQuYXBwZW5kQ2hpbGQoYm90dG9tTGluZSk7XG59O1xuY29uc3Qgc2V0dXBQYXJhbGxheCA9IChhZFNsb3QsIGJhY2tncm91bmQsIGJhY2tncm91bmRQYXJlbnQpID0+IHtcbiAgICBiYWNrZ3JvdW5kLnN0eWxlLnBvc2l0aW9uID0gJ2Fic29sdXRlJztcbiAgICBhZFNsb3Quc3R5bGUucG9zaXRpb24gPSAncmVsYXRpdmUnO1xuICAgIGNvbnN0IG9uU2Nyb2xsID0gKGJhY2tncm91bmQpID0+IGZhc3Rkb21cbiAgICAgICAgLm1lYXN1cmUoKCkgPT4gYmFja2dyb3VuZC5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKSlcbiAgICAgICAgLnRoZW4oKHJlY3QpID0+IGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgY29uc3QgYmFja2dyb3VuZEhlaWdodCA9IHJlY3QuaGVpZ2h0O1xuICAgICAgICBjb25zdCB3aW5kb3dIZWlnaHQgPSB3aW5kb3cuaW5uZXJIZWlnaHQ7XG4gICAgICAgIC8vIHdlIHNob3VsZCBzY3JvbGwgYXQgYSByYXRlIHN1Y2ggdGhhdCB3ZSBkb24ndCBydW4gb3V0IG9mIGJhY2tncm91bmQgKHdoZW4gbm9uLXJlcGVhdGluZylcbiAgICAgICAgY29uc3QgcGFyYWxsYXhCYWNrZ3JvdW5kTW92ZW1lbnQgPSBNYXRoLmZsb29yKChyZWN0LmJvdHRvbSAvICh3aW5kb3dIZWlnaHQgKyBiYWNrZ3JvdW5kSGVpZ2h0KSkgKiAxMzApO1xuICAgICAgICBiYWNrZ3JvdW5kLnN0eWxlLmJhY2tncm91bmRQb3NpdGlvblkgPSBgJHtwYXJhbGxheEJhY2tncm91bmRNb3ZlbWVudH0lYDtcbiAgICB9KSk7XG4gICAgY29uc3Qgb25JbnRlcnNlY3QgPSAoZW50cmllcykgPT4gZW50cmllc1xuICAgICAgICAuZmlsdGVyKChlbnRyeSkgPT4gZW50cnkuaXNJbnRlcnNlY3RpbmcpXG4gICAgICAgIC5mb3JFYWNoKCgpID0+IHtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3Njcm9sbCcsICgpID0+IHZvaWQgb25TY3JvbGwoYmFja2dyb3VuZCksIHtcbiAgICAgICAgICAgIHBhc3NpdmU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICB2b2lkIG9uU2Nyb2xsKGJhY2tncm91bmQpO1xuICAgIH0pO1xuICAgIGNvbnN0IG9ic2VydmVyID0gbmV3IEludGVyc2VjdGlvbk9ic2VydmVyKG9uSW50ZXJzZWN0LCB7XG4gICAgICAgIHJvb3RNYXJnaW46ICcxMHB4JyxcbiAgICB9KTtcbiAgICBvYnNlcnZlci5vYnNlcnZlKGJhY2tncm91bmRQYXJlbnQpO1xufTtcbmNvbnN0IHNldHVwQmFja2dyb3VuZCA9IGFzeW5jIChzcGVjcywgYWRTbG90KSA9PiB7XG4gICAgY29uc3QgeyBiYWNrZ3JvdW5kUGFyZW50LCBiYWNrZ3JvdW5kIH0gPSBjcmVhdGVQYXJlbnQoYWRTbG90LCBzcGVjcy5zY3JvbGxUeXBlKTtcbiAgICBjb25zdCBpbnRlcnNjcm9sbGVyVGVtcGxhdGVJZCA9IDExODg1NjY3O1xuICAgIHJldHVybiBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgIHNldEJhY2tncm91bmRTdHlsZXMoc3BlY3MsIGJhY2tncm91bmQpO1xuICAgICAgICBpZiAoc3BlY3Muc2Nyb2xsVHlwZSA9PT0gJ3BhcmFsbGF4Jykge1xuICAgICAgICAgICAgc2V0dXBQYXJhbGxheChhZFNsb3QsIGJhY2tncm91bmQsIGJhY2tncm91bmRQYXJlbnQpO1xuICAgICAgICB9XG4gICAgICAgIC8vIGZpeGVkIGJhY2tncm91bmQgaXMgdmVyeSBzaW1pbGFyIHRvIGludGVyc2Nyb2xsZXIsIGdlbmVyYWxseSB3aXRoIGEgc21hbGxlciBoZWlnaHRcbiAgICAgICAgaWYgKHNwZWNzLnNjcm9sbFR5cGUgPT09ICdmaXhlZCcpIHtcbiAgICAgICAgICAgIGFkU2xvdC5zdHlsZS5wb3NpdGlvbiA9ICdyZWxhdGl2ZSc7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kLnN0eWxlLnBvc2l0aW9uID0gJ2ZpeGVkJztcbiAgICAgICAgICAgIGlmIChzcGVjcy5iYWNrZ3JvdW5kQ29sb3IpIHtcbiAgICAgICAgICAgICAgICBiYWNrZ3JvdW5kUGFyZW50LnN0eWxlLmJhY2tncm91bmRDb2xvciA9IHNwZWNzLmJhY2tncm91bmRDb2xvcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBpZiAoc3BlY3Muc2Nyb2xsVHlwZSA9PT0gJ2ludGVyc2Nyb2xsZXInKSB7XG4gICAgICAgICAgICBhZFNsb3Quc3R5bGUuaGVpZ2h0ID0gJzg1dmgnO1xuICAgICAgICAgICAgYWRTbG90LnN0eWxlLm1hcmdpbkJvdHRvbSA9ICcxMnB4JztcbiAgICAgICAgICAgIGFkU2xvdC5zdHlsZS5wb3NpdGlvbiA9ICdyZWxhdGl2ZSc7XG4gICAgICAgICAgICBhZFNsb3Quc3R5bGUud2lkdGggPSAnMTAwJSc7XG4gICAgICAgICAgICB2b2lkIHJlbmRlckFkdmVydExhYmVsKGFkU2xvdCwgaW50ZXJzY3JvbGxlclRlbXBsYXRlSWQpO1xuICAgICAgICAgICAgdm9pZCByZW5kZXJTdGlja3lTY3JvbGxGb3JNb3JlTGFiZWwoYmFja2dyb3VuZFBhcmVudCwgaXNHYWxsZXJ5KTtcbiAgICAgICAgICAgIHZvaWQgcmVuZGVyQm90dG9tTGluZShiYWNrZ3JvdW5kLCBiYWNrZ3JvdW5kUGFyZW50LCBpc0dhbGxlcnkpO1xuICAgICAgICAgICAgaWYgKHNwZWNzLmN0YVVybCkge1xuICAgICAgICAgICAgICAgIGNvbnN0IGFuY2hvciA9IHNldEN0YVVSTChzcGVjcy5jdGFVcmwsIGJhY2tncm91bmRQYXJlbnQpO1xuICAgICAgICAgICAgICAgIGFkU2xvdC5pbnNlcnRCZWZvcmUoYW5jaG9yLCBhZFNsb3QuZmlyc3RDaGlsZCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoc3BlY3MudmlkZW9Tb3VyY2UpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2aWRlbyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3ZpZGVvJyk7XG4gICAgICAgICAgICAgICAgdmlkZW8uYXV0b3BsYXkgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHZpZGVvLm11dGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB2aWRlby5wbGF5c0lubGluZSA9IHRydWU7XG4gICAgICAgICAgICAgICAgdmlkZW8uc3JjID0gc3BlY3MudmlkZW9Tb3VyY2U7XG4gICAgICAgICAgICAgICAgdmlkZW8uc3R5bGUuaW5zZXQgPSAnNTAlIDAgMCA1MCUnO1xuICAgICAgICAgICAgICAgIHZpZGVvLnN0eWxlLnBvc2l0aW9uID0gJ2ZpeGVkJztcbiAgICAgICAgICAgICAgICB2aWRlby5zdHlsZS5oZWlnaHQgPSAnMTAwJSc7XG4gICAgICAgICAgICAgICAgdmlkZW8uc3R5bGUudHJhbnNmb3JtID0gJ3RyYW5zbGF0ZSgtNTAlLCAtNTAlKSc7XG4gICAgICAgICAgICAgICAgYmFja2dyb3VuZC5hcHBlbmRDaGlsZCh2aWRlbyk7XG4gICAgICAgICAgICAgICAgbGV0IHBsYXllZCA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIHZpZGVvLm9uZW5kZWQgPSAoKSA9PiAocGxheWVkID0gdHJ1ZSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgZW50cmllcy5mb3JFYWNoKChlbnRyeSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGVudHJ5LmlzSW50ZXJzZWN0aW5nICYmXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgIXBsYXllZCAmJlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZpZGVvLnBhdXNlZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZvaWQgdmlkZW8ucGxheSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmlkZW8ucGF1c2UoKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfSwgeyByb290OiBudWxsLCByb290TWFyZ2luOiAnMHB4JywgdGhyZXNob2xkOiAwLjIgfSk7XG4gICAgICAgICAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShiYWNrZ3JvdW5kUGFyZW50KTtcbiAgICAgICAgICAgICAgICBjb25zdCBhZHZlcnQgPSBnZXRBZHZlcnRCeUlkKGFkU2xvdC5pZCk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2hvdWxkUmVwb3J0VmlkZW9Qcm9ncmVzcyA9IGFkdmVydD8uY3JlYXRpdmVUZW1wbGF0ZUlkID09PSBJTlRFUlNDUk9MTEVSX1RFTVBMQVRFX0lEO1xuICAgICAgICAgICAgICAgIGlmIChzaG91bGRSZXBvcnRWaWRlb1Byb2dyZXNzKSB7XG4gICAgICAgICAgICAgICAgICAgIHZvaWQgc2VuZFByb2dyZXNzT25VbmxvYWRPbmNlKCk7XG4gICAgICAgICAgICAgICAgICAgIHZpZGVvLm9udGltZXVwZGF0ZSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHBlcmNlbnQgPSBNYXRoLnJvdW5kKDEwMCAqICh2aWRlby5jdXJyZW50VGltZSAvIHZpZGVvLmR1cmF0aW9uKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB1cGRhdGVWaWRlb1Byb2dyZXNzKGFkU2xvdC5pZCwgcGVyY2VudCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYWRTbG90Lmluc2VydEJlZm9yZShiYWNrZ3JvdW5kUGFyZW50LCBhZFNsb3QuZmlyc3RDaGlsZCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5jb25zdCBpbml0ID0gKHJlZ2lzdGVyKSA9PiB7XG4gICAgcmVnaXN0ZXIoJ2JhY2tncm91bmQnLCBhc3luYyAoc3BlY3MsIHJldCwgaWZyYW1lKSA9PiB7XG4gICAgICAgIGlmICghaXNCYWNrZ3JvdW5kU3BlY3Moc3BlY3MpKSB7XG4gICAgICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgYWRTbG90ID0gaWZyYW1lPy5jbG9zZXN0KCcuanMtYWQtc2xvdCcpO1xuICAgICAgICBpZiAoYWRTbG90KSB7XG4gICAgICAgICAgICByZXR1cm4gc2V0dXBCYWNrZ3JvdW5kKHNwZWNzLCBhZFNsb3QpO1xuICAgICAgICB9XG4gICAgfSk7XG59O1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgc2V0dXBCYWNrZ3JvdW5kLFxuICAgIGdldFN0eWxlc0Zyb21TcGVjLFxufTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsImltcG9ydCB7IGlzT2JqZWN0LCBpc1N0cmluZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uL2Zhc3Rkb20tcHJvbWlzZSc7XG5jb25zdCBpc1ZhbGlkUmVzaXplU3BlY3MgPSAoc3BlY3MpID0+IHtcbiAgICByZXR1cm4gKGlzT2JqZWN0KHNwZWNzKSAmJlxuICAgICAgICAoc3BlY3Mud2lkdGggPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICAgICAgaXNTdHJpbmcoc3BlY3Mud2lkdGgpIHx8XG4gICAgICAgICAgICB0eXBlb2Ygc3BlY3Mud2lkdGggPT09ICdudW1iZXInKSAmJlxuICAgICAgICAoc3BlY3MuaGVpZ2h0ID09PSB1bmRlZmluZWQgfHxcbiAgICAgICAgICAgIGlzU3RyaW5nKHNwZWNzLmhlaWdodCkgfHxcbiAgICAgICAgICAgIHR5cGVvZiBzcGVjcy5oZWlnaHQgPT09ICdudW1iZXInKSk7XG59O1xuY29uc3Qgbm9ybWFsaXNlID0gKGxlbmd0aCkgPT4ge1xuICAgIGNvbnN0IGxlbmd0aFJlZ2V4cCA9IC9eKFxcZCspKCV8cHh8ZW18ZXh8Y2h8cmVtfHZofHZ3fHZtaW58dm1heCk/LztcbiAgICBjb25zdCBkZWZhdWx0VW5pdCA9ICdweCc7XG4gICAgY29uc3QgbWF0Y2hlcyA9IGxlbmd0aFJlZ2V4cC5leGVjKFN0cmluZyhsZW5ndGgpKTtcbiAgICBpZiAoIW1hdGNoZXMpIHtcbiAgICAgICAgcmV0dXJuICcnO1xuICAgIH1cbiAgICBjb25zdCBudW1iZXIgPSBtYXRjaGVzWzFdO1xuICAgIGNvbnN0IHVuaXQgPSBtYXRjaGVzWzJdID8/IGRlZmF1bHRVbml0O1xuICAgIGlmICghbnVtYmVyKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgcmV0dXJuIG51bWJlciArIHVuaXQ7XG59O1xuY29uc3QgcmVzaXplID0gKHNwZWNzLCBpZnJhbWUsIGlmcmFtZUNvbnRhaW5lciwgYWRTbG90KSA9PiB7XG4gICAgaWYgKCFpc1ZhbGlkUmVzaXplU3BlY3Moc3BlY3MpIHx8ICFhZFNsb3QpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBjb25zdCBzdHlsZXMgPSB7fTtcbiAgICBpZiAoc3BlY3Mud2lkdGgpIHtcbiAgICAgICAgc3R5bGVzLndpZHRoID0gbm9ybWFsaXNlKHNwZWNzLndpZHRoKTtcbiAgICB9XG4gICAgaWYgKHNwZWNzLmhlaWdodCkge1xuICAgICAgICBzdHlsZXMuaGVpZ2h0ID0gbm9ybWFsaXNlKHNwZWNzLmhlaWdodCk7XG4gICAgfVxuICAgIHJldHVybiBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgIE9iamVjdC5hc3NpZ24oaWZyYW1lLnN0eWxlLCBzdHlsZXMpO1xuICAgICAgICBpZiAoaWZyYW1lQ29udGFpbmVyKSB7XG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKGlmcmFtZUNvbnRhaW5lci5zdHlsZSwgc3R5bGVzKTtcbiAgICAgICAgfVxuICAgICAgICBhZFNsb3Quc3R5bGUubWF4SGVpZ2h0ID0gJ25vbmUnO1xuICAgIH0pO1xufTtcbi8vIFdoZW4gYW4gb3V0c3RyZWFtIHJlc2l6ZXMgd2Ugd2FudCBpdCB0byByZXZlcnQgdG8gaXRzIG9yaWdpbmFsIHN0eWxpbmdcbmNvbnN0IHJlbW92ZUFueU91dHN0cmVhbUNsYXNzID0gKGFkU2xvdCkgPT4ge1xuICAgIHZvaWQgZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICBhZFNsb3QuY2xhc3NMaXN0LnJlbW92ZSgnYWQtc2xvdC0tb3V0c3RyZWFtJyk7XG4gICAgfSk7XG59O1xuY29uc3QgaW5pdCA9IChyZWdpc3RlcikgPT4ge1xuICAgIHJlZ2lzdGVyKCdyZXNpemUnLCAoc3BlY3MsIHJldCwgaWZyYW1lKSA9PiB7XG4gICAgICAgIGlmIChpZnJhbWUgJiYgc3BlY3MpIHtcbiAgICAgICAgICAgIGNvbnN0IGFkU2xvdCA9IGlmcmFtZS5jbG9zZXN0KCcuanMtYWQtc2xvdCcpID8/IHVuZGVmaW5lZDtcbiAgICAgICAgICAgIGlmIChhZFNsb3QpIHtcbiAgICAgICAgICAgICAgICByZW1vdmVBbnlPdXRzdHJlYW1DbGFzcyhhZFNsb3QpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgaWZyYW1lQ29udGFpbmVyID0gaWZyYW1lLmNsb3Nlc3QoJy5hZC1zbG90X19jb250ZW50JykgPz8gdW5kZWZpbmVkO1xuICAgICAgICAgICAgcmV0dXJuIHJlc2l6ZShzcGVjcywgaWZyYW1lLCBpZnJhbWVDb250YWluZXIsIGFkU2xvdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5leHBvcnQgY29uc3QgXyA9IHsgcmVzaXplLCBub3JtYWxpc2UgfTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsImltcG9ydCB7IGlzU3RyaW5nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vZmFzdGRvbS1wcm9taXNlJztcbmNvbnN0IHNldFR5cGUgPSAoYWRTbG90VHlwZSwgYWRTbG90KSA9PiBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgYWRTbG90LmNsYXNzTGlzdC5hZGQoYGFkLXNsb3QtLSR7YWRTbG90VHlwZX1gKTtcbn0pO1xuY29uc3QgaW5pdCA9IChyZWdpc3RlcikgPT4ge1xuICAgIHJlZ2lzdGVyKCd0eXBlJywgKHNwZWNzLCByZXQsIGlmcmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBhZFNsb3QgPSBpZnJhbWU/LmNsb3Nlc3QoJy5qcy1hZC1zbG90Jyk7XG4gICAgICAgIGlmIChhZFNsb3QgJiYgaXNTdHJpbmcoc3BlY3MpKSB7XG4gICAgICAgICAgICB2b2lkIHNldFR5cGUoc3BlY3MsIGFkU2xvdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5leHBvcnQgeyBpbml0IH07XG4iLCJpbXBvcnQgeyBidWlsZFBhZ2VUYXJnZXRpbmcgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL3RhcmdldGluZy9idWlsZC1wYWdlLXRhcmdldGluZyc7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBvbmNlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGdldFBhcnRpY2lwYXRpb25zIH0gZnJvbSAnLi4vZXhwZXJpbWVudHMvYWInO1xuaW1wb3J0IHsgY29tbWVyY2lhbEZlYXR1cmVzIH0gZnJvbSAnLi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCB7IHJlbW92ZUZhbHN5VmFsdWVzIH0gZnJvbSAnLi9oZWFkZXItYmlkZGluZy91dGlscyc7XG5jb25zdCBmb3JtYXRBcHBOZXh1c1RhcmdldGluZyA9IChvYmopID0+IHtcbiAgICBjb25zdCBhc0tleVZhbHVlcyA9IE9iamVjdC5lbnRyaWVzKG9iaikubWFwKChlbnRyeSkgPT4ge1xuICAgICAgICBjb25zdCBba2V5LCB2YWx1ZV0gPSBlbnRyeTtcbiAgICAgICAgcmV0dXJuIEFycmF5LmlzQXJyYXkodmFsdWUpXG4gICAgICAgICAgICA/IHZhbHVlLm1hcCgobmVzdGVkVmFsdWUpID0+IGAke2tleX09JHtuZXN0ZWRWYWx1ZX1gKVxuICAgICAgICAgICAgOiBgJHtrZXl9PSR7dmFsdWV9YDtcbiAgICB9KTtcbiAgICBjb25zdCBmbGF0dGVuRGVlcCA9IEFycmF5LnByb3RvdHlwZS5jb25jYXQuYXBwbHkoW10sIGFzS2V5VmFsdWVzKTtcbiAgICByZXR1cm4gZmxhdHRlbkRlZXAuam9pbignLCcpO1xufTtcbmNvbnN0IGJ1aWxkQXBwTmV4dXNUYXJnZXRpbmdPYmplY3QgPSBvbmNlKChwYWdlVGFyZ2V0aW5nKSA9PiByZW1vdmVGYWxzeVZhbHVlcyh7XG4gICAgc2VuczogcGFnZVRhcmdldGluZy5zZW5zLFxuICAgIHB0MTogcGFnZVRhcmdldGluZy51cmwsXG4gICAgcHQyOiBwYWdlVGFyZ2V0aW5nLmVkaXRpb24sXG4gICAgcHQzOiBwYWdlVGFyZ2V0aW5nLmN0LFxuICAgIHB0NDogcGFnZVRhcmdldGluZy5wLFxuICAgIHB0NTogcGFnZVRhcmdldGluZy5rLFxuICAgIHB0NjogcGFnZVRhcmdldGluZy5zdSxcbiAgICBwdDc6IHBhZ2VUYXJnZXRpbmcuYnAsXG4gICAgcHQ5OiBbcGFnZVRhcmdldGluZy5wdiwgcGFnZVRhcmdldGluZy5jbywgcGFnZVRhcmdldGluZy50bl0uam9pbignfCcpLFxuICAgIHBlcm11dGl2ZTogcGFnZVRhcmdldGluZy5wZXJtdXRpdmUsXG59KSk7XG5jb25zdCBidWlsZEFwcE5leHVzVGFyZ2V0aW5nID0gb25jZSgocGFnZVRhcmdldGluZykgPT4gZm9ybWF0QXBwTmV4dXNUYXJnZXRpbmcoYnVpbGRBcHBOZXh1c1RhcmdldGluZ09iamVjdChwYWdlVGFyZ2V0aW5nKSkpO1xuY29uc3QgZ2V0UGFnZVRhcmdldGluZyA9IChjb25zZW50U3RhdGUsIGlzU2lnbmVkSW4pID0+IHtcbiAgICBjb25zdCB7IHBhZ2UgfSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWc7XG4gICAgY29uc3QgcGFnZVRhcmdldGluZyA9IGJ1aWxkUGFnZVRhcmdldGluZyh7XG4gICAgICAgIGFkRnJlZTogY29tbWVyY2lhbEZlYXR1cmVzLmFkRnJlZSxcbiAgICAgICAgY2xpZW50U2lkZVBhcnRpY2lwYXRpb25zOiBnZXRQYXJ0aWNpcGF0aW9ucygpLFxuICAgICAgICBjb25zZW50U3RhdGUsXG4gICAgICAgIGlzU2lnbmVkSW4sXG4gICAgfSk7XG4gICAgLy8gdGhpcmQtcGFydGllcyB3aXNoIHRvIGFjY2VzcyBvdXIgcGFnZSB0YXJnZXRpbmcsIGJlZm9yZSB0aGUgZ29vZ2xldGFnIHNjcmlwdCBpcyBsb2FkZWQuXG4gICAgcGFnZS5hcHBOZXh1c1BhZ2VUYXJnZXRpbmcgPSBidWlsZEFwcE5leHVzVGFyZ2V0aW5nKHBhZ2VUYXJnZXRpbmcpO1xuICAgIC8vIFRoaXMgY2FuIGJlIHJlbW92ZWQgb25jZSB3ZSBnZXQgc2lnbi1vZmYgZnJvbSB0aGlyZCBwYXJ0aWVzIHdobyBwcmVmZXIgdG8gdXNlIGFwcE5leHVzUGFnZVRhcmdldGluZy5cbiAgICBwYWdlLnBhZ2VBZFRhcmdldGluZyA9IHBhZ2VUYXJnZXRpbmc7XG4gICAgbG9nKCdjb21tZXJjaWFsJywgJ3BhZ2VUYXJnZXRpbmcgb2JqZWN0OicsIHBhZ2VUYXJnZXRpbmcpO1xuICAgIHJldHVybiBwYWdlVGFyZ2V0aW5nO1xufTtcbmV4cG9ydCB7IGdldFBhZ2VUYXJnZXRpbmcsIGJ1aWxkQXBwTmV4dXNUYXJnZXRpbmcsIGJ1aWxkQXBwTmV4dXNUYXJnZXRpbmdPYmplY3QsIH07XG4iLCJpbXBvcnQgeyBjaGVja0NvbnNlbnQgYXMgY2hlY2tDb25zZW50Rm9yUmVwb3J0aW5nIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9zZW5kLWNvbW1lcmNpYWwtbWV0cmljcyc7XG5pbXBvcnQgeyBvbmNlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGdldEFkdmVydEJ5SWQgfSBmcm9tICcuL2RmcC9nZXQtYWR2ZXJ0LWJ5LWlkJztcbmNvbnN0IGVuZHBvaW50ID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzRGV2XG4gICAgPyAnLy9sb2dzLmNvZGUuZGV2LWd1YXJkaWFuYXBpcy5jb20vbG9nJ1xuICAgIDogJy8vbG9ncy5ndWFyZGlhbmFwaXMuY29tL2xvZyc7XG4vLyBUaGlzIGlzIGEgbWFwIG9mIHZpZGVvIHByb2dyZXNzIGZvciBlYWNoIHNsb3RJZC5cbmNvbnN0IHZpZGVvUHJvZ3Jlc3MgPSB7fTtcbmNvbnN0IHNlbmRQcm9ncmVzcyA9IG9uY2UoKCkgPT4ge1xuICAgIE9iamVjdC5lbnRyaWVzKHZpZGVvUHJvZ3Jlc3MpLmZvckVhY2goKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgICBjb25zdCBhZHZlcnQgPSBnZXRBZHZlcnRCeUlkKGtleSk7XG4gICAgICAgIGlmICghYWR2ZXJ0Py5jcmVhdGl2ZUlkIHx8ICFhZHZlcnQubGluZUl0ZW1JZCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IHsgY3JlYXRpdmVJZCwgbGluZUl0ZW1JZCB9ID0gYWR2ZXJ0O1xuICAgICAgICBjb25zdCBwcm9ncmVzcyA9IHZhbHVlID8/IDA7XG4gICAgICAgIHZvaWQgZmV0Y2goZW5kcG9pbnQsIHtcbiAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgIGxhYmVsOiAnY29tbWVyY2lhbC5pbnRlcnNjcm9sbGVyLnZpZGVvUHJvZ3Jlc3MnLFxuICAgICAgICAgICAgICAgIHByb3BlcnRpZXM6IFtcbiAgICAgICAgICAgICAgICAgICAgeyBuYW1lOiAnY3JlYXRpdmVJZCcsIHZhbHVlOiBjcmVhdGl2ZUlkIH0sXG4gICAgICAgICAgICAgICAgICAgIHsgbmFtZTogJ2xpbmVJdGVtSWQnLCB2YWx1ZTogbGluZUl0ZW1JZCB9LFxuICAgICAgICAgICAgICAgICAgICB7IG5hbWU6ICdwcm9ncmVzcycsIHZhbHVlOiBwcm9ncmVzcyB9LFxuICAgICAgICAgICAgICAgICAgICB7XG4gICAgICAgICAgICAgICAgICAgICAgICBuYW1lOiAncGFnZXZpZXdJZCcsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5vcGhhbi5wYWdlVmlld0lkLFxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICAgIGtlZXBhbGl2ZTogdHJ1ZSxcbiAgICAgICAgICAgIGNhY2hlOiAnbm8tc3RvcmUnLFxuICAgICAgICAgICAgbW9kZTogJ25vLWNvcnMnLFxuICAgICAgICB9KTtcbiAgICB9KTtcbn0pO1xuY29uc3Qgc2VuZFByb2dyZXNzT25VbmxvYWRPbmNlID0gb25jZShhc3luYyAoKSA9PiB7XG4gICAgaWYgKGF3YWl0IGNoZWNrQ29uc2VudEZvclJlcG9ydGluZygpKSB7XG4gICAgICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCd2aXNpYmlsaXR5Y2hhbmdlJywgc2VuZFByb2dyZXNzLCB7XG4gICAgICAgICAgICBvbmNlOiB0cnVlLFxuICAgICAgICB9KTtcbiAgICAgICAgLy8gU2FmYXJpIGRvZXMgbm90IHJlbGlhYmx5IGZpcmUgdGhlIGB2aXNpYmlsaXR5Y2hhbmdlYCBvbiBwYWdlIHVubG9hZC5cbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ3BhZ2VoaWRlJywgc2VuZFByb2dyZXNzLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgfVxufSk7XG5jb25zdCB1cGRhdGVWaWRlb1Byb2dyZXNzID0gKHNsb3RJZCwgdXBkYXRlZFByb2dyZXNzKSA9PiB7XG4gICAgdmlkZW9Qcm9ncmVzc1tzbG90SWRdID0gdXBkYXRlZFByb2dyZXNzO1xufTtcbmV4cG9ydCB7IHNlbmRQcm9ncmVzc09uVW5sb2FkT25jZSwgdXBkYXRlVmlkZW9Qcm9ncmVzcyB9O1xuIiwiZXhwb3J0IGRlZmF1bHQgXCI8c3ZnIHdpZHRoPVxcXCIxOFxcXCIgaGVpZ2h0PVxcXCIxOFxcXCIgdmlld0JveD1cXFwiMCAwIDE4IDE4XFxcIj48cGF0aCBkPVxcXCJNNy41IDlsLTYuNS03IDEtMSA3IDYuNSA3LTYuNSAxIDEtNi41IDcgNi41IDctMSAxLTctNi41LTcgNi41LTEtMSA2LjUtN3pcXFwiLz48L3N2Zz5cXG5cIjsiXSwibmFtZXMiOlsiYnJlYWtwb2ludHMiLCJpc0JyZWFrcG9pbnQiLCJBZFNpemUiLCJBcnJheSIsImNvbnN0cnVjdG9yIiwiX3JlZiIsIndpZHRoIiwiaGVpZ2h0IiwiX2RlZmluZVByb3BlcnR5IiwidG9TdHJpbmciLCJjb25jYXQiLCJ0b0FycmF5IiwiaXNQcm94eSIsImlzT3V0T2ZQYWdlIiwiaXNFbXB0eSIsImlzRmx1aWQiLCJpc01lcmNoIiwiaXNTcG9uc29yTG9nbyIsImNyZWF0ZUFkU2l6ZSIsIm5hbWVkU3RhbmRhcmRBZFNpemVzIiwiYmlsbGJvYXJkIiwiaGFsZlBhZ2UiLCJsZWFkZXJib2FyZCIsIm1vYmlsZXN0aWNreSIsIm1wdSIsInBvcnRyYWl0Iiwic2t5c2NyYXBlciIsImNhc2NhZGUiLCJwb3J0cmFpdEludGVyc3RpdGlhbCIsInN0YW5kYXJkQWRTaXplcyIsIm91dHN0cmVhbVNpemVzIiwib3V0c3RyZWFtRGVza3RvcCIsIm91dHN0cmVhbUdvb2dsZURlc2t0b3AiLCJvdXRzdHJlYW1Nb2JpbGUiLCJwcm9wcmlldGFyeUFkU2l6ZXMiLCJmbHVpZCIsImdvb2dsZUNhcmQiLCJvdXRPZlBhZ2UiLCJwdWJtYXRpY0ludGVyc2Nyb2xsZXIiLCJndWFyZGlhblByb3ByaWV0YXJ5QWRTaXplcyIsImVtcHR5IiwiZmFicmljIiwibWVyY2hhbmRpc2luZyIsIm1lcmNoYW5kaXNpbmdIaWdoIiwibWVyY2hhbmRpc2luZ0hpZ2hBZEZlYXR1cmUiLCJzcG9uc29yTG9nbyIsImFkU2l6ZXMiLCJfb2JqZWN0U3ByZWFkIiwic2xvdFNpemVNYXBwaW5ncyIsImlubGluZSIsIm1vYmlsZSIsImRlc2t0b3AiLCJyaWdodCIsImNvbW1lbnRzIiwidGFibGV0IiwibW9zdHBvcCIsInBoYWJsZXQiLCJzdXJ2ZXkiLCJjYXJyb3QiLCJleGNsdXNpb24iLCJleHRlcm5hbCIsImludGVyYWN0aXZlIiwiZ2V0QWRTaXplIiwic2l6ZSIsImZpbmRBcHBsaWVkU2l6ZXNGb3JCcmVha3BvaW50Iiwic2l6ZU1hcHBpbmdzIiwiYnJlYWtwb2ludCIsImJyZWFrcG9pbnRJbmRleCIsImZpbmRJbmRleCIsImIiLCJicmVha3BvaW50VG9UcnkiLCJzaXplTWFwcGluZyIsImxlbmd0aCIsIl8iLCJzIiwiaW5jbHVkZXMiLCJQUkVCSURfVElNRU9VVCIsImdldENvb2tpZSIsImlzU3RyaW5nIiwic3RvcmFnZSIsImVkaXRpb25Ub0NvdW50cnlDb2RlTWFwIiwiVUsiLCJVUyIsIkFVIiwiZWRpdGlvblRvQ291bnRyeUNvZGUiLCJlZGl0aW9uS2V5IiwiYXJndW1lbnRzIiwidW5kZWZpbmVkIiwiY291bnRyeUNvb2tpZU5hbWUiLCJjb3VudHJ5T3ZlcnJpZGVOYW1lIiwiZ2V0Q291bnRyeUNvZGUiLCJwYWdlRWRpdGlvbiIsIndpbmRvdyIsImd1YXJkaWFuIiwiY29uZmlnIiwicGFnZSIsImVkaXRpb24iLCJtYXliZUNvdW50cnlPdmVycmlkZSIsImxvY2FsIiwiZ2V0IiwiY291bnRyeU92ZXJyaWRlIiwibmFtZSIsInNob3VsZE1lbW9pemUiLCJnZW8iLCJjdXJyZW50R2VvTG9jYXRpb24iLCJpc0luVWsiLCJpc0luVXNhIiwiaXNJbkNhbmFkYSIsImlzSW5BdXN0cmFsaWEiLCJpc0luTmV3WmVhbGFuZCIsImlzSW5Vc09yQ2EiLCJpc0luQXVPck56IiwiaXNJblJvdyIsInJlc2V0TW9kdWxlIiwiS0VZIiwiS0VZX09WRVJSSURFIiwiQ09VTlRSWV9SRUdFWCIsImlzVmFsaWRDb3VudHJ5Q29kZSIsImNvdW50cnkiLCJ0ZXN0IiwibG9jYWxlIiwiZWRpdGlvblRvR2VvbG9jYXRpb25NYXAiLCJlZGl0aW9uVG9HZW9sb2NhdGlvbiIsIl9fcmVzZXRDYWNoZWRWYWx1ZSIsImdldExvY2FsZSIsImdlb092ZXJyaWRlIiwic3RvcmVkIiwiZWRpdGlvbkNvdW50cnlDb2RlIiwicG9zdE1lc3NhZ2UiLCJtZXNzYWdlIiwidGFyZ2V0IiwidGFyZ2V0T3JpZ2luIiwiSlNPTiIsInN0cmluZ2lmeSIsIlBFUk1VVElWRV9LRVkiLCJQRVJNVVRJVkVfUEZQX0tFWSIsImdldFNlZ21lbnRzIiwia2V5IiwicmF3U2VnbWVudHMiLCJnZXRSYXciLCJzZWdtZW50cyIsInBhcnNlIiwiaXNBcnJheSIsInNsaWNlIiwibWFwIiwiTnVtYmVyIiwicGFyc2VJbnQiLCJmaWx0ZXIiLCJuIiwiaXNOYU4iLCJTdHJpbmciLCJlcnIiLCJnZXRQZXJtdXRpdmVTZWdtZW50cyIsImdldFBlcm11dGl2ZVBGUFNlZ21lbnRzIiwiY2xlYXJQZXJtdXRpdmVTZWdtZW50cyIsInJlbW92ZSIsImdldE1lYXN1cmVzIiwiaXNOb25OdWxsYWJsZSIsImxvZyIsIm9uQ29uc2VudCIsIkV2ZW50VGltZXIiLCJFbmRwb2ludHMiLCJjb21tZXJjaWFsTWV0cmljc1BheWxvYWQiLCJwYWdlX3ZpZXdfaWQiLCJicm93c2VyX2lkIiwicGxhdGZvcm0iLCJtZXRyaWNzIiwicHJvcGVydGllcyIsImRldlByb3BlcnRpZXMiLCJhZEJsb2NrZXJQcm9wZXJ0aWVzIiwiZW5kcG9pbnQiLCJzZXRFbmRwb2ludCIsImlzRGV2IiwiQ09ERSIsIlBST0QiLCJzZXREZXZQcm9wZXJ0aWVzIiwidmFsdWUiLCJsb2NhdGlvbiIsImhvc3RuYW1lIiwic2V0QWRCbG9ja2VyUHJvcGVydGllcyIsImFkQmxvY2tlckluVXNlIiwidHJhbnNmb3JtVG9PYmplY3RFbnRyaWVzIiwiZXZlbnRUaW1lclByb3BlcnRpZXMiLCJPYmplY3QiLCJlbnRyaWVzIiwibWFwRXZlbnRUaW1lclByb3BlcnRpZXNUb1N0cmluZyIsInJvdW5kVGltZVN0YW1wIiwiZXZlbnRzIiwibWVhc3VyZXMiLCJyb3VuZGVkRXZlbnRzIiwiX3JlZjIiLCJ0cyIsIk1hdGgiLCJjZWlsIiwicm91bmRlZE1lYXN1cmVzIiwiX3JlZjMiLCJkdXJhdGlvbiIsInNlbmRNZXRyaWNzIiwiZmV0Y2giLCJtZXRob2QiLCJib2R5Iiwia2VlcGFsaXZlIiwiY2FjaGUiLCJtb2RlIiwiZ2V0T2ZmbGluZUNvdW50Iiwib2ZmbGluZUNvdW50IiwiZ2V0UGVyZm9ybWFuY2VNZWFzdXJlcyIsIl9sZW4iLCJ0ZWFtcyIsIl9rZXkiLCJfcmVmNCIsImRldGFpbCIsInN1YnNjcmlwdGlvbiIsImFjdGlvbiIsImpvaW4iLCJnYXRoZXJNZXRyaWNzT25QYWdlVW5sb2FkIiwiZXZlbnRUaW1lciIsInRyYW5zZm9ybWVkRW50cmllcyIsImZpbHRlcmVkRXZlbnRUaW1lclByb3BlcnRpZXMiLCJpdGVtIiwibWFwcGVkRXZlbnRUaW1lclByb3BlcnRpZXMiLCJtYXJrcyIsImxpc3RlbmVyIiwiZSIsInNob3VsZFNlbmRDb21tZXJjaWFsTWV0cmljcyIsInR5cGUiLCJkb2N1bWVudCIsInZpc2liaWxpdHlTdGF0ZSIsImFkZFZpc2liaWxpdHlMaXN0ZW5lcnMiLCJhZGRFdmVudExpc3RlbmVyIiwib25jZSIsImNoZWNrQ29uc2VudCIsIl9yZWY1IiwiX2FzeW5jVG9HZW5lcmF0b3IiLCJjb25zZW50U3RhdGUiLCJ0Y2Z2MiIsImNvbnNlbnRzIiwiUkVRVUlSRURfQ09OU0VOVFMiLCJldmVyeSIsImNvbnNlbnQiLCJhcHBseSIsImJ5cGFzc0NvbW1lcmNpYWxNZXRyaWNzU2FtcGxpbmciLCJfYnlwYXNzQ29tbWVyY2lhbE1ldHJpY3NTYW1wbGluZyIsImNvbW1lcmNpYWxNZXRyaWNzSW5pdGlhbGlzZWQiLCJjb25zb2xlIiwid2FybiIsImNvbnNlbnRlZCIsImluaXRDb21tZXJjaWFsTWV0cmljcyIsIl94IiwiX2luaXRDb21tZXJjaWFsTWV0cmljcyIsIl9yZWY2IiwicGFnZVZpZXdJZCIsImJyb3dzZXJJZCIsInNhbXBsaW5nIiwidXNlcklzSW5TYW1wbGluZ0dyb3VwIiwicmFuZG9tIiwicmVzZXQiLCJyZW1vdmVFdmVudExpc3RlbmVyIiwiY21wIiwiZ2V0Q29uc2VudEZvciIsInN1cHBvcnRzUGVyZm9ybWFuY2VBUEkiLCJnZXRDb250ZW50VGFyZ2V0aW5nIiwiZ2V0UGVyc29uYWxpc2VkVGFyZ2V0aW5nIiwiZ2V0U2Vzc2lvblRhcmdldGluZyIsImdldExvY2FsSG91ciIsImdldFNoYXJlZFRhcmdldGluZyIsImdldFZpZXdwb3J0VGFyZ2V0aW5nIiwiZmlsdGVyVmFsdWVzIiwicGFnZVRhcmdldHMiLCJmaWx0ZXJlZCIsImxhc3RQZXJmb3JtYW5jZUVudHJ5SXNOYXZpZ2F0aW9uVHlwZSIsIm5hdmlnYXRpb25FdmVudHMiLCJwZXJmb3JtYW5jZSIsImdldEVudHJpZXNCeVR5cGUiLCJsYXN0TmF2aWdhdGlvbkV2ZW50IiwiZW50cnlUeXBlIiwicmVmZXJyZXJNYXRjaGVzSG9zdCIsInJlZmVycmVyIiwicmVmZXJyZXJVcmwiLCJVUkwiLCJpc0ZpcnN0VmlzaXQiLCJidWlsZFBhZ2VUYXJnZXRpbmciLCJfc2hhcmVkQWRUYXJnZXRpbmckayIsIl93aW5kb3ckZ3VhcmRpYW4kY29uZiIsImFkRnJlZSIsImNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucyIsImlzU2lnbmVkSW4iLCJ5b3V0dWJlIiwiaXNEb3Rjb21SZW5kZXJpbmciLCJhZEZyZWVUYXJnZXRpbmciLCJhZiIsInNoYXJlZEFkVGFyZ2V0aW5nIiwiY29udGVudFRhcmdldGluZyIsIndlYlB1YmxpY2F0aW9uRGF0ZSIsImVsaWdpYmxlRm9yRENSIiwiZGNyQ291bGRSZW5kZXIiLCJwYXRoIiwicGFnZUlkIiwicmVuZGVyaW5nUGxhdGZvcm0iLCJzZWN0aW9uIiwic2Vuc2l0aXZlIiwiaXNTZW5zaXRpdmUiLCJ2aWRlb0xlbmd0aCIsInZpZGVvRHVyYXRpb24iLCJrZXl3b3JkcyIsImsiLCJzZXNzaW9uVGFyZ2V0aW5nIiwiYWRUZXN0IiwiY291bnRyeUNvZGUiLCJsb2NhbEhvdXIiLCJvcGhhbiIsInBhcnRpY2lwYXRpb25zIiwic2VydmVyU2lkZVBhcnRpY2lwYXRpb25zIiwidGVzdHMiLCJnZXRWaWV3cG9ydCIsImlubmVyV2lkdGgiLCJjbGllbnRXaWR0aCIsImlubmVySGVpZ2h0IiwiY2xpZW50SGVpZ2h0Iiwidmlld3BvcnRUYXJnZXRpbmciLCJ2aWV3UG9ydFdpZHRoIiwiY21wQmFubmVyV2lsbFNob3ciLCJoYXNJbml0aWFsaXNlZCIsIndpbGxTaG93UHJpdmFjeU1lc3NhZ2VTeW5jIiwicGVyc29uYWxpc2VkVGFyZ2V0aW5nIiwic3RhdGUiLCJjb25zZW50bGVzc1RhcmdldGluZyIsImZpcnN0dmlzaXQiLCJwYWdlVGFyZ2V0aW5nIiwidmlkZW9MZW5ndGhzIiwiZ2V0VmlkZW9MZW5ndGgiLCJfdmlkZW9MZW5ndGhzJGluZGV4IiwiaW5kZXgiLCJtaW4iLCJnZXRVcmxLZXl3b3JkcyIsInVybCIsImxhc3RTZWdtZW50Iiwic3BsaXQiLCJCb29sZWFuIiwiY29uY2F0VW5pcXVlIiwiYSIsIlNldCIsImNhbGN1bGF0ZVJlY2VudGx5UHVibGlzaGVkQnVja2V0Iiwibm93IiwiRGF0ZSIsImhvdXJzU2luY2VQdWJsaWNhdGlvbiIsImRheXNTaW5jZVB1YmxpY2F0aW9uIiwibW9udGhzU2luY2VQdWJsaWNhdGlvbiIsInVybGt3IiwiZGNyZSIsInJjIiwicnAiLCJzZW5zIiwidmwiLCJhbGxrdyIsImZyZXF1ZW5jeSIsIkFNVEdSUF9TVE9SQUdFX0tFWSIsImFkTWFuYWdlckdyb3VwcyIsImdldFJhd1dpdGhDb25zZW50IiwidXNuYXQiLCJkb05vdFNlbGwiLCJhdXMiLCJwZXJzb25hbGlzZWRBZHZlcnRpc2luZyIsImdldEZyZXF1ZW5jeVZhbHVlIiwicmF3VmFsdWUiLCJ2aXNpdENvdW50IiwiX2ZyZXF1ZW5jeSR2aXNpdENvdW50IiwiZ2V0Q01QVGFyZ2V0aW5nIiwiY21wX2ludGVyYWN0aW9uIiwiZXZlbnRTdGF0dXMiLCJwYSIsImNhblRhcmdldCIsImNvbnNlbnRfdGNmdjIiLCJyZHAiLCJpc0FkTWFuYWdlckdyb3VwIiwic29tZSIsImciLCJjcmVhdGVBZE1hbmFnZXJHcm91cCIsIl9hZE1hbmFnZXJHcm91cHMkaW5kZSIsImZsb29yIiwiZ3JvdXAiLCJzZXRSYXciLCJnZXRBZE1hbmFnZXJHcm91cCIsImZyYW1ld29yayIsImV4aXN0aW5nR3JvdXAiLCJnZXRQZXJtdXRpdmVXaXRoU3RhdGUiLCJhbXRncnAiLCJmciIsInBlcm11dGl2ZSIsImlzVGFyZ2V0aW5nU3RyaW5nIiwic3RyaW5nIiwiaXNUYXJnZXRpbmdBcnJheSIsImFycmF5IiwiaXNWYWxpZFRhcmdldGluZyIsInBpY2tUYXJnZXRpbmdWYWx1ZXMiLCJvYmoiLCJpbml0aWFsVmFsdWUiLCJyZWR1Y2UiLCJ2YWxpZCIsInJlZmVycmVycyIsImlkIiwibWF0Y2giLCJnZXRSZWZlcnJlciIsIl9yZWZlcnJlcnMkZmluZCIsIm1hdGNoZWRSZWYiLCJmaW5kIiwicmVmZXJyZXJUeXBlIiwiZXhwZXJpbWVudHNUYXJnZXRpbmciLCJ0ZXN0VG9QYXJhbXMiLCJ0ZXN0TmFtZSIsInZhcmlhbnQiLCJzdWJzdHJpbmciLCJjbGllbnRTaWRlRXhwZXJpbWVudCIsInNlcnZlclNpZGVFeHBlcmltZW50cyIsImFiIiwiYXQiLCJjYyIsImxoIiwicHYiLCJyZWYiLCJzaSIsInN1cmdlcyIsImdldFN1cmdpbmdQYXJhbSIsInN1cmdpbmciLCJ0aHJlc2hvbGRzIiwiZ2V0SG91cnMiLCJzaGFyZWQiLCJhbGxvd2VkQ29udGVudFR5cGVzIiwiaXNFbGlnaWJsZUZvclRlYWRzIiwic2xvdElkIiwiY29udGVudFR5cGUiLCJpc0JyYW5kU2FmZSIsImdvb2dsZXRhZyIsInB1YmFkcyIsImdldFRhcmdldGluZyIsImZpbmRCcmVha3BvaW50IiwiaXNQcmV2aWV3IiwiaW5za2luIiwiYnAiLCJza2luc2l6ZSIsInNvdXJjZUJyZWFrcG9pbnRzIiwiY29uY2F0U2l6ZU1hcHBpbmdzIiwiZmFzdGRvbSIsImJ1aWxkR29vZ2xldGFnU2l6ZU1hcHBpbmciLCJkZWZpbmVTbG90Iiwic3RyaW5nVG9UdXBsZSIsImRpbWVuc2lvbnMiLCJjcmVhdGVTaXplTWFwcGluZyIsImF0dHIiLCJicmVha3BvaW50TmFtZVRvQXR0cmlidXRlIiwiYnJlYWtwb2ludE5hbWUiLCJyZXBsYWNlIiwidG9Mb3dlckNhc2UiLCJnZXRTbG90U2l6ZU1hcHBpbmdzRnJvbURhdGFBdHRycyIsImFkdmVydE5vZGUiLCJzaXplcyIsImRhdGEiLCJnZXRBdHRyaWJ1dGUiLCJpc1Nsb3ROYW1lIiwic2xvdE5hbWUiLCJnZXRTbG90U2l6ZU1hcHBpbmciLCJmaW5kU21hbGxlc3RBZEhlaWdodEZvclNsb3QiLCJzbG90Iiwia2V5cyIsInNpemVzRm9yQnJlYWtwb2ludCIsImhlaWdodHMiLCJpc1NpemVNYXBwaW5nRW1wdHkiLCJtYXBwaW5nIiwiQWR2ZXJ0IiwiYWRTbG90Tm9kZSIsImFkZGl0aW9uYWxTaXplTWFwcGluZyIsInNsb3RUYXJnZXRpbmciLCJub2RlIiwiZ2VuZXJhdGVTaXplTWFwcGluZyIsInNsb3REZWZpbml0aW9uIiwid2hlblNsb3RSZWFkeSIsInNsb3RSZWFkeSIsInRlc3Rncm91cCIsImZpbmlzaGVkUmVuZGVyaW5nIiwiaXNSZW5kZXJlZCIsInVwZGF0ZUV4dHJhU2xvdENsYXNzZXMiLCJfYXJndW1lbnRzIiwiX3RoaXMiLCJuZXdDbGFzc2VzIiwiY2xhc3Nlc1RvUmVtb3ZlIiwiZXh0cmFOb2RlQ2xhc3NlcyIsImMiLCJtdXRhdGUiLCJjbGFzc0xpc3QiLCJhZGQiLCJkZWZhdWx0U2l6ZU1hcHBpbmdGb3JTbG90IiwiZGF0YXNldCIsImRhdGFBdHRyU2l6ZU1hcHBpbmciLCJfdGhpcyRub2RlJGRhdGFzZXQkbmEiLCJFcnJvciIsInVwZGF0ZVNpemVNYXBwaW5nIiwiZ29vZ2xldGFnU2l6ZU1hcHBpbmciLCJkZWZpbmVTaXplTWFwcGluZyIsImlzQWRTaXplIiwicmVwb3J0RXJyb3IiLCJEZWZpbmVTbG90RXJyb3IiLCJjcmVhdGVBZHZlcnQiLCJhZFNsb3QiLCJhZGRpdGlvbmFsU2l6ZXMiLCJhZHZlcnQiLCJlcnJvciIsImFkU2xvdElkIiwicmVwb3J0IiwibmF2aWdhdG9yIiwidXNlckFnZW50IiwiZ2V0VXJsVmFycyIsImluaXRTbG90SWFzIiwiYnJlYWtwb2ludFZpZXdwb3J0cyIsIndpZGUiLCJhZFVuaXQiLCJ1cmxWYXJzIiwiZGZwQWNjb3VudElkIiwidG9Hb29nbGVUYWdTaXplIiwiY2FuRGVmaW5lU2xvdCIsInRlc3RNYXBwaW5nIiwiYWRkU2l6ZSIsImJ1aWxkIiwiZm9yRWFjaCIsImlzTXVsdGlTaXplIiwiaXNTaXplSW5BcnJheSIsImNvbGxlY3RTaXplcyIsInB1c2giLCJpc0VsaWdpYmxlRm9yT3V0c3RyZWFtIiwic2xvdFRhcmdldCIsImFsbG93U2FmZUZyYW1lVG9FeHBhbmQiLCJzZXRTYWZlRnJhbWVDb25maWciLCJhbGxvd092ZXJsYXlFeHBhbnNpb24iLCJhbGxvd1B1c2hFeHBhbnNpb24iLCJzYW5kYm94IiwibWFyayIsIl9zbG90IiwiZGVmaW5lT3V0T2ZQYWdlU2xvdCIsIl9zbG90MiIsInRoZW4iLCJpc1RlYWRzRWxpZ2libGUiLCJzZXRUYXJnZXRpbmciLCJpc2JuIiwiZmFicmljS2V5VmFsdWVzIiwiTWFwIiwic2xvdEZhYnJpYyIsImFkZFNlcnZpY2UiLCJ0aW1lb3V0IiwicHJvbWlzZSIsIm1zIiwidGltZW91dElkIiwiUHJvbWlzZSIsInJhY2UiLCJyZXNvbHZlIiwic2V0VGltZW91dCIsInJlc3VsdCIsImNsZWFyVGltZW91dCIsIl94MiIsIl93aW5kb3ckX19pYXNQRVQiLCJfaWFzUEVUJHF1ZXVlIiwiX19pYXNQRVQiLCJpYXNQRVQiLCJxdWV1ZSIsInB1YklkIiwic2xvdFNpemVzIiwiZ2V0U2l6ZXMiLCJpYXNQRVRTbG90cyIsImdldFdpZHRoIiwiZ2V0SGVpZ2h0IiwiYWRVbml0UGF0aCIsImlhc0RhdGFDYWxsYmFjayIsInRhcmdldGluZ0pTT04iLCJfdGFyZ2V0aW5nJGN1c3RvbSIsInRhcmdldGluZyIsImJyYW5kU2FmZXR5IiwiYnJhbmRTYWZldHlWYWx1ZSIsImN1c3RvbSIsImlnbm9yZWRLZXlzIiwic2xvdHMiLCJ4IiwidGFyZ2V0aW5nU2xvdCIsInRhcmdldGluZ1ZhbHVlIiwiYWRTbG90cyIsImRhdGFIYW5kbGVyIiwiZ2V0Q3VycmVudEJyZWFrcG9pbnQiLCJkZnBFbnYiLCJnZXRBZHZlcnRCeUlkIiwibG9hZEFkdmVydCIsInJlZnJlc2hBZHZlcnQiLCJyZXF1ZXN0Qmlkc0ZvckFkIiwiZGlzcGxheUFkIiwiYWR2ZXJ0SWQiLCJyZXF1ZXN0QmlkcyIsIm9uSW50ZXJzZWN0RGlzcGxheUFkIiwib2JzZXJ2ZXIiLCJhZHZlcnRJZHMiLCJlbnRyeSIsImlzSW50ZXJzZWN0aW5nIiwidW5vYnNlcnZlIiwiYWR2ZXJ0c1RvTG9hZCIsIm9uSW50ZXJzZWN0UHJlYmlkIiwiZ2V0RGlzcGxheUFkT2JzZXJ2ZXIiLCJpc0VhZ2VyUHJlYmlkIiwiSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJyb290TWFyZ2luIiwiZ2V0UHJlYmlkT2JzZXJ2ZXIiLCJzaG91bGRSdW5FYWdlclByZWJpZCIsImVuYWJsZUxhenlMb2FkIiwibGF6eUxvYWRPYnNlcnZlIiwib2JzZXJ2ZSIsInN0cmlwRGZwQWRQcmVmaXhGcm9tIiwicmVmcmVzaEJpZHNGb3JBZCIsImFkTmFtZSIsImNhdGNoIiwiaGVhZGVyQmlkZGluZ0JpZFJlcXVlc3QiLCJkaXNwbGF5IiwiX2FkdmVydCRub2RlJGNsb3Nlc3QiLCJjbG9zZXN0IiwicmVmcmVzaCIsImE5IiwicHJlYmlkIiwicmV0YWluQWRTaXplT25SZWZyZXNoIiwiYWR2ZXJ0U2l6ZSIsImhiU2xvdCIsInN0YXJ0c1dpdGgiLCJyZXF1ZXN0Qmlkc0ZvckFkcyIsImFkdmVydHMiLCJhZHNUb1JlcXVlc3RCaWRzRm9yIiwiYWxsIiwicHJlYmlkUHJvbWlzZSIsInByZWJpZFNsb3QiLCJhOVByb21pc2UiLCJhOVNsb3QiLCJfeDMiLCJyZW1vdmVGcm9tRGZwRW52IiwiZGVsZXRlIiwiZmluZEVsZW1lbnRUb1JlbW92ZSIsInBhcmVudCIsInBhcmVudEVsZW1lbnQiLCJpc0FkQ29udGFpbmVyIiwiSFRNTEVsZW1lbnQiLCJjb250YWlucyIsInRvcExldmVsQ29udGFpbmVyIiwicmVtb3ZlU2xvdEZyb21Eb20iLCJzbG90RWxlbWVudCIsImVsZW1lbnRUb1JlbW92ZSIsInN0eWxlIiwiZW1wdHlBZHZlcnQiLCJkZXN0cm95U2xvdHMiLCJjcm9zc0ljb24iLCJ0ZW1wbGF0ZXNXaXRob3V0TGFiZWxzIiwic2hvdWxkUmVuZGVyTGFiZWwiLCJjcmVhdGl2ZVRlbXBsYXRlSWQiLCJzaG91bGRSZW5kZXJDbG9zZUJ1dHRvbiIsImNyZWF0ZUFkQ2xvc2VEaXYiLCJidXR0b25FbCIsImNyZWF0ZUVsZW1lbnQiLCJjbGFzc05hbWUiLCJpbm5lckhUTUwiLCJvbmNsaWNrIiwiY29udGFpbmVyIiwiY2xvc2VEaXYiLCJjc3NUZXh0IiwiYXBwZW5kQ2hpbGQiLCJzaG91bGRSZW5kZXJBZFRlc3RMYWJlbCIsImNyZWF0ZUFkVGVzdExhYmVsIiwic2hvdWxkUmVuZGVyIiwiYWRUZXN0TmFtZSIsImFkVGVzdExhYmVsIiwiY3JlYXRlQWRUZXN0Q29va2llUmVtb3ZhbExpbmsiLCJhZFRlc3RDb29raWVSZW1vdmFsTGluayIsImhyZWYiLCJzZWFyY2hQYXJhbXMiLCJzZXQiLCJjbGVhckxpbmsiLCJyZW5kZXJBZHZlcnRMYWJlbCIsIm1lYXN1cmUiLCJfYWRTbG90Tm9kZSRwYXJlbnROb2QiLCJyZW5kZXJBZFRlc3RMYWJlbCIsImFkVGVzdENsZWFyRXhpc3RzIiwicGFyZW50Tm9kZSIsImZpcnN0RWxlbWVudENoaWxkIiwiSFRNTEFuY2hvckVsZW1lbnQiLCJhZFRlc3RDb29raWVOYW1lIiwiYWRMYWJlbENvbnRlbnQiLCJfYWRTbG90Tm9kZSRwYXJlbnRFbGUiLCJzZXRBdHRyaWJ1dGUiLCJpbnNlcnRCZWZvcmUiLCJmaXJzdENoaWxkIiwiX2FkU2xvdE5vZGUkcGFyZW50Tm9kMiIsInJlbmRlclN0aWNreVNjcm9sbEZvck1vcmVMYWJlbCIsImlzR2FsbGVyeSIsInNjcm9sbEZvck1vcmVMYWJlbCIsImV2ZW50Iiwic2Nyb2xsSW50b1ZpZXciLCJiZWhhdmlvciIsImJsb2NrIiwicHJldmVudERlZmF1bHQiLCJhZG1pcmFsQWRibG9ja1JlY292ZXJ5IiwicHJlYmlkOTQ2IiwiY29uY3VycmVudFRlc3RzIiwiZ2V0Rm9yY2VkUGFydGljaXBhdGlvbnNGcm9tVXJsIiwiaGFzaCIsInRva2VucyIsInRva2VuIiwidGVzdElkIiwidmFyaWFudElkIiwiQUIiLCJnZXRQYXJ0aWNpcGF0aW9uc0Zyb21Mb2NhbFN0b3JhZ2UiLCJzZXRQYXJ0aWNpcGF0aW9uc0luTG9jYWxTdG9yYWdlIiwibXZ0TWluVmFsdWUiLCJtdnRNYXhWYWx1ZSIsInBhcnNlTXZ0SWQiLCJudW1iZXIiLCJnZXRNdnRJZCIsIm12dElkIiwiYWJUZXN0U3dpdGNoZXMiLCJzd2l0Y2hlcyIsInByZXYiLCJ2YWwiLCJpbml0IiwiZm9yY2VkVGVzdFZhcmlhbnRzIiwib3BoYW5FdmVudHMiLCJvcGhhblJlY29yZCIsIl93aW5kb3ckZ3VhcmRpYW4kb3BoYSIsInJlY29yZCIsInBhZ2VJc1NlbnNpdGl2ZSIsImFycmF5T2ZUZXN0T2JqZWN0cyIsInNlcnZlclNpZGVUZXN0cyIsImVycm9yUmVwb3J0ZXIiLCJhbGxSdW5uYWJsZVRlc3RzIiwidHJhY2tBQlRlc3RzIiwicmVnaXN0ZXJJbXByZXNzaW9uRXZlbnRzIiwicmVnaXN0ZXJDb21wbGV0ZUV2ZW50cyIsImdldFBhcnRpY2lwYXRpb25zIiwicnVubmFibGVUZXN0cyIsImFjYyIsInZhcmlhbnRUb1J1biIsImlzVXNlckluVmFyaWFudCIsImdldFZhcmlhbnQiLCJfcGFydGljaXBhdGlvbnMkdGVzdCQiLCJhdXRob3IiLCJzdGFydCIsImV4cGlyeSIsImF1ZGllbmNlIiwiYXVkaWVuY2VPZmZzZXQiLCJhdWRpZW5jZUNyaXRlcmlhIiwic3VjY2Vzc01lYXN1cmUiLCJkZXNjcmlwdGlvbiIsInZhcmlhbnRzIiwiY2FuUnVuIiwib25Db25zZW50Q2hhbmdlIiwiaW5pdGlhbENvbnNlbnRTdGF0ZSIsInJlbG9hZFBhZ2VPbkNvbnNlbnRDaGFuZ2UiLCJyZWxvYWQiLCJyZW1vdmVDb29raWUiLCJzZXRDb29raWUiLCJxdWVyeVBhcmFtcyIsImFkdGVzdCIsImVuY29kZVVSSUNvbXBvbmVudCIsImRheXNUb0xpdmUiLCJhZHRlc3RJbkxhYmVscyIsInF1ZXVlQWR2ZXJ0IiwiZm9yY2VEaXNwbGF5Iiwic2hvdWxkTGF6eUxvYWQiLCJmaWxsRHluYW1pY0FkU2xvdCIsImNtZCIsImhhcyIsImVycm9yTWVzc2FnZSIsImNvbW1lcmNpYWxGZWF0dXJlcyIsImFkU2xvdENvbnRhaW5lckNsYXNzIiwiY3JlYXRlQWRTbG90Iiwid3JhcFNsb3RJbkNvbnRhaW5lciIsImNvbXB1dGVTdGlja3lIZWlnaHRzIiwiaW5zZXJ0SGVpZ2h0U3R5bGVzIiwiaW5pdENhcnJvdCIsInJ1bGVzIiwic3BhY2VGaWxsZXIiLCJhcnRpY2xlQm9keVNlbGVjdG9yIiwiaXNQYWlkQ29udGVudCIsImdldFN0aWNreUNvbnRhaW5lckNsYXNzbmFtZSIsImkiLCJpbnNlcnRTbG90QXRQYXJhIiwicGFyYSIsImNsYXNzZXMiLCJjb250YWluZXJPcHRpb25zIiwiYWQiLCJfeDQiLCJkZWNpZGVBZGRpdGlvbmFsU2l6ZXMiLCJ3aW5uaW5nUGFyYSIsImlzTGFzdElubGluZSIsImRpc3RhbmNlRnJvbUJvdHRvbSIsIl9kb2N1bWVudCRxdWVyeVNlbGVjdCIsInBhcmFUb3AiLCJnZXRCb3VuZGluZ0NsaWVudFJlY3QiLCJ0b3AiLCJhcnRpY2xlQm9keUJvdHRvbSIsInF1ZXJ5U2VsZWN0b3IiLCJib3R0b20iLCJhYnMiLCJhZFNpemUiLCJfeDUiLCJfeDYiLCJfeDciLCJhZGREZXNrdG9wSW5saW5lMSIsImZpbGxTbG90IiwiaW5zZXJ0QWQiLCJwYXJhcyIsIl94OSIsIl94OCIsImZpbGxTcGFjZSIsImRlc2t0b3BJbmxpbmUxIiwid2FpdEZvckltYWdlcyIsIndhaXRGb3JJbnRlcmFjdGl2ZXMiLCJwYXNzIiwiYWRkRGVza3RvcFJpZ2h0UmFpbEFkcyIsImlzQ29uc2VudGxlc3MiLCJpbnNlcnRBZHMiLCJzdGlja3lDb250YWluZXJIZWlnaHRzIiwiY29udGFpbmVyQ2xhc3NlcyIsInN0aWNreSIsIl94MSIsIl94MTAiLCJfeDAiLCJkZXNrdG9wUmlnaHRSYWlsIiwiYWRkaXRpb25hbE1vYmlsZUFuZFRhYmxldElubGluZVNpemVzIiwiYWRkTW9iaWxlQW5kVGFibGV0SW5saW5lQWRzIiwiY3VycmVudEJyZWFrcG9pbnQiLCJfcmVmNyIsIl9yZWY4IiwiX3gxMiIsIl94MTMiLCJfeDExIiwibW9iaWxlQW5kVGFibGV0SW5saW5lcyIsImFkZElubGluZUFkcyIsIl9yZWY5IiwiZmlsbEFkU2xvdCIsImFydGljbGVCb2R5QWR2ZXJ0cyIsIl94MTQiLCJnZXRDdXJyZW50VHdlYWtwb2ludCIsImJvZHlTZWxlY3RvciIsIndpZGVSdWxlcyIsImNhbmRpZGF0ZVNlbGVjdG9yIiwibWluRGlzdGFuY2VGcm9tVG9wIiwibWluRGlzdGFuY2VGcm9tQm90dG9tIiwiY2xlYXJDb250ZW50TWV0YSIsIm9wcG9uZW50U2VsZWN0b3JSdWxlcyIsIm1hcmdpbkJvdHRvbSIsIm1hcmdpblRvcCIsImZyb21Cb3R0b20iLCJkZXNrdG9wUnVsZXMiLCJpbnNlcnRTbG90IiwiY2FuZGlkYXRlcyIsIl9jYW5kaWRhdGVzJCIsImdldFJ1bGVzIiwiY2Fycm90VHJhZmZpY0RyaXZlciIsImFkU2xvdENvbnRhaW5lclNlbGVjdG9yIiwiaGlnaFZhbHVlU2VjdGlvbnMiLCJpc0luSGlnaFZhbHVlU2VjdGlvbiIsIk1PU1RfVklFV0VEX0hFSUdIVCIsImlzSW1tZXJzaXZlIiwiaGFzSW1hZ2VzIiwibGlnaHRib3hJbWFnZXMiLCJpbWFnZXMiLCJoYXNWaWRlbyIsImhhc1lvdVR1YmVBdG9tIiwiaGFzU2hvd2Nhc2VNYWluRWxlbWVudCIsIm1pbkRpc3RhbmNlQmV0d2VlblJpZ2h0UmFpbEFkcyIsIm1pbkRpc3RhbmNlQmV0d2VlbklubGluZUFkcyIsImxlZnRDb2x1bW5PcHBvbmVudFNlbGVjdG9yIiwicm9sZSIsInJpZ2h0Q29sdW1uT3Bwb25lbnRTZWxlY3RvciIsImlubGluZU9wcG9uZW50U2VsZWN0b3IiLCJoZWFkaW5nU2VsZWN0b3IiLCJkZXNrdG9wUmlnaHRSYWlsTWluQWJvdmUiLCJiYXNlIiwiY2FuZGlkYXRlIiwibGFzdFdpbm5lciIsImxhcmdlc3RTaXplRm9yU2xvdCIsImRpc3RhbmNlQmV0d2VlbkFkcyIsIm1vYmlsZU1pbkRpc3RhbmNlRnJvbUFydGljbGVUb3AiLCJtb2JpbGVDYW5kaWRhdGVTZWxlY3RvciIsIm1vYmlsZUhlYWRpbmdTZWxlY3RvciIsIm1vYmlsZU9wcG9uZW50U2VsZWN0b3JSdWxlcyIsImJ5cGFzc01pblRvcCIsImZpbmRTcGFjZSIsIlNwYWNlRXJyb3IiLCJTcGFjZUZpbGxlciIsIndyaXRlciIsIm9wdGlvbnMiLCJpbnNlcnROZXh0Q29udGVudCIsInBhcmFncmFwaHMiLCJleCIsIm1lbW9pemUiLCJxdWVyeSIsInNlbGVjdG9yIiwiY29udGV4dCIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJMT0FESU5HX1RJTUVPVVQiLCJkZWZhdWx0T3B0aW9ucyIsImlzSWZyYW1lIiwiSFRNTElGcmFtZUVsZW1lbnQiLCJpc0lmcmFtZUxvYWRlZCIsImlmcmFtZSIsIl9pZnJhbWUkY29udGVudFdpbmRvdyIsImNvbnRlbnRXaW5kb3ciLCJyZWFkeVN0YXRlIiwiZ2V0RnVuY0lkIiwiaXNJbWFnZSIsImVsZW1lbnQiLCJIVE1MSW1hZ2VFbGVtZW50Iiwib25JbWFnZXNMb2FkZWQiLCJub3RMb2FkZWQiLCJpbWciLCJjb21wbGV0ZSIsImxvYWRpbmciLCJpbWdQcm9taXNlcyIsIndhaXRGb3JTZXRIZWlnaHRNZXNzYWdlIiwiY2FsbGJhY2siLCJzb3VyY2UiLCJvbkludGVyYWN0aXZlc0xvYWRlZCIsImlmcmFtZXMiLCJmcm9tIiwiY2hpbGRyZW4iLCJtdXRhdGlvbnMiLCJNdXRhdGlvbk9ic2VydmVyIiwicmVjb3JkcyIsImluc3RhbmNlIiwiX3JlY29yZHMkIiwiX3JlY29yZHMkMiIsImFkZGVkTm9kZXMiLCJkaXNjb25uZWN0IiwiY2hpbGRMaXN0IiwicGFydGl0aW9uQ2FuZGlkYXRlcyIsImxpc3QiLCJmaWx0ZXJFbGVtZW50IiwiZXhjbHVzaW9ucyIsImlzVG9wT2ZDYW5kaWRhdGVGYXJFbm91Z2hGcm9tT3Bwb25lbnQiLCJvcHBvbmVudCIsInJ1bGUiLCJpc09wcG9uZW50QmVsb3ciLCJwb3RlbnRpYWxJbnNlcnRQb3NpdGlvbiIsIm1hdGNoZXMiLCJieXBhc3NUZXN0Q2FuZGlkYXRlIiwidGVzdENhbmRpZGF0ZSIsImlzT3Bwb25lbnRBYm92ZSIsIm9wcG9uZW50T3ZlcmxhcHMiLCJtZXRhIiwib3ZlcmxhcHMiLCJyZXF1aXJlZCIsImFjdHVhbCIsInRvb0Nsb3NlIiwidGVzdENhbmRpZGF0ZXMiLCJvcHBvbmVudHMiLCJlbmZvcmNlUnVsZXMiLCJtZWFzdXJlbWVudHMiLCJzcGFjZWZpbmRlckV4Y2x1c2lvbnMiLCJhYnNvbHV0ZU1pbkRpc3RhbmNlRnJvbVRvcCIsImJvZHlUb3AiLCJmYXJFbm91Z2hGcm9tVG9wT2ZCb2R5IiwiZmFyRW5vdWdoRnJvbUJvdHRvbU9mQm9keSIsImJvZHlIZWlnaHQiLCJhYm92ZUFuZEJlbG93IiwiY29udGVudE1ldGEiLCJzZWxlY3RvckV4Y2x1c2lvbnMiLCJfbG9vcCIsIl9tZWFzdXJlbWVudHMkb3Bwb25lbiIsIl9tZWFzdXJlbWVudHMkb3Bwb25lbjIiLCJnZXRSZWFkeSIsImdldENhbmRpZGF0ZXMiLCJyZXZlcnNlIiwic3RhcnRBdCIsImRyb3AiLCJzdG9wQXQiLCJrZWVwIiwiZ2V0RGltZW5zaW9ucyIsImZyZWV6ZSIsIm9mZnNldFRvcCIsIm9mZnNldEhlaWdodCIsImdldE1lYXN1cmVtZW50cyIsImJvZHlEaXN0YW5jZVRvVG9wT2ZQYWdlIiwiRWxlbWVudCIsImJvZHlFbGVtZW50Iiwic2Nyb2xsWSIsImNhbmRpZGF0ZXNXaXRoRGltcyIsImNvbnRlbnRNZXRhV2l0aERpbXMiLCJvcHBvbmVudHNXaXRoRGltcyIsInNlbGVjdGVkRWxlbWVudHMiLCJfZG9jdW1lbnQkcXVlcnlTZWxlY3QyIiwiX21lYXN1cmUkZHVyYXRpb24iLCJ3aW5uZXJzIiwiZW5hYmxlRGVidWciLCJzZmRlYnVnIiwicm91bmQiLCJpc1VuZGVmaW5lZCIsIlBBUkFHUkFQSF9CVUZGRVJfUFgiLCJJTU1FUlNJVkVfQlVGRkVSX1BYIiwiQVJUSUNMRV9CT1RUT01fQlVGRkVSX1BYIiwiTEFCU19IRUFERVJfSEVJR0hUIiwiaGVpZ2h0TWFwcGluZyIsImhlaWdodENsYXNzZXMiLCJjc3MiLCJjcmVhdGVUZXh0Tm9kZSIsImhlYWQiLCJpbW1lcnNpdmVGaWd1cmVzIiwiZmlndXJlcyIsIndpbm5pbmdQYXJhcyIsImFydGljbGVCb2R5RWxlbWVudEhlaWdodEJvdHRvbSIsImtpbmQiLCJzb3J0IiwiZmlyc3QiLCJzZWNvbmQiLCJjdXJyZW50IiwiaXRlbXMiLCJuZXh0IiwiYnVmZmVyIiwicHVibWF0aWMiLCJiaWQiLCJhY0VuYWJsZWQiLCJ1dGlscyIsImRlZmF1bHRGbiIsInBzZWdzIiwibG9jYWxTdG9yYWdlIiwiX3BzZWdzIiwicHBhbSIsIl9wcGFtIiwicGNycHJzIiwiX3BjcnBycyIsImFjIiwic2VnIiwicGJqcyIsInNldEJpZGRlckNvbmZpZyIsImJpZGRlcnMiLCJvcnRiMiIsInVzZXIiLCJzZWdtZW50IiwiaXNPYmplY3QiLCJwYXJ0aWNpcGF0aW9uc0tleSIsImlzUGFydGljaXBhdGlvbnMiLCJ2YWx1ZXMiLCJwYXJ0aWNpcGF0aW9uIiwiYWRTbG90SWRQcmVmaXgiLCJhZFNsb3RDb25maWdzIiwibGFiZWwiLCJjcmVhdGVBZFNsb3RFbGVtZW50IiwiYXR0cnMiLCJnZXRFbGVtZW50QnlJZCIsInJlbW92ZUNoaWxkIiwibGlua05hbWUiLCJ2IiwiY3JlYXRlQ2xhc3NlcyIsIl9jbGFzc2VzJHNwbGl0IiwiZGVmYXVsdFNpemVNYXBwaW5ncyIsIm9wdGlvblNpemVNYXBwaW5ncyIsImNvbWJpbmVkU2l6ZU1hcHBpbmciLCJfY29tYmluZWRTaXplTWFwcGluZyQiLCJkZXZpY2UiLCJvcHRpb25TaXplcyIsImV4aXN0aW5nU2l6ZSIsIl9vcHRpb25zJGNsYXNzTmFtZSIsIl9hZFNsb3RDb25maWdzJG5hbWUiLCJfb3B0aW9ucyRuYW1lIiwiYWRTbG90Q29uZmlnIiwiZGF0YUF0dHJpYnV0ZXMiLCJfZGZwRW52JGFkdmVydHMkZ2V0IiwiZmxhdHRlbiIsImdldEhlYWRlckJpZGRpbmdBZFNsb3RzIiwiQTlBZFVuaXQiLCJzbG90SUQiLCJpbml0aWFsaXNlZCIsInJlcXVlc3RRdWV1ZSIsImJpZGRlclRpbWVvdXQiLCJpbml0aWFsaXNlIiwiYXBzdGFnIiwiYmxvY2tlZEJpZGRlcnMiLCJpc0Zyb250IiwicHViSUQiLCJhOVB1Ymxpc2hlcklkIiwiYWRTZXJ2ZXIiLCJiaWRUaW1lb3V0IiwibG9nQTlCaWRSZXNwb25zZSIsImJpZFJlc3BvbnNlIiwiX3dpbmRvdyRndWFyZGlhbiIsIl93aW5kb3ckZ3VhcmRpYW4kY29tbSIsIl93aW5kb3ckZ3VhcmRpYW4kY29tbTIiLCJfd2luZG93JGd1YXJkaWFuJGNvbW0zIiwiY29tbWVyY2lhbCIsImE5V2lubmluZ0JpZHMiLCJzbG90RmxhdE1hcCIsImE5SGVhZGVyQmlkZGluZyIsImFkVW5pdHMiLCJfd2luZG93JGFwc3RhZyIsImZldGNoQmlkcyIsIl93aW5kb3ckYXBzdGFnMiIsInNldERpc3BsYXlCaWRzIiwiYnVpbGRBcHBOZXh1c1RhcmdldGluZ09iamVjdCIsImNvbnRhaW5zQmlsbGJvYXJkTm90TGVhZGVyYm9hcmQiLCJjb250YWluc0xlYWRlcmJvYXJkIiwiY29udGFpbnNMZWFkZXJib2FyZE9yQmlsbGJvYXJkIiwiY29udGFpbnNNb2JpbGVTdGlja3kiLCJjb250YWluc01wdSIsImNvbnRhaW5zTXB1T3JEbXB1IiwiZ2V0QnJlYWtwb2ludEtleSIsImdldExhcmdlc3RTaXplIiwiZ2V0QXBwTmV4dXNJbnZDb2RlIiwic2VjdGlvbk5hbWUiLCJzbG90U2l6ZSIsImdldEFwcE5leHVzRGlyZWN0UGxhY2VtZW50SWQiLCJkZWZhdWx0UGxhY2VtZW50SWQiLCJnZXRBcHBOZXh1c0RpcmVjdEJpZFBhcmFtcyIsInByZWJpZEFwcG5leHVzSW52Y29kZSIsImludkNvZGUiLCJtZW1iZXIiLCJpbnZjIiwicGxhY2VtZW50SWQiLCJwYlRlc3ROYW1lTWFwIiwiY29udGFpbnNCaWxsYm9hcmQiLCJjb250YWluc0RtcHUiLCJzaG91bGRJbmNsdWRlQmlkZGVyIiwic3RyaXBNb2JpbGVTdWZmaXgiLCJnZXRNYWduaXRlU2l0ZUlkIiwiZ2V0TWFnbml0ZVpvbmVJZCIsImlzQXJ0aWNsZSIsImlzRGVza3RvcEFuZEFydGljbGUiLCJnZXRUcnVzdFhBZFVuaXRJZCIsImlzRGVza3RvcEFydGljbGUiLCJnZXRJbmRleFNpdGVJZEZyb21Db25maWciLCJzaXRlIiwicGJJbmRleFNpdGVzIiwiZ2V0SW5kZXhTaXRlSWQiLCJnZXRYYXhpc1BsYWNlbWVudElkIiwiZ2V0VHJpcGxlTGlmdEludmVudG9yeUNvZGUiLCJpc1BiVGVzdE9uIiwiaW5QYlRlc3RPciIsImxpdmVDbGF1c2UiLCJhcHBOZXh1c0JpZGRlciIsInN3aXRjaE5hbWUiLCJiaWRQYXJhbXMiLCJvcGVueEJpZGRlciIsImN1c3RvbVBhcmFtcyIsImRlbERvbWFpbiIsInVuaXQiLCJnZXRPem9uZVBsYWNlbWVudElkIiwib3pvbmVCaWRkZXIiLCJfc2xvdElkIiwicHVibGlzaGVySWQiLCJzaXRlSWQiLCJjdXN0b21EYXRhIiwic2V0dGluZ3MiLCJvem9uZURhdGEiLCJnZXRQdWJtYXRpY1B1Ymxpc2hlcklkIiwiZ2V0S2FyZ29QbGFjZW1lbnRJZCIsImdldFB1Ym1hdGljUGxhY2VtZW50SWQiLCJwdWJtYXRpY0JpZGRlciIsImRlZmF1bHRQYXJhbXMiLCJ0cnVzdFhCaWRkZXIiLCJ1aWQiLCJ0cmlwbGVMaWZ0QmlkZGVyIiwiaW52ZW50b3J5Q29kZSIsInRhZ2lkIiwieGF4aXNCaWRkZXIiLCJjcml0ZW9CaWRkZXIiLCJ6b25lSWQiLCJuZXR3b3JrSWQiLCJrYXJnb0JpZGRlciIsIm1hZ25pdGVCaWRkZXIiLCJhY2NvdW50SWQiLCJ0aGVUcmFkZURlc2tCaWRkZXIiLCJncGlkIiwic3VwcGx5U291cmNlSWQiLCJpbmRleEV4Y2hhbmdlQmlkZGVycyIsImJpZGRlcnNCZWluZ1Rlc3RlZCIsImFsbEJpZGRlcnMiLCJiaWRkZXIiLCJjdXJyZW50QmlkZGVycyIsInNob3VsZEluY2x1ZGUiLCJpeEJpZGRlcnMiLCJiaWRkZXJzVG9DaGVjayIsIm90aGVyQmlkZGVycyIsImJpZHMiLCJwYXJhbXMiLCJjb250YWluc1BvcnRyYWl0SW50ZXJzdGl0aWFsIiwiY29udGFpbnNXUyIsImlzVXNlckxvZ2dlZEluIiwiZ2V0UGFnZVRhcmdldGluZyIsImlzU3dpdGNoZWRPbiIsInNob3VsZEluY2x1ZGVQZXJtdXRpdmUiLCJvdmVycmlkZVByaWNlQnVja2V0IiwicHJpY2VHcmFudWxhcml0eSIsIlByZWJpZEFkVW5pdCIsImNvZGUiLCJtZWRpYVR5cGVzIiwiYmFubmVyIiwiZ2VuZXJhdGVHcGlkIiwib3J0YjJJbXAiLCJleHQiLCJwYmFkc2xvdCIsImhlYWRlckJpZGRpbmdTaXplcyIsInNob3VsZEVuYWJsZUFuYWx5dGljcyIsInByZWJpZEFuYWx5dGljcyIsImFuYWx5dGljc1NhbXBsZVJhdGUiLCJpc0luU2FtcGxlIiwiaXNJblNlcnZlclNpZGVUZXN0IiwiaXNJbkNsaWVudFNpZGVUZXN0IiwiaGFzUXVlcnlQYXJhbSIsInNlYXJjaCIsInRpbWVvdXRCdWZmZXIiLCJ1c2VySWRzIiwiZXhwaXJlcyIsInBhcnRuZXIiLCJyZWZyZXNoSW5TZWNvbmRzIiwidXNlclN5bmMiLCJzeW5jc1BlckJpZGRlciIsImZpbHRlclNldHRpbmdzIiwic3luY0VuYWJsZWQiLCJjb25zZW50TWFuYWdlbWVudCIsInVzcCIsImNtcEFwaSIsImdwcCIsImdkcHIiLCJkZWZhdWx0R2RwclNjb3BlIiwicGJqc0NvbmZpZyIsImFzc2lnbiIsImtleXdvcmRzQXJyYXkiLCJiaWRkZXJTZXR0aW5ncyIsImluY2x1ZGVkQWNCaWRkZXJzIiwicmVhbFRpbWVEYXRhIiwiZGF0YVByb3ZpZGVycyIsImFjQmlkZGVycyIsIm92ZXJ3cml0ZXMiLCJjcml0ZW8iLCJzdG9yYWdlQWxsb3dlZCIsImFkc2VydmVyVGFyZ2V0aW5nIiwiY3BtIiwicGJDZyIsIm96b25lIiwiaXgiLCJlbmFibGVBbmFseXRpY3MiLCJwcm92aWRlciIsInhoYiIsIl9iaWRSZXNwb25zZSRhcHBuZXh1cyIsIl9iaWRSZXNwb25zZSRhcHBuZXh1czIiLCJhcHBuZXh1cyIsImJ1eWVyTWVtYmVySWQiLCJiaWRDcG1BZGp1c3RtZW50IiwiYmlkQ3BtIiwia2FyZ28iLCJtYWduaXRlIiwic2V0Q29uZmlnIiwib25FdmVudCIsImFkVW5pdENvZGUiLCJoYXNQcmViaWRTaXplIiwiYmlkc0JhY2tIYW5kbGVyIiwiX3dpbmRvdyRwYmpzIiwic2V0VGFyZ2V0aW5nRm9yR1BUQXN5bmMiLCJ1IiwicHJlYmlkSGVhZGVyQmlkZGluZyIsIl93aW5kb3ckcGJqczIiLCJxdWUiLCJfd2luZG93JHBianMzIiwiZ2V0UHJpY2VCdWNrZXRTdHJpbmciLCJidWNrZXRzIiwibWF4IiwiaW5jcmVtZW50IiwiY3JpdGVvUHJpY2VHcmFudWxhcml0eSIsIm96b25lUHJpY2VHcmFudWxhcml0eSIsInNpemVTdHJpbmciLCJpbmRleFByaWNlR3JhbnVsYXJpdHkiLCJnZXRQcmljZUdyYW51bGFyaXR5Rm9yU2l6ZSIsImRlZmF1bHRQcmljZUJ1Y2tldCIsInByaWNlQnVja2V0Iiwic2hvdWxkSW5jbHVkZU1vYmlsZVN0aWNreSIsImdldEhiQnJlYWtwb2ludCIsImZpbHRlckJ5U2l6ZU1hcHBpbmciLCJmaWx0ZXJlZFNpemVzIiwiaGJXaWR0aCIsImhiSGVpZ2h0IiwiZ2V0SGVhZGVyQmlkZGluZ0tleSIsImdldFNsb3ROYW1lc0Zyb21TaXplTWFwcGluZyIsImZpbHRlckJ5QWR2ZXJ0IiwiX3NpemVNYXBwaW5nJGtleSIsInNsb3ROYW1lcyIsImdldFNsb3RzIiwiaGFzRXh0ZW5kZWRNb3N0UG9wIiwiZXh0ZW5kZWRNb3N0UG9wdWxhciIsImlubGluZTEiLCJpbmxpbmUyIiwiaGVhZGVyQmlkZGluZ1Nsb3RzIiwiZWx0IiwibWF0Y2hlc0JyZWFrcG9pbnRzIiwiU1VGRklYX1JFR0VYUFMiLCJzdHJpcFN1ZmZpeCIsInN1ZmZpeCIsIl9TVUZGSVhfUkVHRVhQUyRzdWZmaSIsInJlIiwiUmVnRXhwIiwiUFJFRklYX1JFR0VYUFMiLCJzdHJpcFByZWZpeCIsInByZWZpeCIsIl9QUkVGSVhfUkVHRVhQUyRwcmVmaSIsImlzVmFsaWRQYWdlRm9yTW9iaWxlU3RpY2t5IiwicmVtb3ZlRmFsc3lWYWx1ZXMiLCJvIiwiY3VyciIsInJlZHVjZXIiLCJwcmV2aW91cyIsImdldFJhbmRvbUludEluY2x1c2l2ZSIsIm1pbmltdW0iLCJtYXhpbXVtIiwiYW5kIiwiaXNIb3N0ZWQiLCJzdHJpcFRyYWlsaW5nTnVtYmVyc0Fib3ZlMSIsInNob3VsZEluY2x1ZGVPbmx5QTkiLCJnZXRJZGVudGl0eUF1dGgiLCJnZXRBdXRoU3RhdHVzIiwiaXNBdXRoZW50aWNhdGVkIiwiYWNjZXNzVG9rZW4iLCJpZFRva2VuIiwiaXNTaWduZWRJbldpdGhBdXRoU3RhdGUiLCJnZXRHb29nbGVUYWdJZCIsImF1dGhTdGF0dXMiLCJjbGFpbXMiLCJnb29nbGVfdGFnX2lkIiwiTElTVEVORVJTIiwiUkVHSVNURVJFRF9MSVNURU5FUlMiLCJlcnJvcjQwNSIsImVycm9yNTAwIiwiaXNQcm9ncmFtbWF0aWNNZXNzYWdlIiwicGF5bG9hZCIsInBheWxvYWRUb0NoZWNrIiwidG9TdGFuZGFyZE1lc3NhZ2UiLCJpZnJhbWVJZCIsImdldElmcmFtZSIsIm1lc3NhZ2VFdmVudFNvdXJjZSIsIl9jb250YWluZXIkcXVlcnlTZWxlYyIsImVsIiwidmFsaWRNZXNzYWdlUmVnZXgiLCJpc1ZhbGlkUGF5bG9hZCIsImZvcm1hdEVycm9yIiwiYXJncyIsImFyZyIsImV2ZW50VG9TdGFuZGFyZE1lc3NhZ2UiLCJyZXNwb25kIiwib25NZXNzYWdlIiwiZnVuYyIsInJldCIsInRoaXNSZXQiLCJyZXNwb25zZSIsIm9uIiwib2ZmIiwicmVnaXN0ZXIiLCJfTElTVEVORVJTJHR5cGUiLCJfb3B0aW9ucyR3aW5kb3ciLCJsaXN0ZW5lcnMiLCJyZWdpc3RlclBlcnNpc3RlbnRMaXN0ZW5lciIsIl9vcHRpb25zJHdpbmRvdzIiLCJ1bnJlZ2lzdGVyIiwiY2IiLCJjYWxsYmFja3NFcXVhbCIsIl9vcHRpb25zJHdpbmRvdzMiLCJwZXJzaXN0ZW50TGlzdGVuZXJzIiwibW9kdWxlSW5pdCIsInNlbmRQcm9ncmVzc09uVW5sb2FkT25jZSIsInVwZGF0ZVZpZGVvUHJvZ3Jlc3MiLCJJTlRFUlNDUk9MTEVSX1RFTVBMQVRFX0lEIiwiZ2V0U3R5bGVzRnJvbVNwZWMiLCJzcGVjcyIsInN0eWxlcyIsInNjcm9sbFR5cGUiLCJjdGFVcmwiLCJ2aWRlb1NvdXJjZSIsImJhY2tncm91bmRDb2xvdXIiLCJiYWNrZ3JvdW5kQ29sb3IiLCJpc0JhY2tncm91bmRTcGVjcyIsImNyZWF0ZVBhcmVudCIsImJhY2tncm91bmRQYXJlbnQiLCJiYWNrZ3JvdW5kIiwiekluZGV4IiwicG9zaXRpb24iLCJpbnNldCIsImNsaXBQYXRoIiwib3ZlcmZsb3ciLCJ0cmFuc2l0aW9uIiwic2V0QmFja2dyb3VuZFN0eWxlcyIsInNwZWNTdHlsZXMiLCJzZXRDdGFVUkwiLCJjdGFVUkwiLCJjdGFVUkxBbmNob3IiLCJyZW5kZXJCb3R0b21MaW5lIiwiYm90dG9tTGluZSIsImJvcmRlckJvdHRvbSIsInNldHVwUGFyYWxsYXgiLCJvblNjcm9sbCIsInJlY3QiLCJiYWNrZ3JvdW5kSGVpZ2h0Iiwid2luZG93SGVpZ2h0IiwicGFyYWxsYXhCYWNrZ3JvdW5kTW92ZW1lbnQiLCJiYWNrZ3JvdW5kUG9zaXRpb25ZIiwib25JbnRlcnNlY3QiLCJwYXNzaXZlIiwic2V0dXBCYWNrZ3JvdW5kIiwiaW50ZXJzY3JvbGxlclRlbXBsYXRlSWQiLCJhbmNob3IiLCJ2aWRlbyIsImF1dG9wbGF5IiwibXV0ZWQiLCJwbGF5c0lubGluZSIsInNyYyIsInRyYW5zZm9ybSIsInBsYXllZCIsIm9uZW5kZWQiLCJwYXVzZWQiLCJwbGF5IiwicGF1c2UiLCJyb290IiwidGhyZXNob2xkIiwic2hvdWxkUmVwb3J0VmlkZW9Qcm9ncmVzcyIsIm9udGltZXVwZGF0ZSIsInBlcmNlbnQiLCJjdXJyZW50VGltZSIsImlzVmFsaWRSZXNpemVTcGVjcyIsIm5vcm1hbGlzZSIsIl9tYXRjaGVzJCIsImxlbmd0aFJlZ2V4cCIsImRlZmF1bHRVbml0IiwiZXhlYyIsInJlc2l6ZSIsImlmcmFtZUNvbnRhaW5lciIsIm1heEhlaWdodCIsInJlbW92ZUFueU91dHN0cmVhbUNsYXNzIiwiX2lmcmFtZSRjbG9zZXN0IiwiX2lmcmFtZSRjbG9zZXN0MiIsInNldFR5cGUiLCJhZFNsb3RUeXBlIiwiZm9ybWF0QXBwTmV4dXNUYXJnZXRpbmciLCJhc0tleVZhbHVlcyIsIm5lc3RlZFZhbHVlIiwiZmxhdHRlbkRlZXAiLCJwcm90b3R5cGUiLCJwdDEiLCJwdDIiLCJwdDMiLCJjdCIsInB0NCIsInAiLCJwdDUiLCJwdDYiLCJzdSIsInB0NyIsInB0OSIsImNvIiwidG4iLCJidWlsZEFwcE5leHVzVGFyZ2V0aW5nIiwiYXBwTmV4dXNQYWdlVGFyZ2V0aW5nIiwicGFnZUFkVGFyZ2V0aW5nIiwiY2hlY2tDb25zZW50Rm9yUmVwb3J0aW5nIiwidmlkZW9Qcm9ncmVzcyIsInNlbmRQcm9ncmVzcyIsImNyZWF0aXZlSWQiLCJsaW5lSXRlbUlkIiwicHJvZ3Jlc3MiLCJ1cGRhdGVkUHJvZ3Jlc3MiXSwic291cmNlUm9vdCI6IiJ9