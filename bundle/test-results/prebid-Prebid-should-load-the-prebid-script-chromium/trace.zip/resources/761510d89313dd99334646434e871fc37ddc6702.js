/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/aus/api.js":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/aus/api.js ***!
  \*****************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getUSPData: () => (/* binding */ getUSPData)
/* harmony export */ });
var api = command => new Promise((resolve, reject) => {
  if (window.__uspapi) {
    window.__uspapi(command, 1, (result, success) => success ? resolve(result) : (/* istanbul ignore next */
    reject(new Error("Unable to get ".concat(command, " data")))));
  } else {
    reject(new Error("No __uspapi found on window"));
  }
});
var getUSPData = () => api("getUSPData");


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/aus/getConsentState.js":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/aus/getConsentState.js ***!
  \*****************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getConsentState: () => (/* binding */ getConsentState)
/* harmony export */ });
/* harmony import */ var _api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/aus/api.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }

var getConsentState = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var uspData = yield (0,_api_js__WEBPACK_IMPORTED_MODULE_0__.getUSPData)();
    var optedOut = uspData.uspString.charAt(2) === "Y";
    return {
      personalisedAdvertising: !optedOut
    };
  });
  return function getConsentState() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/cmp.js":
/*!*************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/cmp.js ***!
  \*************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   CMP: () => (/* binding */ CMP)
/* harmony export */ });
/* harmony import */ var _getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getCurrentFramework.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getCurrentFramework.js");
/* harmony import */ var _isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./isConsentOrPay.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/isConsentOrPay.js");
/* harmony import */ var _lib_mark_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/mark.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/mark.js");
/* harmony import */ var _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lib/sourcepointConfig.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js");
/* harmony import */ var _sourcepoint_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./sourcepoint.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/sourcepoint.js");





var init = (framework, countryCode, isUserSignedIn, useNonAdvertisedList, pubData) => {
  (0,_lib_mark_js__WEBPACK_IMPORTED_MODULE_2__.mark)("cmp-init");
  (0,_sourcepoint_js__WEBPACK_IMPORTED_MODULE_4__.init)(framework, countryCode, isUserSignedIn, useNonAdvertisedList, pubData);
};
var willShowPrivacyMessage = () => _sourcepoint_js__WEBPACK_IMPORTED_MODULE_4__.willShowPrivacyMessage;
function showPrivacyManager() {
  var _window$_sp_, _window$_sp_$loadPriv, _window$_sp_2, _window$_sp_2$loadPri, _window$_sp_3, _window$_sp_3$loadPri;
  switch ((0,_getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_0__.getCurrentFramework)()) {
    case "tcfv2":
      (_window$_sp_ = window._sp_) === null || _window$_sp_ === void 0 || (_window$_sp_ = _window$_sp_.gdpr) === null || _window$_sp_ === void 0 || (_window$_sp_$loadPriv = _window$_sp_.loadPrivacyManagerModal) === null || _window$_sp_$loadPriv === void 0 || _window$_sp_$loadPriv.call(_window$_sp_, (0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_1__.getIsConsentOrPay)() ? _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PRIVACY_MANAGER_TCFV2_CONSENT_OR_PAY : _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PRIVACY_MANAGER_TCFV2);
      break;
    case "usnat":
      (_window$_sp_2 = window._sp_) === null || _window$_sp_2 === void 0 || (_window$_sp_2 = _window$_sp_2.usnat) === null || _window$_sp_2 === void 0 || (_window$_sp_2$loadPri = _window$_sp_2.loadPrivacyManagerModal) === null || _window$_sp_2$loadPri === void 0 || _window$_sp_2$loadPri.call(_window$_sp_2, _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PRIVACY_MANAGER_USNAT);
      break;
    case "aus":
      (_window$_sp_3 = window._sp_) === null || _window$_sp_3 === void 0 || (_window$_sp_3 = _window$_sp_3.ccpa) === null || _window$_sp_3 === void 0 || (_window$_sp_3$loadPri = _window$_sp_3.loadPrivacyManagerModal) === null || _window$_sp_3$loadPri === void 0 || _window$_sp_3$loadPri.call(_window$_sp_3, _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PRIVACY_MANAGER_AUSTRALIA);
      break;
  }
}
var CMP = {
  init,
  willShowPrivacyMessage,
  showPrivacyManager
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/disable.js":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/disable.js ***!
  \*****************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   disable: () => (/* binding */ disable),
/* harmony export */   enable: () => (/* binding */ enable),
/* harmony export */   isDisabled: () => (/* binding */ isDisabled)
/* harmony export */ });
var COOKIE_NAME = "gu-cmp-disabled";
var disable = () => {
  document.cookie = "".concat(COOKIE_NAME, "=true");
};
var enable = () => {
  document.cookie = "".concat(COOKIE_NAME, "=false");
};
var isDisabled = () => new RegExp("".concat(COOKIE_NAME, "=true(\\W+|$)")).test(document.cookie);


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/exclusionList.js":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/exclusionList.js ***!
  \***********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isExcludedFromCMP: () => (/* binding */ isExcludedFromCMP)
/* harmony export */ });
var sectionExclusionList = ["info", "help"];
var isExcludedFromCMP = pageSection => {
  return sectionExclusionList.some(section => section === pageSection);
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getConsentFor.js":
/*!***********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getConsentFor.js ***!
  \***********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getConsentFor: () => (/* binding */ getConsentFor)
/* harmony export */ });
/* harmony import */ var _vendors_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./vendors.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendors.js");

var getConsentFor = (vendor, consent) => {
  var _consent$tcfv2;
  var sourcepointIds = _vendors_js__WEBPACK_IMPORTED_MODULE_0__.VendorIDs[vendor];
  if (typeof sourcepointIds === "undefined" || sourcepointIds.length === 0) {
    throw new Error("Vendor '".concat(vendor, "' not found, or with no Sourcepoint ID. If it should be added, raise an issue at https://github.com/guardian/consent-management-platform/issues"));
  }
  if (consent.usnat) {
    return !consent.usnat.doNotSell;
  }
  if (consent.aus) {
    return consent.aus.personalisedAdvertising;
  }
  var foundSourcepointId = sourcepointIds.find(id => {
    var _consent$tcfv;
    return typeof ((_consent$tcfv = consent.tcfv2) === null || _consent$tcfv === void 0 ? void 0 : _consent$tcfv.vendorConsents[id]) !== "undefined";
  });
  if (typeof foundSourcepointId === "undefined") {
    console.warn("No consent returned from Sourcepoint for vendor: '".concat(vendor, "'"));
    return false;
  }
  var tcfv2Consent = (_consent$tcfv2 = consent.tcfv2) === null || _consent$tcfv2 === void 0 ? void 0 : _consent$tcfv2.vendorConsents[foundSourcepointId];
  if (typeof tcfv2Consent === "undefined") {
    console.warn("No consent returned from Sourcepoint for vendor: '".concat(vendor, "'"));
    return false;
  }
  return tcfv2Consent;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getCurrentFramework.js":
/*!*****************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getCurrentFramework.js ***!
  \*****************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCurrentFramework: () => (/* binding */ getCurrentFramework),
/* harmony export */   setCurrentFramework: () => (/* binding */ setCurrentFramework)
/* harmony export */ });
/* harmony import */ var _logger_logger_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../logger/logger.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");

var currentFramework;
var setCurrentFramework = framework => {
  (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "Framework set to ".concat(framework));
  currentFramework = framework;
};
var getCurrentFramework = () => currentFramework;


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getFramework.js":
/*!**********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getFramework.js ***!
  \**********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getFramework: () => (/* binding */ getFramework)
/* harmony export */ });
var getFramework = countryCode => {
  var framework;
  switch (countryCode) {
    case "US":
      framework = "usnat";
      break;
    case "AU":
      framework = "aus";
      break;
    case "GB":
    default:
      framework = "tcfv2";
      break;
  }
  return framework;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js":
/*!***************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js ***!
  \***************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cmp: () => (/* binding */ cmp),
/* harmony export */   getConsentFor: () => (/* binding */ getConsentFor),
/* harmony export */   onConsent: () => (/* binding */ onConsent),
/* harmony export */   onConsentChange: () => (/* binding */ onConsentChange)
/* harmony export */ });
/* harmony import */ var _package_json_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../package.json.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/package.json.js");
/* harmony import */ var _logger_logger_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../logger/logger.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _cmp_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./cmp.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/cmp.js");
/* harmony import */ var _disable_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./disable.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/disable.js");
/* harmony import */ var _getConsentFor_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./getConsentFor.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getConsentFor.js");
/* harmony import */ var _getFramework_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./getFramework.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getFramework.js");
/* harmony import */ var _onConsent_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./onConsent.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsent.js");
/* harmony import */ var _onConsentChange_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./onConsentChange.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsentChange.js");
/* harmony import */ var _server_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./server.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/server.js");
/* harmony import */ var _vendorDataManager_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./vendorDataManager.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendorDataManager.js");
var _a$cmp, _b$onConsent, _c$onConsentChange, _d$getConsentFor;










var _a, _b, _c, _d;
if (!_server_js__WEBPACK_IMPORTED_MODULE_8__.isServerSide) {
  if (typeof window.guCmpHotFix === "undefined") {
    window.guCmpHotFix = {};
  }
}
var _willShowPrivacyMessage;
var initComplete = false;
var resolveInitialised;
var initialised = new Promise(resolve => {
  resolveInitialised = resolve;
});
var init = _ref => {
  var {
    pubData,
    country,
    isUserSignedIn = false,
    useNonAdvertisedList = false
  } = _ref;
  if ((0,_disable_js__WEBPACK_IMPORTED_MODULE_3__.isDisabled)() || _server_js__WEBPACK_IMPORTED_MODULE_8__.isServerSide) {
    return;
  }
  if (window.guCmpHotFix.initialised) {
    var _window$guCmpHotFix$c;
    if (((_window$guCmpHotFix$c = window.guCmpHotFix.cmp) === null || _window$guCmpHotFix$c === void 0 ? void 0 : _window$guCmpHotFix$c.version) !== _package_json_js__WEBPACK_IMPORTED_MODULE_0__.version) {
      var _window$guCmpHotFix$c2;
      console.warn("Two different versions of the CMP are running:", [_package_json_js__WEBPACK_IMPORTED_MODULE_0__.version, (_window$guCmpHotFix$c2 = window.guCmpHotFix.cmp) === null || _window$guCmpHotFix$c2 === void 0 ? void 0 : _window$guCmpHotFix$c2.version]);
    }
    return;
  }
  window.guCmpHotFix.initialised = true;
  if (typeof country === "undefined") {
    throw new Error("CMP initialised without `country` property. A 2-letter, ISO ISO_3166-1 country code is required.");
  }
  var framework = (0,_getFramework_js__WEBPACK_IMPORTED_MODULE_5__.getFramework)(country);
  _cmp_js__WEBPACK_IMPORTED_MODULE_2__.CMP.init(framework, country, isUserSignedIn, useNonAdvertisedList, pubData !== null && pubData !== void 0 ? pubData : {});
  void _cmp_js__WEBPACK_IMPORTED_MODULE_2__.CMP.willShowPrivacyMessage().then(willShowValue => {
    _willShowPrivacyMessage = willShowValue;
    initComplete = true;
    (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_1__.log)("cmp", "initComplete");
  });
  resolveInitialised();
  (0,_vendorDataManager_js__WEBPACK_IMPORTED_MODULE_9__.initVendorDataManager)();
};
var willShowPrivacyMessage = () => initialised.then(() => _cmp_js__WEBPACK_IMPORTED_MODULE_2__.CMP.willShowPrivacyMessage());
var willShowPrivacyMessageSync = () => {
  if (_willShowPrivacyMessage !== void 0) {
    return _willShowPrivacyMessage;
  }
  throw new Error("CMP has not been initialised. Use the async willShowPrivacyMessage() instead.");
};
var hasInitialised = () => initComplete;
var showPrivacyManager = () => {
  void initialised.then(_cmp_js__WEBPACK_IMPORTED_MODULE_2__.CMP.showPrivacyManager);
};
var cmp = _server_js__WEBPACK_IMPORTED_MODULE_8__.isServerSide ? _server_js__WEBPACK_IMPORTED_MODULE_8__.cmp : (_a$cmp = (_a = window.guCmpHotFix).cmp) !== null && _a$cmp !== void 0 ? _a$cmp : _a.cmp = {
  init,
  willShowPrivacyMessage,
  willShowPrivacyMessageSync,
  hasInitialised,
  showPrivacyManager,
  version: _package_json_js__WEBPACK_IMPORTED_MODULE_0__.version,
  // special helper methods for disabling CMP
  __isDisabled: _disable_js__WEBPACK_IMPORTED_MODULE_3__.isDisabled,
  __enable: _disable_js__WEBPACK_IMPORTED_MODULE_3__.enable,
  __disable: _disable_js__WEBPACK_IMPORTED_MODULE_3__.disable
};
var onConsent = _server_js__WEBPACK_IMPORTED_MODULE_8__.isServerSide ? _server_js__WEBPACK_IMPORTED_MODULE_8__.onConsent : (_b$onConsent = (_b = window.guCmpHotFix).onConsent) !== null && _b$onConsent !== void 0 ? _b$onConsent : _b.onConsent = _onConsent_js__WEBPACK_IMPORTED_MODULE_6__.onConsent;
var onConsentChange = _server_js__WEBPACK_IMPORTED_MODULE_8__.isServerSide ? _server_js__WEBPACK_IMPORTED_MODULE_8__.onConsentChange : (_c$onConsentChange = (_c = window.guCmpHotFix).onConsentChange) !== null && _c$onConsentChange !== void 0 ? _c$onConsentChange : _c.onConsentChange = _onConsentChange_js__WEBPACK_IMPORTED_MODULE_7__.onConsentChange;
var getConsentFor = _server_js__WEBPACK_IMPORTED_MODULE_8__.isServerSide ? _server_js__WEBPACK_IMPORTED_MODULE_8__.getConsentFor : (_d$getConsentFor = (_d = window.guCmpHotFix).getConsentFor) !== null && _d$getConsentFor !== void 0 ? _d$getConsentFor : _d.getConsentFor = _getConsentFor_js__WEBPACK_IMPORTED_MODULE_4__.getConsentFor;


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/isConsentOrPay.js":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/isConsentOrPay.js ***!
  \************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getIsConsentOrPay: () => (/* binding */ getIsConsentOrPay),
/* harmony export */   isConsentOrPayCountry: () => (/* binding */ isConsentOrPayCountry),
/* harmony export */   setIsConsentOrPay: () => (/* binding */ setIsConsentOrPay)
/* harmony export */ });
/* harmony import */ var _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./lib/sourcepointConfig.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js");


var _isConsentOrPay = false;
var setIsConsentOrPay = isConsentOrPay => {
  _isConsentOrPay = isConsentOrPay;
};
var getIsConsentOrPay = () => {
  return _isConsentOrPay;
};
var isConsentOrPayCountry = countryCode => {
  return _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_0__.consentOrPayCountries.includes(countryCode);
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/domain.js":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/domain.js ***!
  \********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isGuardianDomain: () => (/* binding */ isGuardianDomain)
/* harmony export */ });
/* harmony import */ var _server_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../server.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/server.js");

var isGuardian;
var isGuardianDomain = () => {
  if (typeof isGuardian === "undefined") {
    if (_server_js__WEBPACK_IMPORTED_MODULE_0__.isServerSide) {
      isGuardian = true;
    } else {
      isGuardian = window.location.host.endsWith(".theguardian.com");
    }
  }
  return isGuardian;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/mark.js":
/*!******************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/mark.js ***!
  \******************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   mark: () => (/* binding */ mark)
/* harmony export */ });
/* harmony import */ var _logger_logger_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../logger/logger.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");

var mark = label => {
  var _window$performance, _window$performance$m;
  (_window$performance = window.performance) === null || _window$performance === void 0 || (_window$performance$m = _window$performance.mark) === null || _window$performance$m === void 0 || _window$performance$m.call(_window$performance, label);
  if (true) {
    (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "[event]", label);
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/ophan.js":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/ophan.js ***!
  \*******************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   constructBannerMessageId: () => (/* binding */ constructBannerMessageId),
/* harmony export */   sendConsentChoicesToOphan: () => (/* binding */ sendConsentChoicesToOphan),
/* harmony export */   sendJurisdictionMismatchToOphan: () => (/* binding */ sendJurisdictionMismatchToOphan),
/* harmony export */   sendMessageReadyToOphan: () => (/* binding */ sendMessageReadyToOphan)
/* harmony export */ });
/* harmony import */ var _isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../isConsentOrPay.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/isConsentOrPay.js");
/* harmony import */ var _sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./sourcepointConfig.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js");


var getOphanRecordFunction = () => {
  var _window$guardian;
  var record = (_window$guardian = window.guardian) === null || _window$guardian === void 0 || (_window$guardian = _window$guardian.ophan) === null || _window$guardian === void 0 ? void 0 : _window$guardian.record;
  if (record) {
    return record;
  }
  console.log("window.guardian.ophan.record is not available");
  return () => {};
};
var constructBannerMessageId = messageId => {
  var messageType = (0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_0__.getIsConsentOrPay)() ? "CONSENT_OR_PAY_BANNER" : "ACCEPT_REJECT";
  return "".concat(messageType, "-").concat(messageId);
};
var sendConsentChoicesToOphan = (choiceType, messageId) => {
  var actionValue;
  switch (choiceType) {
    case _sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_1__.SourcePointChoiceTypes.AcceptAll:
      actionValue = "accept";
      break;
    case _sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_1__.SourcePointChoiceTypes.RejectAll:
      actionValue = "reject";
      break;
    case _sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_1__.SourcePointChoiceTypes.Dismiss:
      actionValue = "dismiss";
      break;
    case _sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_1__.SourcePointChoiceTypes.ManageCookies:
      actionValue = "manage-cookies";
      break;
  }
  var componentEvent = {
    component: {
      componentType: "CONSENT",
      id: messageId
    },
    action: "CLICK",
    value: actionValue
  };
  var record = getOphanRecordFunction();
  record({
    componentEvent
  });
};
var sendMessageReadyToOphan = messageId => {
  var componentEvent = {
    component: {
      componentType: "CONSENT",
      id: messageId
    },
    action: "VIEW"
  };
  var record = getOphanRecordFunction();
  record({
    componentEvent
  });
};
var sendJurisdictionMismatchToOphan = value => {
  var componentEvent = {
    component: {
      componentType: "CONSENT"
    },
    value,
    action: "CONSENT_GEOLOCATION_MISMATCH"
  };
  var record = getOphanRecordFunction();
  record({
    componentEvent
  });
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/signals.js":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/signals.js ***!
  \*********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getGpcSignal: () => (/* binding */ getGpcSignal)
/* harmony export */ });
/* harmony import */ var _server_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../server.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/server.js");

var getGpcSignal = () => {
  return _server_js__WEBPACK_IMPORTED_MODULE_0__.isServerSide ? void 0 : navigator.globalPrivacyControl;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js ***!
  \*******************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ACCOUNT_ID: () => (/* binding */ ACCOUNT_ID),
/* harmony export */   ENDPOINT: () => (/* binding */ ENDPOINT),
/* harmony export */   PRIVACY_MANAGER_AUSTRALIA: () => (/* binding */ PRIVACY_MANAGER_AUSTRALIA),
/* harmony export */   PRIVACY_MANAGER_TCFV2: () => (/* binding */ PRIVACY_MANAGER_TCFV2),
/* harmony export */   PRIVACY_MANAGER_TCFV2_CONSENT_OR_PAY: () => (/* binding */ PRIVACY_MANAGER_TCFV2_CONSENT_OR_PAY),
/* harmony export */   PRIVACY_MANAGER_USNAT: () => (/* binding */ PRIVACY_MANAGER_USNAT),
/* harmony export */   PROPERTY_HREF_MAIN: () => (/* binding */ PROPERTY_HREF_MAIN),
/* harmony export */   PROPERTY_HREF_SUBDOMAIN: () => (/* binding */ PROPERTY_HREF_SUBDOMAIN),
/* harmony export */   PROPERTY_ID_AUSTRALIA: () => (/* binding */ PROPERTY_ID_AUSTRALIA),
/* harmony export */   PROPERTY_ID_MAIN: () => (/* binding */ PROPERTY_ID_MAIN),
/* harmony export */   PROPERTY_ID_SUBDOMAIN: () => (/* binding */ PROPERTY_ID_SUBDOMAIN),
/* harmony export */   SourcePointChoiceTypes: () => (/* binding */ SourcePointChoiceTypes),
/* harmony export */   consentOrPayCountries: () => (/* binding */ consentOrPayCountries)
/* harmony export */ });
/* harmony import */ var _domain_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./domain.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/domain.js");

var ACCOUNT_ID = 1257;
var PRIVACY_MANAGER_USNAT = 1068329;
var PROPERTY_ID_MAIN = 7417;
var PROPERTY_ID_SUBDOMAIN = 38161;
var PROPERTY_ID_AUSTRALIA = 13348;
var PROPERTY_HREF_SUBDOMAIN = "https://subdomain.theguardian.com";
var PROPERTY_HREF_MAIN = "https://test.theguardian.com";
var PRIVACY_MANAGER_TCFV2 = 106842;
var PRIVACY_MANAGER_TCFV2_CONSENT_OR_PAY = 1263449;
var PRIVACY_MANAGER_AUSTRALIA = 1178486;
var ENDPOINT = (0,_domain_js__WEBPACK_IMPORTED_MODULE_0__.isGuardianDomain)() ? "https://sourcepoint.theguardian.com" : "https://cdn.privacy-mgmt.com";
var SourcePointChoiceTypes = {
  AcceptAll: 11,
  ManageCookies: 12,
  RejectAll: 13,
  Dismiss: 15
};
var consentOrPayCountries = ["GB"];


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/mergeUserConsent.js":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/mergeUserConsent.js ***!
  \**************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   mergeVendorList: () => (/* binding */ mergeVendorList)
/* harmony export */ });
/* harmony import */ var _cookies_getCookie_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../cookies/getCookie.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _isString_isString_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../isString/isString.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _isUndefined_isUndefined_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../isUndefined/isUndefined.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isUndefined/isUndefined.js");
/* harmony import */ var _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./lib/sourcepointConfig.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }




var purposeIdToNonAdvertisingPurposesMap = /* @__PURE__ */new Map([[1, "677e3387b265dc07332909da"],
// 1
[2, "677e3386b265dc073328f686"],
//2
[3, "677e3386b265dc073328f96f"],
// 3
[4, "677e3386b265dc073328fc01"],
//4
[5, "677e3386b265dc073328fe72"],
// 5
[6, "677e3386b265dc073328ff70"],
//6
[7, "677e3386b265dc0733290050"],
//7
[8, "677e3386b265dc07332903c8"],
//8
[9, "677e3386b265dc0733290502"],
//9
[10, "677e3386b265dc073329071a"],
//10
[11, "677e3386b265dc07332909c2"]
//11
]);
var spBaseUrl = "https://cdn.privacy-mgmt.com/consent/tcfv2/consent/v3";
var mergeVendorList = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var userConsent = yield getUserConsentForAdvertisingVendorList();
    var purposesAndVendors = getConsentedPurposesandVendorsStrings(userConsent);
    if (!(0,_isUndefined_isUndefined_js__WEBPACK_IMPORTED_MODULE_2__.isUndefined)(purposesAndVendors)) {
      yield sendUserCustomConsentToNonAdvertisingVendorList(purposesAndVendors.vendors, purposesAndVendors.purposes, purposesAndVendors.legitimateInterestPurposeIds);
      yield sendUserConsentStringToNonAdvertisingVendorList();
    }
  });
  return function mergeVendorList() {
    return _ref.apply(this, arguments);
  };
}();
var getUserConsentForAdvertisingVendorList = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* () {
    var consentUUID = (0,_cookies_getCookie_js__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
      name: "consentUUID"
    });
    var url = "".concat(spBaseUrl, "/history/").concat(_lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PROPERTY_ID_MAIN, "?consentUUID=").concat(consentUUID);
    var getUserConsentOnAdvertisingListResponse = yield fetch(url, {
      method: "GET",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      }
    });
    return yield getUserConsentOnAdvertisingListResponse.json();
  });
  return function getUserConsentForAdvertisingVendorList() {
    return _ref2.apply(this, arguments);
  };
}();
var getConsentedPurposesandVendorsStrings = data => {
  var _data$, _data$2, _data$3;
  var vendorIds = (_data$ = data[0]) === null || _data$ === void 0 ? void 0 : _data$.vendors.map(vendor => vendor._id);
  var purposeIds = (_data$2 = data[0]) === null || _data$2 === void 0 ? void 0 : _data$2.categories.map(category => {
    var _purposeIdToNonAdvert;
    return (_purposeIdToNonAdvert = purposeIdToNonAdvertisingPurposesMap.get(category.iabPurposeRef.iabId)) !== null && _purposeIdToNonAdvert !== void 0 ? _purposeIdToNonAdvert : "";
  }).filter(_isString_isString_js__WEBPACK_IMPORTED_MODULE_1__.isString);
  var legitimateInterestPurposeIds = (_data$3 = data[0]) === null || _data$3 === void 0 ? void 0 : _data$3.legIntCategories.map(category => {
    var _purposeIdToNonAdvert2;
    return (_purposeIdToNonAdvert2 = purposeIdToNonAdvertisingPurposesMap.get(category.iabPurposeRef.iabId)) !== null && _purposeIdToNonAdvert2 !== void 0 ? _purposeIdToNonAdvert2 : "";
  }).filter(_isString_isString_js__WEBPACK_IMPORTED_MODULE_1__.isString);
  if (vendorIds && purposeIds && legitimateInterestPurposeIds) {
    return {
      vendors: vendorIds,
      purposes: purposeIds,
      legitimateInterestPurposeIds
    };
  } else {
    return void 0;
  }
};
var sendUserCustomConsentToNonAdvertisingVendorList = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator(function* (vendorIds, purposeIds, legitimateInterestPurposeIds) {
    var consentUUID = (0,_cookies_getCookie_js__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
      name: "consentUUID"
    });
    var url = "".concat(spBaseUrl, "/custom/").concat(_lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PROPERTY_ID_SUBDOMAIN, "?hasCsp=true&consentUUID=").concat(consentUUID);
    yield makePOSTRequest(url, {
      vendors: vendorIds,
      categories: purposeIds,
      legIntCategories: legitimateInterestPurposeIds
    });
  });
  return function sendUserCustomConsentToNonAdvertisingVendorList(_x, _x2, _x3) {
    return _ref3.apply(this, arguments);
  };
}();
var sendUserConsentStringToNonAdvertisingVendorList = /*#__PURE__*/function () {
  var _ref4 = _asyncToGenerator(function* () {
    var _userConsent$gdpr;
    var consentUUID = (0,_cookies_getCookie_js__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
      name: "consentUUID"
    });
    var url = "".concat(spBaseUrl, "/").concat(_lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PROPERTY_ID_SUBDOMAIN, "/tcstring?consentUUID=").concat(consentUUID);
    var spUserConsentString = localStorage.getItem("_sp_user_consent_".concat(_lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_3__.PROPERTY_ID_MAIN));
    var userConsent = JSON.parse(spUserConsentString !== null && spUserConsentString !== void 0 ? spUserConsentString : "{}");
    yield makePOSTRequest(url, {
      euconsent: (_userConsent$gdpr = userConsent.gdpr) === null || _userConsent$gdpr === void 0 ? void 0 : _userConsent$gdpr.euconsent
    });
  });
  return function sendUserConsentStringToNonAdvertisingVendorList() {
    return _ref4.apply(this, arguments);
  };
}();
var makePOSTRequest = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator(function* (url, body) {
    yield fetch(url, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });
  });
  return function makePOSTRequest(_x4, _x5) {
    return _ref5.apply(this, arguments);
  };
}();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsent.js":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsent.js ***!
  \*******************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   onConsent: () => (/* binding */ onConsent)
/* harmony export */ });
/* harmony import */ var _onConsentChange_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./onConsentChange.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsentChange.js");

var onConsent = () => new Promise((resolve, reject) => {
  (0,_onConsentChange_js__WEBPACK_IMPORTED_MODULE_0__.onConsentChange)(consentState => {
    var _ref, _consentState$tcfv;
    if ((_ref = (_consentState$tcfv = consentState.tcfv2) !== null && _consentState$tcfv !== void 0 ? _consentState$tcfv : consentState.usnat) !== null && _ref !== void 0 ? _ref : consentState.aus) {
      resolve(consentState);
    }
    reject("Unknown framework");
  });
});


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsentChange.js":
/*!*************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsentChange.js ***!
  \*************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   invokeCallbacks: () => (/* binding */ invokeCallbacks),
/* harmony export */   onConsentChange: () => (/* binding */ onConsentChange)
/* harmony export */ });
/* harmony import */ var _aus_getConsentState_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./aus/getConsentState.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/aus/getConsentState.js");
/* harmony import */ var _getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./getCurrentFramework.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getCurrentFramework.js");
/* harmony import */ var _lib_signals_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./lib/signals.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/signals.js");
/* harmony import */ var _tcfv2_getConsentState_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./tcfv2/getConsentState.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/tcfv2/getConsentState.js");
/* harmony import */ var _usnat_getConsentState_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./usnat/getConsentState.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/usnat/getConsentState.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }





var callBackQueue = [];
var finalCallbackQueue = [];
var awaitingUserInteractionInTCFv2 = state => {
  var _state$tcfv;
  return ((_state$tcfv = state.tcfv2) === null || _state$tcfv === void 0 ? void 0 : _state$tcfv.eventStatus) === "cmpuishown";
};
var awaitingUserInteractionInUSNAT = state => {
  var _state$usnat;
  return ((_state$usnat = state.usnat) === null || _state$usnat === void 0 ? void 0 : _state$usnat.signalStatus) === "not ready";
};
var invokeCallback = (callback, state) => {
  if (awaitingUserInteractionInTCFv2(state) || awaitingUserInteractionInUSNAT(state)) {
    return;
  }
  var stateString = JSON.stringify(state);
  if (stateString !== callback.lastState) {
    callback.fn(state);
    callback.lastState = stateString;
  }
};
var enhanceConsentState = consentState => {
  var gpcSignal = (0,_lib_signals_js__WEBPACK_IMPORTED_MODULE_2__.getGpcSignal)();
  if (consentState.tcfv2) {
    var consents = consentState.tcfv2.consents;
    return _objectSpread(_objectSpread({}, consentState), {}, {
      canTarget: Object.keys(consents).length > 0 && Object.values(consents).every(Boolean),
      framework: "tcfv2",
      gpcSignal
    });
  } else if (consentState.usnat) {
    return _objectSpread(_objectSpread({}, consentState), {}, {
      canTarget: !consentState.usnat.doNotSell,
      framework: "usnat",
      gpcSignal
    });
  } else if (consentState.aus) {
    return _objectSpread(_objectSpread({}, consentState), {}, {
      canTarget: consentState.aus.personalisedAdvertising,
      framework: "aus",
      gpcSignal
    });
  }
  return _objectSpread(_objectSpread({}, consentState), {}, {
    canTarget: false,
    framework: null,
    gpcSignal
  });
};
var getConsentState = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    switch ((0,_getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_1__.getCurrentFramework)()) {
      case "aus":
        return enhanceConsentState({
          aus: yield (0,_aus_getConsentState_js__WEBPACK_IMPORTED_MODULE_0__.getConsentState)()
        });
      case "usnat":
        {
          return enhanceConsentState({
            usnat: yield (0,_usnat_getConsentState_js__WEBPACK_IMPORTED_MODULE_4__.getConsentState)()
          });
        }
      case "tcfv2":
        return enhanceConsentState({
          tcfv2: yield (0,_tcfv2_getConsentState_js__WEBPACK_IMPORTED_MODULE_3__.getConsentState)()
        });
      default:
        throw new Error("no IAB consent framework found on the page");
    }
  });
  return function getConsentState() {
    return _ref.apply(this, arguments);
  };
}();
var invokeCallbacks = () => {
  var callbacksToInvoke = callBackQueue.concat(finalCallbackQueue);
  if (callbacksToInvoke.length === 0) {
    return;
  }
  void getConsentState().then(state => {
    if (awaitingUserInteractionInTCFv2(state) || awaitingUserInteractionInUSNAT(state)) {
      return;
    }
    callbacksToInvoke.forEach(callback => invokeCallback(callback, state));
  });
};
var onConsentChange = function (callBack) {
  var final = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
  var newCallback = {
    fn: callBack
  };
  if (final) {
    finalCallbackQueue.push(newCallback);
  } else {
    callBackQueue.push(newCallback);
  }
  void getConsentState().then(consentState => {
    invokeCallback(newCallback, consentState);
  }).catch(() => {});
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/server.js":
/*!****************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/server.js ***!
  \****************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cmp: () => (/* binding */ cmp),
/* harmony export */   getConsentFor: () => (/* binding */ getConsentFor),
/* harmony export */   isServerSide: () => (/* binding */ isServerSide),
/* harmony export */   onConsent: () => (/* binding */ onConsent),
/* harmony export */   onConsentChange: () => (/* binding */ onConsentChange),
/* harmony export */   serverSideWarn: () => (/* binding */ serverSideWarn),
/* harmony export */   serverSideWarnAndReturn: () => (/* binding */ serverSideWarnAndReturn)
/* harmony export */ });
var isServerSide = typeof window === "undefined";
var serverSideWarn = () => {
  console.warn("This is a server-side version of the @guardian/consent-management-platform", "No consent signals will be received.");
};
var serverSideWarnAndReturn = arg => {
  return () => {
    serverSideWarn();
    return arg;
  };
};
var cmp = {
  __disable: serverSideWarn,
  __enable: serverSideWarnAndReturn(false),
  __isDisabled: serverSideWarnAndReturn(false),
  hasInitialised: serverSideWarnAndReturn(false),
  init: serverSideWarn,
  showPrivacyManager: serverSideWarn,
  version: "n/a",
  willShowPrivacyMessage: serverSideWarnAndReturn(Promise.resolve(false)),
  willShowPrivacyMessageSync: serverSideWarnAndReturn(false)
};
var onConsent = () => {
  serverSideWarn();
  return Promise.resolve({
    canTarget: false,
    framework: null
  });
};
var onConsentChange = () => {
  return serverSideWarn();
};
var getConsentFor = (vendor, consent) => {
  console.log("Server-side call for getConsentFor(".concat(vendor, ", ").concat(JSON.stringify(consent), ")"), "getConsentFor will always return false server-side");
  serverSideWarn();
  return false;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/sourcepoint.js":
/*!*********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/sourcepoint.js ***!
  \*********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init),
/* harmony export */   willShowPrivacyMessage: () => (/* binding */ willShowPrivacyMessage)
/* harmony export */ });
/* harmony import */ var _logger_logger_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../logger/logger.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _exclusionList_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./exclusionList.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/exclusionList.js");
/* harmony import */ var _getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./getCurrentFramework.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getCurrentFramework.js");
/* harmony import */ var _isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./isConsentOrPay.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/isConsentOrPay.js");
/* harmony import */ var _lib_mark_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./lib/mark.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/mark.js");
/* harmony import */ var _lib_ophan_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./lib/ophan.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/ophan.js");
/* harmony import */ var _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./lib/sourcepointConfig.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/lib/sourcepointConfig.js");
/* harmony import */ var _mergeUserConsent_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./mergeUserConsent.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/mergeUserConsent.js");
/* harmony import */ var _onConsentChange_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./onConsentChange.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsentChange.js");
/* harmony import */ var _stub_js__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./stub.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }










var resolveWillShowPrivacyMessage;
var willShowPrivacyMessage = new Promise(resolve => {
  resolveWillShowPrivacyMessage = resolve;
});
var getPropertyHref = (framework, useNonAdvertisedList) => {
  if (framework == "aus") {
    return "https://au.theguardian.com";
  }
  if (framework == "usnat") {
    return "https://www.theguardian.com";
  }
  return useNonAdvertisedList ? _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_HREF_SUBDOMAIN : _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_HREF_MAIN;
};
var getPropertyId = (framework, useNonAdvertisedList) => {
  if (framework == "aus") {
    return _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_ID_AUSTRALIA;
  }
  if (framework == "usnat") {
    return _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_ID_MAIN;
  }
  return useNonAdvertisedList ? _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_ID_SUBDOMAIN : _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_ID_MAIN;
};
var hasConsentedToNonAdvertisedList = () => {
  var _userConsent$gdpr$con, _userConsent$gdpr;
  var spUserConsentString = localStorage.getItem("_sp_user_consent_".concat(_lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.PROPERTY_ID_SUBDOMAIN));
  var userConsent = JSON.parse(spUserConsentString !== null && spUserConsentString !== void 0 ? spUserConsentString : "{}");
  return (_userConsent$gdpr$con = (_userConsent$gdpr = userConsent.gdpr) === null || _userConsent$gdpr === void 0 || (_userConsent$gdpr = _userConsent$gdpr.consentStatus) === null || _userConsent$gdpr === void 0 ? void 0 : _userConsent$gdpr.hasConsentData) !== null && _userConsent$gdpr$con !== void 0 ? _userConsent$gdpr$con : false;
};
var shouldMergeVendorList = (countryCode, useNonAdvertisedList) => {
  return (0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_3__.isConsentOrPayCountry)(countryCode) && useNonAdvertisedList && !hasConsentedToNonAdvertisedList();
};
var init = function (framework, countryCode, isUserSignedIn, useNonAdvertisedList) {
  var _window$guardian, _window$guardian2;
  var pubData = arguments.length > 4 && arguments[4] !== undefined ? arguments[4] : {};
  (0,_stub_js__WEBPACK_IMPORTED_MODULE_9__.loadStubsFor)(framework);
  if (window._sp_) {
    throw new Error("Sourcepoint global (window._sp_) is already defined!");
  }
  (0,_getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_2__.setCurrentFramework)(framework);
  if (!(0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_3__.isConsentOrPayCountry)(countryCode)) {
    useNonAdvertisedList = false;
  }
  (0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_3__.setIsConsentOrPay)((0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_3__.isConsentOrPayCountry)(countryCode) && !useNonAdvertisedList);
  (0,_onConsentChange_js__WEBPACK_IMPORTED_MODULE_8__.invokeCallbacks)();
  var frameworkMessageType;
  switch (framework) {
    case "usnat":
      frameworkMessageType = "usnat";
      break;
    case "aus":
      frameworkMessageType = "ccpa";
      break;
    case "tcfv2":
    default:
      frameworkMessageType = "gdpr";
      break;
  }
  var messageId;
  var isInPropertyIdABTest = ((_window$guardian = window.guardian) === null || _window$guardian === void 0 || (_window$guardian = _window$guardian.config) === null || _window$guardian === void 0 || (_window$guardian = _window$guardian.tests) === null || _window$guardian === void 0 ? void 0 : _window$guardian.useSourcepointPropertyIdVariant) === "variant";
  (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "framework: ".concat(framework));
  (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "frameworkMessageType: ".concat(frameworkMessageType));
  var pageSection = (_window$guardian2 = window.guardian) === null || _window$guardian2 === void 0 || (_window$guardian2 = _window$guardian2.config) === null || _window$guardian2 === void 0 || (_window$guardian2 = _window$guardian2.page) === null || _window$guardian2 === void 0 ? void 0 : _window$guardian2.section;
  window._sp_queue = [];
  window._sp_ = {
    config: {
      baseEndpoint: _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.ENDPOINT,
      accountId: _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.ACCOUNT_ID,
      propertyId: getPropertyId(framework, useNonAdvertisedList),
      propertyHref: getPropertyHref(framework, useNonAdvertisedList),
      joinHref: true,
      isSPA: true,
      targetingParams: {
        framework,
        excludePage: (0,_exclusionList_js__WEBPACK_IMPORTED_MODULE_1__.isExcludedFromCMP)(pageSection)
      },
      pubData: _objectSpread(_objectSpread({}, pubData), {}, {
        cmpInitTimeUtc: (/* @__PURE__ */new Date()).getTime()
      }),
      // ccpa or gdpr object added below
      events: {
        onConsentReady: (message_type, consentUUID, euconsent) => {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onConsentReady ".concat(message_type));
          if (message_type != frameworkMessageType) {
            (0,_lib_ophan_js__WEBPACK_IMPORTED_MODULE_5__.sendJurisdictionMismatchToOphan)(JSON.stringify({
              sp: message_type,
              gu: frameworkMessageType,
              gu_country: countryCode
            }));
            (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageReceiveData Data mismatch ;sp:".concat(message_type, ";fastly:").concat(frameworkMessageType, ";"));
            return;
          }
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "consentUUID ".concat(consentUUID));
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "euconsent ".concat(euconsent));
          (0,_lib_mark_js__WEBPACK_IMPORTED_MODULE_4__.mark)("cmp-got-consent");
          setTimeout(_onConsentChange_js__WEBPACK_IMPORTED_MODULE_8__.invokeCallbacks, 0);
        },
        onMessageReady: message_type => {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageReady ".concat(message_type));
          if (message_type != frameworkMessageType) {
            return;
          }
          (0,_lib_mark_js__WEBPACK_IMPORTED_MODULE_4__.mark)("cmp-ui-displayed");
        },
        onMessageReceiveData: (message_type, data) => {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageReceiveData ".concat(message_type));
          if (data.messageId !== 0) {
            messageId = data.messageId;
            (0,_lib_ophan_js__WEBPACK_IMPORTED_MODULE_5__.sendMessageReadyToOphan)((0,_lib_ophan_js__WEBPACK_IMPORTED_MODULE_5__.constructBannerMessageId)(messageId.toString()));
          }
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageReceiveData ", data);
          if (message_type != frameworkMessageType) {
            return;
          }
          void resolveWillShowPrivacyMessage(data.messageId !== 0);
        },
        onMessageChoiceSelect: (message_type, choice_id, choiceTypeID) => {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageChoiceSelect message_type: ".concat(message_type));
          if (message_type != frameworkMessageType) {
            return;
          }
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageChoiceSelect choice_id: ".concat(choice_id));
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageChoiceSelect choice_type_id: ".concat(choiceTypeID));
          (0,_lib_ophan_js__WEBPACK_IMPORTED_MODULE_5__.sendConsentChoicesToOphan)(choiceTypeID, (0,_lib_ophan_js__WEBPACK_IMPORTED_MODULE_5__.constructBannerMessageId)(messageId.toString()));
          if (choiceTypeID === _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.SourcePointChoiceTypes.AcceptAll || choiceTypeID === _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.SourcePointChoiceTypes.RejectAll || choiceTypeID === _lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.SourcePointChoiceTypes.Dismiss) {
            setTimeout(_onConsentChange_js__WEBPACK_IMPORTED_MODULE_8__.invokeCallbacks, 0);
          }
        },
        onPrivacyManagerAction: function (message_type, pmData) {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onPrivacyManagerAction message_type: ".concat(message_type));
          if (message_type != frameworkMessageType) {
            return;
          }
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onPrivacyManagerAction ".concat(pmData));
        },
        onMessageChoiceError: function (message_type, err) {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageChoiceError ".concat(message_type));
          if (message_type != frameworkMessageType) {
            return;
          }
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onMessageChoiceError ".concat(err));
        },
        onPMCancel: function (message_type) {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onPMCancel ".concat(message_type));
          if (message_type != frameworkMessageType) {
            return;
          }
        },
        onSPPMObjectReady: function () {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "onSPPMObjectReady");
        },
        onError: function (message_type, errorCode, errorObject, userReset) {
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "errorCode: ".concat(message_type));
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "errorCode: ".concat(errorCode));
          if (message_type != frameworkMessageType) {
            return;
          }
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", errorObject);
          (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "userReset: ".concat(userReset));
        }
      }
    }
  };
  if (isInPropertyIdABTest) {
    window._sp_.config.propertyId = getPropertyId(framework, useNonAdvertisedList);
  }
  switch (framework) {
    case "tcfv2":
      window._sp_.config.gdpr = {
        targetingParams: {
          framework,
          excludePage: (0,_exclusionList_js__WEBPACK_IMPORTED_MODULE_1__.isExcludedFromCMP)(pageSection),
          isCorP: (0,_isConsentOrPay_js__WEBPACK_IMPORTED_MODULE_3__.isConsentOrPayCountry)(countryCode),
          isUserSignedIn
        }
      };
      break;
    case "usnat":
      window._sp_.config.usnat = {
        targetingParams: {
          framework
        }
      };
      break;
    case "aus":
      window._sp_.config.ccpa = {
        targetingParams: {
          framework
        }
      };
      break;
  }
  var spLib = document.createElement("script");
  spLib.id = "sourcepoint-lib";
  spLib.addEventListener("load", () => {
    if (shouldMergeVendorList(countryCode, useNonAdvertisedList)) {
      (0,_mergeUserConsent_js__WEBPACK_IMPORTED_MODULE_7__.mergeVendorList)().then(() => {
        var _window$_sp_, _window$_sp_$executeM;
        (_window$_sp_ = window._sp_) === null || _window$_sp_ === void 0 || (_window$_sp_$executeM = _window$_sp_.executeMessaging) === null || _window$_sp_$executeM === void 0 || _window$_sp_$executeM.call(_window$_sp_);
      }).catch(error => {
        (0,_logger_logger_js__WEBPACK_IMPORTED_MODULE_0__.log)("cmp", "'Failed to merge vendor list': ".concat(error));
      });
    } else {
      var _window$_sp_2, _window$_sp_2$execute;
      (_window$_sp_2 = window._sp_) === null || _window$_sp_2 === void 0 || (_window$_sp_2$execute = _window$_sp_2.executeMessaging) === null || _window$_sp_2$execute === void 0 || _window$_sp_2$execute.call(_window$_sp_2);
    }
  });
  spLib.src = "".concat(_lib_sourcepointConfig_js__WEBPACK_IMPORTED_MODULE_6__.ENDPOINT, "/unified/wrapperMessagingWithoutDetection.js");
  document.body.appendChild(spLib);
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub.js":
/*!**************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub.js ***!
  \**************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   loadStubsFor: () => (/* binding */ loadStubsFor)
/* harmony export */ });
/* harmony import */ var _stub_gpp_usnat_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./stub_gpp_usnat.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_gpp_usnat.js");
/* harmony import */ var _stub_tcfv2_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./stub_tcfv2.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_tcfv2.js");
/* harmony import */ var _stub_uspapi_ccpa_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./stub_uspapi_ccpa.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_uspapi_ccpa.js");



var loadStubsFor = framework => {
  switch (framework) {
    case "tcfv2":
      (0,_stub_tcfv2_js__WEBPACK_IMPORTED_MODULE_1__.stub_tcfv2)();
      break;
    case "usnat":
      (0,_stub_gpp_usnat_js__WEBPACK_IMPORTED_MODULE_0__.stub_gpp_usnat)();
      break;
    case "aus":
      (0,_stub_uspapi_ccpa_js__WEBPACK_IMPORTED_MODULE_2__.stub_uspapi_ccpa)();
      break;
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_gpp_usnat.js":
/*!************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_gpp_usnat.js ***!
  \************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   stub_gpp_usnat: () => (/* binding */ stub_gpp_usnat)
/* harmony export */ });
var stub_gpp_usnat = () => {
  window.__gpp_addFrame = function (e) {
    if (!window.frames[e]) if (document.body) {
      var t = document.createElement("iframe");
      t.style.cssText = "display:none", t.name = e, document.body.appendChild(t);
    } else window.setTimeout(window.__gpp_addFrame, 10, e);
  }, window.__gpp_stub = function () {
    var e = arguments;
    if (__gpp.queue = __gpp.queue || [], __gpp.events = __gpp.events || [], !e.length || 1 == e.length && "queue" == e[0]) return __gpp.queue;
    if (1 == e.length && "events" == e[0]) return __gpp.events;
    var t = e[0],
      p = e.length > 1 ? e[1] : null,
      s = e.length > 2 ? e[2] : null;
    if ("ping" === t) p({
      gppVersion: "1.1",
      cmpStatus: "stub",
      cmpDisplayStatus: "hidden",
      signalStatus: "not ready",
      supportedAPIs: ["2:tcfeuv2", "5:tcfcav1", "6:uspv1", "7:usnatv1", "8:uscav1", "9:usvav1", "10:uscov1", "11:usutv1", "12:usctv1"],
      cmpId: 0,
      sectionList: [],
      applicableSections: [],
      gppString: "",
      parsedSections: {}
    }, true);else if ("addEventListener" === t) {
      "lastId" in __gpp || (__gpp.lastId = 0), __gpp.lastId++;
      var n = __gpp.lastId;
      __gpp.events.push({
        id: n,
        callback: p,
        parameter: s
      }), p({
        eventName: "listenerRegistered",
        listenerId: n,
        data: true,
        pingData: {
          gppVersion: "1.1",
          cmpStatus: "stub",
          cmpDisplayStatus: "hidden",
          signalStatus: "not ready",
          supportedAPIs: ["2:tcfeuv2", "5:tcfcav1", "6:uspv1", "7:usnatv1", "8:uscav1", "9:usvav1", "10:uscov1", "11:usutv1", "12:usctv1"],
          cmpId: 0,
          sectionList: [],
          applicableSections: [],
          gppString: "",
          parsedSections: {}
        }
      }, true);
    } else if ("removeEventListener" === t) {
      for (var a = false, i = 0; i < __gpp.events.length; i++) if (__gpp.events[i].id == s) {
        __gpp.events.splice(i, 1), a = true;
        break;
      }
      p({
        eventName: "listenerRemoved",
        listenerId: s,
        data: a,
        pingData: {
          gppVersion: "1.1",
          cmpStatus: "stub",
          cmpDisplayStatus: "hidden",
          signalStatus: "not ready",
          supportedAPIs: ["2:tcfeuv2", "5:tcfcav1", "6:uspv1", "7:usnatv1", "8:uscav1", "9:usvav1", "10:uscov1", "11:usutv1", "12:usctv1"],
          cmpId: 0,
          sectionList: [],
          applicableSections: [],
          gppString: "",
          parsedSections: {}
        }
      }, true);
    } else "hasSection" === t ? p(false, true) : "getSection" === t || "getField" === t ? p(null, true) : __gpp.queue.push([].slice.apply(e));
  }, window.__gpp_msghandler = function (e) {
    var t = "string" == typeof e.data;
    try {
      var p = t ? JSON.parse(e.data) : e.data;
    } catch (e2) {
      p = null;
    }
    if ("object" == typeof p && null !== p && "__gppCall" in p) {
      var s = p.__gppCall;
      window.__gpp(s.command, function (p2, n) {
        var a = {
          __gppReturn: {
            returnValue: p2,
            success: n,
            callId: s.callId
          }
        };
        e.source.postMessage(t ? JSON.stringify(a) : a, "*");
      }, "parameter" in s ? s.parameter : null, "version" in s ? s.version : "1.1");
    }
  }, "__gpp" in window && "function" == typeof window.__gpp || (window.__gpp = window.__gpp_stub, window.addEventListener("message", window.__gpp_msghandler, false), window.__gpp_addFrame("__gppLocator"));
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_tcfv2.js":
/*!********************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_tcfv2.js ***!
  \********************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   stub_tcfv2: () => (/* binding */ stub_tcfv2)
/* harmony export */ });
var stub_tcfv2 = () => {
  !function (t) {
    var e = {};
    function n(r) {
      if (e[r]) return e[r].exports;
      var o = e[r] = {
        i: r,
        l: false,
        exports: {}
      };
      return t[r].call(o.exports, o, o.exports, n), o.l = true, o.exports;
    }
    n.m = t, n.c = e, n.d = function (t2, e2, r) {
      n.o(t2, e2) || Object.defineProperty(t2, e2, {
        enumerable: true,
        get: r
      });
    }, n.r = function (t2) {
      "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t2, Symbol.toStringTag, {
        value: "Module"
      }), Object.defineProperty(t2, "__esModule", {
        value: true
      });
    }, n.t = function (t2, e2) {
      if (1 & e2 && (t2 = n(t2)), 8 & e2) return t2;
      if (4 & e2 && "object" == typeof t2 && t2 && t2.__esModule) return t2;
      var r = /* @__PURE__ */Object.create(null);
      if (n.r(r), Object.defineProperty(r, "default", {
        enumerable: true,
        value: t2
      }), 2 & e2 && "string" != typeof t2) for (var o in t2) n.d(r, o, function (e3) {
        return t2[e3];
      }.bind(null, o));
      return r;
    }, n.n = function (t2) {
      var e2 = t2 && t2.__esModule ? function () {
        return t2.default;
      } : function () {
        return t2;
      };
      return n.d(e2, "a", e2), e2;
    }, n.o = function (t2, e2) {
      return Object.prototype.hasOwnProperty.call(t2, e2);
    }, n.p = "", n(n.s = 3);
  }([function (t, e, n) {
    var r = n(2);
    t.exports = !r(function () {
      return 7 != Object.defineProperty({}, "a", {
        get: function () {
          return 7;
        }
      }).a;
    });
  }, function (t, e) {
    t.exports = function (t2) {
      return "object" == typeof t2 ? null !== t2 : "function" == typeof t2;
    };
  }, function (t, e) {
    t.exports = function (t2) {
      try {
        return !!t2();
      } catch (t3) {
        return true;
      }
    };
  }, function (t, e, n) {
    n(4), function () {
      if ("function" != typeof window.__tcfapi) {
        var t2,
          e2 = [],
          n2 = window,
          r = n2.document;
        !n2.__tcfapi && function t3() {
          var e3 = !!n2.frames.__tcfapiLocator;
          if (!e3) if (r.body) {
            var o = r.createElement("iframe");
            o.style.cssText = "display:none", o.name = "__tcfapiLocator", r.body.appendChild(o);
          } else setTimeout(t3, 5);
          return !e3;
        }() && (n2.__tcfapi = function () {
          for (var n3 = arguments.length, r2 = new Array(n3), o = 0; o < n3; o++) r2[o] = arguments[o];
          if (!r2.length) return e2;
          if ("setGdprApplies" === r2[0]) r2.length > 3 && 2 === parseInt(r2[1], 10) && "boolean" == typeof r2[3] && (t2 = r2[3], "function" == typeof r2[2] && r2[2]("set", true));else if ("ping" === r2[0]) {
            var i = {
              gdprApplies: t2,
              cmpLoaded: false,
              apiVersion: "2.0"
            };
            "function" == typeof r2[2] && r2[2](i, true);
          } else e2.push(r2);
        }, n2.addEventListener("message", function (t3) {
          var e3 = "string" == typeof t3.data,
            r2 = {};
          try {
            r2 = e3 ? JSON.parse(t3.data) : t3.data;
          } catch (t4) {}
          var o = r2.__tcfapiCall;
          o && n2.__tcfapi(o.command, o.version, function (n3, r3) {
            var i = {
              __tcfapiReturn: {
                returnValue: n3,
                success: r3,
                callId: o.callId
              }
            };
            e3 && (i = JSON.stringify(i)), t3.source.postMessage(i, "*");
          }, o.parameter);
        }, false));
      }
    }();
  }, function (t, e, n) {
    var r = n(0),
      o = n(5).f,
      i = Function.prototype,
      c = i.toString,
      u = /^s*function ([^ (]*)/;
    r && !("name" in i) && o(i, "name", {
      configurable: true,
      get: function () {
        try {
          return c.call(this).match(u)[1];
        } catch (t2) {
          return "";
        }
      }
    });
  }, function (t, e, n) {
    var r = n(0),
      o = n(6),
      i = n(10),
      c = n(11),
      u = Object.defineProperty;
    e.f = r ? u : function (t2, e2, n2) {
      if (i(t2), e2 = c(e2, true), i(n2), o) try {
        return u(t2, e2, n2);
      } catch (t3) {}
      if ("get" in n2 || "set" in n2) throw TypeError("Accessors not supported");
      return "value" in n2 && (t2[e2] = n2.value), t2;
    };
  }, function (t, e, n) {
    var r = n(0),
      o = n(2),
      i = n(7);
    t.exports = !r && !o(function () {
      return 7 != Object.defineProperty(i("div"), "a", {
        get: function () {
          return 7;
        }
      }).a;
    });
  }, function (t, e, n) {
    var r = n(8),
      o = n(1),
      i = r.document,
      c = o(i) && o(i.createElement);
    t.exports = function (t2) {
      return c ? i.createElement(t2) : {};
    };
  }, function (t, e, n) {
    (function (e2) {
      var n2 = function (t2) {
        return t2 && t2.Math == Math && t2;
      };
      t.exports = n2("object" == typeof globalThis && globalThis) || n2("object" == typeof window && window) || n2("object" == typeof self && self) || n2("object" == typeof e2 && e2) || Function("return this")();
    }).call(this, n(9));
  }, function (t, e) {
    var n;
    n = /* @__PURE__ */function () {
      return this;
    }();
    try {
      n = n || new Function("return this")();
    } catch (t2) {
      "object" == typeof window && (n = window);
    }
    t.exports = n;
  }, function (t, e, n) {
    var r = n(1);
    t.exports = function (t2) {
      if (!r(t2)) throw TypeError(String(t2) + " is not an object");
      return t2;
    };
  }, function (t, e, n) {
    var r = n(1);
    t.exports = function (t2, e2) {
      if (!r(t2)) return t2;
      var n2, o;
      if (e2 && "function" == typeof (n2 = t2.toString) && !r(o = n2.call(t2))) return o;
      if ("function" == typeof (n2 = t2.valueOf) && !r(o = n2.call(t2))) return o;
      if (!e2 && "function" == typeof (n2 = t2.toString) && !r(o = n2.call(t2))) return o;
      throw TypeError("Can't convert object to primitive value");
    };
  }]);
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_uspapi_ccpa.js":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/stub_uspapi_ccpa.js ***!
  \**************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   stub_uspapi_ccpa: () => (/* binding */ stub_uspapi_ccpa)
/* harmony export */ });
var stub_uspapi_ccpa = () => {
  (function () {
    var e = false;
    var c = window;
    var t = document;
    function r() {
      if (!c.frames["__uspapiLocator"]) {
        if (t.body) {
          var a = t.body;
          var e2 = t.createElement("iframe");
          e2.style.cssText = "display:none";
          e2.name = "__uspapiLocator";
          a.appendChild(e2);
        } else {
          setTimeout(r, 5);
        }
      }
    }
    r();
    function p() {
      var a = arguments;
      __uspapi.a = __uspapi.a || [];
      if (!a.length) {
        return __uspapi.a;
      } else if (a[0] === "ping") {
        a[2]({
          gdprAppliesGlobally: e,
          cmpLoaded: false
        }, true);
      } else {
        __uspapi.a.push([].slice.apply(a));
      }
    }
    function l(t2) {
      var r2 = typeof t2.data === "string";
      try {
        var a = r2 ? JSON.parse(t2.data) : t2.data;
        if (a.__cmpCall) {
          var n = a.__cmpCall;
          c.__uspapi(n.command, n.parameter, function (a2, e2) {
            var c2 = {
              __cmpReturn: {
                returnValue: a2,
                success: e2,
                callId: n.callId
              }
            };
            t2.source.postMessage(r2 ? JSON.stringify(c2) : c2, "*");
          });
        }
      } catch (a2) {}
    }
    if (typeof __uspapi !== "function") {
      c.__uspapi = p;
      __uspapi.msgHandler = l;
      c.addEventListener("message", l, false);
    }
  })();
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/tcfv2/api.js":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/tcfv2/api.js ***!
  \*******************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCustomVendorConsents: () => (/* binding */ getCustomVendorConsents),
/* harmony export */   getTCData: () => (/* binding */ getTCData)
/* harmony export */ });
var api = (command, vendorIds, purposeIds, legitimateInterestPurposeIds) => new Promise((resolve, reject) => {
  if (window.__tcfapi) {
    window.__tcfapi(command, 2, (result, success) => success ? resolve(result) : (/* istanbul ignore next */
    reject(new Error("Unable to get ".concat(command, " data")))), vendorIds, purposeIds, legitimateInterestPurposeIds);
  } else {
    reject(new Error("No __tcfapi found on window"));
  }
});
var getTCData = () => api("addEventListener");
var getCustomVendorConsents = () => api("getCustomVendorConsents");


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/tcfv2/getConsentState.js":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/tcfv2/getConsentState.js ***!
  \*******************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getConsentState: () => (/* binding */ getConsentState)
/* harmony export */ });
/* harmony import */ var _getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../getCurrentFramework.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getCurrentFramework.js");
/* harmony import */ var _api_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./api.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/tcfv2/api.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var defaultConsents = {
  "1": false,
  "2": false,
  "3": false,
  "4": false,
  "5": false,
  "6": false,
  "7": false,
  "8": false,
  "9": false,
  "10": false,
  "11": false
};
var getConsentState = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var [tcData, customVendors] = yield Promise.all([(0,_api_js__WEBPACK_IMPORTED_MODULE_1__.getTCData)(), (0,_api_js__WEBPACK_IMPORTED_MODULE_1__.getCustomVendorConsents)()]);
    if (typeof tcData === "undefined") {
      var _getCurrentFramework;
      var currentFramework = (_getCurrentFramework = (0,_getCurrentFramework_js__WEBPACK_IMPORTED_MODULE_0__.getCurrentFramework)()) !== null && _getCurrentFramework !== void 0 ? _getCurrentFramework : "undefined";
      throw new Error("No TC Data found with current framework: ".concat(currentFramework));
    }
    var consents = _objectSpread(_objectSpread({}, defaultConsents), tcData.purpose.consents);
    var {
      eventStatus,
      gdprApplies,
      tcString,
      addtlConsent
    } = tcData;
    var {
      grants
    } = customVendors;
    var vendorConsents = Object.keys(grants).sort().reduce((acc, cur) => {
      var _grants$cur;
      return _objectSpread(_objectSpread({}, acc), {}, {
        [cur]: (_grants$cur = grants[cur]) === null || _grants$cur === void 0 ? void 0 : _grants$cur.vendorGrant
      });
    }, {});
    return {
      consents,
      eventStatus,
      vendorConsents,
      addtlConsent,
      gdprApplies,
      tcString
    };
  });
  return function getConsentState() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/usnat/api.js":
/*!*******************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/usnat/api.js ***!
  \*******************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   api: () => (/* binding */ api),
/* harmony export */   getUsnatData: () => (/* binding */ getUsnatData)
/* harmony export */ });
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var api = () => new Promise(resolve => {
  var _window$_sp_;
  if ((_window$_sp_ = window._sp_) !== null && _window$_sp_ !== void 0 && (_window$_sp_ = _window$_sp_.usnat) !== null && _window$_sp_ !== void 0 && _window$_sp_.getUserConsents) {
    window._sp_.usnat.getUserConsents(usNatData => {
      return resolve(_objectSpread(_objectSpread({}, usNatData), {}, {
        signalStatus: "ready"
      }));
    });
  } else {
    resolve({
      applies: false,
      categories: [],
      vendors: [],
      signalStatus: "not ready"
    });
  }
});
var getUsnatData = () => api();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/usnat/getConsentState.js":
/*!*******************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/usnat/getConsentState.js ***!
  \*******************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getConsentState: () => (/* binding */ getConsentState)
/* harmony export */ });
/* harmony import */ var _api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./api.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/usnat/api.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }

var getConsentState = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var _usnatData$categories;
    var doNotSell = false;
    var usnatData = yield (0,_api_js__WEBPACK_IMPORTED_MODULE_0__.getUsnatData)();
    doNotSell = ((_usnatData$categories = usnatData.categories) === null || _usnatData$categories === void 0 || (_usnatData$categories = _usnatData$categories.find(category => category.systemId === 3)) === null || _usnatData$categories === void 0 ? void 0 : _usnatData$categories.consented) === false;
    return {
      doNotSell,
      signalStatus: usnatData.signalStatus
    };
  });
  return function getConsentState() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendorDataManager.js":
/*!***************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendorDataManager.js ***!
  \***************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initVendorDataManager: () => (/* binding */ initVendorDataManager)
/* harmony export */ });
/* harmony import */ var _cookies_removeCookie_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../cookies/removeCookie.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/removeCookie.js");
/* harmony import */ var _storage_storage_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../storage/storage.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
/* harmony import */ var _getConsentFor_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./getConsentFor.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/getConsentFor.js");
/* harmony import */ var _onConsentChange_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./onConsentChange.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/onConsentChange.js");
/* harmony import */ var _vendorStorageIds_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./vendorStorageIds.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendorStorageIds.js");





var removeData = _ref => {
  var {
    cookies = [],
    localStorage = [],
    sessionStorage = []
  } = _ref;
  for (var name of cookies) {
    (0,_cookies_removeCookie_js__WEBPACK_IMPORTED_MODULE_0__.removeCookie)({
      name
    });
  }
  for (var _name of localStorage) {
    _storage_storage_js__WEBPACK_IMPORTED_MODULE_1__.storage.local.remove(_name);
  }
  for (var _name2 of sessionStorage) {
    _storage_storage_js__WEBPACK_IMPORTED_MODULE_1__.storage.session.remove(_name2);
  }
};
var removeUnconsentedData = consent => {
  Object.keys(_vendorStorageIds_js__WEBPACK_IMPORTED_MODULE_4__.vendorStorageIds).forEach(vendor => {
    var consentForVendor = (0,_getConsentFor_js__WEBPACK_IMPORTED_MODULE_2__.getConsentFor)(vendor, consent);
    var vendorData = _vendorStorageIds_js__WEBPACK_IMPORTED_MODULE_4__.vendorStorageIds[vendor];
    if (!consentForVendor) {
      removeData(vendorData);
    }
  });
  Object.entries(_vendorStorageIds_js__WEBPACK_IMPORTED_MODULE_4__.deprecatedVendorStorageIds).forEach(_ref2 => {
    var [, vendorData] = _ref2;
    return removeData(vendorData);
  });
};
var initVendorDataManager = () => {
  (0,_onConsentChange_js__WEBPACK_IMPORTED_MODULE_3__.onConsentChange)(consent => {
    if ("requestIdleCallback" in window) {
      requestIdleCallback(() => {
        removeUnconsentedData(consent);
      }, {
        timeout: 2e3
      });
    } else {
      removeUnconsentedData(consent);
    }
  });
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendorStorageIds.js":
/*!**************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendorStorageIds.js ***!
  \**************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deprecatedVendorStorageIds: () => (/* binding */ deprecatedVendorStorageIds),
/* harmony export */   vendorStorageIds: () => (/* binding */ vendorStorageIds)
/* harmony export */ });
var vendorStorageIds = {
  a9: {
    localStorage: ["apstagUserAgentClientHints", "apstagCxMEnabled"]
  },
  inizio: {
    localStorage: ["__bm_s", "__bm_m"]
  },
  criteo: {
    cookies: ["cto_bundle"],
    localStorage: ["criteo_fast_bid_expires", "cto_bundle", "criteo_fast_bid", "criteo_pt_cdb_mngr_metrics", "__ansync3rdp_criteo"]
  },
  comscore: {
    cookies: ["comScore", "_scor_uid"]
  },
  ipsos: {
    cookies: ["DM_SitId1073", "DM_SitId1073SecId5802", "DotMetrics.AmpCookie"],
    localStorage: ["DotmetricsSiteData", "DotMetricsTimeOnPage", "DotMetricsUserId", "DotMetricsDeviceGuidId"]
  },
  permutive: {
    cookies: ["permutive-id"],
    localStorage: ["permutive-data-queries", "_pubcid", "permutive-pvc", "permutive-data-enrichers", "permutive-session", "permutive-data-misc", "permutive-unprocessed-pba", "permutive-app", "permutive-data-models", "permutive-id", "permutive-consent", "permutive-events-cache", "permutive-data-queries", "permutive-events-for-page", "__permutiveConfigQueryParams", "_psegs"],
    sessionStorage: ["__permutiveConfigQueryParams"]
  },
  googletag: {
    cookies: ["__gpi", "__gads"]
  }
};
var deprecatedVendorStorageIds = {
  "google-analytics": {
    cookies: ["_gid", "_ga"]
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendors.js":
/*!*****************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/vendors.js ***!
  \*****************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AusVendorIDs: () => (/* binding */ AusVendorIDs),
/* harmony export */   TCFV2VendorIDs: () => (/* binding */ TCFV2VendorIDs),
/* harmony export */   UsVendorIDs: () => (/* binding */ UsVendorIDs),
/* harmony export */   VendorIDs: () => (/* binding */ VendorIDs)
/* harmony export */ });
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }
var TCFV2VendorIDs = {
  // keep the list in README.md up to date with these values
  a9: ["5f369a02b8e05c308701f829"],
  acast: ["5f203dcb1f0dea790562e20f"],
  adYouLike: ["5f2d22a5b8e05c028e5c2e97"],
  braze: ["5ed8c49c4b8ce4571c7ad801"],
  comscore: ["5efefe25b8e05c06542b2a77"],
  criteo: ["5e98e7f1b8e05c111d01b462"],
  "google-mobile-ads": ["5f1aada6b8e05c306c0597d7"],
  "google-tag-manager": ["5e952f6107d9d20c88e7c975"],
  googletag: ["5f1aada6b8e05c306c0597d7"],
  groupM: ["5e37fc3e56a5e66147767231"],
  ias: ["5e7ced57b8e05c485246ccf3"],
  id5: ["5ee15bc7b8e05c16366599cb"],
  inizio: ["5e37fc3e56a5e6615502f9c9"],
  ipsos: ["5fa51b29a228638b4a1980e4"],
  indexExchange: ["5e7ced57b8e05c485246ccd8"],
  magnite: ["5e7ced57b8e05c485246cce5"],
  nielsen: ["5ef5c3a5b8e05c69980eaa5b"],
  ophan: ["5f203dbeeaaaa8768fd3226a"],
  openX: ["5e865b36b8e05c6f984a37e6"],
  ozone: ["5e7ced57b8e05c5a7d171cd3"],
  permutive: ["5f369a02b8e05c2f2d546a40"],
  pubmatic: ["5eab3d5ab8e05c241a63c5db"],
  qm: ["5f295fa4b8e05c76a44c3149"],
  remarketing: ["5ed0eb688a76503f1016578f"],
  sentry: ["5f0f39014effda6e8bbd2006"],
  teads: ["5eab3d5ab8e05c2bbe33f399"],
  theTradeDesk: ["5e865b36b8e05c48537f60a7"],
  twitter: ["5e71760b69966540e4554f01"],
  xandr: ["5e7ced57b8e05c4854221bba"],
  "youtube-player": ["5e7ac3fae30e7d1bc1ebf5e8"]
};
var AusVendorIDs = {
  redplanet: ["not-tcfv2-vendor"]
};
var UsVendorIDs = {
  admiral: ["not-tcfv2-vendor"]
};
var VendorIDs = _objectSpread(_objectSpread(_objectSpread({}, TCFV2VendorIDs), AusVendorIDs), UsVendorIDs);


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js":
/*!***********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js ***!
  \***********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCookie: () => (/* binding */ getCookie)
/* harmony export */ });
/* harmony import */ var _getCookieValues_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getCookieValues.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookieValues.js");
/* harmony import */ var _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./memoizedCookies.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/memoizedCookies.js");


var getCookie = _ref => {
  var {
    name,
    shouldMemoize = false
  } = _ref;
  var memoizedCookie = _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_1__.memoizedCookies.get(name);
  if (memoizedCookie) {
    return memoizedCookie;
  }
  var [value] = (0,_getCookieValues_js__WEBPACK_IMPORTED_MODULE_0__.getCookieValues)(name);
  if (value) {
    if (shouldMemoize) {
      _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_1__.memoizedCookies.set(name, value);
    }
    return value;
  }
  return null;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookieValues.js":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookieValues.js ***!
  \*****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getCookieValues: () => (/* binding */ getCookieValues)
/* harmony export */ });
var getCookieValues = name => {
  var nameEq = "".concat(name, "=");
  var cookies = document.cookie.split(";");
  return cookies.reduce((acc, cookie) => {
    var cookieTrimmed = cookie.trim();
    if (cookieTrimmed.startsWith(nameEq)) {
      acc.push(cookieTrimmed.substring(nameEq.length, cookieTrimmed.length));
    }
    return acc;
  }, []);
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getShortDomain.js":
/*!****************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getShortDomain.js ***!
  \****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getShortDomain: () => (/* binding */ getShortDomain)
/* harmony export */ });
var getShortDomain = function () {
  var _window$guardian;
  var {
    isCrossSubdomain = false
  } = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  var domain = document.domain || "";
  if (domain === "localhost" || (_window$guardian = window.guardian) !== null && _window$guardian !== void 0 && (_window$guardian = _window$guardian.config) !== null && _window$guardian !== void 0 && (_window$guardian = _window$guardian.page) !== null && _window$guardian !== void 0 && _window$guardian.isPreview) {
    return domain;
  }
  if (isCrossSubdomain) {
    return ["", ...domain.split(".").slice(-2)].join(".");
  }
  return domain.replace(/^(www|m\.code|dev|m)\./, ".");
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/memoizedCookies.js":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/memoizedCookies.js ***!
  \*****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   memoizedCookies: () => (/* binding */ memoizedCookies)
/* harmony export */ });
var memoizedCookies = /* @__PURE__ */new Map();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/removeCookie.js":
/*!**************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/removeCookie.js ***!
  \**************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   removeCookie: () => (/* binding */ removeCookie)
/* harmony export */ });
/* harmony import */ var _getShortDomain_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./getShortDomain.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getShortDomain.js");

var removeCookie = _ref => {
  var {
    name,
    currentDomainOnly = false
  } = _ref;
  var expires = "expires=Thu, 01 Jan 1970 00:00:01 GMT;";
  var path = "path=/;";
  document.cookie = "".concat(name, "=;").concat(path).concat(expires);
  if (!currentDomainOnly) {
    document.cookie = "".concat(name, "=;").concat(path).concat(expires, " domain=").concat((0,_getShortDomain_js__WEBPACK_IMPORTED_MODULE_0__.getShortDomain)(), ";");
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js":
/*!***********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js ***!
  \***********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isObject: () => (/* binding */ isObject)
/* harmony export */ });
var isObject = value => {
  if (Object.prototype.toString.call(value) !== "[object Object]") {
    return false;
  }
  var prototype = Object.getPrototypeOf(value);
  return prototype === null || prototype === Object.prototype;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js":
/*!***********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js ***!
  \***********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isString: () => (/* binding */ isString)
/* harmony export */ });
var isString = _ => {
  return Object.prototype.toString.call(_) === "[object String]";
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isUndefined/isUndefined.js":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isUndefined/isUndefined.js ***!
  \*****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isUndefined: () => (/* binding */ isUndefined)
/* harmony export */ });
var isUndefined = _ => _ === void 0;


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js":
/*!*******************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js ***!
  \*******************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isSubscribedTo: () => (/* binding */ isSubscribedTo),
/* harmony export */   log: () => (/* binding */ log),
/* harmony export */   messageStyle: () => (/* binding */ messageStyle)
/* harmony export */ });
/* harmony import */ var _isString_isString_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../isString/isString.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _isUndefined_isUndefined_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../isUndefined/isUndefined.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isUndefined/isUndefined.js");
/* harmony import */ var _storage_storage_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../storage/storage.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
/* harmony import */ var _storage_key_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./storage-key.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/storage-key.js");
/* harmony import */ var _subscriptions_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./subscriptions.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/subscriptions.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }





var _a;
var SUBSCRIPTIONS_CACHE;
var getSubscriptions = () => {
  if ((0,_isUndefined_isUndefined_js__WEBPACK_IMPORTED_MODULE_1__.isUndefined)(SUBSCRIPTIONS_CACHE)) {
    var storedSubscriptions = _storage_storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.local.get(_storage_key_js__WEBPACK_IMPORTED_MODULE_3__.STORAGE_KEY);
    if ((0,_isString_isString_js__WEBPACK_IMPORTED_MODULE_0__.isString)(storedSubscriptions)) {
      SUBSCRIPTIONS_CACHE = new Set(storedSubscriptions.split(",").filter(_subscriptions_js__WEBPACK_IMPORTED_MODULE_4__.isSubscription));
    } else {
      SUBSCRIPTIONS_CACHE = /* @__PURE__ */new Set();
    }
  }
  return SUBSCRIPTIONS_CACHE;
};
var subscribeTo = subscription => {
  var subscriptions = getSubscriptions();
  subscriptions.add(subscription);
  _storage_storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.local.set(_storage_key_js__WEBPACK_IMPORTED_MODULE_3__.STORAGE_KEY, Array.from(subscriptions).join(","));
  log(subscription, "\u{1F514} Subscribed, hello!");
};
var unsubscribeFrom = subscription => {
  var subscriptions = getSubscriptions();
  subscriptions.delete(subscription);
  _storage_storage_js__WEBPACK_IMPORTED_MODULE_2__.storage.local.set(_storage_key_js__WEBPACK_IMPORTED_MODULE_3__.STORAGE_KEY, Array.from(subscriptions).join(","));
  log(subscription, "\u{1F515} Unsubscribed, good-bye!");
};
var isSubscribedTo = subscription => getSubscriptions().has(subscription);
var logStyles = _objectSpread(_objectSpread({}, _subscriptions_js__WEBPACK_IMPORTED_MODULE_4__.subscriptionStyles), _subscriptions_js__WEBPACK_IMPORTED_MODULE_4__.commonStyle);
var messageStyle = subscriptionStyle => {
  var {
    background,
    font
  } = logStyles[subscriptionStyle];
  return "background: ".concat(background, "; color: ").concat(font, "; padding: 2px 6px; border-radius:20px");
};
var log = function (subscription) {
  if (isSubscribedTo(subscription)) {
    var styles = [messageStyle("common"), "", messageStyle(subscription), ""];
    for (var _len = arguments.length, args = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      args[_key - 1] = arguments[_key];
    }
    console.log("%c@guardian%c %c".concat(subscription, "%c"), ...styles, ...args);
  }
};
if (typeof window !== "undefined") {
  var _window$guardian, _a$logger;
  (_window$guardian = window.guardian) !== null && _window$guardian !== void 0 ? _window$guardian : window.guardian = {};
  (_a$logger = (_a = window.guardian).logger) !== null && _a$logger !== void 0 ? _a$logger : _a.logger = {
    subscribeTo,
    unsubscribeFrom,
    teams: () => {
      console.warn("guardian.logger.teams() is deprecated - use subscriptions()");
      return Object.keys(_subscriptions_js__WEBPACK_IMPORTED_MODULE_4__.subscriptionStyles);
    },
    subscriptions: () => Object.keys(_subscriptions_js__WEBPACK_IMPORTED_MODULE_4__.subscriptionStyles)
  };
}


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/storage-key.js":
/*!************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/storage-key.js ***!
  \************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   STORAGE_KEY: () => (/* binding */ STORAGE_KEY)
/* harmony export */ });
var STORAGE_KEY = "gu.logger";


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/subscriptions.js":
/*!**************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/subscriptions.js ***!
  \**************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   commonStyle: () => (/* binding */ commonStyle),
/* harmony export */   isSubscription: () => (/* binding */ isSubscription),
/* harmony export */   subscriptionStyles: () => (/* binding */ subscriptionStyles)
/* harmony export */ });
var commonStyle = {
  common: {
    background: "#C1D8FC",
    font: "#052962"
  }
};
var subscriptionStyles = {
  commercial: {
    background: "#77EEAA",
    font: "#004400"
  },
  cmp: {
    background: "#FF6BB5",
    font: "#2F0404"
  },
  dotcom: {
    background: "#000000",
    font: "#ff7300"
  },
  design: {
    background: "#185E36",
    font: "#FFF4F2"
  },
  tx: {
    background: "#2F4F4F",
    font: "#FFFFFF"
  },
  supporterRevenue: {
    background: "#0F70B7",
    font: "#ffffff"
  },
  identity: {
    background: "#6F5F8F",
    font: "#ffffff"
  },
  openJournalism: {
    background: "#C74600",
    font: "#FEF9F5"
  },
  perf: {
    background: "#FFD700",
    font: "#000000"
  }
};
var isSubscription = subscription => Object.keys(subscriptionStyles).includes(subscription);


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/package.json.js":
/*!******************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/package.json.js ***!
  \******************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   version: () => (/* binding */ version)
/* harmony export */ });
var version = "25.2.0";


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js":
/*!*********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js ***!
  \*********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   storage: () => (/* binding */ storage)
/* harmony export */ });
/* harmony import */ var _isObject_isObject_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../isObject/isObject.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");
/* harmony import */ var _isString_isString_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../isString/isString.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");


var __defProp = Object.defineProperty;
var __typeError = msg => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
  enumerable: true,
  configurable: true,
  writable: true,
  value
}) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var _storage, _local, _session, _a;
class StorageFactory {
  // https://mdn.io/Private_class_fields
  constructor(storageHandler) {
    __privateAdd(this, _storage);
    /**
     * Check whether storage is available.
     */
    __publicField(this, "isAvailable", () => Boolean(__privateGet(this, _storage)));
    /**
     * Retrieve an item from storage.
     *
     * @param key - the name of the item
     */
    __publicField(this, "get", key => {
      try {
        var _privateGet$getItem, _privateGet;
        var data = JSON.parse((_privateGet$getItem = (_privateGet = __privateGet(this, _storage)) === null || _privateGet === void 0 ? void 0 : _privateGet.getItem(key)) !== null && _privateGet$getItem !== void 0 ? _privateGet$getItem : "");
        if (!(0,_isObject_isObject_js__WEBPACK_IMPORTED_MODULE_0__.isObject)(data)) {
          return null;
        }
        var {
          value,
          expires
        } = data;
        if (((0,_isString_isString_js__WEBPACK_IMPORTED_MODULE_1__.isString)(expires) || typeof expires === "number") && /* @__PURE__ */new Date() > new Date(expires)) {
          this.remove(key);
          return null;
        }
        return value;
      } catch (e) {
        return null;
      }
    });
    /**
     * Save a value to storage.
     *
     * @param key - the name of the item
     * @param value - the data to save
     * @param expires - optional date on which this data will expire
     */
    __publicField(this, "set", (key, value, expires) => {
      var _privateGet2;
      return (_privateGet2 = __privateGet(this, _storage)) === null || _privateGet2 === void 0 ? void 0 : _privateGet2.setItem(key, JSON.stringify({
        value,
        expires: expires ? new Date(expires) : void 0
      }));
    });
    /**
     * Remove an item from storage.
     *
     * @param key - the name of the item
     */
    __publicField(this, "remove", key => {
      var _privateGet3;
      return (_privateGet3 = __privateGet(this, _storage)) === null || _privateGet3 === void 0 ? void 0 : _privateGet3.removeItem(key);
    });
    /**
     * Removes all items from storage.
     */
    __publicField(this, "clear", () => {
      var _privateGet4;
      return (_privateGet4 = __privateGet(this, _storage)) === null || _privateGet4 === void 0 ? void 0 : _privateGet4.clear();
    });
    /**
     * Retrieve an item from storage in its raw state.
     *
     * @param key - the name of the item
     */
    __publicField(this, "getRaw", key => {
      var _privateGet$getItem2, _privateGet5;
      return (_privateGet$getItem2 = (_privateGet5 = __privateGet(this, _storage)) === null || _privateGet5 === void 0 ? void 0 : _privateGet5.getItem(key)) !== null && _privateGet$getItem2 !== void 0 ? _privateGet$getItem2 : null;
    });
    /**
     * Save a raw value to storage.
     *
     * @param key - the name of the item
     * @param value - the data to save
     */
    __publicField(this, "setRaw", (key, value) => {
      var _privateGet6;
      return (_privateGet6 = __privateGet(this, _storage)) === null || _privateGet6 === void 0 ? void 0 : _privateGet6.setItem(key, value);
    });
    /**
     * Get key by index.
     * @returns the name of the key at that index (`string`), or `null` (if
     *      index is out of range of if storage is unavailable) - if the index
     *      is out of range, or if storage is not available.
     *
     * Wrapper for the `key` method on the native `Storage` object, with
     * additional check for availability of storage. Note that the _order_ of
     * keys in storage is dependent on user-agent implementation, and so you
     * should not assume that keys will be stored in any particular order (e.g.
     * order of insertion).
     * @see https://developer.mozilla.org/en-US/docs/Web/API/Storage/key
     */
    __publicField(this, "key", index => {
      var _privateGet$key, _privateGet7;
      return (_privateGet$key = (_privateGet7 = __privateGet(this, _storage)) === null || _privateGet7 === void 0 ? void 0 : _privateGet7.key(index)) !== null && _privateGet$key !== void 0 ? _privateGet$key : null;
    });
    /**
     * Get the number of items in storage.
     * @returns the number of items in storage, or `null` if storage is
     * 	not available.
     */
    __publicField(this, "length", () => {
      var _privateGet$length, _privateGet8;
      return (_privateGet$length = (_privateGet8 = __privateGet(this, _storage)) === null || _privateGet8 === void 0 ? void 0 : _privateGet8.length) !== null && _privateGet$length !== void 0 ? _privateGet$length : null;
    });
    try {
      var storage2 = window[storageHandler];
      var uid = (/* @__PURE__ */new Date()).toString();
      storage2.setItem(uid, uid);
      var available = storage2.getItem(uid) == uid;
      storage2.removeItem(uid);
      if (available) {
        __privateSet(this, _storage, storage2);
      }
    } catch (e) {}
  }
}
_storage = new WeakMap();
var storage = new (_a = class {
  constructor() {
    __privateAdd(this, _local);
    __privateAdd(this, _session);
  }
  // creating the instance requires testing the native implementation
  // which is blocking. therefore, only create new instances of the factory
  // when it's accessed i.e. we know we're going to use it
  get local() {
    var _privateGet9;
    return (_privateGet9 = __privateGet(this, _local)) !== null && _privateGet9 !== void 0 ? _privateGet9 : __privateSet(this, _local, new StorageFactory("localStorage"));
  }
  get session() {
    var _privateGet0;
    return (_privateGet0 = __privateGet(this, _session)) !== null && _privateGet0 !== void 0 ? _privateGet0 : __privateSet(this, _session, new StorageFactory("sessionStorage"));
  }
}, _local = new WeakMap(), _session = new WeakMap(), _a)();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js":
/*!**************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js ***!
  \**************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   breakpoints: () => (/* binding */ breakpoints)
/* harmony export */ });
var breakpoints = {
  desktop: 980,
  leftCol: 1140,
  mobile: 320,
  mobileLandscape: 480,
  mobileMedium: 375,
  phablet: 660,
  tablet: 740,
  wide: 1300
};


/***/ }),

/***/ "../node_modules/.pnpm/ansi-html-community@0.0.8/node_modules/ansi-html-community/index.js":
/*!*************************************************************************************************!*\
  !*** ../node_modules/.pnpm/ansi-html-community@0.0.8/node_modules/ansi-html-community/index.js ***!
  \*************************************************************************************************/
/***/ ((module) => {



module.exports = ansiHTML;
// Reference to https://github.com/sindresorhus/ansi-regex
var _regANSI = /(?:(?:\u001b\[)|\u009b)(?:(?:[0-9]{1,3})?(?:(?:;[0-9]{0,3})*)?[A-M|f-m])|\u001b[A-M]/;
var _defColors = {
  reset: ['fff', '000'],
  // [FOREGROUD_COLOR, BACKGROUND_COLOR]
  black: '000',
  red: 'ff0000',
  green: '209805',
  yellow: 'e8bf03',
  blue: '0000ff',
  magenta: 'ff00ff',
  cyan: '00ffee',
  lightgrey: 'f0f0f0',
  darkgrey: '888'
};
var _styles = {
  30: 'black',
  31: 'red',
  32: 'green',
  33: 'yellow',
  34: 'blue',
  35: 'magenta',
  36: 'cyan',
  37: 'lightgrey'
};
var _openTags = {
  '1': 'font-weight:bold',
  // bold
  '2': 'opacity:0.5',
  // dim
  '3': '<i>',
  // italic
  '4': '<u>',
  // underscore
  '8': 'display:none',
  // hidden
  '9': '<del>' // delete
};
var _closeTags = {
  '23': '</i>',
  // reset italic
  '24': '</u>',
  // reset underscore
  '29': '</del>' // reset delete
};
[0, 21, 22, 27, 28, 39, 49].forEach(function (n) {
  _closeTags[n] = '</span>';
});
/**
 * Converts text with ANSI color codes to HTML markup.
 * @param {String} text
 * @returns {*}
 */
function ansiHTML(text) {
  // Returns the text if the string has no ANSI escape code.
  if (!_regANSI.test(text)) {
    return text;
  }
  // Cache opened sequence.
  var ansiCodes = [];
  // Replace with markup.
  var ret = text.replace(/\033\[(\d+)m/g, function (match, seq) {
    var ot = _openTags[seq];
    if (ot) {
      // If current sequence has been opened, close it.
      if (!!~ansiCodes.indexOf(seq)) {
        // eslint-disable-line no-extra-boolean-cast
        ansiCodes.pop();
        return '</span>';
      }
      // Open tag.
      ansiCodes.push(seq);
      return ot[0] === '<' ? ot : '<span style="' + ot + ';">';
    }
    var ct = _closeTags[seq];
    if (ct) {
      // Pop sequence
      ansiCodes.pop();
      return ct;
    }
    return '';
  });
  // Make sure tags are closed.
  var l = ansiCodes.length;
  l > 0 && (ret += Array(l + 1).join('</span>'));
  return ret;
}
/**
 * Customize colors.
 * @param {Object} colors reference to _defColors
 */
ansiHTML.setColors = function (colors) {
  if (typeof colors !== 'object') {
    throw new Error('`colors` parameter must be an Object.');
  }
  var _finalColors = {};
  for (var key in _defColors) {
    var hex = colors.hasOwnProperty(key) ? colors[key] : null;
    if (!hex) {
      _finalColors[key] = _defColors[key];
      continue;
    }
    if ('reset' === key) {
      if (typeof hex === 'string') {
        hex = [hex];
      }
      if (!Array.isArray(hex) || hex.length === 0 || hex.some(function (h) {
        return typeof h !== 'string';
      })) {
        throw new Error('The value of `' + key + '` property must be an Array and each item could only be a hex string, e.g.: FF0000');
      }
      var defHexColor = _defColors[key];
      if (!hex[0]) {
        hex[0] = defHexColor[0];
      }
      if (hex.length === 1 || !hex[1]) {
        hex = [hex[0]];
        hex.push(defHexColor[1]);
      }
      hex = hex.slice(0, 2);
    } else if (typeof hex !== 'string') {
      throw new Error('The value of `' + key + '` property must be a hex string, e.g.: FF0000');
    }
    _finalColors[key] = hex;
  }
  _setTags(_finalColors);
};
/**
 * Reset colors.
 */
ansiHTML.reset = function () {
  _setTags(_defColors);
};
/**
 * Expose tags, including open and close.
 * @type {Object}
 */
ansiHTML.tags = {};
if (Object.defineProperty) {
  Object.defineProperty(ansiHTML.tags, 'open', {
    get: function () {
      return _openTags;
    }
  });
  Object.defineProperty(ansiHTML.tags, 'close', {
    get: function () {
      return _closeTags;
    }
  });
} else {
  ansiHTML.tags.open = _openTags;
  ansiHTML.tags.close = _closeTags;
}
function _setTags(colors) {
  // reset all
  _openTags['0'] = 'font-weight:normal;opacity:1;color:#' + colors.reset[0] + ';background:#' + colors.reset[1];
  // inverse
  _openTags['7'] = 'color:#' + colors.reset[1] + ';background:#' + colors.reset[0];
  // dark grey
  _openTags['90'] = 'color:#' + colors.darkgrey;
  for (var code in _styles) {
    var color = _styles[code];
    var oriColor = colors[color] || '000';
    _openTags[code] = 'color:#' + oriColor;
    code = parseInt(code);
    _openTags[(code + 10).toString()] = 'background:#' + oriColor;
  }
}
ansiHTML.reset();

/***/ }),

/***/ "../node_modules/.pnpm/events@3.3.0/node_modules/events/events.js":
/*!************************************************************************!*\
  !*** ../node_modules/.pnpm/events@3.3.0/node_modules/events/events.js ***!
  \************************************************************************/
/***/ ((module) => {

// Copyright Joyent, Inc. and other Node contributors.
//
// Permission is hereby granted, free of charge, to any person obtaining a
// copy of this software and associated documentation files (the
// "Software"), to deal in the Software without restriction, including
// without limitation the rights to use, copy, modify, merge, publish,
// distribute, sublicense, and/or sell copies of the Software, and to permit
// persons to whom the Software is furnished to do so, subject to the
// following conditions:
//
// The above copyright notice and this permission notice shall be included
// in all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
// OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
// MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
// NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
// DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
// OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
// USE OR OTHER DEALINGS IN THE SOFTWARE.


var R = typeof Reflect === 'object' ? Reflect : null;
var ReflectApply = R && typeof R.apply === 'function' ? R.apply : function ReflectApply(target, receiver, args) {
  return Function.prototype.apply.call(target, receiver, args);
};
var ReflectOwnKeys;
if (R && typeof R.ownKeys === 'function') {
  ReflectOwnKeys = R.ownKeys;
} else if (Object.getOwnPropertySymbols) {
  ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target).concat(Object.getOwnPropertySymbols(target));
  };
} else {
  ReflectOwnKeys = function ReflectOwnKeys(target) {
    return Object.getOwnPropertyNames(target);
  };
}
function ProcessEmitWarning(warning) {
  if (console && console.warn) console.warn(warning);
}
var NumberIsNaN = Number.isNaN || function NumberIsNaN(value) {
  return value !== value;
};
function EventEmitter() {
  EventEmitter.init.call(this);
}
module.exports = EventEmitter;
module.exports.once = once;
// Backwards-compat with node 0.10.x
EventEmitter.EventEmitter = EventEmitter;
EventEmitter.prototype._events = undefined;
EventEmitter.prototype._eventsCount = 0;
EventEmitter.prototype._maxListeners = undefined;
// By default EventEmitters will print a warning if more than 10 listeners are
// added to it. This is a useful default which helps finding memory leaks.
var defaultMaxListeners = 10;
function checkListener(listener) {
  if (typeof listener !== 'function') {
    throw new TypeError('The "listener" argument must be of type Function. Received type ' + typeof listener);
  }
}
Object.defineProperty(EventEmitter, 'defaultMaxListeners', {
  enumerable: true,
  get: function () {
    return defaultMaxListeners;
  },
  set: function (arg) {
    if (typeof arg !== 'number' || arg < 0 || NumberIsNaN(arg)) {
      throw new RangeError('The value of "defaultMaxListeners" is out of range. It must be a non-negative number. Received ' + arg + '.');
    }
    defaultMaxListeners = arg;
  }
});
EventEmitter.init = function () {
  if (this._events === undefined || this._events === Object.getPrototypeOf(this)._events) {
    this._events = Object.create(null);
    this._eventsCount = 0;
  }
  this._maxListeners = this._maxListeners || undefined;
};
// Obviously not all Emitters should be limited to 10. This function allows
// that to be increased. Set to zero for unlimited.
EventEmitter.prototype.setMaxListeners = function setMaxListeners(n) {
  if (typeof n !== 'number' || n < 0 || NumberIsNaN(n)) {
    throw new RangeError('The value of "n" is out of range. It must be a non-negative number. Received ' + n + '.');
  }
  this._maxListeners = n;
  return this;
};
function _getMaxListeners(that) {
  if (that._maxListeners === undefined) return EventEmitter.defaultMaxListeners;
  return that._maxListeners;
}
EventEmitter.prototype.getMaxListeners = function getMaxListeners() {
  return _getMaxListeners(this);
};
EventEmitter.prototype.emit = function emit(type) {
  var args = [];
  for (var i = 1; i < arguments.length; i++) args.push(arguments[i]);
  var doError = type === 'error';
  var events = this._events;
  if (events !== undefined) doError = doError && events.error === undefined;else if (!doError) return false;
  // If there is no 'error' event listener then throw.
  if (doError) {
    var er;
    if (args.length > 0) er = args[0];
    if (er instanceof Error) {
      // Note: The comments on the `throw` lines are intentional, they show
      // up in Node's output if this results in an unhandled exception.
      throw er; // Unhandled 'error' event
    }
    // At least give some kind of context to the user
    var err = new Error('Unhandled error.' + (er ? ' (' + er.message + ')' : ''));
    err.context = er;
    throw err; // Unhandled 'error' event
  }
  var handler = events[type];
  if (handler === undefined) return false;
  if (typeof handler === 'function') {
    ReflectApply(handler, this, args);
  } else {
    var len = handler.length;
    var listeners = arrayClone(handler, len);
    for (var i = 0; i < len; ++i) ReflectApply(listeners[i], this, args);
  }
  return true;
};
function _addListener(target, type, listener, prepend) {
  var m;
  var events;
  var existing;
  checkListener(listener);
  events = target._events;
  if (events === undefined) {
    events = target._events = Object.create(null);
    target._eventsCount = 0;
  } else {
    // To avoid recursion in the case that type === "newListener"! Before
    // adding it to the listeners, first emit "newListener".
    if (events.newListener !== undefined) {
      target.emit('newListener', type, listener.listener ? listener.listener : listener);
      // Re-assign `events` because a newListener handler could have caused the
      // this._events to be assigned to a new object
      events = target._events;
    }
    existing = events[type];
  }
  if (existing === undefined) {
    // Optimize the case of one listener. Don't need the extra array object.
    existing = events[type] = listener;
    ++target._eventsCount;
  } else {
    if (typeof existing === 'function') {
      // Adding the second element, need to change to array.
      existing = events[type] = prepend ? [listener, existing] : [existing, listener];
      // If we've already got an array, just append.
    } else if (prepend) {
      existing.unshift(listener);
    } else {
      existing.push(listener);
    }
    // Check for listener leak
    m = _getMaxListeners(target);
    if (m > 0 && existing.length > m && !existing.warned) {
      existing.warned = true;
      // No error code for this since it is a Warning
      // eslint-disable-next-line no-restricted-syntax
      var w = new Error('Possible EventEmitter memory leak detected. ' + existing.length + ' ' + String(type) + ' listeners ' + 'added. Use emitter.setMaxListeners() to ' + 'increase limit');
      w.name = 'MaxListenersExceededWarning';
      w.emitter = target;
      w.type = type;
      w.count = existing.length;
      ProcessEmitWarning(w);
    }
  }
  return target;
}
EventEmitter.prototype.addListener = function addListener(type, listener) {
  return _addListener(this, type, listener, false);
};
EventEmitter.prototype.on = EventEmitter.prototype.addListener;
EventEmitter.prototype.prependListener = function prependListener(type, listener) {
  return _addListener(this, type, listener, true);
};
function onceWrapper() {
  if (!this.fired) {
    this.target.removeListener(this.type, this.wrapFn);
    this.fired = true;
    if (arguments.length === 0) return this.listener.call(this.target);
    return this.listener.apply(this.target, arguments);
  }
}
function _onceWrap(target, type, listener) {
  var state = {
    fired: false,
    wrapFn: undefined,
    target: target,
    type: type,
    listener: listener
  };
  var wrapped = onceWrapper.bind(state);
  wrapped.listener = listener;
  state.wrapFn = wrapped;
  return wrapped;
}
EventEmitter.prototype.once = function once(type, listener) {
  checkListener(listener);
  this.on(type, _onceWrap(this, type, listener));
  return this;
};
EventEmitter.prototype.prependOnceListener = function prependOnceListener(type, listener) {
  checkListener(listener);
  this.prependListener(type, _onceWrap(this, type, listener));
  return this;
};
// Emits a 'removeListener' event if and only if the listener was removed.
EventEmitter.prototype.removeListener = function removeListener(type, listener) {
  var list, events, position, i, originalListener;
  checkListener(listener);
  events = this._events;
  if (events === undefined) return this;
  list = events[type];
  if (list === undefined) return this;
  if (list === listener || list.listener === listener) {
    if (--this._eventsCount === 0) this._events = Object.create(null);else {
      delete events[type];
      if (events.removeListener) this.emit('removeListener', type, list.listener || listener);
    }
  } else if (typeof list !== 'function') {
    position = -1;
    for (i = list.length - 1; i >= 0; i--) {
      if (list[i] === listener || list[i].listener === listener) {
        originalListener = list[i].listener;
        position = i;
        break;
      }
    }
    if (position < 0) return this;
    if (position === 0) list.shift();else {
      spliceOne(list, position);
    }
    if (list.length === 1) events[type] = list[0];
    if (events.removeListener !== undefined) this.emit('removeListener', type, originalListener || listener);
  }
  return this;
};
EventEmitter.prototype.off = EventEmitter.prototype.removeListener;
EventEmitter.prototype.removeAllListeners = function removeAllListeners(type) {
  var listeners, events, i;
  events = this._events;
  if (events === undefined) return this;
  // not listening for removeListener, no need to emit
  if (events.removeListener === undefined) {
    if (arguments.length === 0) {
      this._events = Object.create(null);
      this._eventsCount = 0;
    } else if (events[type] !== undefined) {
      if (--this._eventsCount === 0) this._events = Object.create(null);else delete events[type];
    }
    return this;
  }
  // emit removeListener for all listeners on all events
  if (arguments.length === 0) {
    var keys = Object.keys(events);
    var key;
    for (i = 0; i < keys.length; ++i) {
      key = keys[i];
      if (key === 'removeListener') continue;
      this.removeAllListeners(key);
    }
    this.removeAllListeners('removeListener');
    this._events = Object.create(null);
    this._eventsCount = 0;
    return this;
  }
  listeners = events[type];
  if (typeof listeners === 'function') {
    this.removeListener(type, listeners);
  } else if (listeners !== undefined) {
    // LIFO order
    for (i = listeners.length - 1; i >= 0; i--) {
      this.removeListener(type, listeners[i]);
    }
  }
  return this;
};
function _listeners(target, type, unwrap) {
  var events = target._events;
  if (events === undefined) return [];
  var evlistener = events[type];
  if (evlistener === undefined) return [];
  if (typeof evlistener === 'function') return unwrap ? [evlistener.listener || evlistener] : [evlistener];
  return unwrap ? unwrapListeners(evlistener) : arrayClone(evlistener, evlistener.length);
}
EventEmitter.prototype.listeners = function listeners(type) {
  return _listeners(this, type, true);
};
EventEmitter.prototype.rawListeners = function rawListeners(type) {
  return _listeners(this, type, false);
};
EventEmitter.listenerCount = function (emitter, type) {
  if (typeof emitter.listenerCount === 'function') {
    return emitter.listenerCount(type);
  } else {
    return listenerCount.call(emitter, type);
  }
};
EventEmitter.prototype.listenerCount = listenerCount;
function listenerCount(type) {
  var events = this._events;
  if (events !== undefined) {
    var evlistener = events[type];
    if (typeof evlistener === 'function') {
      return 1;
    } else if (evlistener !== undefined) {
      return evlistener.length;
    }
  }
  return 0;
}
EventEmitter.prototype.eventNames = function eventNames() {
  return this._eventsCount > 0 ? ReflectOwnKeys(this._events) : [];
};
function arrayClone(arr, n) {
  var copy = new Array(n);
  for (var i = 0; i < n; ++i) copy[i] = arr[i];
  return copy;
}
function spliceOne(list, index) {
  for (; index + 1 < list.length; index++) list[index] = list[index + 1];
  list.pop();
}
function unwrapListeners(arr) {
  var ret = new Array(arr.length);
  for (var i = 0; i < ret.length; ++i) {
    ret[i] = arr[i].listener || arr[i];
  }
  return ret;
}
function once(emitter, name) {
  return new Promise(function (resolve, reject) {
    function errorListener(err) {
      emitter.removeListener(name, resolver);
      reject(err);
    }
    function resolver() {
      if (typeof emitter.removeListener === 'function') {
        emitter.removeListener('error', errorListener);
      }
      resolve([].slice.call(arguments));
    }
    ;
    eventTargetAgnosticAddListener(emitter, name, resolver, {
      once: true
    });
    if (name !== 'error') {
      addErrorHandlerIfEventEmitter(emitter, errorListener, {
        once: true
      });
    }
  });
}
function addErrorHandlerIfEventEmitter(emitter, handler, flags) {
  if (typeof emitter.on === 'function') {
    eventTargetAgnosticAddListener(emitter, 'error', handler, flags);
  }
}
function eventTargetAgnosticAddListener(emitter, name, listener, flags) {
  if (typeof emitter.on === 'function') {
    if (flags.once) {
      emitter.once(name, listener);
    } else {
      emitter.on(name, listener);
    }
  } else if (typeof emitter.addEventListener === 'function') {
    // EventTarget does not have `error` event semantics like Node
    // EventEmitters, we do not listen for `error` events here.
    emitter.addEventListener(name, function wrapListener(arg) {
      // IE does not have builtin `{ once: true }` support so we
      // have to do it manually.
      if (flags.once) {
        emitter.removeEventListener(name, wrapListener);
      }
      listener(arg);
    });
  } else {
    throw new TypeError('The "emitter" argument must be of type EventEmitter. Received type ' + typeof emitter);
  }
}

/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/clients/WebSocketClient.js":
/*!**********************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/clients/WebSocketClient.js ***!
  \**********************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ WebSocketClient)
/* harmony export */ });
/* harmony import */ var _utils_log_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../utils/log.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/log.js");
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function _classCallCheck(a, n) {
  if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
  for (var t = 0; t < r.length; t++) {
    var o = r[t];
    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
  }
}
function _createClass(e, r, t) {
  return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
    writable: !1
  }), e;
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}

var WebSocketClient = /*#__PURE__*/function () {
  /**
   * @param {string} url
   */
  function WebSocketClient(url) {
    _classCallCheck(this, WebSocketClient);
    this.client = new WebSocket(url);
    this.client.onerror = function (error) {
      _utils_log_js__WEBPACK_IMPORTED_MODULE_0__.log.error(error);
    };
  }
  /**
   * @param {(...args: any[]) => void} f
   */
  return _createClass(WebSocketClient, [{
    key: "onOpen",
    value: function onOpen(f) {
      this.client.onopen = f;
    }
    /**
     * @param {(...args: any[]) => void} f
     */
  }, {
    key: "onClose",
    value: function onClose(f) {
      this.client.onclose = f;
    }
    // call f with the message string as the first argument
    /**
     * @param {(...args: any[]) => void} f
     */
  }, {
    key: "onMessage",
    value: function onMessage(f) {
      this.client.onmessage = function (e) {
        f(e.data);
      };
    }
  }]);
}();


/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/modules/logger/index.js":
/*!*******************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/modules/logger/index.js ***!
  \*******************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, exports) => {



/******/
(function () {
  /******/"use strict";

  /******/
  var __webpack_modules__ = {
    /***/"./client-src/modules/logger/tapable.js": (
    /*!**********************************************!*\
      !*** ./client-src/modules/logger/tapable.js ***!
      \**********************************************/
    /***/
    function (__unused_webpack_module, __nested_webpack_exports__, __nested_webpack_require_395__) {
      __nested_webpack_require_395__.r(__nested_webpack_exports__);
      /* harmony export */
      __nested_webpack_require_395__.d(__nested_webpack_exports__, {
        /* harmony export */SyncBailHook: function () {
          return /* binding */SyncBailHook;
        }
        /* harmony export */
      });
      function SyncBailHook() {
        return {
          call: function call() {}
        };
      }
      /**
       * Client stub for tapable SyncBailHook
       */
      // eslint-disable-next-line import/prefer-default-export
      /***/
    }),
    /***/"./node_modules/webpack/lib/logging/Logger.js": (
    /*!****************************************************!*\
      !*** ./node_modules/webpack/lib/logging/Logger.js ***!
      \****************************************************/
    /***/
    function (module) {
      /*
          MIT License http://www.opensource.org/licenses/mit-license.php
          Author Tobias Koppers @sokra
      */
      function _typeof(o) {
        "@babel/helpers - typeof";

        return _typeof = "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }) && "symbol" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }).iterator ? function (o) {
          return typeof o;
        } : function (o) {
          return o && "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
            return i;
          }) && o.constructor === (typeof Symbol !== "undefined" ? Symbol : function (i) {
            return i;
          }) && o !== (typeof Symbol !== "undefined" ? Symbol : function (i) {
            return i;
          }).prototype ? "symbol" : typeof o;
        }, _typeof(o);
      }
      function _toConsumableArray(r) {
        return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
      }
      function _nonIterableSpread() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      function _unsupportedIterableToArray(r, a) {
        if (r) {
          if ("string" == typeof r) return _arrayLikeToArray(r, a);
          var t = {}.toString.call(r).slice(8, -1);
          return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
        }
      }
      function _iterableToArray(r) {
        if ("undefined" != typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }) && null != r[(typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }).iterator] || null != r["@@iterator"]) return Array.from(r);
      }
      function _arrayWithoutHoles(r) {
        if (Array.isArray(r)) return _arrayLikeToArray(r);
      }
      function _arrayLikeToArray(r, a) {
        (null == a || a > r.length) && (a = r.length);
        for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
        return n;
      }
      function _classCallCheck(a, n) {
        if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
      }
      function _defineProperties(e, r) {
        for (var t = 0; t < r.length; t++) {
          var o = r[t];
          o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
        }
      }
      function _createClass(e, r, t) {
        return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
          writable: !1
        }), e;
      }
      function _toPropertyKey(t) {
        var i = _toPrimitive(t, "string");
        return "symbol" == _typeof(i) ? i : i + "";
      }
      function _toPrimitive(t, r) {
        if ("object" != _typeof(t) || !t) return t;
        var e = t[(typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }).toPrimitive];
        if (void 0 !== e) {
          var i = e.call(t, r || "default");
          if ("object" != _typeof(i)) return i;
          throw new TypeError("@@toPrimitive must return a primitive value.");
        }
        return ("string" === r ? String : Number)(t);
      }
      var LogType = Object.freeze({
        error: (/** @type {"error"} */"error"),
        // message, c style arguments
        warn: (/** @type {"warn"} */"warn"),
        // message, c style arguments
        info: (/** @type {"info"} */"info"),
        // message, c style arguments
        log: (/** @type {"log"} */"log"),
        // message, c style arguments
        debug: (/** @type {"debug"} */"debug"),
        // message, c style arguments
        trace: (/** @type {"trace"} */"trace"),
        // no arguments
        group: (/** @type {"group"} */"group"),
        // [label]
        groupCollapsed: (/** @type {"groupCollapsed"} */"groupCollapsed"),
        // [label]
        groupEnd: (/** @type {"groupEnd"} */"groupEnd"),
        // [label]
        profile: (/** @type {"profile"} */"profile"),
        // [profileName]
        profileEnd: (/** @type {"profileEnd"} */"profileEnd"),
        // [profileName]
        time: (/** @type {"time"} */"time"),
        // name, time as [seconds, nanoseconds]
        clear: (/** @type {"clear"} */"clear"),
        // no arguments
        status: (/** @type {"status"} */"status") // message, arguments
      });
      module.exports.LogType = LogType;
      /** @typedef {typeof LogType[keyof typeof LogType]} LogTypeEnum */
      var LOG_SYMBOL = (typeof Symbol !== "undefined" ? Symbol : function (i) {
        return i;
      })("webpack logger raw log method");
      var TIMERS_SYMBOL = (typeof Symbol !== "undefined" ? Symbol : function (i) {
        return i;
      })("webpack logger times");
      var TIMERS_AGGREGATES_SYMBOL = (typeof Symbol !== "undefined" ? Symbol : function (i) {
        return i;
      })("webpack logger aggregated times");
      var WebpackLogger = /*#__PURE__*/function () {
        /**
         * @param {(type: LogTypeEnum, args?: EXPECTED_ANY[]) => void} log log function
         * @param {(name: string | (() => string)) => WebpackLogger} getChildLogger function to create child logger
         */
        function WebpackLogger(log, getChildLogger) {
          _classCallCheck(this, WebpackLogger);
          this[LOG_SYMBOL] = log;
          this.getChildLogger = getChildLogger;
        }
        /**
         * @param {...EXPECTED_ANY} args args
         */
        return _createClass(WebpackLogger, [{
          key: "error",
          value: function error() {
            for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
              args[_key] = arguments[_key];
            }
            this[LOG_SYMBOL](LogType.error, args);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "warn",
          value: function warn() {
            for (var _len2 = arguments.length, args = new Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
              args[_key2] = arguments[_key2];
            }
            this[LOG_SYMBOL](LogType.warn, args);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "info",
          value: function info() {
            for (var _len3 = arguments.length, args = new Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
              args[_key3] = arguments[_key3];
            }
            this[LOG_SYMBOL](LogType.info, args);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "log",
          value: function log() {
            for (var _len4 = arguments.length, args = new Array(_len4), _key4 = 0; _key4 < _len4; _key4++) {
              args[_key4] = arguments[_key4];
            }
            this[LOG_SYMBOL](LogType.log, args);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "debug",
          value: function debug() {
            for (var _len5 = arguments.length, args = new Array(_len5), _key5 = 0; _key5 < _len5; _key5++) {
              args[_key5] = arguments[_key5];
            }
            this[LOG_SYMBOL](LogType.debug, args);
          }
          /**
           * @param {EXPECTED_ANY} assertion assertion
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "assert",
          value: function assert(assertion) {
            if (!assertion) {
              for (var _len6 = arguments.length, args = new Array(_len6 > 1 ? _len6 - 1 : 0), _key6 = 1; _key6 < _len6; _key6++) {
                args[_key6 - 1] = arguments[_key6];
              }
              this[LOG_SYMBOL](LogType.error, args);
            }
          }
        }, {
          key: "trace",
          value: function trace() {
            this[LOG_SYMBOL](LogType.trace, ["Trace"]);
          }
        }, {
          key: "clear",
          value: function clear() {
            this[LOG_SYMBOL](LogType.clear);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "status",
          value: function status() {
            for (var _len7 = arguments.length, args = new Array(_len7), _key7 = 0; _key7 < _len7; _key7++) {
              args[_key7] = arguments[_key7];
            }
            this[LOG_SYMBOL](LogType.status, args);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "group",
          value: function group() {
            for (var _len8 = arguments.length, args = new Array(_len8), _key8 = 0; _key8 < _len8; _key8++) {
              args[_key8] = arguments[_key8];
            }
            this[LOG_SYMBOL](LogType.group, args);
          }
          /**
           * @param {...EXPECTED_ANY} args args
           */
        }, {
          key: "groupCollapsed",
          value: function groupCollapsed() {
            for (var _len9 = arguments.length, args = new Array(_len9), _key9 = 0; _key9 < _len9; _key9++) {
              args[_key9] = arguments[_key9];
            }
            this[LOG_SYMBOL](LogType.groupCollapsed, args);
          }
        }, {
          key: "groupEnd",
          value: function groupEnd() {
            this[LOG_SYMBOL](LogType.groupEnd);
          }
          /**
           * @param {string=} label label
           */
        }, {
          key: "profile",
          value: function profile(label) {
            this[LOG_SYMBOL](LogType.profile, [label]);
          }
          /**
           * @param {string=} label label
           */
        }, {
          key: "profileEnd",
          value: function profileEnd(label) {
            this[LOG_SYMBOL](LogType.profileEnd, [label]);
          }
          /**
           * @param {string} label label
           */
        }, {
          key: "time",
          value: function time(label) {
            /** @type {Map<string | undefined, [number, number]>} */
            this[TIMERS_SYMBOL] = this[TIMERS_SYMBOL] || new Map();
            this[TIMERS_SYMBOL].set(label, process.hrtime());
          }
          /**
           * @param {string=} label label
           */
        }, {
          key: "timeLog",
          value: function timeLog(label) {
            var prev = this[TIMERS_SYMBOL] && this[TIMERS_SYMBOL].get(label);
            if (!prev) {
              throw new Error("No such label '".concat(label, "' for WebpackLogger.timeLog()"));
            }
            var time = process.hrtime(prev);
            this[LOG_SYMBOL](LogType.time, [label].concat(_toConsumableArray(time)));
          }
          /**
           * @param {string=} label label
           */
        }, {
          key: "timeEnd",
          value: function timeEnd(label) {
            var prev = this[TIMERS_SYMBOL] && this[TIMERS_SYMBOL].get(label);
            if (!prev) {
              throw new Error("No such label '".concat(label, "' for WebpackLogger.timeEnd()"));
            }
            var time = process.hrtime(prev);
            /** @type {Map<string | undefined, [number, number]>} */
            this[TIMERS_SYMBOL].delete(label);
            this[LOG_SYMBOL](LogType.time, [label].concat(_toConsumableArray(time)));
          }
          /**
           * @param {string=} label label
           */
        }, {
          key: "timeAggregate",
          value: function timeAggregate(label) {
            var prev = this[TIMERS_SYMBOL] && this[TIMERS_SYMBOL].get(label);
            if (!prev) {
              throw new Error("No such label '".concat(label, "' for WebpackLogger.timeAggregate()"));
            }
            var time = process.hrtime(prev);
            /** @type {Map<string | undefined, [number, number]>} */
            this[TIMERS_SYMBOL].delete(label);
            /** @type {Map<string | undefined, [number, number]>} */
            this[TIMERS_AGGREGATES_SYMBOL] = this[TIMERS_AGGREGATES_SYMBOL] || new Map();
            var current = this[TIMERS_AGGREGATES_SYMBOL].get(label);
            if (current !== undefined) {
              if (time[1] + current[1] > 1e9) {
                time[0] += current[0] + 1;
                time[1] = time[1] - 1e9 + current[1];
              } else {
                time[0] += current[0];
                time[1] += current[1];
              }
            }
            this[TIMERS_AGGREGATES_SYMBOL].set(label, time);
          }
          /**
           * @param {string=} label label
           */
        }, {
          key: "timeAggregateEnd",
          value: function timeAggregateEnd(label) {
            if (this[TIMERS_AGGREGATES_SYMBOL] === undefined) return;
            var time = this[TIMERS_AGGREGATES_SYMBOL].get(label);
            if (time === undefined) return;
            this[TIMERS_AGGREGATES_SYMBOL].delete(label);
            this[LOG_SYMBOL](LogType.time, [label].concat(_toConsumableArray(time)));
          }
        }]);
      }();
      module.exports.Logger = WebpackLogger;
      /***/
    }),
    /***/"./node_modules/webpack/lib/logging/createConsoleLogger.js": (
    /*!*****************************************************************!*\
      !*** ./node_modules/webpack/lib/logging/createConsoleLogger.js ***!
      \*****************************************************************/
    /***/
    function (module, __unused_webpack_exports, __nested_webpack_require_15101__) {
      /*
          MIT License http://www.opensource.org/licenses/mit-license.php
          Author Tobias Koppers @sokra
      */
      function _slicedToArray(r, e) {
        return _arrayWithHoles(r) || _iterableToArrayLimit(r, e) || _unsupportedIterableToArray(r, e) || _nonIterableRest();
      }
      function _nonIterableRest() {
        throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      function _iterableToArrayLimit(r, l) {
        var t = null == r ? null : "undefined" != typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }) && r[(typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }).iterator] || r["@@iterator"];
        if (null != t) {
          var e,
            n,
            i,
            u,
            a = [],
            f = !0,
            o = !1;
          try {
            if (i = (t = t.call(r)).next, 0 === l) {
              if (Object(t) !== t) return;
              f = !1;
            } else for (; !(f = (e = i.call(t)).done) && (a.push(e.value), a.length !== l); f = !0);
          } catch (r) {
            o = !0, n = r;
          } finally {
            try {
              if (!f && null != t.return && (u = t.return(), Object(u) !== u)) return;
            } finally {
              if (o) throw n;
            }
          }
          return a;
        }
      }
      function _arrayWithHoles(r) {
        if (Array.isArray(r)) return r;
      }
      function _toConsumableArray(r) {
        return _arrayWithoutHoles(r) || _iterableToArray(r) || _unsupportedIterableToArray(r) || _nonIterableSpread();
      }
      function _nonIterableSpread() {
        throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.");
      }
      function _unsupportedIterableToArray(r, a) {
        if (r) {
          if ("string" == typeof r) return _arrayLikeToArray(r, a);
          var t = {}.toString.call(r).slice(8, -1);
          return "Object" === t && r.constructor && (t = r.constructor.name), "Map" === t || "Set" === t ? Array.from(r) : "Arguments" === t || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(t) ? _arrayLikeToArray(r, a) : void 0;
        }
      }
      function _iterableToArray(r) {
        if ("undefined" != typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }) && null != r[(typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }).iterator] || null != r["@@iterator"]) return Array.from(r);
      }
      function _arrayWithoutHoles(r) {
        if (Array.isArray(r)) return _arrayLikeToArray(r);
      }
      function _arrayLikeToArray(r, a) {
        (null == a || a > r.length) && (a = r.length);
        for (var e = 0, n = Array(a); e < a; e++) n[e] = r[e];
        return n;
      }
      function _typeof(o) {
        "@babel/helpers - typeof";

        return _typeof = "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }) && "symbol" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
          return i;
        }).iterator ? function (o) {
          return typeof o;
        } : function (o) {
          return o && "function" == typeof (typeof Symbol !== "undefined" ? Symbol : function (i) {
            return i;
          }) && o.constructor === (typeof Symbol !== "undefined" ? Symbol : function (i) {
            return i;
          }) && o !== (typeof Symbol !== "undefined" ? Symbol : function (i) {
            return i;
          }).prototype ? "symbol" : typeof o;
        }, _typeof(o);
      }
      var _require = __nested_webpack_require_15101__(/*! ./Logger */"./node_modules/webpack/lib/logging/Logger.js"),
        LogType = _require.LogType;
      /** @typedef {import("../../declarations/WebpackOptions").FilterItemTypes} FilterItemTypes */
      /** @typedef {import("../../declarations/WebpackOptions").FilterTypes} FilterTypes */
      /** @typedef {import("./Logger").LogTypeEnum} LogTypeEnum */
      /** @typedef {(item: string) => boolean} FilterFunction */
      /** @typedef {(value: string, type: LogTypeEnum, args?: EXPECTED_ANY[]) => void} LoggingFunction */
      /**
       * @typedef {object} LoggerConsole
       * @property {() => void} clear
       * @property {() => void} trace
       * @property {(...args: EXPECTED_ANY[]) => void} info
       * @property {(...args: EXPECTED_ANY[]) => void} log
       * @property {(...args: EXPECTED_ANY[]) => void} warn
       * @property {(...args: EXPECTED_ANY[]) => void} error
       * @property {(...args: EXPECTED_ANY[]) => void=} debug
       * @property {(...args: EXPECTED_ANY[]) => void=} group
       * @property {(...args: EXPECTED_ANY[]) => void=} groupCollapsed
       * @property {(...args: EXPECTED_ANY[]) => void=} groupEnd
       * @property {(...args: EXPECTED_ANY[]) => void=} status
       * @property {(...args: EXPECTED_ANY[]) => void=} profile
       * @property {(...args: EXPECTED_ANY[]) => void=} profileEnd
       * @property {(...args: EXPECTED_ANY[]) => void=} logTime
       */
      /**
       * @typedef {object} LoggerOptions
       * @property {false|true|"none"|"error"|"warn"|"info"|"log"|"verbose"} level loglevel
       * @property {FilterTypes|boolean} debug filter for debug logging
       * @property {LoggerConsole} console the console to log to
       */
      /**
       * @param {FilterItemTypes} item an input item
       * @returns {FilterFunction | undefined} filter function
       */
      var filterToFunction = function filterToFunction(item) {
        if (typeof item === "string") {
          var regExp = new RegExp("[\\\\/]".concat(item.replace(/[-[\]{}()*+?.\\^$|]/g, "\\$&"), "([\\\\/]|$|!|\\?)"));
          return function (ident) {
            return regExp.test(ident);
          };
        }
        if (item && _typeof(item) === "object" && typeof item.test === "function") {
          return function (ident) {
            return item.test(ident);
          };
        }
        if (typeof item === "function") {
          return item;
        }
        if (typeof item === "boolean") {
          return function () {
            return item;
          };
        }
      };
      /**
       * @enum {number}
       */
      var LogLevel = {
        none: 6,
        false: 6,
        error: 5,
        warn: 4,
        info: 3,
        log: 2,
        true: 2,
        verbose: 1
      };
      /**
       * @param {LoggerOptions} options options object
       * @returns {LoggingFunction} logging function
       */
      module.exports = function (_ref) {
        var _ref$level = _ref.level,
          level = _ref$level === void 0 ? "info" : _ref$level,
          _ref$debug = _ref.debug,
          debug = _ref$debug === void 0 ? false : _ref$debug,
          console = _ref.console;
        var debugFilters = /** @type {FilterFunction[]} */typeof debug === "boolean" ? [function () {
          return debug;
        }] : /** @type {FilterItemTypes[]} */[].concat(debug).map(filterToFunction);
        var loglevel = LogLevel["".concat(level)] || 0;
        /**
         * @param {string} name name of the logger
         * @param {LogTypeEnum} type type of the log entry
         * @param {EXPECTED_ANY[]=} args arguments of the log entry
         * @returns {void}
         */
        var logger = function logger(name, type, args) {
          var labeledArgs = function labeledArgs() {
            if (Array.isArray(args)) {
              if (args.length > 0 && typeof args[0] === "string") {
                return ["[".concat(name, "] ").concat(args[0])].concat(_toConsumableArray(args.slice(1)));
              }
              return ["[".concat(name, "]")].concat(_toConsumableArray(args));
            }
            return [];
          };
          var debug = debugFilters.some(function (f) {
            return f(name);
          });
          switch (type) {
            case LogType.debug:
              if (!debug) return;
              if (typeof console.debug === "function") {
                console.debug.apply(console, _toConsumableArray(labeledArgs()));
              } else {
                console.log.apply(console, _toConsumableArray(labeledArgs()));
              }
              break;
            case LogType.log:
              if (!debug && loglevel > LogLevel.log) return;
              console.log.apply(console, _toConsumableArray(labeledArgs()));
              break;
            case LogType.info:
              if (!debug && loglevel > LogLevel.info) return;
              console.info.apply(console, _toConsumableArray(labeledArgs()));
              break;
            case LogType.warn:
              if (!debug && loglevel > LogLevel.warn) return;
              console.warn.apply(console, _toConsumableArray(labeledArgs()));
              break;
            case LogType.error:
              if (!debug && loglevel > LogLevel.error) return;
              console.error.apply(console, _toConsumableArray(labeledArgs()));
              break;
            case LogType.trace:
              if (!debug) return;
              console.trace();
              break;
            case LogType.groupCollapsed:
              if (!debug && loglevel > LogLevel.log) return;
              if (!debug && loglevel > LogLevel.verbose) {
                if (typeof console.groupCollapsed === "function") {
                  console.groupCollapsed.apply(console, _toConsumableArray(labeledArgs()));
                } else {
                  console.log.apply(console, _toConsumableArray(labeledArgs()));
                }
                break;
              }
            // falls through
            case LogType.group:
              if (!debug && loglevel > LogLevel.log) return;
              if (typeof console.group === "function") {
                console.group.apply(console, _toConsumableArray(labeledArgs()));
              } else {
                console.log.apply(console, _toConsumableArray(labeledArgs()));
              }
              break;
            case LogType.groupEnd:
              if (!debug && loglevel > LogLevel.log) return;
              if (typeof console.groupEnd === "function") {
                console.groupEnd();
              }
              break;
            case LogType.time:
              {
                if (!debug && loglevel > LogLevel.log) return;
                var _args = _slicedToArray(/** @type {[string, number, number]} */args, 3),
                  label = _args[0],
                  start = _args[1],
                  end = _args[2];
                var ms = start * 1000 + end / 1000000;
                var msg = "[".concat(name, "] ").concat(label, ": ").concat(ms, " ms");
                if (typeof console.logTime === "function") {
                  console.logTime(msg);
                } else {
                  console.log(msg);
                }
                break;
              }
            case LogType.profile:
              if (typeof console.profile === "function") {
                console.profile.apply(console, _toConsumableArray(labeledArgs()));
              }
              break;
            case LogType.profileEnd:
              if (typeof console.profileEnd === "function") {
                console.profileEnd.apply(console, _toConsumableArray(labeledArgs()));
              }
              break;
            case LogType.clear:
              if (!debug && loglevel > LogLevel.log) return;
              if (typeof console.clear === "function") {
                console.clear();
              }
              break;
            case LogType.status:
              if (!debug && loglevel > LogLevel.info) return;
              if (typeof console.status === "function") {
                if (!args || args.length === 0) {
                  console.status();
                } else {
                  console.status.apply(console, _toConsumableArray(labeledArgs()));
                }
              } else if (args && args.length !== 0) {
                console.info.apply(console, _toConsumableArray(labeledArgs()));
              }
              break;
            default:
              throw new Error("Unexpected LogType ".concat(type));
          }
        };
        return logger;
      };
      /***/
    }),
    /***/"./node_modules/webpack/lib/logging/runtime.js": (
    /*!*****************************************************!*\
      !*** ./node_modules/webpack/lib/logging/runtime.js ***!
      \*****************************************************/
    /***/
    function (module, __unused_webpack_exports, __nested_webpack_require_27921__) {
      /*
          MIT License http://www.opensource.org/licenses/mit-license.php
          Author Tobias Koppers @sokra
      */
      function _extends() {
        return _extends = Object.assign ? Object.assign.bind() : function (n) {
          for (var e = 1; e < arguments.length; e++) {
            var t = arguments[e];
            for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]);
          }
          return n;
        }, _extends.apply(null, arguments);
      }
      var _require = __nested_webpack_require_27921__(/*! tapable */"./client-src/modules/logger/tapable.js"),
        SyncBailHook = _require.SyncBailHook;
      var _require2 = __nested_webpack_require_27921__(/*! ./Logger */"./node_modules/webpack/lib/logging/Logger.js"),
        Logger = _require2.Logger;
      var createConsoleLogger = __nested_webpack_require_27921__(/*! ./createConsoleLogger */"./node_modules/webpack/lib/logging/createConsoleLogger.js");
      /** @type {createConsoleLogger.LoggerOptions} */
      var currentDefaultLoggerOptions = {
        level: "info",
        debug: false,
        console: console
      };
      var currentDefaultLogger = createConsoleLogger(currentDefaultLoggerOptions);
      /**
       * @param {string} name name of the logger
       * @returns {Logger} a logger
       */
      module.exports.getLogger = function (name) {
        return new Logger(function (type, args) {
          if (module.exports.hooks.log.call(name, type, args) === undefined) {
            currentDefaultLogger(name, type, args);
          }
        }, function (childName) {
          return module.exports.getLogger("".concat(name, "/").concat(childName));
        });
      };
      /**
       * @param {createConsoleLogger.LoggerOptions} options new options, merge with old options
       * @returns {void}
       */
      module.exports.configureDefaultLogger = function (options) {
        _extends(currentDefaultLoggerOptions, options);
        currentDefaultLogger = createConsoleLogger(currentDefaultLoggerOptions);
      };
      module.exports.hooks = {
        log: new SyncBailHook(["origin", "type", "args"])
      };
      /***/
    })
    /******/
  };
  /************************************************************************/
  /******/ // The module cache
  /******/
  var __webpack_module_cache__ = {};
  /******/
  /******/ // The require function
  /******/
  function __nested_webpack_require_30310__(moduleId) {
    /******/ // Check if module is in cache
    /******/var cachedModule = __webpack_module_cache__[moduleId];
    /******/
    if (cachedModule !== undefined) {
      /******/return cachedModule.exports;
      /******/
    }
    /******/ // Create a new module (and put it into the cache)
    /******/
    var module = __webpack_module_cache__[moduleId] = {
      /******/ // no module.id needed
      /******/ // no module.loaded needed
      /******/exports: {}
      /******/
    };
    /******/
    /******/ // Execute the module function
    /******/
    __webpack_modules__[moduleId](module, module.exports, __nested_webpack_require_30310__);
    /******/
    /******/ // Return the exports of the module
    /******/
    return module.exports;
    /******/
  }
  /******/
  /************************************************************************/
  /******/ /* webpack/runtime/define property getters */
  /******/
  !function () {
    /******/ // define getter functions for harmony exports
    /******/__nested_webpack_require_30310__.d = function (exports, definition) {
      /******/for (var key in definition) {
        /******/if (__nested_webpack_require_30310__.o(definition, key) && !__nested_webpack_require_30310__.o(exports, key)) {
          /******/Object.defineProperty(exports, key, {
            enumerable: true,
            get: definition[key]
          });
          /******/
        }
        /******/
      }
      /******/
    };
    /******/
  }();
  /******/
  /******/ /* webpack/runtime/hasOwnProperty shorthand */
  /******/
  !function () {
    /******/__nested_webpack_require_30310__.o = function (obj, prop) {
      return Object.prototype.hasOwnProperty.call(obj, prop);
    };
    /******/
  }();
  /******/
  /******/ /* webpack/runtime/make namespace object */
  /******/
  !function () {
    /******/ // define __esModule on exports
    /******/__nested_webpack_require_30310__.r = function (exports) {
      /******/if (typeof Symbol !== 'undefined' && Symbol.toStringTag) {
        /******/Object.defineProperty(exports, Symbol.toStringTag, {
          value: 'Module'
        });
        /******/
      }
      /******/
      Object.defineProperty(exports, '__esModule', {
        value: true
      });
      /******/
    };
    /******/
  }();
  /******/
  /************************************************************************/
  var __nested_webpack_exports__ = {};
  // This entry needs to be wrapped in an IIFE because it needs to be isolated against other modules in the chunk.
  !function () {
    /*!********************************************!*\
      !*** ./client-src/modules/logger/index.js ***!
      \********************************************/
    __nested_webpack_require_30310__.r(__nested_webpack_exports__);
    /* harmony export */
    __nested_webpack_require_30310__.d(__nested_webpack_exports__, {
      /* harmony export */"default": function () {
        return /* reexport default export from named module */webpack_lib_logging_runtime_js__WEBPACK_IMPORTED_MODULE_0__;
      }
      /* harmony export */
    });
    /* harmony import */
    var webpack_lib_logging_runtime_js__WEBPACK_IMPORTED_MODULE_0__ = __nested_webpack_require_30310__(/*! webpack/lib/logging/runtime.js */"./node_modules/webpack/lib/logging/runtime.js");
  }();
  var __webpack_export_target__ = exports;
  for (var __webpack_i__ in __nested_webpack_exports__) __webpack_export_target__[__webpack_i__] = __nested_webpack_exports__[__webpack_i__];
  if (__nested_webpack_exports__.__esModule) Object.defineProperty(__webpack_export_target__, "__esModule", {
    value: true
  });
  /******/
})();

/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/overlay.js":
/*!******************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/overlay.js ***!
  \******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createOverlay: () => (/* binding */ createOverlay),
/* harmony export */   formatProblem: () => (/* binding */ formatProblem)
/* harmony export */ });
/* harmony import */ var ansi_html_community__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ansi-html-community */ "../node_modules/.pnpm/ansi-html-community@0.0.8/node_modules/ansi-html-community/index.js");
/* harmony import */ var ansi_html_community__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(ansi_html_community__WEBPACK_IMPORTED_MODULE_0__);
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
      _defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
function _defineProperty(e, r, t) {
  return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
// The error overlay is inspired (and mostly copied) from Create React App (https://github.com/facebookincubator/create-react-app)
// They, in turn, got inspired by webpack-hot-middleware (https://github.com/glenjamin/webpack-hot-middleware).

/**
 * @type {(input: string, position: number) => string}
 */
var getCodePoint = String.prototype.codePointAt ? function (input, position) {
  return input.codePointAt(position);
} : function (input, position) {
  return (input.charCodeAt(position) - 0xd800) * 0x400 + input.charCodeAt(position + 1) - 0xdc00 + 0x10000;
};
/**
 * @param {string} macroText
 * @param {RegExp} macroRegExp
 * @param {(input: string) => string} macroReplacer
 * @returns {string}
 */
var replaceUsingRegExp = function replaceUsingRegExp(macroText, macroRegExp, macroReplacer) {
  macroRegExp.lastIndex = 0;
  var replaceMatch = macroRegExp.exec(macroText);
  var replaceResult;
  if (replaceMatch) {
    replaceResult = "";
    var replaceLastIndex = 0;
    do {
      if (replaceLastIndex !== replaceMatch.index) {
        replaceResult += macroText.substring(replaceLastIndex, replaceMatch.index);
      }
      var replaceInput = replaceMatch[0];
      replaceResult += macroReplacer(replaceInput);
      replaceLastIndex = replaceMatch.index + replaceInput.length;
      // eslint-disable-next-line no-cond-assign
    } while (replaceMatch = macroRegExp.exec(macroText));
    if (replaceLastIndex !== macroText.length) {
      replaceResult += macroText.substring(replaceLastIndex);
    }
  } else {
    replaceResult = macroText;
  }
  return replaceResult;
};
var references = {
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&apos;",
  "&": "&amp;"
};
/**
 * @param {string} text text
 * @returns {string}
 */
function encode(text) {
  if (!text) {
    return "";
  }
  return replaceUsingRegExp(text, /[<>'"&]/g, function (input) {
    var result = references[input];
    if (!result) {
      var code = input.length > 1 ? getCodePoint(input, 0) : input.charCodeAt(0);
      result = "&#".concat(code, ";");
    }
    return result;
  });
}
/**
 * @typedef {Object} StateDefinitions
 * @property {{[event: string]: { target: string; actions?: Array<string> }}} [on]
 */
/**
 * @typedef {Object} Options
 * @property {{[state: string]: StateDefinitions}} states
 * @property {object} context;
 * @property {string} initial
 */
/**
 * @typedef {Object} Implementation
 * @property {{[actionName: string]: (ctx: object, event: any) => object}} actions
 */
/**
 * A simplified `createMachine` from `@xstate/fsm` with the following differences:
 *
 *  - the returned machine is technically a "service". No `interpret(machine).start()` is needed.
 *  - the state definition only support `on` and target must be declared with { target: 'nextState', actions: [] } explicitly.
 *  - event passed to `send` must be an object with `type` property.
 *  - actions implementation will be [assign action](https://xstate.js.org/docs/guides/context.html#assign-action) if you return any value.
 *  Do not return anything if you just want to invoke side effect.
 *
 * The goal of this custom function is to avoid installing the entire `'xstate/fsm'` package, while enabling modeling using
 * state machine. You can copy the first parameter into the editor at https://stately.ai/viz to visualize the state machine.
 *
 * @param {Options} options
 * @param {Implementation} implementation
 */
function createMachine(_ref, _ref2) {
  var states = _ref.states,
    context = _ref.context,
    initial = _ref.initial;
  var actions = _ref2.actions;
  var currentState = initial;
  var currentContext = context;
  return {
    send: function send(event) {
      var currentStateOn = states[currentState].on;
      var transitionConfig = currentStateOn && currentStateOn[event.type];
      if (transitionConfig) {
        currentState = transitionConfig.target;
        if (transitionConfig.actions) {
          transitionConfig.actions.forEach(function (actName) {
            var actionImpl = actions[actName];
            var nextContextValue = actionImpl && actionImpl(currentContext, event);
            if (nextContextValue) {
              currentContext = _objectSpread(_objectSpread({}, currentContext), nextContextValue);
            }
          });
        }
      }
    }
  };
}
/**
 * @typedef {Object} ShowOverlayData
 * @property {'warning' | 'error'} level
 * @property {Array<string  | { moduleIdentifier?: string, moduleName?: string, loc?: string, message?: string }>} messages
 * @property {'build' | 'runtime'} messageSource
 */
/**
 * @typedef {Object} CreateOverlayMachineOptions
 * @property {(data: ShowOverlayData) => void} showOverlay
 * @property {() => void} hideOverlay
 */
/**
 * @param {CreateOverlayMachineOptions} options
 */
var createOverlayMachine = function createOverlayMachine(options) {
  var hideOverlay = options.hideOverlay,
    showOverlay = options.showOverlay;
  return createMachine({
    initial: "hidden",
    context: {
      level: "error",
      messages: [],
      messageSource: "build"
    },
    states: {
      hidden: {
        on: {
          BUILD_ERROR: {
            target: "displayBuildError",
            actions: ["setMessages", "showOverlay"]
          },
          RUNTIME_ERROR: {
            target: "displayRuntimeError",
            actions: ["setMessages", "showOverlay"]
          }
        }
      },
      displayBuildError: {
        on: {
          DISMISS: {
            target: "hidden",
            actions: ["dismissMessages", "hideOverlay"]
          },
          BUILD_ERROR: {
            target: "displayBuildError",
            actions: ["appendMessages", "showOverlay"]
          }
        }
      },
      displayRuntimeError: {
        on: {
          DISMISS: {
            target: "hidden",
            actions: ["dismissMessages", "hideOverlay"]
          },
          RUNTIME_ERROR: {
            target: "displayRuntimeError",
            actions: ["appendMessages", "showOverlay"]
          },
          BUILD_ERROR: {
            target: "displayBuildError",
            actions: ["setMessages", "showOverlay"]
          }
        }
      }
    }
  }, {
    actions: {
      dismissMessages: function dismissMessages() {
        return {
          messages: [],
          level: "error",
          messageSource: "build"
        };
      },
      appendMessages: function appendMessages(context, event) {
        return {
          messages: context.messages.concat(event.messages),
          level: event.level || context.level,
          messageSource: event.type === "RUNTIME_ERROR" ? "runtime" : "build"
        };
      },
      setMessages: function setMessages(context, event) {
        return {
          messages: event.messages,
          level: event.level || context.level,
          messageSource: event.type === "RUNTIME_ERROR" ? "runtime" : "build"
        };
      },
      hideOverlay: hideOverlay,
      showOverlay: showOverlay
    }
  });
};
/**
 *
 * @param {Error} error
 */
var parseErrorToStacks = function parseErrorToStacks(error) {
  if (!error || !(error instanceof Error)) {
    throw new Error("parseErrorToStacks expects Error object");
  }
  if (typeof error.stack === "string") {
    return error.stack.split("\n").filter(function (stack) {
      return stack !== "Error: ".concat(error.message);
    });
  }
};
/**
 * @callback ErrorCallback
 * @param {ErrorEvent} error
 * @returns {void}
 */
/**
 * @param {ErrorCallback} callback
 */
var listenToRuntimeError = function listenToRuntimeError(callback) {
  window.addEventListener("error", callback);
  return function cleanup() {
    window.removeEventListener("error", callback);
  };
};
/**
 * @callback UnhandledRejectionCallback
 * @param {PromiseRejectionEvent} rejectionEvent
 * @returns {void}
 */
/**
 * @param {UnhandledRejectionCallback} callback
 */
var listenToUnhandledRejection = function listenToUnhandledRejection(callback) {
  window.addEventListener("unhandledrejection", callback);
  return function cleanup() {
    window.removeEventListener("unhandledrejection", callback);
  };
};
// Styles are inspired by `react-error-overlay`
var msgStyles = {
  error: {
    backgroundColor: "rgba(206, 17, 38, 0.1)",
    color: "#fccfcf"
  },
  warning: {
    backgroundColor: "rgba(251, 245, 180, 0.1)",
    color: "#fbf5b4"
  }
};
var iframeStyle = {
  position: "fixed",
  top: 0,
  left: 0,
  right: 0,
  bottom: 0,
  width: "100vw",
  height: "100vh",
  border: "none",
  "z-index": 9999999999
};
var containerStyle = {
  position: "fixed",
  boxSizing: "border-box",
  left: 0,
  top: 0,
  right: 0,
  bottom: 0,
  width: "100vw",
  height: "100vh",
  fontSize: "large",
  padding: "2rem 2rem 4rem 2rem",
  lineHeight: "1.2",
  whiteSpace: "pre-wrap",
  overflow: "auto",
  backgroundColor: "rgba(0, 0, 0, 0.9)",
  color: "white"
};
var headerStyle = {
  color: "#e83b46",
  fontSize: "2em",
  whiteSpace: "pre-wrap",
  fontFamily: "sans-serif",
  margin: "0 2rem 2rem 0",
  flex: "0 0 auto",
  maxHeight: "50%",
  overflow: "auto"
};
var dismissButtonStyle = {
  color: "#ffffff",
  lineHeight: "1rem",
  fontSize: "1.5rem",
  padding: "1rem",
  cursor: "pointer",
  position: "absolute",
  right: 0,
  top: 0,
  backgroundColor: "transparent",
  border: "none"
};
var msgTypeStyle = {
  color: "#e83b46",
  fontSize: "1.2em",
  marginBottom: "1rem",
  fontFamily: "sans-serif"
};
var msgTextStyle = {
  lineHeight: "1.5",
  fontSize: "1rem",
  fontFamily: "Menlo, Consolas, monospace"
};
// ANSI HTML
var colors = {
  reset: ["transparent", "transparent"],
  black: "181818",
  red: "E36049",
  green: "B3CB74",
  yellow: "FFD080",
  blue: "7CAFC2",
  magenta: "7FACCA",
  cyan: "C3C2EF",
  lightgrey: "EBE7E3",
  darkgrey: "6D7891"
};
ansi_html_community__WEBPACK_IMPORTED_MODULE_0___default().setColors(colors);
/**
 * @param {string} type
 * @param {string  | { file?: string, moduleName?: string, loc?: string, message?: string; stack?: string[] }} item
 * @returns {{ header: string, body: string }}
 */
var formatProblem = function formatProblem(type, item) {
  var header = type === "warning" ? "WARNING" : "ERROR";
  var body = "";
  if (typeof item === "string") {
    body += item;
  } else {
    var file = item.file || "";
    // eslint-disable-next-line no-nested-ternary
    var moduleName = item.moduleName ? item.moduleName.indexOf("!") !== -1 ? "".concat(item.moduleName.replace(/^(\s|\S)*!/, ""), " (").concat(item.moduleName, ")") : "".concat(item.moduleName) : "";
    var loc = item.loc;
    header += "".concat(moduleName || file ? " in ".concat(moduleName ? "".concat(moduleName).concat(file ? " (".concat(file, ")") : "") : file).concat(loc ? " ".concat(loc) : "") : "");
    body += item.message || "";
  }
  if (Array.isArray(item.stack)) {
    item.stack.forEach(function (stack) {
      if (typeof stack === "string") {
        body += "\r\n".concat(stack);
      }
    });
  }
  return {
    header: header,
    body: body
  };
};
/**
 * @typedef {Object} CreateOverlayOptions
 * @property {string | null} trustedTypesPolicyName
 * @property {boolean | (error: Error) => void} [catchRuntimeError]
 */
/**
 *
 * @param {CreateOverlayOptions} options
 */
var createOverlay = function createOverlay(options) {
  /** @type {HTMLIFrameElement | null | undefined} */
  var iframeContainerElement;
  /** @type {HTMLDivElement | null | undefined} */
  var containerElement;
  /** @type {HTMLDivElement | null | undefined} */
  var headerElement;
  /** @type {Array<(element: HTMLDivElement) => void>} */
  var onLoadQueue = [];
  /** @type {TrustedTypePolicy | undefined} */
  var overlayTrustedTypesPolicy;
  /**
   *
   * @param {HTMLElement} element
   * @param {CSSStyleDeclaration} style
   */
  function applyStyle(element, style) {
    Object.keys(style).forEach(function (prop) {
      element.style[prop] = style[prop];
    });
  }
  /**
   * @param {string | null} trustedTypesPolicyName
   */
  function createContainer(trustedTypesPolicyName) {
    // Enable Trusted Types if they are available in the current browser.
    if (window.trustedTypes) {
      overlayTrustedTypesPolicy = window.trustedTypes.createPolicy(trustedTypesPolicyName || "webpack-dev-server#overlay", {
        createHTML: function createHTML(value) {
          return value;
        }
      });
    }
    iframeContainerElement = document.createElement("iframe");
    iframeContainerElement.id = "webpack-dev-server-client-overlay";
    iframeContainerElement.src = "about:blank";
    applyStyle(iframeContainerElement, iframeStyle);
    iframeContainerElement.onload = function () {
      var contentElement = /** @type {Document} */(/** @type {HTMLIFrameElement} */iframeContainerElement.contentDocument).createElement("div");
      containerElement = /** @type {Document} */
      (/** @type {HTMLIFrameElement} */iframeContainerElement.contentDocument).createElement("div");
      contentElement.id = "webpack-dev-server-client-overlay-div";
      applyStyle(contentElement, containerStyle);
      headerElement = document.createElement("div");
      headerElement.innerText = "Compiled with problems:";
      applyStyle(headerElement, headerStyle);
      var closeButtonElement = document.createElement("button");
      applyStyle(closeButtonElement, dismissButtonStyle);
      closeButtonElement.innerText = "×";
      closeButtonElement.ariaLabel = "Dismiss";
      closeButtonElement.addEventListener("click", function () {
        // eslint-disable-next-line no-use-before-define
        overlayService.send({
          type: "DISMISS"
        });
      });
      contentElement.appendChild(headerElement);
      contentElement.appendChild(closeButtonElement);
      contentElement.appendChild(containerElement);
      /** @type {Document} */
      (/** @type {HTMLIFrameElement} */iframeContainerElement.contentDocument).body.appendChild(contentElement);
      onLoadQueue.forEach(function (onLoad) {
        onLoad(/** @type {HTMLDivElement} */contentElement);
      });
      onLoadQueue = [];
      /** @type {HTMLIFrameElement} */
      iframeContainerElement.onload = null;
    };
    document.body.appendChild(iframeContainerElement);
  }
  /**
   * @param {(element: HTMLDivElement) => void} callback
   * @param {string | null} trustedTypesPolicyName
   */
  function ensureOverlayExists(callback, trustedTypesPolicyName) {
    if (containerElement) {
      containerElement.innerHTML = overlayTrustedTypesPolicy ? overlayTrustedTypesPolicy.createHTML("") : "";
      // Everything is ready, call the callback right away.
      callback(containerElement);
      return;
    }
    onLoadQueue.push(callback);
    if (iframeContainerElement) {
      return;
    }
    createContainer(trustedTypesPolicyName);
  }
  // Successful compilation.
  function hide() {
    if (!iframeContainerElement) {
      return;
    }
    // Clean up and reset internal state.
    document.body.removeChild(iframeContainerElement);
    iframeContainerElement = null;
    containerElement = null;
  }
  // Compilation with errors (e.g. syntax error or missing modules).
  /**
   * @param {string} type
   * @param {Array<string  | { moduleIdentifier?: string, moduleName?: string, loc?: string, message?: string }>} messages
   * @param {string | null} trustedTypesPolicyName
   * @param {'build' | 'runtime'} messageSource
   */
  function show(type, messages, trustedTypesPolicyName, messageSource) {
    ensureOverlayExists(function () {
      headerElement.innerText = messageSource === "runtime" ? "Uncaught runtime errors:" : "Compiled with problems:";
      messages.forEach(function (message) {
        var entryElement = document.createElement("div");
        var msgStyle = type === "warning" ? msgStyles.warning : msgStyles.error;
        applyStyle(entryElement, _objectSpread(_objectSpread({}, msgStyle), {}, {
          padding: "1rem 1rem 1.5rem 1rem"
        }));
        var typeElement = document.createElement("div");
        var _formatProblem = formatProblem(type, message),
          header = _formatProblem.header,
          body = _formatProblem.body;
        typeElement.innerText = header;
        applyStyle(typeElement, msgTypeStyle);
        if (message.moduleIdentifier) {
          applyStyle(typeElement, {
            cursor: "pointer"
          });
          // element.dataset not supported in IE
          typeElement.setAttribute("data-can-open", true);
          typeElement.addEventListener("click", function () {
            fetch("/webpack-dev-server/open-editor?fileName=".concat(message.moduleIdentifier));
          });
        }
        // Make it look similar to our terminal.
        var text = ansi_html_community__WEBPACK_IMPORTED_MODULE_0___default()(encode(body));
        var messageTextNode = document.createElement("div");
        applyStyle(messageTextNode, msgTextStyle);
        messageTextNode.innerHTML = overlayTrustedTypesPolicy ? overlayTrustedTypesPolicy.createHTML(text) : text;
        entryElement.appendChild(typeElement);
        entryElement.appendChild(messageTextNode);
        /** @type {HTMLDivElement} */
        containerElement.appendChild(entryElement);
      });
    }, trustedTypesPolicyName);
  }
  var overlayService = createOverlayMachine({
    showOverlay: function showOverlay(_ref3) {
      var _ref3$level = _ref3.level,
        level = _ref3$level === void 0 ? "error" : _ref3$level,
        messages = _ref3.messages,
        messageSource = _ref3.messageSource;
      return show(level, messages, options.trustedTypesPolicyName, messageSource);
    },
    hideOverlay: hide
  });
  if (options.catchRuntimeError) {
    /**
     * @param {Error | undefined} error
     * @param {string} fallbackMessage
     */
    var handleError = function handleError(error, fallbackMessage) {
      var errorObject = error instanceof Error ? error : new Error(error || fallbackMessage);
      var shouldDisplay = typeof options.catchRuntimeError === "function" ? options.catchRuntimeError(errorObject) : true;
      if (shouldDisplay) {
        overlayService.send({
          type: "RUNTIME_ERROR",
          messages: [{
            message: errorObject.message,
            stack: parseErrorToStacks(errorObject)
          }]
        });
      }
    };
    listenToRuntimeError(function (errorEvent) {
      // error property may be empty in older browser like IE
      var error = errorEvent.error,
        message = errorEvent.message;
      if (!error && !message) {
        return;
      }
      // if error stack indicates a React error boundary caught the error, do not show overlay.
      if (error && error.stack && error.stack.includes("invokeGuardedCallbackDev")) {
        return;
      }
      handleError(error, message);
    });
    listenToUnhandledRejection(function (promiseRejectionEvent) {
      var reason = promiseRejectionEvent.reason;
      handleError(reason, "Unknown promise rejection reason");
    });
  }
  return overlayService;
};


/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/progress.js":
/*!*******************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/progress.js ***!
  \*******************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defineProgressElement: () => (/* binding */ defineProgressElement),
/* harmony export */   isProgressSupported: () => (/* binding */ isProgressSupported)
/* harmony export */ });
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
function _classCallCheck(a, n) {
  if (!(a instanceof n)) throw new TypeError("Cannot call a class as a function");
}
function _defineProperties(e, r) {
  for (var t = 0; t < r.length; t++) {
    var o = r[t];
    o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(e, _toPropertyKey(o.key), o);
  }
}
function _createClass(e, r, t) {
  return r && _defineProperties(e.prototype, r), t && _defineProperties(e, t), Object.defineProperty(e, "prototype", {
    writable: !1
  }), e;
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function _callSuper(t, o, e) {
  return o = _getPrototypeOf(o), _possibleConstructorReturn(t, _isNativeReflectConstruct() ? Reflect.construct(o, e || [], _getPrototypeOf(t).constructor) : o.apply(t, e));
}
function _possibleConstructorReturn(t, e) {
  if (e && ("object" == _typeof(e) || "function" == typeof e)) return e;
  if (void 0 !== e) throw new TypeError("Derived constructors may only return object or undefined");
  return _assertThisInitialized(t);
}
function _assertThisInitialized(e) {
  if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
  return e;
}
function _inherits(t, e) {
  if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function");
  t.prototype = Object.create(e && e.prototype, {
    constructor: {
      value: t,
      writable: !0,
      configurable: !0
    }
  }), Object.defineProperty(t, "prototype", {
    writable: !1
  }), e && _setPrototypeOf(t, e);
}
function _wrapNativeSuper(t) {
  var r = "function" == typeof Map ? new Map() : void 0;
  return _wrapNativeSuper = function _wrapNativeSuper(t) {
    if (null === t || !_isNativeFunction(t)) return t;
    if ("function" != typeof t) throw new TypeError("Super expression must either be null or a function");
    if (void 0 !== r) {
      if (r.has(t)) return r.get(t);
      r.set(t, Wrapper);
    }
    function Wrapper() {
      return _construct(t, arguments, _getPrototypeOf(this).constructor);
    }
    return Wrapper.prototype = Object.create(t.prototype, {
      constructor: {
        value: Wrapper,
        enumerable: !1,
        writable: !0,
        configurable: !0
      }
    }), _setPrototypeOf(Wrapper, t);
  }, _wrapNativeSuper(t);
}
function _construct(t, e, r) {
  if (_isNativeReflectConstruct()) return Reflect.construct.apply(null, arguments);
  var o = [null];
  o.push.apply(o, e);
  var p = new (t.bind.apply(t, o))();
  return r && _setPrototypeOf(p, r.prototype), p;
}
function _isNativeReflectConstruct() {
  try {
    var t = !Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function () {}));
  } catch (t) {}
  return (_isNativeReflectConstruct = function _isNativeReflectConstruct() {
    return !!t;
  })();
}
function _isNativeFunction(t) {
  try {
    return -1 !== Function.toString.call(t).indexOf("[native code]");
  } catch (n) {
    return "function" == typeof t;
  }
}
function _setPrototypeOf(t, e) {
  return _setPrototypeOf = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function (t, e) {
    return t.__proto__ = e, t;
  }, _setPrototypeOf(t, e);
}
function _getPrototypeOf(t) {
  return _getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function (t) {
    return t.__proto__ || Object.getPrototypeOf(t);
  }, _getPrototypeOf(t);
}
function _classPrivateMethodInitSpec(e, a) {
  _checkPrivateRedeclaration(e, a), a.add(e);
}
function _checkPrivateRedeclaration(e, t) {
  if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
}
function _assertClassBrand(e, t, n) {
  if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
  throw new TypeError("Private element is not present on this object");
}
function isProgressSupported() {
  return "customElements" in self && !!HTMLElement.prototype.attachShadow;
}
function defineProgressElement() {
  var _WebpackDevServerProgress;
  if (customElements.get("wds-progress")) {
    return;
  }
  var _WebpackDevServerProgress_brand = /*#__PURE__*/new WeakSet();
  var WebpackDevServerProgress = /*#__PURE__*/function (_HTMLElement) {
    function WebpackDevServerProgress() {
      var _this;
      _classCallCheck(this, WebpackDevServerProgress);
      _this = _callSuper(this, WebpackDevServerProgress);
      _classPrivateMethodInitSpec(_this, _WebpackDevServerProgress_brand);
      _this.attachShadow({
        mode: "open"
      });
      _this.maxDashOffset = -219.99078369140625;
      _this.animationTimer = null;
      return _this;
    }
    _inherits(WebpackDevServerProgress, _HTMLElement);
    return _createClass(WebpackDevServerProgress, [{
      key: "connectedCallback",
      value: function connectedCallback() {
        _assertClassBrand(_WebpackDevServerProgress_brand, this, _reset).call(this);
      }
    }, {
      key: "attributeChangedCallback",
      value: function attributeChangedCallback(name, oldValue, newValue) {
        if (name === "progress") {
          _assertClassBrand(_WebpackDevServerProgress_brand, this, _update).call(this, Number(newValue));
        } else if (name === "type") {
          _assertClassBrand(_WebpackDevServerProgress_brand, this, _reset).call(this);
        }
      }
    }], [{
      key: "observedAttributes",
      get: function get() {
        return ["progress", "type"];
      }
    }]);
  }(/*#__PURE__*/_wrapNativeSuper(HTMLElement));
  _WebpackDevServerProgress = WebpackDevServerProgress;
  function _reset() {
    var _this$getAttribute, _Number;
    clearTimeout(this.animationTimer);
    this.animationTimer = null;
    var typeAttr = (_this$getAttribute = this.getAttribute("type")) === null || _this$getAttribute === void 0 ? void 0 : _this$getAttribute.toLowerCase();
    this.type = typeAttr === "circular" ? "circular" : "linear";
    var innerHTML = this.type === "circular" ? _circularTemplate.call(_WebpackDevServerProgress) : _linearTemplate.call(_WebpackDevServerProgress);
    this.shadowRoot.innerHTML = innerHTML;
    this.initialProgress = (_Number = Number(this.getAttribute("progress"))) !== null && _Number !== void 0 ? _Number : 0;
    _assertClassBrand(_WebpackDevServerProgress_brand, this, _update).call(this, this.initialProgress);
  }
  function _circularTemplate() {
    return "\n        <style>\n        :host {\n            width: 200px;\n            height: 200px;\n            position: fixed;\n            right: 5%;\n            top: 5%;\n            transition: opacity .25s ease-in-out;\n            z-index: 2147483645;\n        }\n\n        circle {\n            fill: #282d35;\n        }\n\n        path {\n            fill: rgba(0, 0, 0, 0);\n            stroke: rgb(186, 223, 172);\n            stroke-dasharray: 219.99078369140625;\n            stroke-dashoffset: -219.99078369140625;\n            stroke-width: 10;\n            transform: rotate(90deg) translate(0px, -80px);\n        }\n\n        text {\n            font-family: 'Open Sans', sans-serif;\n            font-size: 18px;\n            fill: #ffffff;\n            dominant-baseline: middle;\n            text-anchor: middle;\n        }\n\n        tspan#percent-super {\n            fill: #bdc3c7;\n            font-size: 0.45em;\n            baseline-shift: 10%;\n        }\n\n        @keyframes fade {\n            0% { opacity: 1; transform: scale(1); }\n            100% { opacity: 0; transform: scale(0); }\n        }\n\n        .disappear {\n            animation: fade 0.3s;\n            animation-fill-mode: forwards;\n            animation-delay: 0.5s;\n        }\n\n        .hidden {\n            display: none;\n        }\n        </style>\n        <svg id=\"progress\" class=\"hidden noselect\" viewBox=\"0 0 80 80\">\n        <circle cx=\"50%\" cy=\"50%\" r=\"35\"></circle>\n        <path d=\"M5,40a35,35 0 1,0 70,0a35,35 0 1,0 -70,0\"></path>\n        <text x=\"50%\" y=\"51%\">\n            <tspan id=\"percent-value\">0</tspan>\n            <tspan id=\"percent-super\">%</tspan>\n        </text>\n        </svg>\n      ";
  }
  function _linearTemplate() {
    return "\n        <style>\n        :host {\n            position: fixed;\n            top: 0;\n            left: 0;\n            height: 4px;\n            width: 100vw;\n            z-index: 2147483645;\n        }\n\n        #bar {\n            width: 0%;\n            height: 4px;\n            background-color: rgb(186, 223, 172);\n        }\n\n        @keyframes fade {\n            0% { opacity: 1; }\n            100% { opacity: 0; }\n        }\n\n        .disappear {\n            animation: fade 0.3s;\n            animation-fill-mode: forwards;\n            animation-delay: 0.5s;\n        }\n\n        .hidden {\n            display: none;\n        }\n        </style>\n        <div id=\"progress\"></div>\n        ";
  }
  function _update(percent) {
    var element = this.shadowRoot.querySelector("#progress");
    if (this.type === "circular") {
      var path = this.shadowRoot.querySelector("path");
      var value = this.shadowRoot.querySelector("#percent-value");
      var offset = (100 - percent) / 100 * this.maxDashOffset;
      path.style.strokeDashoffset = offset;
      value.textContent = percent;
    } else {
      element.style.width = "".concat(percent, "%");
    }
    if (percent >= 100) {
      _assertClassBrand(_WebpackDevServerProgress_brand, this, _hide).call(this);
    } else if (percent > 0) {
      _assertClassBrand(_WebpackDevServerProgress_brand, this, _show).call(this);
    }
  }
  function _show() {
    var element = this.shadowRoot.querySelector("#progress");
    element.classList.remove("hidden");
  }
  function _hide() {
    var _this2 = this;
    var element = this.shadowRoot.querySelector("#progress");
    if (this.type === "circular") {
      element.classList.add("disappear");
      element.addEventListener("animationend", function () {
        element.classList.add("hidden");
        _assertClassBrand(_WebpackDevServerProgress_brand, _this2, _update).call(_this2, 0);
      }, {
        once: true
      });
    } else if (this.type === "linear") {
      element.classList.add("disappear");
      this.animationTimer = setTimeout(function () {
        element.classList.remove("disappear");
        element.classList.add("hidden");
        element.style.width = "0%";
        _this2.animationTimer = null;
      }, 800);
    }
  }
  customElements.define("wds-progress", WebpackDevServerProgress);
}

/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/socket.js":
/*!*****************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/socket.js ***!
  \*****************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   client: () => (/* binding */ client),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _clients_WebSocketClient_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./clients/WebSocketClient.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/clients/WebSocketClient.js");
/* harmony import */ var _utils_log_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils/log.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/log.js");
/* provided dependency */ var __webpack_dev_server_client__ = __webpack_require__(/*! ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/clients/WebSocketClient.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/clients/WebSocketClient.js");
/* global __webpack_dev_server_client__ */


// this WebsocketClient is here as a default fallback, in case the client is not injected
/* eslint-disable camelcase */
var Client =
// eslint-disable-next-line no-nested-ternary
typeof __webpack_dev_server_client__ !== "undefined" ? typeof __webpack_dev_server_client__.default !== "undefined" ? __webpack_dev_server_client__.default : __webpack_dev_server_client__ : _clients_WebSocketClient_js__WEBPACK_IMPORTED_MODULE_0__["default"];
/* eslint-enable camelcase */
var retries = 0;
var maxRetries = 10;
// Initialized client is exported so external consumers can utilize the same instance
// It is mutable to enforce singleton
// eslint-disable-next-line import/no-mutable-exports
var client = null;
var timeout;
/**
 * @param {string} url
 * @param {{ [handler: string]: (data?: any, params?: any) => any }} handlers
 * @param {number} [reconnect]
 */
var socket = function initSocket(url, handlers, reconnect) {
  client = new Client(url);
  client.onOpen(function () {
    retries = 0;
    if (timeout) {
      clearTimeout(timeout);
    }
    if (typeof reconnect !== "undefined") {
      maxRetries = reconnect;
    }
  });
  client.onClose(function () {
    if (retries === 0) {
      handlers.close();
    }
    // Try to reconnect.
    client = null;
    // After 10 retries stop trying, to prevent logspam.
    if (retries < maxRetries) {
      // Exponentially increase timeout to reconnect.
      // Respectfully copied from the package `got`.
      // eslint-disable-next-line no-restricted-properties
      var retryInMs = 1000 * Math.pow(2, retries) + Math.random() * 100;
      retries += 1;
      _utils_log_js__WEBPACK_IMPORTED_MODULE_1__.log.info("Trying to reconnect...");
      timeout = setTimeout(function () {
        socket(url, handlers, reconnect);
      }, retryInMs);
    }
  });
  client.onMessage(
  /**
   * @param {any} data
   */
  function (data) {
    var message = JSON.parse(data);
    if (handlers[message.type]) {
      handlers[message.type](message.data, message.params);
    }
  });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (socket);

/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/log.js":
/*!********************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/log.js ***!
  \********************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   log: () => (/* binding */ log),
/* harmony export */   setLogLevel: () => (/* binding */ setLogLevel)
/* harmony export */ });
/* harmony import */ var _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../modules/logger/index.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/modules/logger/index.js");
/* harmony import */ var _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0__);

var name = "webpack-dev-server";
// default level is set on the client side, so it does not need
// to be set by the CLI or API
var defaultLevel = "info";
// options new options, merge with old options
/**
 * @param {false | true | "none" | "error" | "warn" | "info" | "log" | "verbose"} level
 * @returns {void}
 */
function setLogLevel(level) {
  _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0___default().configureDefaultLogger({
    level: level
  });
}
setLogLevel(defaultLevel);
var log = _modules_logger_index_js__WEBPACK_IMPORTED_MODULE_0___default().getLogger(name);


/***/ }),

/***/ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/sendMessage.js":
/*!****************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/sendMessage.js ***!
  \****************************************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* global __resourceQuery WorkerGlobalScope */
// Send messages to the outside, so plugins can consume it.
/**
 * @param {string} type
 * @param {any} [data]
 */
function sendMsg(type, data) {
  if (typeof self !== "undefined" && (typeof WorkerGlobalScope === "undefined" || !(self instanceof WorkerGlobalScope))) {
    self.postMessage({
      type: "webpack".concat(type),
      data: data
    }, "*");
  }
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (sendMsg);

/***/ }),

/***/ "../node_modules/.pnpm/webpack@5.101.0_webpack-cli@6.0.1/node_modules/webpack/hot/emitter.js":
/*!***************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack@5.101.0_webpack-cli@6.0.1/node_modules/webpack/hot/emitter.js ***!
  \***************************************************************************************************/
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {



var EventEmitter = __webpack_require__(/*! events */ "../node_modules/.pnpm/events@3.3.0/node_modules/events/events.js");
module.exports = new EventEmitter();

/***/ }),

/***/ "../node_modules/.pnpm/webpack@5.101.0_webpack-cli@6.0.1/node_modules/webpack/hot/log.js":
/*!***********************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack@5.101.0_webpack-cli@6.0.1/node_modules/webpack/hot/log.js ***!
  \***********************************************************************************************/
/***/ ((module) => {



/** @typedef {"info" | "warning" | "error"} LogLevel */
/** @type {LogLevel} */
var logLevel = "info";
function dummy() {}
/**
 * @param {LogLevel} level log level
 * @returns {boolean} true, if should log
 */
function shouldLog(level) {
  var shouldLog = logLevel === "info" && level === "info" || ["info", "warning"].indexOf(logLevel) >= 0 && level === "warning" || ["info", "warning", "error"].indexOf(logLevel) >= 0 && level === "error";
  return shouldLog;
}
/**
 * @param {(msg?: string) => void} logFn log function
 * @returns {(level: LogLevel, msg?: string) => void} function that logs when log level is sufficient
 */
function logGroup(logFn) {
  return function (level, msg) {
    if (shouldLog(level)) {
      logFn(msg);
    }
  };
}
/**
 * @param {LogLevel} level log level
 * @param {string|Error} msg message
 */
module.exports = function (level, msg) {
  if (shouldLog(level)) {
    if (level === "info") {
      console.log(msg);
    } else if (level === "warning") {
      console.warn(msg);
    } else if (level === "error") {
      console.error(msg);
    }
  }
};
/**
 * @param {Error} err error
 * @returns {string} formatted error
 */
module.exports.formatError = function (err) {
  var message = err.message;
  var stack = err.stack;
  if (!stack) {
    return message;
  } else if (stack.indexOf(message) < 0) {
    return message + "\n" + stack;
  }
  return stack;
};
var group = console.group || dummy;
var groupCollapsed = console.groupCollapsed || dummy;
var groupEnd = console.groupEnd || dummy;
module.exports.group = logGroup(group);
module.exports.groupCollapsed = logGroup(groupCollapsed);
module.exports.groupEnd = logGroup(groupEnd);
/**
 * @param {LogLevel} level log level
 */
module.exports.setLogLevel = function (level) {
  logLevel = level;
};

/***/ }),

/***/ "./src/lib/commercial-features.ts":
/*!****************************************!*\
  !*** ./src/lib/commercial-features.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   commercialFeatures: () => (/* binding */ commercialFeatures)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
/* harmony import */ var _detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


/**
 * Log the reason why adverts are disabled
 *
 * @param trueConditions - normally true conditions, log if false
 * @param falseConditions - normally false conditions, log if true
 */
function adsDisabledLogger(trueConditions, falseConditions) {
  var noAdsLog = (condition, value) => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Adverts are not shown because ".concat(condition, " = ").concat(String(value)));
  for (var [condition, value] of Object.entries(trueConditions)) {
    if (!value) noAdsLog(condition, value);
  }
  for (var [_condition, _value] of Object.entries(falseConditions)) {
    if (_value) noAdsLog(_condition, _value);
  }
}
/**
 * Ad free cookie helpers
 */
var AD_FREE_USER_COOKIE = 'GU_AF1';
var getAdFreeCookie = () => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
  name: AD_FREE_USER_COOKIE
});
var adFreeDataIsPresent = () => {
  var cookieVal = getAdFreeCookie();
  if (!cookieVal) return false;
  return !Number.isNaN(parseInt(cookieVal, 10));
};
/**
 * Determine whether current browser is a version of Internet Explorer
 */
var isInternetExplorer = () => {
  var _navigator$userAgent$;
  return !!((_navigator$userAgent$ = navigator.userAgent.match(/MSIE|Trident/g)) !== null && _navigator$userAgent$ !== void 0 && _navigator$userAgent$.length);
};
var DIGITAL_SUBSCRIBER_COOKIE = 'gu_digital_subscriber';
var isDigitalSubscriber = () => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
  name: DIGITAL_SUBSCRIBER_COOKIE
}) === 'true';
var isAdFreeUser = () => isDigitalSubscriber() || adFreeDataIsPresent();
var isUserPrefsAdsOff = () => _guardian_libs__WEBPACK_IMPORTED_MODULE_2__.storage.local.get("gu.prefs.switch.adverts") === false;
// Having a constructor means we can easily re-instantiate the object in a test
class CommercialFeatures {
  constructor() {
    _defineProperty(this, "shouldLoadGoogletag", void 0);
    _defineProperty(this, "isSecureContact", void 0);
    _defineProperty(this, "articleBodyAdverts", void 0);
    _defineProperty(this, "carrotTrafficDriver", void 0);
    _defineProperty(this, "highMerch", void 0);
    _defineProperty(this, "thirdPartyTags", void 0);
    _defineProperty(this, "commentAdverts", void 0);
    _defineProperty(this, "liveblogAdverts", void 0);
    _defineProperty(this, "adFree", void 0);
    _defineProperty(this, "comscore", void 0);
    _defineProperty(this, "youtubeAdvertising", void 0);
    _defineProperty(this, "footballFixturesAdverts", void 0);
    // this is used for SpeedCurve tests
    var noadsUrl = /[#&]noads(&.*)?$/.test(window.location.hash);
    var forceAdFree = /[#&]noadsaf(&.*)?$/.test(window.location.hash);
    var forceAds = /[?&]forceads(&.*)?$/.test(window.location.search);
    var externalAdvertising = !noadsUrl && !isUserPrefsAdsOff();
    var sensitiveContent = window.guardian.config.page.shouldHideAdverts || window.guardian.config.page.section === 'childrens-books-site';
    var isMinuteArticle = window.guardian.config.page.isMinuteArticle;
    var isArticle = window.guardian.config.page.contentType === 'Article';
    var isInteractive = window.guardian.config.page.contentType === 'Interactive';
    var isLiveBlog = window.guardian.config.page.isLiveBlog;
    var isHosted = window.guardian.config.page.isHosted;
    var isIdentityPage = window.guardian.config.page.contentType === 'Identity' || window.guardian.config.page.section === 'identity'; // needed for pages under profile.* subdomain
    var switches = window.guardian.config.switches;
    var isWidePage = (0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__.getCurrentBreakpoint)() === 'wide';
    var newRecipeDesign = window.guardian.config.page.showNewRecipeDesign;
    var isUnsupportedBrowser = isInternetExplorer();
    // Detect presence of space for football-right ad slot
    var {
      pageId
    } = window.guardian.config.page;
    var isFootballPage = pageId.startsWith('football/');
    var isPageWithRightAdSpace = pageId.endsWith('/fixtures') || pageId.endsWith('/live') || pageId.endsWith('/results') || pageId.endsWith('/tables') || pageId.endsWith('/table');
    this.footballFixturesAdverts = isFootballPage && isPageWithRightAdSpace;
    this.isSecureContact = ['help/ng-interactive/2017/mar/17/contact-the-guardian-securely', 'help/2016/sep/19/how-to-contact-the-guardian-securely'].includes(window.guardian.config.page.pageId);
    // Feature switches
    this.adFree = !!forceAdFree || isAdFreeUser();
    this.youtubeAdvertising = !this.adFree && !sensitiveContent;
    var shouldLoadGoogletagTrueConditions = {
      'switches.shouldLoadGoogletag': !!switches.shouldLoadGoogletag,
      externalAdvertising
    };
    var shouldLoadGoogletagFalseConditions = {
      sensitiveContent,
      isIdentityPage,
      adFree: this.adFree,
      isUnsupportedBrowser
    };
    this.shouldLoadGoogletag = forceAds || Object.values(shouldLoadGoogletagTrueConditions).every(Boolean) && !Object.values(shouldLoadGoogletagFalseConditions).some(Boolean);
    if (!this.shouldLoadGoogletag) {
      adsDisabledLogger(shouldLoadGoogletagTrueConditions, shouldLoadGoogletagFalseConditions);
    }
    var articleBodyAdvertsTrueConditions = {
      isArticle
    };
    var articleBodyAdvertsFalseConditions = {
      isMinuteArticle,
      isLiveBlog: !!isLiveBlog,
      isHosted,
      newRecipeDesign: !!newRecipeDesign
    };
    this.articleBodyAdverts = this.shouldLoadGoogletag && !this.adFree && Object.values(articleBodyAdvertsTrueConditions).every(Boolean) && !Object.values(articleBodyAdvertsFalseConditions).some(Boolean);
    if (isArticle && !this.articleBodyAdverts) {
      // Log why article adverts are disabled
      adsDisabledLogger(articleBodyAdvertsTrueConditions, articleBodyAdvertsFalseConditions);
    }
    this.carrotTrafficDriver = !this.adFree && this.articleBodyAdverts && !window.guardian.config.page.isPaidContent;
    this.highMerch = this.shouldLoadGoogletag && !this.adFree && !isMinuteArticle && !isHosted && !isInteractive && !window.guardian.config.page.isFront && !window.guardian.config.isDotcomRendering && !newRecipeDesign;
    this.thirdPartyTags = !this.adFree && externalAdvertising && !isIdentityPage && !this.isSecureContact;
    this.commentAdverts = this.shouldLoadGoogletag && !this.adFree && !isMinuteArticle && !!window.guardian.config.switches.enableDiscussionSwitch && window.guardian.config.page.commentable && (!isLiveBlog || isWidePage);
    this.liveblogAdverts = !!isLiveBlog && this.shouldLoadGoogletag && !this.adFree;
    this.comscore = !!window.guardian.config.switches.comscore && !isIdentityPage && !this.isSecureContact;
  }
}
var commercialFeatures = new CommercialFeatures();

/***/ }),

/***/ "./src/lib/detect/detect-breakpoint.ts":
/*!*********************************************!*\
  !*** ./src/lib/detect/detect-breakpoint.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getBreakpoint: () => (/* binding */ getBreakpoint),
/* harmony export */   getCurrentBreakpoint: () => (/* binding */ getCurrentBreakpoint),
/* harmony export */   getCurrentTweakpoint: () => (/* binding */ getCurrentTweakpoint),
/* harmony export */   getTweakpoint: () => (/* binding */ getTweakpoint),
/* harmony export */   hasCrossedBreakpoint: () => (/* binding */ hasCrossedBreakpoint),
/* harmony export */   matchesBreakpoints: () => (/* binding */ matchesBreakpoints)
/* harmony export */ });
/* harmony import */ var _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/source/foundations */ "../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js");
/* harmony import */ var _detect_viewport__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./detect-viewport */ "./src/lib/detect/detect-viewport.ts");


var breakpoints = {
  mobile: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['mobile'],
  tablet: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['tablet'],
  desktop: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['desktop'],
  wide: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['wide']
};
var isSourceBreakpoint = point => point in _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints;
var isBreakpoint = point => point in breakpoints;
var tweakpoints = {
  mobileMedium: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['mobileMedium'],
  mobileLandscape: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['mobileLandscape'],
  phablet: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['phablet'],
  leftCol: _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints['leftCol']
};
var sourceBreakpointNames = ['wide', 'leftCol', 'desktop', 'tablet', 'phablet', 'mobileLandscape', 'mobileMedium', 'mobile'];
var currentBreakpoint;
var currentTweakpoint;
// Get the closest breakpoint to a given width
var getPoint = (includeTweakpoint, width) => {
  var point = sourceBreakpointNames.find(point => {
    if (isBreakpoint(point)) {
      return width >= breakpoints[point];
    } else if (includeTweakpoint) {
      return width >= tweakpoints[point];
    }
    return false;
  });
  // This assertion is captured in tests
  return point !== null && point !== void 0 ? point : 'mobile';
};
var getBreakpoint = width => getPoint(false, width);
var getTweakpoint = width => getPoint(true, width);
var getCurrentBreakpoint = () => currentBreakpoint !== null && currentBreakpoint !== void 0 ? currentBreakpoint : getBreakpoint((0,_detect_viewport__WEBPACK_IMPORTED_MODULE_1__.getViewport)().width);
var getCurrentTweakpoint = () => currentTweakpoint !== null && currentTweakpoint !== void 0 ? currentTweakpoint : getTweakpoint((0,_detect_viewport__WEBPACK_IMPORTED_MODULE_1__.getViewport)().width);
// create a media query string from a min and max breakpoint
var getMediaQuery = _ref => {
  var {
    min,
    max
  } = _ref;
  var minWidth = min ? typeof min === 'number' ? min : _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints[min] : null;
  var maxWidth = max ? typeof max === 'number' ? max : _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints[max] - 1 : null;
  var minQuery = minWidth ? "(min-width: ".concat(minWidth, "px)") : null;
  var maxQuery = maxWidth ? "(max-width: ".concat(maxWidth, "px)") : null;
  return [minQuery, maxQuery].filter(Boolean).join(' and ');
};
var updateBreakpoint = breakpoint => {
  currentTweakpoint = breakpoint;
  currentBreakpoint = getPoint(false, _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints[currentTweakpoint]);
};
/**
 * We use media queries to keep track of what breakpoint we're in. This is to avoid
 * using getViewPort, which utilizes window.innerWidth which causes a reflow.
 */
var initMediaQueryListeners = () => {
  [...sourceBreakpointNames].reverse().forEach((bp, index, bps) => {
    if (isSourceBreakpoint(bp)) {
      var nextBp = bps[index + 1];
      var mql = window.matchMedia(getMediaQuery({
        min: bp,
        max: nextBp ? _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_0__.breakpoints[nextBp] : undefined
      }));
      var listener = mql => mql.matches && updateBreakpoint(bp);
      //addListener is a deprecated method but Safari 13 and earlier versions do not support the new
      //method, so we need it here as a fallback to load ads on those versions of Safari
      if (typeof mql.addEventListener !== 'undefined') {
        mql.addEventListener('change', listener);
      } else if (typeof mql.addListener !== 'undefined') {
        mql.addListener(listener);
      }
      listener(mql);
    }
  });
};
var matchesBreakpoints = _ref2 => {
  var {
    min,
    max
  } = _ref2;
  return window.matchMedia(getMediaQuery({
    min,
    max
  })).matches;
};
var hasCrossedBreakpoint = includeTweakpoint => {
  var was = includeTweakpoint ? getCurrentTweakpoint() : getCurrentBreakpoint();
  return callback => {
    var is = includeTweakpoint ? getCurrentTweakpoint() : getCurrentBreakpoint();
    if (is !== was) {
      callback(is, was);
      was = is;
    }
  };
};
initMediaQueryListeners();


/***/ }),

/***/ "./src/lib/detect/detect-viewport.ts":
/*!*******************************************!*\
  !*** ./src/lib/detect/detect-viewport.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getViewport: () => (/* binding */ getViewport)
/* harmony export */ });
/**
 * Expects `window.innerWidth` or `document.body.clientWidth` to return
 * a value
 *
 * @returns
 */
var getViewport = () => {
  return {
    width: window.innerWidth || document.body.clientWidth || 0,
    height: window.innerHeight || document.body.clientHeight || 0
  };
};


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = __webpack_modules__;
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/ensure chunk */
/******/ 	(() => {
/******/ 		__webpack_require__.f = {};
/******/ 		// This file contains only the entry chunk.
/******/ 		// The chunk loading function for additional chunks
/******/ 		__webpack_require__.e = (chunkId) => {
/******/ 			return Promise.all(Object.keys(__webpack_require__.f).reduce((promises, key) => {
/******/ 				__webpack_require__.f[key](chunkId, promises);
/******/ 				return promises;
/******/ 			}, []));
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/get javascript chunk filename */
/******/ 	(() => {
/******/ 		// This function allow to reference async chunks
/******/ 		__webpack_require__.u = (chunkId) => {
/******/ 			// return url for filenames based on template
/******/ 			return "graun." + chunkId + ".commercial.js";
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/getFullHash */
/******/ 	(() => {
/******/ 		__webpack_require__.h = () => ("b5011ca5f2b27c84e520")
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/global */
/******/ 	(() => {
/******/ 		__webpack_require__.g = (function() {
/******/ 			if (typeof globalThis === 'object') return globalThis;
/******/ 			try {
/******/ 				return this || new Function('return this')();
/******/ 			} catch (e) {
/******/ 				if (typeof window === 'object') return window;
/******/ 			}
/******/ 		})();
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/load script */
/******/ 	(() => {
/******/ 		var inProgress = {};
/******/ 		var dataWebpackPrefix = "@guardian/commercial-bundle:";
/******/ 		// loadScript function to load a script via script tag
/******/ 		__webpack_require__.l = (url, done, key, chunkId) => {
/******/ 			if(inProgress[url]) { inProgress[url].push(done); return; }
/******/ 			var script, needAttach;
/******/ 			if(key !== undefined) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				for(var i = 0; i < scripts.length; i++) {
/******/ 					var s = scripts[i];
/******/ 					if(s.getAttribute("src") == url || s.getAttribute("data-webpack") == dataWebpackPrefix + key) { script = s; break; }
/******/ 				}
/******/ 			}
/******/ 			if(!script) {
/******/ 				needAttach = true;
/******/ 				script = document.createElement('script');
/******/ 		
/******/ 				script.charset = 'utf-8';
/******/ 				script.timeout = 120;
/******/ 				if (__webpack_require__.nc) {
/******/ 					script.setAttribute("nonce", __webpack_require__.nc);
/******/ 				}
/******/ 				script.setAttribute("data-webpack", dataWebpackPrefix + key);
/******/ 		
/******/ 				script.src = url;
/******/ 			}
/******/ 			inProgress[url] = [done];
/******/ 			var onScriptComplete = (prev, event) => {
/******/ 				// avoid mem leaks in IE.
/******/ 				script.onerror = script.onload = null;
/******/ 				clearTimeout(timeout);
/******/ 				var doneFns = inProgress[url];
/******/ 				delete inProgress[url];
/******/ 				script.parentNode && script.parentNode.removeChild(script);
/******/ 				doneFns && doneFns.forEach((fn) => (fn(event)));
/******/ 				if(prev) return prev(event);
/******/ 			}
/******/ 			var timeout = setTimeout(onScriptComplete.bind(null, undefined, { type: 'timeout', target: script }), 120000);
/******/ 			script.onerror = onScriptComplete.bind(null, script.onerror);
/******/ 			script.onload = onScriptComplete.bind(null, script.onload);
/******/ 			needAttach && document.head.appendChild(script);
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/publicPath */
/******/ 	(() => {
/******/ 		var scriptUrl;
/******/ 		if (__webpack_require__.g.importScripts) scriptUrl = __webpack_require__.g.location + "";
/******/ 		var document = __webpack_require__.g.document;
/******/ 		if (!scriptUrl && document) {
/******/ 			if (document.currentScript && document.currentScript.tagName.toUpperCase() === 'SCRIPT')
/******/ 				scriptUrl = document.currentScript.src;
/******/ 			if (!scriptUrl) {
/******/ 				var scripts = document.getElementsByTagName("script");
/******/ 				if(scripts.length) {
/******/ 					var i = scripts.length - 1;
/******/ 					while (i > -1 && (!scriptUrl || !/^http(s?):/.test(scriptUrl))) scriptUrl = scripts[i--].src;
/******/ 				}
/******/ 			}
/******/ 		}
/******/ 		// When supporting browsers where an automatic publicPath is not supported you must specify an output.publicPath manually via configuration
/******/ 		// or pass an empty string ("") and set the __webpack_public_path__ variable from your code to use your own logic.
/******/ 		if (!scriptUrl) throw new Error("Automatic publicPath is not supported in this browser");
/******/ 		scriptUrl = scriptUrl.replace(/^blob:/, "").replace(/#.*$/, "").replace(/\?.*$/, "").replace(/\/[^\/]+$/, "/");
/******/ 		__webpack_require__.p = scriptUrl;
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/jsonp chunk loading */
/******/ 	(() => {
/******/ 		// no baseURI
/******/ 		
/******/ 		// object to store loaded and loading chunks
/******/ 		// undefined = chunk not loaded, null = chunk preloaded/prefetched
/******/ 		// [resolve, reject, Promise] = chunk loading, 0 = chunk loaded
/******/ 		var installedChunks = {
/******/ 			"commercial-standalone": 0
/******/ 		};
/******/ 		
/******/ 		__webpack_require__.f.j = (chunkId, promises) => {
/******/ 				// JSONP chunk loading for javascript
/******/ 				var installedChunkData = __webpack_require__.o(installedChunks, chunkId) ? installedChunks[chunkId] : undefined;
/******/ 				if(installedChunkData !== 0) { // 0 means "already installed".
/******/ 		
/******/ 					// a Promise means "currently loading".
/******/ 					if(installedChunkData) {
/******/ 						promises.push(installedChunkData[2]);
/******/ 					} else {
/******/ 						if(true) { // all chunks have JS
/******/ 							// setup Promise in chunk cache
/******/ 							var promise = new Promise((resolve, reject) => (installedChunkData = installedChunks[chunkId] = [resolve, reject]));
/******/ 							promises.push(installedChunkData[2] = promise);
/******/ 		
/******/ 							// start chunk loading
/******/ 							var url = __webpack_require__.p + __webpack_require__.u(chunkId);
/******/ 							// create error before stack unwound to get useful stacktrace later
/******/ 							var error = new Error();
/******/ 							var loadingEnded = (event) => {
/******/ 								if(__webpack_require__.o(installedChunks, chunkId)) {
/******/ 									installedChunkData = installedChunks[chunkId];
/******/ 									if(installedChunkData !== 0) installedChunks[chunkId] = undefined;
/******/ 									if(installedChunkData) {
/******/ 										var errorType = event && (event.type === 'load' ? 'missing' : event.type);
/******/ 										var realSrc = event && event.target && event.target.src;
/******/ 										error.message = 'Loading chunk ' + chunkId + ' failed.\n(' + errorType + ': ' + realSrc + ')';
/******/ 										error.name = 'ChunkLoadError';
/******/ 										error.type = errorType;
/******/ 										error.request = realSrc;
/******/ 										installedChunkData[1](error);
/******/ 									}
/******/ 								}
/******/ 							};
/******/ 							__webpack_require__.l(url, loadingEnded, "chunk-" + chunkId, chunkId);
/******/ 						}
/******/ 					}
/******/ 				}
/******/ 		};
/******/ 		
/******/ 		// no prefetching
/******/ 		
/******/ 		// no preloaded
/******/ 		
/******/ 		// no HMR
/******/ 		
/******/ 		// no HMR manifest
/******/ 		
/******/ 		// no on chunks loaded
/******/ 		
/******/ 		// install a JSONP callback for chunk loading
/******/ 		var webpackJsonpCallback = (parentChunkLoadingFunction, data) => {
/******/ 			var [chunkIds, moreModules, runtime] = data;
/******/ 			// add "moreModules" to the modules object,
/******/ 			// then flag all "chunkIds" as loaded and fire callback
/******/ 			var moduleId, chunkId, i = 0;
/******/ 			if(chunkIds.some((id) => (installedChunks[id] !== 0))) {
/******/ 				for(moduleId in moreModules) {
/******/ 					if(__webpack_require__.o(moreModules, moduleId)) {
/******/ 						__webpack_require__.m[moduleId] = moreModules[moduleId];
/******/ 					}
/******/ 				}
/******/ 				if(runtime) var result = runtime(__webpack_require__);
/******/ 			}
/******/ 			if(parentChunkLoadingFunction) parentChunkLoadingFunction(data);
/******/ 			for(;i < chunkIds.length; i++) {
/******/ 				chunkId = chunkIds[i];
/******/ 				if(__webpack_require__.o(installedChunks, chunkId) && installedChunks[chunkId]) {
/******/ 					installedChunks[chunkId][0]();
/******/ 				}
/******/ 				installedChunks[chunkId] = 0;
/******/ 			}
/******/ 		
/******/ 		}
/******/ 		
/******/ 		var chunkLoadingGlobal = self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || [];
/******/ 		chunkLoadingGlobal.forEach(webpackJsonpCallback.bind(null, 0));
/******/ 		chunkLoadingGlobal.push = webpackJsonpCallback.bind(null, chunkLoadingGlobal.push.bind(chunkLoadingGlobal));
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be isolated against other entry modules.
(() => {
var __webpack_exports__ = {};
/*!*******************************************************************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/index.js?protocol=ws%3A&hostname=0.0.0.0&port=3031&pathname=%2Fws&logging=info&overlay=true&reconnect=10&hot=false&live-reload=true ***!
  \*******************************************************************************************************************************************************************************************************************************************************************/
var __resourceQuery = "?protocol=ws%3A&hostname=0.0.0.0&port=3031&pathname=%2Fws&logging=info&overlay=true&reconnect=10&hot=false&live-reload=true";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   createSocketURL: () => (/* binding */ createSocketURL),
/* harmony export */   getCurrentScriptSource: () => (/* binding */ getCurrentScriptSource),
/* harmony export */   parseURL: () => (/* binding */ parseURL)
/* harmony export */ });
/* harmony import */ var webpack_hot_log_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! webpack/hot/log.js */ "../node_modules/.pnpm/webpack@5.101.0_webpack-cli@6.0.1/node_modules/webpack/hot/log.js");
/* harmony import */ var webpack_hot_log_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(webpack_hot_log_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var webpack_hot_emitter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! webpack/hot/emitter.js */ "../node_modules/.pnpm/webpack@5.101.0_webpack-cli@6.0.1/node_modules/webpack/hot/emitter.js");
/* harmony import */ var webpack_hot_emitter_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(webpack_hot_emitter_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _socket_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./socket.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/socket.js");
/* harmony import */ var _overlay_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./overlay.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/overlay.js");
/* harmony import */ var _utils_log_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/log.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/log.js");
/* harmony import */ var _utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./utils/sendMessage.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/utils/sendMessage.js");
/* harmony import */ var _progress_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./progress.js */ "../node_modules/.pnpm/webpack-dev-server@5.2.2_webpack-cli@6.0.1_webpack@5.101.0/node_modules/webpack-dev-server/client/progress.js");
function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
      _defineProperty(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
function _defineProperty(e, r, t) {
  return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}
function _toPropertyKey(t) {
  var i = _toPrimitive(t, "string");
  return "symbol" == _typeof(i) ? i : i + "";
}
function _toPrimitive(t, r) {
  if ("object" != _typeof(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != _typeof(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}
/* global __resourceQuery, __webpack_hash__ */
/// <reference types="webpack/module" />







/**
 * @typedef {Object} OverlayOptions
 * @property {boolean | (error: Error) => boolean} [warnings]
 * @property {boolean | (error: Error) => boolean} [errors]
 * @property {boolean | (error: Error) => boolean} [runtimeErrors]
 * @property {string} [trustedTypesPolicyName]
 */
/**
 * @typedef {Object} Options
 * @property {boolean} hot
 * @property {boolean} liveReload
 * @property {boolean} progress
 * @property {boolean | OverlayOptions} overlay
 * @property {string} [logging]
 * @property {number} [reconnect]
 */
/**
 * @typedef {Object} Status
 * @property {boolean} isUnloading
 * @property {string} currentHash
 * @property {string} [previousHash]
 */
/**
 * @param {boolean | { warnings?: boolean | string; errors?: boolean | string; runtimeErrors?: boolean | string; }} overlayOptions
 */
var decodeOverlayOptions = function decodeOverlayOptions(overlayOptions) {
  if (_typeof(overlayOptions) === "object") {
    ["warnings", "errors", "runtimeErrors"].forEach(function (property) {
      if (typeof overlayOptions[property] === "string") {
        var overlayFilterFunctionString = decodeURIComponent(overlayOptions[property]);
        // eslint-disable-next-line no-new-func
        overlayOptions[property] = new Function("message", "var callback = ".concat(overlayFilterFunctionString, "\n        return callback(message)"));
      }
    });
  }
};
/**
 * @type {Status}
 */
var status = {
  isUnloading: false,
  // eslint-disable-next-line camelcase
  currentHash: __webpack_require__.h()
};
/**
 * @returns {string}
 */
var getCurrentScriptSource = function getCurrentScriptSource() {
  // `document.currentScript` is the most accurate way to find the current script,
  // but is not supported in all browsers.
  if (document.currentScript) {
    return document.currentScript.getAttribute("src");
  }
  // Fallback to getting all scripts running in the document.
  var scriptElements = document.scripts || [];
  var scriptElementsWithSrc = Array.prototype.filter.call(scriptElements, function (element) {
    return element.getAttribute("src");
  });
  if (scriptElementsWithSrc.length > 0) {
    var currentScript = scriptElementsWithSrc[scriptElementsWithSrc.length - 1];
    return currentScript.getAttribute("src");
  }
  // Fail as there was no script to use.
  throw new Error("[webpack-dev-server] Failed to get current script source.");
};
/**
 * @param {string} resourceQuery
 * @returns {{ [key: string]: string | boolean }}
 */
var parseURL = function parseURL(resourceQuery) {
  /** @type {{ [key: string]: string }} */
  var result = {};
  if (typeof resourceQuery === "string" && resourceQuery !== "") {
    var searchParams = resourceQuery.slice(1).split("&");
    for (var i = 0; i < searchParams.length; i++) {
      var pair = searchParams[i].split("=");
      result[pair[0]] = decodeURIComponent(pair[1]);
    }
  } else {
    // Else, get the url from the <script> this file was called with.
    var scriptSource = getCurrentScriptSource();
    var scriptSourceURL;
    try {
      // The placeholder `baseURL` with `window.location.href`,
      // is to allow parsing of path-relative or protocol-relative URLs,
      // and will have no effect if `scriptSource` is a fully valid URL.
      scriptSourceURL = new URL(scriptSource, self.location.href);
    } catch (error) {
      // URL parsing failed, do nothing.
      // We will still proceed to see if we can recover using `resourceQuery`
    }
    if (scriptSourceURL) {
      result = scriptSourceURL;
      result.fromCurrentScript = true;
    }
  }
  return result;
};
var parsedResourceQuery = parseURL(__resourceQuery);
var enabledFeatures = {
  "Hot Module Replacement": false,
  "Live Reloading": false,
  Progress: false,
  Overlay: false
};
/** @type {Options} */
var options = {
  hot: false,
  liveReload: false,
  progress: false,
  overlay: false
};
if (parsedResourceQuery.hot === "true") {
  options.hot = true;
  enabledFeatures["Hot Module Replacement"] = true;
}
if (parsedResourceQuery["live-reload"] === "true") {
  options.liveReload = true;
  enabledFeatures["Live Reloading"] = true;
}
if (parsedResourceQuery.progress === "true") {
  options.progress = true;
  enabledFeatures.Progress = true;
}
if (parsedResourceQuery.overlay) {
  try {
    options.overlay = JSON.parse(parsedResourceQuery.overlay);
  } catch (e) {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.error("Error parsing overlay options from resource query:", e);
  }
  // Fill in default "true" params for partially-specified objects.
  if (_typeof(options.overlay) === "object") {
    options.overlay = _objectSpread({
      errors: true,
      warnings: true,
      runtimeErrors: true
    }, options.overlay);
    decodeOverlayOptions(options.overlay);
  }
  enabledFeatures.Overlay = options.overlay !== false;
}
if (parsedResourceQuery.logging) {
  options.logging = parsedResourceQuery.logging;
}
if (typeof parsedResourceQuery.reconnect !== "undefined") {
  options.reconnect = Number(parsedResourceQuery.reconnect);
}
/**
 * @param {string} level
 */
var setAllLogLevel = function setAllLogLevel(level) {
  // This is needed because the HMR logger operate separately from dev server logger
  webpack_hot_log_js__WEBPACK_IMPORTED_MODULE_0___default().setLogLevel(level === "verbose" || level === "log" ? "info" : level);
  (0,_utils_log_js__WEBPACK_IMPORTED_MODULE_4__.setLogLevel)(level);
};
if (options.logging) {
  setAllLogLevel(options.logging);
}
var logEnabledFeatures = function logEnabledFeatures(features) {
  var listEnabledFeatures = Object.keys(features);
  if (!features || listEnabledFeatures.length === 0) {
    return;
  }
  var logString = "Server started:";
  // Server started: Hot Module Replacement enabled, Live Reloading enabled, Overlay disabled.
  for (var i = 0; i < listEnabledFeatures.length; i++) {
    var key = listEnabledFeatures[i];
    logString += " ".concat(key, " ").concat(features[key] ? "enabled" : "disabled", ",");
  }
  // replace last comma with a period
  logString = logString.slice(0, -1).concat(".");
  _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info(logString);
};
logEnabledFeatures(enabledFeatures);
self.addEventListener("beforeunload", function () {
  status.isUnloading = true;
});
var overlay = typeof window !== "undefined" ? (0,_overlay_js__WEBPACK_IMPORTED_MODULE_3__.createOverlay)(_typeof(options.overlay) === "object" ? {
  trustedTypesPolicyName: options.overlay.trustedTypesPolicyName,
  catchRuntimeError: options.overlay.runtimeErrors
} : {
  trustedTypesPolicyName: false,
  catchRuntimeError: options.overlay
}) : {
  send: function send() {}
};
/**
 * @param {Options} options
 * @param {Status} currentStatus
 */
var reloadApp = function reloadApp(_ref, currentStatus) {
  var hot = _ref.hot,
    liveReload = _ref.liveReload;
  if (currentStatus.isUnloading) {
    return;
  }
  var currentHash = currentStatus.currentHash,
    previousHash = currentStatus.previousHash;
  var isInitial = currentHash.indexOf(/** @type {string} */previousHash) >= 0;
  if (isInitial) {
    return;
  }
  /**
   * @param {Window} rootWindow
   * @param {number} intervalId
   */
  function applyReload(rootWindow, intervalId) {
    clearInterval(intervalId);
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("App updated. Reloading...");
    rootWindow.location.reload();
  }
  var search = self.location.search.toLowerCase();
  var allowToHot = search.indexOf("webpack-dev-server-hot=false") === -1;
  var allowToLiveReload = search.indexOf("webpack-dev-server-live-reload=false") === -1;
  if (hot && allowToHot) {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("App hot update...");
    webpack_hot_emitter_js__WEBPACK_IMPORTED_MODULE_1___default().emit("webpackHotUpdate", currentStatus.currentHash);
    if (typeof self !== "undefined" && self.window) {
      // broadcast update to window
      self.postMessage("webpackHotUpdate".concat(currentStatus.currentHash), "*");
    }
  }
  // allow refreshing the page only if liveReload isn't disabled
  else if (liveReload && allowToLiveReload) {
    var rootWindow = self;
    // use parent window for reload (in case we're in an iframe with no valid src)
    var intervalId = self.setInterval(function () {
      if (rootWindow.location.protocol !== "about:") {
        // reload immediately if protocol is valid
        applyReload(rootWindow, intervalId);
      } else {
        rootWindow = rootWindow.parent;
        if (rootWindow.parent === rootWindow) {
          // if parent equals current window we've reached the root which would continue forever, so trigger a reload anyways
          applyReload(rootWindow, intervalId);
        }
      }
    });
  }
};
var ansiRegex = new RegExp(["[\\u001B\\u009B][[\\]()#;?]*(?:(?:(?:(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]+)*|[a-zA-Z\\d]+(?:;[-a-zA-Z\\d\\/#&.:=?%@~_]*)*)?\\u0007)", "(?:(?:\\d{1,4}(?:;\\d{0,4})*)?[\\dA-PR-TZcf-nq-uy=><~]))"].join("|"), "g");
/**
 *
 * Strip [ANSI escape codes](https://en.wikipedia.org/wiki/ANSI_escape_code) from a string.
 * Adapted from code originally released by Sindre Sorhus
 * Licensed the MIT License
 *
 * @param {string} string
 * @return {string}
 */
var stripAnsi = function stripAnsi(string) {
  if (typeof string !== "string") {
    throw new TypeError("Expected a `string`, got `".concat(_typeof(string), "`"));
  }
  return string.replace(ansiRegex, "");
};
var onSocketMessage = {
  hot: function hot() {
    if (parsedResourceQuery.hot === "false") {
      return;
    }
    options.hot = true;
  },
  liveReload: function liveReload() {
    if (parsedResourceQuery["live-reload"] === "false") {
      return;
    }
    options.liveReload = true;
  },
  invalid: function invalid() {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("App updated. Recompiling...");
    // Fixes #1042. overlay doesn't clear if errors are fixed but warnings remain.
    if (options.overlay) {
      overlay.send({
        type: "DISMISS"
      });
    }
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("Invalid");
  },
  /**
   * @param {string} hash
   */
  hash: function hash(_hash) {
    status.previousHash = status.currentHash;
    status.currentHash = _hash;
  },
  logging: setAllLogLevel,
  /**
   * @param {boolean} value
   */
  overlay: function overlay(value) {
    if (typeof document === "undefined") {
      return;
    }
    options.overlay = value;
    decodeOverlayOptions(options.overlay);
  },
  /**
   * @param {number} value
   */
  reconnect: function reconnect(value) {
    if (parsedResourceQuery.reconnect === "false") {
      return;
    }
    options.reconnect = value;
  },
  /**
   * @param {boolean} value
   */
  progress: function progress(value) {
    options.progress = value;
  },
  /**
   * @param {{ pluginName?: string, percent: number, msg: string }} data
   */
  "progress-update": function progressUpdate(data) {
    if (options.progress) {
      _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("".concat(data.pluginName ? "[".concat(data.pluginName, "] ") : "").concat(data.percent, "% - ").concat(data.msg, "."));
    }
    if ((0,_progress_js__WEBPACK_IMPORTED_MODULE_6__.isProgressSupported)()) {
      if (typeof options.progress === "string") {
        var progress = document.querySelector("wds-progress");
        if (!progress) {
          (0,_progress_js__WEBPACK_IMPORTED_MODULE_6__.defineProgressElement)();
          progress = document.createElement("wds-progress");
          document.body.appendChild(progress);
        }
        progress.setAttribute("progress", data.percent);
        progress.setAttribute("type", options.progress);
      }
    }
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("Progress", data);
  },
  "still-ok": function stillOk() {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("Nothing changed.");
    if (options.overlay) {
      overlay.send({
        type: "DISMISS"
      });
    }
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("StillOk");
  },
  ok: function ok() {
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("Ok");
    if (options.overlay) {
      overlay.send({
        type: "DISMISS"
      });
    }
    reloadApp(options, status);
  },
  /**
   * @param {string} file
   */
  "static-changed": function staticChanged(file) {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("".concat(file ? "\"".concat(file, "\"") : "Content", " from static directory was changed. Reloading..."));
    self.location.reload();
  },
  /**
   * @param {Error[]} warnings
   * @param {any} params
   */
  warnings: function warnings(_warnings, params) {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.warn("Warnings while compiling.");
    var printableWarnings = _warnings.map(function (error) {
      var _formatProblem = (0,_overlay_js__WEBPACK_IMPORTED_MODULE_3__.formatProblem)("warning", error),
        header = _formatProblem.header,
        body = _formatProblem.body;
      return "".concat(header, "\n").concat(stripAnsi(body));
    });
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("Warnings", printableWarnings);
    for (var i = 0; i < printableWarnings.length; i++) {
      _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.warn(printableWarnings[i]);
    }
    var overlayWarningsSetting = typeof options.overlay === "boolean" ? options.overlay : options.overlay && options.overlay.warnings;
    if (overlayWarningsSetting) {
      var warningsToDisplay = typeof overlayWarningsSetting === "function" ? _warnings.filter(overlayWarningsSetting) : _warnings;
      if (warningsToDisplay.length) {
        overlay.send({
          type: "BUILD_ERROR",
          level: "warning",
          messages: _warnings
        });
      }
    }
    if (params && params.preventReloading) {
      return;
    }
    reloadApp(options, status);
  },
  /**
   * @param {Error[]} errors
   */
  errors: function errors(_errors) {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.error("Errors while compiling. Reload prevented.");
    var printableErrors = _errors.map(function (error) {
      var _formatProblem2 = (0,_overlay_js__WEBPACK_IMPORTED_MODULE_3__.formatProblem)("error", error),
        header = _formatProblem2.header,
        body = _formatProblem2.body;
      return "".concat(header, "\n").concat(stripAnsi(body));
    });
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("Errors", printableErrors);
    for (var i = 0; i < printableErrors.length; i++) {
      _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.error(printableErrors[i]);
    }
    var overlayErrorsSettings = typeof options.overlay === "boolean" ? options.overlay : options.overlay && options.overlay.errors;
    if (overlayErrorsSettings) {
      var errorsToDisplay = typeof overlayErrorsSettings === "function" ? _errors.filter(overlayErrorsSettings) : _errors;
      if (errorsToDisplay.length) {
        overlay.send({
          type: "BUILD_ERROR",
          level: "error",
          messages: _errors
        });
      }
    }
  },
  /**
   * @param {Error} error
   */
  error: function error(_error) {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.error(_error);
  },
  close: function close() {
    _utils_log_js__WEBPACK_IMPORTED_MODULE_4__.log.info("Disconnected!");
    if (options.overlay) {
      overlay.send({
        type: "DISMISS"
      });
    }
    (0,_utils_sendMessage_js__WEBPACK_IMPORTED_MODULE_5__["default"])("Close");
  }
};
/**
 * @param {{ protocol?: string, auth?: string, hostname?: string, port?: string, pathname?: string, search?: string, hash?: string, slashes?: boolean }} objURL
 * @returns {string}
 */
var formatURL = function formatURL(objURL) {
  var protocol = objURL.protocol || "";
  if (protocol && protocol.substr(-1) !== ":") {
    protocol += ":";
  }
  var auth = objURL.auth || "";
  if (auth) {
    auth = encodeURIComponent(auth);
    auth = auth.replace(/%3A/i, ":");
    auth += "@";
  }
  var host = "";
  if (objURL.hostname) {
    host = auth + (objURL.hostname.indexOf(":") === -1 ? objURL.hostname : "[".concat(objURL.hostname, "]"));
    if (objURL.port) {
      host += ":".concat(objURL.port);
    }
  }
  var pathname = objURL.pathname || "";
  if (objURL.slashes) {
    host = "//".concat(host || "");
    if (pathname && pathname.charAt(0) !== "/") {
      pathname = "/".concat(pathname);
    }
  } else if (!host) {
    host = "";
  }
  var search = objURL.search || "";
  if (search && search.charAt(0) !== "?") {
    search = "?".concat(search);
  }
  var hash = objURL.hash || "";
  if (hash && hash.charAt(0) !== "#") {
    hash = "#".concat(hash);
  }
  pathname = pathname.replace(/[?#]/g,
  /**
   * @param {string} match
   * @returns {string}
   */
  function (match) {
    return encodeURIComponent(match);
  });
  search = search.replace("#", "%23");
  return "".concat(protocol).concat(host).concat(pathname).concat(search).concat(hash);
};
/**
 * @param {URL & { fromCurrentScript?: boolean }} parsedURL
 * @returns {string}
 */
var createSocketURL = function createSocketURL(parsedURL) {
  var hostname = parsedURL.hostname;
  // Node.js module parses it as `::`
  // `new URL(urlString, [baseURLString])` parses it as '[::]'
  var isInAddrAny = hostname === "0.0.0.0" || hostname === "::" || hostname === "[::]";
  // why do we need this check?
  // hostname n/a for file protocol (example, when using electron, ionic)
  // see: https://github.com/webpack/webpack-dev-server/pull/384
  if (isInAddrAny && self.location.hostname && self.location.protocol.indexOf("http") === 0) {
    hostname = self.location.hostname;
  }
  var socketURLProtocol = parsedURL.protocol || self.location.protocol;
  // When https is used in the app, secure web sockets are always necessary because the browser doesn't accept non-secure web sockets.
  if (socketURLProtocol === "auto:" || hostname && isInAddrAny && self.location.protocol === "https:") {
    socketURLProtocol = self.location.protocol;
  }
  socketURLProtocol = socketURLProtocol.replace(/^(?:http|.+-extension|file)/i, "ws");
  var socketURLAuth = "";
  // `new URL(urlString, [baseURLstring])` doesn't have `auth` property
  // Parse authentication credentials in case we need them
  if (parsedURL.username) {
    socketURLAuth = parsedURL.username;
    // Since HTTP basic authentication does not allow empty username,
    // we only include password if the username is not empty.
    if (parsedURL.password) {
      // Result: <username>:<password>
      socketURLAuth = socketURLAuth.concat(":", parsedURL.password);
    }
  }
  // In case the host is a raw IPv6 address, it can be enclosed in
  // the brackets as the brackets are needed in the final URL string.
  // Need to remove those as url.format blindly adds its own set of brackets
  // if the host string contains colons. That would lead to non-working
  // double brackets (e.g. [[::]]) host
  //
  // All of these web socket url params are optionally passed in through resourceQuery,
  // so we need to fall back to the default if they are not provided
  var socketURLHostname = (hostname || self.location.hostname || "localhost").replace(/^\[(.*)\]$/, "$1");
  var socketURLPort = parsedURL.port;
  if (!socketURLPort || socketURLPort === "0") {
    socketURLPort = self.location.port;
  }
  // If path is provided it'll be passed in via the resourceQuery as a
  // query param so it has to be parsed out of the querystring in order for the
  // client to open the socket to the correct location.
  var socketURLPathname = "/ws";
  if (parsedURL.pathname && !parsedURL.fromCurrentScript) {
    socketURLPathname = parsedURL.pathname;
  }
  return formatURL({
    protocol: socketURLProtocol,
    auth: socketURLAuth,
    hostname: socketURLHostname,
    port: socketURLPort,
    pathname: socketURLPathname,
    slashes: true
  });
};
var socketURL = createSocketURL(parsedResourceQuery);
(0,_socket_js__WEBPACK_IMPORTED_MODULE_2__["default"])(socketURL, onSocketMessage, options.reconnect);

})();

// This entry needs to be wrapped in an IIFE because it needs to be isolated against other entry modules.
(() => {
/*!***************************!*\
  !*** ./src/commercial.ts ***!
  \***************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lib/commercial-features */ "./src/lib/commercial-features.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var shouldBootConsentless = consentState => {
  return window.guardian.config.switches.optOutAdvertising && consentState.tcfv2 && !(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)('googletag', consentState) && !_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.adFree;
};
/**
 * Choose whether to launch Googletag or Opt Out tag (ootag) based on consent state
 */
void _asyncToGenerator(function* () {
  var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
  // Only load the Opt Out tag if:
  // - Opt Out switch is on
  // - in TCF region
  // - no consent for Googletag
  // - the user is not a subscriber
  if (shouldBootConsentless(consentState)) {
    void Promise.all(/*! import() | consentless-advertising */[__webpack_require__.e("vendors-node_modules_pnpm_fastdom_1_0_12_node_modules_fastdom_extensions_fastdom-promised_js--5b2882"), __webpack_require__.e("vendors-node_modules_pnpm_prebid_js_9_27_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-3193a3"), __webpack_require__.e("src_init_consented_remove-slots_ts-src_lib_error_report-error_ts-core_src_event-timer_ts"), __webpack_require__.e("src_events_empty-advert_ts-src_init_shared_reload-page-on-consent-change_ts-src_init_shared_s-78f028"), __webpack_require__.e("consentless-advertising")]).then(__webpack_require__.bind(__webpack_require__, /*! ./init/consentless-advertising */ "./src/init/consentless-advertising.ts")).then(_ref2 => {
      var {
        bootConsentless
      } = _ref2;
      return bootConsentless(consentState);
    });
  } else if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.adFree) {
    void Promise.all(/*! import() | ad-free */[__webpack_require__.e("vendors-node_modules_pnpm_fastdom_1_0_12_node_modules_fastdom_extensions_fastdom-promised_js--5b2882"), __webpack_require__.e("src_init_consented_remove-slots_ts-src_lib_error_report-error_ts-core_src_event-timer_ts"), __webpack_require__.e("src_init_consented_ad-free-slot-remove_ts-src_init_consented_comscore_ts-src_init_consented_i-69c2bc"), __webpack_require__.e("ad-free")]).then(__webpack_require__.bind(__webpack_require__, /*! ./init/ad-free */ "./src/init/ad-free.ts")).then(_ref3 => {
      var {
        bootCommercialWhenReady
      } = _ref3;
      return bootCommercialWhenReady();
    });
  } else {
    void Promise.all(/*! import() | consented-advertising */[__webpack_require__.e("vendors-node_modules_pnpm_fastdom_1_0_12_node_modules_fastdom_extensions_fastdom-promised_js--5b2882"), __webpack_require__.e("vendors-node_modules_pnpm_prebid_js_9_27_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-3193a3"), __webpack_require__.e("src_init_consented_remove-slots_ts-src_lib_error_report-error_ts-core_src_event-timer_ts"), __webpack_require__.e("src_events_empty-advert_ts-src_init_shared_reload-page-on-consent-change_ts-src_init_shared_s-78f028"), __webpack_require__.e("src_init_consented_ad-free-slot-remove_ts-src_init_consented_comscore_ts-src_init_consented_i-69c2bc"), __webpack_require__.e("consented-advertising")]).then(__webpack_require__.bind(__webpack_require__, /*! ./init/consented-advertising */ "./src/init/consented-advertising.ts")).then(_ref4 => {
      var {
        bootCommercialWhenReady
      } = _ref4;
      return bootCommercialWhenReady();
    });
  }
})();
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uc3RhbmRhbG9uZS5jb21tZXJjaWFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBTUEsR0FBRyxHQUFJQyxPQUFPLElBQUssSUFBSUMsT0FBTyxDQUFDLENBQUNDLE9BQU8sRUFBRUMsTUFBTSxLQUFLO0VBQ3RELElBQUlDLE1BQU0sQ0FBQ0MsUUFBUSxFQUFFO0lBQ2pCRCxNQUFNLENBQUNDLFFBQVEsQ0FBQ0wsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDTSxNQUFNLEVBQUVDLE9BQU8sS0FBS0EsT0FBTyxHQUFHTCxPQUFPLENBQUNJLE1BQU0sQ0FBQyxJQUMxRTtJQUNBSCxNQUFNLENBQUMsSUFBSUssS0FBSyxrQkFBQUMsTUFBQSxDQUFrQlQsT0FBTyxVQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDeEQsQ0FBQyxNQUNJO0lBQ0RHLE1BQU0sQ0FBQyxJQUFJSyxLQUFLLENBQUMsNkJBQTZCLENBQUMsQ0FBQztFQUNwRDtBQUNKLENBQUMsQ0FBQztBQUNGLElBQU1FLFVBQVUsR0FBR0EsQ0FBQSxLQUFNWCxHQUFHLENBQUMsWUFBWSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNWSjtBQUN0QyxJQUFNWSxlQUFlO0VBQUEsSUFBQUMsSUFBQSxHQUFBQyxpQkFBQSxDQUFHLGFBQVk7SUFDaEMsSUFBTUMsT0FBTyxTQUFTSixtREFBVSxDQUFDLENBQUM7SUFDbEMsSUFBTUssUUFBUSxHQUFHRCxPQUFPLENBQUNFLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUc7SUFDcEQsT0FBTztNQUNIQyx1QkFBdUIsRUFBRSxDQUFDSDtJQUM5QixDQUFDO0VBQ0wsQ0FBQztFQUFBLGdCQU5LSixlQUFlQSxDQUFBO0lBQUEsT0FBQUMsSUFBQSxDQUFBTyxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBTXBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1A4RDtBQUNQO0FBQ25CO0FBQ3NIO0FBQ3JEO0FBQ3RHLElBQU1VLElBQUksR0FBR0EsQ0FBQ0UsU0FBUyxFQUFFQyxXQUFXLEVBQUVDLGNBQWMsRUFBRUMsb0JBQW9CLEVBQUVDLE9BQU8sS0FBSztFQUNwRmIsa0RBQUksQ0FBQyxVQUFVLENBQUM7RUFDaEJRLHFEQUFNLENBQUNDLFNBQVMsRUFBRUMsV0FBVyxFQUFFQyxjQUFjLEVBQUVDLG9CQUFvQixFQUFFQyxPQUFPLENBQUM7QUFDakYsQ0FBQztBQUNELElBQU1SLHNCQUFzQixHQUFHQSxDQUFBLEtBQU1DLG1FQUF3QjtBQUM3RCxTQUFTUSxrQkFBa0JBLENBQUEsRUFBRztFQUFBLElBQUFDLFlBQUEsRUFBQUMscUJBQUEsRUFBQUMsYUFBQSxFQUFBQyxxQkFBQSxFQUFBQyxhQUFBLEVBQUFDLHFCQUFBO0VBQzFCLFFBQVF0Qiw0RUFBbUIsQ0FBQyxDQUFDO0lBQ3pCLEtBQUssT0FBTztNQUNSLENBQUFpQixZQUFBLEdBQUFsQyxNQUFNLENBQUN3QyxJQUFJLGNBQUFOLFlBQUEsZ0JBQUFBLFlBQUEsR0FBWEEsWUFBQSxDQUFhTyxJQUFJLGNBQUFQLFlBQUEsZ0JBQUFDLHFCQUFBLEdBQWpCRCxZQUFBLENBQW1CUSx1QkFBdUIsY0FBQVAscUJBQUEsZUFBMUNBLHFCQUFBLENBQUFRLElBQUEsQ0FBQVQsWUFBQSxFQUE2Q2hCLHFFQUFpQixDQUFDLENBQUMsR0FBR0ssMkZBQW9DLEdBQUdELDRFQUFxQixDQUFDO01BQ2hJO0lBQ0osS0FBSyxPQUFPO01BQ1IsQ0FBQWMsYUFBQSxHQUFBcEMsTUFBTSxDQUFDd0MsSUFBSSxjQUFBSixhQUFBLGdCQUFBQSxhQUFBLEdBQVhBLGFBQUEsQ0FBYVEsS0FBSyxjQUFBUixhQUFBLGdCQUFBQyxxQkFBQSxHQUFsQkQsYUFBQSxDQUFvQk0sdUJBQXVCLGNBQUFMLHFCQUFBLGVBQTNDQSxxQkFBQSxDQUFBTSxJQUFBLENBQUFQLGFBQUEsRUFBOENmLDRFQUFxQixDQUFDO01BQ3BFO0lBQ0osS0FBSyxLQUFLO01BQ04sQ0FBQWlCLGFBQUEsR0FBQXRDLE1BQU0sQ0FBQ3dDLElBQUksY0FBQUYsYUFBQSxnQkFBQUEsYUFBQSxHQUFYQSxhQUFBLENBQWFPLElBQUksY0FBQVAsYUFBQSxnQkFBQUMscUJBQUEsR0FBakJELGFBQUEsQ0FBbUJJLHVCQUF1QixjQUFBSCxxQkFBQSxlQUExQ0EscUJBQUEsQ0FBQUksSUFBQSxDQUFBTCxhQUFBLEVBQTZDbEIsZ0ZBQXlCLENBQUM7TUFDdkU7RUFDUjtBQUNKO0FBQ0EsSUFBTTBCLEdBQUcsR0FBRztFQUNScEIsSUFBSTtFQUNKRixzQkFBc0I7RUFDdEJTO0FBQ0osQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQkQsSUFBTWMsV0FBVyxHQUFHLGlCQUFpQjtBQUNyQyxJQUFNQyxPQUFPLEdBQUdBLENBQUEsS0FBTTtFQUNsQkMsUUFBUSxDQUFDQyxNQUFNLE1BQUE3QyxNQUFBLENBQU0wQyxXQUFXLFVBQU87QUFDM0MsQ0FBQztBQUNELElBQU1JLE1BQU0sR0FBR0EsQ0FBQSxLQUFNO0VBQ2pCRixRQUFRLENBQUNDLE1BQU0sTUFBQTdDLE1BQUEsQ0FBTTBDLFdBQVcsV0FBUTtBQUM1QyxDQUFDO0FBQ0QsSUFBTUssVUFBVSxHQUFHQSxDQUFBLEtBQU0sSUFBSUMsTUFBTSxJQUFBaEQsTUFBQSxDQUFJMEMsV0FBVyxrQkFBZSxDQUFDLENBQUNPLElBQUksQ0FBQ0wsUUFBUSxDQUFDQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ1B4RixJQUFNSyxvQkFBb0IsR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7QUFDN0MsSUFBTUMsaUJBQWlCLEdBQUlDLFdBQVcsSUFBSztFQUN2QyxPQUFPRixvQkFBb0IsQ0FBQ0csSUFBSSxDQUFFQyxPQUFPLElBQUtBLE9BQU8sS0FBS0YsV0FBVyxDQUFDO0FBQzFFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNId0M7QUFDekMsSUFBTUksYUFBYSxHQUFHQSxDQUFDQyxNQUFNLEVBQUVDLE9BQU8sS0FBSztFQUFBLElBQUFDLGNBQUE7RUFDdkMsSUFBTUMsY0FBYyxHQUFHTCxrREFBUyxDQUFDRSxNQUFNLENBQUM7RUFDeEMsSUFBSSxPQUFPRyxjQUFjLEtBQUssV0FBVyxJQUFJQSxjQUFjLENBQUNDLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDdEUsTUFBTSxJQUFJOUQsS0FBSyxZQUFBQyxNQUFBLENBQVl5RCxNQUFNLG9KQUFpSixDQUFDO0VBQ3ZMO0VBQ0EsSUFBSUMsT0FBTyxDQUFDbkIsS0FBSyxFQUFFO0lBQ2YsT0FBTyxDQUFDbUIsT0FBTyxDQUFDbkIsS0FBSyxDQUFDdUIsU0FBUztFQUNuQztFQUNBLElBQUlKLE9BQU8sQ0FBQ0ssR0FBRyxFQUFFO0lBQ2IsT0FBT0wsT0FBTyxDQUFDSyxHQUFHLENBQUN0RCx1QkFBdUI7RUFDOUM7RUFDQSxJQUFNdUQsa0JBQWtCLEdBQUdKLGNBQWMsQ0FBQ0ssSUFBSSxDQUFFQyxFQUFFO0lBQUEsSUFBQUMsYUFBQTtJQUFBLE9BQUssU0FBQUEsYUFBQSxHQUFPVCxPQUFPLENBQUNVLEtBQUssY0FBQUQsYUFBQSx1QkFBYkEsYUFBQSxDQUFlRSxjQUFjLENBQUNILEVBQUUsQ0FBQyxNQUFLLFdBQVc7RUFBQSxFQUFDO0VBQ2hILElBQUksT0FBT0Ysa0JBQWtCLEtBQUssV0FBVyxFQUFFO0lBQzNDTSxPQUFPLENBQUNDLElBQUksc0RBQUF2RSxNQUFBLENBQXNEeUQsTUFBTSxNQUFHLENBQUM7SUFDNUUsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBTWUsWUFBWSxJQUFBYixjQUFBLEdBQUdELE9BQU8sQ0FBQ1UsS0FBSyxjQUFBVCxjQUFBLHVCQUFiQSxjQUFBLENBQWVVLGNBQWMsQ0FBQ0wsa0JBQWtCLENBQUM7RUFDdEUsSUFBSSxPQUFPUSxZQUFZLEtBQUssV0FBVyxFQUFFO0lBQ3JDRixPQUFPLENBQUNDLElBQUksc0RBQUF2RSxNQUFBLENBQXNEeUQsTUFBTSxNQUFHLENBQUM7SUFDNUUsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsT0FBT2UsWUFBWTtBQUN2QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZCeUM7QUFDMUMsSUFBSUUsZ0JBQWdCO0FBQ3BCLElBQU1DLG1CQUFtQixHQUFJcEQsU0FBUyxJQUFLO0VBQ3ZDa0Qsc0RBQUcsQ0FBQyxLQUFLLHNCQUFBekUsTUFBQSxDQUFzQnVCLFNBQVMsQ0FBRSxDQUFDO0VBQzNDbUQsZ0JBQWdCLEdBQUduRCxTQUFTO0FBQ2hDLENBQUM7QUFDRCxJQUFNWCxtQkFBbUIsR0FBR0EsQ0FBQSxLQUFNOEQsZ0JBQWdCOzs7Ozs7Ozs7Ozs7Ozs7QUNObEQsSUFBTUUsWUFBWSxHQUFJcEQsV0FBVyxJQUFLO0VBQ2xDLElBQUlELFNBQVM7RUFDYixRQUFRQyxXQUFXO0lBQ2YsS0FBSyxJQUFJO01BQ0xELFNBQVMsR0FBRyxPQUFPO01BQ25CO0lBQ0osS0FBSyxJQUFJO01BQ0xBLFNBQVMsR0FBRyxLQUFLO01BQ2pCO0lBQ0osS0FBSyxJQUFJO0lBQ1Q7TUFDSUEsU0FBUyxHQUFHLE9BQU87TUFDbkI7RUFDUjtFQUNBLE9BQU9BLFNBQVM7QUFDcEIsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmNEM7QUFDSDtBQUNYO0FBQzRCO0FBQ1c7QUFDckI7QUFDUztBQUNrQjtBQUMrRTtBQUM1RjtBQUMvRCxJQUFJbUUsRUFBRSxFQUFFQyxFQUFFLEVBQUVDLEVBQUUsRUFBRUMsRUFBRTtBQUNsQixJQUFJLENBQUNWLG9EQUFZLEVBQUU7RUFDZixJQUFJLE9BQU94RixNQUFNLENBQUNtRyxXQUFXLEtBQUssV0FBVyxFQUFFO0lBQzNDbkcsTUFBTSxDQUFDbUcsV0FBVyxHQUFHLENBQUMsQ0FBQztFQUMzQjtBQUNKO0FBQ0EsSUFBSUMsdUJBQXVCO0FBQzNCLElBQUlDLFlBQVksR0FBRyxLQUFLO0FBQ3hCLElBQUlDLGtCQUFrQjtBQUN0QixJQUFNQyxXQUFXLEdBQUcsSUFBSTFHLE9BQU8sQ0FBRUMsT0FBTyxJQUFLO0VBQ3pDd0csa0JBQWtCLEdBQUd4RyxPQUFPO0FBQ2hDLENBQUMsQ0FBQztBQUNGLElBQU00QixJQUFJLEdBQUdsQixJQUFBLElBQWdGO0VBQUEsSUFBL0U7SUFBRXdCLE9BQU87SUFBRXdFLE9BQU87SUFBRTFFLGNBQWMsR0FBRyxLQUFLO0lBQUVDLG9CQUFvQixHQUFHO0VBQU0sQ0FBQyxHQUFBdkIsSUFBQTtFQUNwRixJQUFJNEMsdURBQVUsQ0FBQyxDQUFDLElBQUlvQyxvREFBWSxFQUFFO0lBQzlCO0VBQ0o7RUFDQSxJQUFJeEYsTUFBTSxDQUFDbUcsV0FBVyxDQUFDSSxXQUFXLEVBQUU7SUFBQSxJQUFBRSxxQkFBQTtJQUNoQyxJQUFJLEVBQUFBLHFCQUFBLEdBQUF6RyxNQUFNLENBQUNtRyxXQUFXLENBQUNWLEdBQUcsY0FBQWdCLHFCQUFBLHVCQUF0QkEscUJBQUEsQ0FBd0J2QixPQUFPLE1BQUtBLHFEQUFPLEVBQUU7TUFBQSxJQUFBd0Isc0JBQUE7TUFDN0MvQixPQUFPLENBQUNDLElBQUksQ0FBQyxnREFBZ0QsRUFBRSxDQUMzRE0scURBQU8sR0FBQXdCLHNCQUFBLEdBQ1AxRyxNQUFNLENBQUNtRyxXQUFXLENBQUNWLEdBQUcsY0FBQWlCLHNCQUFBLHVCQUF0QkEsc0JBQUEsQ0FBd0J4QixPQUFPLENBQ2xDLENBQUM7SUFDTjtJQUNBO0VBQ0o7RUFDQWxGLE1BQU0sQ0FBQ21HLFdBQVcsQ0FBQ0ksV0FBVyxHQUFHLElBQUk7RUFDckMsSUFBSSxPQUFPQyxPQUFPLEtBQUssV0FBVyxFQUFFO0lBQ2hDLE1BQU0sSUFBSXBHLEtBQUssQ0FBQyxrR0FBa0csQ0FBQztFQUN2SDtFQUNBLElBQU13QixTQUFTLEdBQUdxRCw4REFBWSxDQUFDdUIsT0FBTyxDQUFDO0VBQ3ZDMUQsd0NBQUcsQ0FBQ3BCLElBQUksQ0FBQ0UsU0FBUyxFQUFFNEUsT0FBTyxFQUFFMUUsY0FBYyxFQUFFQyxvQkFBb0IsRUFBRUMsT0FBTyxhQUFQQSxPQUFPLGNBQVBBLE9BQU8sR0FBSSxDQUFDLENBQUMsQ0FBQztFQUNqRixLQUFLYyx3Q0FBRyxDQUFDdEIsc0JBQXNCLENBQUMsQ0FBQyxDQUFDbUYsSUFBSSxDQUFFQyxhQUFhLElBQUs7SUFDdERSLHVCQUF1QixHQUFHUSxhQUFhO0lBQ3ZDUCxZQUFZLEdBQUcsSUFBSTtJQUNuQnZCLHNEQUFHLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQztFQUM5QixDQUFDLENBQUM7RUFDRndCLGtCQUFrQixDQUFDLENBQUM7RUFDcEJSLDRFQUFxQixDQUFDLENBQUM7QUFDM0IsQ0FBQztBQUNELElBQU10RSxzQkFBc0IsR0FBR0EsQ0FBQSxLQUFNK0UsV0FBVyxDQUFDSSxJQUFJLENBQUMsTUFBTTdELHdDQUFHLENBQUN0QixzQkFBc0IsQ0FBQyxDQUFDLENBQUM7QUFDekYsSUFBTXFGLDBCQUEwQixHQUFHQSxDQUFBLEtBQU07RUFDckMsSUFBSVQsdUJBQXVCLEtBQUssS0FBSyxDQUFDLEVBQUU7SUFDcEMsT0FBT0EsdUJBQXVCO0VBQ2xDO0VBQ0EsTUFBTSxJQUFJaEcsS0FBSyxDQUFDLCtFQUErRSxDQUFDO0FBQ3BHLENBQUM7QUFDRCxJQUFNMEcsY0FBYyxHQUFHQSxDQUFBLEtBQU1ULFlBQVk7QUFDekMsSUFBTXBFLGtCQUFrQixHQUFHQSxDQUFBLEtBQU07RUFDN0IsS0FBS3NFLFdBQVcsQ0FBQ0ksSUFBSSxDQUFDN0Qsd0NBQUcsQ0FBQ2Isa0JBQWtCLENBQUM7QUFDakQsQ0FBQztBQUNELElBQU13RCxHQUFHLEdBQUdELG9EQUFZLEdBQUdFLDJDQUFLLElBQUFxQixNQUFBLEdBQUcsQ0FBQ2hCLEVBQUUsR0FBRy9GLE1BQU0sQ0FBQ21HLFdBQVcsRUFBRVYsR0FBRyxjQUFBc0IsTUFBQSxjQUFBQSxNQUFBLEdBQUtoQixFQUFFLENBQUNOLEdBQUcsR0FBRztFQUMxRS9ELElBQUk7RUFDSkYsc0JBQXNCO0VBQ3RCcUYsMEJBQTBCO0VBQzFCQyxjQUFjO0VBQ2Q3RSxrQkFBa0I7RUFDbEJpRCxPQUFPO0VBQ1A7RUFDQThCLFlBQVksRUFBRTVELG1EQUFVO0VBQ3hCNkQsUUFBUSxFQUFFOUQsK0NBQU07RUFDaEIrRCxTQUFTLEVBQUVsRSxnREFBT0E7QUFDdEIsQ0FBRTtBQUNGLElBQU1vQyxTQUFTLEdBQUdJLG9EQUFZLEdBQUdHLGlEQUFXLElBQUF3QixZQUFBLEdBQUcsQ0FBQ25CLEVBQUUsR0FBR2hHLE1BQU0sQ0FBQ21HLFdBQVcsRUFBRWYsU0FBUyxjQUFBK0IsWUFBQSxjQUFBQSxZQUFBLEdBQUtuQixFQUFFLENBQUNaLFNBQVMsR0FBR0Msb0RBQVk7QUFDbEgsSUFBTUMsZUFBZSxHQUFHRSxvREFBWSxHQUFHSSx1REFBaUIsSUFBQXdCLGtCQUFBLEdBQUcsQ0FBQ25CLEVBQUUsR0FBR2pHLE1BQU0sQ0FBQ21HLFdBQVcsRUFBRWIsZUFBZSxjQUFBOEIsa0JBQUEsY0FBQUEsa0JBQUEsR0FBS25CLEVBQUUsQ0FBQ1gsZUFBZSxHQUFHQyxnRUFBa0I7QUFDaEosSUFBTTFCLGFBQWEsR0FBRzJCLG9EQUFZLEdBQUdLLHFEQUFlLElBQUF3QixnQkFBQSxHQUFHLENBQUNuQixFQUFFLEdBQUdsRyxNQUFNLENBQUNtRyxXQUFXLEVBQUV0QyxhQUFhLGNBQUF3RCxnQkFBQSxjQUFBQSxnQkFBQSxHQUFLbkIsRUFBRSxDQUFDckMsYUFBYSxHQUFHc0IsNERBQWdCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxRWpIO0FBQzhDO0FBQ25FLElBQUlvQyxlQUFlLEdBQUcsS0FBSztBQUMzQixJQUFNQyxpQkFBaUIsR0FBSUMsY0FBYyxJQUFLO0VBQzFDRixlQUFlLEdBQUdFLGNBQWM7QUFDcEMsQ0FBQztBQUNELElBQU12RyxpQkFBaUIsR0FBR0EsQ0FBQSxLQUFNO0VBQzVCLE9BQU9xRyxlQUFlO0FBQzFCLENBQUM7QUFDRCxJQUFNRyxxQkFBcUIsR0FBSTdGLFdBQVcsSUFBSztFQUMzQyxPQUFPeUYsNEVBQXFCLENBQUNLLFFBQVEsQ0FBQzlGLFdBQVcsQ0FBQztBQUN0RCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDWDJDO0FBQzVDLElBQUkrRixVQUFVO0FBQ2QsSUFBTUMsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTTtFQUMzQixJQUFJLE9BQU9ELFVBQVUsS0FBSyxXQUFXLEVBQUU7SUFDbkMsSUFBSXBDLG9EQUFZLEVBQUU7TUFDZG9DLFVBQVUsR0FBRyxJQUFJO0lBQ3JCLENBQUMsTUFDSTtNQUNEQSxVQUFVLEdBQUc1SCxNQUFNLENBQUM4SCxRQUFRLENBQUNDLElBQUksQ0FBQ0MsUUFBUSxDQUFDLGtCQUFrQixDQUFDO0lBQ2xFO0VBQ0o7RUFDQSxPQUFPSixVQUFVO0FBQ3JCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaNEM7QUFDN0MsSUFBTXpHLElBQUksR0FBSThHLEtBQUssSUFBSztFQUFBLElBQUFDLG1CQUFBLEVBQUFDLHFCQUFBO0VBQ3BCLENBQUFELG1CQUFBLEdBQUFsSSxNQUFNLENBQUNvSSxXQUFXLGNBQUFGLG1CQUFBLGdCQUFBQyxxQkFBQSxHQUFsQkQsbUJBQUEsQ0FBb0IvRyxJQUFJLGNBQUFnSCxxQkFBQSxlQUF4QkEscUJBQUEsQ0FBQXhGLElBQUEsQ0FBQXVGLG1CQUFBLEVBQTJCRCxLQUFLLENBQUM7RUFDakMsSUFBSUksSUFBK0IsRUFBRTtJQUNqQ3ZELHNEQUFHLENBQUMsS0FBSyxFQUFFLFNBQVMsRUFBRW1ELEtBQUssQ0FBQztFQUNoQztBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTndEO0FBQ087QUFDaEUsSUFBTVEsc0JBQXNCLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUFDLGdCQUFBO0VBQ2pDLElBQU1DLE1BQU0sSUFBQUQsZ0JBQUEsR0FBRzFJLE1BQU0sQ0FBQzRJLFFBQVEsY0FBQUYsZ0JBQUEsZ0JBQUFBLGdCQUFBLEdBQWZBLGdCQUFBLENBQWlCRyxLQUFLLGNBQUFILGdCQUFBLHVCQUF0QkEsZ0JBQUEsQ0FBd0JDLE1BQU07RUFDN0MsSUFBSUEsTUFBTSxFQUFFO0lBQ1IsT0FBT0EsTUFBTTtFQUNqQjtFQUNBaEUsT0FBTyxDQUFDRyxHQUFHLENBQUMsK0NBQStDLENBQUM7RUFDNUQsT0FBTyxNQUFNLENBQ2IsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNZ0Usd0JBQXdCLEdBQUlDLFNBQVMsSUFBSztFQUM1QyxJQUFNQyxXQUFXLEdBQUc5SCxxRUFBaUIsQ0FBQyxDQUFDLEdBQUcsdUJBQXVCLEdBQUcsZUFBZTtFQUNuRixVQUFBYixNQUFBLENBQVUySSxXQUFXLE9BQUEzSSxNQUFBLENBQUkwSSxTQUFTO0FBQ3RDLENBQUM7QUFDRCxJQUFNRSx5QkFBeUIsR0FBR0EsQ0FBQ0MsVUFBVSxFQUFFSCxTQUFTLEtBQUs7RUFDekQsSUFBSUksV0FBVztFQUNmLFFBQVFELFVBQVU7SUFDZCxLQUFLVix5RUFBc0IsQ0FBQ1ksU0FBUztNQUNqQ0QsV0FBVyxHQUFHLFFBQVE7TUFDdEI7SUFDSixLQUFLWCx5RUFBc0IsQ0FBQ2EsU0FBUztNQUNqQ0YsV0FBVyxHQUFHLFFBQVE7TUFDdEI7SUFDSixLQUFLWCx5RUFBc0IsQ0FBQ2MsT0FBTztNQUMvQkgsV0FBVyxHQUFHLFNBQVM7TUFDdkI7SUFDSixLQUFLWCx5RUFBc0IsQ0FBQ2UsYUFBYTtNQUNyQ0osV0FBVyxHQUFHLGdCQUFnQjtNQUM5QjtFQUNSO0VBQ0EsSUFBTUssY0FBYyxHQUFHO0lBQ25CQyxTQUFTLEVBQUU7TUFDUEMsYUFBYSxFQUFFLFNBQVM7TUFDeEJuRixFQUFFLEVBQUV3RTtJQUNSLENBQUM7SUFDRFksTUFBTSxFQUFFLE9BQU87SUFDZkMsS0FBSyxFQUFFVDtFQUNYLENBQUM7RUFDRCxJQUFNUixNQUFNLEdBQUdGLHNCQUFzQixDQUFDLENBQUM7RUFDdkNFLE1BQU0sQ0FBQztJQUFFYTtFQUFlLENBQUMsQ0FBQztBQUM5QixDQUFDO0FBQ0QsSUFBTUssdUJBQXVCLEdBQUlkLFNBQVMsSUFBSztFQUMzQyxJQUFNUyxjQUFjLEdBQUc7SUFDbkJDLFNBQVMsRUFBRTtNQUNQQyxhQUFhLEVBQUUsU0FBUztNQUN4Qm5GLEVBQUUsRUFBRXdFO0lBQ1IsQ0FBQztJQUNEWSxNQUFNLEVBQUU7RUFDWixDQUFDO0VBQ0QsSUFBTWhCLE1BQU0sR0FBR0Ysc0JBQXNCLENBQUMsQ0FBQztFQUN2Q0UsTUFBTSxDQUFDO0lBQUVhO0VBQWUsQ0FBQyxDQUFDO0FBQzlCLENBQUM7QUFDRCxJQUFNTSwrQkFBK0IsR0FBSUYsS0FBSyxJQUFLO0VBQy9DLElBQU1KLGNBQWMsR0FBRztJQUNuQkMsU0FBUyxFQUFFO01BQ1BDLGFBQWEsRUFBRTtJQUNuQixDQUFDO0lBQ0RFLEtBQUs7SUFDTEQsTUFBTSxFQUFFO0VBQ1osQ0FBQztFQUNELElBQU1oQixNQUFNLEdBQUdGLHNCQUFzQixDQUFDLENBQUM7RUFDdkNFLE1BQU0sQ0FBQztJQUFFYTtFQUFlLENBQUMsQ0FBQztBQUM5QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDL0QyQztBQUM1QyxJQUFNTyxZQUFZLEdBQUdBLENBQUEsS0FBTTtFQUN2QixPQUFPdkUsb0RBQVksR0FBRyxLQUFLLENBQUMsR0FBR3dFLFNBQVMsQ0FBQ0Msb0JBQW9CO0FBQ2pFLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIOEM7QUFDL0MsSUFBTUMsVUFBVSxHQUFHLElBQUk7QUFDdkIsSUFBTTdJLHFCQUFxQixHQUFHLE9BQU87QUFDckMsSUFBTThJLGdCQUFnQixHQUFHLElBQUk7QUFDN0IsSUFBTUMscUJBQXFCLEdBQUcsS0FBSztBQUNuQyxJQUFNQyxxQkFBcUIsR0FBRyxLQUFLO0FBQ25DLElBQU1DLHVCQUF1QixHQUFHLG1DQUFtQztBQUNuRSxJQUFNQyxrQkFBa0IsR0FBRyw4QkFBOEI7QUFDekQsSUFBTWpKLHFCQUFxQixHQUFHLE1BQU07QUFDcEMsSUFBTUMsb0NBQW9DLEdBQUcsT0FBTztBQUNwRCxJQUFNSCx5QkFBeUIsR0FBRyxPQUFPO0FBQ3pDLElBQU1vSixRQUFRLEdBQUczQyw0REFBZ0IsQ0FBQyxDQUFDLEdBQUcscUNBQXFDLEdBQUcsOEJBQThCO0FBQzVHLElBQU1XLHNCQUFzQixHQUFHO0VBQzNCWSxTQUFTLEVBQUUsRUFBRTtFQUNiRyxhQUFhLEVBQUUsRUFBRTtFQUNqQkYsU0FBUyxFQUFFLEVBQUU7RUFDYkMsT0FBTyxFQUFFO0FBQ2IsQ0FBQztBQUNELElBQU1oQyxxQkFBcUIsR0FBRyxDQUFDLElBQUksQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbEJnQjtBQUNEO0FBQ1M7QUFDeUI7QUFDckYsSUFBTXNELG9DQUFvQyxHQUFHLGVBQWdCLElBQUlDLEdBQUcsQ0FBQyxDQUNqRSxDQUFDLENBQUMsRUFBRSwwQkFBMEIsQ0FBQztBQUMvQjtBQUNBLENBQUMsQ0FBQyxFQUFFLDBCQUEwQixDQUFDO0FBQy9CO0FBQ0EsQ0FBQyxDQUFDLEVBQUUsMEJBQTBCLENBQUM7QUFDL0I7QUFDQSxDQUFDLENBQUMsRUFBRSwwQkFBMEIsQ0FBQztBQUMvQjtBQUNBLENBQUMsQ0FBQyxFQUFFLDBCQUEwQixDQUFDO0FBQy9CO0FBQ0EsQ0FBQyxDQUFDLEVBQUUsMEJBQTBCLENBQUM7QUFDL0I7QUFDQSxDQUFDLENBQUMsRUFBRSwwQkFBMEIsQ0FBQztBQUMvQjtBQUNBLENBQUMsQ0FBQyxFQUFFLDBCQUEwQixDQUFDO0FBQy9CO0FBQ0EsQ0FBQyxDQUFDLEVBQUUsMEJBQTBCLENBQUM7QUFDL0I7QUFDQSxDQUFDLEVBQUUsRUFBRSwwQkFBMEIsQ0FBQztBQUNoQztBQUNBLENBQUMsRUFBRSxFQUFFLDBCQUEwQjtBQUMvQjtBQUFBLENBQ0gsQ0FBQztBQUNGLElBQU1DLFNBQVMsR0FBRyx1REFBdUQ7QUFDekUsSUFBTUMsZUFBZTtFQUFBLElBQUF2SyxJQUFBLEdBQUFDLGlCQUFBLENBQUcsYUFBWTtJQUNoQyxJQUFNdUssV0FBVyxTQUFTQyxzQ0FBc0MsQ0FBQyxDQUFDO0lBQ2xFLElBQU1DLGtCQUFrQixHQUFHQyxxQ0FBcUMsQ0FBQ0gsV0FBVyxDQUFDO0lBQzdFLElBQUksQ0FBQ0wsd0VBQVcsQ0FBQ08sa0JBQWtCLENBQUMsRUFBRTtNQUNsQyxNQUFNRSwrQ0FBK0MsQ0FBQ0Ysa0JBQWtCLENBQUNHLE9BQU8sRUFBRUgsa0JBQWtCLENBQUNJLFFBQVEsRUFBRUosa0JBQWtCLENBQUNLLDRCQUE0QixDQUFDO01BQy9KLE1BQU1DLCtDQUErQyxDQUFDLENBQUM7SUFDM0Q7RUFDSixDQUFDO0VBQUEsZ0JBUEtULGVBQWVBLENBQUE7SUFBQSxPQUFBdkssSUFBQSxDQUFBTyxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBT3BCO0FBQ0QsSUFBTWlLLHNDQUFzQztFQUFBLElBQUFRLEtBQUEsR0FBQWhMLGlCQUFBLENBQUcsYUFBWTtJQUN2RCxJQUFNaUwsV0FBVyxHQUFHakIsZ0VBQVMsQ0FBQztNQUFFa0IsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDO0lBQ3RELElBQU1DLEdBQUcsTUFBQXZMLE1BQUEsQ0FBTXlLLFNBQVMsZUFBQXpLLE1BQUEsQ0FBWThKLHVFQUFnQixtQkFBQTlKLE1BQUEsQ0FBZ0JxTCxXQUFXLENBQUU7SUFDakYsSUFBTUcsdUNBQXVDLFNBQVNDLEtBQUssQ0FBQ0YsR0FBRyxFQUFFO01BQzdERyxNQUFNLEVBQUUsS0FBSztNQUNiQyxPQUFPLEVBQUU7UUFDTEMsTUFBTSxFQUFFLGtCQUFrQjtRQUMxQixjQUFjLEVBQUU7TUFDcEI7SUFDSixDQUFDLENBQUM7SUFDRixhQUFhSix1Q0FBdUMsQ0FBQ0ssSUFBSSxDQUFDLENBQUM7RUFDL0QsQ0FBQztFQUFBLGdCQVhLakIsc0NBQXNDQSxDQUFBO0lBQUEsT0FBQVEsS0FBQSxDQUFBMUssS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQVczQztBQUNELElBQU1tSyxxQ0FBcUMsR0FBSWdCLElBQUksSUFBSztFQUFBLElBQUFDLE1BQUEsRUFBQUMsT0FBQSxFQUFBQyxPQUFBO0VBQ3BELElBQU1DLFNBQVMsSUFBQUgsTUFBQSxHQUFHRCxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQUFDLE1BQUEsdUJBQVBBLE1BQUEsQ0FBU2YsT0FBTyxDQUFDbUIsR0FBRyxDQUFFMUksTUFBTSxJQUFLQSxNQUFNLENBQUMySSxHQUFHLENBQUM7RUFDOUQsSUFBTUMsVUFBVSxJQUFBTCxPQUFBLEdBQUdGLElBQUksQ0FBQyxDQUFDLENBQUMsY0FBQUUsT0FBQSx1QkFBUEEsT0FBQSxDQUFTTSxVQUFVLENBQUNILEdBQUcsQ0FBRUksUUFBUTtJQUFBLElBQUFDLHFCQUFBO0lBQUEsUUFBQUEscUJBQUEsR0FBS2pDLG9DQUFvQyxDQUFDa0MsR0FBRyxDQUFDRixRQUFRLENBQUNHLGFBQWEsQ0FBQ0MsS0FBSyxDQUFDLGNBQUFILHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksRUFBRTtFQUFBLEVBQUMsQ0FBQ0ksTUFBTSxDQUFDdkMsMkRBQVEsQ0FBQztFQUN2SixJQUFNYSw0QkFBNEIsSUFBQWUsT0FBQSxHQUFHSCxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQUFHLE9BQUEsdUJBQVBBLE9BQUEsQ0FBU1ksZ0JBQWdCLENBQUNWLEdBQUcsQ0FBRUksUUFBUTtJQUFBLElBQUFPLHNCQUFBO0lBQUEsUUFBQUEsc0JBQUEsR0FBS3ZDLG9DQUFvQyxDQUFDa0MsR0FBRyxDQUFDRixRQUFRLENBQUNHLGFBQWEsQ0FBQ0MsS0FBSyxDQUFDLGNBQUFHLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUksRUFBRTtFQUFBLEVBQUMsQ0FBQ0YsTUFBTSxDQUFDdkMsMkRBQVEsQ0FBQztFQUMvSyxJQUFJNkIsU0FBUyxJQUFJRyxVQUFVLElBQUluQiw0QkFBNEIsRUFBRTtJQUN6RCxPQUFPO01BQ0hGLE9BQU8sRUFBRWtCLFNBQVM7TUFDbEJqQixRQUFRLEVBQUVvQixVQUFVO01BQ3BCbkI7SUFDSixDQUFDO0VBQ0wsQ0FBQyxNQUNJO0lBQ0QsT0FBTyxLQUFLLENBQUM7RUFDakI7QUFDSixDQUFDO0FBQ0QsSUFBTUgsK0NBQStDO0VBQUEsSUFBQWdDLEtBQUEsR0FBQTNNLGlCQUFBLENBQUcsV0FBTzhMLFNBQVMsRUFBRUcsVUFBVSxFQUFFbkIsNEJBQTRCLEVBQUs7SUFDbkgsSUFBTUcsV0FBVyxHQUFHakIsZ0VBQVMsQ0FBQztNQUFFa0IsSUFBSSxFQUFFO0lBQWMsQ0FBQyxDQUFDO0lBQ3RELElBQU1DLEdBQUcsTUFBQXZMLE1BQUEsQ0FBTXlLLFNBQVMsY0FBQXpLLE1BQUEsQ0FBVytKLDRFQUFxQiwrQkFBQS9KLE1BQUEsQ0FBNEJxTCxXQUFXLENBQUU7SUFDakcsTUFBTTJCLGVBQWUsQ0FBQ3pCLEdBQUcsRUFBRTtNQUN2QlAsT0FBTyxFQUFFa0IsU0FBUztNQUNsQkksVUFBVSxFQUFFRCxVQUFVO01BQ3RCUSxnQkFBZ0IsRUFBRTNCO0lBQ3RCLENBQUMsQ0FBQztFQUNOLENBQUM7RUFBQSxnQkFSS0gsK0NBQStDQSxDQUFBa0MsRUFBQSxFQUFBQyxHQUFBLEVBQUFDLEdBQUE7SUFBQSxPQUFBSixLQUFBLENBQUFyTSxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBUXBEO0FBQ0QsSUFBTXdLLCtDQUErQztFQUFBLElBQUFpQyxLQUFBLEdBQUFoTixpQkFBQSxDQUFHLGFBQVk7SUFBQSxJQUFBaU4saUJBQUE7SUFDaEUsSUFBTWhDLFdBQVcsR0FBR2pCLGdFQUFTLENBQUM7TUFBRWtCLElBQUksRUFBRTtJQUFjLENBQUMsQ0FBQztJQUN0RCxJQUFNQyxHQUFHLE1BQUF2TCxNQUFBLENBQU15SyxTQUFTLE9BQUF6SyxNQUFBLENBQUkrSiw0RUFBcUIsNEJBQUEvSixNQUFBLENBQXlCcUwsV0FBVyxDQUFFO0lBQ3ZGLElBQU1pQyxtQkFBbUIsR0FBR0MsWUFBWSxDQUFDQyxPQUFPLHFCQUFBeE4sTUFBQSxDQUFxQjhKLHVFQUFnQixDQUFFLENBQUM7SUFDeEYsSUFBTWEsV0FBVyxHQUFHOEMsSUFBSSxDQUFDQyxLQUFLLENBQUNKLG1CQUFtQixhQUFuQkEsbUJBQW1CLGNBQW5CQSxtQkFBbUIsR0FBSSxJQUFJLENBQUM7SUFDM0QsTUFBTU4sZUFBZSxDQUFDekIsR0FBRyxFQUFFO01BQ3ZCb0MsU0FBUyxHQUFBTixpQkFBQSxHQUFFMUMsV0FBVyxDQUFDdkksSUFBSSxjQUFBaUwsaUJBQUEsdUJBQWhCQSxpQkFBQSxDQUFrQk07SUFDakMsQ0FBQyxDQUFDO0VBQ04sQ0FBQztFQUFBLGdCQVJLeEMsK0NBQStDQSxDQUFBO0lBQUEsT0FBQWlDLEtBQUEsQ0FBQTFNLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FRcEQ7QUFDRCxJQUFNcU0sZUFBZTtFQUFBLElBQUFZLEtBQUEsR0FBQXhOLGlCQUFBLENBQUcsV0FBT21MLEdBQUcsRUFBRXNDLElBQUksRUFBSztJQUN6QyxNQUFNcEMsS0FBSyxDQUFDRixHQUFHLEVBQUU7TUFDYkcsTUFBTSxFQUFFLE1BQU07TUFDZEMsT0FBTyxFQUFFO1FBQ0xDLE1BQU0sRUFBRSxrQkFBa0I7UUFDMUIsY0FBYyxFQUFFO01BQ3BCLENBQUM7TUFDRGlDLElBQUksRUFBRUosSUFBSSxDQUFDSyxTQUFTLENBQUNELElBQUk7SUFDN0IsQ0FBQyxDQUFDO0VBQ04sQ0FBQztFQUFBLGdCQVRLYixlQUFlQSxDQUFBZSxHQUFBLEVBQUFDLEdBQUE7SUFBQSxPQUFBSixLQUFBLENBQUFsTixLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBU3BCOzs7Ozs7Ozs7Ozs7Ozs7O0FDM0ZzRDtBQUN2RCxJQUFNb0UsU0FBUyxHQUFHQSxDQUFBLEtBQU0sSUFBSXZGLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztFQUNyRHVGLG9FQUFlLENBQUVnSixZQUFZLElBQUs7SUFBQSxJQUFBOU4sSUFBQSxFQUFBK04sa0JBQUE7SUFDOUIsS0FBQS9OLElBQUEsSUFBQStOLGtCQUFBLEdBQUlELFlBQVksQ0FBQzdKLEtBQUssY0FBQThKLGtCQUFBLGNBQUFBLGtCQUFBLEdBQUlELFlBQVksQ0FBQzFMLEtBQUssY0FBQXBDLElBQUEsY0FBQUEsSUFBQSxHQUFJOE4sWUFBWSxDQUFDbEssR0FBRyxFQUFFO01BQzlEdEUsT0FBTyxDQUFDd08sWUFBWSxDQUFDO0lBQ3pCO0lBQ0F2TyxNQUFNLENBQUMsbUJBQW1CLENBQUM7RUFDL0IsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUjhFO0FBQ2pCO0FBQ2Y7QUFDa0M7QUFDQTtBQUNsRixJQUFNNE8sYUFBYSxHQUFHLEVBQUU7QUFDeEIsSUFBTUMsa0JBQWtCLEdBQUcsRUFBRTtBQUM3QixJQUFNQyw4QkFBOEIsR0FBSUMsS0FBSztFQUFBLElBQUFDLFdBQUE7RUFBQSxPQUFLLEVBQUFBLFdBQUEsR0FBQUQsS0FBSyxDQUFDckssS0FBSyxjQUFBc0ssV0FBQSx1QkFBWEEsV0FBQSxDQUFhQyxXQUFXLE1BQUssWUFBWTtBQUFBO0FBQzNGLElBQU1DLDhCQUE4QixHQUFJSCxLQUFLO0VBQUEsSUFBQUksWUFBQTtFQUFBLE9BQUssRUFBQUEsWUFBQSxHQUFBSixLQUFLLENBQUNsTSxLQUFLLGNBQUFzTSxZQUFBLHVCQUFYQSxZQUFBLENBQWFDLFlBQVksTUFBSyxXQUFXO0FBQUE7QUFDM0YsSUFBTUMsY0FBYyxHQUFHQSxDQUFDQyxRQUFRLEVBQUVQLEtBQUssS0FBSztFQUN4QyxJQUFJRCw4QkFBOEIsQ0FBQ0MsS0FBSyxDQUFDLElBQUlHLDhCQUE4QixDQUFDSCxLQUFLLENBQUMsRUFBRTtJQUNoRjtFQUNKO0VBQ0EsSUFBTVEsV0FBVyxHQUFHeEIsSUFBSSxDQUFDSyxTQUFTLENBQUNXLEtBQUssQ0FBQztFQUN6QyxJQUFJUSxXQUFXLEtBQUtELFFBQVEsQ0FBQ0UsU0FBUyxFQUFFO0lBQ3BDRixRQUFRLENBQUNHLEVBQUUsQ0FBQ1YsS0FBSyxDQUFDO0lBQ2xCTyxRQUFRLENBQUNFLFNBQVMsR0FBR0QsV0FBVztFQUNwQztBQUNKLENBQUM7QUFDRCxJQUFNRyxtQkFBbUIsR0FBSW5CLFlBQVksSUFBSztFQUMxQyxJQUFNb0IsU0FBUyxHQUFHM0YsNkRBQVksQ0FBQyxDQUFDO0VBQ2hDLElBQUl1RSxZQUFZLENBQUM3SixLQUFLLEVBQUU7SUFDcEIsSUFBTWtMLFFBQVEsR0FBR3JCLFlBQVksQ0FBQzdKLEtBQUssQ0FBQ2tMLFFBQVE7SUFDNUMsT0FBQUMsYUFBQSxDQUFBQSxhQUFBLEtBQ090QixZQUFZO01BQ2Z1QixTQUFTLEVBQUVDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDSixRQUFRLENBQUMsQ0FBQ3pMLE1BQU0sR0FBRyxDQUFDLElBQUk0TCxNQUFNLENBQUNFLE1BQU0sQ0FBQ0wsUUFBUSxDQUFDLENBQUNNLEtBQUssQ0FBQ0MsT0FBTyxDQUFDO01BQ3JGdE8sU0FBUyxFQUFFLE9BQU87TUFDbEI4TjtJQUFTO0VBRWpCLENBQUMsTUFDSSxJQUFJcEIsWUFBWSxDQUFDMUwsS0FBSyxFQUFFO0lBQ3pCLE9BQUFnTixhQUFBLENBQUFBLGFBQUEsS0FDT3RCLFlBQVk7TUFDZnVCLFNBQVMsRUFBRSxDQUFDdkIsWUFBWSxDQUFDMUwsS0FBSyxDQUFDdUIsU0FBUztNQUN4Q3ZDLFNBQVMsRUFBRSxPQUFPO01BQ2xCOE47SUFBUztFQUVqQixDQUFDLE1BQ0ksSUFBSXBCLFlBQVksQ0FBQ2xLLEdBQUcsRUFBRTtJQUN2QixPQUFBd0wsYUFBQSxDQUFBQSxhQUFBLEtBQ090QixZQUFZO01BQ2Z1QixTQUFTLEVBQUV2QixZQUFZLENBQUNsSyxHQUFHLENBQUN0RCx1QkFBdUI7TUFDbkRjLFNBQVMsRUFBRSxLQUFLO01BQ2hCOE47SUFBUztFQUVqQjtFQUNBLE9BQUFFLGFBQUEsQ0FBQUEsYUFBQSxLQUNPdEIsWUFBWTtJQUNmdUIsU0FBUyxFQUFFLEtBQUs7SUFDaEJqTyxTQUFTLEVBQUUsSUFBSTtJQUNmOE47RUFBUztBQUVqQixDQUFDO0FBQ0QsSUFBTW5QLGVBQWU7RUFBQSxJQUFBQyxJQUFBLEdBQUFDLGlCQUFBLENBQUcsYUFBWTtJQUNoQyxRQUFRUSw0RUFBbUIsQ0FBQyxDQUFDO01BQ3pCLEtBQUssS0FBSztRQUNOLE9BQU93TyxtQkFBbUIsQ0FBQztVQUFFckwsR0FBRyxRQUFRb0ssd0VBQWlCLENBQUM7UUFBRSxDQUFDLENBQUM7TUFDbEUsS0FBSyxPQUFPO1FBQUU7VUFDVixPQUFPaUIsbUJBQW1CLENBQUM7WUFDdkI3TSxLQUFLLFFBQVE4TCwwRUFBaUIsQ0FBQztVQUNuQyxDQUFDLENBQUM7UUFDTjtNQUNBLEtBQUssT0FBTztRQUNSLE9BQU9lLG1CQUFtQixDQUFDO1VBQUVoTCxLQUFLLFFBQVFnSywwRUFBaUIsQ0FBQztRQUFFLENBQUMsQ0FBQztNQUNwRTtRQUNJLE1BQU0sSUFBSXJPLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztJQUNyRTtFQUNKLENBQUM7RUFBQSxnQkFkS0csZUFBZUEsQ0FBQTtJQUFBLE9BQUFDLElBQUEsQ0FBQU8sS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQWNwQjtBQUNELElBQU1tUCxlQUFlLEdBQUdBLENBQUEsS0FBTTtFQUMxQixJQUFNQyxpQkFBaUIsR0FBR3pCLGFBQWEsQ0FBQ3RPLE1BQU0sQ0FBQ3VPLGtCQUFrQixDQUFDO0VBQ2xFLElBQUl3QixpQkFBaUIsQ0FBQ2xNLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDaEM7RUFDSjtFQUNBLEtBQUszRCxlQUFlLENBQUMsQ0FBQyxDQUFDb0csSUFBSSxDQUFFbUksS0FBSyxJQUFLO0lBQ25DLElBQUlELDhCQUE4QixDQUFDQyxLQUFLLENBQUMsSUFBSUcsOEJBQThCLENBQUNILEtBQUssQ0FBQyxFQUFFO01BQ2hGO0lBQ0o7SUFDQXNCLGlCQUFpQixDQUFDQyxPQUFPLENBQUVoQixRQUFRLElBQUtELGNBQWMsQ0FBQ0MsUUFBUSxFQUFFUCxLQUFLLENBQUMsQ0FBQztFQUM1RSxDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsSUFBTXhKLGVBQWUsR0FBRyxTQUFBQSxDQUFDZ0wsUUFBUSxFQUFvQjtFQUFBLElBQWxCQyxLQUFLLEdBQUF2UCxTQUFBLENBQUFrRCxNQUFBLFFBQUFsRCxTQUFBLFFBQUF3UCxTQUFBLEdBQUF4UCxTQUFBLE1BQUcsS0FBSztFQUM1QyxJQUFNeVAsV0FBVyxHQUFHO0lBQUVqQixFQUFFLEVBQUVjO0VBQVMsQ0FBQztFQUNwQyxJQUFJQyxLQUFLLEVBQUU7SUFDUDNCLGtCQUFrQixDQUFDOEIsSUFBSSxDQUFDRCxXQUFXLENBQUM7RUFDeEMsQ0FBQyxNQUNJO0lBQ0Q5QixhQUFhLENBQUMrQixJQUFJLENBQUNELFdBQVcsQ0FBQztFQUNuQztFQUNBLEtBQUtsUSxlQUFlLENBQUMsQ0FBQyxDQUFDb0csSUFBSSxDQUFFMkgsWUFBWSxJQUFLO0lBQzFDYyxjQUFjLENBQUNxQixXQUFXLEVBQUVuQyxZQUFZLENBQUM7RUFDN0MsQ0FBQyxDQUFDLENBQUNxQyxLQUFLLENBQUMsTUFBTSxDQUNmLENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzVGRCxJQUFNbkwsWUFBWSxHQUFHLE9BQU94RixNQUFNLEtBQUssV0FBVztBQUNsRCxJQUFNNFEsY0FBYyxHQUFHQSxDQUFBLEtBQU07RUFDekJqTSxPQUFPLENBQUNDLElBQUksQ0FBQyw0RUFBNEUsRUFBRSxzQ0FBc0MsQ0FBQztBQUN0SSxDQUFDO0FBQ0QsSUFBTWlNLHVCQUF1QixHQUFJQyxHQUFHLElBQUs7RUFDckMsT0FBTyxNQUFNO0lBQ1RGLGNBQWMsQ0FBQyxDQUFDO0lBQ2hCLE9BQU9FLEdBQUc7RUFDZCxDQUFDO0FBQ0wsQ0FBQztBQUNELElBQU1yTCxHQUFHLEdBQUc7RUFDUnlCLFNBQVMsRUFBRTBKLGNBQWM7RUFDekIzSixRQUFRLEVBQUU0Six1QkFBdUIsQ0FBQyxLQUFLLENBQUM7RUFDeEM3SixZQUFZLEVBQUU2Six1QkFBdUIsQ0FBQyxLQUFLLENBQUM7RUFDNUMvSixjQUFjLEVBQUUrSix1QkFBdUIsQ0FBQyxLQUFLLENBQUM7RUFDOUNuUCxJQUFJLEVBQUVrUCxjQUFjO0VBQ3BCM08sa0JBQWtCLEVBQUUyTyxjQUFjO0VBQ2xDMUwsT0FBTyxFQUFFLEtBQUs7RUFDZDFELHNCQUFzQixFQUFFcVAsdUJBQXVCLENBQUNoUixPQUFPLENBQUNDLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztFQUN2RStHLDBCQUEwQixFQUFFZ0ssdUJBQXVCLENBQUMsS0FBSztBQUM3RCxDQUFDO0FBQ0QsSUFBTXpMLFNBQVMsR0FBR0EsQ0FBQSxLQUFNO0VBQ3BCd0wsY0FBYyxDQUFDLENBQUM7RUFDaEIsT0FBTy9RLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDO0lBQ25CK1AsU0FBUyxFQUFFLEtBQUs7SUFDaEJqTyxTQUFTLEVBQUU7RUFDZixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsSUFBTTBELGVBQWUsR0FBR0EsQ0FBQSxLQUFNO0VBQzFCLE9BQU9zTCxjQUFjLENBQUMsQ0FBQztBQUMzQixDQUFDO0FBQ0QsSUFBTS9NLGFBQWEsR0FBR0EsQ0FBQ0MsTUFBTSxFQUFFQyxPQUFPLEtBQUs7RUFDdkNZLE9BQU8sQ0FBQ0csR0FBRyx1Q0FBQXpFLE1BQUEsQ0FBdUN5RCxNQUFNLFFBQUF6RCxNQUFBLENBQUt5TixJQUFJLENBQUNLLFNBQVMsQ0FBQ3BLLE9BQU8sQ0FBQyxRQUFLLG9EQUFvRCxDQUFDO0VBQzlJNk0sY0FBYyxDQUFDLENBQUM7RUFDaEIsT0FBTyxLQUFLO0FBQ2hCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ3lDO0FBQ2E7QUFDUTtBQUNnQjtBQUMxQztBQUMwRztBQUN3RDtBQUMvSTtBQUNEO0FBQ2Q7QUFDekMsSUFBSUksNkJBQTZCO0FBQ2pDLElBQU14UCxzQkFBc0IsR0FBRyxJQUFJM0IsT0FBTyxDQUFFQyxPQUFPLElBQUs7RUFDcERrUiw2QkFBNkIsR0FBR2xSLE9BQU87QUFDM0MsQ0FBQyxDQUFDO0FBQ0YsSUFBTW1SLGVBQWUsR0FBR0EsQ0FBQ3JQLFNBQVMsRUFBRUcsb0JBQW9CLEtBQUs7RUFDekQsSUFBSUgsU0FBUyxJQUFJLEtBQUssRUFBRTtJQUNwQixPQUFPLDRCQUE0QjtFQUN2QztFQUNBLElBQUlBLFNBQVMsSUFBSSxPQUFPLEVBQUU7SUFDdEIsT0FBTyw2QkFBNkI7RUFDeEM7RUFDQSxPQUFPRyxvQkFBb0IsR0FBR3VJLDhFQUF1QixHQUFHQyx5RUFBa0I7QUFDOUUsQ0FBQztBQUNELElBQU0yRyxhQUFhLEdBQUdBLENBQUN0UCxTQUFTLEVBQUVHLG9CQUFvQixLQUFLO0VBQ3ZELElBQUlILFNBQVMsSUFBSSxLQUFLLEVBQUU7SUFDcEIsT0FBT3lJLDRFQUFxQjtFQUNoQztFQUNBLElBQUl6SSxTQUFTLElBQUksT0FBTyxFQUFFO0lBQ3RCLE9BQU91SSx1RUFBZ0I7RUFDM0I7RUFDQSxPQUFPcEksb0JBQW9CLEdBQUdxSSw0RUFBcUIsR0FBR0QsdUVBQWdCO0FBQzFFLENBQUM7QUFDRCxJQUFNZ0gsK0JBQStCLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUFDLHFCQUFBLEVBQUExRCxpQkFBQTtFQUMxQyxJQUFNQyxtQkFBbUIsR0FBR0MsWUFBWSxDQUFDQyxPQUFPLHFCQUFBeE4sTUFBQSxDQUFxQitKLDRFQUFxQixDQUFFLENBQUM7RUFDN0YsSUFBTVksV0FBVyxHQUFHOEMsSUFBSSxDQUFDQyxLQUFLLENBQUNKLG1CQUFtQixhQUFuQkEsbUJBQW1CLGNBQW5CQSxtQkFBbUIsR0FBSSxJQUFJLENBQUM7RUFDM0QsUUFBQXlELHFCQUFBLElBQUExRCxpQkFBQSxHQUFPMUMsV0FBVyxDQUFDdkksSUFBSSxjQUFBaUwsaUJBQUEsZ0JBQUFBLGlCQUFBLEdBQWhCQSxpQkFBQSxDQUFrQjJELGFBQWEsY0FBQTNELGlCQUFBLHVCQUEvQkEsaUJBQUEsQ0FBaUM0RCxjQUFjLGNBQUFGLHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksS0FBSztBQUNuRSxDQUFDO0FBQ0QsSUFBTUcscUJBQXFCLEdBQUdBLENBQUMxUCxXQUFXLEVBQUVFLG9CQUFvQixLQUFLO0VBQ2pFLE9BQU8yRix5RUFBcUIsQ0FBQzdGLFdBQVcsQ0FBQyxJQUFJRSxvQkFBb0IsSUFBSSxDQUFDb1AsK0JBQStCLENBQUMsQ0FBQztBQUMzRyxDQUFDO0FBQ0QsSUFBTXpQLElBQUksR0FBRyxTQUFBQSxDQUFDRSxTQUFTLEVBQUVDLFdBQVcsRUFBRUMsY0FBYyxFQUFFQyxvQkFBb0IsRUFBbUI7RUFBQSxJQUFBMkcsZ0JBQUEsRUFBQThJLGlCQUFBO0VBQUEsSUFBakJ4UCxPQUFPLEdBQUFoQixTQUFBLENBQUFrRCxNQUFBLFFBQUFsRCxTQUFBLFFBQUF3UCxTQUFBLEdBQUF4UCxTQUFBLE1BQUcsQ0FBQyxDQUFDO0VBQ3BGK1Asc0RBQVksQ0FBQ25QLFNBQVMsQ0FBQztFQUN2QixJQUFJNUIsTUFBTSxDQUFDd0MsSUFBSSxFQUFFO0lBQ2IsTUFBTSxJQUFJcEMsS0FBSyxDQUFDLHNEQUFzRCxDQUFDO0VBQzNFO0VBQ0E0RSw0RUFBbUIsQ0FBQ3BELFNBQVMsQ0FBQztFQUM5QixJQUFJLENBQUM4Rix5RUFBcUIsQ0FBQzdGLFdBQVcsQ0FBQyxFQUFFO0lBQ3JDRSxvQkFBb0IsR0FBRyxLQUFLO0VBQ2hDO0VBQ0F5RixxRUFBaUIsQ0FBQ0UseUVBQXFCLENBQUM3RixXQUFXLENBQUMsSUFBSSxDQUFDRSxvQkFBb0IsQ0FBQztFQUM5RW9PLG9FQUFlLENBQUMsQ0FBQztFQUNqQixJQUFJc0Isb0JBQW9CO0VBQ3hCLFFBQVE3UCxTQUFTO0lBQ2IsS0FBSyxPQUFPO01BQ1I2UCxvQkFBb0IsR0FBRyxPQUFPO01BQzlCO0lBQ0osS0FBSyxLQUFLO01BQ05BLG9CQUFvQixHQUFHLE1BQU07TUFDN0I7SUFDSixLQUFLLE9BQU87SUFDWjtNQUNJQSxvQkFBb0IsR0FBRyxNQUFNO01BQzdCO0VBQ1I7RUFDQSxJQUFJMUksU0FBUztFQUNiLElBQU0ySSxvQkFBb0IsR0FBRyxFQUFBaEosZ0JBQUEsR0FBQTFJLE1BQU0sQ0FBQzRJLFFBQVEsY0FBQUYsZ0JBQUEsZ0JBQUFBLGdCQUFBLEdBQWZBLGdCQUFBLENBQWlCaUosTUFBTSxjQUFBakosZ0JBQUEsZ0JBQUFBLGdCQUFBLEdBQXZCQSxnQkFBQSxDQUF5QmtKLEtBQUssY0FBQWxKLGdCQUFBLHVCQUE5QkEsZ0JBQUEsQ0FBZ0NtSiwrQkFBK0IsTUFBSyxTQUFTO0VBQzFHL00sc0RBQUcsQ0FBQyxLQUFLLGdCQUFBekUsTUFBQSxDQUFnQnVCLFNBQVMsQ0FBRSxDQUFDO0VBQ3JDa0Qsc0RBQUcsQ0FBQyxLQUFLLDJCQUFBekUsTUFBQSxDQUEyQm9SLG9CQUFvQixDQUFFLENBQUM7RUFDM0QsSUFBTWhPLFdBQVcsSUFBQStOLGlCQUFBLEdBQUd4UixNQUFNLENBQUM0SSxRQUFRLGNBQUE0SSxpQkFBQSxnQkFBQUEsaUJBQUEsR0FBZkEsaUJBQUEsQ0FBaUJHLE1BQU0sY0FBQUgsaUJBQUEsZ0JBQUFBLGlCQUFBLEdBQXZCQSxpQkFBQSxDQUF5Qk0sSUFBSSxjQUFBTixpQkFBQSx1QkFBN0JBLGlCQUFBLENBQStCN04sT0FBTztFQUMxRDNELE1BQU0sQ0FBQytSLFNBQVMsR0FBRyxFQUFFO0VBQ3JCL1IsTUFBTSxDQUFDd0MsSUFBSSxHQUFHO0lBQ1ZtUCxNQUFNLEVBQUU7TUFDSkssWUFBWSxFQUFFeEgsK0RBQVE7TUFDdEJ5SCxTQUFTLEVBQUUvSCxpRUFBVTtNQUNyQmdJLFVBQVUsRUFBRWhCLGFBQWEsQ0FBQ3RQLFNBQVMsRUFBRUcsb0JBQW9CLENBQUM7TUFDMURvUSxZQUFZLEVBQUVsQixlQUFlLENBQUNyUCxTQUFTLEVBQUVHLG9CQUFvQixDQUFDO01BQzlEcVEsUUFBUSxFQUFFLElBQUk7TUFDZEMsS0FBSyxFQUFFLElBQUk7TUFDWEMsZUFBZSxFQUFFO1FBQ2IxUSxTQUFTO1FBQ1QyUSxXQUFXLEVBQUUvTyxvRUFBaUIsQ0FBQ0MsV0FBVztNQUM5QyxDQUFDO01BQ0R6QixPQUFPLEVBQUE0TixhQUFBLENBQUFBLGFBQUEsS0FBTzVOLE9BQU87UUFBRXdRLGNBQWMsRUFBRSxDQUFFLGVBQWUsSUFBSUMsSUFBSSxDQUFDLENBQUMsRUFBRUMsT0FBTyxDQUFDO01BQUMsRUFBRTtNQUMvRTtNQUNBQyxNQUFNLEVBQUU7UUFDSkMsY0FBYyxFQUFFQSxDQUFDQyxZQUFZLEVBQUVuSCxXQUFXLEVBQUVzQyxTQUFTLEtBQUs7VUFDdERsSixzREFBRyxDQUFDLEtBQUssb0JBQUF6RSxNQUFBLENBQW9Cd1MsWUFBWSxDQUFFLENBQUM7VUFDNUMsSUFBSUEsWUFBWSxJQUFJcEIsb0JBQW9CLEVBQUU7WUFDdEMzSCw4RUFBK0IsQ0FBQ2dFLElBQUksQ0FBQ0ssU0FBUyxDQUFDO2NBQzNDMkUsRUFBRSxFQUFFRCxZQUFZO2NBQ2hCRSxFQUFFLEVBQUV0QixvQkFBb0I7Y0FDeEJ1QixVQUFVLEVBQUVuUjtZQUNoQixDQUFDLENBQUMsQ0FBQztZQUNIaUQsc0RBQUcsQ0FBQyxLQUFLLDRDQUFBekUsTUFBQSxDQUE0Q3dTLFlBQVksY0FBQXhTLE1BQUEsQ0FBV29SLG9CQUFvQixNQUFHLENBQUM7WUFDcEc7VUFDSjtVQUNBM00sc0RBQUcsQ0FBQyxLQUFLLGlCQUFBekUsTUFBQSxDQUFpQnFMLFdBQVcsQ0FBRSxDQUFDO1VBQ3hDNUcsc0RBQUcsQ0FBQyxLQUFLLGVBQUF6RSxNQUFBLENBQWUyTixTQUFTLENBQUUsQ0FBQztVQUNwQzdNLGtEQUFJLENBQUMsaUJBQWlCLENBQUM7VUFDdkI4UixVQUFVLENBQUM5QyxnRUFBZSxFQUFFLENBQUMsQ0FBQztRQUNsQyxDQUFDO1FBQ0QrQyxjQUFjLEVBQUdMLFlBQVksSUFBSztVQUM5Qi9OLHNEQUFHLENBQUMsS0FBSyxvQkFBQXpFLE1BQUEsQ0FBb0J3UyxZQUFZLENBQUUsQ0FBQztVQUM1QyxJQUFJQSxZQUFZLElBQUlwQixvQkFBb0IsRUFBRTtZQUN0QztVQUNKO1VBQ0F0USxrREFBSSxDQUFDLGtCQUFrQixDQUFDO1FBQzVCLENBQUM7UUFDRGdTLG9CQUFvQixFQUFFQSxDQUFDTixZQUFZLEVBQUUxRyxJQUFJLEtBQUs7VUFDMUNySCxzREFBRyxDQUFDLEtBQUssMEJBQUF6RSxNQUFBLENBQTBCd1MsWUFBWSxDQUFFLENBQUM7VUFDbEQsSUFBSTFHLElBQUksQ0FBQ3BELFNBQVMsS0FBSyxDQUFDLEVBQUU7WUFDdEJBLFNBQVMsR0FBR29ELElBQUksQ0FBQ3BELFNBQVM7WUFDMUJjLHNFQUF1QixDQUFDZix1RUFBd0IsQ0FBQ0MsU0FBUyxDQUFDcUssUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1VBQzNFO1VBQ0F0TyxzREFBRyxDQUFDLEtBQUssRUFBRSx1QkFBdUIsRUFBRXFILElBQUksQ0FBQztVQUN6QyxJQUFJMEcsWUFBWSxJQUFJcEIsb0JBQW9CLEVBQUU7WUFDdEM7VUFDSjtVQUNBLEtBQUtULDZCQUE2QixDQUFDN0UsSUFBSSxDQUFDcEQsU0FBUyxLQUFLLENBQUMsQ0FBQztRQUM1RCxDQUFDO1FBQ0RzSyxxQkFBcUIsRUFBRUEsQ0FBQ1IsWUFBWSxFQUFFUyxTQUFTLEVBQUVDLFlBQVksS0FBSztVQUM5RHpPLHNEQUFHLENBQUMsS0FBSyx5Q0FBQXpFLE1BQUEsQ0FBeUN3UyxZQUFZLENBQUUsQ0FBQztVQUNqRSxJQUFJQSxZQUFZLElBQUlwQixvQkFBb0IsRUFBRTtZQUN0QztVQUNKO1VBQ0EzTSxzREFBRyxDQUFDLEtBQUssc0NBQUF6RSxNQUFBLENBQXNDaVQsU0FBUyxDQUFFLENBQUM7VUFDM0R4TyxzREFBRyxDQUFDLEtBQUssMkNBQUF6RSxNQUFBLENBQTJDa1QsWUFBWSxDQUFFLENBQUM7VUFDbkV0Syx3RUFBeUIsQ0FBQ3NLLFlBQVksRUFBRXpLLHVFQUF3QixDQUFDQyxTQUFTLENBQUNxSyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7VUFDdkYsSUFBSUcsWUFBWSxLQUFLL0ssNkVBQXNCLENBQUNZLFNBQVMsSUFBSW1LLFlBQVksS0FBSy9LLDZFQUFzQixDQUFDYSxTQUFTLElBQUlrSyxZQUFZLEtBQUsvSyw2RUFBc0IsQ0FBQ2MsT0FBTyxFQUFFO1lBQzNKMkosVUFBVSxDQUFDOUMsZ0VBQWUsRUFBRSxDQUFDLENBQUM7VUFDbEM7UUFDSixDQUFDO1FBQ0RxRCxzQkFBc0IsRUFBRSxTQUFBQSxDQUFVWCxZQUFZLEVBQUVZLE1BQU0sRUFBRTtVQUNwRDNPLHNEQUFHLENBQUMsS0FBSywwQ0FBQXpFLE1BQUEsQ0FBMEN3UyxZQUFZLENBQUUsQ0FBQztVQUNsRSxJQUFJQSxZQUFZLElBQUlwQixvQkFBb0IsRUFBRTtZQUN0QztVQUNKO1VBQ0EzTSxzREFBRyxDQUFDLEtBQUssNEJBQUF6RSxNQUFBLENBQTRCb1QsTUFBTSxDQUFFLENBQUM7UUFDbEQsQ0FBQztRQUNEQyxvQkFBb0IsRUFBRSxTQUFBQSxDQUFVYixZQUFZLEVBQUVjLEdBQUcsRUFBRTtVQUMvQzdPLHNEQUFHLENBQUMsS0FBSywwQkFBQXpFLE1BQUEsQ0FBMEJ3UyxZQUFZLENBQUUsQ0FBQztVQUNsRCxJQUFJQSxZQUFZLElBQUlwQixvQkFBb0IsRUFBRTtZQUN0QztVQUNKO1VBQ0EzTSxzREFBRyxDQUFDLEtBQUssMEJBQUF6RSxNQUFBLENBQTBCc1QsR0FBRyxDQUFFLENBQUM7UUFDN0MsQ0FBQztRQUNEQyxVQUFVLEVBQUUsU0FBQUEsQ0FBVWYsWUFBWSxFQUFFO1VBQ2hDL04sc0RBQUcsQ0FBQyxLQUFLLGdCQUFBekUsTUFBQSxDQUFnQndTLFlBQVksQ0FBRSxDQUFDO1VBQ3hDLElBQUlBLFlBQVksSUFBSXBCLG9CQUFvQixFQUFFO1lBQ3RDO1VBQ0o7UUFDSixDQUFDO1FBQ0RvQyxpQkFBaUIsRUFBRSxTQUFBQSxDQUFBLEVBQVk7VUFDM0IvTyxzREFBRyxDQUFDLEtBQUssRUFBRSxtQkFBbUIsQ0FBQztRQUNuQyxDQUFDO1FBQ0RnUCxPQUFPLEVBQUUsU0FBQUEsQ0FBVWpCLFlBQVksRUFBRWtCLFNBQVMsRUFBRUMsV0FBVyxFQUFFQyxTQUFTLEVBQUU7VUFDaEVuUCxzREFBRyxDQUFDLEtBQUssZ0JBQUF6RSxNQUFBLENBQWdCd1MsWUFBWSxDQUFFLENBQUM7VUFDeEMvTixzREFBRyxDQUFDLEtBQUssZ0JBQUF6RSxNQUFBLENBQWdCMFQsU0FBUyxDQUFFLENBQUM7VUFDckMsSUFBSWxCLFlBQVksSUFBSXBCLG9CQUFvQixFQUFFO1lBQ3RDO1VBQ0o7VUFDQTNNLHNEQUFHLENBQUMsS0FBSyxFQUFFa1AsV0FBVyxDQUFDO1VBQ3ZCbFAsc0RBQUcsQ0FBQyxLQUFLLGdCQUFBekUsTUFBQSxDQUFnQjRULFNBQVMsQ0FBRSxDQUFDO1FBQ3pDO01BQ0o7SUFDSjtFQUNKLENBQUM7RUFDRCxJQUFJdkMsb0JBQW9CLEVBQUU7SUFDdEIxUixNQUFNLENBQUN3QyxJQUFJLENBQUNtUCxNQUFNLENBQUNPLFVBQVUsR0FBR2hCLGFBQWEsQ0FBQ3RQLFNBQVMsRUFBRUcsb0JBQW9CLENBQUM7RUFDbEY7RUFDQSxRQUFRSCxTQUFTO0lBQ2IsS0FBSyxPQUFPO01BQ1I1QixNQUFNLENBQUN3QyxJQUFJLENBQUNtUCxNQUFNLENBQUNsUCxJQUFJLEdBQUc7UUFDdEI2UCxlQUFlLEVBQUU7VUFDYjFRLFNBQVM7VUFDVDJRLFdBQVcsRUFBRS9PLG9FQUFpQixDQUFDQyxXQUFXLENBQUM7VUFDM0N5USxNQUFNLEVBQUV4TSx5RUFBcUIsQ0FBQzdGLFdBQVcsQ0FBQztVQUMxQ0M7UUFDSjtNQUNKLENBQUM7TUFDRDtJQUNKLEtBQUssT0FBTztNQUNSOUIsTUFBTSxDQUFDd0MsSUFBSSxDQUFDbVAsTUFBTSxDQUFDL08sS0FBSyxHQUFHO1FBQ3ZCMFAsZUFBZSxFQUFFO1VBQ2IxUTtRQUNKO01BQ0osQ0FBQztNQUNEO0lBQ0osS0FBSyxLQUFLO01BQ041QixNQUFNLENBQUN3QyxJQUFJLENBQUNtUCxNQUFNLENBQUM5TyxJQUFJLEdBQUc7UUFDdEJ5UCxlQUFlLEVBQUU7VUFDYjFRO1FBQ0o7TUFDSixDQUFDO01BQ0Q7RUFDUjtFQUNBLElBQU11UyxLQUFLLEdBQUdsUixRQUFRLENBQUNtUixhQUFhLENBQUMsUUFBUSxDQUFDO0VBQzlDRCxLQUFLLENBQUM1UCxFQUFFLEdBQUcsaUJBQWlCO0VBQzVCNFAsS0FBSyxDQUFDRSxnQkFBZ0IsQ0FBQyxNQUFNLEVBQUUsTUFBTTtJQUNqQyxJQUFJOUMscUJBQXFCLENBQUMxUCxXQUFXLEVBQUVFLG9CQUFvQixDQUFDLEVBQUU7TUFDMURnSixxRUFBZSxDQUFDLENBQUMsQ0FBQ3BFLElBQUksQ0FBQyxNQUFNO1FBQUEsSUFBQXpFLFlBQUEsRUFBQW9TLHFCQUFBO1FBQ3pCLENBQUFwUyxZQUFBLEdBQUFsQyxNQUFNLENBQUN3QyxJQUFJLGNBQUFOLFlBQUEsZ0JBQUFvUyxxQkFBQSxHQUFYcFMsWUFBQSxDQUFhcVMsZ0JBQWdCLGNBQUFELHFCQUFBLGVBQTdCQSxxQkFBQSxDQUFBM1IsSUFBQSxDQUFBVCxZQUFnQyxDQUFDO01BQ3JDLENBQUMsQ0FBQyxDQUFDeU8sS0FBSyxDQUFFNkQsS0FBSyxJQUFLO1FBQ2hCMVAsc0RBQUcsQ0FBQyxLQUFLLG9DQUFBekUsTUFBQSxDQUFvQ21VLEtBQUssQ0FBRSxDQUFDO01BQ3pELENBQUMsQ0FBQztJQUNOLENBQUMsTUFDSTtNQUFBLElBQUFwUyxhQUFBLEVBQUFxUyxxQkFBQTtNQUNELENBQUFyUyxhQUFBLEdBQUFwQyxNQUFNLENBQUN3QyxJQUFJLGNBQUFKLGFBQUEsZ0JBQUFxUyxxQkFBQSxHQUFYclMsYUFBQSxDQUFhbVMsZ0JBQWdCLGNBQUFFLHFCQUFBLGVBQTdCQSxxQkFBQSxDQUFBOVIsSUFBQSxDQUFBUCxhQUFnQyxDQUFDO0lBQ3JDO0VBQ0osQ0FBQyxDQUFDO0VBQ0YrUixLQUFLLENBQUNPLEdBQUcsTUFBQXJVLE1BQUEsQ0FBTW1LLCtEQUFRLGlEQUE4QztFQUNyRXZILFFBQVEsQ0FBQ2lMLElBQUksQ0FBQ3lHLFdBQVcsQ0FBQ1IsS0FBSyxDQUFDO0FBQ3BDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3BOb0Q7QUFDUjtBQUNZO0FBQ3pELElBQU1wRCxZQUFZLEdBQUluUCxTQUFTLElBQUs7RUFDaEMsUUFBUUEsU0FBUztJQUNiLEtBQUssT0FBTztNQUNSaVQsMERBQVUsQ0FBQyxDQUFDO01BQ1o7SUFDSixLQUFLLE9BQU87TUFDUkQsa0VBQWMsQ0FBQyxDQUFDO01BQ2hCO0lBQ0osS0FBSyxLQUFLO01BQ05FLHNFQUFnQixDQUFDLENBQUM7TUFDbEI7RUFDUjtBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ2ZELElBQU1GLGNBQWMsR0FBR0EsQ0FBQSxLQUFNO0VBQ3pCNVUsTUFBTSxDQUFDK1UsY0FBYyxHQUFHLFVBQVVDLENBQUMsRUFBRTtJQUNqQyxJQUFJLENBQUNoVixNQUFNLENBQUNpVixNQUFNLENBQUNELENBQUMsQ0FBQyxFQUNqQixJQUFJL1IsUUFBUSxDQUFDaUwsSUFBSSxFQUFFO01BQ2YsSUFBSWdILENBQUMsR0FBR2pTLFFBQVEsQ0FBQ21SLGFBQWEsQ0FBQyxRQUFRLENBQUM7TUFDeENjLENBQUMsQ0FBQ0MsS0FBSyxDQUFDQyxPQUFPLEdBQUcsY0FBYyxFQUFFRixDQUFDLENBQUN2SixJQUFJLEdBQUdxSixDQUFDLEVBQUUvUixRQUFRLENBQUNpTCxJQUFJLENBQUN5RyxXQUFXLENBQUNPLENBQUMsQ0FBQztJQUM5RSxDQUFDLE1BRUdsVixNQUFNLENBQUNpVCxVQUFVLENBQUNqVCxNQUFNLENBQUMrVSxjQUFjLEVBQUUsRUFBRSxFQUFFQyxDQUFDLENBQUM7RUFDM0QsQ0FBQyxFQUFFaFYsTUFBTSxDQUFDcVYsVUFBVSxHQUFHLFlBQVk7SUFDL0IsSUFBSUwsQ0FBQyxHQUFHaFUsU0FBUztJQUNqQixJQUFJc1UsS0FBSyxDQUFDQyxLQUFLLEdBQUdELEtBQUssQ0FBQ0MsS0FBSyxJQUFJLEVBQUUsRUFBRUQsS0FBSyxDQUFDM0MsTUFBTSxHQUFHMkMsS0FBSyxDQUFDM0MsTUFBTSxJQUFJLEVBQUUsRUFBRSxDQUFDcUMsQ0FBQyxDQUFDOVEsTUFBTSxJQUFJLENBQUMsSUFBSThRLENBQUMsQ0FBQzlRLE1BQU0sSUFBSSxPQUFPLElBQUk4USxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQ2pILE9BQU9NLEtBQUssQ0FBQ0MsS0FBSztJQUN0QixJQUFJLENBQUMsSUFBSVAsQ0FBQyxDQUFDOVEsTUFBTSxJQUFJLFFBQVEsSUFBSThRLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFDakMsT0FBT00sS0FBSyxDQUFDM0MsTUFBTTtJQUN2QixJQUFJdUMsQ0FBQyxHQUFHRixDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUVRLENBQUMsR0FBR1IsQ0FBQyxDQUFDOVEsTUFBTSxHQUFHLENBQUMsR0FBRzhRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJO01BQUVTLENBQUMsR0FBR1QsQ0FBQyxDQUFDOVEsTUFBTSxHQUFHLENBQUMsR0FBRzhRLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJO0lBQzVFLElBQUksTUFBTSxLQUFLRSxDQUFDLEVBQ1pNLENBQUMsQ0FBQztNQUNFRSxVQUFVLEVBQUUsS0FBSztNQUNqQkMsU0FBUyxFQUFFLE1BQU07TUFDakJDLGdCQUFnQixFQUFFLFFBQVE7TUFDMUJ6RyxZQUFZLEVBQUUsV0FBVztNQUN6QjBHLGFBQWEsRUFBRSxDQUNYLFdBQVcsRUFDWCxXQUFXLEVBQ1gsU0FBUyxFQUNULFdBQVcsRUFDWCxVQUFVLEVBQ1YsVUFBVSxFQUNWLFdBQVcsRUFDWCxXQUFXLEVBQ1gsV0FBVyxDQUNkO01BQ0RDLEtBQUssRUFBRSxDQUFDO01BQ1JDLFdBQVcsRUFBRSxFQUFFO01BQ2ZDLGtCQUFrQixFQUFFLEVBQUU7TUFDdEJDLFNBQVMsRUFBRSxFQUFFO01BQ2JDLGNBQWMsRUFBRSxDQUFDO0lBQ3JCLENBQUMsRUFBRSxJQUFJLENBQUMsQ0FBQyxLQUNSLElBQUksa0JBQWtCLEtBQUtoQixDQUFDLEVBQUU7TUFDL0IsUUFBUSxJQUFJSSxLQUFLLEtBQUtBLEtBQUssQ0FBQ2EsTUFBTSxHQUFHLENBQUMsQ0FBQyxFQUFFYixLQUFLLENBQUNhLE1BQU0sRUFBRTtNQUN2RCxJQUFJQyxDQUFDLEdBQUdkLEtBQUssQ0FBQ2EsTUFBTTtNQUNwQmIsS0FBSyxDQUFDM0MsTUFBTSxDQUFDakMsSUFBSSxDQUFDO1FBQUVuTSxFQUFFLEVBQUU2UixDQUFDO1FBQUUvRyxRQUFRLEVBQUVtRyxDQUFDO1FBQUVhLFNBQVMsRUFBRVo7TUFBRSxDQUFDLENBQUMsRUFBRUQsQ0FBQyxDQUFDO1FBQ3ZEYyxTQUFTLEVBQUUsb0JBQW9CO1FBQy9CQyxVQUFVLEVBQUVILENBQUM7UUFDYmpLLElBQUksRUFBRSxJQUFJO1FBQ1ZxSyxRQUFRLEVBQUU7VUFDTmQsVUFBVSxFQUFFLEtBQUs7VUFDakJDLFNBQVMsRUFBRSxNQUFNO1VBQ2pCQyxnQkFBZ0IsRUFBRSxRQUFRO1VBQzFCekcsWUFBWSxFQUFFLFdBQVc7VUFDekIwRyxhQUFhLEVBQUUsQ0FDWCxXQUFXLEVBQ1gsV0FBVyxFQUNYLFNBQVMsRUFDVCxXQUFXLEVBQ1gsVUFBVSxFQUNWLFVBQVUsRUFDVixXQUFXLEVBQ1gsV0FBVyxFQUNYLFdBQVcsQ0FDZDtVQUNEQyxLQUFLLEVBQUUsQ0FBQztVQUNSQyxXQUFXLEVBQUUsRUFBRTtVQUNmQyxrQkFBa0IsRUFBRSxFQUFFO1VBQ3RCQyxTQUFTLEVBQUUsRUFBRTtVQUNiQyxjQUFjLEVBQUUsQ0FBQztRQUNyQjtNQUNKLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDWixDQUFDLE1BQ0ksSUFBSSxxQkFBcUIsS0FBS2hCLENBQUMsRUFBRTtNQUNsQyxLQUFLLElBQUl1QixDQUFDLEdBQUcsS0FBSyxFQUFFQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdwQixLQUFLLENBQUMzQyxNQUFNLENBQUN6TyxNQUFNLEVBQUV3UyxDQUFDLEVBQUUsRUFDbkQsSUFBSXBCLEtBQUssQ0FBQzNDLE1BQU0sQ0FBQytELENBQUMsQ0FBQyxDQUFDblMsRUFBRSxJQUFJa1IsQ0FBQyxFQUFFO1FBQ3pCSCxLQUFLLENBQUMzQyxNQUFNLENBQUNnRSxNQUFNLENBQUNELENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRUQsQ0FBQyxHQUFHLElBQUk7UUFDbkM7TUFDSjtNQUNKakIsQ0FBQyxDQUFDO1FBQ0VjLFNBQVMsRUFBRSxpQkFBaUI7UUFDNUJDLFVBQVUsRUFBRWQsQ0FBQztRQUNidEosSUFBSSxFQUFFc0ssQ0FBQztRQUNQRCxRQUFRLEVBQUU7VUFDTmQsVUFBVSxFQUFFLEtBQUs7VUFDakJDLFNBQVMsRUFBRSxNQUFNO1VBQ2pCQyxnQkFBZ0IsRUFBRSxRQUFRO1VBQzFCekcsWUFBWSxFQUFFLFdBQVc7VUFDekIwRyxhQUFhLEVBQUUsQ0FDWCxXQUFXLEVBQ1gsV0FBVyxFQUNYLFNBQVMsRUFDVCxXQUFXLEVBQ1gsVUFBVSxFQUNWLFVBQVUsRUFDVixXQUFXLEVBQ1gsV0FBVyxFQUNYLFdBQVcsQ0FDZDtVQUNEQyxLQUFLLEVBQUUsQ0FBQztVQUNSQyxXQUFXLEVBQUUsRUFBRTtVQUNmQyxrQkFBa0IsRUFBRSxFQUFFO1VBQ3RCQyxTQUFTLEVBQUUsRUFBRTtVQUNiQyxjQUFjLEVBQUUsQ0FBQztRQUNyQjtNQUNKLENBQUMsRUFBRSxJQUFJLENBQUM7SUFDWixDQUFDLE1BRUcsWUFBWSxLQUFLaEIsQ0FBQyxHQUFHTSxDQUFDLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxHQUFHLFlBQVksS0FBS04sQ0FBQyxJQUFJLFVBQVUsS0FBS0EsQ0FBQyxHQUFHTSxDQUFDLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHRixLQUFLLENBQUNDLEtBQUssQ0FBQzdFLElBQUksQ0FBQyxFQUFFLENBQUNrRyxLQUFLLENBQUM3VixLQUFLLENBQUNpVSxDQUFDLENBQUMsQ0FBQztFQUMxSSxDQUFDLEVBQUVoVixNQUFNLENBQUM2VyxnQkFBZ0IsR0FBRyxVQUFVN0IsQ0FBQyxFQUFFO0lBQ3RDLElBQUlFLENBQUMsR0FBRyxRQUFRLElBQUksT0FBT0YsQ0FBQyxDQUFDN0ksSUFBSTtJQUNqQyxJQUFJO01BQ0EsSUFBSXFKLENBQUMsR0FBR04sQ0FBQyxHQUFHcEgsSUFBSSxDQUFDQyxLQUFLLENBQUNpSCxDQUFDLENBQUM3SSxJQUFJLENBQUMsR0FBRzZJLENBQUMsQ0FBQzdJLElBQUk7SUFDM0MsQ0FBQyxDQUNELE9BQU8ySyxFQUFFLEVBQUU7TUFDUHRCLENBQUMsR0FBRyxJQUFJO0lBQ1o7SUFDQSxJQUFJLFFBQVEsSUFBSSxPQUFPQSxDQUFDLElBQUksSUFBSSxLQUFLQSxDQUFDLElBQUksV0FBVyxJQUFJQSxDQUFDLEVBQUU7TUFDeEQsSUFBSUMsQ0FBQyxHQUFHRCxDQUFDLENBQUN1QixTQUFTO01BQ25CL1csTUFBTSxDQUFDc1YsS0FBSyxDQUFDRyxDQUFDLENBQUM3VixPQUFPLEVBQUUsVUFBVW9YLEVBQUUsRUFBRVosQ0FBQyxFQUFFO1FBQ3JDLElBQUlLLENBQUMsR0FBRztVQUNKUSxXQUFXLEVBQUU7WUFDVEMsV0FBVyxFQUFFRixFQUFFO1lBQ2Y3VyxPQUFPLEVBQUVpVyxDQUFDO1lBQ1ZlLE1BQU0sRUFBRTFCLENBQUMsQ0FBQzBCO1VBQ2Q7UUFDSixDQUFDO1FBQ0RuQyxDQUFDLENBQUNvQyxNQUFNLENBQUNDLFdBQVcsQ0FBQ25DLENBQUMsR0FBR3BILElBQUksQ0FBQ0ssU0FBUyxDQUFDc0ksQ0FBQyxDQUFDLEdBQUdBLENBQUMsRUFBRSxHQUFHLENBQUM7TUFDeEQsQ0FBQyxFQUFFLFdBQVcsSUFBSWhCLENBQUMsR0FBR0EsQ0FBQyxDQUFDWSxTQUFTLEdBQUcsSUFBSSxFQUFFLFNBQVMsSUFBSVosQ0FBQyxHQUFHQSxDQUFDLENBQUN2USxPQUFPLEdBQUcsS0FBSyxDQUFDO0lBQ2pGO0VBQ0osQ0FBQyxFQUFFLE9BQU8sSUFBSWxGLE1BQU0sSUFBSSxVQUFVLElBQUksT0FBT0EsTUFBTSxDQUFDc1YsS0FBSyxLQUFLdFYsTUFBTSxDQUFDc1YsS0FBSyxHQUFHdFYsTUFBTSxDQUFDcVYsVUFBVSxFQUFFclYsTUFBTSxDQUFDcVUsZ0JBQWdCLENBQUMsU0FBUyxFQUFFclUsTUFBTSxDQUFDNlcsZ0JBQWdCLEVBQUUsS0FBSyxDQUFDLEVBQUU3VyxNQUFNLENBQUMrVSxjQUFjLENBQUMsY0FBYyxDQUFDLENBQUM7QUFDOU0sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDaElELElBQU1GLFVBQVUsR0FBR0EsQ0FBQSxLQUFNO0VBQ3JCLENBQUMsVUFBVUssQ0FBQyxFQUFFO0lBQ1YsSUFBSUYsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNWLFNBQVNvQixDQUFDQSxDQUFDa0IsQ0FBQyxFQUFFO01BQ1YsSUFBSXRDLENBQUMsQ0FBQ3NDLENBQUMsQ0FBQyxFQUNKLE9BQU90QyxDQUFDLENBQUNzQyxDQUFDLENBQUMsQ0FBQ0MsT0FBTztNQUN2QixJQUFJQyxDQUFDLEdBQUd4QyxDQUFDLENBQUNzQyxDQUFDLENBQUMsR0FBRztRQUFFWixDQUFDLEVBQUVZLENBQUM7UUFBRUcsQ0FBQyxFQUFFLEtBQUs7UUFBRUYsT0FBTyxFQUFFLENBQUM7TUFBRSxDQUFDO01BQzlDLE9BQU9yQyxDQUFDLENBQUNvQyxDQUFDLENBQUMsQ0FBQzNVLElBQUksQ0FBQzZVLENBQUMsQ0FBQ0QsT0FBTyxFQUFFQyxDQUFDLEVBQUVBLENBQUMsQ0FBQ0QsT0FBTyxFQUFFbkIsQ0FBQyxDQUFDLEVBQUVvQixDQUFDLENBQUNDLENBQUMsR0FBRyxJQUFJLEVBQUVELENBQUMsQ0FBQ0QsT0FBTztJQUN2RTtJQUNBbkIsQ0FBQyxDQUFDc0IsQ0FBQyxHQUFHeEMsQ0FBQyxFQUFFa0IsQ0FBQyxDQUFDdUIsQ0FBQyxHQUFHM0MsQ0FBQyxFQUFFb0IsQ0FBQyxDQUFDd0IsQ0FBQyxHQUFHLFVBQVVDLEVBQUUsRUFBRWYsRUFBRSxFQUFFUSxDQUFDLEVBQUU7TUFDekNsQixDQUFDLENBQUNvQixDQUFDLENBQUNLLEVBQUUsRUFBRWYsRUFBRSxDQUFDLElBQUloSCxNQUFNLENBQUNnSSxjQUFjLENBQUNELEVBQUUsRUFBRWYsRUFBRSxFQUFFO1FBQUVpQixVQUFVLEVBQUUsSUFBSTtRQUFFakwsR0FBRyxFQUFFd0s7TUFBRSxDQUFDLENBQUM7SUFDOUUsQ0FBQyxFQUFFbEIsQ0FBQyxDQUFDa0IsQ0FBQyxHQUFHLFVBQVVPLEVBQUUsRUFBRTtNQUNuQixXQUFXLElBQUksT0FBT0csTUFBTSxJQUFJQSxNQUFNLENBQUNDLFdBQVcsSUFBSW5JLE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQ0QsRUFBRSxFQUFFRyxNQUFNLENBQUNDLFdBQVcsRUFBRTtRQUNoR3JPLEtBQUssRUFBRTtNQUNYLENBQUMsQ0FBQyxFQUFFa0csTUFBTSxDQUFDZ0ksY0FBYyxDQUFDRCxFQUFFLEVBQUUsWUFBWSxFQUFFO1FBQUVqTyxLQUFLLEVBQUU7TUFBSyxDQUFDLENBQUM7SUFDaEUsQ0FBQyxFQUFFd00sQ0FBQyxDQUFDbEIsQ0FBQyxHQUFHLFVBQVUyQyxFQUFFLEVBQUVmLEVBQUUsRUFBRTtNQUN2QixJQUFJLENBQUMsR0FBR0EsRUFBRSxLQUFLZSxFQUFFLEdBQUd6QixDQUFDLENBQUN5QixFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBR2YsRUFBRSxFQUM5QixPQUFPZSxFQUFFO01BQ2IsSUFBSSxDQUFDLEdBQUdmLEVBQUUsSUFBSSxRQUFRLElBQUksT0FBT2UsRUFBRSxJQUFJQSxFQUFFLElBQUlBLEVBQUUsQ0FBQ0ssVUFBVSxFQUN0RCxPQUFPTCxFQUFFO01BQ2IsSUFBSVAsQ0FBQyxHQUFHLGVBQWdCeEgsTUFBTSxDQUFDcUksTUFBTSxDQUFDLElBQUksQ0FBQztNQUMzQyxJQUFJL0IsQ0FBQyxDQUFDa0IsQ0FBQyxDQUFDQSxDQUFDLENBQUMsRUFBRXhILE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQ1IsQ0FBQyxFQUFFLFNBQVMsRUFBRTtRQUM1Q1MsVUFBVSxFQUFFLElBQUk7UUFDaEJuTyxLQUFLLEVBQUVpTztNQUNYLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBR2YsRUFBRSxJQUFJLFFBQVEsSUFBSSxPQUFPZSxFQUFFLEVBQy9CLEtBQUssSUFBSUwsQ0FBQyxJQUFJSyxFQUFFLEVBQ1p6QixDQUFDLENBQUN3QixDQUFDLENBQUNOLENBQUMsRUFBRUUsQ0FBQyxFQUFFLFVBQVVZLEVBQUUsRUFBRTtRQUNwQixPQUFPUCxFQUFFLENBQUNPLEVBQUUsQ0FBQztNQUNqQixDQUFDLENBQUNDLElBQUksQ0FBQyxJQUFJLEVBQUViLENBQUMsQ0FBQyxDQUFDO01BQ3hCLE9BQU9GLENBQUM7SUFDWixDQUFDLEVBQUVsQixDQUFDLENBQUNBLENBQUMsR0FBRyxVQUFVeUIsRUFBRSxFQUFFO01BQ25CLElBQUlmLEVBQUUsR0FBR2UsRUFBRSxJQUFJQSxFQUFFLENBQUNLLFVBQVUsR0FBRyxZQUFZO1FBQ3ZDLE9BQU9MLEVBQUUsQ0FBQ1MsT0FBTztNQUNyQixDQUFDLEdBQUcsWUFBWTtRQUNaLE9BQU9ULEVBQUU7TUFDYixDQUFDO01BQ0QsT0FBT3pCLENBQUMsQ0FBQ3dCLENBQUMsQ0FBQ2QsRUFBRSxFQUFFLEdBQUcsRUFBRUEsRUFBRSxDQUFDLEVBQUVBLEVBQUU7SUFDL0IsQ0FBQyxFQUFFVixDQUFDLENBQUNvQixDQUFDLEdBQUcsVUFBVUssRUFBRSxFQUFFZixFQUFFLEVBQUU7TUFDdkIsT0FBT2hILE1BQU0sQ0FBQ3lJLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDN1YsSUFBSSxDQUFDa1YsRUFBRSxFQUFFZixFQUFFLENBQUM7SUFDdkQsQ0FBQyxFQUFFVixDQUFDLENBQUNaLENBQUMsR0FBRyxFQUFFLEVBQUVZLENBQUMsQ0FBQ0EsQ0FBQyxDQUFDWCxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQzNCLENBQUMsQ0FBQyxDQUNFLFVBQVVQLENBQUMsRUFBRUYsQ0FBQyxFQUFFb0IsQ0FBQyxFQUFFO0lBQ2YsSUFBSWtCLENBQUMsR0FBR2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDWmxCLENBQUMsQ0FBQ3FDLE9BQU8sR0FBRyxDQUFDRCxDQUFDLENBQUMsWUFBWTtNQUN2QixPQUFPLENBQUMsSUFBSXhILE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHLEVBQUU7UUFDdkNoTCxHQUFHLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1VBQ2IsT0FBTyxDQUFDO1FBQ1o7TUFDSixDQUFDLENBQUMsQ0FBQzJKLENBQUM7SUFDUixDQUFDLENBQUM7RUFDTixDQUFDLEVBQ0QsVUFBVXZCLENBQUMsRUFBRUYsQ0FBQyxFQUFFO0lBQ1pFLENBQUMsQ0FBQ3FDLE9BQU8sR0FBRyxVQUFVTSxFQUFFLEVBQUU7TUFDdEIsT0FBTyxRQUFRLElBQUksT0FBT0EsRUFBRSxHQUFHLElBQUksS0FBS0EsRUFBRSxHQUFHLFVBQVUsSUFBSSxPQUFPQSxFQUFFO0lBQ3hFLENBQUM7RUFDTCxDQUFDLEVBQ0QsVUFBVTNDLENBQUMsRUFBRUYsQ0FBQyxFQUFFO0lBQ1pFLENBQUMsQ0FBQ3FDLE9BQU8sR0FBRyxVQUFVTSxFQUFFLEVBQUU7TUFDdEIsSUFBSTtRQUNBLE9BQU8sQ0FBQyxDQUFDQSxFQUFFLENBQUMsQ0FBQztNQUNqQixDQUFDLENBQ0QsT0FBT1ksRUFBRSxFQUFFO1FBQ1AsT0FBTyxJQUFJO01BQ2Y7SUFDSixDQUFDO0VBQ0wsQ0FBQyxFQUNELFVBQVV2RCxDQUFDLEVBQUVGLENBQUMsRUFBRW9CLENBQUMsRUFBRTtJQUNmQSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsWUFBWTtNQUNkLElBQUksVUFBVSxJQUFJLE9BQU9wVyxNQUFNLENBQUMwWSxRQUFRLEVBQUU7UUFDdEMsSUFBSWIsRUFBRTtVQUFFZixFQUFFLEdBQUcsRUFBRTtVQUFFNkIsRUFBRSxHQUFHM1ksTUFBTTtVQUFFc1gsQ0FBQyxHQUFHcUIsRUFBRSxDQUFDMVYsUUFBUTtRQUM3QyxDQUFDMFYsRUFBRSxDQUFDRCxRQUFRLElBQUksU0FBU0QsRUFBRUEsQ0FBQSxFQUFHO1VBQzFCLElBQUlMLEVBQUUsR0FBRyxDQUFDLENBQUNPLEVBQUUsQ0FBQzFELE1BQU0sQ0FBQzJELGVBQWU7VUFDcEMsSUFBSSxDQUFDUixFQUFFLEVBQ0gsSUFBSWQsQ0FBQyxDQUFDcEosSUFBSSxFQUFFO1lBQ1IsSUFBSXNKLENBQUMsR0FBR0YsQ0FBQyxDQUFDbEQsYUFBYSxDQUFDLFFBQVEsQ0FBQztZQUNqQ29ELENBQUMsQ0FBQ3JDLEtBQUssQ0FBQ0MsT0FBTyxHQUFHLGNBQWMsRUFBRW9DLENBQUMsQ0FBQzdMLElBQUksR0FBRyxpQkFBaUIsRUFBRTJMLENBQUMsQ0FBQ3BKLElBQUksQ0FBQ3lHLFdBQVcsQ0FBQzZDLENBQUMsQ0FBQztVQUN2RixDQUFDLE1BRUd2RSxVQUFVLENBQUN3RixFQUFFLEVBQUUsQ0FBQyxDQUFDO1VBQ3pCLE9BQU8sQ0FBQ0wsRUFBRTtRQUNkLENBQUMsQ0FBQyxDQUFDLEtBQUtPLEVBQUUsQ0FBQ0QsUUFBUSxHQUFHLFlBQVk7VUFDOUIsS0FBSyxJQUFJRyxFQUFFLEdBQUc3WCxTQUFTLENBQUNrRCxNQUFNLEVBQUU0VSxFQUFFLEdBQUcsSUFBSUMsS0FBSyxDQUFDRixFQUFFLENBQUMsRUFBRXJCLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR3FCLEVBQUUsRUFBRXJCLENBQUMsRUFBRSxFQUNsRXNCLEVBQUUsQ0FBQ3RCLENBQUMsQ0FBQyxHQUFHeFcsU0FBUyxDQUFDd1csQ0FBQyxDQUFDO1VBQ3hCLElBQUksQ0FBQ3NCLEVBQUUsQ0FBQzVVLE1BQU0sRUFDVixPQUFPNFMsRUFBRTtVQUNiLElBQUksZ0JBQWdCLEtBQUtnQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQzFCQSxFQUFFLENBQUM1VSxNQUFNLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSzhVLFFBQVEsQ0FBQ0YsRUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxJQUFJLFNBQVMsSUFBSSxPQUFPQSxFQUFFLENBQUMsQ0FBQyxDQUFDLEtBQUtqQixFQUFFLEdBQUdpQixFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxJQUFJLE9BQU9BLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSUEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQ3pJLElBQUksTUFBTSxLQUFLQSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDdkIsSUFBSXBDLENBQUMsR0FBRztjQUNKdUMsV0FBVyxFQUFFcEIsRUFBRTtjQUNmcUIsU0FBUyxFQUFFLEtBQUs7Y0FDaEJDLFVBQVUsRUFBRTtZQUNoQixDQUFDO1lBQ0QsVUFBVSxJQUFJLE9BQU9MLEVBQUUsQ0FBQyxDQUFDLENBQUMsSUFBSUEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDcEMsQ0FBQyxFQUFFLElBQUksQ0FBQztVQUNoRCxDQUFDLE1BRUdJLEVBQUUsQ0FBQ3BHLElBQUksQ0FBQ29JLEVBQUUsQ0FBQztRQUNuQixDQUFDLEVBQUVILEVBQUUsQ0FBQ3RFLGdCQUFnQixDQUFDLFNBQVMsRUFBRSxVQUFVb0UsRUFBRSxFQUFFO1VBQzVDLElBQUlMLEVBQUUsR0FBRyxRQUFRLElBQUksT0FBT0ssRUFBRSxDQUFDdE0sSUFBSTtZQUFFMk0sRUFBRSxHQUFHLENBQUMsQ0FBQztVQUM1QyxJQUFJO1lBQ0FBLEVBQUUsR0FBR1YsRUFBRSxHQUFHdEssSUFBSSxDQUFDQyxLQUFLLENBQUMwSyxFQUFFLENBQUN0TSxJQUFJLENBQUMsR0FBR3NNLEVBQUUsQ0FBQ3RNLElBQUk7VUFDM0MsQ0FBQyxDQUNELE9BQU9pTixFQUFFLEVBQUUsQ0FDWDtVQUNBLElBQUk1QixDQUFDLEdBQUdzQixFQUFFLENBQUNPLFlBQVk7VUFDdkI3QixDQUFDLElBQUltQixFQUFFLENBQUNELFFBQVEsQ0FBQ2xCLENBQUMsQ0FBQzVYLE9BQU8sRUFBRTRYLENBQUMsQ0FBQ3RTLE9BQU8sRUFBRSxVQUFVMlQsRUFBRSxFQUFFUyxFQUFFLEVBQUU7WUFDckQsSUFBSTVDLENBQUMsR0FBRztjQUNKNkMsY0FBYyxFQUFFO2dCQUNackMsV0FBVyxFQUFFMkIsRUFBRTtnQkFDZjFZLE9BQU8sRUFBRW1aLEVBQUU7Z0JBQ1huQyxNQUFNLEVBQUVLLENBQUMsQ0FBQ0w7Y0FDZDtZQUNKLENBQUM7WUFDRGlCLEVBQUUsS0FBSzFCLENBQUMsR0FBRzVJLElBQUksQ0FBQ0ssU0FBUyxDQUFDdUksQ0FBQyxDQUFDLENBQUMsRUFBRStCLEVBQUUsQ0FBQ3JCLE1BQU0sQ0FBQ0MsV0FBVyxDQUFDWCxDQUFDLEVBQUUsR0FBRyxDQUFDO1VBQ2hFLENBQUMsRUFBRWMsQ0FBQyxDQUFDbkIsU0FBUyxDQUFDO1FBQ25CLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQztNQUNkO0lBQ0osQ0FBQyxDQUFDLENBQUM7RUFDUCxDQUFDLEVBQ0QsVUFBVW5CLENBQUMsRUFBRUYsQ0FBQyxFQUFFb0IsQ0FBQyxFQUFFO0lBQ2YsSUFBSWtCLENBQUMsR0FBR2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBRW9CLENBQUMsR0FBR3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ29ELENBQUM7TUFBRTlDLENBQUMsR0FBRytDLFFBQVEsQ0FBQ2xCLFNBQVM7TUFBRVosQ0FBQyxHQUFHakIsQ0FBQyxDQUFDdEQsUUFBUTtNQUFFc0csQ0FBQyxHQUFHLHNCQUFzQjtJQUM1RnBDLENBQUMsSUFBSSxFQUFFLE1BQU0sSUFBSVosQ0FBQyxDQUFDLElBQUljLENBQUMsQ0FBQ2QsQ0FBQyxFQUFFLE1BQU0sRUFBRTtNQUNoQ2lELFlBQVksRUFBRSxJQUFJO01BQ2xCN00sR0FBRyxFQUFFLFNBQUFBLENBQUEsRUFBWTtRQUNiLElBQUk7VUFDQSxPQUFPNkssQ0FBQyxDQUFDaFYsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDaVgsS0FBSyxDQUFDRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDbkMsQ0FBQyxDQUNELE9BQU83QixFQUFFLEVBQUU7VUFDUCxPQUFPLEVBQUU7UUFDYjtNQUNKO0lBQ0osQ0FBQyxDQUFDO0VBQ04sQ0FBQyxFQUNELFVBQVUzQyxDQUFDLEVBQUVGLENBQUMsRUFBRW9CLENBQUMsRUFBRTtJQUNmLElBQUlrQixDQUFDLEdBQUdsQixDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUVvQixDQUFDLEdBQUdwQixDQUFDLENBQUMsQ0FBQyxDQUFDO01BQUVNLENBQUMsR0FBR04sQ0FBQyxDQUFDLEVBQUUsQ0FBQztNQUFFdUIsQ0FBQyxHQUFHdkIsQ0FBQyxDQUFDLEVBQUUsQ0FBQztNQUFFc0QsQ0FBQyxHQUFHNUosTUFBTSxDQUFDZ0ksY0FBYztJQUN2RTlDLENBQUMsQ0FBQ3dFLENBQUMsR0FBR2xDLENBQUMsR0FBR29DLENBQUMsR0FBRyxVQUFVN0IsRUFBRSxFQUFFZixFQUFFLEVBQUU2QixFQUFFLEVBQUU7TUFDaEMsSUFBSWpDLENBQUMsQ0FBQ21CLEVBQUUsQ0FBQyxFQUFFZixFQUFFLEdBQUdhLENBQUMsQ0FBQ2IsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFSixDQUFDLENBQUNpQyxFQUFFLENBQUMsRUFBRW5CLENBQUMsRUFDakMsSUFBSTtRQUNBLE9BQU9rQyxDQUFDLENBQUM3QixFQUFFLEVBQUVmLEVBQUUsRUFBRTZCLEVBQUUsQ0FBQztNQUN4QixDQUFDLENBQ0QsT0FBT0YsRUFBRSxFQUFFLENBQ1g7TUFDSixJQUFJLEtBQUssSUFBSUUsRUFBRSxJQUFJLEtBQUssSUFBSUEsRUFBRSxFQUMxQixNQUFNa0IsU0FBUyxDQUFDLHlCQUF5QixDQUFDO01BQzlDLE9BQU8sT0FBTyxJQUFJbEIsRUFBRSxLQUFLZCxFQUFFLENBQUNmLEVBQUUsQ0FBQyxHQUFHNkIsRUFBRSxDQUFDL08sS0FBSyxDQUFDLEVBQUVpTyxFQUFFO0lBQ25ELENBQUM7RUFDTCxDQUFDLEVBQ0QsVUFBVTNDLENBQUMsRUFBRUYsQ0FBQyxFQUFFb0IsQ0FBQyxFQUFFO0lBQ2YsSUFBSWtCLENBQUMsR0FBR2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBRW9CLENBQUMsR0FBR3BCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBRU0sQ0FBQyxHQUFHTixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hDbEIsQ0FBQyxDQUFDcUMsT0FBTyxHQUFHLENBQUNELENBQUMsSUFBSSxDQUFDRSxDQUFDLENBQUMsWUFBWTtNQUM3QixPQUFPLENBQUMsSUFBSTFILE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQ3BCLENBQUMsQ0FBQyxLQUFLLENBQUMsRUFBRSxHQUFHLEVBQUU7UUFDN0M1SixHQUFHLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1VBQ2IsT0FBTyxDQUFDO1FBQ1o7TUFDSixDQUFDLENBQUMsQ0FBQzJKLENBQUM7SUFDUixDQUFDLENBQUM7RUFDTixDQUFDLEVBQ0QsVUFBVXZCLENBQUMsRUFBRUYsQ0FBQyxFQUFFb0IsQ0FBQyxFQUFFO0lBQ2YsSUFBSWtCLENBQUMsR0FBR2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBRW9CLENBQUMsR0FBR3BCLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFBRU0sQ0FBQyxHQUFHWSxDQUFDLENBQUNyVSxRQUFRO01BQUUwVSxDQUFDLEdBQUdILENBQUMsQ0FBQ2QsQ0FBQyxDQUFDLElBQUljLENBQUMsQ0FBQ2QsQ0FBQyxDQUFDdEMsYUFBYSxDQUFDO0lBQ3RFYyxDQUFDLENBQUNxQyxPQUFPLEdBQUcsVUFBVU0sRUFBRSxFQUFFO01BQ3RCLE9BQU9GLENBQUMsR0FBR2pCLENBQUMsQ0FBQ3RDLGFBQWEsQ0FBQ3lELEVBQUUsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUN2QyxDQUFDO0VBQ0wsQ0FBQyxFQUNELFVBQVUzQyxDQUFDLEVBQUVGLENBQUMsRUFBRW9CLENBQUMsRUFBRTtJQUNmLENBQUMsVUFBVVUsRUFBRSxFQUFFO01BQ1gsSUFBSTZCLEVBQUUsR0FBRyxTQUFBQSxDQUFVZCxFQUFFLEVBQUU7UUFDbkIsT0FBT0EsRUFBRSxJQUFJQSxFQUFFLENBQUNpQyxJQUFJLElBQUlBLElBQUksSUFBSWpDLEVBQUU7TUFDdEMsQ0FBQztNQUNEM0MsQ0FBQyxDQUFDcUMsT0FBTyxHQUFHb0IsRUFBRSxDQUFDLFFBQVEsSUFBSSxPQUFPb0IsVUFBVSxJQUFJQSxVQUFVLENBQUMsSUFBSXBCLEVBQUUsQ0FBQyxRQUFRLElBQUksT0FBTzNZLE1BQU0sSUFBSUEsTUFBTSxDQUFDLElBQUkyWSxFQUFFLENBQUMsUUFBUSxJQUFJLE9BQU9xQixJQUFJLElBQUlBLElBQUksQ0FBQyxJQUFJckIsRUFBRSxDQUFDLFFBQVEsSUFBSSxPQUFPN0IsRUFBRSxJQUFJQSxFQUFFLENBQUMsSUFBSTJDLFFBQVEsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDO0lBQ2pOLENBQUMsRUFBRTlXLElBQUksQ0FBQyxJQUFJLEVBQUV5VCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7RUFDdkIsQ0FBQyxFQUNELFVBQVVsQixDQUFDLEVBQUVGLENBQUMsRUFBRTtJQUNaLElBQUlvQixDQUFDO0lBQ0xBLENBQUMsR0FBRyxlQUFnQixZQUFZO01BQzVCLE9BQU8sSUFBSTtJQUNmLENBQUMsQ0FBQyxDQUFDO0lBQ0gsSUFBSTtNQUNBQSxDQUFDLEdBQUdBLENBQUMsSUFBSSxJQUFJcUQsUUFBUSxDQUFDLGFBQWEsQ0FBQyxDQUFDLENBQUM7SUFDMUMsQ0FBQyxDQUNELE9BQU81QixFQUFFLEVBQUU7TUFDUCxRQUFRLElBQUksT0FBTzdYLE1BQU0sS0FBS29XLENBQUMsR0FBR3BXLE1BQU0sQ0FBQztJQUM3QztJQUNBa1YsQ0FBQyxDQUFDcUMsT0FBTyxHQUFHbkIsQ0FBQztFQUNqQixDQUFDLEVBQ0QsVUFBVWxCLENBQUMsRUFBRUYsQ0FBQyxFQUFFb0IsQ0FBQyxFQUFFO0lBQ2YsSUFBSWtCLENBQUMsR0FBR2xCLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDWmxCLENBQUMsQ0FBQ3FDLE9BQU8sR0FBRyxVQUFVTSxFQUFFLEVBQUU7TUFDdEIsSUFBSSxDQUFDUCxDQUFDLENBQUNPLEVBQUUsQ0FBQyxFQUNOLE1BQU1nQyxTQUFTLENBQUNJLE1BQU0sQ0FBQ3BDLEVBQUUsQ0FBQyxHQUFHLG1CQUFtQixDQUFDO01BQ3JELE9BQU9BLEVBQUU7SUFDYixDQUFDO0VBQ0wsQ0FBQyxFQUNELFVBQVUzQyxDQUFDLEVBQUVGLENBQUMsRUFBRW9CLENBQUMsRUFBRTtJQUNmLElBQUlrQixDQUFDLEdBQUdsQixDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ1psQixDQUFDLENBQUNxQyxPQUFPLEdBQUcsVUFBVU0sRUFBRSxFQUFFZixFQUFFLEVBQUU7TUFDMUIsSUFBSSxDQUFDUSxDQUFDLENBQUNPLEVBQUUsQ0FBQyxFQUNOLE9BQU9BLEVBQUU7TUFDYixJQUFJYyxFQUFFLEVBQUVuQixDQUFDO01BQ1QsSUFBSVYsRUFBRSxJQUFJLFVBQVUsSUFBSSxRQUFRNkIsRUFBRSxHQUFHZCxFQUFFLENBQUN6RSxRQUFRLENBQUMsSUFBSSxDQUFDa0UsQ0FBQyxDQUFDRSxDQUFDLEdBQUdtQixFQUFFLENBQUNoVyxJQUFJLENBQUNrVixFQUFFLENBQUMsQ0FBQyxFQUNwRSxPQUFPTCxDQUFDO01BQ1osSUFBSSxVQUFVLElBQUksUUFBUW1CLEVBQUUsR0FBR2QsRUFBRSxDQUFDcUMsT0FBTyxDQUFDLElBQUksQ0FBQzVDLENBQUMsQ0FBQ0UsQ0FBQyxHQUFHbUIsRUFBRSxDQUFDaFcsSUFBSSxDQUFDa1YsRUFBRSxDQUFDLENBQUMsRUFDN0QsT0FBT0wsQ0FBQztNQUNaLElBQUksQ0FBQ1YsRUFBRSxJQUFJLFVBQVUsSUFBSSxRQUFRNkIsRUFBRSxHQUFHZCxFQUFFLENBQUN6RSxRQUFRLENBQUMsSUFBSSxDQUFDa0UsQ0FBQyxDQUFDRSxDQUFDLEdBQUdtQixFQUFFLENBQUNoVyxJQUFJLENBQUNrVixFQUFFLENBQUMsQ0FBQyxFQUNyRSxPQUFPTCxDQUFDO01BQ1osTUFBTXFDLFNBQVMsQ0FBQyx5Q0FBeUMsQ0FBQztJQUM5RCxDQUFDO0VBQ0wsQ0FBQyxDQUNKLENBQUM7QUFDTixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNoTkQsSUFBTS9FLGdCQUFnQixHQUFHQSxDQUFBLEtBQU07RUFDM0IsQ0FBQyxZQUFZO0lBQ1QsSUFBSUUsQ0FBQyxHQUFHLEtBQUs7SUFDYixJQUFJMkMsQ0FBQyxHQUFHM1gsTUFBTTtJQUNkLElBQUlrVixDQUFDLEdBQUdqUyxRQUFRO0lBQ2hCLFNBQVNxVSxDQUFDQSxDQUFBLEVBQUc7TUFDVCxJQUFJLENBQUNLLENBQUMsQ0FBQzFDLE1BQU0sQ0FBQyxpQkFBaUIsQ0FBQyxFQUFFO1FBQzlCLElBQUlDLENBQUMsQ0FBQ2hILElBQUksRUFBRTtVQUNSLElBQUl1SSxDQUFDLEdBQUd2QixDQUFDLENBQUNoSCxJQUFJO1VBQ2QsSUFBSTRJLEVBQUUsR0FBRzVCLENBQUMsQ0FBQ2QsYUFBYSxDQUFDLFFBQVEsQ0FBQztVQUNsQzBDLEVBQUUsQ0FBQzNCLEtBQUssQ0FBQ0MsT0FBTyxHQUFHLGNBQWM7VUFDakMwQixFQUFFLENBQUNuTCxJQUFJLEdBQUcsaUJBQWlCO1VBQzNCOEssQ0FBQyxDQUFDOUIsV0FBVyxDQUFDbUMsRUFBRSxDQUFDO1FBQ3JCLENBQUMsTUFDSTtVQUNEN0QsVUFBVSxDQUFDcUUsQ0FBQyxFQUFFLENBQUMsQ0FBQztRQUNwQjtNQUNKO0lBQ0o7SUFDQUEsQ0FBQyxDQUFDLENBQUM7SUFDSCxTQUFTOUIsQ0FBQ0EsQ0FBQSxFQUFHO01BQ1QsSUFBSWlCLENBQUMsR0FBR3pWLFNBQVM7TUFDakJmLFFBQVEsQ0FBQ3dXLENBQUMsR0FBR3hXLFFBQVEsQ0FBQ3dXLENBQUMsSUFBSSxFQUFFO01BQzdCLElBQUksQ0FBQ0EsQ0FBQyxDQUFDdlMsTUFBTSxFQUFFO1FBQ1gsT0FBT2pFLFFBQVEsQ0FBQ3dXLENBQUM7TUFDckIsQ0FBQyxNQUNJLElBQUlBLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxNQUFNLEVBQUU7UUFDdEJBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztVQUFFMEQsbUJBQW1CLEVBQUVuRixDQUFDO1VBQUVrRSxTQUFTLEVBQUU7UUFBTSxDQUFDLEVBQUUsSUFBSSxDQUFDO01BQzVELENBQUMsTUFDSTtRQUNEalosUUFBUSxDQUFDd1csQ0FBQyxDQUFDL0YsSUFBSSxDQUFDLEVBQUUsQ0FBQ2tHLEtBQUssQ0FBQzdWLEtBQUssQ0FBQzBWLENBQUMsQ0FBQyxDQUFDO01BQ3RDO0lBQ0o7SUFDQSxTQUFTZ0IsQ0FBQ0EsQ0FBQ0ksRUFBRSxFQUFFO01BQ1gsSUFBSWlCLEVBQUUsR0FBRyxPQUFPakIsRUFBRSxDQUFDMUwsSUFBSSxLQUFLLFFBQVE7TUFDcEMsSUFBSTtRQUNBLElBQUlzSyxDQUFDLEdBQUdxQyxFQUFFLEdBQUdoTCxJQUFJLENBQUNDLEtBQUssQ0FBQzhKLEVBQUUsQ0FBQzFMLElBQUksQ0FBQyxHQUFHMEwsRUFBRSxDQUFDMUwsSUFBSTtRQUMxQyxJQUFJc0ssQ0FBQyxDQUFDMkQsU0FBUyxFQUFFO1VBQ2IsSUFBSWhFLENBQUMsR0FBR0ssQ0FBQyxDQUFDMkQsU0FBUztVQUNuQnpDLENBQUMsQ0FBQzFYLFFBQVEsQ0FBQ21XLENBQUMsQ0FBQ3hXLE9BQU8sRUFBRXdXLENBQUMsQ0FBQ0MsU0FBUyxFQUFFLFVBQVVnRSxFQUFFLEVBQUV2RCxFQUFFLEVBQUU7WUFDakQsSUFBSXdELEVBQUUsR0FBRztjQUNMQyxXQUFXLEVBQUU7Z0JBQ1RyRCxXQUFXLEVBQUVtRCxFQUFFO2dCQUNmbGEsT0FBTyxFQUFFMlcsRUFBRTtnQkFDWEssTUFBTSxFQUFFZixDQUFDLENBQUNlO2NBQ2Q7WUFDSixDQUFDO1lBQ0RVLEVBQUUsQ0FBQ1QsTUFBTSxDQUFDQyxXQUFXLENBQUN5QixFQUFFLEdBQUdoTCxJQUFJLENBQUNLLFNBQVMsQ0FBQ21NLEVBQUUsQ0FBQyxHQUFHQSxFQUFFLEVBQUUsR0FBRyxDQUFDO1VBQzVELENBQUMsQ0FBQztRQUNOO01BQ0osQ0FBQyxDQUNELE9BQU9ELEVBQUUsRUFBRSxDQUNYO0lBQ0o7SUFDQSxJQUFJLE9BQU9wYSxRQUFRLEtBQUssVUFBVSxFQUFFO01BQ2hDMFgsQ0FBQyxDQUFDMVgsUUFBUSxHQUFHdVYsQ0FBQztNQUNkdlYsUUFBUSxDQUFDdWEsVUFBVSxHQUFHL0MsQ0FBQztNQUN2QkUsQ0FBQyxDQUFDdEQsZ0JBQWdCLENBQUMsU0FBUyxFQUFFb0QsQ0FBQyxFQUFFLEtBQUssQ0FBQztJQUMzQztFQUNKLENBQUMsRUFBRSxDQUFDO0FBQ1IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztBQzVERCxJQUFNOVgsR0FBRyxHQUFHQSxDQUFDQyxPQUFPLEVBQUUyTSxTQUFTLEVBQUVHLFVBQVUsRUFBRW5CLDRCQUE0QixLQUFLLElBQUkxTCxPQUFPLENBQUMsQ0FBQ0MsT0FBTyxFQUFFQyxNQUFNLEtBQUs7RUFDM0csSUFBSUMsTUFBTSxDQUFDMFksUUFBUSxFQUFFO0lBQ2pCMVksTUFBTSxDQUFDMFksUUFBUSxDQUFDOVksT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDTSxNQUFNLEVBQUVDLE9BQU8sS0FBS0EsT0FBTyxHQUFHTCxPQUFPLENBQUNJLE1BQU0sQ0FBQyxJQUMxRTtJQUNBSCxNQUFNLENBQUMsSUFBSUssS0FBSyxrQkFBQUMsTUFBQSxDQUFrQlQsT0FBTyxVQUFPLENBQUMsQ0FBQyxDQUFDLEVBQUUyTSxTQUFTLEVBQUVHLFVBQVUsRUFBRW5CLDRCQUE0QixDQUFDO0VBQzdHLENBQUMsTUFDSTtJQUNEeEwsTUFBTSxDQUFDLElBQUlLLEtBQUssQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO0VBQ3BEO0FBQ0osQ0FBQyxDQUFDO0FBQ0YsSUFBTXFhLFNBQVMsR0FBR0EsQ0FBQSxLQUFNOWEsR0FBRyxDQUFDLGtCQUFrQixDQUFDO0FBQy9DLElBQU0rYSx1QkFBdUIsR0FBR0EsQ0FBQSxLQUFNL2EsR0FBRyxDQUFDLHlCQUF5QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYSjtBQUNGO0FBQzlELElBQU1nYixlQUFlLEdBQUc7RUFDcEIsR0FBRyxFQUFFLEtBQUs7RUFDVixHQUFHLEVBQUUsS0FBSztFQUNWLEdBQUcsRUFBRSxLQUFLO0VBQ1YsR0FBRyxFQUFFLEtBQUs7RUFDVixHQUFHLEVBQUUsS0FBSztFQUNWLEdBQUcsRUFBRSxLQUFLO0VBQ1YsR0FBRyxFQUFFLEtBQUs7RUFDVixHQUFHLEVBQUUsS0FBSztFQUNWLEdBQUcsRUFBRSxLQUFLO0VBQ1YsSUFBSSxFQUFFLEtBQUs7RUFDWCxJQUFJLEVBQUU7QUFDVixDQUFDO0FBQ0QsSUFBTXBhLGVBQWU7RUFBQSxJQUFBQyxJQUFBLEdBQUFDLGlCQUFBLENBQUcsYUFBWTtJQUNoQyxJQUFNLENBQUNtYSxNQUFNLEVBQUVDLGFBQWEsQ0FBQyxTQUFTaGIsT0FBTyxDQUFDaWIsR0FBRyxDQUFDLENBQzlDTCxrREFBUyxDQUFDLENBQUMsRUFDWEMsZ0VBQXVCLENBQUMsQ0FBQyxDQUM1QixDQUFDO0lBQ0YsSUFBSSxPQUFPRSxNQUFNLEtBQUssV0FBVyxFQUFFO01BQUEsSUFBQUcsb0JBQUE7TUFDL0IsSUFBTWhXLGdCQUFnQixJQUFBZ1csb0JBQUEsR0FBRzlaLDRFQUFtQixDQUFDLENBQUMsY0FBQThaLG9CQUFBLGNBQUFBLG9CQUFBLEdBQUksV0FBVztNQUM3RCxNQUFNLElBQUkzYSxLQUFLLDZDQUFBQyxNQUFBLENBQTZDMEUsZ0JBQWdCLENBQUUsQ0FBQztJQUNuRjtJQUNBLElBQU00SyxRQUFRLEdBQUFDLGFBQUEsQ0FBQUEsYUFBQSxLQUNQK0ssZUFBZSxHQUNmQyxNQUFNLENBQUNJLE9BQU8sQ0FBQ3JMLFFBQVEsQ0FDN0I7SUFDRCxJQUFNO01BQUVYLFdBQVc7TUFBRWlLLFdBQVc7TUFBRWdDLFFBQVE7TUFBRUM7SUFBYSxDQUFDLEdBQUdOLE1BQU07SUFDbkUsSUFBTTtNQUFFTztJQUFPLENBQUMsR0FBR04sYUFBYTtJQUNoQyxJQUFNblcsY0FBYyxHQUFHb0wsTUFBTSxDQUFDQyxJQUFJLENBQUNvTCxNQUFNLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQ0MsTUFBTSxDQUFDLENBQUNDLEdBQUcsRUFBRUMsR0FBRztNQUFBLElBQUFDLFdBQUE7TUFBQSxPQUFBNUwsYUFBQSxDQUFBQSxhQUFBLEtBQVcwTCxHQUFHO1FBQUUsQ0FBQ0MsR0FBRyxJQUFBQyxXQUFBLEdBQUdMLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDLGNBQUFDLFdBQUEsdUJBQVhBLFdBQUEsQ0FBYUM7TUFBVztJQUFBLENBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUN6SCxPQUFPO01BQ0g5TCxRQUFRO01BQ1JYLFdBQVc7TUFDWHRLLGNBQWM7TUFDZHdXLFlBQVk7TUFDWmpDLFdBQVc7TUFDWGdDO0lBQ0osQ0FBQztFQUNMLENBQUM7RUFBQSxnQkF4QksxYSxlQUFlQSxDQUFBO0lBQUEsT0FBQUMsSUFBQSxDQUFBTyxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBd0JwQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkNELElBQU1yQixHQUFHLEdBQUdBLENBQUEsS0FBTSxJQUFJRSxPQUFPLENBQUVDLE9BQU8sSUFBSztFQUFBLElBQUFvQyxZQUFBO0VBQ3ZDLEtBQUFBLFlBQUEsR0FBSWxDLE1BQU0sQ0FBQ3dDLElBQUksY0FBQU4sWUFBQSxnQkFBQUEsWUFBQSxHQUFYQSxZQUFBLENBQWFVLEtBQUssY0FBQVYsWUFBQSxlQUFsQkEsWUFBQSxDQUFvQndaLGVBQWUsRUFBRTtJQUNyQzFiLE1BQU0sQ0FBQ3dDLElBQUksQ0FBQ0ksS0FBSyxDQUFDOFksZUFBZSxDQUFFQyxTQUFTLElBQUs7TUFDN0MsT0FBTzdiLE9BQU8sQ0FBQThQLGFBQUEsQ0FBQUEsYUFBQSxLQUFNK0wsU0FBUztRQUFFeE0sWUFBWSxFQUFFO01BQU8sRUFBRSxDQUFDO0lBQzNELENBQUMsQ0FBQztFQUNOLENBQUMsTUFDSTtJQUNEclAsT0FBTyxDQUFDO01BQ0o4YixPQUFPLEVBQUUsS0FBSztNQUNkalAsVUFBVSxFQUFFLEVBQUU7TUFDZHRCLE9BQU8sRUFBRSxFQUFFO01BQ1g4RCxZQUFZLEVBQUU7SUFDbEIsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDLENBQUM7QUFDRixJQUFNME0sWUFBWSxHQUFHQSxDQUFBLEtBQU1sYyxHQUFHLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZlE7QUFDeEMsSUFBTVksZUFBZTtFQUFBLElBQUFDLElBQUEsR0FBQUMsaUJBQUEsQ0FBRyxhQUFZO0lBQUEsSUFBQXFiLHFCQUFBO0lBQ2hDLElBQUkzWCxTQUFTLEdBQUcsS0FBSztJQUNyQixJQUFNNFgsU0FBUyxTQUFTRixxREFBWSxDQUFDLENBQUM7SUFDdEMxWCxTQUFTLEdBQUcsRUFBQTJYLHFCQUFBLEdBQUFDLFNBQVMsQ0FBQ3BQLFVBQVUsY0FBQW1QLHFCQUFBLGdCQUFBQSxxQkFBQSxHQUFwQkEscUJBQUEsQ0FBc0J4WCxJQUFJLENBQUVzSSxRQUFRLElBQUtBLFFBQVEsQ0FBQ29QLFFBQVEsS0FBSyxDQUFDLENBQUMsY0FBQUYscUJBQUEsdUJBQWpFQSxxQkFBQSxDQUFtRUcsU0FBUyxNQUFLLEtBQUs7SUFDbEcsT0FBTztNQUNIOVgsU0FBUztNQUNUZ0wsWUFBWSxFQUFFNE0sU0FBUyxDQUFDNU07SUFDNUIsQ0FBQztFQUNMLENBQUM7RUFBQSxnQkFSSzVPLGVBQWVBLENBQUE7SUFBQSxPQUFBQyxJQUFBLENBQUFPLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FRcEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVHlEO0FBQ1Y7QUFDRztBQUNJO0FBQzhCO0FBQ3JGLElBQU1zYixVQUFVLEdBQUc5YixJQUFBLElBQThEO0VBQUEsSUFBN0Q7SUFBRStiLE9BQU8sR0FBRyxFQUFFO0lBQUUzTyxZQUFZLEdBQUcsRUFBRTtJQUFFNE8sY0FBYyxHQUFHO0VBQUcsQ0FBQyxHQUFBaGMsSUFBQTtFQUN4RSxLQUFLLElBQU1tTCxJQUFJLElBQUk0USxPQUFPLEVBQUU7SUFDeEJMLHNFQUFZLENBQUM7TUFBRXZRO0lBQUssQ0FBQyxDQUFDO0VBQzFCO0VBQ0EsS0FBSyxJQUFNQSxLQUFJLElBQUlpQyxZQUFZLEVBQUU7SUFDN0J1Tyx3REFBTyxDQUFDTSxLQUFLLENBQUNDLE1BQU0sQ0FBQy9RLEtBQUksQ0FBQztFQUM5QjtFQUNBLEtBQUssSUFBTUEsTUFBSSxJQUFJNlEsY0FBYyxFQUFFO0lBQy9CTCx3REFBTyxDQUFDUSxPQUFPLENBQUNELE1BQU0sQ0FBQy9RLE1BQUksQ0FBQztFQUNoQztBQUNKLENBQUM7QUFDRCxJQUFNaVIscUJBQXFCLEdBQUk3WSxPQUFPLElBQUs7RUFDdkMrTCxNQUFNLENBQUNDLElBQUksQ0FBQ3FNLGtFQUFnQixDQUFDLENBQUMvTCxPQUFPLENBQUV2TSxNQUFNLElBQUs7SUFDOUMsSUFBTStZLGdCQUFnQixHQUFHaFosZ0VBQWEsQ0FBQ0MsTUFBTSxFQUFFQyxPQUFPLENBQUM7SUFDdkQsSUFBTStZLFVBQVUsR0FBR1Ysa0VBQWdCLENBQUN0WSxNQUFNLENBQUM7SUFDM0MsSUFBSSxDQUFDK1ksZ0JBQWdCLEVBQUU7TUFDbkJQLFVBQVUsQ0FBQ1EsVUFBVSxDQUFDO0lBQzFCO0VBQ0osQ0FBQyxDQUFDO0VBQ0ZoTixNQUFNLENBQUNpTixPQUFPLENBQUNWLDRFQUEwQixDQUFDLENBQUNoTSxPQUFPLENBQUM1RSxLQUFBO0lBQUEsSUFBQyxHQUFHcVIsVUFBVSxDQUFDLEdBQUFyUixLQUFBO0lBQUEsT0FBSzZRLFVBQVUsQ0FBQ1EsVUFBVSxDQUFDO0VBQUEsRUFBQztBQUNsRyxDQUFDO0FBQ0QsSUFBTWhYLHFCQUFxQixHQUFHQSxDQUFBLEtBQU07RUFDaENSLG9FQUFlLENBQUV2QixPQUFPLElBQUs7SUFDekIsSUFBSSxxQkFBcUIsSUFBSS9ELE1BQU0sRUFBRTtNQUNqQ2dkLG1CQUFtQixDQUFDLE1BQU07UUFDdEJKLHFCQUFxQixDQUFDN1ksT0FBTyxDQUFDO01BQ2xDLENBQUMsRUFBRTtRQUNDa1osT0FBTyxFQUFFO01BQ2IsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxNQUNJO01BQ0RMLHFCQUFxQixDQUFDN1ksT0FBTyxDQUFDO0lBQ2xDO0VBQ0osQ0FBQyxDQUFDO0FBQ04sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztBQ3ZDRCxJQUFNcVksZ0JBQWdCLEdBQUc7RUFDckJjLEVBQUUsRUFBRTtJQUNBdFAsWUFBWSxFQUFFLENBQUMsNEJBQTRCLEVBQUUsa0JBQWtCO0VBQ25FLENBQUM7RUFDRHVQLE1BQU0sRUFBRTtJQUNKdlAsWUFBWSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVE7RUFDckMsQ0FBQztFQUNEd1AsTUFBTSxFQUFFO0lBQ0piLE9BQU8sRUFBRSxDQUFDLFlBQVksQ0FBQztJQUN2QjNPLFlBQVksRUFBRSxDQUNWLHlCQUF5QixFQUN6QixZQUFZLEVBQ1osaUJBQWlCLEVBQ2pCLDRCQUE0QixFQUM1QixxQkFBcUI7RUFFN0IsQ0FBQztFQUNEeVAsUUFBUSxFQUFFO0lBQ05kLE9BQU8sRUFBRSxDQUFDLFVBQVUsRUFBRSxXQUFXO0VBQ3JDLENBQUM7RUFDRGUsS0FBSyxFQUFFO0lBQ0hmLE9BQU8sRUFBRSxDQUFDLGNBQWMsRUFBRSx1QkFBdUIsRUFBRSxzQkFBc0IsQ0FBQztJQUMxRTNPLFlBQVksRUFBRSxDQUNWLG9CQUFvQixFQUNwQixzQkFBc0IsRUFDdEIsa0JBQWtCLEVBQ2xCLHdCQUF3QjtFQUVoQyxDQUFDO0VBQ0QyUCxTQUFTLEVBQUU7SUFDUGhCLE9BQU8sRUFBRSxDQUFDLGNBQWMsQ0FBQztJQUN6QjNPLFlBQVksRUFBRSxDQUNWLHdCQUF3QixFQUN4QixTQUFTLEVBQ1QsZUFBZSxFQUNmLDBCQUEwQixFQUMxQixtQkFBbUIsRUFDbkIscUJBQXFCLEVBQ3JCLDJCQUEyQixFQUMzQixlQUFlLEVBQ2YsdUJBQXVCLEVBQ3ZCLGNBQWMsRUFDZCxtQkFBbUIsRUFDbkIsd0JBQXdCLEVBQ3hCLHdCQUF3QixFQUN4QiwyQkFBMkIsRUFDM0IsOEJBQThCLEVBQzlCLFFBQVEsQ0FDWDtJQUNENE8sY0FBYyxFQUFFLENBQUMsOEJBQThCO0VBQ25ELENBQUM7RUFDRGdCLFNBQVMsRUFBRTtJQUFFakIsT0FBTyxFQUFFLENBQUMsT0FBTyxFQUFFLFFBQVE7RUFBRTtBQUM5QyxDQUFDO0FBQ0QsSUFBTUYsMEJBQTBCLEdBQUc7RUFDL0Isa0JBQWtCLEVBQUU7SUFDaEJFLE9BQU8sRUFBRSxDQUFDLE1BQU0sRUFBRSxLQUFLO0VBQzNCO0FBQ0osQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6REQsSUFBTWtCLGNBQWMsR0FBRztFQUNuQjtFQUNBUCxFQUFFLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUNoQ1EsS0FBSyxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDbkNDLFNBQVMsRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ3ZDQyxLQUFLLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUNuQ1AsUUFBUSxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDdENELE1BQU0sRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ3BDLG1CQUFtQixFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDakQsb0JBQW9CLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUNsREksU0FBUyxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDdkNLLE1BQU0sRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ3BDQyxHQUFHLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUNqQ0MsR0FBRyxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDakNaLE1BQU0sRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ3BDRyxLQUFLLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUNuQ1UsYUFBYSxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDM0NDLE9BQU8sRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ3JDQyxPQUFPLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUNyQ3JWLEtBQUssRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ25Dc1YsS0FBSyxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDbkNDLEtBQUssRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ25DYixTQUFTLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUN2Q2MsUUFBUSxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDdENDLEVBQUUsRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ2hDQyxXQUFXLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUN6Q0MsTUFBTSxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDcENDLEtBQUssRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ25DQyxZQUFZLEVBQUUsQ0FBQywwQkFBMEIsQ0FBQztFQUMxQ0MsT0FBTyxFQUFFLENBQUMsMEJBQTBCLENBQUM7RUFDckNDLEtBQUssRUFBRSxDQUFDLDBCQUEwQixDQUFDO0VBQ25DLGdCQUFnQixFQUFFLENBQUMsMEJBQTBCO0FBQ2pELENBQUM7QUFDRCxJQUFNQyxZQUFZLEdBQUc7RUFDakJDLFNBQVMsRUFBRSxDQUFDLGtCQUFrQjtBQUNsQyxDQUFDO0FBQ0QsSUFBTUMsV0FBVyxHQUFHO0VBQ2hCQyxPQUFPLEVBQUUsQ0FBQyxrQkFBa0I7QUFDaEMsQ0FBQztBQUNELElBQU1wYixTQUFTLEdBQUFnTSxhQUFBLENBQUFBLGFBQUEsQ0FBQUEsYUFBQSxLQUNSNk4sY0FBYyxHQUNkb0IsWUFBWSxHQUNaRSxXQUFXLENBQ2pCOzs7Ozs7Ozs7Ozs7Ozs7OztBQzNDc0Q7QUFDQTtBQUN2RCxJQUFNdFUsU0FBUyxHQUFHakssSUFBQSxJQUFxQztFQUFBLElBQXBDO0lBQUVtTCxJQUFJO0lBQUV3VCxhQUFhLEdBQUc7RUFBTSxDQUFDLEdBQUEzZSxJQUFBO0VBQzlDLElBQU00ZSxjQUFjLEdBQUdGLGdFQUFlLENBQUNwUyxHQUFHLENBQUNuQixJQUFJLENBQUM7RUFDaEQsSUFBSXlULGNBQWMsRUFBRTtJQUNoQixPQUFPQSxjQUFjO0VBQ3pCO0VBQ0EsSUFBTSxDQUFDeFYsS0FBSyxDQUFDLEdBQUdxVixvRUFBZSxDQUFDdFQsSUFBSSxDQUFDO0VBQ3JDLElBQUkvQixLQUFLLEVBQUU7SUFDUCxJQUFJdVYsYUFBYSxFQUFFO01BQ2ZELGdFQUFlLENBQUNHLEdBQUcsQ0FBQzFULElBQUksRUFBRS9CLEtBQUssQ0FBQztJQUNwQztJQUNBLE9BQU9BLEtBQUs7RUFDaEI7RUFDQSxPQUFPLElBQUk7QUFDZixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNmRCxJQUFNcVYsZUFBZSxHQUFJdFQsSUFBSSxJQUFLO0VBQzlCLElBQU0yVCxNQUFNLE1BQUFqZixNQUFBLENBQU1zTCxJQUFJLE1BQUc7RUFDekIsSUFBTTRRLE9BQU8sR0FBR3RaLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDcWMsS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUMxQyxPQUFPaEQsT0FBTyxDQUFDbEIsTUFBTSxDQUFDLENBQUNDLEdBQUcsRUFBRXBZLE1BQU0sS0FBSztJQUNuQyxJQUFNc2MsYUFBYSxHQUFHdGMsTUFBTSxDQUFDdWMsSUFBSSxDQUFDLENBQUM7SUFDbkMsSUFBSUQsYUFBYSxDQUFDRSxVQUFVLENBQUNKLE1BQU0sQ0FBQyxFQUFFO01BQ2xDaEUsR0FBRyxDQUFDNUssSUFBSSxDQUFDOE8sYUFBYSxDQUFDRyxTQUFTLENBQUNMLE1BQU0sQ0FBQ3BiLE1BQU0sRUFBRXNiLGFBQWEsQ0FBQ3RiLE1BQU0sQ0FBQyxDQUFDO0lBQzFFO0lBQ0EsT0FBT29YLEdBQUc7RUFDZCxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBQ1YsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDVkQsSUFBTXNFLGNBQWMsR0FBRyxTQUFBQSxDQUFBLEVBQXVDO0VBQUEsSUFBQWxYLGdCQUFBO0VBQUEsSUFBdEM7SUFBRW1YLGdCQUFnQixHQUFHO0VBQU0sQ0FBQyxHQUFBN2UsU0FBQSxDQUFBa0QsTUFBQSxRQUFBbEQsU0FBQSxRQUFBd1AsU0FBQSxHQUFBeFAsU0FBQSxNQUFHLENBQUMsQ0FBQztFQUNyRCxJQUFNOGUsTUFBTSxHQUFHN2MsUUFBUSxDQUFDNmMsTUFBTSxJQUFJLEVBQUU7RUFDcEMsSUFBSUEsTUFBTSxLQUFLLFdBQVcsS0FBQXBYLGdCQUFBLEdBQUkxSSxNQUFNLENBQUM0SSxRQUFRLGNBQUFGLGdCQUFBLGdCQUFBQSxnQkFBQSxHQUFmQSxnQkFBQSxDQUFpQmlKLE1BQU0sY0FBQWpKLGdCQUFBLGdCQUFBQSxnQkFBQSxHQUF2QkEsZ0JBQUEsQ0FBeUJvSixJQUFJLGNBQUFwSixnQkFBQSxlQUE3QkEsZ0JBQUEsQ0FBK0JxWCxTQUFTLEVBQUU7SUFDcEUsT0FBT0QsTUFBTTtFQUNqQjtFQUNBLElBQUlELGdCQUFnQixFQUFFO0lBQ2xCLE9BQU8sQ0FBQyxFQUFFLEVBQUUsR0FBR0MsTUFBTSxDQUFDUCxLQUFLLENBQUMsR0FBRyxDQUFDLENBQUMzSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDb0osSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUN6RDtFQUNBLE9BQU9GLE1BQU0sQ0FBQ0csT0FBTyxDQUFDLHdCQUF3QixFQUFFLEdBQUcsQ0FBQztBQUN4RCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNURCxJQUFNZixlQUFlLEdBQUcsZUFBZ0IsSUFBSXJVLEdBQUcsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDQUk7QUFDckQsSUFBTXFSLFlBQVksR0FBRzFiLElBQUEsSUFBeUM7RUFBQSxJQUF4QztJQUFFbUwsSUFBSTtJQUFFdVUsaUJBQWlCLEdBQUc7RUFBTSxDQUFDLEdBQUExZixJQUFBO0VBQ3JELElBQU0yZixPQUFPLEdBQUcsd0NBQXdDO0VBQ3hELElBQU1DLElBQUksR0FBRyxTQUFTO0VBQ3RCbmQsUUFBUSxDQUFDQyxNQUFNLE1BQUE3QyxNQUFBLENBQU1zTCxJQUFJLFFBQUF0TCxNQUFBLENBQUsrZixJQUFJLEVBQUEvZixNQUFBLENBQUc4ZixPQUFPLENBQUU7RUFDOUMsSUFBSSxDQUFDRCxpQkFBaUIsRUFBRTtJQUNwQmpkLFFBQVEsQ0FBQ0MsTUFBTSxNQUFBN0MsTUFBQSxDQUFNc0wsSUFBSSxRQUFBdEwsTUFBQSxDQUFLK2YsSUFBSSxFQUFBL2YsTUFBQSxDQUFHOGYsT0FBTyxjQUFBOWYsTUFBQSxDQUFXdWYsa0VBQWMsQ0FBQyxDQUFDLE1BQUc7RUFDOUU7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNSRCxJQUFNUyxRQUFRLEdBQUl6VyxLQUFLLElBQUs7RUFDeEIsSUFBSWtHLE1BQU0sQ0FBQ3lJLFNBQVMsQ0FBQ25GLFFBQVEsQ0FBQ3pRLElBQUksQ0FBQ2lILEtBQUssQ0FBQyxLQUFLLGlCQUFpQixFQUFFO0lBQzdELE9BQU8sS0FBSztFQUNoQjtFQUNBLElBQU0yTyxTQUFTLEdBQUd6SSxNQUFNLENBQUN3USxjQUFjLENBQUMxVyxLQUFLLENBQUM7RUFDOUMsT0FBTzJPLFNBQVMsS0FBSyxJQUFJLElBQUlBLFNBQVMsS0FBS3pJLE1BQU0sQ0FBQ3lJLFNBQVM7QUFDL0QsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDTkQsSUFBTTdOLFFBQVEsR0FBSTZWLENBQUMsSUFBSztFQUNwQixPQUFPelEsTUFBTSxDQUFDeUksU0FBUyxDQUFDbkYsUUFBUSxDQUFDelEsSUFBSSxDQUFDNGQsQ0FBQyxDQUFDLEtBQUssaUJBQWlCO0FBQ2xFLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ0ZELElBQU01VixXQUFXLEdBQUk0VixDQUFDLElBQUtBLENBQUMsS0FBSyxLQUFLLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FZO0FBQ1M7QUFDWjtBQUNEO0FBQ3NDO0FBQ3JGLElBQUl4YSxFQUFFO0FBQ04sSUFBSTZhLG1CQUFtQjtBQUN2QixJQUFNQyxnQkFBZ0IsR0FBR0EsQ0FBQSxLQUFNO0VBQzNCLElBQUlsVyx3RUFBVyxDQUFDaVcsbUJBQW1CLENBQUMsRUFBRTtJQUNsQyxJQUFNRSxtQkFBbUIsR0FBRzNFLHdEQUFPLENBQUNNLEtBQUssQ0FBQzNQLEdBQUcsQ0FBQzBULHdEQUFXLENBQUM7SUFDMUQsSUFBSTlWLCtEQUFRLENBQUNvVyxtQkFBbUIsQ0FBQyxFQUFFO01BQy9CRixtQkFBbUIsR0FBRyxJQUFJRyxHQUFHLENBQUNELG1CQUFtQixDQUFDdkIsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDdFMsTUFBTSxDQUFDeVQsNkRBQWMsQ0FBQyxDQUFDO0lBQ3hGLENBQUMsTUFDSTtNQUNERSxtQkFBbUIsR0FBRyxlQUFnQixJQUFJRyxHQUFHLENBQUMsQ0FBQztJQUNuRDtFQUNKO0VBQ0EsT0FBT0gsbUJBQW1CO0FBQzlCLENBQUM7QUFDRCxJQUFNSSxXQUFXLEdBQUlDLFlBQVksSUFBSztFQUNsQyxJQUFNQyxhQUFhLEdBQUdMLGdCQUFnQixDQUFDLENBQUM7RUFDeENLLGFBQWEsQ0FBQ0MsR0FBRyxDQUFDRixZQUFZLENBQUM7RUFDL0I5RSx3REFBTyxDQUFDTSxLQUFLLENBQUM0QyxHQUFHLENBQUNtQix3REFBVyxFQUFFekgsS0FBSyxDQUFDcUksSUFBSSxDQUFDRixhQUFhLENBQUMsQ0FBQ2xCLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUNuRWxiLEdBQUcsQ0FBQ21jLFlBQVksRUFBRSw4QkFBOEIsQ0FBQztBQUNyRCxDQUFDO0FBQ0QsSUFBTUksZUFBZSxHQUFJSixZQUFZLElBQUs7RUFDdEMsSUFBTUMsYUFBYSxHQUFHTCxnQkFBZ0IsQ0FBQyxDQUFDO0VBQ3hDSyxhQUFhLENBQUNJLE1BQU0sQ0FBQ0wsWUFBWSxDQUFDO0VBQ2xDOUUsd0RBQU8sQ0FBQ00sS0FBSyxDQUFDNEMsR0FBRyxDQUFDbUIsd0RBQVcsRUFBRXpILEtBQUssQ0FBQ3FJLElBQUksQ0FBQ0YsYUFBYSxDQUFDLENBQUNsQixJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDbkVsYixHQUFHLENBQUNtYyxZQUFZLEVBQUUsbUNBQW1DLENBQUM7QUFDMUQsQ0FBQztBQUNELElBQU1NLGNBQWMsR0FBSU4sWUFBWSxJQUFLSixnQkFBZ0IsQ0FBQyxDQUFDLENBQUNXLEdBQUcsQ0FBQ1AsWUFBWSxDQUFDO0FBQzdFLElBQU1RLFNBQVMsR0FBQTdSLGFBQUEsQ0FBQUEsYUFBQSxLQUFRNlEsaUVBQWtCLEdBQUtFLDBEQUFXLENBQUU7QUFDM0QsSUFBTWUsWUFBWSxHQUFJQyxpQkFBaUIsSUFBSztFQUN4QyxJQUFNO0lBQUVDLFVBQVU7SUFBRUM7RUFBSyxDQUFDLEdBQUdKLFNBQVMsQ0FBQ0UsaUJBQWlCLENBQUM7RUFDekQsc0JBQUF0aEIsTUFBQSxDQUFzQnVoQixVQUFVLGVBQUF2aEIsTUFBQSxDQUFZd2hCLElBQUk7QUFDcEQsQ0FBQztBQUNELElBQU0vYyxHQUFHLEdBQUcsU0FBQUEsQ0FBQ21jLFlBQVksRUFBYztFQUNuQyxJQUFJTSxjQUFjLENBQUNOLFlBQVksQ0FBQyxFQUFFO0lBQzlCLElBQU1hLE1BQU0sR0FBRyxDQUFDSixZQUFZLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxFQUFFQSxZQUFZLENBQUNULFlBQVksQ0FBQyxFQUFFLEVBQUUsQ0FBQztJQUFDLFNBQUFjLElBQUEsR0FBQS9nQixTQUFBLENBQUFrRCxNQUFBLEVBRnREOGQsSUFBSSxPQUFBakosS0FBQSxDQUFBZ0osSUFBQSxPQUFBQSxJQUFBLFdBQUFFLElBQUEsTUFBQUEsSUFBQSxHQUFBRixJQUFBLEVBQUFFLElBQUE7TUFBSkQsSUFBSSxDQUFBQyxJQUFBLFFBQUFqaEIsU0FBQSxDQUFBaWhCLElBQUE7SUFBQTtJQUcxQnRkLE9BQU8sQ0FBQ0csR0FBRyxvQkFBQXpFLE1BQUEsQ0FBb0I0Z0IsWUFBWSxTQUFNLEdBQUdhLE1BQU0sRUFBRSxHQUFHRSxJQUFJLENBQUM7RUFDeEU7QUFDSixDQUFDO0FBQ0QsSUFBSSxPQUFPaGlCLE1BQU0sS0FBSyxXQUFXLEVBQUU7RUFBQSxJQUFBMEksZ0JBQUEsRUFBQXdaLFNBQUE7RUFDL0IsQ0FBQXhaLGdCQUFBLEdBQUExSSxNQUFNLENBQUM0SSxRQUFRLGNBQUFGLGdCQUFBLGNBQUFBLGdCQUFBLEdBQUsxSSxNQUFNLENBQUM0SSxRQUFRLEdBQUcsQ0FBQyxDQUFDO0VBQ3hDLENBQUFzWixTQUFBLElBQUNuYyxFQUFFLEdBQUcvRixNQUFNLENBQUM0SSxRQUFRLEVBQUV1WixNQUFNLGNBQUFELFNBQUEsY0FBQUEsU0FBQSxHQUFLbmMsRUFBRSxDQUFDb2MsTUFBTSxHQUFHO0lBQzFDbkIsV0FBVztJQUNYSyxlQUFlO0lBQ2ZlLEtBQUssRUFBRUEsQ0FBQSxLQUFNO01BQ1R6ZCxPQUFPLENBQUNDLElBQUksQ0FBQyw2REFBNkQsQ0FBQztNQUMzRSxPQUFPa0wsTUFBTSxDQUFDQyxJQUFJLENBQUMwUSxpRUFBa0IsQ0FBQztJQUMxQyxDQUFDO0lBQ0RTLGFBQWEsRUFBRUEsQ0FBQSxLQUFNcFIsTUFBTSxDQUFDQyxJQUFJLENBQUMwUSxpRUFBa0I7RUFDdkQsQ0FBQztBQUNMOzs7Ozs7Ozs7Ozs7Ozs7QUN0REEsSUFBTUQsV0FBVyxHQUFHLFdBQVc7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQS9CLElBQU1HLFdBQVcsR0FBRztFQUNoQjBCLE1BQU0sRUFBRTtJQUNKVCxVQUFVLEVBQUUsU0FBUztJQUNyQkMsSUFBSSxFQUFFO0VBQ1Y7QUFDSixDQUFDO0FBQ0QsSUFBTXBCLGtCQUFrQixHQUFHO0VBQ3ZCNkIsVUFBVSxFQUFFO0lBQ1JWLFVBQVUsRUFBRSxTQUFTO0lBQ3JCQyxJQUFJLEVBQUU7RUFDVixDQUFDO0VBQ0RwYyxHQUFHLEVBQUU7SUFDRG1jLFVBQVUsRUFBRSxTQUFTO0lBQ3JCQyxJQUFJLEVBQUU7RUFDVixDQUFDO0VBQ0RVLE1BQU0sRUFBRTtJQUNKWCxVQUFVLEVBQUUsU0FBUztJQUNyQkMsSUFBSSxFQUFFO0VBQ1YsQ0FBQztFQUNEVyxNQUFNLEVBQUU7SUFDSlosVUFBVSxFQUFFLFNBQVM7SUFDckJDLElBQUksRUFBRTtFQUNWLENBQUM7RUFDRFksRUFBRSxFQUFFO0lBQ0FiLFVBQVUsRUFBRSxTQUFTO0lBQ3JCQyxJQUFJLEVBQUU7RUFDVixDQUFDO0VBQ0RhLGdCQUFnQixFQUFFO0lBQ2RkLFVBQVUsRUFBRSxTQUFTO0lBQ3JCQyxJQUFJLEVBQUU7RUFDVixDQUFDO0VBQ0RjLFFBQVEsRUFBRTtJQUNOZixVQUFVLEVBQUUsU0FBUztJQUNyQkMsSUFBSSxFQUFFO0VBQ1YsQ0FBQztFQUNEZSxjQUFjLEVBQUU7SUFDWmhCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCQyxJQUFJLEVBQUU7RUFDVixDQUFDO0VBQ0RnQixJQUFJLEVBQUU7SUFDRmpCLFVBQVUsRUFBRSxTQUFTO0lBQ3JCQyxJQUFJLEVBQUU7RUFDVjtBQUNKLENBQUM7QUFDRCxJQUFNbkIsY0FBYyxHQUFJTyxZQUFZLElBQUtuUixNQUFNLENBQUNDLElBQUksQ0FBQzBRLGtCQUFrQixDQUFDLENBQUM5WSxRQUFRLENBQUNzWixZQUFZLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzVDL0YsSUFBSS9iLE9BQU8sR0FBRyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7OztBQ0E2QjtBQUNBO0FBQ25ELElBQUk0ZCxTQUFTLEdBQUdoVCxNQUFNLENBQUNnSSxjQUFjO0FBQ3JDLElBQUlpTCxXQUFXLEdBQUlDLEdBQUcsSUFBSztFQUN2QixNQUFNbkosU0FBUyxDQUFDbUosR0FBRyxDQUFDO0FBQ3hCLENBQUM7QUFDRCxJQUFJQyxlQUFlLEdBQUdBLENBQUNDLEdBQUcsRUFBRUMsR0FBRyxFQUFFdlosS0FBSyxLQUFLdVosR0FBRyxJQUFJRCxHQUFHLEdBQUdKLFNBQVMsQ0FBQ0ksR0FBRyxFQUFFQyxHQUFHLEVBQUU7RUFBRXBMLFVBQVUsRUFBRSxJQUFJO0VBQUU0QixZQUFZLEVBQUUsSUFBSTtFQUFFeUosUUFBUSxFQUFFLElBQUk7RUFBRXhaO0FBQU0sQ0FBQyxDQUFDLEdBQUdzWixHQUFHLENBQUNDLEdBQUcsQ0FBQyxHQUFHdlosS0FBSztBQUMvSixJQUFJeVosYUFBYSxHQUFHQSxDQUFDSCxHQUFHLEVBQUVDLEdBQUcsRUFBRXZaLEtBQUssS0FBS3FaLGVBQWUsQ0FBQ0MsR0FBRyxFQUFFLE9BQU9DLEdBQUcsS0FBSyxRQUFRLEdBQUdBLEdBQUcsR0FBRyxFQUFFLEdBQUdBLEdBQUcsRUFBRXZaLEtBQUssQ0FBQztBQUM5RyxJQUFJMFosYUFBYSxHQUFHQSxDQUFDSixHQUFHLEVBQUVLLE1BQU0sRUFBRVAsR0FBRyxLQUFLTyxNQUFNLENBQUMvQixHQUFHLENBQUMwQixHQUFHLENBQUMsSUFBSUgsV0FBVyxDQUFDLFNBQVMsR0FBR0MsR0FBRyxDQUFDO0FBQ3pGLElBQUlRLFlBQVksR0FBR0EsQ0FBQ04sR0FBRyxFQUFFSyxNQUFNLEVBQUVFLE1BQU0sTUFBTUgsYUFBYSxDQUFDSixHQUFHLEVBQUVLLE1BQU0sRUFBRSx5QkFBeUIsQ0FBQyxFQUFFRSxNQUFNLEdBQUdBLE1BQU0sQ0FBQzlnQixJQUFJLENBQUN1Z0IsR0FBRyxDQUFDLEdBQUdLLE1BQU0sQ0FBQ3pXLEdBQUcsQ0FBQ29XLEdBQUcsQ0FBQyxDQUFDO0FBQ2hKLElBQUlRLFlBQVksR0FBR0EsQ0FBQ1IsR0FBRyxFQUFFSyxNQUFNLEVBQUUzWixLQUFLLEtBQUsyWixNQUFNLENBQUMvQixHQUFHLENBQUMwQixHQUFHLENBQUMsR0FBR0gsV0FBVyxDQUFDLG1EQUFtRCxDQUFDLEdBQUdRLE1BQU0sWUFBWUksT0FBTyxHQUFHSixNQUFNLENBQUNwQyxHQUFHLENBQUMrQixHQUFHLENBQUMsR0FBR0ssTUFBTSxDQUFDbEUsR0FBRyxDQUFDNkQsR0FBRyxFQUFFdFosS0FBSyxDQUFDO0FBQ3BNLElBQUlnYSxZQUFZLEdBQUdBLENBQUNWLEdBQUcsRUFBRUssTUFBTSxFQUFFM1osS0FBSyxFQUFFaWEsTUFBTSxNQUFNUCxhQUFhLENBQUNKLEdBQUcsRUFBRUssTUFBTSxFQUFFLHdCQUF3QixDQUFDLEVBQUVBLE1BQU0sQ0FBQ2xFLEdBQUcsQ0FBQzZELEdBQUcsRUFBRXRaLEtBQUssQ0FBQyxFQUFFQSxLQUFLLENBQUM7QUFDeEksSUFBSWthLFFBQVEsRUFBRUMsTUFBTSxFQUFFQyxRQUFRLEVBQUVqZSxFQUFFO0FBQ2xDLE1BQU1rZSxjQUFjLENBQUM7RUFDakI7RUFDQUMsV0FBV0EsQ0FBQ0MsY0FBYyxFQUFFO0lBQ3hCVCxZQUFZLENBQUMsSUFBSSxFQUFFSSxRQUFRLENBQUM7SUFDNUI7QUFDUjtBQUNBO0lBQ1FULGFBQWEsQ0FBQyxJQUFJLEVBQUUsYUFBYSxFQUFFLE1BQU1uVCxPQUFPLENBQUNzVCxZQUFZLENBQUMsSUFBSSxFQUFFTSxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBQy9FO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7SUFDUVQsYUFBYSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUdGLEdBQUcsSUFBSztNQUNoQyxJQUFJO1FBQUEsSUFBQWlCLG1CQUFBLEVBQUFDLFdBQUE7UUFDQSxJQUFNbFksSUFBSSxHQUFHMkIsSUFBSSxDQUFDQyxLQUFLLEVBQUFxVyxtQkFBQSxJQUFBQyxXQUFBLEdBQUNiLFlBQVksQ0FBQyxJQUFJLEVBQUVNLFFBQVEsQ0FBQyxjQUFBTyxXQUFBLHVCQUE1QkEsV0FBQSxDQUE4QnhXLE9BQU8sQ0FBQ3NWLEdBQUcsQ0FBQyxjQUFBaUIsbUJBQUEsY0FBQUEsbUJBQUEsR0FBSSxFQUFFLENBQUM7UUFDekUsSUFBSSxDQUFDL0QsK0RBQVEsQ0FBQ2xVLElBQUksQ0FBQyxFQUFFO1VBQ2pCLE9BQU8sSUFBSTtRQUNmO1FBQ0EsSUFBTTtVQUFFdkMsS0FBSztVQUFFdVc7UUFBUSxDQUFDLEdBQUdoVSxJQUFJO1FBQy9CLElBQUksQ0FBQ3pCLCtEQUFRLENBQUN5VixPQUFPLENBQUMsSUFBSSxPQUFPQSxPQUFPLEtBQUssUUFBUSxLQUFLLGVBQWdCLElBQUkxTixJQUFJLENBQUMsQ0FBQyxHQUFHLElBQUlBLElBQUksQ0FBQzBOLE9BQU8sQ0FBQyxFQUFFO1VBQ3RHLElBQUksQ0FBQ3pELE1BQU0sQ0FBQ3lHLEdBQUcsQ0FBQztVQUNoQixPQUFPLElBQUk7UUFDZjtRQUNBLE9BQU92WixLQUFLO01BQ2hCLENBQUMsQ0FDRCxPQUFPb0wsQ0FBQyxFQUFFO1FBQ04sT0FBTyxJQUFJO01BQ2Y7SUFDSixDQUFDLENBQUM7SUFDRjtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNRcU8sYUFBYSxDQUFDLElBQUksRUFBRSxLQUFLLEVBQUUsQ0FBQ0YsR0FBRyxFQUFFdlosS0FBSyxFQUFFdVcsT0FBTztNQUFBLElBQUFtRSxZQUFBO01BQUEsUUFBQUEsWUFBQSxHQUFLZCxZQUFZLENBQUMsSUFBSSxFQUFFTSxRQUFRLENBQUMsY0FBQVEsWUFBQSx1QkFBNUJBLFlBQUEsQ0FBOEJDLE9BQU8sQ0FBQ3BCLEdBQUcsRUFBRXJWLElBQUksQ0FBQ0ssU0FBUyxDQUFDO1FBQzFHdkUsS0FBSztRQUNMdVcsT0FBTyxFQUFFQSxPQUFPLEdBQUcsSUFBSTFOLElBQUksQ0FBQzBOLE9BQU8sQ0FBQyxHQUFHLEtBQUs7TUFDaEQsQ0FBQyxDQUFDLENBQUM7SUFBQSxFQUFDO0lBQ0o7QUFDUjtBQUNBO0FBQ0E7QUFDQTtJQUNRa0QsYUFBYSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUdGLEdBQUc7TUFBQSxJQUFBcUIsWUFBQTtNQUFBLFFBQUFBLFlBQUEsR0FBS2hCLFlBQVksQ0FBQyxJQUFJLEVBQUVNLFFBQVEsQ0FBQyxjQUFBVSxZQUFBLHVCQUE1QkEsWUFBQSxDQUE4QkMsVUFBVSxDQUFDdEIsR0FBRyxDQUFDO0lBQUEsRUFBQztJQUNyRjtBQUNSO0FBQ0E7SUFDUUUsYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPLEVBQUU7TUFBQSxJQUFBcUIsWUFBQTtNQUFBLFFBQUFBLFlBQUEsR0FBTWxCLFlBQVksQ0FBQyxJQUFJLEVBQUVNLFFBQVEsQ0FBQyxjQUFBWSxZQUFBLHVCQUE1QkEsWUFBQSxDQUE4QkMsS0FBSyxDQUFDLENBQUM7SUFBQSxFQUFDO0lBQ3pFO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7SUFDUXRCLGFBQWEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFHRixHQUFHO01BQUEsSUFBQXlCLG9CQUFBLEVBQUFDLFlBQUE7TUFBQSxRQUFBRCxvQkFBQSxJQUFBQyxZQUFBLEdBQUtyQixZQUFZLENBQUMsSUFBSSxFQUFFTSxRQUFRLENBQUMsY0FBQWUsWUFBQSx1QkFBNUJBLFlBQUEsQ0FBOEJoWCxPQUFPLENBQUNzVixHQUFHLENBQUMsY0FBQXlCLG9CQUFBLGNBQUFBLG9CQUFBLEdBQUksSUFBSTtJQUFBLEVBQUM7SUFDMUY7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ1F2QixhQUFhLENBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxDQUFDRixHQUFHLEVBQUV2WixLQUFLO01BQUEsSUFBQWtiLFlBQUE7TUFBQSxRQUFBQSxZQUFBLEdBQUt0QixZQUFZLENBQUMsSUFBSSxFQUFFTSxRQUFRLENBQUMsY0FBQWdCLFlBQUEsdUJBQTVCQSxZQUFBLENBQThCUCxPQUFPLENBQUNwQixHQUFHLEVBQUV2WixLQUFLLENBQUM7SUFBQSxFQUFDO0lBQ2hHO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0lBQ1F5WixhQUFhLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRzBCLEtBQUs7TUFBQSxJQUFBQyxlQUFBLEVBQUFDLFlBQUE7TUFBQSxRQUFBRCxlQUFBLElBQUFDLFlBQUEsR0FBS3pCLFlBQVksQ0FBQyxJQUFJLEVBQUVNLFFBQVEsQ0FBQyxjQUFBbUIsWUFBQSx1QkFBNUJBLFlBQUEsQ0FBOEI5QixHQUFHLENBQUM0QixLQUFLLENBQUMsY0FBQUMsZUFBQSxjQUFBQSxlQUFBLEdBQUksSUFBSTtJQUFBLEVBQUM7SUFDdkY7QUFDUjtBQUNBO0FBQ0E7QUFDQTtJQUNRM0IsYUFBYSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUU7TUFBQSxJQUFBNkIsa0JBQUEsRUFBQUMsWUFBQTtNQUFBLFFBQUFELGtCQUFBLElBQUFDLFlBQUEsR0FBTTNCLFlBQVksQ0FBQyxJQUFJLEVBQUVNLFFBQVEsQ0FBQyxjQUFBcUIsWUFBQSx1QkFBNUJBLFlBQUEsQ0FBOEJqaEIsTUFBTSxjQUFBZ2hCLGtCQUFBLGNBQUFBLGtCQUFBLEdBQUksSUFBSTtJQUFBLEVBQUM7SUFDakYsSUFBSTtNQUNBLElBQU1FLFFBQVEsR0FBR3BsQixNQUFNLENBQUNta0IsY0FBYyxDQUFDO01BQ3ZDLElBQU1rQixHQUFHLEdBQUcsQ0FBRSxlQUFlLElBQUk1UyxJQUFJLENBQUMsQ0FBQyxFQUFFVyxRQUFRLENBQUMsQ0FBQztNQUNuRGdTLFFBQVEsQ0FBQ2IsT0FBTyxDQUFDYyxHQUFHLEVBQUVBLEdBQUcsQ0FBQztNQUMxQixJQUFNQyxTQUFTLEdBQUdGLFFBQVEsQ0FBQ3ZYLE9BQU8sQ0FBQ3dYLEdBQUcsQ0FBQyxJQUFJQSxHQUFHO01BQzlDRCxRQUFRLENBQUNYLFVBQVUsQ0FBQ1ksR0FBRyxDQUFDO01BQ3hCLElBQUlDLFNBQVMsRUFBRTtRQUNYMUIsWUFBWSxDQUFDLElBQUksRUFBRUUsUUFBUSxFQUFFc0IsUUFBUSxDQUFDO01BQzFDO0lBQ0osQ0FBQyxDQUNELE9BQU9wUSxDQUFDLEVBQUUsQ0FDVjtFQUNKO0FBQ0o7QUFDQThPLFFBQVEsR0FBRyxJQUFJeUIsT0FBTyxDQUFDLENBQUM7QUFDeEIsSUFBTXBKLE9BQU8sR0FBRyxLQUFLcFcsRUFBRSxHQUFHLE1BQU07RUFDNUJtZSxXQUFXQSxDQUFBLEVBQUc7SUFDVlIsWUFBWSxDQUFDLElBQUksRUFBRUssTUFBTSxDQUFDO0lBQzFCTCxZQUFZLENBQUMsSUFBSSxFQUFFTSxRQUFRLENBQUM7RUFDaEM7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFJdkgsS0FBS0EsQ0FBQSxFQUFHO0lBQUEsSUFBQStJLFlBQUE7SUFDUixRQUFBQSxZQUFBLEdBQU9oQyxZQUFZLENBQUMsSUFBSSxFQUFFTyxNQUFNLENBQUMsY0FBQXlCLFlBQUEsY0FBQUEsWUFBQSxHQUFJNUIsWUFBWSxDQUFDLElBQUksRUFBRUcsTUFBTSxFQUFFLElBQUlFLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQztFQUN2RztFQUNBLElBQUl0SCxPQUFPQSxDQUFBLEVBQUc7SUFBQSxJQUFBOEksWUFBQTtJQUNWLFFBQUFBLFlBQUEsR0FBT2pDLFlBQVksQ0FBQyxJQUFJLEVBQUVRLFFBQVEsQ0FBQyxjQUFBeUIsWUFBQSxjQUFBQSxZQUFBLEdBQUk3QixZQUFZLENBQUMsSUFBSSxFQUFFSSxRQUFRLEVBQUUsSUFBSUMsY0FBYyxDQUFDLGdCQUFnQixDQUFDLENBQUM7RUFDN0c7QUFDSixDQUFDLEVBQUVGLE1BQU0sR0FBRyxJQUFJd0IsT0FBTyxDQUFDLENBQUMsRUFBRXZCLFFBQVEsR0FBRyxJQUFJdUIsT0FBTyxDQUFDLENBQUMsRUFBRXhmLEVBQUUsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUM5SDFELElBQU0yZixXQUFXLEdBQUc7RUFDaEJDLE9BQU8sRUFBRSxHQUFHO0VBQ1pDLE9BQU8sRUFBRSxJQUFJO0VBQ2JDLE1BQU0sRUFBRSxHQUFHO0VBQ1hDLGVBQWUsRUFBRSxHQUFHO0VBQ3BCQyxZQUFZLEVBQUUsR0FBRztFQUNqQkMsT0FBTyxFQUFFLEdBQUc7RUFDWkMsTUFBTSxFQUFFLEdBQUc7RUFDWEMsSUFBSSxFQUFFO0FBQ1YsQ0FBQzs7Ozs7Ozs7Ozs7QUNUWTs7QUFDYkMsTUFBTSxDQUFDNU8sT0FBTyxHQUFHNk8sUUFBUTtBQUN6QjtBQUNBLElBQUlDLFFBQVEsR0FBRyxzRkFBc0Y7QUFDckcsSUFBSUMsVUFBVSxHQUFHO0VBQ2JDLEtBQUssRUFBRSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUM7RUFBRTtFQUN2QkMsS0FBSyxFQUFFLEtBQUs7RUFDWkMsR0FBRyxFQUFFLFFBQVE7RUFDYkMsS0FBSyxFQUFFLFFBQVE7RUFDZkMsTUFBTSxFQUFFLFFBQVE7RUFDaEJDLElBQUksRUFBRSxRQUFRO0VBQ2RDLE9BQU8sRUFBRSxRQUFRO0VBQ2pCQyxJQUFJLEVBQUUsUUFBUTtFQUNkQyxTQUFTLEVBQUUsUUFBUTtFQUNuQkMsUUFBUSxFQUFFO0FBQ2QsQ0FBQztBQUNELElBQUlDLE9BQU8sR0FBRztFQUNWLEVBQUUsRUFBRSxPQUFPO0VBQ1gsRUFBRSxFQUFFLEtBQUs7RUFDVCxFQUFFLEVBQUUsT0FBTztFQUNYLEVBQUUsRUFBRSxRQUFRO0VBQ1osRUFBRSxFQUFFLE1BQU07RUFDVixFQUFFLEVBQUUsU0FBUztFQUNiLEVBQUUsRUFBRSxNQUFNO0VBQ1YsRUFBRSxFQUFFO0FBQ1IsQ0FBQztBQUNELElBQUlDLFNBQVMsR0FBRztFQUNaLEdBQUcsRUFBRSxrQkFBa0I7RUFBRTtFQUN6QixHQUFHLEVBQUUsYUFBYTtFQUFFO0VBQ3BCLEdBQUcsRUFBRSxLQUFLO0VBQUU7RUFDWixHQUFHLEVBQUUsS0FBSztFQUFFO0VBQ1osR0FBRyxFQUFFLGNBQWM7RUFBRTtFQUNyQixHQUFHLEVBQUUsT0FBTyxDQUFDO0FBQ2pCLENBQUM7QUFDRCxJQUFJQyxVQUFVLEdBQUc7RUFDYixJQUFJLEVBQUUsTUFBTTtFQUFFO0VBQ2QsSUFBSSxFQUFFLE1BQU07RUFBRTtFQUNkLElBQUksRUFBRSxRQUFRLENBQUM7QUFDbkIsQ0FBQztBQUNELENBQUMsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM5VyxPQUFPLENBQUMsVUFBVStGLENBQUMsRUFBRTtFQUM3QytRLFVBQVUsQ0FBQy9RLENBQUMsQ0FBQyxHQUFHLFNBQVM7QUFDN0IsQ0FBQyxDQUFDO0FBQ0Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFNBQVNnUSxRQUFRQSxDQUFDZ0IsSUFBSSxFQUFFO0VBQ3BCO0VBQ0EsSUFBSSxDQUFDZixRQUFRLENBQUMvaUIsSUFBSSxDQUFDOGpCLElBQUksQ0FBQyxFQUFFO0lBQ3RCLE9BQU9BLElBQUk7RUFDZjtFQUNBO0VBQ0EsSUFBSUMsU0FBUyxHQUFHLEVBQUU7RUFDbEI7RUFDQSxJQUFJQyxHQUFHLEdBQUdGLElBQUksQ0FBQ25ILE9BQU8sQ0FBQyxlQUFlLEVBQUUsVUFBVXJHLEtBQUssRUFBRTJOLEdBQUcsRUFBRTtJQUMxRCxJQUFJQyxFQUFFLEdBQUdOLFNBQVMsQ0FBQ0ssR0FBRyxDQUFDO0lBQ3ZCLElBQUlDLEVBQUUsRUFBRTtNQUNKO01BQ0EsSUFBSSxDQUFDLENBQUMsQ0FBQ0gsU0FBUyxDQUFDSSxPQUFPLENBQUNGLEdBQUcsQ0FBQyxFQUFFO1FBQUU7UUFDN0JGLFNBQVMsQ0FBQ0ssR0FBRyxDQUFDLENBQUM7UUFDZixPQUFPLFNBQVM7TUFDcEI7TUFDQTtNQUNBTCxTQUFTLENBQUMzVyxJQUFJLENBQUM2VyxHQUFHLENBQUM7TUFDbkIsT0FBT0MsRUFBRSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBR0EsRUFBRSxHQUFHLGVBQWUsR0FBR0EsRUFBRSxHQUFHLEtBQUs7SUFDNUQ7SUFDQSxJQUFJRyxFQUFFLEdBQUdSLFVBQVUsQ0FBQ0ksR0FBRyxDQUFDO0lBQ3hCLElBQUlJLEVBQUUsRUFBRTtNQUNKO01BQ0FOLFNBQVMsQ0FBQ0ssR0FBRyxDQUFDLENBQUM7TUFDZixPQUFPQyxFQUFFO0lBQ2I7SUFDQSxPQUFPLEVBQUU7RUFDYixDQUFDLENBQUM7RUFDRjtFQUNBLElBQUlsUSxDQUFDLEdBQUc0UCxTQUFTLENBQUNuakIsTUFBTTtFQUN2QnVULENBQUMsR0FBRyxDQUFDLEtBQU02UCxHQUFHLElBQUl2TyxLQUFLLENBQUN0QixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUN1SSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQUM7RUFDaEQsT0FBT3NILEdBQUc7QUFDZDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FsQixRQUFRLENBQUN3QixTQUFTLEdBQUcsVUFBVUMsTUFBTSxFQUFFO0VBQ25DLElBQUksT0FBT0EsTUFBTSxLQUFLLFFBQVEsRUFBRTtJQUM1QixNQUFNLElBQUl6bkIsS0FBSyxDQUFDLHVDQUF1QyxDQUFDO0VBQzVEO0VBQ0EsSUFBSTBuQixZQUFZLEdBQUcsQ0FBQyxDQUFDO0VBQ3JCLEtBQUssSUFBSTNFLEdBQUcsSUFBSW1ELFVBQVUsRUFBRTtJQUN4QixJQUFJeUIsR0FBRyxHQUFHRixNQUFNLENBQUNyUCxjQUFjLENBQUMySyxHQUFHLENBQUMsR0FBRzBFLE1BQU0sQ0FBQzFFLEdBQUcsQ0FBQyxHQUFHLElBQUk7SUFDekQsSUFBSSxDQUFDNEUsR0FBRyxFQUFFO01BQ05ELFlBQVksQ0FBQzNFLEdBQUcsQ0FBQyxHQUFHbUQsVUFBVSxDQUFDbkQsR0FBRyxDQUFDO01BQ25DO0lBQ0o7SUFDQSxJQUFJLE9BQU8sS0FBS0EsR0FBRyxFQUFFO01BQ2pCLElBQUksT0FBTzRFLEdBQUcsS0FBSyxRQUFRLEVBQUU7UUFDekJBLEdBQUcsR0FBRyxDQUFDQSxHQUFHLENBQUM7TUFDZjtNQUNBLElBQUksQ0FBQ2hQLEtBQUssQ0FBQ2lQLE9BQU8sQ0FBQ0QsR0FBRyxDQUFDLElBQUlBLEdBQUcsQ0FBQzdqQixNQUFNLEtBQUssQ0FBQyxJQUFJNmpCLEdBQUcsQ0FBQ3JrQixJQUFJLENBQUMsVUFBVXVrQixDQUFDLEVBQUU7UUFDakUsT0FBTyxPQUFPQSxDQUFDLEtBQUssUUFBUTtNQUNoQyxDQUFDLENBQUMsRUFBRTtRQUNBLE1BQU0sSUFBSTduQixLQUFLLENBQUMsZ0JBQWdCLEdBQUcraUIsR0FBRyxHQUFHLG9GQUFvRixDQUFDO01BQ2xJO01BQ0EsSUFBSStFLFdBQVcsR0FBRzVCLFVBQVUsQ0FBQ25ELEdBQUcsQ0FBQztNQUNqQyxJQUFJLENBQUM0RSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDVEEsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHRyxXQUFXLENBQUMsQ0FBQyxDQUFDO01BQzNCO01BQ0EsSUFBSUgsR0FBRyxDQUFDN2pCLE1BQU0sS0FBSyxDQUFDLElBQUksQ0FBQzZqQixHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUU7UUFDN0JBLEdBQUcsR0FBRyxDQUFDQSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDZEEsR0FBRyxDQUFDclgsSUFBSSxDQUFDd1gsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO01BQzVCO01BQ0FILEdBQUcsR0FBR0EsR0FBRyxDQUFDblIsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDekIsQ0FBQyxNQUNJLElBQUksT0FBT21SLEdBQUcsS0FBSyxRQUFRLEVBQUU7TUFDOUIsTUFBTSxJQUFJM25CLEtBQUssQ0FBQyxnQkFBZ0IsR0FBRytpQixHQUFHLEdBQUcsK0NBQStDLENBQUM7SUFDN0Y7SUFDQTJFLFlBQVksQ0FBQzNFLEdBQUcsQ0FBQyxHQUFHNEUsR0FBRztFQUMzQjtFQUNBSSxRQUFRLENBQUNMLFlBQVksQ0FBQztBQUMxQixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0ExQixRQUFRLENBQUNHLEtBQUssR0FBRyxZQUFZO0VBQ3pCNEIsUUFBUSxDQUFDN0IsVUFBVSxDQUFDO0FBQ3hCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBRixRQUFRLENBQUNnQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO0FBQ2xCLElBQUl0WSxNQUFNLENBQUNnSSxjQUFjLEVBQUU7RUFDdkJoSSxNQUFNLENBQUNnSSxjQUFjLENBQUNzTyxRQUFRLENBQUNnQyxJQUFJLEVBQUUsTUFBTSxFQUFFO0lBQ3pDdGIsR0FBRyxFQUFFLFNBQUFBLENBQUEsRUFBWTtNQUFFLE9BQU9vYSxTQUFTO0lBQUU7RUFDekMsQ0FBQyxDQUFDO0VBQ0ZwWCxNQUFNLENBQUNnSSxjQUFjLENBQUNzTyxRQUFRLENBQUNnQyxJQUFJLEVBQUUsT0FBTyxFQUFFO0lBQzFDdGIsR0FBRyxFQUFFLFNBQUFBLENBQUEsRUFBWTtNQUFFLE9BQU9xYSxVQUFVO0lBQUU7RUFDMUMsQ0FBQyxDQUFDO0FBQ04sQ0FBQyxNQUNJO0VBQ0RmLFFBQVEsQ0FBQ2dDLElBQUksQ0FBQ0MsSUFBSSxHQUFHbkIsU0FBUztFQUM5QmQsUUFBUSxDQUFDZ0MsSUFBSSxDQUFDRSxLQUFLLEdBQUduQixVQUFVO0FBQ3BDO0FBQ0EsU0FBU2dCLFFBQVFBLENBQUNOLE1BQU0sRUFBRTtFQUN0QjtFQUNBWCxTQUFTLENBQUMsR0FBRyxDQUFDLEdBQUcsc0NBQXNDLEdBQUdXLE1BQU0sQ0FBQ3RCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxlQUFlLEdBQUdzQixNQUFNLENBQUN0QixLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQzdHO0VBQ0FXLFNBQVMsQ0FBQyxHQUFHLENBQUMsR0FBRyxTQUFTLEdBQUdXLE1BQU0sQ0FBQ3RCLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxlQUFlLEdBQUdzQixNQUFNLENBQUN0QixLQUFLLENBQUMsQ0FBQyxDQUFDO0VBQ2hGO0VBQ0FXLFNBQVMsQ0FBQyxJQUFJLENBQUMsR0FBRyxTQUFTLEdBQUdXLE1BQU0sQ0FBQ2IsUUFBUTtFQUM3QyxLQUFLLElBQUl1QixJQUFJLElBQUl0QixPQUFPLEVBQUU7SUFDdEIsSUFBSXVCLEtBQUssR0FBR3ZCLE9BQU8sQ0FBQ3NCLElBQUksQ0FBQztJQUN6QixJQUFJRSxRQUFRLEdBQUdaLE1BQU0sQ0FBQ1csS0FBSyxDQUFDLElBQUksS0FBSztJQUNyQ3RCLFNBQVMsQ0FBQ3FCLElBQUksQ0FBQyxHQUFHLFNBQVMsR0FBR0UsUUFBUTtJQUN0Q0YsSUFBSSxHQUFHdlAsUUFBUSxDQUFDdVAsSUFBSSxDQUFDO0lBQ3JCckIsU0FBUyxDQUFDLENBQUNxQixJQUFJLEdBQUcsRUFBRSxFQUFFblYsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLGNBQWMsR0FBR3FWLFFBQVE7RUFDakU7QUFDSjtBQUNBckMsUUFBUSxDQUFDRyxLQUFLLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7O0FDL0poQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ2E7O0FBQ2IsSUFBSW1DLENBQUMsR0FBRyxPQUFPQyxPQUFPLEtBQUssUUFBUSxHQUFHQSxPQUFPLEdBQUcsSUFBSTtBQUNwRCxJQUFJQyxZQUFZLEdBQUdGLENBQUMsSUFBSSxPQUFPQSxDQUFDLENBQUMzbkIsS0FBSyxLQUFLLFVBQVUsR0FDL0MybkIsQ0FBQyxDQUFDM25CLEtBQUssR0FDUCxTQUFTNm5CLFlBQVlBLENBQUNDLE1BQU0sRUFBRUMsUUFBUSxFQUFFOUcsSUFBSSxFQUFFO0VBQzVDLE9BQU92SSxRQUFRLENBQUNsQixTQUFTLENBQUN4WCxLQUFLLENBQUM0QixJQUFJLENBQUNrbUIsTUFBTSxFQUFFQyxRQUFRLEVBQUU5RyxJQUFJLENBQUM7QUFDaEUsQ0FBQztBQUNMLElBQUkrRyxjQUFjO0FBQ2xCLElBQUlMLENBQUMsSUFBSSxPQUFPQSxDQUFDLENBQUNNLE9BQU8sS0FBSyxVQUFVLEVBQUU7RUFDdENELGNBQWMsR0FBR0wsQ0FBQyxDQUFDTSxPQUFPO0FBQzlCLENBQUMsTUFDSSxJQUFJbFosTUFBTSxDQUFDbVoscUJBQXFCLEVBQUU7RUFDbkNGLGNBQWMsR0FBRyxTQUFTQSxjQUFjQSxDQUFDRixNQUFNLEVBQUU7SUFDN0MsT0FBTy9ZLE1BQU0sQ0FBQ29aLG1CQUFtQixDQUFDTCxNQUFNLENBQUMsQ0FDcEN4b0IsTUFBTSxDQUFDeVAsTUFBTSxDQUFDbVoscUJBQXFCLENBQUNKLE1BQU0sQ0FBQyxDQUFDO0VBQ3JELENBQUM7QUFDTCxDQUFDLE1BQ0k7RUFDREUsY0FBYyxHQUFHLFNBQVNBLGNBQWNBLENBQUNGLE1BQU0sRUFBRTtJQUM3QyxPQUFPL1ksTUFBTSxDQUFDb1osbUJBQW1CLENBQUNMLE1BQU0sQ0FBQztFQUM3QyxDQUFDO0FBQ0w7QUFDQSxTQUFTTSxrQkFBa0JBLENBQUNDLE9BQU8sRUFBRTtFQUNqQyxJQUFJemtCLE9BQU8sSUFBSUEsT0FBTyxDQUFDQyxJQUFJLEVBQ3ZCRCxPQUFPLENBQUNDLElBQUksQ0FBQ3drQixPQUFPLENBQUM7QUFDN0I7QUFDQSxJQUFJQyxXQUFXLEdBQUdDLE1BQU0sQ0FBQ0MsS0FBSyxJQUFJLFNBQVNGLFdBQVdBLENBQUN6ZixLQUFLLEVBQUU7RUFDMUQsT0FBT0EsS0FBSyxLQUFLQSxLQUFLO0FBQzFCLENBQUM7QUFDRCxTQUFTNGYsWUFBWUEsQ0FBQSxFQUFHO0VBQ3BCQSxZQUFZLENBQUM5bkIsSUFBSSxDQUFDaUIsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNoQztBQUNBd2pCLE1BQU0sQ0FBQzVPLE9BQU8sR0FBR2lTLFlBQVk7QUFDN0JyRCxtQkFBbUIsR0FBR3NELElBQUk7QUFDMUI7QUFDQUQsWUFBWSxDQUFDQSxZQUFZLEdBQUdBLFlBQVk7QUFDeENBLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQ21SLE9BQU8sR0FBR2xaLFNBQVM7QUFDMUNnWixZQUFZLENBQUNqUixTQUFTLENBQUNvUixZQUFZLEdBQUcsQ0FBQztBQUN2Q0gsWUFBWSxDQUFDalIsU0FBUyxDQUFDcVIsYUFBYSxHQUFHcFosU0FBUztBQUNoRDtBQUNBO0FBQ0EsSUFBSXFaLG1CQUFtQixHQUFHLEVBQUU7QUFDNUIsU0FBU0MsYUFBYUEsQ0FBQ0MsUUFBUSxFQUFFO0VBQzdCLElBQUksT0FBT0EsUUFBUSxLQUFLLFVBQVUsRUFBRTtJQUNoQyxNQUFNLElBQUlsUSxTQUFTLENBQUMsa0VBQWtFLEdBQUcsT0FBT2tRLFFBQVEsQ0FBQztFQUM3RztBQUNKO0FBQ0FqYSxNQUFNLENBQUNnSSxjQUFjLENBQUMwUixZQUFZLEVBQUUscUJBQXFCLEVBQUU7RUFDdkR6UixVQUFVLEVBQUUsSUFBSTtFQUNoQmpMLEdBQUcsRUFBRSxTQUFBQSxDQUFBLEVBQVk7SUFDYixPQUFPK2MsbUJBQW1CO0VBQzlCLENBQUM7RUFDRHhLLEdBQUcsRUFBRSxTQUFBQSxDQUFVdk8sR0FBRyxFQUFFO0lBQ2hCLElBQUksT0FBT0EsR0FBRyxLQUFLLFFBQVEsSUFBSUEsR0FBRyxHQUFHLENBQUMsSUFBSXVZLFdBQVcsQ0FBQ3ZZLEdBQUcsQ0FBQyxFQUFFO01BQ3hELE1BQU0sSUFBSWtaLFVBQVUsQ0FBQyxpR0FBaUcsR0FBR2xaLEdBQUcsR0FBRyxHQUFHLENBQUM7SUFDdkk7SUFDQStZLG1CQUFtQixHQUFHL1ksR0FBRztFQUM3QjtBQUNKLENBQUMsQ0FBQztBQUNGMFksWUFBWSxDQUFDOW5CLElBQUksR0FBRyxZQUFZO0VBQzVCLElBQUksSUFBSSxDQUFDZ29CLE9BQU8sS0FBS2xaLFNBQVMsSUFDMUIsSUFBSSxDQUFDa1osT0FBTyxLQUFLNVosTUFBTSxDQUFDd1EsY0FBYyxDQUFDLElBQUksQ0FBQyxDQUFDb0osT0FBTyxFQUFFO0lBQ3RELElBQUksQ0FBQ0EsT0FBTyxHQUFHNVosTUFBTSxDQUFDcUksTUFBTSxDQUFDLElBQUksQ0FBQztJQUNsQyxJQUFJLENBQUN3UixZQUFZLEdBQUcsQ0FBQztFQUN6QjtFQUNBLElBQUksQ0FBQ0MsYUFBYSxHQUFHLElBQUksQ0FBQ0EsYUFBYSxJQUFJcFosU0FBUztBQUN4RCxDQUFDO0FBQ0Q7QUFDQTtBQUNBZ1osWUFBWSxDQUFDalIsU0FBUyxDQUFDMFIsZUFBZSxHQUFHLFNBQVNBLGVBQWVBLENBQUM3VCxDQUFDLEVBQUU7RUFDakUsSUFBSSxPQUFPQSxDQUFDLEtBQUssUUFBUSxJQUFJQSxDQUFDLEdBQUcsQ0FBQyxJQUFJaVQsV0FBVyxDQUFDalQsQ0FBQyxDQUFDLEVBQUU7SUFDbEQsTUFBTSxJQUFJNFQsVUFBVSxDQUFDLCtFQUErRSxHQUFHNVQsQ0FBQyxHQUFHLEdBQUcsQ0FBQztFQUNuSDtFQUNBLElBQUksQ0FBQ3dULGFBQWEsR0FBR3hULENBQUM7RUFDdEIsT0FBTyxJQUFJO0FBQ2YsQ0FBQztBQUNELFNBQVM4VCxnQkFBZ0JBLENBQUNDLElBQUksRUFBRTtFQUM1QixJQUFJQSxJQUFJLENBQUNQLGFBQWEsS0FBS3BaLFNBQVMsRUFDaEMsT0FBT2daLFlBQVksQ0FBQ0ssbUJBQW1CO0VBQzNDLE9BQU9NLElBQUksQ0FBQ1AsYUFBYTtBQUM3QjtBQUNBSixZQUFZLENBQUNqUixTQUFTLENBQUM2UixlQUFlLEdBQUcsU0FBU0EsZUFBZUEsQ0FBQSxFQUFHO0VBQ2hFLE9BQU9GLGdCQUFnQixDQUFDLElBQUksQ0FBQztBQUNqQyxDQUFDO0FBQ0RWLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQzhSLElBQUksR0FBRyxTQUFTQSxJQUFJQSxDQUFDQyxJQUFJLEVBQUU7RUFDOUMsSUFBSXRJLElBQUksR0FBRyxFQUFFO0VBQ2IsS0FBSyxJQUFJdEwsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHMVYsU0FBUyxDQUFDa0QsTUFBTSxFQUFFd1MsQ0FBQyxFQUFFLEVBQ3JDc0wsSUFBSSxDQUFDdFIsSUFBSSxDQUFDMVAsU0FBUyxDQUFDMFYsQ0FBQyxDQUFDLENBQUM7RUFDM0IsSUFBSTZULE9BQU8sR0FBSUQsSUFBSSxLQUFLLE9BQVE7RUFDaEMsSUFBSTNYLE1BQU0sR0FBRyxJQUFJLENBQUMrVyxPQUFPO0VBQ3pCLElBQUkvVyxNQUFNLEtBQUtuQyxTQUFTLEVBQ3BCK1osT0FBTyxHQUFJQSxPQUFPLElBQUk1WCxNQUFNLENBQUM2QixLQUFLLEtBQUtoRSxTQUFVLENBQUMsS0FDakQsSUFBSSxDQUFDK1osT0FBTyxFQUNiLE9BQU8sS0FBSztFQUNoQjtFQUNBLElBQUlBLE9BQU8sRUFBRTtJQUNULElBQUlDLEVBQUU7SUFDTixJQUFJeEksSUFBSSxDQUFDOWQsTUFBTSxHQUFHLENBQUMsRUFDZnNtQixFQUFFLEdBQUd4SSxJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQ2hCLElBQUl3SSxFQUFFLFlBQVlwcUIsS0FBSyxFQUFFO01BQ3JCO01BQ0E7TUFDQSxNQUFNb3FCLEVBQUUsQ0FBQyxDQUFDO0lBQ2Q7SUFDQTtJQUNBLElBQUk3VyxHQUFHLEdBQUcsSUFBSXZULEtBQUssQ0FBQyxrQkFBa0IsSUFBSW9xQixFQUFFLEdBQUcsSUFBSSxHQUFHQSxFQUFFLENBQUNDLE9BQU8sR0FBRyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUM7SUFDN0U5VyxHQUFHLENBQUMrVyxPQUFPLEdBQUdGLEVBQUU7SUFDaEIsTUFBTTdXLEdBQUcsQ0FBQyxDQUFDO0VBQ2Y7RUFDQSxJQUFJZ1gsT0FBTyxHQUFHaFksTUFBTSxDQUFDMlgsSUFBSSxDQUFDO0VBQzFCLElBQUlLLE9BQU8sS0FBS25hLFNBQVMsRUFDckIsT0FBTyxLQUFLO0VBQ2hCLElBQUksT0FBT21hLE9BQU8sS0FBSyxVQUFVLEVBQUU7SUFDL0IvQixZQUFZLENBQUMrQixPQUFPLEVBQUUsSUFBSSxFQUFFM0ksSUFBSSxDQUFDO0VBQ3JDLENBQUMsTUFDSTtJQUNELElBQUk0SSxHQUFHLEdBQUdELE9BQU8sQ0FBQ3ptQixNQUFNO0lBQ3hCLElBQUkybUIsU0FBUyxHQUFHQyxVQUFVLENBQUNILE9BQU8sRUFBRUMsR0FBRyxDQUFDO0lBQ3hDLEtBQUssSUFBSWxVLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR2tVLEdBQUcsRUFBRSxFQUFFbFUsQ0FBQyxFQUN4QmtTLFlBQVksQ0FBQ2lDLFNBQVMsQ0FBQ25VLENBQUMsQ0FBQyxFQUFFLElBQUksRUFBRXNMLElBQUksQ0FBQztFQUM5QztFQUNBLE9BQU8sSUFBSTtBQUNmLENBQUM7QUFDRCxTQUFTK0ksWUFBWUEsQ0FBQ2xDLE1BQU0sRUFBRXlCLElBQUksRUFBRVAsUUFBUSxFQUFFaUIsT0FBTyxFQUFFO0VBQ25ELElBQUl0VCxDQUFDO0VBQ0wsSUFBSS9FLE1BQU07RUFDVixJQUFJc1ksUUFBUTtFQUNabkIsYUFBYSxDQUFDQyxRQUFRLENBQUM7RUFDdkJwWCxNQUFNLEdBQUdrVyxNQUFNLENBQUNhLE9BQU87RUFDdkIsSUFBSS9XLE1BQU0sS0FBS25DLFNBQVMsRUFBRTtJQUN0Qm1DLE1BQU0sR0FBR2tXLE1BQU0sQ0FBQ2EsT0FBTyxHQUFHNVosTUFBTSxDQUFDcUksTUFBTSxDQUFDLElBQUksQ0FBQztJQUM3QzBRLE1BQU0sQ0FBQ2MsWUFBWSxHQUFHLENBQUM7RUFDM0IsQ0FBQyxNQUNJO0lBQ0Q7SUFDQTtJQUNBLElBQUloWCxNQUFNLENBQUN1WSxXQUFXLEtBQUsxYSxTQUFTLEVBQUU7TUFDbENxWSxNQUFNLENBQUN3QixJQUFJLENBQUMsYUFBYSxFQUFFQyxJQUFJLEVBQUVQLFFBQVEsQ0FBQ0EsUUFBUSxHQUFHQSxRQUFRLENBQUNBLFFBQVEsR0FBR0EsUUFBUSxDQUFDO01BQ2xGO01BQ0E7TUFDQXBYLE1BQU0sR0FBR2tXLE1BQU0sQ0FBQ2EsT0FBTztJQUMzQjtJQUNBdUIsUUFBUSxHQUFHdFksTUFBTSxDQUFDMlgsSUFBSSxDQUFDO0VBQzNCO0VBQ0EsSUFBSVcsUUFBUSxLQUFLemEsU0FBUyxFQUFFO0lBQ3hCO0lBQ0F5YSxRQUFRLEdBQUd0WSxNQUFNLENBQUMyWCxJQUFJLENBQUMsR0FBR1AsUUFBUTtJQUNsQyxFQUFFbEIsTUFBTSxDQUFDYyxZQUFZO0VBQ3pCLENBQUMsTUFDSTtJQUNELElBQUksT0FBT3NCLFFBQVEsS0FBSyxVQUFVLEVBQUU7TUFDaEM7TUFDQUEsUUFBUSxHQUFHdFksTUFBTSxDQUFDMlgsSUFBSSxDQUFDLEdBQ25CVSxPQUFPLEdBQUcsQ0FBQ2pCLFFBQVEsRUFBRWtCLFFBQVEsQ0FBQyxHQUFHLENBQUNBLFFBQVEsRUFBRWxCLFFBQVEsQ0FBQztNQUN6RDtJQUNKLENBQUMsTUFDSSxJQUFJaUIsT0FBTyxFQUFFO01BQ2RDLFFBQVEsQ0FBQ0UsT0FBTyxDQUFDcEIsUUFBUSxDQUFDO0lBQzlCLENBQUMsTUFDSTtNQUNEa0IsUUFBUSxDQUFDdmEsSUFBSSxDQUFDcVosUUFBUSxDQUFDO0lBQzNCO0lBQ0E7SUFDQXJTLENBQUMsR0FBR3dTLGdCQUFnQixDQUFDckIsTUFBTSxDQUFDO0lBQzVCLElBQUluUixDQUFDLEdBQUcsQ0FBQyxJQUFJdVQsUUFBUSxDQUFDL21CLE1BQU0sR0FBR3dULENBQUMsSUFBSSxDQUFDdVQsUUFBUSxDQUFDRyxNQUFNLEVBQUU7TUFDbERILFFBQVEsQ0FBQ0csTUFBTSxHQUFHLElBQUk7TUFDdEI7TUFDQTtNQUNBLElBQUlDLENBQUMsR0FBRyxJQUFJanJCLEtBQUssQ0FBQyw4Q0FBOEMsR0FDNUQ2cUIsUUFBUSxDQUFDL21CLE1BQU0sR0FBRyxHQUFHLEdBQUcrVixNQUFNLENBQUNxUSxJQUFJLENBQUMsR0FBRyxhQUFhLEdBQ3BELDBDQUEwQyxHQUMxQyxnQkFBZ0IsQ0FBQztNQUNyQmUsQ0FBQyxDQUFDMWYsSUFBSSxHQUFHLDZCQUE2QjtNQUN0QzBmLENBQUMsQ0FBQ0MsT0FBTyxHQUFHekMsTUFBTTtNQUNsQndDLENBQUMsQ0FBQ2YsSUFBSSxHQUFHQSxJQUFJO01BQ2JlLENBQUMsQ0FBQ0UsS0FBSyxHQUFHTixRQUFRLENBQUMvbUIsTUFBTTtNQUN6QmlsQixrQkFBa0IsQ0FBQ2tDLENBQUMsQ0FBQztJQUN6QjtFQUNKO0VBQ0EsT0FBT3hDLE1BQU07QUFDakI7QUFDQVcsWUFBWSxDQUFDalIsU0FBUyxDQUFDaVQsV0FBVyxHQUFHLFNBQVNBLFdBQVdBLENBQUNsQixJQUFJLEVBQUVQLFFBQVEsRUFBRTtFQUN0RSxPQUFPZ0IsWUFBWSxDQUFDLElBQUksRUFBRVQsSUFBSSxFQUFFUCxRQUFRLEVBQUUsS0FBSyxDQUFDO0FBQ3BELENBQUM7QUFDRFAsWUFBWSxDQUFDalIsU0FBUyxDQUFDa1QsRUFBRSxHQUFHakMsWUFBWSxDQUFDalIsU0FBUyxDQUFDaVQsV0FBVztBQUM5RGhDLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQ21ULGVBQWUsR0FDbEMsU0FBU0EsZUFBZUEsQ0FBQ3BCLElBQUksRUFBRVAsUUFBUSxFQUFFO0VBQ3JDLE9BQU9nQixZQUFZLENBQUMsSUFBSSxFQUFFVCxJQUFJLEVBQUVQLFFBQVEsRUFBRSxJQUFJLENBQUM7QUFDbkQsQ0FBQztBQUNMLFNBQVM0QixXQUFXQSxDQUFBLEVBQUc7RUFDbkIsSUFBSSxDQUFDLElBQUksQ0FBQ0MsS0FBSyxFQUFFO0lBQ2IsSUFBSSxDQUFDL0MsTUFBTSxDQUFDZ0QsY0FBYyxDQUFDLElBQUksQ0FBQ3ZCLElBQUksRUFBRSxJQUFJLENBQUN3QixNQUFNLENBQUM7SUFDbEQsSUFBSSxDQUFDRixLQUFLLEdBQUcsSUFBSTtJQUNqQixJQUFJNXFCLFNBQVMsQ0FBQ2tELE1BQU0sS0FBSyxDQUFDLEVBQ3RCLE9BQU8sSUFBSSxDQUFDNmxCLFFBQVEsQ0FBQ3BuQixJQUFJLENBQUMsSUFBSSxDQUFDa21CLE1BQU0sQ0FBQztJQUMxQyxPQUFPLElBQUksQ0FBQ2tCLFFBQVEsQ0FBQ2hwQixLQUFLLENBQUMsSUFBSSxDQUFDOG5CLE1BQU0sRUFBRTduQixTQUFTLENBQUM7RUFDdEQ7QUFDSjtBQUNBLFNBQVMrcUIsU0FBU0EsQ0FBQ2xELE1BQU0sRUFBRXlCLElBQUksRUFBRVAsUUFBUSxFQUFFO0VBQ3ZDLElBQUlqYixLQUFLLEdBQUc7SUFBRThjLEtBQUssRUFBRSxLQUFLO0lBQUVFLE1BQU0sRUFBRXRiLFNBQVM7SUFBRXFZLE1BQU0sRUFBRUEsTUFBTTtJQUFFeUIsSUFBSSxFQUFFQSxJQUFJO0lBQUVQLFFBQVEsRUFBRUE7RUFBUyxDQUFDO0VBQy9GLElBQUlpQyxPQUFPLEdBQUdMLFdBQVcsQ0FBQ3RULElBQUksQ0FBQ3ZKLEtBQUssQ0FBQztFQUNyQ2tkLE9BQU8sQ0FBQ2pDLFFBQVEsR0FBR0EsUUFBUTtFQUMzQmpiLEtBQUssQ0FBQ2dkLE1BQU0sR0FBR0UsT0FBTztFQUN0QixPQUFPQSxPQUFPO0FBQ2xCO0FBQ0F4QyxZQUFZLENBQUNqUixTQUFTLENBQUNrUixJQUFJLEdBQUcsU0FBU0EsSUFBSUEsQ0FBQ2EsSUFBSSxFQUFFUCxRQUFRLEVBQUU7RUFDeERELGFBQWEsQ0FBQ0MsUUFBUSxDQUFDO0VBQ3ZCLElBQUksQ0FBQzBCLEVBQUUsQ0FBQ25CLElBQUksRUFBRXlCLFNBQVMsQ0FBQyxJQUFJLEVBQUV6QixJQUFJLEVBQUVQLFFBQVEsQ0FBQyxDQUFDO0VBQzlDLE9BQU8sSUFBSTtBQUNmLENBQUM7QUFDRFAsWUFBWSxDQUFDalIsU0FBUyxDQUFDMFQsbUJBQW1CLEdBQ3RDLFNBQVNBLG1CQUFtQkEsQ0FBQzNCLElBQUksRUFBRVAsUUFBUSxFQUFFO0VBQ3pDRCxhQUFhLENBQUNDLFFBQVEsQ0FBQztFQUN2QixJQUFJLENBQUMyQixlQUFlLENBQUNwQixJQUFJLEVBQUV5QixTQUFTLENBQUMsSUFBSSxFQUFFekIsSUFBSSxFQUFFUCxRQUFRLENBQUMsQ0FBQztFQUMzRCxPQUFPLElBQUk7QUFDZixDQUFDO0FBQ0w7QUFDQVAsWUFBWSxDQUFDalIsU0FBUyxDQUFDc1QsY0FBYyxHQUNqQyxTQUFTQSxjQUFjQSxDQUFDdkIsSUFBSSxFQUFFUCxRQUFRLEVBQUU7RUFDcEMsSUFBSW1DLElBQUksRUFBRXZaLE1BQU0sRUFBRXdaLFFBQVEsRUFBRXpWLENBQUMsRUFBRTBWLGdCQUFnQjtFQUMvQ3RDLGFBQWEsQ0FBQ0MsUUFBUSxDQUFDO0VBQ3ZCcFgsTUFBTSxHQUFHLElBQUksQ0FBQytXLE9BQU87RUFDckIsSUFBSS9XLE1BQU0sS0FBS25DLFNBQVMsRUFDcEIsT0FBTyxJQUFJO0VBQ2YwYixJQUFJLEdBQUd2WixNQUFNLENBQUMyWCxJQUFJLENBQUM7RUFDbkIsSUFBSTRCLElBQUksS0FBSzFiLFNBQVMsRUFDbEIsT0FBTyxJQUFJO0VBQ2YsSUFBSTBiLElBQUksS0FBS25DLFFBQVEsSUFBSW1DLElBQUksQ0FBQ25DLFFBQVEsS0FBS0EsUUFBUSxFQUFFO0lBQ2pELElBQUksRUFBRSxJQUFJLENBQUNKLFlBQVksS0FBSyxDQUFDLEVBQ3pCLElBQUksQ0FBQ0QsT0FBTyxHQUFHNVosTUFBTSxDQUFDcUksTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQ2xDO01BQ0QsT0FBT3hGLE1BQU0sQ0FBQzJYLElBQUksQ0FBQztNQUNuQixJQUFJM1gsTUFBTSxDQUFDa1osY0FBYyxFQUNyQixJQUFJLENBQUN4QixJQUFJLENBQUMsZ0JBQWdCLEVBQUVDLElBQUksRUFBRTRCLElBQUksQ0FBQ25DLFFBQVEsSUFBSUEsUUFBUSxDQUFDO0lBQ3BFO0VBQ0osQ0FBQyxNQUNJLElBQUksT0FBT21DLElBQUksS0FBSyxVQUFVLEVBQUU7SUFDakNDLFFBQVEsR0FBRyxDQUFDLENBQUM7SUFDYixLQUFLelYsQ0FBQyxHQUFHd1YsSUFBSSxDQUFDaG9CLE1BQU0sR0FBRyxDQUFDLEVBQUV3UyxDQUFDLElBQUksQ0FBQyxFQUFFQSxDQUFDLEVBQUUsRUFBRTtNQUNuQyxJQUFJd1YsSUFBSSxDQUFDeFYsQ0FBQyxDQUFDLEtBQUtxVCxRQUFRLElBQUltQyxJQUFJLENBQUN4VixDQUFDLENBQUMsQ0FBQ3FULFFBQVEsS0FBS0EsUUFBUSxFQUFFO1FBQ3ZEcUMsZ0JBQWdCLEdBQUdGLElBQUksQ0FBQ3hWLENBQUMsQ0FBQyxDQUFDcVQsUUFBUTtRQUNuQ29DLFFBQVEsR0FBR3pWLENBQUM7UUFDWjtNQUNKO0lBQ0o7SUFDQSxJQUFJeVYsUUFBUSxHQUFHLENBQUMsRUFDWixPQUFPLElBQUk7SUFDZixJQUFJQSxRQUFRLEtBQUssQ0FBQyxFQUNkRCxJQUFJLENBQUNHLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FDWjtNQUNEQyxTQUFTLENBQUNKLElBQUksRUFBRUMsUUFBUSxDQUFDO0lBQzdCO0lBQ0EsSUFBSUQsSUFBSSxDQUFDaG9CLE1BQU0sS0FBSyxDQUFDLEVBQ2pCeU8sTUFBTSxDQUFDMlgsSUFBSSxDQUFDLEdBQUc0QixJQUFJLENBQUMsQ0FBQyxDQUFDO0lBQzFCLElBQUl2WixNQUFNLENBQUNrWixjQUFjLEtBQUtyYixTQUFTLEVBQ25DLElBQUksQ0FBQzZaLElBQUksQ0FBQyxnQkFBZ0IsRUFBRUMsSUFBSSxFQUFFOEIsZ0JBQWdCLElBQUlyQyxRQUFRLENBQUM7RUFDdkU7RUFDQSxPQUFPLElBQUk7QUFDZixDQUFDO0FBQ0xQLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQ2dVLEdBQUcsR0FBRy9DLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQ3NULGNBQWM7QUFDbEVyQyxZQUFZLENBQUNqUixTQUFTLENBQUNpVSxrQkFBa0IsR0FDckMsU0FBU0Esa0JBQWtCQSxDQUFDbEMsSUFBSSxFQUFFO0VBQzlCLElBQUlPLFNBQVMsRUFBRWxZLE1BQU0sRUFBRStELENBQUM7RUFDeEIvRCxNQUFNLEdBQUcsSUFBSSxDQUFDK1csT0FBTztFQUNyQixJQUFJL1csTUFBTSxLQUFLbkMsU0FBUyxFQUNwQixPQUFPLElBQUk7RUFDZjtFQUNBLElBQUltQyxNQUFNLENBQUNrWixjQUFjLEtBQUtyYixTQUFTLEVBQUU7SUFDckMsSUFBSXhQLFNBQVMsQ0FBQ2tELE1BQU0sS0FBSyxDQUFDLEVBQUU7TUFDeEIsSUFBSSxDQUFDd2xCLE9BQU8sR0FBRzVaLE1BQU0sQ0FBQ3FJLE1BQU0sQ0FBQyxJQUFJLENBQUM7TUFDbEMsSUFBSSxDQUFDd1IsWUFBWSxHQUFHLENBQUM7SUFDekIsQ0FBQyxNQUNJLElBQUloWCxNQUFNLENBQUMyWCxJQUFJLENBQUMsS0FBSzlaLFNBQVMsRUFBRTtNQUNqQyxJQUFJLEVBQUUsSUFBSSxDQUFDbVosWUFBWSxLQUFLLENBQUMsRUFDekIsSUFBSSxDQUFDRCxPQUFPLEdBQUc1WixNQUFNLENBQUNxSSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsS0FFbkMsT0FBT3hGLE1BQU0sQ0FBQzJYLElBQUksQ0FBQztJQUMzQjtJQUNBLE9BQU8sSUFBSTtFQUNmO0VBQ0E7RUFDQSxJQUFJdHBCLFNBQVMsQ0FBQ2tELE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDeEIsSUFBSTZMLElBQUksR0FBR0QsTUFBTSxDQUFDQyxJQUFJLENBQUM0QyxNQUFNLENBQUM7SUFDOUIsSUFBSXdRLEdBQUc7SUFDUCxLQUFLek0sQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHM0csSUFBSSxDQUFDN0wsTUFBTSxFQUFFLEVBQUV3UyxDQUFDLEVBQUU7TUFDOUJ5TSxHQUFHLEdBQUdwVCxJQUFJLENBQUMyRyxDQUFDLENBQUM7TUFDYixJQUFJeU0sR0FBRyxLQUFLLGdCQUFnQixFQUN4QjtNQUNKLElBQUksQ0FBQ3FKLGtCQUFrQixDQUFDckosR0FBRyxDQUFDO0lBQ2hDO0lBQ0EsSUFBSSxDQUFDcUosa0JBQWtCLENBQUMsZ0JBQWdCLENBQUM7SUFDekMsSUFBSSxDQUFDOUMsT0FBTyxHQUFHNVosTUFBTSxDQUFDcUksTUFBTSxDQUFDLElBQUksQ0FBQztJQUNsQyxJQUFJLENBQUN3UixZQUFZLEdBQUcsQ0FBQztJQUNyQixPQUFPLElBQUk7RUFDZjtFQUNBa0IsU0FBUyxHQUFHbFksTUFBTSxDQUFDMlgsSUFBSSxDQUFDO0VBQ3hCLElBQUksT0FBT08sU0FBUyxLQUFLLFVBQVUsRUFBRTtJQUNqQyxJQUFJLENBQUNnQixjQUFjLENBQUN2QixJQUFJLEVBQUVPLFNBQVMsQ0FBQztFQUN4QyxDQUFDLE1BQ0ksSUFBSUEsU0FBUyxLQUFLcmEsU0FBUyxFQUFFO0lBQzlCO0lBQ0EsS0FBS2tHLENBQUMsR0FBR21VLFNBQVMsQ0FBQzNtQixNQUFNLEdBQUcsQ0FBQyxFQUFFd1MsQ0FBQyxJQUFJLENBQUMsRUFBRUEsQ0FBQyxFQUFFLEVBQUU7TUFDeEMsSUFBSSxDQUFDbVYsY0FBYyxDQUFDdkIsSUFBSSxFQUFFTyxTQUFTLENBQUNuVSxDQUFDLENBQUMsQ0FBQztJQUMzQztFQUNKO0VBQ0EsT0FBTyxJQUFJO0FBQ2YsQ0FBQztBQUNMLFNBQVMrVixVQUFVQSxDQUFDNUQsTUFBTSxFQUFFeUIsSUFBSSxFQUFFb0MsTUFBTSxFQUFFO0VBQ3RDLElBQUkvWixNQUFNLEdBQUdrVyxNQUFNLENBQUNhLE9BQU87RUFDM0IsSUFBSS9XLE1BQU0sS0FBS25DLFNBQVMsRUFDcEIsT0FBTyxFQUFFO0VBQ2IsSUFBSW1jLFVBQVUsR0FBR2hhLE1BQU0sQ0FBQzJYLElBQUksQ0FBQztFQUM3QixJQUFJcUMsVUFBVSxLQUFLbmMsU0FBUyxFQUN4QixPQUFPLEVBQUU7RUFDYixJQUFJLE9BQU9tYyxVQUFVLEtBQUssVUFBVSxFQUNoQyxPQUFPRCxNQUFNLEdBQUcsQ0FBQ0MsVUFBVSxDQUFDNUMsUUFBUSxJQUFJNEMsVUFBVSxDQUFDLEdBQUcsQ0FBQ0EsVUFBVSxDQUFDO0VBQ3RFLE9BQU9ELE1BQU0sR0FDVEUsZUFBZSxDQUFDRCxVQUFVLENBQUMsR0FBRzdCLFVBQVUsQ0FBQzZCLFVBQVUsRUFBRUEsVUFBVSxDQUFDem9CLE1BQU0sQ0FBQztBQUMvRTtBQUNBc2xCLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQ3NTLFNBQVMsR0FBRyxTQUFTQSxTQUFTQSxDQUFDUCxJQUFJLEVBQUU7RUFDeEQsT0FBT21DLFVBQVUsQ0FBQyxJQUFJLEVBQUVuQyxJQUFJLEVBQUUsSUFBSSxDQUFDO0FBQ3ZDLENBQUM7QUFDRGQsWUFBWSxDQUFDalIsU0FBUyxDQUFDc1UsWUFBWSxHQUFHLFNBQVNBLFlBQVlBLENBQUN2QyxJQUFJLEVBQUU7RUFDOUQsT0FBT21DLFVBQVUsQ0FBQyxJQUFJLEVBQUVuQyxJQUFJLEVBQUUsS0FBSyxDQUFDO0FBQ3hDLENBQUM7QUFDRGQsWUFBWSxDQUFDc0QsYUFBYSxHQUFHLFVBQVV4QixPQUFPLEVBQUVoQixJQUFJLEVBQUU7RUFDbEQsSUFBSSxPQUFPZ0IsT0FBTyxDQUFDd0IsYUFBYSxLQUFLLFVBQVUsRUFBRTtJQUM3QyxPQUFPeEIsT0FBTyxDQUFDd0IsYUFBYSxDQUFDeEMsSUFBSSxDQUFDO0VBQ3RDLENBQUMsTUFDSTtJQUNELE9BQU93QyxhQUFhLENBQUNucUIsSUFBSSxDQUFDMm9CLE9BQU8sRUFBRWhCLElBQUksQ0FBQztFQUM1QztBQUNKLENBQUM7QUFDRGQsWUFBWSxDQUFDalIsU0FBUyxDQUFDdVUsYUFBYSxHQUFHQSxhQUFhO0FBQ3BELFNBQVNBLGFBQWFBLENBQUN4QyxJQUFJLEVBQUU7RUFDekIsSUFBSTNYLE1BQU0sR0FBRyxJQUFJLENBQUMrVyxPQUFPO0VBQ3pCLElBQUkvVyxNQUFNLEtBQUtuQyxTQUFTLEVBQUU7SUFDdEIsSUFBSW1jLFVBQVUsR0FBR2hhLE1BQU0sQ0FBQzJYLElBQUksQ0FBQztJQUM3QixJQUFJLE9BQU9xQyxVQUFVLEtBQUssVUFBVSxFQUFFO01BQ2xDLE9BQU8sQ0FBQztJQUNaLENBQUMsTUFDSSxJQUFJQSxVQUFVLEtBQUtuYyxTQUFTLEVBQUU7TUFDL0IsT0FBT21jLFVBQVUsQ0FBQ3pvQixNQUFNO0lBQzVCO0VBQ0o7RUFDQSxPQUFPLENBQUM7QUFDWjtBQUNBc2xCLFlBQVksQ0FBQ2pSLFNBQVMsQ0FBQ3dVLFVBQVUsR0FBRyxTQUFTQSxVQUFVQSxDQUFBLEVBQUc7RUFDdEQsT0FBTyxJQUFJLENBQUNwRCxZQUFZLEdBQUcsQ0FBQyxHQUFHWixjQUFjLENBQUMsSUFBSSxDQUFDVyxPQUFPLENBQUMsR0FBRyxFQUFFO0FBQ3BFLENBQUM7QUFDRCxTQUFTb0IsVUFBVUEsQ0FBQ2tDLEdBQUcsRUFBRTVXLENBQUMsRUFBRTtFQUN4QixJQUFJNlcsSUFBSSxHQUFHLElBQUlsVSxLQUFLLENBQUMzQyxDQUFDLENBQUM7RUFDdkIsS0FBSyxJQUFJTSxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdOLENBQUMsRUFBRSxFQUFFTSxDQUFDLEVBQ3RCdVcsSUFBSSxDQUFDdlcsQ0FBQyxDQUFDLEdBQUdzVyxHQUFHLENBQUN0VyxDQUFDLENBQUM7RUFDcEIsT0FBT3VXLElBQUk7QUFDZjtBQUNBLFNBQVNYLFNBQVNBLENBQUNKLElBQUksRUFBRW5ILEtBQUssRUFBRTtFQUM1QixPQUFPQSxLQUFLLEdBQUcsQ0FBQyxHQUFHbUgsSUFBSSxDQUFDaG9CLE1BQU0sRUFBRTZnQixLQUFLLEVBQUUsRUFDbkNtSCxJQUFJLENBQUNuSCxLQUFLLENBQUMsR0FBR21ILElBQUksQ0FBQ25ILEtBQUssR0FBRyxDQUFDLENBQUM7RUFDakNtSCxJQUFJLENBQUN4RSxHQUFHLENBQUMsQ0FBQztBQUNkO0FBQ0EsU0FBU2tGLGVBQWVBLENBQUNJLEdBQUcsRUFBRTtFQUMxQixJQUFJMUYsR0FBRyxHQUFHLElBQUl2TyxLQUFLLENBQUNpVSxHQUFHLENBQUM5b0IsTUFBTSxDQUFDO0VBQy9CLEtBQUssSUFBSXdTLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRzRRLEdBQUcsQ0FBQ3BqQixNQUFNLEVBQUUsRUFBRXdTLENBQUMsRUFBRTtJQUNqQzRRLEdBQUcsQ0FBQzVRLENBQUMsQ0FBQyxHQUFHc1csR0FBRyxDQUFDdFcsQ0FBQyxDQUFDLENBQUNxVCxRQUFRLElBQUlpRCxHQUFHLENBQUN0VyxDQUFDLENBQUM7RUFDdEM7RUFDQSxPQUFPNFEsR0FBRztBQUNkO0FBQ0EsU0FBU21DLElBQUlBLENBQUM2QixPQUFPLEVBQUUzZixJQUFJLEVBQUU7RUFDekIsT0FBTyxJQUFJOUwsT0FBTyxDQUFDLFVBQVVDLE9BQU8sRUFBRUMsTUFBTSxFQUFFO0lBQzFDLFNBQVNtdEIsYUFBYUEsQ0FBQ3ZaLEdBQUcsRUFBRTtNQUN4QjJYLE9BQU8sQ0FBQ08sY0FBYyxDQUFDbGdCLElBQUksRUFBRXdoQixRQUFRLENBQUM7TUFDdENwdEIsTUFBTSxDQUFDNFQsR0FBRyxDQUFDO0lBQ2Y7SUFDQSxTQUFTd1osUUFBUUEsQ0FBQSxFQUFHO01BQ2hCLElBQUksT0FBTzdCLE9BQU8sQ0FBQ08sY0FBYyxLQUFLLFVBQVUsRUFBRTtRQUM5Q1AsT0FBTyxDQUFDTyxjQUFjLENBQUMsT0FBTyxFQUFFcUIsYUFBYSxDQUFDO01BQ2xEO01BQ0FwdEIsT0FBTyxDQUFDLEVBQUUsQ0FBQzhXLEtBQUssQ0FBQ2pVLElBQUksQ0FBQzNCLFNBQVMsQ0FBQyxDQUFDO0lBQ3JDO0lBQ0E7SUFDQW9zQiw4QkFBOEIsQ0FBQzlCLE9BQU8sRUFBRTNmLElBQUksRUFBRXdoQixRQUFRLEVBQUU7TUFBRTFELElBQUksRUFBRTtJQUFLLENBQUMsQ0FBQztJQUN2RSxJQUFJOWQsSUFBSSxLQUFLLE9BQU8sRUFBRTtNQUNsQjBoQiw2QkFBNkIsQ0FBQy9CLE9BQU8sRUFBRTRCLGFBQWEsRUFBRTtRQUFFekQsSUFBSSxFQUFFO01BQUssQ0FBQyxDQUFDO0lBQ3pFO0VBQ0osQ0FBQyxDQUFDO0FBQ047QUFDQSxTQUFTNEQsNkJBQTZCQSxDQUFDL0IsT0FBTyxFQUFFWCxPQUFPLEVBQUUyQyxLQUFLLEVBQUU7RUFDNUQsSUFBSSxPQUFPaEMsT0FBTyxDQUFDRyxFQUFFLEtBQUssVUFBVSxFQUFFO0lBQ2xDMkIsOEJBQThCLENBQUM5QixPQUFPLEVBQUUsT0FBTyxFQUFFWCxPQUFPLEVBQUUyQyxLQUFLLENBQUM7RUFDcEU7QUFDSjtBQUNBLFNBQVNGLDhCQUE4QkEsQ0FBQzlCLE9BQU8sRUFBRTNmLElBQUksRUFBRW9lLFFBQVEsRUFBRXVELEtBQUssRUFBRTtFQUNwRSxJQUFJLE9BQU9oQyxPQUFPLENBQUNHLEVBQUUsS0FBSyxVQUFVLEVBQUU7SUFDbEMsSUFBSTZCLEtBQUssQ0FBQzdELElBQUksRUFBRTtNQUNaNkIsT0FBTyxDQUFDN0IsSUFBSSxDQUFDOWQsSUFBSSxFQUFFb2UsUUFBUSxDQUFDO0lBQ2hDLENBQUMsTUFDSTtNQUNEdUIsT0FBTyxDQUFDRyxFQUFFLENBQUM5ZixJQUFJLEVBQUVvZSxRQUFRLENBQUM7SUFDOUI7RUFDSixDQUFDLE1BQ0ksSUFBSSxPQUFPdUIsT0FBTyxDQUFDalgsZ0JBQWdCLEtBQUssVUFBVSxFQUFFO0lBQ3JEO0lBQ0E7SUFDQWlYLE9BQU8sQ0FBQ2pYLGdCQUFnQixDQUFDMUksSUFBSSxFQUFFLFNBQVM0aEIsWUFBWUEsQ0FBQ3pjLEdBQUcsRUFBRTtNQUN0RDtNQUNBO01BQ0EsSUFBSXdjLEtBQUssQ0FBQzdELElBQUksRUFBRTtRQUNaNkIsT0FBTyxDQUFDa0MsbUJBQW1CLENBQUM3aEIsSUFBSSxFQUFFNGhCLFlBQVksQ0FBQztNQUNuRDtNQUNBeEQsUUFBUSxDQUFDalosR0FBRyxDQUFDO0lBQ2pCLENBQUMsQ0FBQztFQUNOLENBQUMsTUFDSTtJQUNELE1BQU0sSUFBSStJLFNBQVMsQ0FBQyxxRUFBcUUsR0FBRyxPQUFPeVIsT0FBTyxDQUFDO0VBQy9HO0FBQ0osQzs7Ozs7Ozs7Ozs7Ozs7O0FDcGJBLFNBQVNtQyxPQUFPQSxDQUFDalcsQ0FBQyxFQUFFO0VBQ2hCLHlCQUF5Qjs7RUFDekIsT0FBT2lXLE9BQU8sR0FBRyxVQUFVLElBQUksT0FBT3pWLE1BQU0sSUFBSSxRQUFRLElBQUksT0FBT0EsTUFBTSxDQUFDMFYsUUFBUSxHQUFHLFVBQVVsVyxDQUFDLEVBQUU7SUFBRSxPQUFPLE9BQU9BLENBQUM7RUFBRSxDQUFDLEdBQUcsVUFBVUEsQ0FBQyxFQUFFO0lBQUUsT0FBT0EsQ0FBQyxJQUFJLFVBQVUsSUFBSSxPQUFPUSxNQUFNLElBQUlSLENBQUMsQ0FBQzBNLFdBQVcsS0FBS2xNLE1BQU0sSUFBSVIsQ0FBQyxLQUFLUSxNQUFNLENBQUNPLFNBQVMsR0FBRyxRQUFRLEdBQUcsT0FBT2YsQ0FBQztFQUFFLENBQUMsRUFBRWlXLE9BQU8sQ0FBQ2pXLENBQUMsQ0FBQztBQUM5UTtBQUNBLFNBQVNtVyxlQUFlQSxDQUFDbFgsQ0FBQyxFQUFFTCxDQUFDLEVBQUU7RUFBRSxJQUFJLEVBQUVLLENBQUMsWUFBWUwsQ0FBQyxDQUFDLEVBQ2xELE1BQU0sSUFBSXlELFNBQVMsQ0FBQyxtQ0FBbUMsQ0FBQztBQUFFO0FBQzlELFNBQVMrVCxpQkFBaUJBLENBQUM1WSxDQUFDLEVBQUVzQyxDQUFDLEVBQUU7RUFBRSxLQUFLLElBQUlwQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdvQyxDQUFDLENBQUNwVCxNQUFNLEVBQUVnUixDQUFDLEVBQUUsRUFBRTtJQUNsRSxJQUFJc0MsQ0FBQyxHQUFHRixDQUFDLENBQUNwQyxDQUFDLENBQUM7SUFDWnNDLENBQUMsQ0FBQ08sVUFBVSxHQUFHUCxDQUFDLENBQUNPLFVBQVUsSUFBSSxDQUFDLENBQUMsRUFBRVAsQ0FBQyxDQUFDbUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxFQUFFLE9BQU8sSUFBSW5DLENBQUMsS0FBS0EsQ0FBQyxDQUFDNEwsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUV0VCxNQUFNLENBQUNnSSxjQUFjLENBQUM5QyxDQUFDLEVBQUU2WSxjQUFjLENBQUNyVyxDQUFDLENBQUMyTCxHQUFHLENBQUMsRUFBRTNMLENBQUMsQ0FBQztFQUNqSjtBQUFFO0FBQ0YsU0FBU3NXLFlBQVlBLENBQUM5WSxDQUFDLEVBQUVzQyxDQUFDLEVBQUVwQyxDQUFDLEVBQUU7RUFBRSxPQUFPb0MsQ0FBQyxJQUFJc1csaUJBQWlCLENBQUM1WSxDQUFDLENBQUN1RCxTQUFTLEVBQUVqQixDQUFDLENBQUMsRUFBRXBDLENBQUMsSUFBSTBZLGlCQUFpQixDQUFDNVksQ0FBQyxFQUFFRSxDQUFDLENBQUMsRUFBRXBGLE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQzlDLENBQUMsRUFBRSxXQUFXLEVBQUU7SUFBRW9PLFFBQVEsRUFBRSxDQUFDO0VBQUUsQ0FBQyxDQUFDLEVBQUVwTyxDQUFDO0FBQUU7QUFDMUssU0FBUzZZLGNBQWNBLENBQUMzWSxDQUFDLEVBQUU7RUFBRSxJQUFJd0IsQ0FBQyxHQUFHcVgsWUFBWSxDQUFDN1ksQ0FBQyxFQUFFLFFBQVEsQ0FBQztFQUFFLE9BQU8sUUFBUSxJQUFJdVksT0FBTyxDQUFDL1csQ0FBQyxDQUFDLEdBQUdBLENBQUMsR0FBR0EsQ0FBQyxHQUFHLEVBQUU7QUFBRTtBQUM1RyxTQUFTcVgsWUFBWUEsQ0FBQzdZLENBQUMsRUFBRW9DLENBQUMsRUFBRTtFQUFFLElBQUksUUFBUSxJQUFJbVcsT0FBTyxDQUFDdlksQ0FBQyxDQUFDLElBQUksQ0FBQ0EsQ0FBQyxFQUMxRCxPQUFPQSxDQUFDO0VBQUUsSUFBSUYsQ0FBQyxHQUFHRSxDQUFDLENBQUM4QyxNQUFNLENBQUNnVyxXQUFXLENBQUM7RUFBRSxJQUFJLEtBQUssQ0FBQyxLQUFLaFosQ0FBQyxFQUFFO0lBQzNELElBQUkwQixDQUFDLEdBQUcxQixDQUFDLENBQUNyUyxJQUFJLENBQUN1UyxDQUFDLEVBQUVvQyxDQUFDLElBQUksU0FBUyxDQUFDO0lBQ2pDLElBQUksUUFBUSxJQUFJbVcsT0FBTyxDQUFDL1csQ0FBQyxDQUFDLEVBQ3RCLE9BQU9BLENBQUM7SUFDWixNQUFNLElBQUltRCxTQUFTLENBQUMsOENBQThDLENBQUM7RUFDdkU7RUFBRSxPQUFPLENBQUMsUUFBUSxLQUFLdkMsQ0FBQyxHQUFHMkMsTUFBTSxHQUFHcVAsTUFBTSxFQUFFcFUsQ0FBQyxDQUFDO0FBQUU7QUFDVjtBQUN0QyxJQUFJK1ksZUFBZSxHQUFHLGFBQWMsWUFBWTtFQUM1QztBQUNKO0FBQ0E7RUFDSSxTQUFTQSxlQUFlQSxDQUFDcmlCLEdBQUcsRUFBRTtJQUMxQitoQixlQUFlLENBQUMsSUFBSSxFQUFFTSxlQUFlLENBQUM7SUFDdEMsSUFBSSxDQUFDQyxNQUFNLEdBQUcsSUFBSUMsU0FBUyxDQUFDdmlCLEdBQUcsQ0FBQztJQUNoQyxJQUFJLENBQUNzaUIsTUFBTSxDQUFDRSxPQUFPLEdBQUcsVUFBVTVaLEtBQUssRUFBRTtNQUNuQzFQLDhDQUFHLENBQUMwUCxLQUFLLENBQUNBLEtBQUssQ0FBQztJQUNwQixDQUFDO0VBQ0w7RUFDQTtBQUNKO0FBQ0E7RUFDSSxPQUFPc1osWUFBWSxDQUFDRyxlQUFlLEVBQUUsQ0FBQztJQUM5QjlLLEdBQUcsRUFBRSxRQUFRO0lBQ2J2WixLQUFLLEVBQUUsU0FBU3lrQixNQUFNQSxDQUFDN1UsQ0FBQyxFQUFFO01BQ3RCLElBQUksQ0FBQzBVLE1BQU0sQ0FBQ0ksTUFBTSxHQUFHOVUsQ0FBQztJQUMxQjtJQUNBO0FBQ1o7QUFDQTtFQUNRLENBQUMsRUFBRTtJQUNDMkosR0FBRyxFQUFFLFNBQVM7SUFDZHZaLEtBQUssRUFBRSxTQUFTMmtCLE9BQU9BLENBQUMvVSxDQUFDLEVBQUU7TUFDdkIsSUFBSSxDQUFDMFUsTUFBTSxDQUFDTSxPQUFPLEdBQUdoVixDQUFDO0lBQzNCO0lBQ0E7SUFDQTtBQUNaO0FBQ0E7RUFDUSxDQUFDLEVBQUU7SUFDQzJKLEdBQUcsRUFBRSxXQUFXO0lBQ2hCdlosS0FBSyxFQUFFLFNBQVM2a0IsU0FBU0EsQ0FBQ2pWLENBQUMsRUFBRTtNQUN6QixJQUFJLENBQUMwVSxNQUFNLENBQUNRLFNBQVMsR0FBRyxVQUFVMVosQ0FBQyxFQUFFO1FBQ2pDd0UsQ0FBQyxDQUFDeEUsQ0FBQyxDQUFDN0ksSUFBSSxDQUFDO01BQ2IsQ0FBQztJQUNMO0VBQ0osQ0FBQyxDQUFDLENBQUM7QUFDWCxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7QUMzRFU7O0FBQ2I7QUFBUyxDQUFDLFlBQVk7RUFDbEIsUUFBUyxZQUFZOztFQUNyQjtFQUFTLElBQUl3aUIsbUJBQW1CLEdBQUk7SUFDaEMsS0FBTSx3Q0FBd0M7SUFDOUM7QUFDUjtBQUNBO0lBQ1E7SUFBTyxTQUFBQyxDQUFVQyx1QkFBdUIsRUFBRUMsMEJBQW1CLEVBQUVDLDhCQUFtQixFQUFFO01BQ2hGQSw4QkFBbUIsQ0FBQ3pYLENBQUMsQ0FBQ3dYLDBCQUFtQixDQUFDO01BQzFDO01BQXFCQyw4QkFBbUIsQ0FBQ25YLENBQUMsQ0FBQ2tYLDBCQUFtQixFQUFFO1FBQzVELG9CQUFxQkUsWUFBWSxFQUFFLFNBQUFBLENBQUEsRUFBWTtVQUFFLE9BQU8sYUFBY0EsWUFBWTtRQUFFO1FBQ3BGO01BQ0osQ0FBQyxDQUFDO01BQ0YsU0FBU0EsWUFBWUEsQ0FBQSxFQUFHO1FBQ3BCLE9BQU87VUFDSHJzQixJQUFJLEVBQUUsU0FBU0EsSUFBSUEsQ0FBQSxFQUFHLENBQUU7UUFDNUIsQ0FBQztNQUNMO01BQ0E7QUFDWjtBQUNBO01BQ1k7TUFDQTtJQUNKLENBQUMsQ0FBQztJQUNGLEtBQU0sOENBQThDO0lBQ3BEO0FBQ1I7QUFDQTtJQUNRO0lBQU8sU0FBQXNzQixDQUFVOUksTUFBTSxFQUFFO01BQ3JCO0FBQ1o7QUFDQTtBQUNBO01BQ1ksU0FBU3NILE9BQU9BLENBQUNqVyxDQUFDLEVBQUU7UUFDaEIseUJBQXlCOztRQUN6QixPQUFPaVcsT0FBTyxHQUFHLFVBQVUsSUFBSSxRQUFRLE9BQU96VixNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLEdBQUcsVUFBVXRCLENBQUMsRUFBRTtVQUFFLE9BQU9BLENBQUM7UUFBRSxDQUFDLENBQUMsSUFBSSxRQUFRLElBQUksT0FBTyxDQUFDLE9BQU9zQixNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLEdBQUcsVUFBVXRCLENBQUMsRUFBRTtVQUFFLE9BQU9BLENBQUM7UUFBRSxDQUFDLEVBQUVnWCxRQUFRLEdBQUcsVUFBVWxXLENBQUMsRUFBRTtVQUM1TixPQUFPLE9BQU9BLENBQUM7UUFDbkIsQ0FBQyxHQUFHLFVBQVVBLENBQUMsRUFBRTtVQUNiLE9BQU9BLENBQUMsSUFBSSxVQUFVLElBQUksUUFBUSxPQUFPUSxNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLEdBQUcsVUFBVXRCLENBQUMsRUFBRTtZQUFFLE9BQU9BLENBQUM7VUFBRSxDQUFDLENBQUMsSUFBSWMsQ0FBQyxDQUFDME0sV0FBVyxNQUFNLE9BQU9sTSxNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLEdBQUcsVUFBVXRCLENBQUMsRUFBRTtZQUFFLE9BQU9BLENBQUM7VUFBRSxDQUFDLENBQUMsSUFBSWMsQ0FBQyxLQUFLLENBQUMsT0FBT1EsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7WUFBRSxPQUFPQSxDQUFDO1VBQUUsQ0FBQyxFQUFFNkIsU0FBUyxHQUFHLFFBQVEsR0FBRyxPQUFPZixDQUFDO1FBQ3BULENBQUMsRUFBRWlXLE9BQU8sQ0FBQ2pXLENBQUMsQ0FBQztNQUNqQjtNQUNBLFNBQVMwWCxrQkFBa0JBLENBQUM1WCxDQUFDLEVBQUU7UUFDM0IsT0FBTzZYLGtCQUFrQixDQUFDN1gsQ0FBQyxDQUFDLElBQUk4WCxnQkFBZ0IsQ0FBQzlYLENBQUMsQ0FBQyxJQUFJK1gsMkJBQTJCLENBQUMvWCxDQUFDLENBQUMsSUFBSWdZLGtCQUFrQixDQUFDLENBQUM7TUFDakg7TUFDQSxTQUFTQSxrQkFBa0JBLENBQUEsRUFBRztRQUMxQixNQUFNLElBQUl6VixTQUFTLENBQUMsc0lBQXNJLENBQUM7TUFDL0o7TUFDQSxTQUFTd1YsMkJBQTJCQSxDQUFDL1gsQ0FBQyxFQUFFYixDQUFDLEVBQUU7UUFDdkMsSUFBSWEsQ0FBQyxFQUFFO1VBQ0gsSUFBSSxRQUFRLElBQUksT0FBT0EsQ0FBQyxFQUNwQixPQUFPaVksaUJBQWlCLENBQUNqWSxDQUFDLEVBQUViLENBQUMsQ0FBQztVQUNsQyxJQUFJdkIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOUIsUUFBUSxDQUFDelEsSUFBSSxDQUFDMlUsQ0FBQyxDQUFDLENBQUNWLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7VUFDeEMsT0FBTyxRQUFRLEtBQUsxQixDQUFDLElBQUlvQyxDQUFDLENBQUM0TSxXQUFXLEtBQUtoUCxDQUFDLEdBQUdvQyxDQUFDLENBQUM0TSxXQUFXLENBQUN2WSxJQUFJLENBQUMsRUFBRSxLQUFLLEtBQUt1SixDQUFDLElBQUksS0FBSyxLQUFLQSxDQUFDLEdBQUc2RCxLQUFLLENBQUNxSSxJQUFJLENBQUM5SixDQUFDLENBQUMsR0FBRyxXQUFXLEtBQUtwQyxDQUFDLElBQUksMENBQTBDLENBQUM1UixJQUFJLENBQUM0UixDQUFDLENBQUMsR0FBR3FhLGlCQUFpQixDQUFDalksQ0FBQyxFQUFFYixDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7UUFDL047TUFDSjtNQUNBLFNBQVMyWSxnQkFBZ0JBLENBQUM5WCxDQUFDLEVBQUU7UUFDekIsSUFBSSxXQUFXLElBQUksUUFBUSxPQUFPVSxNQUFNLEtBQUssV0FBVyxHQUFHQSxNQUFNLEdBQUcsVUFBVXRCLENBQUMsRUFBRTtVQUFFLE9BQU9BLENBQUM7UUFBRSxDQUFDLENBQUMsSUFBSSxJQUFJLElBQUlZLENBQUMsQ0FBQyxDQUFDLE9BQU9VLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1VBQUUsT0FBT0EsQ0FBQztRQUFFLENBQUMsRUFBRWdYLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSXBXLENBQUMsQ0FBQyxZQUFZLENBQUMsRUFDbk4sT0FBT3lCLEtBQUssQ0FBQ3FJLElBQUksQ0FBQzlKLENBQUMsQ0FBQztNQUM1QjtNQUNBLFNBQVM2WCxrQkFBa0JBLENBQUM3WCxDQUFDLEVBQUU7UUFDM0IsSUFBSXlCLEtBQUssQ0FBQ2lQLE9BQU8sQ0FBQzFRLENBQUMsQ0FBQyxFQUNoQixPQUFPaVksaUJBQWlCLENBQUNqWSxDQUFDLENBQUM7TUFDbkM7TUFDQSxTQUFTaVksaUJBQWlCQSxDQUFDalksQ0FBQyxFQUFFYixDQUFDLEVBQUU7UUFDN0IsQ0FBQyxJQUFJLElBQUlBLENBQUMsSUFBSUEsQ0FBQyxHQUFHYSxDQUFDLENBQUNwVCxNQUFNLE1BQU11UyxDQUFDLEdBQUdhLENBQUMsQ0FBQ3BULE1BQU0sQ0FBQztRQUM3QyxLQUFLLElBQUk4USxDQUFDLEdBQUcsQ0FBQyxFQUFFb0IsQ0FBQyxHQUFHMkMsS0FBSyxDQUFDdEMsQ0FBQyxDQUFDLEVBQUV6QixDQUFDLEdBQUd5QixDQUFDLEVBQUV6QixDQUFDLEVBQUUsRUFDcENvQixDQUFDLENBQUNwQixDQUFDLENBQUMsR0FBR3NDLENBQUMsQ0FBQ3RDLENBQUMsQ0FBQztRQUNmLE9BQU9vQixDQUFDO01BQ1o7TUFDQSxTQUFTdVgsZUFBZUEsQ0FBQ2xYLENBQUMsRUFBRUwsQ0FBQyxFQUFFO1FBQzNCLElBQUksRUFBRUssQ0FBQyxZQUFZTCxDQUFDLENBQUMsRUFDakIsTUFBTSxJQUFJeUQsU0FBUyxDQUFDLG1DQUFtQyxDQUFDO01BQ2hFO01BQ0EsU0FBUytULGlCQUFpQkEsQ0FBQzVZLENBQUMsRUFBRXNDLENBQUMsRUFBRTtRQUM3QixLQUFLLElBQUlwQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdvQyxDQUFDLENBQUNwVCxNQUFNLEVBQUVnUixDQUFDLEVBQUUsRUFBRTtVQUMvQixJQUFJc0MsQ0FBQyxHQUFHRixDQUFDLENBQUNwQyxDQUFDLENBQUM7VUFDWnNDLENBQUMsQ0FBQ08sVUFBVSxHQUFHUCxDQUFDLENBQUNPLFVBQVUsSUFBSSxDQUFDLENBQUMsRUFBRVAsQ0FBQyxDQUFDbUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxFQUFFLE9BQU8sSUFBSW5DLENBQUMsS0FBS0EsQ0FBQyxDQUFDNEwsUUFBUSxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUV0VCxNQUFNLENBQUNnSSxjQUFjLENBQUM5QyxDQUFDLEVBQUU2WSxjQUFjLENBQUNyVyxDQUFDLENBQUMyTCxHQUFHLENBQUMsRUFBRTNMLENBQUMsQ0FBQztRQUNqSjtNQUNKO01BQ0EsU0FBU3NXLFlBQVlBLENBQUM5WSxDQUFDLEVBQUVzQyxDQUFDLEVBQUVwQyxDQUFDLEVBQUU7UUFDM0IsT0FBT29DLENBQUMsSUFBSXNXLGlCQUFpQixDQUFDNVksQ0FBQyxDQUFDdUQsU0FBUyxFQUFFakIsQ0FBQyxDQUFDLEVBQUVwQyxDQUFDLElBQUkwWSxpQkFBaUIsQ0FBQzVZLENBQUMsRUFBRUUsQ0FBQyxDQUFDLEVBQUVwRixNQUFNLENBQUNnSSxjQUFjLENBQUM5QyxDQUFDLEVBQUUsV0FBVyxFQUFFO1VBQy9Hb08sUUFBUSxFQUFFLENBQUM7UUFDZixDQUFDLENBQUMsRUFBRXBPLENBQUM7TUFDVDtNQUNBLFNBQVM2WSxjQUFjQSxDQUFDM1ksQ0FBQyxFQUFFO1FBQ3ZCLElBQUl3QixDQUFDLEdBQUdxWCxZQUFZLENBQUM3WSxDQUFDLEVBQUUsUUFBUSxDQUFDO1FBQ2pDLE9BQU8sUUFBUSxJQUFJdVksT0FBTyxDQUFDL1csQ0FBQyxDQUFDLEdBQUdBLENBQUMsR0FBR0EsQ0FBQyxHQUFHLEVBQUU7TUFDOUM7TUFDQSxTQUFTcVgsWUFBWUEsQ0FBQzdZLENBQUMsRUFBRW9DLENBQUMsRUFBRTtRQUN4QixJQUFJLFFBQVEsSUFBSW1XLE9BQU8sQ0FBQ3ZZLENBQUMsQ0FBQyxJQUFJLENBQUNBLENBQUMsRUFDNUIsT0FBT0EsQ0FBQztRQUNaLElBQUlGLENBQUMsR0FBR0UsQ0FBQyxDQUFDLENBQUMsT0FBTzhDLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1VBQUUsT0FBT0EsQ0FBQztRQUFFLENBQUMsRUFBRXNYLFdBQVcsQ0FBQztRQUM1RixJQUFJLEtBQUssQ0FBQyxLQUFLaFosQ0FBQyxFQUFFO1VBQ2QsSUFBSTBCLENBQUMsR0FBRzFCLENBQUMsQ0FBQ3JTLElBQUksQ0FBQ3VTLENBQUMsRUFBRW9DLENBQUMsSUFBSSxTQUFTLENBQUM7VUFDakMsSUFBSSxRQUFRLElBQUltVyxPQUFPLENBQUMvVyxDQUFDLENBQUMsRUFDdEIsT0FBT0EsQ0FBQztVQUNaLE1BQU0sSUFBSW1ELFNBQVMsQ0FBQyw4Q0FBOEMsQ0FBQztRQUN2RTtRQUNBLE9BQU8sQ0FBQyxRQUFRLEtBQUt2QyxDQUFDLEdBQUcyQyxNQUFNLEdBQUdxUCxNQUFNLEVBQUVwVSxDQUFDLENBQUM7TUFDaEQ7TUFDQSxJQUFJc2EsT0FBTyxHQUFHMWYsTUFBTSxDQUFDMmYsTUFBTSxDQUFDO1FBQ3hCamIsS0FBSyxHQUFJLHNCQUFzQixPQUFPLENBQUM7UUFDdkM7UUFDQTVQLElBQUksR0FBSSxxQkFBcUIsTUFBTSxDQUFDO1FBQ3BDO1FBQ0E4cUIsSUFBSSxHQUFJLHFCQUFxQixNQUFNLENBQUM7UUFDcEM7UUFDQTVxQixHQUFHLEdBQUksb0JBQW9CLEtBQUssQ0FBQztRQUNqQztRQUNBNnFCLEtBQUssR0FBSSxzQkFBc0IsT0FBTyxDQUFDO1FBQ3ZDO1FBQ0FDLEtBQUssR0FBSSxzQkFBc0IsT0FBTyxDQUFDO1FBQ3ZDO1FBQ0FDLEtBQUssR0FBSSxzQkFBc0IsT0FBTyxDQUFDO1FBQ3ZDO1FBQ0FDLGNBQWMsR0FBSSwrQkFBK0IsZ0JBQWdCLENBQUM7UUFDbEU7UUFDQUMsUUFBUSxHQUFJLHlCQUF5QixVQUFVLENBQUM7UUFDaEQ7UUFDQUMsT0FBTyxHQUFJLHdCQUF3QixTQUFTLENBQUM7UUFDN0M7UUFDQUMsVUFBVSxHQUFJLDJCQUEyQixZQUFZLENBQUM7UUFDdEQ7UUFDQUMsSUFBSSxHQUFJLHFCQUFxQixNQUFNLENBQUM7UUFDcEM7UUFDQXZMLEtBQUssR0FBSSxzQkFBc0IsT0FBTyxDQUFDO1FBQ3ZDO1FBQ0F3TCxNQUFNLEdBQUksdUJBQXVCLFFBQVEsQ0FBQyxDQUFDO01BQy9DLENBQUMsQ0FBQztNQUNGaEssTUFBTSxDQUFDNU8sT0FBTyxDQUFDaVksT0FBTyxHQUFHQSxPQUFPO01BQ2hDO01BQ0EsSUFBSVksVUFBVSxHQUFHLENBQUMsT0FBT3BZLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1FBQUUsT0FBT0EsQ0FBQztNQUFFLENBQUMsRUFBRSwrQkFBK0IsQ0FBQztNQUN2SCxJQUFJMlosYUFBYSxHQUFHLENBQUMsT0FBT3JZLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1FBQUUsT0FBT0EsQ0FBQztNQUFFLENBQUMsRUFBRSxzQkFBc0IsQ0FBQztNQUNqSCxJQUFJNFosd0JBQXdCLEdBQUcsQ0FBQyxPQUFPdFksTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7UUFBRSxPQUFPQSxDQUFDO01BQUUsQ0FBQyxFQUFFLGlDQUFpQyxDQUFDO01BQ3ZJLElBQUk2WixhQUFhLEdBQUcsYUFBYyxZQUFZO1FBQzFDO0FBQ2hCO0FBQ0E7QUFDQTtRQUNnQixTQUFTQSxhQUFhQSxDQUFDenJCLEdBQUcsRUFBRTByQixjQUFjLEVBQUU7VUFDeEM3QyxlQUFlLENBQUMsSUFBSSxFQUFFNEMsYUFBYSxDQUFDO1VBQ3BDLElBQUksQ0FBQ0gsVUFBVSxDQUFDLEdBQUd0ckIsR0FBRztVQUN0QixJQUFJLENBQUMwckIsY0FBYyxHQUFHQSxjQUFjO1FBQ3hDO1FBQ0E7QUFDaEI7QUFDQTtRQUNnQixPQUFPMUMsWUFBWSxDQUFDeUMsYUFBYSxFQUFFLENBQUM7VUFDNUJwTixHQUFHLEVBQUUsT0FBTztVQUNadlosS0FBSyxFQUFFLFNBQVM0SyxLQUFLQSxDQUFBLEVBQUc7WUFDcEIsS0FBSyxJQUFJdU4sSUFBSSxHQUFHL2dCLFNBQVMsQ0FBQ2tELE1BQU0sRUFBRThkLElBQUksR0FBRyxJQUFJakosS0FBSyxDQUFDZ0osSUFBSSxDQUFDLEVBQUVFLElBQUksR0FBRyxDQUFDLEVBQUVBLElBQUksR0FBR0YsSUFBSSxFQUFFRSxJQUFJLEVBQUUsRUFBRTtjQUNyRkQsSUFBSSxDQUFDQyxJQUFJLENBQUMsR0FBR2poQixTQUFTLENBQUNpaEIsSUFBSSxDQUFDO1lBQ2hDO1lBQ0EsSUFBSSxDQUFDbU8sVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ2hiLEtBQUssRUFBRXdOLElBQUksQ0FBQztVQUN6QztVQUNBO0FBQ3hCO0FBQ0E7UUFDb0IsQ0FBQyxFQUFFO1VBQ0NtQixHQUFHLEVBQUUsTUFBTTtVQUNYdlosS0FBSyxFQUFFLFNBQVNoRixJQUFJQSxDQUFBLEVBQUc7WUFDbkIsS0FBSyxJQUFJNnJCLEtBQUssR0FBR3p2QixTQUFTLENBQUNrRCxNQUFNLEVBQUU4ZCxJQUFJLEdBQUcsSUFBSWpKLEtBQUssQ0FBQzBYLEtBQUssQ0FBQyxFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQSxLQUFLLEdBQUdELEtBQUssRUFBRUMsS0FBSyxFQUFFLEVBQUU7Y0FDM0YxTyxJQUFJLENBQUMwTyxLQUFLLENBQUMsR0FBRzF2QixTQUFTLENBQUMwdkIsS0FBSyxDQUFDO1lBQ2xDO1lBQ0EsSUFBSSxDQUFDTixVQUFVLENBQUMsQ0FBQ1osT0FBTyxDQUFDNXFCLElBQUksRUFBRW9kLElBQUksQ0FBQztVQUN4QztVQUNBO0FBQ3hCO0FBQ0E7UUFDb0IsQ0FBQyxFQUFFO1VBQ0NtQixHQUFHLEVBQUUsTUFBTTtVQUNYdlosS0FBSyxFQUFFLFNBQVM4bEIsSUFBSUEsQ0FBQSxFQUFHO1lBQ25CLEtBQUssSUFBSWlCLEtBQUssR0FBRzN2QixTQUFTLENBQUNrRCxNQUFNLEVBQUU4ZCxJQUFJLEdBQUcsSUFBSWpKLEtBQUssQ0FBQzRYLEtBQUssQ0FBQyxFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQSxLQUFLLEdBQUdELEtBQUssRUFBRUMsS0FBSyxFQUFFLEVBQUU7Y0FDM0Y1TyxJQUFJLENBQUM0TyxLQUFLLENBQUMsR0FBRzV2QixTQUFTLENBQUM0dkIsS0FBSyxDQUFDO1lBQ2xDO1lBQ0EsSUFBSSxDQUFDUixVQUFVLENBQUMsQ0FBQ1osT0FBTyxDQUFDRSxJQUFJLEVBQUUxTixJQUFJLENBQUM7VUFDeEM7VUFDQTtBQUN4QjtBQUNBO1FBQ29CLENBQUMsRUFBRTtVQUNDbUIsR0FBRyxFQUFFLEtBQUs7VUFDVnZaLEtBQUssRUFBRSxTQUFTOUUsR0FBR0EsQ0FBQSxFQUFHO1lBQ2xCLEtBQUssSUFBSStyQixLQUFLLEdBQUc3dkIsU0FBUyxDQUFDa0QsTUFBTSxFQUFFOGQsSUFBSSxHQUFHLElBQUlqSixLQUFLLENBQUM4WCxLQUFLLENBQUMsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUEsS0FBSyxHQUFHRCxLQUFLLEVBQUVDLEtBQUssRUFBRSxFQUFFO2NBQzNGOU8sSUFBSSxDQUFDOE8sS0FBSyxDQUFDLEdBQUc5dkIsU0FBUyxDQUFDOHZCLEtBQUssQ0FBQztZQUNsQztZQUNBLElBQUksQ0FBQ1YsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQzFxQixHQUFHLEVBQUVrZCxJQUFJLENBQUM7VUFDdkM7VUFDQTtBQUN4QjtBQUNBO1FBQ29CLENBQUMsRUFBRTtVQUNDbUIsR0FBRyxFQUFFLE9BQU87VUFDWnZaLEtBQUssRUFBRSxTQUFTK2xCLEtBQUtBLENBQUEsRUFBRztZQUNwQixLQUFLLElBQUlvQixLQUFLLEdBQUcvdkIsU0FBUyxDQUFDa0QsTUFBTSxFQUFFOGQsSUFBSSxHQUFHLElBQUlqSixLQUFLLENBQUNnWSxLQUFLLENBQUMsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUEsS0FBSyxHQUFHRCxLQUFLLEVBQUVDLEtBQUssRUFBRSxFQUFFO2NBQzNGaFAsSUFBSSxDQUFDZ1AsS0FBSyxDQUFDLEdBQUdod0IsU0FBUyxDQUFDZ3dCLEtBQUssQ0FBQztZQUNsQztZQUNBLElBQUksQ0FBQ1osVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ0csS0FBSyxFQUFFM04sSUFBSSxDQUFDO1VBQ3pDO1VBQ0E7QUFDeEI7QUFDQTtBQUNBO1FBQ29CLENBQUMsRUFBRTtVQUNDbUIsR0FBRyxFQUFFLFFBQVE7VUFDYnZaLEtBQUssRUFBRSxTQUFTcW5CLE1BQU1BLENBQUNDLFNBQVMsRUFBRTtZQUM5QixJQUFJLENBQUNBLFNBQVMsRUFBRTtjQUNaLEtBQUssSUFBSUMsS0FBSyxHQUFHbndCLFNBQVMsQ0FBQ2tELE1BQU0sRUFBRThkLElBQUksR0FBRyxJQUFJakosS0FBSyxDQUFDb1ksS0FBSyxHQUFHLENBQUMsR0FBR0EsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUEsS0FBSyxHQUFHRCxLQUFLLEVBQUVDLEtBQUssRUFBRSxFQUFFO2dCQUMvR3BQLElBQUksQ0FBQ29QLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBR3B3QixTQUFTLENBQUNvd0IsS0FBSyxDQUFDO2NBQ3RDO2NBQ0EsSUFBSSxDQUFDaEIsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ2hiLEtBQUssRUFBRXdOLElBQUksQ0FBQztZQUN6QztVQUNKO1FBQ0osQ0FBQyxFQUFFO1VBQ0NtQixHQUFHLEVBQUUsT0FBTztVQUNadlosS0FBSyxFQUFFLFNBQVNnbUIsS0FBS0EsQ0FBQSxFQUFHO1lBQ3BCLElBQUksQ0FBQ1EsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ0ksS0FBSyxFQUFFLENBQUMsT0FBTyxDQUFDLENBQUM7VUFDOUM7UUFDSixDQUFDLEVBQUU7VUFDQ3pNLEdBQUcsRUFBRSxPQUFPO1VBQ1p2WixLQUFLLEVBQUUsU0FBUythLEtBQUtBLENBQUEsRUFBRztZQUNwQixJQUFJLENBQUN5TCxVQUFVLENBQUMsQ0FBQ1osT0FBTyxDQUFDN0ssS0FBSyxDQUFDO1VBQ25DO1VBQ0E7QUFDeEI7QUFDQTtRQUNvQixDQUFDLEVBQUU7VUFDQ3hCLEdBQUcsRUFBRSxRQUFRO1VBQ2J2WixLQUFLLEVBQUUsU0FBU3VtQixNQUFNQSxDQUFBLEVBQUc7WUFDckIsS0FBSyxJQUFJa0IsS0FBSyxHQUFHcndCLFNBQVMsQ0FBQ2tELE1BQU0sRUFBRThkLElBQUksR0FBRyxJQUFJakosS0FBSyxDQUFDc1ksS0FBSyxDQUFDLEVBQUVDLEtBQUssR0FBRyxDQUFDLEVBQUVBLEtBQUssR0FBR0QsS0FBSyxFQUFFQyxLQUFLLEVBQUUsRUFBRTtjQUMzRnRQLElBQUksQ0FBQ3NQLEtBQUssQ0FBQyxHQUFHdHdCLFNBQVMsQ0FBQ3N3QixLQUFLLENBQUM7WUFDbEM7WUFDQSxJQUFJLENBQUNsQixVQUFVLENBQUMsQ0FBQ1osT0FBTyxDQUFDVyxNQUFNLEVBQUVuTyxJQUFJLENBQUM7VUFDMUM7VUFDQTtBQUN4QjtBQUNBO1FBQ29CLENBQUMsRUFBRTtVQUNDbUIsR0FBRyxFQUFFLE9BQU87VUFDWnZaLEtBQUssRUFBRSxTQUFTaW1CLEtBQUtBLENBQUEsRUFBRztZQUNwQixLQUFLLElBQUkwQixLQUFLLEdBQUd2d0IsU0FBUyxDQUFDa0QsTUFBTSxFQUFFOGQsSUFBSSxHQUFHLElBQUlqSixLQUFLLENBQUN3WSxLQUFLLENBQUMsRUFBRUMsS0FBSyxHQUFHLENBQUMsRUFBRUEsS0FBSyxHQUFHRCxLQUFLLEVBQUVDLEtBQUssRUFBRSxFQUFFO2NBQzNGeFAsSUFBSSxDQUFDd1AsS0FBSyxDQUFDLEdBQUd4d0IsU0FBUyxDQUFDd3dCLEtBQUssQ0FBQztZQUNsQztZQUNBLElBQUksQ0FBQ3BCLFVBQVUsQ0FBQyxDQUFDWixPQUFPLENBQUNLLEtBQUssRUFBRTdOLElBQUksQ0FBQztVQUN6QztVQUNBO0FBQ3hCO0FBQ0E7UUFDb0IsQ0FBQyxFQUFFO1VBQ0NtQixHQUFHLEVBQUUsZ0JBQWdCO1VBQ3JCdlosS0FBSyxFQUFFLFNBQVNrbUIsY0FBY0EsQ0FBQSxFQUFHO1lBQzdCLEtBQUssSUFBSTJCLEtBQUssR0FBR3p3QixTQUFTLENBQUNrRCxNQUFNLEVBQUU4ZCxJQUFJLEdBQUcsSUFBSWpKLEtBQUssQ0FBQzBZLEtBQUssQ0FBQyxFQUFFQyxLQUFLLEdBQUcsQ0FBQyxFQUFFQSxLQUFLLEdBQUdELEtBQUssRUFBRUMsS0FBSyxFQUFFLEVBQUU7Y0FDM0YxUCxJQUFJLENBQUMwUCxLQUFLLENBQUMsR0FBRzF3QixTQUFTLENBQUMwd0IsS0FBSyxDQUFDO1lBQ2xDO1lBQ0EsSUFBSSxDQUFDdEIsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ00sY0FBYyxFQUFFOU4sSUFBSSxDQUFDO1VBQ2xEO1FBQ0osQ0FBQyxFQUFFO1VBQ0NtQixHQUFHLEVBQUUsVUFBVTtVQUNmdlosS0FBSyxFQUFFLFNBQVNtbUIsUUFBUUEsQ0FBQSxFQUFHO1lBQ3ZCLElBQUksQ0FBQ0ssVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ08sUUFBUSxDQUFDO1VBQ3RDO1VBQ0E7QUFDeEI7QUFDQTtRQUNvQixDQUFDLEVBQUU7VUFDQzVNLEdBQUcsRUFBRSxTQUFTO1VBQ2R2WixLQUFLLEVBQUUsU0FBU29tQixPQUFPQSxDQUFDL25CLEtBQUssRUFBRTtZQUMzQixJQUFJLENBQUNtb0IsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ1EsT0FBTyxFQUFFLENBQUMvbkIsS0FBSyxDQUFDLENBQUM7VUFDOUM7VUFDQTtBQUN4QjtBQUNBO1FBQ29CLENBQUMsRUFBRTtVQUNDa2IsR0FBRyxFQUFFLFlBQVk7VUFDakJ2WixLQUFLLEVBQUUsU0FBU3FtQixVQUFVQSxDQUFDaG9CLEtBQUssRUFBRTtZQUM5QixJQUFJLENBQUNtb0IsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ1MsVUFBVSxFQUFFLENBQUNob0IsS0FBSyxDQUFDLENBQUM7VUFDakQ7VUFDQTtBQUN4QjtBQUNBO1FBQ29CLENBQUMsRUFBRTtVQUNDa2IsR0FBRyxFQUFFLE1BQU07VUFDWHZaLEtBQUssRUFBRSxTQUFTc21CLElBQUlBLENBQUNqb0IsS0FBSyxFQUFFO1lBQ3hCO1lBQ0EsSUFBSSxDQUFDb29CLGFBQWEsQ0FBQyxHQUFHLElBQUksQ0FBQ0EsYUFBYSxDQUFDLElBQUksSUFBSXhsQixHQUFHLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUN3bEIsYUFBYSxDQUFDLENBQUNoUixHQUFHLENBQUNwWCxLQUFLLEVBQUVJLE9BQU8sQ0FBQ3NwQixNQUFNLENBQUMsQ0FBQyxDQUFDO1VBQ3BEO1VBQ0E7QUFDeEI7QUFDQTtRQUNvQixDQUFDLEVBQUU7VUFDQ3hPLEdBQUcsRUFBRSxTQUFTO1VBQ2R2WixLQUFLLEVBQUUsU0FBU2dvQixPQUFPQSxDQUFDM3BCLEtBQUssRUFBRTtZQUMzQixJQUFJNHBCLElBQUksR0FBRyxJQUFJLENBQUN4QixhQUFhLENBQUMsSUFBSSxJQUFJLENBQUNBLGFBQWEsQ0FBQyxDQUFDdmpCLEdBQUcsQ0FBQzdFLEtBQUssQ0FBQztZQUNoRSxJQUFJLENBQUM0cEIsSUFBSSxFQUFFO2NBQ1AsTUFBTSxJQUFJenhCLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQ0MsTUFBTSxDQUFDNEgsS0FBSyxFQUFFLCtCQUErQixDQUFDLENBQUM7WUFDckY7WUFDQSxJQUFJaW9CLElBQUksR0FBRzduQixPQUFPLENBQUNzcEIsTUFBTSxDQUFDRSxJQUFJLENBQUM7WUFDL0IsSUFBSSxDQUFDekIsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ1UsSUFBSSxFQUFFLENBQUNqb0IsS0FBSyxDQUFDLENBQUM1SCxNQUFNLENBQUM2dUIsa0JBQWtCLENBQUNnQixJQUFJLENBQUMsQ0FBQyxDQUFDO1VBQzVFO1VBQ0E7QUFDeEI7QUFDQTtRQUNvQixDQUFDLEVBQUU7VUFDQy9NLEdBQUcsRUFBRSxTQUFTO1VBQ2R2WixLQUFLLEVBQUUsU0FBU2tvQixPQUFPQSxDQUFDN3BCLEtBQUssRUFBRTtZQUMzQixJQUFJNHBCLElBQUksR0FBRyxJQUFJLENBQUN4QixhQUFhLENBQUMsSUFBSSxJQUFJLENBQUNBLGFBQWEsQ0FBQyxDQUFDdmpCLEdBQUcsQ0FBQzdFLEtBQUssQ0FBQztZQUNoRSxJQUFJLENBQUM0cEIsSUFBSSxFQUFFO2NBQ1AsTUFBTSxJQUFJenhCLEtBQUssQ0FBQyxpQkFBaUIsQ0FBQ0MsTUFBTSxDQUFDNEgsS0FBSyxFQUFFLCtCQUErQixDQUFDLENBQUM7WUFDckY7WUFDQSxJQUFJaW9CLElBQUksR0FBRzduQixPQUFPLENBQUNzcEIsTUFBTSxDQUFDRSxJQUFJLENBQUM7WUFDL0I7WUFDQSxJQUFJLENBQUN4QixhQUFhLENBQUMsQ0FBQy9PLE1BQU0sQ0FBQ3JaLEtBQUssQ0FBQztZQUNqQyxJQUFJLENBQUNtb0IsVUFBVSxDQUFDLENBQUNaLE9BQU8sQ0FBQ1UsSUFBSSxFQUFFLENBQUNqb0IsS0FBSyxDQUFDLENBQUM1SCxNQUFNLENBQUM2dUIsa0JBQWtCLENBQUNnQixJQUFJLENBQUMsQ0FBQyxDQUFDO1VBQzVFO1VBQ0E7QUFDeEI7QUFDQTtRQUNvQixDQUFDLEVBQUU7VUFDQy9NLEdBQUcsRUFBRSxlQUFlO1VBQ3BCdlosS0FBSyxFQUFFLFNBQVNtb0IsYUFBYUEsQ0FBQzlwQixLQUFLLEVBQUU7WUFDakMsSUFBSTRwQixJQUFJLEdBQUcsSUFBSSxDQUFDeEIsYUFBYSxDQUFDLElBQUksSUFBSSxDQUFDQSxhQUFhLENBQUMsQ0FBQ3ZqQixHQUFHLENBQUM3RSxLQUFLLENBQUM7WUFDaEUsSUFBSSxDQUFDNHBCLElBQUksRUFBRTtjQUNQLE1BQU0sSUFBSXp4QixLQUFLLENBQUMsaUJBQWlCLENBQUNDLE1BQU0sQ0FBQzRILEtBQUssRUFBRSxxQ0FBcUMsQ0FBQyxDQUFDO1lBQzNGO1lBQ0EsSUFBSWlvQixJQUFJLEdBQUc3bkIsT0FBTyxDQUFDc3BCLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDO1lBQy9CO1lBQ0EsSUFBSSxDQUFDeEIsYUFBYSxDQUFDLENBQUMvTyxNQUFNLENBQUNyWixLQUFLLENBQUM7WUFDakM7WUFDQSxJQUFJLENBQUNxb0Isd0JBQXdCLENBQUMsR0FBRyxJQUFJLENBQUNBLHdCQUF3QixDQUFDLElBQUksSUFBSXpsQixHQUFHLENBQUMsQ0FBQztZQUM1RSxJQUFJbW5CLE9BQU8sR0FBRyxJQUFJLENBQUMxQix3QkFBd0IsQ0FBQyxDQUFDeGpCLEdBQUcsQ0FBQzdFLEtBQUssQ0FBQztZQUN2RCxJQUFJK3BCLE9BQU8sS0FBS3hoQixTQUFTLEVBQUU7Y0FDdkIsSUFBSTBmLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRzhCLE9BQU8sQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLEVBQUU7Z0JBQzVCOUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJOEIsT0FBTyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7Z0JBQ3pCOUIsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHQSxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHOEIsT0FBTyxDQUFDLENBQUMsQ0FBQztjQUN4QyxDQUFDLE1BQ0k7Z0JBQ0Q5QixJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUk4QixPQUFPLENBQUMsQ0FBQyxDQUFDO2dCQUNyQjlCLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBSThCLE9BQU8sQ0FBQyxDQUFDLENBQUM7Y0FDekI7WUFDSjtZQUNBLElBQUksQ0FBQzFCLHdCQUF3QixDQUFDLENBQUNqUixHQUFHLENBQUNwWCxLQUFLLEVBQUVpb0IsSUFBSSxDQUFDO1VBQ25EO1VBQ0E7QUFDeEI7QUFDQTtRQUNvQixDQUFDLEVBQUU7VUFDQy9NLEdBQUcsRUFBRSxrQkFBa0I7VUFDdkJ2WixLQUFLLEVBQUUsU0FBU3FvQixnQkFBZ0JBLENBQUNocUIsS0FBSyxFQUFFO1lBQ3BDLElBQUksSUFBSSxDQUFDcW9CLHdCQUF3QixDQUFDLEtBQUs5ZixTQUFTLEVBQzVDO1lBQ0osSUFBSTBmLElBQUksR0FBRyxJQUFJLENBQUNJLHdCQUF3QixDQUFDLENBQUN4akIsR0FBRyxDQUFDN0UsS0FBSyxDQUFDO1lBQ3BELElBQUlpb0IsSUFBSSxLQUFLMWYsU0FBUyxFQUNsQjtZQUNKLElBQUksQ0FBQzhmLHdCQUF3QixDQUFDLENBQUNoUCxNQUFNLENBQUNyWixLQUFLLENBQUM7WUFDNUMsSUFBSSxDQUFDbW9CLFVBQVUsQ0FBQyxDQUFDWixPQUFPLENBQUNVLElBQUksRUFBRSxDQUFDam9CLEtBQUssQ0FBQyxDQUFDNUgsTUFBTSxDQUFDNnVCLGtCQUFrQixDQUFDZ0IsSUFBSSxDQUFDLENBQUMsQ0FBQztVQUM1RTtRQUNKLENBQUMsQ0FBQyxDQUFDO01BQ1gsQ0FBQyxDQUFDLENBQUM7TUFDSC9KLE1BQU0sQ0FBQzVPLE9BQU8sQ0FBQzJhLE1BQU0sR0FBRzNCLGFBQWE7TUFDckM7SUFDSixDQUFDLENBQUM7SUFDRixLQUFNLDJEQUEyRDtJQUNqRTtBQUNSO0FBQ0E7SUFDUTtJQUFPLFNBQUE0QixDQUFVaE0sTUFBTSxFQUFFaU0sd0JBQXdCLEVBQUVyRCxnQ0FBbUIsRUFBRTtNQUNwRTtBQUNaO0FBQ0E7QUFDQTtNQUNZLFNBQVNzRCxjQUFjQSxDQUFDL2EsQ0FBQyxFQUFFdEMsQ0FBQyxFQUFFO1FBQzFCLE9BQU9zZCxlQUFlLENBQUNoYixDQUFDLENBQUMsSUFBSWliLHFCQUFxQixDQUFDamIsQ0FBQyxFQUFFdEMsQ0FBQyxDQUFDLElBQUlxYSwyQkFBMkIsQ0FBQy9YLENBQUMsRUFBRXRDLENBQUMsQ0FBQyxJQUFJd2QsZ0JBQWdCLENBQUMsQ0FBQztNQUN2SDtNQUNBLFNBQVNBLGdCQUFnQkEsQ0FBQSxFQUFHO1FBQ3hCLE1BQU0sSUFBSTNZLFNBQVMsQ0FBQywySUFBMkksQ0FBQztNQUNwSztNQUNBLFNBQVMwWSxxQkFBcUJBLENBQUNqYixDQUFDLEVBQUVHLENBQUMsRUFBRTtRQUNqQyxJQUFJdkMsQ0FBQyxHQUFHLElBQUksSUFBSW9DLENBQUMsR0FBRyxJQUFJLEdBQUcsV0FBVyxJQUFJLFFBQVEsT0FBT1UsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7VUFBRSxPQUFPQSxDQUFDO1FBQUUsQ0FBQyxDQUFDLElBQUlZLENBQUMsQ0FBQyxDQUFDLE9BQU9VLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1VBQUUsT0FBT0EsQ0FBQztRQUFFLENBQUMsRUFBRWdYLFFBQVEsQ0FBQyxJQUFJcFcsQ0FBQyxDQUFDLFlBQVksQ0FBQztRQUM5TixJQUFJLElBQUksSUFBSXBDLENBQUMsRUFBRTtVQUNYLElBQUlGLENBQUM7WUFBRW9CLENBQUM7WUFBRU0sQ0FBQztZQUFFZ0QsQ0FBQztZQUFFakQsQ0FBQyxHQUFHLEVBQUU7WUFBRStDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFBRWhDLENBQUMsR0FBRyxDQUFDLENBQUM7VUFDdEMsSUFBSTtZQUNBLElBQUlkLENBQUMsR0FBRyxDQUFDeEIsQ0FBQyxHQUFHQSxDQUFDLENBQUN2UyxJQUFJLENBQUMyVSxDQUFDLENBQUMsRUFBRW1iLElBQUksRUFBRSxDQUFDLEtBQUtoYixDQUFDLEVBQUU7Y0FDbkMsSUFBSTNILE1BQU0sQ0FBQ29GLENBQUMsQ0FBQyxLQUFLQSxDQUFDLEVBQ2Y7Y0FDSnNFLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDVixDQUFDLE1BRUcsT0FBTyxFQUFFQSxDQUFDLEdBQUcsQ0FBQ3hFLENBQUMsR0FBRzBCLENBQUMsQ0FBQy9ULElBQUksQ0FBQ3VTLENBQUMsQ0FBQyxFQUFFd2QsSUFBSSxDQUFDLEtBQUtqYyxDQUFDLENBQUMvRixJQUFJLENBQUNzRSxDQUFDLENBQUNwTCxLQUFLLENBQUMsRUFBRTZNLENBQUMsQ0FBQ3ZTLE1BQU0sS0FBS3VULENBQUMsQ0FBQyxFQUFFK0IsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUMzRTtVQUNaLENBQUMsQ0FDRCxPQUFPbEMsQ0FBQyxFQUFFO1lBQ05FLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRXBCLENBQUMsR0FBR2tCLENBQUM7VUFDakIsQ0FBQyxTQUNPO1lBQ0osSUFBSTtjQUNBLElBQUksQ0FBQ2tDLENBQUMsSUFBSSxJQUFJLElBQUl0RSxDQUFDLENBQUN5ZCxNQUFNLEtBQUtqWixDQUFDLEdBQUd4RSxDQUFDLENBQUN5ZCxNQUFNLENBQUMsQ0FBQyxFQUFFN2lCLE1BQU0sQ0FBQzRKLENBQUMsQ0FBQyxLQUFLQSxDQUFDLENBQUMsRUFDM0Q7WUFDUixDQUFDLFNBQ087Y0FDSixJQUFJbEMsQ0FBQyxFQUNELE1BQU1wQixDQUFDO1lBQ2Y7VUFDSjtVQUNBLE9BQU9LLENBQUM7UUFDWjtNQUNKO01BQ0EsU0FBUzZiLGVBQWVBLENBQUNoYixDQUFDLEVBQUU7UUFDeEIsSUFBSXlCLEtBQUssQ0FBQ2lQLE9BQU8sQ0FBQzFRLENBQUMsQ0FBQyxFQUNoQixPQUFPQSxDQUFDO01BQ2hCO01BQ0EsU0FBUzRYLGtCQUFrQkEsQ0FBQzVYLENBQUMsRUFBRTtRQUMzQixPQUFPNlgsa0JBQWtCLENBQUM3WCxDQUFDLENBQUMsSUFBSThYLGdCQUFnQixDQUFDOVgsQ0FBQyxDQUFDLElBQUkrWCwyQkFBMkIsQ0FBQy9YLENBQUMsQ0FBQyxJQUFJZ1ksa0JBQWtCLENBQUMsQ0FBQztNQUNqSDtNQUNBLFNBQVNBLGtCQUFrQkEsQ0FBQSxFQUFHO1FBQzFCLE1BQU0sSUFBSXpWLFNBQVMsQ0FBQyxzSUFBc0ksQ0FBQztNQUMvSjtNQUNBLFNBQVN3ViwyQkFBMkJBLENBQUMvWCxDQUFDLEVBQUViLENBQUMsRUFBRTtRQUN2QyxJQUFJYSxDQUFDLEVBQUU7VUFDSCxJQUFJLFFBQVEsSUFBSSxPQUFPQSxDQUFDLEVBQ3BCLE9BQU9pWSxpQkFBaUIsQ0FBQ2pZLENBQUMsRUFBRWIsQ0FBQyxDQUFDO1VBQ2xDLElBQUl2QixDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM5QixRQUFRLENBQUN6USxJQUFJLENBQUMyVSxDQUFDLENBQUMsQ0FBQ1YsS0FBSyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztVQUN4QyxPQUFPLFFBQVEsS0FBSzFCLENBQUMsSUFBSW9DLENBQUMsQ0FBQzRNLFdBQVcsS0FBS2hQLENBQUMsR0FBR29DLENBQUMsQ0FBQzRNLFdBQVcsQ0FBQ3ZZLElBQUksQ0FBQyxFQUFFLEtBQUssS0FBS3VKLENBQUMsSUFBSSxLQUFLLEtBQUtBLENBQUMsR0FBRzZELEtBQUssQ0FBQ3FJLElBQUksQ0FBQzlKLENBQUMsQ0FBQyxHQUFHLFdBQVcsS0FBS3BDLENBQUMsSUFBSSwwQ0FBMEMsQ0FBQzVSLElBQUksQ0FBQzRSLENBQUMsQ0FBQyxHQUFHcWEsaUJBQWlCLENBQUNqWSxDQUFDLEVBQUViLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQztRQUMvTjtNQUNKO01BQ0EsU0FBUzJZLGdCQUFnQkEsQ0FBQzlYLENBQUMsRUFBRTtRQUN6QixJQUFJLFdBQVcsSUFBSSxRQUFRLE9BQU9VLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1VBQUUsT0FBT0EsQ0FBQztRQUFFLENBQUMsQ0FBQyxJQUFJLElBQUksSUFBSVksQ0FBQyxDQUFDLENBQUMsT0FBT1UsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7VUFBRSxPQUFPQSxDQUFDO1FBQUUsQ0FBQyxFQUFFZ1gsUUFBUSxDQUFDLElBQUksSUFBSSxJQUFJcFcsQ0FBQyxDQUFDLFlBQVksQ0FBQyxFQUNuTixPQUFPeUIsS0FBSyxDQUFDcUksSUFBSSxDQUFDOUosQ0FBQyxDQUFDO01BQzVCO01BQ0EsU0FBUzZYLGtCQUFrQkEsQ0FBQzdYLENBQUMsRUFBRTtRQUMzQixJQUFJeUIsS0FBSyxDQUFDaVAsT0FBTyxDQUFDMVEsQ0FBQyxDQUFDLEVBQ2hCLE9BQU9pWSxpQkFBaUIsQ0FBQ2pZLENBQUMsQ0FBQztNQUNuQztNQUNBLFNBQVNpWSxpQkFBaUJBLENBQUNqWSxDQUFDLEVBQUViLENBQUMsRUFBRTtRQUM3QixDQUFDLElBQUksSUFBSUEsQ0FBQyxJQUFJQSxDQUFDLEdBQUdhLENBQUMsQ0FBQ3BULE1BQU0sTUFBTXVTLENBQUMsR0FBR2EsQ0FBQyxDQUFDcFQsTUFBTSxDQUFDO1FBQzdDLEtBQUssSUFBSThRLENBQUMsR0FBRyxDQUFDLEVBQUVvQixDQUFDLEdBQUcyQyxLQUFLLENBQUN0QyxDQUFDLENBQUMsRUFBRXpCLENBQUMsR0FBR3lCLENBQUMsRUFBRXpCLENBQUMsRUFBRSxFQUNwQ29CLENBQUMsQ0FBQ3BCLENBQUMsQ0FBQyxHQUFHc0MsQ0FBQyxDQUFDdEMsQ0FBQyxDQUFDO1FBQ2YsT0FBT29CLENBQUM7TUFDWjtNQUNBLFNBQVNxWCxPQUFPQSxDQUFDalcsQ0FBQyxFQUFFO1FBQ2hCLHlCQUF5Qjs7UUFDekIsT0FBT2lXLE9BQU8sR0FBRyxVQUFVLElBQUksUUFBUSxPQUFPelYsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7VUFBRSxPQUFPQSxDQUFDO1FBQUUsQ0FBQyxDQUFDLElBQUksUUFBUSxJQUFJLE9BQU8sQ0FBQyxPQUFPc0IsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7VUFBRSxPQUFPQSxDQUFDO1FBQUUsQ0FBQyxFQUFFZ1gsUUFBUSxHQUFHLFVBQVVsVyxDQUFDLEVBQUU7VUFDNU4sT0FBTyxPQUFPQSxDQUFDO1FBQ25CLENBQUMsR0FBRyxVQUFVQSxDQUFDLEVBQUU7VUFDYixPQUFPQSxDQUFDLElBQUksVUFBVSxJQUFJLFFBQVEsT0FBT1EsTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7WUFBRSxPQUFPQSxDQUFDO1VBQUUsQ0FBQyxDQUFDLElBQUljLENBQUMsQ0FBQzBNLFdBQVcsTUFBTSxPQUFPbE0sTUFBTSxLQUFLLFdBQVcsR0FBR0EsTUFBTSxHQUFHLFVBQVV0QixDQUFDLEVBQUU7WUFBRSxPQUFPQSxDQUFDO1VBQUUsQ0FBQyxDQUFDLElBQUljLENBQUMsS0FBSyxDQUFDLE9BQU9RLE1BQU0sS0FBSyxXQUFXLEdBQUdBLE1BQU0sR0FBRyxVQUFVdEIsQ0FBQyxFQUFFO1lBQUUsT0FBT0EsQ0FBQztVQUFFLENBQUMsRUFBRTZCLFNBQVMsR0FBRyxRQUFRLEdBQUcsT0FBT2YsQ0FBQztRQUNwVCxDQUFDLEVBQUVpVyxPQUFPLENBQUNqVyxDQUFDLENBQUM7TUFDakI7TUFDQSxJQUFJb2IsUUFBUSxHQUFHN0QsZ0NBQW1CLENBQUMsZUFBZ0IsOENBQThDLENBQUM7UUFBRVMsT0FBTyxHQUFHb0QsUUFBUSxDQUFDcEQsT0FBTztNQUM5SDtNQUNBO01BQ0E7TUFDQTtNQUNBO01BQ0E7QUFDWjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNZO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtNQUNZO0FBQ1o7QUFDQTtBQUNBO01BQ1ksSUFBSXFELGdCQUFnQixHQUFHLFNBQVNBLGdCQUFnQkEsQ0FBQ0MsSUFBSSxFQUFFO1FBQ25ELElBQUksT0FBT0EsSUFBSSxLQUFLLFFBQVEsRUFBRTtVQUMxQixJQUFJQyxNQUFNLEdBQUcsSUFBSTF2QixNQUFNLENBQUMsU0FBUyxDQUFDaEQsTUFBTSxDQUFDeXlCLElBQUksQ0FBQzdTLE9BQU8sQ0FBQyxzQkFBc0IsRUFBRSxNQUFNLENBQUMsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1VBQzVHLE9BQU8sVUFBVStTLEtBQUssRUFBRTtZQUNwQixPQUFPRCxNQUFNLENBQUN6dkIsSUFBSSxDQUFDMHZCLEtBQUssQ0FBQztVQUM3QixDQUFDO1FBQ0w7UUFDQSxJQUFJRixJQUFJLElBQUlyRixPQUFPLENBQUNxRixJQUFJLENBQUMsS0FBSyxRQUFRLElBQUksT0FBT0EsSUFBSSxDQUFDeHZCLElBQUksS0FBSyxVQUFVLEVBQUU7VUFDdkUsT0FBTyxVQUFVMHZCLEtBQUssRUFBRTtZQUNwQixPQUFPRixJQUFJLENBQUN4dkIsSUFBSSxDQUFDMHZCLEtBQUssQ0FBQztVQUMzQixDQUFDO1FBQ0w7UUFDQSxJQUFJLE9BQU9GLElBQUksS0FBSyxVQUFVLEVBQUU7VUFDNUIsT0FBT0EsSUFBSTtRQUNmO1FBQ0EsSUFBSSxPQUFPQSxJQUFJLEtBQUssU0FBUyxFQUFFO1VBQzNCLE9BQU8sWUFBWTtZQUNmLE9BQU9BLElBQUk7VUFDZixDQUFDO1FBQ0w7TUFDSixDQUFDO01BQ0Q7QUFDWjtBQUNBO01BQ1ksSUFBSUcsUUFBUSxHQUFHO1FBQ1hDLElBQUksRUFBRSxDQUFDO1FBQ1BDLEtBQUssRUFBRSxDQUFDO1FBQ1IzZSxLQUFLLEVBQUUsQ0FBQztRQUNSNVAsSUFBSSxFQUFFLENBQUM7UUFDUDhxQixJQUFJLEVBQUUsQ0FBQztRQUNQNXFCLEdBQUcsRUFBRSxDQUFDO1FBQ05zdUIsSUFBSSxFQUFFLENBQUM7UUFDUEMsT0FBTyxFQUFFO01BQ2IsQ0FBQztNQUNEO0FBQ1o7QUFDQTtBQUNBO01BQ1lsTixNQUFNLENBQUM1TyxPQUFPLEdBQUcsVUFBVS9XLElBQUksRUFBRTtRQUM3QixJQUFJOHlCLFVBQVUsR0FBRzl5QixJQUFJLENBQUMreUIsS0FBSztVQUFFQSxLQUFLLEdBQUdELFVBQVUsS0FBSyxLQUFLLENBQUMsR0FBRyxNQUFNLEdBQUdBLFVBQVU7VUFBRUUsVUFBVSxHQUFHaHpCLElBQUksQ0FBQ212QixLQUFLO1VBQUVBLEtBQUssR0FBRzZELFVBQVUsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLEdBQUdBLFVBQVU7VUFBRTd1QixPQUFPLEdBQUduRSxJQUFJLENBQUNtRSxPQUFPO1FBQ3JMLElBQUk4dUIsWUFBWSxHQUFHLCtCQUFnQyxPQUFPOUQsS0FBSyxLQUFLLFNBQVMsR0FBRyxDQUFDLFlBQVk7VUFDckYsT0FBT0EsS0FBSztRQUNoQixDQUFDLENBQUMsR0FBRyxnQ0FBaUMsRUFBRSxDQUFDdHZCLE1BQU0sQ0FBQ3N2QixLQUFLLENBQUMsQ0FBQ25qQixHQUFHLENBQUNxbUIsZ0JBQWdCLENBQUM7UUFDaEYsSUFBSWEsUUFBUSxHQUFHVCxRQUFRLENBQUMsRUFBRSxDQUFDNXlCLE1BQU0sQ0FBQ2t6QixLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDOUM7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtRQUNnQixJQUFJcFIsTUFBTSxHQUFHLFNBQVNBLE1BQU1BLENBQUN4VyxJQUFJLEVBQUUyZSxJQUFJLEVBQUV0SSxJQUFJLEVBQUU7VUFDM0MsSUFBSTJSLFdBQVcsR0FBRyxTQUFTQSxXQUFXQSxDQUFBLEVBQUc7WUFDckMsSUFBSTVhLEtBQUssQ0FBQ2lQLE9BQU8sQ0FBQ2hHLElBQUksQ0FBQyxFQUFFO2NBQ3JCLElBQUlBLElBQUksQ0FBQzlkLE1BQU0sR0FBRyxDQUFDLElBQUksT0FBTzhkLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxRQUFRLEVBQUU7Z0JBQ2hELE9BQU8sQ0FBQyxHQUFHLENBQUMzaEIsTUFBTSxDQUFDc0wsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFDdEwsTUFBTSxDQUFDMmhCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMzaEIsTUFBTSxDQUFDNnVCLGtCQUFrQixDQUFDbE4sSUFBSSxDQUFDcEwsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FDN0Y7Y0FDQSxPQUFPLENBQUMsR0FBRyxDQUFDdlcsTUFBTSxDQUFDc0wsSUFBSSxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUN0TCxNQUFNLENBQUM2dUIsa0JBQWtCLENBQUNsTixJQUFJLENBQUMsQ0FBQztZQUNuRTtZQUNBLE9BQU8sRUFBRTtVQUNiLENBQUM7VUFDRCxJQUFJMk4sS0FBSyxHQUFHOEQsWUFBWSxDQUFDL3ZCLElBQUksQ0FBQyxVQUFVOFYsQ0FBQyxFQUFFO1lBQ3ZDLE9BQU9BLENBQUMsQ0FBQzdOLElBQUksQ0FBQztVQUNsQixDQUFDLENBQUM7VUFDRixRQUFRMmUsSUFBSTtZQUNSLEtBQUtrRixPQUFPLENBQUNHLEtBQUs7Y0FDZCxJQUFJLENBQUNBLEtBQUssRUFDTjtjQUNKLElBQUksT0FBT2hyQixPQUFPLENBQUNnckIsS0FBSyxLQUFLLFVBQVUsRUFBRTtnQkFDckNockIsT0FBTyxDQUFDZ3JCLEtBQUssQ0FBQzV1QixLQUFLLENBQUM0RCxPQUFPLEVBQUV1cUIsa0JBQWtCLENBQUN5RSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FDbkUsQ0FBQyxNQUNJO2dCQUNEaHZCLE9BQU8sQ0FBQ0csR0FBRyxDQUFDL0QsS0FBSyxDQUFDNEQsT0FBTyxFQUFFdXFCLGtCQUFrQixDQUFDeUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQ2pFO2NBQ0E7WUFDSixLQUFLbkUsT0FBTyxDQUFDMXFCLEdBQUc7Y0FDWixJQUFJLENBQUM2cUIsS0FBSyxJQUFJK0QsUUFBUSxHQUFHVCxRQUFRLENBQUNudUIsR0FBRyxFQUNqQztjQUNKSCxPQUFPLENBQUNHLEdBQUcsQ0FBQy9ELEtBQUssQ0FBQzRELE9BQU8sRUFBRXVxQixrQkFBa0IsQ0FBQ3lFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUM3RDtZQUNKLEtBQUtuRSxPQUFPLENBQUNFLElBQUk7Y0FDYixJQUFJLENBQUNDLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDdkQsSUFBSSxFQUNsQztjQUNKL3FCLE9BQU8sQ0FBQytxQixJQUFJLENBQUMzdUIsS0FBSyxDQUFDNEQsT0FBTyxFQUFFdXFCLGtCQUFrQixDQUFDeUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQzlEO1lBQ0osS0FBS25FLE9BQU8sQ0FBQzVxQixJQUFJO2NBQ2IsSUFBSSxDQUFDK3FCLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDcnVCLElBQUksRUFDbEM7Y0FDSkQsT0FBTyxDQUFDQyxJQUFJLENBQUM3RCxLQUFLLENBQUM0RCxPQUFPLEVBQUV1cUIsa0JBQWtCLENBQUN5RSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Y0FDOUQ7WUFDSixLQUFLbkUsT0FBTyxDQUFDaGIsS0FBSztjQUNkLElBQUksQ0FBQ21iLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDemUsS0FBSyxFQUNuQztjQUNKN1AsT0FBTyxDQUFDNlAsS0FBSyxDQUFDelQsS0FBSyxDQUFDNEQsT0FBTyxFQUFFdXFCLGtCQUFrQixDQUFDeUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQy9EO1lBQ0osS0FBS25FLE9BQU8sQ0FBQ0ksS0FBSztjQUNkLElBQUksQ0FBQ0QsS0FBSyxFQUNOO2NBQ0pockIsT0FBTyxDQUFDaXJCLEtBQUssQ0FBQyxDQUFDO2NBQ2Y7WUFDSixLQUFLSixPQUFPLENBQUNNLGNBQWM7Y0FDdkIsSUFBSSxDQUFDSCxLQUFLLElBQUkrRCxRQUFRLEdBQUdULFFBQVEsQ0FBQ251QixHQUFHLEVBQ2pDO2NBQ0osSUFBSSxDQUFDNnFCLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDSSxPQUFPLEVBQUU7Z0JBQ3ZDLElBQUksT0FBTzF1QixPQUFPLENBQUNtckIsY0FBYyxLQUFLLFVBQVUsRUFBRTtrQkFDOUNuckIsT0FBTyxDQUFDbXJCLGNBQWMsQ0FBQy91QixLQUFLLENBQUM0RCxPQUFPLEVBQUV1cUIsa0JBQWtCLENBQUN5RSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQzVFLENBQUMsTUFDSTtrQkFDRGh2QixPQUFPLENBQUNHLEdBQUcsQ0FBQy9ELEtBQUssQ0FBQzRELE9BQU8sRUFBRXVxQixrQkFBa0IsQ0FBQ3lFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztnQkFDakU7Z0JBQ0E7Y0FDSjtZQUNKO1lBQ0EsS0FBS25FLE9BQU8sQ0FBQ0ssS0FBSztjQUNkLElBQUksQ0FBQ0YsS0FBSyxJQUFJK0QsUUFBUSxHQUFHVCxRQUFRLENBQUNudUIsR0FBRyxFQUNqQztjQUNKLElBQUksT0FBT0gsT0FBTyxDQUFDa3JCLEtBQUssS0FBSyxVQUFVLEVBQUU7Z0JBQ3JDbHJCLE9BQU8sQ0FBQ2tyQixLQUFLLENBQUM5dUIsS0FBSyxDQUFDNEQsT0FBTyxFQUFFdXFCLGtCQUFrQixDQUFDeUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQ25FLENBQUMsTUFDSTtnQkFDRGh2QixPQUFPLENBQUNHLEdBQUcsQ0FBQy9ELEtBQUssQ0FBQzRELE9BQU8sRUFBRXVxQixrQkFBa0IsQ0FBQ3lFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUNqRTtjQUNBO1lBQ0osS0FBS25FLE9BQU8sQ0FBQ08sUUFBUTtjQUNqQixJQUFJLENBQUNKLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDbnVCLEdBQUcsRUFDakM7Y0FDSixJQUFJLE9BQU9ILE9BQU8sQ0FBQ29yQixRQUFRLEtBQUssVUFBVSxFQUFFO2dCQUN4Q3ByQixPQUFPLENBQUNvckIsUUFBUSxDQUFDLENBQUM7Y0FDdEI7Y0FDQTtZQUNKLEtBQUtQLE9BQU8sQ0FBQ1UsSUFBSTtjQUNiO2dCQUNJLElBQUksQ0FBQ1AsS0FBSyxJQUFJK0QsUUFBUSxHQUFHVCxRQUFRLENBQUNudUIsR0FBRyxFQUNqQztnQkFDSixJQUFJOHVCLEtBQUssR0FBR3ZCLGNBQWMsQ0FBQyx1Q0FBd0NyUSxJQUFJLEVBQUUsQ0FBQyxDQUFDO2tCQUFFL1osS0FBSyxHQUFHMnJCLEtBQUssQ0FBQyxDQUFDLENBQUM7a0JBQUVDLEtBQUssR0FBR0QsS0FBSyxDQUFDLENBQUMsQ0FBQztrQkFBRUUsR0FBRyxHQUFHRixLQUFLLENBQUMsQ0FBQyxDQUFDO2dCQUMvSCxJQUFJRyxFQUFFLEdBQUdGLEtBQUssR0FBRyxJQUFJLEdBQUdDLEdBQUcsR0FBRyxPQUFPO2dCQUNyQyxJQUFJOVEsR0FBRyxHQUFHLEdBQUcsQ0FBQzNpQixNQUFNLENBQUNzTCxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUN0TCxNQUFNLENBQUM0SCxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM1SCxNQUFNLENBQUMwekIsRUFBRSxFQUFFLEtBQUssQ0FBQztnQkFDdEUsSUFBSSxPQUFPcHZCLE9BQU8sQ0FBQ3F2QixPQUFPLEtBQUssVUFBVSxFQUFFO2tCQUN2Q3J2QixPQUFPLENBQUNxdkIsT0FBTyxDQUFDaFIsR0FBRyxDQUFDO2dCQUN4QixDQUFDLE1BQ0k7a0JBQ0RyZSxPQUFPLENBQUNHLEdBQUcsQ0FBQ2tlLEdBQUcsQ0FBQztnQkFDcEI7Z0JBQ0E7Y0FDSjtZQUNKLEtBQUt3TSxPQUFPLENBQUNRLE9BQU87Y0FDaEIsSUFBSSxPQUFPcnJCLE9BQU8sQ0FBQ3FyQixPQUFPLEtBQUssVUFBVSxFQUFFO2dCQUN2Q3JyQixPQUFPLENBQUNxckIsT0FBTyxDQUFDanZCLEtBQUssQ0FBQzRELE9BQU8sRUFBRXVxQixrQkFBa0IsQ0FBQ3lFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUNyRTtjQUNBO1lBQ0osS0FBS25FLE9BQU8sQ0FBQ1MsVUFBVTtjQUNuQixJQUFJLE9BQU90ckIsT0FBTyxDQUFDc3JCLFVBQVUsS0FBSyxVQUFVLEVBQUU7Z0JBQzFDdHJCLE9BQU8sQ0FBQ3NyQixVQUFVLENBQUNsdkIsS0FBSyxDQUFDNEQsT0FBTyxFQUFFdXFCLGtCQUFrQixDQUFDeUUsV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDO2NBQ3hFO2NBQ0E7WUFDSixLQUFLbkUsT0FBTyxDQUFDN0ssS0FBSztjQUNkLElBQUksQ0FBQ2dMLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDbnVCLEdBQUcsRUFDakM7Y0FDSixJQUFJLE9BQU9ILE9BQU8sQ0FBQ2dnQixLQUFLLEtBQUssVUFBVSxFQUFFO2dCQUNyQ2hnQixPQUFPLENBQUNnZ0IsS0FBSyxDQUFDLENBQUM7Y0FDbkI7Y0FDQTtZQUNKLEtBQUs2SyxPQUFPLENBQUNXLE1BQU07Y0FDZixJQUFJLENBQUNSLEtBQUssSUFBSStELFFBQVEsR0FBR1QsUUFBUSxDQUFDdkQsSUFBSSxFQUNsQztjQUNKLElBQUksT0FBTy9xQixPQUFPLENBQUN3ckIsTUFBTSxLQUFLLFVBQVUsRUFBRTtnQkFDdEMsSUFBSSxDQUFDbk8sSUFBSSxJQUFJQSxJQUFJLENBQUM5ZCxNQUFNLEtBQUssQ0FBQyxFQUFFO2tCQUM1QlMsT0FBTyxDQUFDd3JCLE1BQU0sQ0FBQyxDQUFDO2dCQUNwQixDQUFDLE1BQ0k7a0JBQ0R4ckIsT0FBTyxDQUFDd3JCLE1BQU0sQ0FBQ3B2QixLQUFLLENBQUM0RCxPQUFPLEVBQUV1cUIsa0JBQWtCLENBQUN5RSxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0JBQ3BFO2NBQ0osQ0FBQyxNQUNJLElBQUkzUixJQUFJLElBQUlBLElBQUksQ0FBQzlkLE1BQU0sS0FBSyxDQUFDLEVBQUU7Z0JBQ2hDUyxPQUFPLENBQUMrcUIsSUFBSSxDQUFDM3VCLEtBQUssQ0FBQzRELE9BQU8sRUFBRXVxQixrQkFBa0IsQ0FBQ3lFLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQztjQUNsRTtjQUNBO1lBQ0o7Y0FDSSxNQUFNLElBQUl2ekIsS0FBSyxDQUFDLHFCQUFxQixDQUFDQyxNQUFNLENBQUNpcUIsSUFBSSxDQUFDLENBQUM7VUFDM0Q7UUFDSixDQUFDO1FBQ0QsT0FBT25JLE1BQU07TUFDakIsQ0FBQztNQUNEO0lBQ0osQ0FBQyxDQUFDO0lBQ0YsS0FBTSwrQ0FBK0M7SUFDckQ7QUFDUjtBQUNBO0lBQ1E7SUFBTyxTQUFBOFIsQ0FBVTlOLE1BQU0sRUFBRWlNLHdCQUF3QixFQUFFckQsZ0NBQW1CLEVBQUU7TUFDcEU7QUFDWjtBQUNBO0FBQ0E7TUFDWSxTQUFTbUYsUUFBUUEsQ0FBQSxFQUFHO1FBQ2hCLE9BQU9BLFFBQVEsR0FBR3BrQixNQUFNLENBQUNxa0IsTUFBTSxHQUFHcmtCLE1BQU0sQ0FBQ3FrQixNQUFNLENBQUM5YixJQUFJLENBQUMsQ0FBQyxHQUFHLFVBQVVqQyxDQUFDLEVBQUU7VUFDbEUsS0FBSyxJQUFJcEIsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHaFUsU0FBUyxDQUFDa0QsTUFBTSxFQUFFOFEsQ0FBQyxFQUFFLEVBQUU7WUFDdkMsSUFBSUUsQ0FBQyxHQUFHbFUsU0FBUyxDQUFDZ1UsQ0FBQyxDQUFDO1lBQ3BCLEtBQUssSUFBSXNDLENBQUMsSUFBSXBDLENBQUMsRUFDWCxDQUFDLENBQUMsQ0FBQyxFQUFFc0QsY0FBYyxDQUFDN1YsSUFBSSxDQUFDdVMsQ0FBQyxFQUFFb0MsQ0FBQyxDQUFDLEtBQUtsQixDQUFDLENBQUNrQixDQUFDLENBQUMsR0FBR3BDLENBQUMsQ0FBQ29DLENBQUMsQ0FBQyxDQUFDO1VBQ3ZEO1VBQ0EsT0FBT2xCLENBQUM7UUFDWixDQUFDLEVBQUU4ZCxRQUFRLENBQUNuekIsS0FBSyxDQUFDLElBQUksRUFBRUMsU0FBUyxDQUFDO01BQ3RDO01BQ0EsSUFBSTR4QixRQUFRLEdBQUc3RCxnQ0FBbUIsQ0FBQyxjQUFlLHdDQUF3QyxDQUFDO1FBQUVDLFlBQVksR0FBRzRELFFBQVEsQ0FBQzVELFlBQVk7TUFDakksSUFBSW9GLFNBQVMsR0FBR3JGLGdDQUFtQixDQUFDLGVBQWdCLDhDQUE4QyxDQUFDO1FBQUVtRCxNQUFNLEdBQUdrQyxTQUFTLENBQUNsQyxNQUFNO01BQzlILElBQUltQyxtQkFBbUIsR0FBR3RGLGdDQUFtQixDQUFDLDRCQUE2QiwyREFBMkQsQ0FBQztNQUN2STtNQUNBLElBQUl1RiwyQkFBMkIsR0FBRztRQUM5QmYsS0FBSyxFQUFFLE1BQU07UUFDYjVELEtBQUssRUFBRSxLQUFLO1FBQ1pockIsT0FBTyxFQUFFQTtNQUNiLENBQUM7TUFDRCxJQUFJNHZCLG9CQUFvQixHQUFHRixtQkFBbUIsQ0FBQ0MsMkJBQTJCLENBQUM7TUFDM0U7QUFDWjtBQUNBO0FBQ0E7TUFDWW5PLE1BQU0sQ0FBQzVPLE9BQU8sQ0FBQ2lkLFNBQVMsR0FBRyxVQUFVN29CLElBQUksRUFBRTtRQUN2QyxPQUFPLElBQUl1bUIsTUFBTSxDQUFDLFVBQVU1SCxJQUFJLEVBQUV0SSxJQUFJLEVBQUU7VUFDcEMsSUFBSW1FLE1BQU0sQ0FBQzVPLE9BQU8sQ0FBQ2tkLEtBQUssQ0FBQzN2QixHQUFHLENBQUNuQyxJQUFJLENBQUNnSixJQUFJLEVBQUUyZSxJQUFJLEVBQUV0SSxJQUFJLENBQUMsS0FBS3hSLFNBQVMsRUFBRTtZQUMvRCtqQixvQkFBb0IsQ0FBQzVvQixJQUFJLEVBQUUyZSxJQUFJLEVBQUV0SSxJQUFJLENBQUM7VUFDMUM7UUFDSixDQUFDLEVBQUUsVUFBVTBTLFNBQVMsRUFBRTtVQUNwQixPQUFPdk8sTUFBTSxDQUFDNU8sT0FBTyxDQUFDaWQsU0FBUyxDQUFDLEVBQUUsQ0FBQ24wQixNQUFNLENBQUNzTCxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUN0TCxNQUFNLENBQUNxMEIsU0FBUyxDQUFDLENBQUM7UUFDM0UsQ0FBQyxDQUFDO01BQ04sQ0FBQztNQUNEO0FBQ1o7QUFDQTtBQUNBO01BQ1l2TyxNQUFNLENBQUM1TyxPQUFPLENBQUNvZCxzQkFBc0IsR0FBRyxVQUFVQyxPQUFPLEVBQUU7UUFDdkRWLFFBQVEsQ0FBQ0ksMkJBQTJCLEVBQUVNLE9BQU8sQ0FBQztRQUM5Q0wsb0JBQW9CLEdBQUdGLG1CQUFtQixDQUFDQywyQkFBMkIsQ0FBQztNQUMzRSxDQUFDO01BQ0RuTyxNQUFNLENBQUM1TyxPQUFPLENBQUNrZCxLQUFLLEdBQUc7UUFDbkIzdkIsR0FBRyxFQUFFLElBQUlrcUIsWUFBWSxDQUFDLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7TUFDcEQsQ0FBQztNQUNEO0lBQ0osQ0FBQztJQUNEO0VBQ0osQ0FBRTtFQUNGO0VBQ0EsU0FBUztFQUNUO0VBQVMsSUFBSTZGLHdCQUF3QixHQUFHLENBQUMsQ0FBQztFQUMxQztFQUNBLFNBQVM7RUFDVDtFQUFTLFNBQVM5RixnQ0FBbUJBLENBQUMrRixRQUFRLEVBQUU7SUFDNUMsU0FBUztJQUNULFFBQVMsSUFBSUMsWUFBWSxHQUFHRix3QkFBd0IsQ0FBQ0MsUUFBUSxDQUFDO0lBQzlEO0lBQVMsSUFBSUMsWUFBWSxLQUFLdmtCLFNBQVMsRUFBRTtNQUNyQyxRQUFTLE9BQU91a0IsWUFBWSxDQUFDeGQsT0FBTztNQUNwQztJQUFTO0lBQ2IsU0FBUztJQUNUO0lBQVMsSUFBSTRPLE1BQU0sR0FBRzBPLHdCQUF3QixDQUFDQyxRQUFRLENBQUMsR0FBRztNQUN2RCxTQUFTO01BQ1QsU0FBUztNQUNULFFBQVN2ZCxPQUFPLEVBQUUsQ0FBQztNQUNuQjtJQUNKLENBQUM7SUFDRDtJQUNBLFNBQVM7SUFDVDtJQUFTb1gsbUJBQW1CLENBQUNtRyxRQUFRLENBQUMsQ0FBQzNPLE1BQU0sRUFBRUEsTUFBTSxDQUFDNU8sT0FBTyxFQUFFd1gsZ0NBQW1CLENBQUM7SUFDbkY7SUFDQSxTQUFTO0lBQ1Q7SUFBUyxPQUFPNUksTUFBTSxDQUFDNU8sT0FBTztJQUM5QjtFQUNKO0VBQ0E7RUFDQTtFQUNBLFNBQVM7RUFDVDtFQUFTLENBQUMsWUFBWTtJQUNsQixTQUFTO0lBQ1QsUUFBU3dYLGdDQUFtQixDQUFDblgsQ0FBQyxHQUFHLFVBQVVMLE9BQU8sRUFBRXlkLFVBQVUsRUFBRTtNQUM1RCxRQUFTLEtBQUssSUFBSTdSLEdBQUcsSUFBSTZSLFVBQVUsRUFBRTtRQUNqQyxRQUFTLElBQUlqRyxnQ0FBbUIsQ0FBQ3ZYLENBQUMsQ0FBQ3dkLFVBQVUsRUFBRTdSLEdBQUcsQ0FBQyxJQUFJLENBQUM0TCxnQ0FBbUIsQ0FBQ3ZYLENBQUMsQ0FBQ0QsT0FBTyxFQUFFNEwsR0FBRyxDQUFDLEVBQUU7VUFDekYsUUFBU3JULE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQ1AsT0FBTyxFQUFFNEwsR0FBRyxFQUFFO1lBQUVwTCxVQUFVLEVBQUUsSUFBSTtZQUFFakwsR0FBRyxFQUFFa29CLFVBQVUsQ0FBQzdSLEdBQUc7VUFBRSxDQUFDLENBQUM7VUFDeEY7UUFBUztRQUNiO01BQVM7TUFDYjtJQUNKLENBQUM7SUFDRDtFQUNKLENBQUMsQ0FBQyxDQUFDO0VBQ0g7RUFDQSxTQUFTO0VBQ1Q7RUFBUyxDQUFDLFlBQVk7SUFDbEIsUUFBUzRMLGdDQUFtQixDQUFDdlgsQ0FBQyxHQUFHLFVBQVUwTCxHQUFHLEVBQUUrUixJQUFJLEVBQUU7TUFBRSxPQUFPbmxCLE1BQU0sQ0FBQ3lJLFNBQVMsQ0FBQ0MsY0FBYyxDQUFDN1YsSUFBSSxDQUFDdWdCLEdBQUcsRUFBRStSLElBQUksQ0FBQztJQUFFLENBQUM7SUFDakg7RUFDSixDQUFDLENBQUMsQ0FBQztFQUNIO0VBQ0EsU0FBUztFQUNUO0VBQVMsQ0FBQyxZQUFZO0lBQ2xCLFNBQVM7SUFDVCxRQUFTbEcsZ0NBQW1CLENBQUN6WCxDQUFDLEdBQUcsVUFBVUMsT0FBTyxFQUFFO01BQ2hELFFBQVMsSUFBSSxPQUFPUyxNQUFNLEtBQUssV0FBVyxJQUFJQSxNQUFNLENBQUNDLFdBQVcsRUFBRTtRQUM5RCxRQUFTbkksTUFBTSxDQUFDZ0ksY0FBYyxDQUFDUCxPQUFPLEVBQUVTLE1BQU0sQ0FBQ0MsV0FBVyxFQUFFO1VBQUVyTyxLQUFLLEVBQUU7UUFBUyxDQUFDLENBQUM7UUFDaEY7TUFBUztNQUNiO01BQVNrRyxNQUFNLENBQUNnSSxjQUFjLENBQUNQLE9BQU8sRUFBRSxZQUFZLEVBQUU7UUFBRTNOLEtBQUssRUFBRTtNQUFLLENBQUMsQ0FBQztNQUN0RTtJQUNKLENBQUM7SUFDRDtFQUNKLENBQUMsQ0FBQyxDQUFDO0VBQ0g7RUFDQTtFQUNBLElBQUlrbEIsMEJBQW1CLEdBQUcsQ0FBQyxDQUFDO0VBQzVCO0VBQ0EsQ0FBQyxZQUFZO0lBQ1Q7QUFDUjtBQUNBO0lBQ1FDLGdDQUFtQixDQUFDelgsQ0FBQyxDQUFDd1gsMEJBQW1CLENBQUM7SUFDMUM7SUFBcUJDLGdDQUFtQixDQUFDblgsQ0FBQyxDQUFDa1gsMEJBQW1CLEVBQUU7TUFDNUQsb0JBQXFCLFNBQVMsRUFBRSxTQUFBeFcsQ0FBQSxFQUFZO1FBQUUsT0FBTywrQ0FBZ0Q0YywyREFBMkQ7TUFBRTtNQUNsSztJQUNKLENBQUMsQ0FBQztJQUNGO0lBQXFCLElBQUlBLDJEQUEyRCxHQUFHbkcsZ0NBQW1CLENBQUMscUNBQXNDLCtDQUErQyxDQUFDO0VBQ3JNLENBQUMsQ0FBQyxDQUFDO0VBQ0gsSUFBSW9HLHlCQUF5QixHQUFHNWQsT0FBTztFQUN2QyxLQUFLLElBQUk2ZCxhQUFhLElBQUl0RywwQkFBbUIsRUFDekNxRyx5QkFBeUIsQ0FBQ0MsYUFBYSxDQUFDLEdBQUd0RywwQkFBbUIsQ0FBQ3NHLGFBQWEsQ0FBQztFQUNqRixJQUFJdEcsMEJBQW1CLENBQUM1VyxVQUFVLEVBQzlCcEksTUFBTSxDQUFDZ0ksY0FBYyxDQUFDcWQseUJBQXlCLEVBQUUsWUFBWSxFQUFFO0lBQUV2ckIsS0FBSyxFQUFFO0VBQUssQ0FBQyxDQUFDO0VBQ25GO0FBQ0osQ0FBQyxFQUFFLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNueUJKLFNBQVM2akIsT0FBT0EsQ0FBQ2pXLENBQUMsRUFBRTtFQUNoQix5QkFBeUI7O0VBQ3pCLE9BQU9pVyxPQUFPLEdBQUcsVUFBVSxJQUFJLE9BQU96VixNQUFNLElBQUksUUFBUSxJQUFJLE9BQU9BLE1BQU0sQ0FBQzBWLFFBQVEsR0FBRyxVQUFVbFcsQ0FBQyxFQUFFO0lBQUUsT0FBTyxPQUFPQSxDQUFDO0VBQUUsQ0FBQyxHQUFHLFVBQVVBLENBQUMsRUFBRTtJQUFFLE9BQU9BLENBQUMsSUFBSSxVQUFVLElBQUksT0FBT1EsTUFBTSxJQUFJUixDQUFDLENBQUMwTSxXQUFXLEtBQUtsTSxNQUFNLElBQUlSLENBQUMsS0FBS1EsTUFBTSxDQUFDTyxTQUFTLEdBQUcsUUFBUSxHQUFHLE9BQU9mLENBQUM7RUFBRSxDQUFDLEVBQUVpVyxPQUFPLENBQUNqVyxDQUFDLENBQUM7QUFDOVE7QUFDQSxTQUFTd1IsT0FBT0EsQ0FBQ2hVLENBQUMsRUFBRXNDLENBQUMsRUFBRTtFQUFFLElBQUlwQyxDQUFDLEdBQUdwRixNQUFNLENBQUNDLElBQUksQ0FBQ2lGLENBQUMsQ0FBQztFQUFFLElBQUlsRixNQUFNLENBQUNtWixxQkFBcUIsRUFBRTtJQUMvRSxJQUFJelIsQ0FBQyxHQUFHMUgsTUFBTSxDQUFDbVoscUJBQXFCLENBQUNqVSxDQUFDLENBQUM7SUFDdkNzQyxDQUFDLEtBQUtFLENBQUMsR0FBR0EsQ0FBQyxDQUFDdkssTUFBTSxDQUFDLFVBQVVxSyxDQUFDLEVBQUU7TUFBRSxPQUFPeEgsTUFBTSxDQUFDdWxCLHdCQUF3QixDQUFDcmdCLENBQUMsRUFBRXNDLENBQUMsQ0FBQyxDQUFDUyxVQUFVO0lBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRTdDLENBQUMsQ0FBQ3hFLElBQUksQ0FBQzNQLEtBQUssQ0FBQ21VLENBQUMsRUFBRXNDLENBQUMsQ0FBQztFQUN0SDtFQUFFLE9BQU90QyxDQUFDO0FBQUU7QUFDWixTQUFTdEYsYUFBYUEsQ0FBQ29GLENBQUMsRUFBRTtFQUFFLEtBQUssSUFBSXNDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR3RXLFNBQVMsQ0FBQ2tELE1BQU0sRUFBRW9ULENBQUMsRUFBRSxFQUFFO0lBQ25FLElBQUlwQyxDQUFDLEdBQUcsSUFBSSxJQUFJbFUsU0FBUyxDQUFDc1csQ0FBQyxDQUFDLEdBQUd0VyxTQUFTLENBQUNzVyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDaERBLENBQUMsR0FBRyxDQUFDLEdBQUcwUixPQUFPLENBQUNsWixNQUFNLENBQUNvRixDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDN0UsT0FBTyxDQUFDLFVBQVVpSCxDQUFDLEVBQUU7TUFBRWdlLGVBQWUsQ0FBQ3RnQixDQUFDLEVBQUVzQyxDQUFDLEVBQUVwQyxDQUFDLENBQUNvQyxDQUFDLENBQUMsQ0FBQztJQUFFLENBQUMsQ0FBQyxHQUFHeEgsTUFBTSxDQUFDeWxCLHlCQUF5QixHQUFHemxCLE1BQU0sQ0FBQzBsQixnQkFBZ0IsQ0FBQ3hnQixDQUFDLEVBQUVsRixNQUFNLENBQUN5bEIseUJBQXlCLENBQUNyZ0IsQ0FBQyxDQUFDLENBQUMsR0FBRzhULE9BQU8sQ0FBQ2xaLE1BQU0sQ0FBQ29GLENBQUMsQ0FBQyxDQUFDLENBQUM3RSxPQUFPLENBQUMsVUFBVWlILENBQUMsRUFBRTtNQUFFeEgsTUFBTSxDQUFDZ0ksY0FBYyxDQUFDOUMsQ0FBQyxFQUFFc0MsQ0FBQyxFQUFFeEgsTUFBTSxDQUFDdWxCLHdCQUF3QixDQUFDbmdCLENBQUMsRUFBRW9DLENBQUMsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0VBQ2pUO0VBQUUsT0FBT3RDLENBQUM7QUFBRTtBQUNaLFNBQVNzZ0IsZUFBZUEsQ0FBQ3RnQixDQUFDLEVBQUVzQyxDQUFDLEVBQUVwQyxDQUFDLEVBQUU7RUFBRSxPQUFPLENBQUNvQyxDQUFDLEdBQUd1VyxjQUFjLENBQUN2VyxDQUFDLENBQUMsS0FBS3RDLENBQUMsR0FBR2xGLE1BQU0sQ0FBQ2dJLGNBQWMsQ0FBQzlDLENBQUMsRUFBRXNDLENBQUMsRUFBRTtJQUFFMU4sS0FBSyxFQUFFc0wsQ0FBQztJQUFFNkMsVUFBVSxFQUFFLENBQUMsQ0FBQztJQUFFNEIsWUFBWSxFQUFFLENBQUMsQ0FBQztJQUFFeUosUUFBUSxFQUFFLENBQUM7RUFBRSxDQUFDLENBQUMsR0FBR3BPLENBQUMsQ0FBQ3NDLENBQUMsQ0FBQyxHQUFHcEMsQ0FBQyxFQUFFRixDQUFDO0FBQUU7QUFDbkwsU0FBUzZZLGNBQWNBLENBQUMzWSxDQUFDLEVBQUU7RUFBRSxJQUFJd0IsQ0FBQyxHQUFHcVgsWUFBWSxDQUFDN1ksQ0FBQyxFQUFFLFFBQVEsQ0FBQztFQUFFLE9BQU8sUUFBUSxJQUFJdVksT0FBTyxDQUFDL1csQ0FBQyxDQUFDLEdBQUdBLENBQUMsR0FBR0EsQ0FBQyxHQUFHLEVBQUU7QUFBRTtBQUM1RyxTQUFTcVgsWUFBWUEsQ0FBQzdZLENBQUMsRUFBRW9DLENBQUMsRUFBRTtFQUFFLElBQUksUUFBUSxJQUFJbVcsT0FBTyxDQUFDdlksQ0FBQyxDQUFDLElBQUksQ0FBQ0EsQ0FBQyxFQUMxRCxPQUFPQSxDQUFDO0VBQUUsSUFBSUYsQ0FBQyxHQUFHRSxDQUFDLENBQUM4QyxNQUFNLENBQUNnVyxXQUFXLENBQUM7RUFBRSxJQUFJLEtBQUssQ0FBQyxLQUFLaFosQ0FBQyxFQUFFO0lBQzNELElBQUkwQixDQUFDLEdBQUcxQixDQUFDLENBQUNyUyxJQUFJLENBQUN1UyxDQUFDLEVBQUVvQyxDQUFDLElBQUksU0FBUyxDQUFDO0lBQ2pDLElBQUksUUFBUSxJQUFJbVcsT0FBTyxDQUFDL1csQ0FBQyxDQUFDLEVBQ3RCLE9BQU9BLENBQUM7SUFDWixNQUFNLElBQUltRCxTQUFTLENBQUMsOENBQThDLENBQUM7RUFDdkU7RUFBRSxPQUFPLENBQUMsUUFBUSxLQUFLdkMsQ0FBQyxHQUFHMkMsTUFBTSxHQUFHcVAsTUFBTSxFQUFFcFUsQ0FBQyxDQUFDO0FBQUU7QUFDaEQ7QUFDQTtBQUMyQztBQUMzQztBQUNBO0FBQ0E7QUFDQSxJQUFJdWdCLFlBQVksR0FBR3hiLE1BQU0sQ0FBQzFCLFNBQVMsQ0FBQ21kLFdBQVcsR0FBRyxVQUFVQyxLQUFLLEVBQUV4SixRQUFRLEVBQUU7RUFDekUsT0FBT3dKLEtBQUssQ0FBQ0QsV0FBVyxDQUFDdkosUUFBUSxDQUFDO0FBQ3RDLENBQUMsR0FBRyxVQUFVd0osS0FBSyxFQUFFeEosUUFBUSxFQUFFO0VBQzNCLE9BQU8sQ0FBQ3dKLEtBQUssQ0FBQ0MsVUFBVSxDQUFDekosUUFBUSxDQUFDLEdBQUcsTUFBTSxJQUFJLEtBQUssR0FBR3dKLEtBQUssQ0FBQ0MsVUFBVSxDQUFDekosUUFBUSxHQUFHLENBQUMsQ0FBQyxHQUFHLE1BQU0sR0FBRyxPQUFPO0FBQzVHLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJMEosa0JBQWtCLEdBQUcsU0FBU0Esa0JBQWtCQSxDQUFDQyxTQUFTLEVBQUVDLFdBQVcsRUFBRUMsYUFBYSxFQUFFO0VBQ3hGRCxXQUFXLENBQUNFLFNBQVMsR0FBRyxDQUFDO0VBQ3pCLElBQUlDLFlBQVksR0FBR0gsV0FBVyxDQUFDSSxJQUFJLENBQUNMLFNBQVMsQ0FBQztFQUM5QyxJQUFJTSxhQUFhO0VBQ2pCLElBQUlGLFlBQVksRUFBRTtJQUNkRSxhQUFhLEdBQUcsRUFBRTtJQUNsQixJQUFJQyxnQkFBZ0IsR0FBRyxDQUFDO0lBQ3hCLEdBQUc7TUFDQyxJQUFJQSxnQkFBZ0IsS0FBS0gsWUFBWSxDQUFDblIsS0FBSyxFQUFFO1FBQ3pDcVIsYUFBYSxJQUFJTixTQUFTLENBQUNuVyxTQUFTLENBQUMwVyxnQkFBZ0IsRUFBRUgsWUFBWSxDQUFDblIsS0FBSyxDQUFDO01BQzlFO01BQ0EsSUFBSXVSLFlBQVksR0FBR0osWUFBWSxDQUFDLENBQUMsQ0FBQztNQUNsQ0UsYUFBYSxJQUFJSixhQUFhLENBQUNNLFlBQVksQ0FBQztNQUM1Q0QsZ0JBQWdCLEdBQUdILFlBQVksQ0FBQ25SLEtBQUssR0FBR3VSLFlBQVksQ0FBQ3B5QixNQUFNO01BQzNEO0lBQ0osQ0FBQyxRQUFRZ3lCLFlBQVksR0FBR0gsV0FBVyxDQUFDSSxJQUFJLENBQUNMLFNBQVMsQ0FBQztJQUNuRCxJQUFJTyxnQkFBZ0IsS0FBS1AsU0FBUyxDQUFDNXhCLE1BQU0sRUFBRTtNQUN2Q2t5QixhQUFhLElBQUlOLFNBQVMsQ0FBQ25XLFNBQVMsQ0FBQzBXLGdCQUFnQixDQUFDO0lBQzFEO0VBQ0osQ0FBQyxNQUNJO0lBQ0RELGFBQWEsR0FBR04sU0FBUztFQUM3QjtFQUNBLE9BQU9NLGFBQWE7QUFDeEIsQ0FBQztBQUNELElBQUlHLFVBQVUsR0FBRztFQUNiLEdBQUcsRUFBRSxNQUFNO0VBQ1gsR0FBRyxFQUFFLE1BQU07RUFDWCxHQUFHLEVBQUUsUUFBUTtFQUNiLEdBQUcsRUFBRSxRQUFRO0VBQ2IsR0FBRyxFQUFFO0FBQ1QsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsTUFBTUEsQ0FBQ3BQLElBQUksRUFBRTtFQUNsQixJQUFJLENBQUNBLElBQUksRUFBRTtJQUNQLE9BQU8sRUFBRTtFQUNiO0VBQ0EsT0FBT3lPLGtCQUFrQixDQUFDek8sSUFBSSxFQUFFLFVBQVUsRUFBRSxVQUFVdU8sS0FBSyxFQUFFO0lBQ3pELElBQUl6MUIsTUFBTSxHQUFHcTJCLFVBQVUsQ0FBQ1osS0FBSyxDQUFDO0lBQzlCLElBQUksQ0FBQ3oxQixNQUFNLEVBQUU7TUFDVCxJQUFJcW9CLElBQUksR0FBR29OLEtBQUssQ0FBQ3p4QixNQUFNLEdBQUcsQ0FBQyxHQUFHdXhCLFlBQVksQ0FBQ0UsS0FBSyxFQUFFLENBQUMsQ0FBQyxHQUFHQSxLQUFLLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUM7TUFDMUUxMUIsTUFBTSxHQUFHLElBQUksQ0FBQ0csTUFBTSxDQUFDa29CLElBQUksRUFBRSxHQUFHLENBQUM7SUFDbkM7SUFDQSxPQUFPcm9CLE1BQU07RUFDakIsQ0FBQyxDQUFDO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU3UyQixhQUFhQSxDQUFDajJCLElBQUksRUFBRWlMLEtBQUssRUFBRTtFQUNoQyxJQUFJaXJCLE1BQU0sR0FBR2wyQixJQUFJLENBQUNrMkIsTUFBTTtJQUFFaE0sT0FBTyxHQUFHbHFCLElBQUksQ0FBQ2txQixPQUFPO0lBQUVpTSxPQUFPLEdBQUduMkIsSUFBSSxDQUFDbTJCLE9BQU87RUFDeEUsSUFBSUMsT0FBTyxHQUFHbnJCLEtBQUssQ0FBQ21yQixPQUFPO0VBQzNCLElBQUlDLFlBQVksR0FBR0YsT0FBTztFQUMxQixJQUFJRyxjQUFjLEdBQUdwTSxPQUFPO0VBQzVCLE9BQU87SUFDSHFNLElBQUksRUFBRSxTQUFTQSxJQUFJQSxDQUFDQyxLQUFLLEVBQUU7TUFDdkIsSUFBSUMsY0FBYyxHQUFHUCxNQUFNLENBQUNHLFlBQVksQ0FBQyxDQUFDcEwsRUFBRTtNQUM1QyxJQUFJeUwsZ0JBQWdCLEdBQUdELGNBQWMsSUFBSUEsY0FBYyxDQUFDRCxLQUFLLENBQUMxTSxJQUFJLENBQUM7TUFDbkUsSUFBSTRNLGdCQUFnQixFQUFFO1FBQ2xCTCxZQUFZLEdBQUdLLGdCQUFnQixDQUFDck8sTUFBTTtRQUN0QyxJQUFJcU8sZ0JBQWdCLENBQUNOLE9BQU8sRUFBRTtVQUMxQk0sZ0JBQWdCLENBQUNOLE9BQU8sQ0FBQ3ZtQixPQUFPLENBQUMsVUFBVThtQixPQUFPLEVBQUU7WUFDaEQsSUFBSUMsVUFBVSxHQUFHUixPQUFPLENBQUNPLE9BQU8sQ0FBQztZQUNqQyxJQUFJRSxnQkFBZ0IsR0FBR0QsVUFBVSxJQUFJQSxVQUFVLENBQUNOLGNBQWMsRUFBRUUsS0FBSyxDQUFDO1lBQ3RFLElBQUlLLGdCQUFnQixFQUFFO2NBQ2xCUCxjQUFjLEdBQUdsbkIsYUFBYSxDQUFDQSxhQUFhLENBQUMsQ0FBQyxDQUFDLEVBQUVrbkIsY0FBYyxDQUFDLEVBQUVPLGdCQUFnQixDQUFDO1lBQ3ZGO1VBQ0osQ0FBQyxDQUFDO1FBQ047TUFDSjtJQUNKO0VBQ0osQ0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlDLG9CQUFvQixHQUFHLFNBQVNBLG9CQUFvQkEsQ0FBQzFDLE9BQU8sRUFBRTtFQUM5RCxJQUFJMkMsV0FBVyxHQUFHM0MsT0FBTyxDQUFDMkMsV0FBVztJQUFFQyxXQUFXLEdBQUc1QyxPQUFPLENBQUM0QyxXQUFXO0VBQ3hFLE9BQU9mLGFBQWEsQ0FBQztJQUNqQkUsT0FBTyxFQUFFLFFBQVE7SUFDakJqTSxPQUFPLEVBQUU7TUFDTDZJLEtBQUssRUFBRSxPQUFPO01BQ2RrRSxRQUFRLEVBQUUsRUFBRTtNQUNaQyxhQUFhLEVBQUU7SUFDbkIsQ0FBQztJQUNEaEIsTUFBTSxFQUFFO01BQ0ppQixNQUFNLEVBQUU7UUFDSmxNLEVBQUUsRUFBRTtVQUNBbU0sV0FBVyxFQUFFO1lBQ1QvTyxNQUFNLEVBQUUsbUJBQW1CO1lBQzNCK04sT0FBTyxFQUFFLENBQUMsYUFBYSxFQUFFLGFBQWE7VUFDMUMsQ0FBQztVQUNEaUIsYUFBYSxFQUFFO1lBQ1hoUCxNQUFNLEVBQUUscUJBQXFCO1lBQzdCK04sT0FBTyxFQUFFLENBQUMsYUFBYSxFQUFFLGFBQWE7VUFDMUM7UUFDSjtNQUNKLENBQUM7TUFDRGtCLGlCQUFpQixFQUFFO1FBQ2ZyTSxFQUFFLEVBQUU7VUFDQXNNLE9BQU8sRUFBRTtZQUNMbFAsTUFBTSxFQUFFLFFBQVE7WUFDaEIrTixPQUFPLEVBQUUsQ0FBQyxpQkFBaUIsRUFBRSxhQUFhO1VBQzlDLENBQUM7VUFDRGdCLFdBQVcsRUFBRTtZQUNUL08sTUFBTSxFQUFFLG1CQUFtQjtZQUMzQitOLE9BQU8sRUFBRSxDQUFDLGdCQUFnQixFQUFFLGFBQWE7VUFDN0M7UUFDSjtNQUNKLENBQUM7TUFDRG9CLG1CQUFtQixFQUFFO1FBQ2pCdk0sRUFBRSxFQUFFO1VBQ0FzTSxPQUFPLEVBQUU7WUFDTGxQLE1BQU0sRUFBRSxRQUFRO1lBQ2hCK04sT0FBTyxFQUFFLENBQUMsaUJBQWlCLEVBQUUsYUFBYTtVQUM5QyxDQUFDO1VBQ0RpQixhQUFhLEVBQUU7WUFDWGhQLE1BQU0sRUFBRSxxQkFBcUI7WUFDN0IrTixPQUFPLEVBQUUsQ0FBQyxnQkFBZ0IsRUFBRSxhQUFhO1VBQzdDLENBQUM7VUFDRGdCLFdBQVcsRUFBRTtZQUNUL08sTUFBTSxFQUFFLG1CQUFtQjtZQUMzQitOLE9BQU8sRUFBRSxDQUFDLGFBQWEsRUFBRSxhQUFhO1VBQzFDO1FBQ0o7TUFDSjtJQUNKO0VBQ0osQ0FBQyxFQUFFO0lBQ0NBLE9BQU8sRUFBRTtNQUNMcUIsZUFBZSxFQUFFLFNBQVNBLGVBQWVBLENBQUEsRUFBRztRQUN4QyxPQUFPO1VBQ0hSLFFBQVEsRUFBRSxFQUFFO1VBQ1psRSxLQUFLLEVBQUUsT0FBTztVQUNkbUUsYUFBYSxFQUFFO1FBQ25CLENBQUM7TUFDTCxDQUFDO01BQ0RRLGNBQWMsRUFBRSxTQUFTQSxjQUFjQSxDQUFDeE4sT0FBTyxFQUFFc00sS0FBSyxFQUFFO1FBQ3BELE9BQU87VUFDSFMsUUFBUSxFQUFFL00sT0FBTyxDQUFDK00sUUFBUSxDQUFDcDNCLE1BQU0sQ0FBQzIyQixLQUFLLENBQUNTLFFBQVEsQ0FBQztVQUNqRGxFLEtBQUssRUFBRXlELEtBQUssQ0FBQ3pELEtBQUssSUFBSTdJLE9BQU8sQ0FBQzZJLEtBQUs7VUFDbkNtRSxhQUFhLEVBQUVWLEtBQUssQ0FBQzFNLElBQUksS0FBSyxlQUFlLEdBQUcsU0FBUyxHQUFHO1FBQ2hFLENBQUM7TUFDTCxDQUFDO01BQ0Q2TixXQUFXLEVBQUUsU0FBU0EsV0FBV0EsQ0FBQ3pOLE9BQU8sRUFBRXNNLEtBQUssRUFBRTtRQUM5QyxPQUFPO1VBQ0hTLFFBQVEsRUFBRVQsS0FBSyxDQUFDUyxRQUFRO1VBQ3hCbEUsS0FBSyxFQUFFeUQsS0FBSyxDQUFDekQsS0FBSyxJQUFJN0ksT0FBTyxDQUFDNkksS0FBSztVQUNuQ21FLGFBQWEsRUFBRVYsS0FBSyxDQUFDMU0sSUFBSSxLQUFLLGVBQWUsR0FBRyxTQUFTLEdBQUc7UUFDaEUsQ0FBQztNQUNMLENBQUM7TUFDRGlOLFdBQVcsRUFBRUEsV0FBVztNQUN4QkMsV0FBVyxFQUFFQTtJQUNqQjtFQUNKLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlZLGtCQUFrQixHQUFHLFNBQVNBLGtCQUFrQkEsQ0FBQzVqQixLQUFLLEVBQUU7RUFDeEQsSUFBSSxDQUFDQSxLQUFLLElBQUksRUFBRUEsS0FBSyxZQUFZcFUsS0FBSyxDQUFDLEVBQUU7SUFDckMsTUFBTSxJQUFJQSxLQUFLLENBQUMseUNBQXlDLENBQUM7RUFDOUQ7RUFDQSxJQUFJLE9BQU9vVSxLQUFLLENBQUM2akIsS0FBSyxLQUFLLFFBQVEsRUFBRTtJQUNqQyxPQUFPN2pCLEtBQUssQ0FBQzZqQixLQUFLLENBQUM5WSxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUN0UyxNQUFNLENBQUMsVUFBVW9yQixLQUFLLEVBQUU7TUFDbkQsT0FBT0EsS0FBSyxLQUFLLFNBQVMsQ0FBQ2g0QixNQUFNLENBQUNtVSxLQUFLLENBQUNpVyxPQUFPLENBQUM7SUFDcEQsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk2TixvQkFBb0IsR0FBRyxTQUFTQSxvQkFBb0JBLENBQUNqcEIsUUFBUSxFQUFFO0VBQy9EclAsTUFBTSxDQUFDcVUsZ0JBQWdCLENBQUMsT0FBTyxFQUFFaEYsUUFBUSxDQUFDO0VBQzFDLE9BQU8sU0FBU2twQixPQUFPQSxDQUFBLEVBQUc7SUFDdEJ2NEIsTUFBTSxDQUFDd3RCLG1CQUFtQixDQUFDLE9BQU8sRUFBRW5lLFFBQVEsQ0FBQztFQUNqRCxDQUFDO0FBQ0wsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJbXBCLDBCQUEwQixHQUFHLFNBQVNBLDBCQUEwQkEsQ0FBQ25wQixRQUFRLEVBQUU7RUFDM0VyUCxNQUFNLENBQUNxVSxnQkFBZ0IsQ0FBQyxvQkFBb0IsRUFBRWhGLFFBQVEsQ0FBQztFQUN2RCxPQUFPLFNBQVNrcEIsT0FBT0EsQ0FBQSxFQUFHO0lBQ3RCdjRCLE1BQU0sQ0FBQ3d0QixtQkFBbUIsQ0FBQyxvQkFBb0IsRUFBRW5lLFFBQVEsQ0FBQztFQUM5RCxDQUFDO0FBQ0wsQ0FBQztBQUNEO0FBQ0EsSUFBSW9wQixTQUFTLEdBQUc7RUFDWmprQixLQUFLLEVBQUU7SUFDSGtrQixlQUFlLEVBQUUsd0JBQXdCO0lBQ3pDbFEsS0FBSyxFQUFFO0VBQ1gsQ0FBQztFQUNEWSxPQUFPLEVBQUU7SUFDTHNQLGVBQWUsRUFBRSwwQkFBMEI7SUFDM0NsUSxLQUFLLEVBQUU7RUFDWDtBQUNKLENBQUM7QUFDRCxJQUFJbVEsV0FBVyxHQUFHO0VBQ2R4TSxRQUFRLEVBQUUsT0FBTztFQUNqQnlNLEdBQUcsRUFBRSxDQUFDO0VBQ05DLElBQUksRUFBRSxDQUFDO0VBQ1BDLEtBQUssRUFBRSxDQUFDO0VBQ1JDLE1BQU0sRUFBRSxDQUFDO0VBQ1RDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLE1BQU0sRUFBRSxPQUFPO0VBQ2ZDLE1BQU0sRUFBRSxNQUFNO0VBQ2QsU0FBUyxFQUFFO0FBQ2YsQ0FBQztBQUNELElBQUlDLGNBQWMsR0FBRztFQUNqQmhOLFFBQVEsRUFBRSxPQUFPO0VBQ2pCaU4sU0FBUyxFQUFFLFlBQVk7RUFDdkJQLElBQUksRUFBRSxDQUFDO0VBQ1BELEdBQUcsRUFBRSxDQUFDO0VBQ05FLEtBQUssRUFBRSxDQUFDO0VBQ1JDLE1BQU0sRUFBRSxDQUFDO0VBQ1RDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLE1BQU0sRUFBRSxPQUFPO0VBQ2ZJLFFBQVEsRUFBRSxPQUFPO0VBQ2pCQyxPQUFPLEVBQUUscUJBQXFCO0VBQzlCQyxVQUFVLEVBQUUsS0FBSztFQUNqQkMsVUFBVSxFQUFFLFVBQVU7RUFDdEJDLFFBQVEsRUFBRSxNQUFNO0VBQ2hCZixlQUFlLEVBQUUsb0JBQW9CO0VBQ3JDbFEsS0FBSyxFQUFFO0FBQ1gsQ0FBQztBQUNELElBQUlrUixXQUFXLEdBQUc7RUFDZGxSLEtBQUssRUFBRSxTQUFTO0VBQ2hCNlEsUUFBUSxFQUFFLEtBQUs7RUFDZkcsVUFBVSxFQUFFLFVBQVU7RUFDdEJHLFVBQVUsRUFBRSxZQUFZO0VBQ3hCQyxNQUFNLEVBQUUsZUFBZTtFQUN2QkMsSUFBSSxFQUFFLFVBQVU7RUFDaEJDLFNBQVMsRUFBRSxLQUFLO0VBQ2hCTCxRQUFRLEVBQUU7QUFDZCxDQUFDO0FBQ0QsSUFBSU0sa0JBQWtCLEdBQUc7RUFDckJ2UixLQUFLLEVBQUUsU0FBUztFQUNoQitRLFVBQVUsRUFBRSxNQUFNO0VBQ2xCRixRQUFRLEVBQUUsUUFBUTtFQUNsQkMsT0FBTyxFQUFFLE1BQU07RUFDZlUsTUFBTSxFQUFFLFNBQVM7RUFDakI3TixRQUFRLEVBQUUsVUFBVTtFQUNwQjJNLEtBQUssRUFBRSxDQUFDO0VBQ1JGLEdBQUcsRUFBRSxDQUFDO0VBQ05GLGVBQWUsRUFBRSxhQUFhO0VBQzlCUSxNQUFNLEVBQUU7QUFDWixDQUFDO0FBQ0QsSUFBSWUsWUFBWSxHQUFHO0VBQ2Z6UixLQUFLLEVBQUUsU0FBUztFQUNoQjZRLFFBQVEsRUFBRSxPQUFPO0VBQ2pCYSxZQUFZLEVBQUUsTUFBTTtFQUNwQlAsVUFBVSxFQUFFO0FBQ2hCLENBQUM7QUFDRCxJQUFJUSxZQUFZLEdBQUc7RUFDZlosVUFBVSxFQUFFLEtBQUs7RUFDakJGLFFBQVEsRUFBRSxNQUFNO0VBQ2hCTSxVQUFVLEVBQUU7QUFDaEIsQ0FBQztBQUNEO0FBQ0EsSUFBSTlSLE1BQU0sR0FBRztFQUNUdEIsS0FBSyxFQUFFLENBQUMsYUFBYSxFQUFFLGFBQWEsQ0FBQztFQUNyQ0MsS0FBSyxFQUFFLFFBQVE7RUFDZkMsR0FBRyxFQUFFLFFBQVE7RUFDYkMsS0FBSyxFQUFFLFFBQVE7RUFDZkMsTUFBTSxFQUFFLFFBQVE7RUFDaEJDLElBQUksRUFBRSxRQUFRO0VBQ2RDLE9BQU8sRUFBRSxRQUFRO0VBQ2pCQyxJQUFJLEVBQUUsUUFBUTtFQUNkQyxTQUFTLEVBQUUsUUFBUTtFQUNuQkMsUUFBUSxFQUFFO0FBQ2QsQ0FBQztBQUNEWixvRUFBa0IsQ0FBQ3lCLE1BQU0sQ0FBQztBQUMxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSXVTLGFBQWEsR0FBRyxTQUFTQSxhQUFhQSxDQUFDOVAsSUFBSSxFQUFFd0ksSUFBSSxFQUFFO0VBQ25ELElBQUl1SCxNQUFNLEdBQUcvUCxJQUFJLEtBQUssU0FBUyxHQUFHLFNBQVMsR0FBRyxPQUFPO0VBQ3JELElBQUlwYyxJQUFJLEdBQUcsRUFBRTtFQUNiLElBQUksT0FBTzRrQixJQUFJLEtBQUssUUFBUSxFQUFFO0lBQzFCNWtCLElBQUksSUFBSTRrQixJQUFJO0VBQ2hCLENBQUMsTUFDSTtJQUNELElBQUl3SCxJQUFJLEdBQUd4SCxJQUFJLENBQUN3SCxJQUFJLElBQUksRUFBRTtJQUMxQjtJQUNBLElBQUlDLFVBQVUsR0FBR3pILElBQUksQ0FBQ3lILFVBQVUsR0FBR3pILElBQUksQ0FBQ3lILFVBQVUsQ0FBQzlTLE9BQU8sQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUNwbkIsTUFBTSxDQUFDeXlCLElBQUksQ0FBQ3lILFVBQVUsQ0FBQ3RhLE9BQU8sQ0FBQyxZQUFZLEVBQUUsRUFBRSxDQUFDLEVBQUUsSUFBSSxDQUFDLENBQUM1ZixNQUFNLENBQUN5eUIsSUFBSSxDQUFDeUgsVUFBVSxFQUFFLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQ2w2QixNQUFNLENBQUN5eUIsSUFBSSxDQUFDeUgsVUFBVSxDQUFDLEdBQUcsRUFBRTtJQUNsTSxJQUFJQyxHQUFHLEdBQUcxSCxJQUFJLENBQUMwSCxHQUFHO0lBQ2xCSCxNQUFNLElBQUksRUFBRSxDQUFDaDZCLE1BQU0sQ0FBQ2s2QixVQUFVLElBQUlELElBQUksR0FBRyxNQUFNLENBQUNqNkIsTUFBTSxDQUFDazZCLFVBQVUsR0FBRyxFQUFFLENBQUNsNkIsTUFBTSxDQUFDazZCLFVBQVUsQ0FBQyxDQUFDbDZCLE1BQU0sQ0FBQ2k2QixJQUFJLEdBQUcsSUFBSSxDQUFDajZCLE1BQU0sQ0FBQ2k2QixJQUFJLEVBQUUsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDLEdBQUdBLElBQUksQ0FBQyxDQUFDajZCLE1BQU0sQ0FBQ202QixHQUFHLEdBQUcsR0FBRyxDQUFDbjZCLE1BQU0sQ0FBQ202QixHQUFHLENBQUMsR0FBRyxFQUFFLENBQUMsR0FBRyxFQUFFLENBQUM7SUFDckx0c0IsSUFBSSxJQUFJNGtCLElBQUksQ0FBQ3JJLE9BQU8sSUFBSSxFQUFFO0VBQzlCO0VBQ0EsSUFBSTFSLEtBQUssQ0FBQ2lQLE9BQU8sQ0FBQzhLLElBQUksQ0FBQ3VGLEtBQUssQ0FBQyxFQUFFO0lBQzNCdkYsSUFBSSxDQUFDdUYsS0FBSyxDQUFDaG9CLE9BQU8sQ0FBQyxVQUFVZ29CLEtBQUssRUFBRTtNQUNoQyxJQUFJLE9BQU9BLEtBQUssS0FBSyxRQUFRLEVBQUU7UUFDM0JucUIsSUFBSSxJQUFJLE1BQU0sQ0FBQzdOLE1BQU0sQ0FBQ2c0QixLQUFLLENBQUM7TUFDaEM7SUFDSixDQUFDLENBQUM7RUFDTjtFQUNBLE9BQU87SUFDSGdDLE1BQU0sRUFBRUEsTUFBTTtJQUNkbnNCLElBQUksRUFBRUE7RUFDVixDQUFDO0FBQ0wsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUl1c0IsYUFBYSxHQUFHLFNBQVNBLGFBQWFBLENBQUM3RixPQUFPLEVBQUU7RUFDaEQ7RUFDQSxJQUFJOEYsc0JBQXNCO0VBQzFCO0VBQ0EsSUFBSUMsZ0JBQWdCO0VBQ3BCO0VBQ0EsSUFBSUMsYUFBYTtFQUNqQjtFQUNBLElBQUlDLFdBQVcsR0FBRyxFQUFFO0VBQ3BCO0VBQ0EsSUFBSUMseUJBQXlCO0VBQzdCO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7RUFDSSxTQUFTQyxVQUFVQSxDQUFDQyxPQUFPLEVBQUU3bEIsS0FBSyxFQUFFO0lBQ2hDckYsTUFBTSxDQUFDQyxJQUFJLENBQUNvRixLQUFLLENBQUMsQ0FBQzlFLE9BQU8sQ0FBQyxVQUFVNGtCLElBQUksRUFBRTtNQUN2QytGLE9BQU8sQ0FBQzdsQixLQUFLLENBQUM4ZixJQUFJLENBQUMsR0FBRzlmLEtBQUssQ0FBQzhmLElBQUksQ0FBQztJQUNyQyxDQUFDLENBQUM7RUFDTjtFQUNBO0FBQ0o7QUFDQTtFQUNJLFNBQVNnRyxlQUFlQSxDQUFDQyxzQkFBc0IsRUFBRTtJQUM3QztJQUNBLElBQUlsN0IsTUFBTSxDQUFDbTdCLFlBQVksRUFBRTtNQUNyQkwseUJBQXlCLEdBQUc5NkIsTUFBTSxDQUFDbTdCLFlBQVksQ0FBQ0MsWUFBWSxDQUFDRixzQkFBc0IsSUFBSSw0QkFBNEIsRUFBRTtRQUNqSEcsVUFBVSxFQUFFLFNBQVNBLFVBQVVBLENBQUN6eEIsS0FBSyxFQUFFO1VBQ25DLE9BQU9BLEtBQUs7UUFDaEI7TUFDSixDQUFDLENBQUM7SUFDTjtJQUNBOHdCLHNCQUFzQixHQUFHejNCLFFBQVEsQ0FBQ21SLGFBQWEsQ0FBQyxRQUFRLENBQUM7SUFDekRzbUIsc0JBQXNCLENBQUNuMkIsRUFBRSxHQUFHLG1DQUFtQztJQUMvRG0yQixzQkFBc0IsQ0FBQ2htQixHQUFHLEdBQUcsYUFBYTtJQUMxQ3FtQixVQUFVLENBQUNMLHNCQUFzQixFQUFFL0IsV0FBVyxDQUFDO0lBQy9DK0Isc0JBQXNCLENBQUNZLE1BQU0sR0FBRyxZQUFZO01BQ3hDLElBQUlDLGNBQWMsR0FBRyx1QkFBd0IsQ0FBRSxnQ0FBZ0NiLHNCQUFzQixDQUFDYyxlQUFlLEVBQUVwbkIsYUFBYSxDQUFDLEtBQUssQ0FBQztNQUMzSXVtQixnQkFBZ0IsR0FBRztNQUNmLENBQUUsZ0NBQWdDRCxzQkFBc0IsQ0FBQ2MsZUFBZSxFQUFFcG5CLGFBQWEsQ0FBQyxLQUFLLENBQUM7TUFDbEdtbkIsY0FBYyxDQUFDaDNCLEVBQUUsR0FBRyx1Q0FBdUM7TUFDM0R3MkIsVUFBVSxDQUFDUSxjQUFjLEVBQUVwQyxjQUFjLENBQUM7TUFDMUN5QixhQUFhLEdBQUczM0IsUUFBUSxDQUFDbVIsYUFBYSxDQUFDLEtBQUssQ0FBQztNQUM3Q3dtQixhQUFhLENBQUNhLFNBQVMsR0FBRyx5QkFBeUI7TUFDbkRWLFVBQVUsQ0FBQ0gsYUFBYSxFQUFFbEIsV0FBVyxDQUFDO01BQ3RDLElBQUlnQyxrQkFBa0IsR0FBR3o0QixRQUFRLENBQUNtUixhQUFhLENBQUMsUUFBUSxDQUFDO01BQ3pEMm1CLFVBQVUsQ0FBQ1csa0JBQWtCLEVBQUUzQixrQkFBa0IsQ0FBQztNQUNsRDJCLGtCQUFrQixDQUFDRCxTQUFTLEdBQUcsR0FBRztNQUNsQ0Msa0JBQWtCLENBQUNDLFNBQVMsR0FBRyxTQUFTO01BQ3hDRCxrQkFBa0IsQ0FBQ3JuQixnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsWUFBWTtRQUNyRDtRQUNBdW5CLGNBQWMsQ0FBQzdFLElBQUksQ0FBQztVQUNoQnpNLElBQUksRUFBRTtRQUNWLENBQUMsQ0FBQztNQUNOLENBQUMsQ0FBQztNQUNGaVIsY0FBYyxDQUFDNW1CLFdBQVcsQ0FBQ2ltQixhQUFhLENBQUM7TUFDekNXLGNBQWMsQ0FBQzVtQixXQUFXLENBQUMrbUIsa0JBQWtCLENBQUM7TUFDOUNILGNBQWMsQ0FBQzVtQixXQUFXLENBQUNnbUIsZ0JBQWdCLENBQUM7TUFDNUM7TUFDQSxDQUFFLGdDQUFnQ0Qsc0JBQXNCLENBQUNjLGVBQWUsRUFBRXR0QixJQUFJLENBQUN5RyxXQUFXLENBQUM0bUIsY0FBYyxDQUFDO01BQzFHVixXQUFXLENBQUN4cUIsT0FBTyxDQUFDLFVBQVV3ckIsTUFBTSxFQUFFO1FBQ2xDQSxNQUFNLENBQUMsNkJBQThCTixjQUFjLENBQUM7TUFDeEQsQ0FBQyxDQUFDO01BQ0ZWLFdBQVcsR0FBRyxFQUFFO01BQ2hCO01BQ0FILHNCQUFzQixDQUFDWSxNQUFNLEdBQUcsSUFBSTtJQUN4QyxDQUFDO0lBQ0RyNEIsUUFBUSxDQUFDaUwsSUFBSSxDQUFDeUcsV0FBVyxDQUFDK2xCLHNCQUFzQixDQUFDO0VBQ3JEO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7RUFDSSxTQUFTb0IsbUJBQW1CQSxDQUFDenNCLFFBQVEsRUFBRTZyQixzQkFBc0IsRUFBRTtJQUMzRCxJQUFJUCxnQkFBZ0IsRUFBRTtNQUNsQkEsZ0JBQWdCLENBQUNvQixTQUFTLEdBQUdqQix5QkFBeUIsR0FBR0EseUJBQXlCLENBQUNPLFVBQVUsQ0FBQyxFQUFFLENBQUMsR0FBRyxFQUFFO01BQ3RHO01BQ0Foc0IsUUFBUSxDQUFDc3JCLGdCQUFnQixDQUFDO01BQzFCO0lBQ0o7SUFDQUUsV0FBVyxDQUFDbnFCLElBQUksQ0FBQ3JCLFFBQVEsQ0FBQztJQUMxQixJQUFJcXJCLHNCQUFzQixFQUFFO01BQ3hCO0lBQ0o7SUFDQU8sZUFBZSxDQUFDQyxzQkFBc0IsQ0FBQztFQUMzQztFQUNBO0VBQ0EsU0FBU2MsSUFBSUEsQ0FBQSxFQUFHO0lBQ1osSUFBSSxDQUFDdEIsc0JBQXNCLEVBQUU7TUFDekI7SUFDSjtJQUNBO0lBQ0F6M0IsUUFBUSxDQUFDaUwsSUFBSSxDQUFDK3RCLFdBQVcsQ0FBQ3ZCLHNCQUFzQixDQUFDO0lBQ2pEQSxzQkFBc0IsR0FBRyxJQUFJO0lBQzdCQyxnQkFBZ0IsR0FBRyxJQUFJO0VBQzNCO0VBQ0E7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSSxTQUFTdUIsSUFBSUEsQ0FBQzVSLElBQUksRUFBRW1OLFFBQVEsRUFBRXlELHNCQUFzQixFQUFFeEQsYUFBYSxFQUFFO0lBQ2pFb0UsbUJBQW1CLENBQUMsWUFBWTtNQUM1QmxCLGFBQWEsQ0FBQ2EsU0FBUyxHQUFHL0QsYUFBYSxLQUFLLFNBQVMsR0FBRywwQkFBMEIsR0FBRyx5QkFBeUI7TUFDOUdELFFBQVEsQ0FBQ3BuQixPQUFPLENBQUMsVUFBVW9hLE9BQU8sRUFBRTtRQUNoQyxJQUFJMFIsWUFBWSxHQUFHbDVCLFFBQVEsQ0FBQ21SLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDaEQsSUFBSWdvQixRQUFRLEdBQUc5UixJQUFJLEtBQUssU0FBUyxHQUFHbU8sU0FBUyxDQUFDclAsT0FBTyxHQUFHcVAsU0FBUyxDQUFDamtCLEtBQUs7UUFDdkV1bUIsVUFBVSxDQUFDb0IsWUFBWSxFQUFFdnNCLGFBQWEsQ0FBQ0EsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFd3NCLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFO1VBQ3BFOUMsT0FBTyxFQUFFO1FBQ2IsQ0FBQyxDQUFDLENBQUM7UUFDSCxJQUFJK0MsV0FBVyxHQUFHcDVCLFFBQVEsQ0FBQ21SLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDL0MsSUFBSWtvQixjQUFjLEdBQUdsQyxhQUFhLENBQUM5UCxJQUFJLEVBQUVHLE9BQU8sQ0FBQztVQUFFNFAsTUFBTSxHQUFHaUMsY0FBYyxDQUFDakMsTUFBTTtVQUFFbnNCLElBQUksR0FBR291QixjQUFjLENBQUNwdUIsSUFBSTtRQUM3R211QixXQUFXLENBQUNaLFNBQVMsR0FBR3BCLE1BQU07UUFDOUJVLFVBQVUsQ0FBQ3NCLFdBQVcsRUFBRXBDLFlBQVksQ0FBQztRQUNyQyxJQUFJeFAsT0FBTyxDQUFDOFIsZ0JBQWdCLEVBQUU7VUFDMUJ4QixVQUFVLENBQUNzQixXQUFXLEVBQUU7WUFDcEJyQyxNQUFNLEVBQUU7VUFDWixDQUFDLENBQUM7VUFDRjtVQUNBcUMsV0FBVyxDQUFDRyxZQUFZLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQztVQUMvQ0gsV0FBVyxDQUFDaG9CLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxZQUFZO1lBQzlDdkksS0FBSyxDQUFDLDJDQUEyQyxDQUFDekwsTUFBTSxDQUFDb3FCLE9BQU8sQ0FBQzhSLGdCQUFnQixDQUFDLENBQUM7VUFDdkYsQ0FBQyxDQUFDO1FBQ047UUFDQTtRQUNBLElBQUluVixJQUFJLEdBQUdoQiwwREFBUSxDQUFDb1EsTUFBTSxDQUFDdG9CLElBQUksQ0FBQyxDQUFDO1FBQ2pDLElBQUl1dUIsZUFBZSxHQUFHeDVCLFFBQVEsQ0FBQ21SLGFBQWEsQ0FBQyxLQUFLLENBQUM7UUFDbkQybUIsVUFBVSxDQUFDMEIsZUFBZSxFQUFFdEMsWUFBWSxDQUFDO1FBQ3pDc0MsZUFBZSxDQUFDVixTQUFTLEdBQUdqQix5QkFBeUIsR0FBR0EseUJBQXlCLENBQUNPLFVBQVUsQ0FBQ2pVLElBQUksQ0FBQyxHQUFHQSxJQUFJO1FBQ3pHK1UsWUFBWSxDQUFDeG5CLFdBQVcsQ0FBQzBuQixXQUFXLENBQUM7UUFDckNGLFlBQVksQ0FBQ3huQixXQUFXLENBQUM4bkIsZUFBZSxDQUFDO1FBQ3pDO1FBQ0E5QixnQkFBZ0IsQ0FBQ2htQixXQUFXLENBQUN3bkIsWUFBWSxDQUFDO01BQzlDLENBQUMsQ0FBQztJQUNOLENBQUMsRUFBRWpCLHNCQUFzQixDQUFDO0VBQzlCO0VBQ0EsSUFBSVUsY0FBYyxHQUFHdEUsb0JBQW9CLENBQUM7SUFDdENFLFdBQVcsRUFBRSxTQUFTQSxXQUFXQSxDQUFDcHFCLEtBQUssRUFBRTtNQUNyQyxJQUFJc3ZCLFdBQVcsR0FBR3R2QixLQUFLLENBQUNtbUIsS0FBSztRQUFFQSxLQUFLLEdBQUdtSixXQUFXLEtBQUssS0FBSyxDQUFDLEdBQUcsT0FBTyxHQUFHQSxXQUFXO1FBQUVqRixRQUFRLEdBQUdycUIsS0FBSyxDQUFDcXFCLFFBQVE7UUFBRUMsYUFBYSxHQUFHdHFCLEtBQUssQ0FBQ3NxQixhQUFhO01BQ3JKLE9BQU93RSxJQUFJLENBQUMzSSxLQUFLLEVBQUVrRSxRQUFRLEVBQUU3QyxPQUFPLENBQUNzRyxzQkFBc0IsRUFBRXhELGFBQWEsQ0FBQztJQUMvRSxDQUFDO0lBQ0RILFdBQVcsRUFBRXlFO0VBQ2pCLENBQUMsQ0FBQztFQUNGLElBQUlwSCxPQUFPLENBQUMrSCxpQkFBaUIsRUFBRTtJQUMzQjtBQUNSO0FBQ0E7QUFDQTtJQUNRLElBQUlDLFdBQVcsR0FBRyxTQUFTQSxXQUFXQSxDQUFDcG9CLEtBQUssRUFBRXFvQixlQUFlLEVBQUU7TUFDM0QsSUFBSTdvQixXQUFXLEdBQUdRLEtBQUssWUFBWXBVLEtBQUssR0FBR29VLEtBQUssR0FBRyxJQUFJcFUsS0FBSyxDQUFDb1UsS0FBSyxJQUFJcW9CLGVBQWUsQ0FBQztNQUN0RixJQUFJQyxhQUFhLEdBQUcsT0FBT2xJLE9BQU8sQ0FBQytILGlCQUFpQixLQUFLLFVBQVUsR0FBRy9ILE9BQU8sQ0FBQytILGlCQUFpQixDQUFDM29CLFdBQVcsQ0FBQyxHQUFHLElBQUk7TUFDbkgsSUFBSThvQixhQUFhLEVBQUU7UUFDZmxCLGNBQWMsQ0FBQzdFLElBQUksQ0FBQztVQUNoQnpNLElBQUksRUFBRSxlQUFlO1VBQ3JCbU4sUUFBUSxFQUFFLENBQUM7WUFDSGhOLE9BQU8sRUFBRXpXLFdBQVcsQ0FBQ3lXLE9BQU87WUFDNUI0TixLQUFLLEVBQUVELGtCQUFrQixDQUFDcGtCLFdBQVc7VUFDekMsQ0FBQztRQUNULENBQUMsQ0FBQztNQUNOO0lBQ0osQ0FBQztJQUNEc2tCLG9CQUFvQixDQUFDLFVBQVV5RSxVQUFVLEVBQUU7TUFDdkM7TUFDQSxJQUFJdm9CLEtBQUssR0FBR3VvQixVQUFVLENBQUN2b0IsS0FBSztRQUFFaVcsT0FBTyxHQUFHc1MsVUFBVSxDQUFDdFMsT0FBTztNQUMxRCxJQUFJLENBQUNqVyxLQUFLLElBQUksQ0FBQ2lXLE9BQU8sRUFBRTtRQUNwQjtNQUNKO01BQ0E7TUFDQSxJQUFJalcsS0FBSyxJQUFJQSxLQUFLLENBQUM2akIsS0FBSyxJQUFJN2pCLEtBQUssQ0FBQzZqQixLQUFLLENBQUMxd0IsUUFBUSxDQUFDLDBCQUEwQixDQUFDLEVBQUU7UUFDMUU7TUFDSjtNQUNBaTFCLFdBQVcsQ0FBQ3BvQixLQUFLLEVBQUVpVyxPQUFPLENBQUM7SUFDL0IsQ0FBQyxDQUFDO0lBQ0YrTiwwQkFBMEIsQ0FBQyxVQUFVd0UscUJBQXFCLEVBQUU7TUFDeEQsSUFBSUMsTUFBTSxHQUFHRCxxQkFBcUIsQ0FBQ0MsTUFBTTtNQUN6Q0wsV0FBVyxDQUFDSyxNQUFNLEVBQUUsa0NBQWtDLENBQUM7SUFDM0QsQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPckIsY0FBYztBQUN6QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7O0FDdmtCRCxTQUFTbk8sT0FBT0EsQ0FBQ2pXLENBQUMsRUFBRTtFQUNoQix5QkFBeUI7O0VBQ3pCLE9BQU9pVyxPQUFPLEdBQUcsVUFBVSxJQUFJLE9BQU96VixNQUFNLElBQUksUUFBUSxJQUFJLE9BQU9BLE1BQU0sQ0FBQzBWLFFBQVEsR0FBRyxVQUFVbFcsQ0FBQyxFQUFFO0lBQUUsT0FBTyxPQUFPQSxDQUFDO0VBQUUsQ0FBQyxHQUFHLFVBQVVBLENBQUMsRUFBRTtJQUFFLE9BQU9BLENBQUMsSUFBSSxVQUFVLElBQUksT0FBT1EsTUFBTSxJQUFJUixDQUFDLENBQUMwTSxXQUFXLEtBQUtsTSxNQUFNLElBQUlSLENBQUMsS0FBS1EsTUFBTSxDQUFDTyxTQUFTLEdBQUcsUUFBUSxHQUFHLE9BQU9mLENBQUM7RUFBRSxDQUFDLEVBQUVpVyxPQUFPLENBQUNqVyxDQUFDLENBQUM7QUFDOVE7QUFDQSxTQUFTbVcsZUFBZUEsQ0FBQ2xYLENBQUMsRUFBRUwsQ0FBQyxFQUFFO0VBQUUsSUFBSSxFQUFFSyxDQUFDLFlBQVlMLENBQUMsQ0FBQyxFQUNsRCxNQUFNLElBQUl5RCxTQUFTLENBQUMsbUNBQW1DLENBQUM7QUFBRTtBQUM5RCxTQUFTK1QsaUJBQWlCQSxDQUFDNVksQ0FBQyxFQUFFc0MsQ0FBQyxFQUFFO0VBQUUsS0FBSyxJQUFJcEMsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHb0MsQ0FBQyxDQUFDcFQsTUFBTSxFQUFFZ1IsQ0FBQyxFQUFFLEVBQUU7SUFDbEUsSUFBSXNDLENBQUMsR0FBR0YsQ0FBQyxDQUFDcEMsQ0FBQyxDQUFDO0lBQ1pzQyxDQUFDLENBQUNPLFVBQVUsR0FBR1AsQ0FBQyxDQUFDTyxVQUFVLElBQUksQ0FBQyxDQUFDLEVBQUVQLENBQUMsQ0FBQ21DLFlBQVksR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLElBQUluQyxDQUFDLEtBQUtBLENBQUMsQ0FBQzRMLFFBQVEsR0FBRyxDQUFDLENBQUMsQ0FBQyxFQUFFdFQsTUFBTSxDQUFDZ0ksY0FBYyxDQUFDOUMsQ0FBQyxFQUFFNlksY0FBYyxDQUFDclcsQ0FBQyxDQUFDMkwsR0FBRyxDQUFDLEVBQUUzTCxDQUFDLENBQUM7RUFDako7QUFBRTtBQUNGLFNBQVNzVyxZQUFZQSxDQUFDOVksQ0FBQyxFQUFFc0MsQ0FBQyxFQUFFcEMsQ0FBQyxFQUFFO0VBQUUsT0FBT29DLENBQUMsSUFBSXNXLGlCQUFpQixDQUFDNVksQ0FBQyxDQUFDdUQsU0FBUyxFQUFFakIsQ0FBQyxDQUFDLEVBQUVwQyxDQUFDLElBQUkwWSxpQkFBaUIsQ0FBQzVZLENBQUMsRUFBRUUsQ0FBQyxDQUFDLEVBQUVwRixNQUFNLENBQUNnSSxjQUFjLENBQUM5QyxDQUFDLEVBQUUsV0FBVyxFQUFFO0lBQUVvTyxRQUFRLEVBQUUsQ0FBQztFQUFFLENBQUMsQ0FBQyxFQUFFcE8sQ0FBQztBQUFFO0FBQzFLLFNBQVM2WSxjQUFjQSxDQUFDM1ksQ0FBQyxFQUFFO0VBQUUsSUFBSXdCLENBQUMsR0FBR3FYLFlBQVksQ0FBQzdZLENBQUMsRUFBRSxRQUFRLENBQUM7RUFBRSxPQUFPLFFBQVEsSUFBSXVZLE9BQU8sQ0FBQy9XLENBQUMsQ0FBQyxHQUFHQSxDQUFDLEdBQUdBLENBQUMsR0FBRyxFQUFFO0FBQUU7QUFDNUcsU0FBU3FYLFlBQVlBLENBQUM3WSxDQUFDLEVBQUVvQyxDQUFDLEVBQUU7RUFBRSxJQUFJLFFBQVEsSUFBSW1XLE9BQU8sQ0FBQ3ZZLENBQUMsQ0FBQyxJQUFJLENBQUNBLENBQUMsRUFDMUQsT0FBT0EsQ0FBQztFQUFFLElBQUlGLENBQUMsR0FBR0UsQ0FBQyxDQUFDOEMsTUFBTSxDQUFDZ1csV0FBVyxDQUFDO0VBQUUsSUFBSSxLQUFLLENBQUMsS0FBS2haLENBQUMsRUFBRTtJQUMzRCxJQUFJMEIsQ0FBQyxHQUFHMUIsQ0FBQyxDQUFDclMsSUFBSSxDQUFDdVMsQ0FBQyxFQUFFb0MsQ0FBQyxJQUFJLFNBQVMsQ0FBQztJQUNqQyxJQUFJLFFBQVEsSUFBSW1XLE9BQU8sQ0FBQy9XLENBQUMsQ0FBQyxFQUN0QixPQUFPQSxDQUFDO0lBQ1osTUFBTSxJQUFJbUQsU0FBUyxDQUFDLDhDQUE4QyxDQUFDO0VBQ3ZFO0VBQUUsT0FBTyxDQUFDLFFBQVEsS0FBS3ZDLENBQUMsR0FBRzJDLE1BQU0sR0FBR3FQLE1BQU0sRUFBRXBVLENBQUMsQ0FBQztBQUFFO0FBQ2hELFNBQVNnb0IsVUFBVUEsQ0FBQ2hvQixDQUFDLEVBQUVzQyxDQUFDLEVBQUV4QyxDQUFDLEVBQUU7RUFBRSxPQUFPd0MsQ0FBQyxHQUFHMmxCLGVBQWUsQ0FBQzNsQixDQUFDLENBQUMsRUFBRTRsQiwwQkFBMEIsQ0FBQ2xvQixDQUFDLEVBQUVtb0IseUJBQXlCLENBQUMsQ0FBQyxHQUFHMVUsT0FBTyxDQUFDMlUsU0FBUyxDQUFDOWxCLENBQUMsRUFBRXhDLENBQUMsSUFBSSxFQUFFLEVBQUVtb0IsZUFBZSxDQUFDam9CLENBQUMsQ0FBQyxDQUFDZ1AsV0FBVyxDQUFDLEdBQUcxTSxDQUFDLENBQUN6VyxLQUFLLENBQUNtVSxDQUFDLEVBQUVGLENBQUMsQ0FBQyxDQUFDO0FBQUU7QUFDMU0sU0FBU29vQiwwQkFBMEJBLENBQUNsb0IsQ0FBQyxFQUFFRixDQUFDLEVBQUU7RUFBRSxJQUFJQSxDQUFDLEtBQUssUUFBUSxJQUFJeVksT0FBTyxDQUFDelksQ0FBQyxDQUFDLElBQUksVUFBVSxJQUFJLE9BQU9BLENBQUMsQ0FBQyxFQUNuRyxPQUFPQSxDQUFDO0VBQUUsSUFBSSxLQUFLLENBQUMsS0FBS0EsQ0FBQyxFQUMxQixNQUFNLElBQUk2RSxTQUFTLENBQUMsMERBQTBELENBQUM7RUFBRSxPQUFPMGpCLHNCQUFzQixDQUFDcm9CLENBQUMsQ0FBQztBQUFFO0FBQ3ZILFNBQVNxb0Isc0JBQXNCQSxDQUFDdm9CLENBQUMsRUFBRTtFQUFFLElBQUksS0FBSyxDQUFDLEtBQUtBLENBQUMsRUFDakQsTUFBTSxJQUFJd29CLGNBQWMsQ0FBQywyREFBMkQsQ0FBQztFQUFFLE9BQU94b0IsQ0FBQztBQUFFO0FBQ3JHLFNBQVN5b0IsU0FBU0EsQ0FBQ3ZvQixDQUFDLEVBQUVGLENBQUMsRUFBRTtFQUFFLElBQUksVUFBVSxJQUFJLE9BQU9BLENBQUMsSUFBSSxJQUFJLEtBQUtBLENBQUMsRUFDL0QsTUFBTSxJQUFJNkUsU0FBUyxDQUFDLG9EQUFvRCxDQUFDO0VBQUUzRSxDQUFDLENBQUNxRCxTQUFTLEdBQUd6SSxNQUFNLENBQUNxSSxNQUFNLENBQUNuRCxDQUFDLElBQUlBLENBQUMsQ0FBQ3VELFNBQVMsRUFBRTtJQUFFMkwsV0FBVyxFQUFFO01BQUV0YSxLQUFLLEVBQUVzTCxDQUFDO01BQUVrTyxRQUFRLEVBQUUsQ0FBQyxDQUFDO01BQUV6SixZQUFZLEVBQUUsQ0FBQztJQUFFO0VBQUUsQ0FBQyxDQUFDLEVBQUU3SixNQUFNLENBQUNnSSxjQUFjLENBQUM1QyxDQUFDLEVBQUUsV0FBVyxFQUFFO0lBQUVrTyxRQUFRLEVBQUUsQ0FBQztFQUFFLENBQUMsQ0FBQyxFQUFFcE8sQ0FBQyxJQUFJMG9CLGVBQWUsQ0FBQ3hvQixDQUFDLEVBQUVGLENBQUMsQ0FBQztBQUFFO0FBQ2xSLFNBQVMyb0IsZ0JBQWdCQSxDQUFDem9CLENBQUMsRUFBRTtFQUFFLElBQUlvQyxDQUFDLEdBQUcsVUFBVSxJQUFJLE9BQU96TSxHQUFHLEdBQUcsSUFBSUEsR0FBRyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7RUFBRSxPQUFPOHlCLGdCQUFnQixHQUFHLFNBQVNBLGdCQUFnQkEsQ0FBQ3pvQixDQUFDLEVBQUU7SUFBRSxJQUFJLElBQUksS0FBS0EsQ0FBQyxJQUFJLENBQUMwb0IsaUJBQWlCLENBQUMxb0IsQ0FBQyxDQUFDLEVBQ2xMLE9BQU9BLENBQUM7SUFBRSxJQUFJLFVBQVUsSUFBSSxPQUFPQSxDQUFDLEVBQ3BDLE1BQU0sSUFBSTJFLFNBQVMsQ0FBQyxvREFBb0QsQ0FBQztJQUFFLElBQUksS0FBSyxDQUFDLEtBQUt2QyxDQUFDLEVBQUU7TUFDN0YsSUFBSUEsQ0FBQyxDQUFDa0ssR0FBRyxDQUFDdE0sQ0FBQyxDQUFDLEVBQ1IsT0FBT29DLENBQUMsQ0FBQ3hLLEdBQUcsQ0FBQ29JLENBQUMsQ0FBQztNQUNuQm9DLENBQUMsQ0FBQytILEdBQUcsQ0FBQ25LLENBQUMsRUFBRTJvQixPQUFPLENBQUM7SUFDckI7SUFBRSxTQUFTQSxPQUFPQSxDQUFBLEVBQUc7TUFBRSxPQUFPQyxVQUFVLENBQUM1b0IsQ0FBQyxFQUFFbFUsU0FBUyxFQUFFbThCLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQ2paLFdBQVcsQ0FBQztJQUFFO0lBQUUsT0FBTzJaLE9BQU8sQ0FBQ3RsQixTQUFTLEdBQUd6SSxNQUFNLENBQUNxSSxNQUFNLENBQUNqRCxDQUFDLENBQUNxRCxTQUFTLEVBQUU7TUFBRTJMLFdBQVcsRUFBRTtRQUFFdGEsS0FBSyxFQUFFaTBCLE9BQU87UUFBRTlsQixVQUFVLEVBQUUsQ0FBQyxDQUFDO1FBQUVxTCxRQUFRLEVBQUUsQ0FBQyxDQUFDO1FBQUV6SixZQUFZLEVBQUUsQ0FBQztNQUFFO0lBQUUsQ0FBQyxDQUFDLEVBQUUrakIsZUFBZSxDQUFDRyxPQUFPLEVBQUUzb0IsQ0FBQyxDQUFDO0VBQUUsQ0FBQyxFQUFFeW9CLGdCQUFnQixDQUFDem9CLENBQUMsQ0FBQztBQUFFO0FBQzlSLFNBQVM0b0IsVUFBVUEsQ0FBQzVvQixDQUFDLEVBQUVGLENBQUMsRUFBRXNDLENBQUMsRUFBRTtFQUFFLElBQUkrbEIseUJBQXlCLENBQUMsQ0FBQyxFQUMxRCxPQUFPMVUsT0FBTyxDQUFDMlUsU0FBUyxDQUFDdjhCLEtBQUssQ0FBQyxJQUFJLEVBQUVDLFNBQVMsQ0FBQztFQUFFLElBQUl3VyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7RUFBRUEsQ0FBQyxDQUFDOUcsSUFBSSxDQUFDM1AsS0FBSyxDQUFDeVcsQ0FBQyxFQUFFeEMsQ0FBQyxDQUFDO0VBQUUsSUFBSVEsQ0FBQyxHQUFHLEtBQUtOLENBQUMsQ0FBQ21ELElBQUksQ0FBQ3RYLEtBQUssQ0FBQ21VLENBQUMsRUFBRXNDLENBQUMsQ0FBQyxFQUFFLENBQUM7RUFBRSxPQUFPRixDQUFDLElBQUlvbUIsZUFBZSxDQUFDbG9CLENBQUMsRUFBRThCLENBQUMsQ0FBQ2lCLFNBQVMsQ0FBQyxFQUFFL0MsQ0FBQztBQUFFO0FBQzdLLFNBQVM2bkIseUJBQXlCQSxDQUFBLEVBQUc7RUFBRSxJQUFJO0lBQ3ZDLElBQUlub0IsQ0FBQyxHQUFHLENBQUNoRixPQUFPLENBQUNxSSxTQUFTLENBQUMyQixPQUFPLENBQUN2WCxJQUFJLENBQUNnbUIsT0FBTyxDQUFDMlUsU0FBUyxDQUFDcHRCLE9BQU8sRUFBRSxFQUFFLEVBQUUsWUFBWSxDQUFFLENBQUMsQ0FBQyxDQUFDO0VBQzVGLENBQUMsQ0FDRCxPQUFPZ0YsQ0FBQyxFQUFFLENBQUU7RUFBRSxPQUFPLENBQUNtb0IseUJBQXlCLEdBQUcsU0FBU0EseUJBQXlCQSxDQUFBLEVBQUc7SUFBRSxPQUFPLENBQUMsQ0FBQ25vQixDQUFDO0VBQUUsQ0FBQyxFQUFFLENBQUM7QUFBRTtBQUMzRyxTQUFTMG9CLGlCQUFpQkEsQ0FBQzFvQixDQUFDLEVBQUU7RUFBRSxJQUFJO0lBQ2hDLE9BQU8sQ0FBQyxDQUFDLEtBQUt1RSxRQUFRLENBQUNyRyxRQUFRLENBQUN6USxJQUFJLENBQUN1UyxDQUFDLENBQUMsQ0FBQ3VTLE9BQU8sQ0FBQyxlQUFlLENBQUM7RUFDcEUsQ0FBQyxDQUNELE9BQU9yUixDQUFDLEVBQUU7SUFDTixPQUFPLFVBQVUsSUFBSSxPQUFPbEIsQ0FBQztFQUNqQztBQUFFO0FBQ0YsU0FBU3dvQixlQUFlQSxDQUFDeG9CLENBQUMsRUFBRUYsQ0FBQyxFQUFFO0VBQUUsT0FBTzBvQixlQUFlLEdBQUc1dEIsTUFBTSxDQUFDaXVCLGNBQWMsR0FBR2p1QixNQUFNLENBQUNpdUIsY0FBYyxDQUFDMWxCLElBQUksQ0FBQyxDQUFDLEdBQUcsVUFBVW5ELENBQUMsRUFBRUYsQ0FBQyxFQUFFO0lBQUUsT0FBT0UsQ0FBQyxDQUFDOG9CLFNBQVMsR0FBR2hwQixDQUFDLEVBQUVFLENBQUM7RUFBRSxDQUFDLEVBQUV3b0IsZUFBZSxDQUFDeG9CLENBQUMsRUFBRUYsQ0FBQyxDQUFDO0FBQUU7QUFDeEwsU0FBU21vQixlQUFlQSxDQUFDam9CLENBQUMsRUFBRTtFQUFFLE9BQU9pb0IsZUFBZSxHQUFHcnRCLE1BQU0sQ0FBQ2l1QixjQUFjLEdBQUdqdUIsTUFBTSxDQUFDd1EsY0FBYyxDQUFDakksSUFBSSxDQUFDLENBQUMsR0FBRyxVQUFVbkQsQ0FBQyxFQUFFO0lBQUUsT0FBT0EsQ0FBQyxDQUFDOG9CLFNBQVMsSUFBSWx1QixNQUFNLENBQUN3USxjQUFjLENBQUNwTCxDQUFDLENBQUM7RUFBRSxDQUFDLEVBQUVpb0IsZUFBZSxDQUFDam9CLENBQUMsQ0FBQztBQUFFO0FBQ3BNLFNBQVMrb0IsMkJBQTJCQSxDQUFDanBCLENBQUMsRUFBRXlCLENBQUMsRUFBRTtFQUFFeW5CLDBCQUEwQixDQUFDbHBCLENBQUMsRUFBRXlCLENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUMwSyxHQUFHLENBQUNuTSxDQUFDLENBQUM7QUFBRTtBQUN6RixTQUFTa3BCLDBCQUEwQkEsQ0FBQ2xwQixDQUFDLEVBQUVFLENBQUMsRUFBRTtFQUFFLElBQUlBLENBQUMsQ0FBQ3NNLEdBQUcsQ0FBQ3hNLENBQUMsQ0FBQyxFQUNwRCxNQUFNLElBQUk2RSxTQUFTLENBQUMsZ0VBQWdFLENBQUM7QUFBRTtBQUMzRixTQUFTc2tCLGlCQUFpQkEsQ0FBQ25wQixDQUFDLEVBQUVFLENBQUMsRUFBRWtCLENBQUMsRUFBRTtFQUFFLElBQUksVUFBVSxJQUFJLE9BQU9wQixDQUFDLEdBQUdBLENBQUMsS0FBS0UsQ0FBQyxHQUFHRixDQUFDLENBQUN3TSxHQUFHLENBQUN0TSxDQUFDLENBQUMsRUFDakYsT0FBT2xVLFNBQVMsQ0FBQ2tELE1BQU0sR0FBRyxDQUFDLEdBQUdnUixDQUFDLEdBQUdrQixDQUFDO0VBQUUsTUFBTSxJQUFJeUQsU0FBUyxDQUFDLCtDQUErQyxDQUFDO0FBQUU7QUFDeEcsU0FBU3VrQixtQkFBbUJBLENBQUEsRUFBRztFQUNsQyxPQUFPLGdCQUFnQixJQUFJcGtCLElBQUksSUFBSSxDQUFDLENBQUNxa0IsV0FBVyxDQUFDOWxCLFNBQVMsQ0FBQytsQixZQUFZO0FBQzNFO0FBQ08sU0FBU0MscUJBQXFCQSxDQUFBLEVBQUc7RUFDcEMsSUFBSUMseUJBQXlCO0VBQzdCLElBQUlDLGNBQWMsQ0FBQzN4QixHQUFHLENBQUMsY0FBYyxDQUFDLEVBQUU7SUFDcEM7RUFDSjtFQUNBLElBQUk0eEIsK0JBQStCLEdBQUcsYUFBYyxJQUFJL2EsT0FBTyxDQUFDLENBQUM7RUFDakUsSUFBSWdiLHdCQUF3QixHQUFHLGFBQWMsVUFBVUMsWUFBWSxFQUFFO0lBQ2pFLFNBQVNELHdCQUF3QkEsQ0FBQSxFQUFHO01BQ2hDLElBQUlFLEtBQUs7TUFDVGxSLGVBQWUsQ0FBQyxJQUFJLEVBQUVnUix3QkFBd0IsQ0FBQztNQUMvQ0UsS0FBSyxHQUFHM0IsVUFBVSxDQUFDLElBQUksRUFBRXlCLHdCQUF3QixDQUFDO01BQ2xEViwyQkFBMkIsQ0FBQ1ksS0FBSyxFQUFFSCwrQkFBK0IsQ0FBQztNQUNuRUcsS0FBSyxDQUFDUCxZQUFZLENBQUM7UUFDZlEsSUFBSSxFQUFFO01BQ1YsQ0FBQyxDQUFDO01BQ0ZELEtBQUssQ0FBQ0UsYUFBYSxHQUFHLENBQUMsa0JBQWtCO01BQ3pDRixLQUFLLENBQUNHLGNBQWMsR0FBRyxJQUFJO01BQzNCLE9BQU9ILEtBQUs7SUFDaEI7SUFDQXBCLFNBQVMsQ0FBQ2tCLHdCQUF3QixFQUFFQyxZQUFZLENBQUM7SUFDakQsT0FBTzlRLFlBQVksQ0FBQzZRLHdCQUF3QixFQUFFLENBQUM7TUFDdkN4YixHQUFHLEVBQUUsbUJBQW1CO01BQ3hCdlosS0FBSyxFQUFFLFNBQVNxMUIsaUJBQWlCQSxDQUFBLEVBQUc7UUFDaENkLGlCQUFpQixDQUFDTywrQkFBK0IsRUFBRSxJQUFJLEVBQUVRLE1BQU0sQ0FBQyxDQUFDdjhCLElBQUksQ0FBQyxJQUFJLENBQUM7TUFDL0U7SUFDSixDQUFDLEVBQUU7TUFDQ3dnQixHQUFHLEVBQUUsMEJBQTBCO01BQy9CdlosS0FBSyxFQUFFLFNBQVN1MUIsd0JBQXdCQSxDQUFDeHpCLElBQUksRUFBRXl6QixRQUFRLEVBQUVDLFFBQVEsRUFBRTtRQUMvRCxJQUFJMXpCLElBQUksS0FBSyxVQUFVLEVBQUU7VUFDckJ3eUIsaUJBQWlCLENBQUNPLCtCQUErQixFQUFFLElBQUksRUFBRVksT0FBTyxDQUFDLENBQUMzOEIsSUFBSSxDQUFDLElBQUksRUFBRTJtQixNQUFNLENBQUMrVixRQUFRLENBQUMsQ0FBQztRQUNsRyxDQUFDLE1BQ0ksSUFBSTF6QixJQUFJLEtBQUssTUFBTSxFQUFFO1VBQ3RCd3lCLGlCQUFpQixDQUFDTywrQkFBK0IsRUFBRSxJQUFJLEVBQUVRLE1BQU0sQ0FBQyxDQUFDdjhCLElBQUksQ0FBQyxJQUFJLENBQUM7UUFDL0U7TUFDSjtJQUNKLENBQUMsQ0FBQyxFQUFFLENBQUM7TUFDRHdnQixHQUFHLEVBQUUsb0JBQW9CO01BQ3pCclcsR0FBRyxFQUFFLFNBQVNBLEdBQUdBLENBQUEsRUFBRztRQUNoQixPQUFPLENBQUMsVUFBVSxFQUFFLE1BQU0sQ0FBQztNQUMvQjtJQUNKLENBQUMsQ0FBQyxDQUFDO0VBQ1gsQ0FBQyxDQUFDLGFBQWM2d0IsZ0JBQWdCLENBQUNVLFdBQVcsQ0FBQyxDQUFDO0VBQzlDRyx5QkFBeUIsR0FBR0csd0JBQXdCO0VBQ3BELFNBQVNPLE1BQU1BLENBQUEsRUFBRztJQUNkLElBQUlLLGtCQUFrQixFQUFFQyxPQUFPO0lBQy9CQyxZQUFZLENBQUMsSUFBSSxDQUFDVCxjQUFjLENBQUM7SUFDakMsSUFBSSxDQUFDQSxjQUFjLEdBQUcsSUFBSTtJQUMxQixJQUFJVSxRQUFRLEdBQUcsQ0FBQ0gsa0JBQWtCLEdBQUcsSUFBSSxDQUFDSSxZQUFZLENBQUMsTUFBTSxDQUFDLE1BQU0sSUFBSSxJQUFJSixrQkFBa0IsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBR0Esa0JBQWtCLENBQUNLLFdBQVcsQ0FBQyxDQUFDO0lBQ3JKLElBQUksQ0FBQ3RWLElBQUksR0FBR29WLFFBQVEsS0FBSyxVQUFVLEdBQUcsVUFBVSxHQUFHLFFBQVE7SUFDM0QsSUFBSTNELFNBQVMsR0FBRyxJQUFJLENBQUN6UixJQUFJLEtBQUssVUFBVSxHQUFHdVYsaUJBQWlCLENBQUNsOUIsSUFBSSxDQUFDNjdCLHlCQUF5QixDQUFDLEdBQUdzQixlQUFlLENBQUNuOUIsSUFBSSxDQUFDNjdCLHlCQUF5QixDQUFDO0lBQzlJLElBQUksQ0FBQ3VCLFVBQVUsQ0FBQ2hFLFNBQVMsR0FBR0EsU0FBUztJQUNyQyxJQUFJLENBQUNpRSxlQUFlLEdBQUcsQ0FBQ1IsT0FBTyxHQUFHbFcsTUFBTSxDQUFDLElBQUksQ0FBQ3FXLFlBQVksQ0FBQyxVQUFVLENBQUMsQ0FBQyxNQUFNLElBQUksSUFBSUgsT0FBTyxLQUFLLEtBQUssQ0FBQyxHQUFHQSxPQUFPLEdBQUcsQ0FBQztJQUNySHJCLGlCQUFpQixDQUFDTywrQkFBK0IsRUFBRSxJQUFJLEVBQUVZLE9BQU8sQ0FBQyxDQUFDMzhCLElBQUksQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDcTlCLGVBQWUsQ0FBQztFQUN0RztFQUNBLFNBQVNILGlCQUFpQkEsQ0FBQSxFQUFHO0lBQ3pCLE9BQU8seXNEQUF5c0Q7RUFDcHREO0VBQ0EsU0FBU0MsZUFBZUEsQ0FBQSxFQUFHO0lBQ3ZCLE9BQU8sOHNCQUE4c0I7RUFDenRCO0VBQ0EsU0FBU1IsT0FBT0EsQ0FBQ1csT0FBTyxFQUFFO0lBQ3RCLElBQUlqRixPQUFPLEdBQUcsSUFBSSxDQUFDK0UsVUFBVSxDQUFDRyxhQUFhLENBQUMsV0FBVyxDQUFDO0lBQ3hELElBQUksSUFBSSxDQUFDNVYsSUFBSSxLQUFLLFVBQVUsRUFBRTtNQUMxQixJQUFJbEssSUFBSSxHQUFHLElBQUksQ0FBQzJmLFVBQVUsQ0FBQ0csYUFBYSxDQUFDLE1BQU0sQ0FBQztNQUNoRCxJQUFJdDJCLEtBQUssR0FBRyxJQUFJLENBQUNtMkIsVUFBVSxDQUFDRyxhQUFhLENBQUMsZ0JBQWdCLENBQUM7TUFDM0QsSUFBSUMsTUFBTSxHQUFHLENBQUMsR0FBRyxHQUFHRixPQUFPLElBQUksR0FBRyxHQUFHLElBQUksQ0FBQ2xCLGFBQWE7TUFDdkQzZSxJQUFJLENBQUNqTCxLQUFLLENBQUNpckIsZ0JBQWdCLEdBQUdELE1BQU07TUFDcEN2MkIsS0FBSyxDQUFDeTJCLFdBQVcsR0FBR0osT0FBTztJQUMvQixDQUFDLE1BQ0k7TUFDRGpGLE9BQU8sQ0FBQzdsQixLQUFLLENBQUM2akIsS0FBSyxHQUFHLEVBQUUsQ0FBQzM0QixNQUFNLENBQUM0L0IsT0FBTyxFQUFFLEdBQUcsQ0FBQztJQUNqRDtJQUNBLElBQUlBLE9BQU8sSUFBSSxHQUFHLEVBQUU7TUFDaEI5QixpQkFBaUIsQ0FBQ08sK0JBQStCLEVBQUUsSUFBSSxFQUFFNEIsS0FBSyxDQUFDLENBQUMzOUIsSUFBSSxDQUFDLElBQUksQ0FBQztJQUM5RSxDQUFDLE1BQ0ksSUFBSXM5QixPQUFPLEdBQUcsQ0FBQyxFQUFFO01BQ2xCOUIsaUJBQWlCLENBQUNPLCtCQUErQixFQUFFLElBQUksRUFBRTZCLEtBQUssQ0FBQyxDQUFDNTlCLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDOUU7RUFDSjtFQUNBLFNBQVM0OUIsS0FBS0EsQ0FBQSxFQUFHO0lBQ2IsSUFBSXZGLE9BQU8sR0FBRyxJQUFJLENBQUMrRSxVQUFVLENBQUNHLGFBQWEsQ0FBQyxXQUFXLENBQUM7SUFDeERsRixPQUFPLENBQUN3RixTQUFTLENBQUM5akIsTUFBTSxDQUFDLFFBQVEsQ0FBQztFQUN0QztFQUNBLFNBQVM0akIsS0FBS0EsQ0FBQSxFQUFHO0lBQ2IsSUFBSUcsTUFBTSxHQUFHLElBQUk7SUFDakIsSUFBSXpGLE9BQU8sR0FBRyxJQUFJLENBQUMrRSxVQUFVLENBQUNHLGFBQWEsQ0FBQyxXQUFXLENBQUM7SUFDeEQsSUFBSSxJQUFJLENBQUM1VixJQUFJLEtBQUssVUFBVSxFQUFFO01BQzFCMFEsT0FBTyxDQUFDd0YsU0FBUyxDQUFDcmYsR0FBRyxDQUFDLFdBQVcsQ0FBQztNQUNsQzZaLE9BQU8sQ0FBQzNtQixnQkFBZ0IsQ0FBQyxjQUFjLEVBQUUsWUFBWTtRQUNqRDJtQixPQUFPLENBQUN3RixTQUFTLENBQUNyZixHQUFHLENBQUMsUUFBUSxDQUFDO1FBQy9CZ2QsaUJBQWlCLENBQUNPLCtCQUErQixFQUFFK0IsTUFBTSxFQUFFbkIsT0FBTyxDQUFDLENBQUMzOEIsSUFBSSxDQUFDODlCLE1BQU0sRUFBRSxDQUFDLENBQUM7TUFDdkYsQ0FBQyxFQUFFO1FBQ0NoWCxJQUFJLEVBQUU7TUFDVixDQUFDLENBQUM7SUFDTixDQUFDLE1BQ0ksSUFBSSxJQUFJLENBQUNhLElBQUksS0FBSyxRQUFRLEVBQUU7TUFDN0IwUSxPQUFPLENBQUN3RixTQUFTLENBQUNyZixHQUFHLENBQUMsV0FBVyxDQUFDO01BQ2xDLElBQUksQ0FBQzZkLGNBQWMsR0FBRy9yQixVQUFVLENBQUMsWUFBWTtRQUN6QytuQixPQUFPLENBQUN3RixTQUFTLENBQUM5akIsTUFBTSxDQUFDLFdBQVcsQ0FBQztRQUNyQ3NlLE9BQU8sQ0FBQ3dGLFNBQVMsQ0FBQ3JmLEdBQUcsQ0FBQyxRQUFRLENBQUM7UUFDL0I2WixPQUFPLENBQUM3bEIsS0FBSyxDQUFDNmpCLEtBQUssR0FBRyxJQUFJO1FBQzFCeUgsTUFBTSxDQUFDekIsY0FBYyxHQUFHLElBQUk7TUFDaEMsQ0FBQyxFQUFFLEdBQUcsQ0FBQztJQUNYO0VBQ0o7RUFDQVAsY0FBYyxDQUFDaUMsTUFBTSxDQUFDLGNBQWMsRUFBRS9CLHdCQUF3QixDQUFDO0FBQ25FLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xLQTtBQUMyRDtBQUN0QjtBQUNyQztBQUNBO0FBQ0EsSUFBSWdDLE1BQU07QUFDVjtBQUNBLE9BQU9DLDZCQUE2QixLQUFLLFdBQVcsR0FBRyxPQUFPQSw2QkFBNkIsQ0FBQ3RvQixPQUFPLEtBQUssV0FBVyxHQUFHc29CLDZCQUE2QixDQUFDdG9CLE9BQU8sR0FBR3NvQiw2QkFBNkIsR0FBRzNTLG1FQUFlO0FBQzdNO0FBQ0EsSUFBSTRTLE9BQU8sR0FBRyxDQUFDO0FBQ2YsSUFBSUMsVUFBVSxHQUFHLEVBQUU7QUFDbkI7QUFDQTtBQUNBO0FBQ08sSUFBSTVTLE1BQU0sR0FBRyxJQUFJO0FBQ3hCLElBQUlqUixPQUFPO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk4akIsTUFBTSxHQUFHLFNBQVNDLFVBQVVBLENBQUNwMUIsR0FBRyxFQUFFcTFCLFFBQVEsRUFBRUMsU0FBUyxFQUFFO0VBQ3ZEaFQsTUFBTSxHQUFHLElBQUl5UyxNQUFNLENBQUMvMEIsR0FBRyxDQUFDO0VBQ3hCc2lCLE1BQU0sQ0FBQ0csTUFBTSxDQUFDLFlBQVk7SUFDdEJ3UyxPQUFPLEdBQUcsQ0FBQztJQUNYLElBQUk1akIsT0FBTyxFQUFFO01BQ1R3aUIsWUFBWSxDQUFDeGlCLE9BQU8sQ0FBQztJQUN6QjtJQUNBLElBQUksT0FBT2lrQixTQUFTLEtBQUssV0FBVyxFQUFFO01BQ2xDSixVQUFVLEdBQUdJLFNBQVM7SUFDMUI7RUFDSixDQUFDLENBQUM7RUFDRmhULE1BQU0sQ0FBQ0ssT0FBTyxDQUFDLFlBQVk7SUFDdkIsSUFBSXNTLE9BQU8sS0FBSyxDQUFDLEVBQUU7TUFDZkksUUFBUSxDQUFDM1ksS0FBSyxDQUFDLENBQUM7SUFDcEI7SUFDQTtJQUNBNEYsTUFBTSxHQUFHLElBQUk7SUFDYjtJQUNBLElBQUkyUyxPQUFPLEdBQUdDLFVBQVUsRUFBRTtNQUN0QjtNQUNBO01BQ0E7TUFDQSxJQUFJSyxTQUFTLEdBQUcsSUFBSSxHQUFHcm5CLElBQUksQ0FBQ3NuQixHQUFHLENBQUMsQ0FBQyxFQUFFUCxPQUFPLENBQUMsR0FBRy9tQixJQUFJLENBQUN1bkIsTUFBTSxDQUFDLENBQUMsR0FBRyxHQUFHO01BQ2pFUixPQUFPLElBQUksQ0FBQztNQUNaLzdCLDhDQUFHLENBQUM0cUIsSUFBSSxDQUFDLHdCQUF3QixDQUFDO01BQ2xDelMsT0FBTyxHQUFHaEssVUFBVSxDQUFDLFlBQVk7UUFDN0I4dEIsTUFBTSxDQUFDbjFCLEdBQUcsRUFBRXExQixRQUFRLEVBQUVDLFNBQVMsQ0FBQztNQUNwQyxDQUFDLEVBQUVDLFNBQVMsQ0FBQztJQUNqQjtFQUNKLENBQUMsQ0FBQztFQUNGalQsTUFBTSxDQUFDTyxTQUFTO0VBQ2hCO0FBQ0o7QUFDQTtFQUNJLFVBQVV0aUIsSUFBSSxFQUFFO0lBQ1osSUFBSXNlLE9BQU8sR0FBRzNjLElBQUksQ0FBQ0MsS0FBSyxDQUFDNUIsSUFBSSxDQUFDO0lBQzlCLElBQUk4MEIsUUFBUSxDQUFDeFcsT0FBTyxDQUFDSCxJQUFJLENBQUMsRUFBRTtNQUN4QjJXLFFBQVEsQ0FBQ3hXLE9BQU8sQ0FBQ0gsSUFBSSxDQUFDLENBQUNHLE9BQU8sQ0FBQ3RlLElBQUksRUFBRXNlLE9BQU8sQ0FBQzZXLE1BQU0sQ0FBQztJQUN4RDtFQUNKLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxpRUFBZVAsTUFBTSxFOzs7Ozs7Ozs7Ozs7Ozs7OztBQzlEMkI7QUFDaEQsSUFBSXAxQixJQUFJLEdBQUcsb0JBQW9CO0FBQy9CO0FBQ0E7QUFDQSxJQUFJNDFCLFlBQVksR0FBRyxNQUFNO0FBQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTQyxXQUFXQSxDQUFDak8sS0FBSyxFQUFFO0VBQ3hCcFIsc0ZBQTZCLENBQUM7SUFDMUJvUixLQUFLLEVBQUVBO0VBQ1gsQ0FBQyxDQUFDO0FBQ047QUFDQWlPLFdBQVcsQ0FBQ0QsWUFBWSxDQUFDO0FBQ3pCLElBQUl6OEIsR0FBRyxHQUFHcWQseUVBQWdCLENBQUN4VyxJQUFJLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ2hCaEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzgxQixPQUFPQSxDQUFDblgsSUFBSSxFQUFFbmUsSUFBSSxFQUFFO0VBQ3pCLElBQUksT0FBTzZOLElBQUksS0FBSyxXQUFXLEtBQUssT0FBTzBuQixpQkFBaUIsS0FBSyxXQUFXLElBQUksRUFBRTFuQixJQUFJLFlBQVkwbkIsaUJBQWlCLENBQUMsQ0FBQyxFQUFFO0lBQ25IMW5CLElBQUksQ0FBQzNDLFdBQVcsQ0FBQztNQUNiaVQsSUFBSSxFQUFFLFNBQVMsQ0FBQ2pxQixNQUFNLENBQUNpcUIsSUFBSSxDQUFDO01BQzVCbmUsSUFBSSxFQUFFQTtJQUNWLENBQUMsRUFBRSxHQUFHLENBQUM7RUFDWDtBQUNKO0FBQ0EsaUVBQWVzMUIsT0FBTyxFOzs7Ozs7Ozs7O0FDZFQ7O0FBQ2IsSUFBSWpZLFlBQVksR0FBR21ZLG1CQUFPLENBQUMsZ0ZBQVEsQ0FBQztBQUNwQ3hiLE1BQU0sQ0FBQzVPLE9BQU8sR0FBRyxJQUFJaVMsWUFBWSxDQUFDLENBQUMsQzs7Ozs7Ozs7OztBQ0Z0Qjs7QUFDYjtBQUNBO0FBQ0EsSUFBSW9ZLFFBQVEsR0FBRyxNQUFNO0FBQ3JCLFNBQVNDLEtBQUtBLENBQUEsRUFBRyxDQUFFO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsU0FBU0EsQ0FBQ3ZPLEtBQUssRUFBRTtFQUN0QixJQUFJdU8sU0FBUyxHQUFJRixRQUFRLEtBQUssTUFBTSxJQUFJck8sS0FBSyxLQUFLLE1BQU0sSUFDbkQsQ0FBQyxNQUFNLEVBQUUsU0FBUyxDQUFDLENBQUM5TCxPQUFPLENBQUNtYSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUlyTyxLQUFLLEtBQUssU0FBVSxJQUNsRSxDQUFDLE1BQU0sRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM5TCxPQUFPLENBQUNtYSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUlyTyxLQUFLLEtBQUssT0FBUTtFQUM5RSxPQUFPdU8sU0FBUztBQUNwQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsUUFBUUEsQ0FBQ0MsS0FBSyxFQUFFO0VBQ3JCLE9BQU8sVUFBVXpPLEtBQUssRUFBRXZRLEdBQUcsRUFBRTtJQUN6QixJQUFJOGUsU0FBUyxDQUFDdk8sS0FBSyxDQUFDLEVBQUU7TUFDbEJ5TyxLQUFLLENBQUNoZixHQUFHLENBQUM7SUFDZDtFQUNKLENBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FtRCxNQUFNLENBQUM1TyxPQUFPLEdBQUcsVUFBVWdjLEtBQUssRUFBRXZRLEdBQUcsRUFBRTtFQUNuQyxJQUFJOGUsU0FBUyxDQUFDdk8sS0FBSyxDQUFDLEVBQUU7SUFDbEIsSUFBSUEsS0FBSyxLQUFLLE1BQU0sRUFBRTtNQUNsQjV1QixPQUFPLENBQUNHLEdBQUcsQ0FBQ2tlLEdBQUcsQ0FBQztJQUNwQixDQUFDLE1BQ0ksSUFBSXVRLEtBQUssS0FBSyxTQUFTLEVBQUU7TUFDMUI1dUIsT0FBTyxDQUFDQyxJQUFJLENBQUNvZSxHQUFHLENBQUM7SUFDckIsQ0FBQyxNQUNJLElBQUl1USxLQUFLLEtBQUssT0FBTyxFQUFFO01BQ3hCNXVCLE9BQU8sQ0FBQzZQLEtBQUssQ0FBQ3dPLEdBQUcsQ0FBQztJQUN0QjtFQUNKO0FBQ0osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0FtRCwwQkFBMEIsR0FBRyxVQUFVeFMsR0FBRyxFQUFFO0VBQ3hDLElBQUk4VyxPQUFPLEdBQUc5VyxHQUFHLENBQUM4VyxPQUFPO0VBQ3pCLElBQUk0TixLQUFLLEdBQUcxa0IsR0FBRyxDQUFDMGtCLEtBQUs7RUFDckIsSUFBSSxDQUFDQSxLQUFLLEVBQUU7SUFDUixPQUFPNU4sT0FBTztFQUNsQixDQUFDLE1BQ0ksSUFBSTROLEtBQUssQ0FBQzVRLE9BQU8sQ0FBQ2dELE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtJQUNqQyxPQUFPQSxPQUFPLEdBQUcsSUFBSSxHQUFHNE4sS0FBSztFQUNqQztFQUNBLE9BQU9BLEtBQUs7QUFDaEIsQ0FBQztBQUNELElBQUl4SSxLQUFLLEdBQUdsckIsT0FBTyxDQUFDa3JCLEtBQUssSUFBSWdTLEtBQUs7QUFDbEMsSUFBSS9SLGNBQWMsR0FBR25yQixPQUFPLENBQUNtckIsY0FBYyxJQUFJK1IsS0FBSztBQUNwRCxJQUFJOVIsUUFBUSxHQUFHcHJCLE9BQU8sQ0FBQ29yQixRQUFRLElBQUk4UixLQUFLO0FBQ3hDMWIsb0JBQW9CLEdBQUc0YixRQUFRLENBQUNsUyxLQUFLLENBQUM7QUFDdEMxSiw2QkFBNkIsR0FBRzRiLFFBQVEsQ0FBQ2pTLGNBQWMsQ0FBQztBQUN4RDNKLHVCQUF1QixHQUFHNGIsUUFBUSxDQUFDaFMsUUFBUSxDQUFDO0FBQzVDO0FBQ0E7QUFDQTtBQUNBNUosMEJBQTBCLEdBQUcsVUFBVW9OLEtBQUssRUFBRTtFQUMxQ3FPLFFBQVEsR0FBR3JPLEtBQUs7QUFDcEIsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyRXdEO0FBQ1M7QUFDbEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBUzRPLGlCQUFpQkEsQ0FBQ0MsY0FBYyxFQUFFQyxlQUFlLEVBQUU7RUFDeEQsSUFBTUMsUUFBUSxHQUFHQSxDQUFDQyxTQUFTLEVBQUUzNEIsS0FBSyxLQUFLOUUsbURBQUcsQ0FBQyxZQUFZLG1DQUFBekUsTUFBQSxDQUFtQ2tpQyxTQUFTLFNBQUFsaUMsTUFBQSxDQUFNNFosTUFBTSxDQUFDclEsS0FBSyxDQUFDLENBQUUsQ0FBQztFQUN6SCxLQUFLLElBQU0sQ0FBQzI0QixTQUFTLEVBQUUzNEIsS0FBSyxDQUFDLElBQUlrRyxNQUFNLENBQUNpTixPQUFPLENBQUNxbEIsY0FBYyxDQUFDLEVBQUU7SUFDN0QsSUFBSSxDQUFDeDRCLEtBQUssRUFDTjA0QixRQUFRLENBQUNDLFNBQVMsRUFBRTM0QixLQUFLLENBQUM7RUFDbEM7RUFDQSxLQUFLLElBQU0sQ0FBQzI0QixVQUFTLEVBQUUzNEIsTUFBSyxDQUFDLElBQUlrRyxNQUFNLENBQUNpTixPQUFPLENBQUNzbEIsZUFBZSxDQUFDLEVBQUU7SUFDOUQsSUFBSXo0QixNQUFLLEVBQ0wwNEIsUUFBUSxDQUFDQyxVQUFTLEVBQUUzNEIsTUFBSyxDQUFDO0VBQ2xDO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNNDRCLG1CQUFtQixHQUFHLFFBQVE7QUFDcEMsSUFBTUMsZUFBZSxHQUFHQSxDQUFBLEtBQU1oNEIseURBQVMsQ0FBQztFQUFFa0IsSUFBSSxFQUFFNjJCO0FBQW9CLENBQUMsQ0FBQztBQUN0RSxJQUFNRSxtQkFBbUIsR0FBR0EsQ0FBQSxLQUFNO0VBQzlCLElBQU1DLFNBQVMsR0FBR0YsZUFBZSxDQUFDLENBQUM7RUFDbkMsSUFBSSxDQUFDRSxTQUFTLEVBQ1YsT0FBTyxLQUFLO0VBQ2hCLE9BQU8sQ0FBQ3JaLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDdlEsUUFBUSxDQUFDMnBCLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUNqRCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBTUMsa0JBQWtCLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUFDLHFCQUFBO0VBQzdCLE9BQU8sQ0FBQyxHQUFBQSxxQkFBQSxHQUFDNzRCLFNBQVMsQ0FBQzg0QixTQUFTLENBQUNscEIsS0FBSyxDQUFDLGVBQWUsQ0FBQyxjQUFBaXBCLHFCQUFBLGVBQTFDQSxxQkFBQSxDQUE0QzMrQixNQUFNO0FBQy9ELENBQUM7QUFDRCxJQUFNNitCLHlCQUF5QixHQUFHLHVCQUF1QjtBQUN6RCxJQUFNQyxtQkFBbUIsR0FBR0EsQ0FBQSxLQUFNdjRCLHlEQUFTLENBQUM7RUFBRWtCLElBQUksRUFBRW8zQjtBQUEwQixDQUFDLENBQUMsS0FBSyxNQUFNO0FBQzNGLElBQU1FLFlBQVksR0FBR0EsQ0FBQSxLQUFNRCxtQkFBbUIsQ0FBQyxDQUFDLElBQUlOLG1CQUFtQixDQUFDLENBQUM7QUFDekUsSUFBTVEsaUJBQWlCLEdBQUdBLENBQUEsS0FBTS9tQixtREFBTyxDQUFDTSxLQUFLLENBQUMzUCxHQUFHLDBCQUEwQixDQUFDLEtBQUssS0FBSztBQUN0RjtBQUNBLE1BQU1xMkIsa0JBQWtCLENBQUM7RUFhckJqZixXQUFXQSxDQUFBLEVBQUc7SUFBQW9SLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQUFBLGVBQUE7SUFBQUEsZUFBQTtJQUFBQSxlQUFBO0lBQ1Y7SUFDQSxJQUFNOE4sUUFBUSxHQUFHLGtCQUFrQixDQUFDOS9CLElBQUksQ0FBQ3RELE1BQU0sQ0FBQzhILFFBQVEsQ0FBQ3U3QixJQUFJLENBQUM7SUFDOUQsSUFBTUMsV0FBVyxHQUFHLG9CQUFvQixDQUFDaGdDLElBQUksQ0FBQ3RELE1BQU0sQ0FBQzhILFFBQVEsQ0FBQ3U3QixJQUFJLENBQUM7SUFDbkUsSUFBTUUsUUFBUSxHQUFHLHFCQUFxQixDQUFDamdDLElBQUksQ0FBQ3RELE1BQU0sQ0FBQzhILFFBQVEsQ0FBQzA3QixNQUFNLENBQUM7SUFDbkUsSUFBTUMsbUJBQW1CLEdBQUcsQ0FBQ0wsUUFBUSxJQUFJLENBQUNGLGlCQUFpQixDQUFDLENBQUM7SUFDN0QsSUFBTVEsZ0JBQWdCLEdBQUcxakMsTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDRyxJQUFJLENBQUM2eEIsaUJBQWlCLElBQ2xFM2pDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDbk8sT0FBTyxLQUFLLHNCQUFzQjtJQUNsRSxJQUFNaWdDLGVBQWUsR0FBRzVqQyxNQUFNLENBQUM0SSxRQUFRLENBQUMrSSxNQUFNLENBQUNHLElBQUksQ0FBQzh4QixlQUFlO0lBQ25FLElBQU1DLFNBQVMsR0FBRzdqQyxNQUFNLENBQUM0SSxRQUFRLENBQUMrSSxNQUFNLENBQUNHLElBQUksQ0FBQ2d5QixXQUFXLEtBQUssU0FBUztJQUN2RSxJQUFNQyxhQUFhLEdBQUcvakMsTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDRyxJQUFJLENBQUNneUIsV0FBVyxLQUFLLGFBQWE7SUFDL0UsSUFBTUUsVUFBVSxHQUFHaGtDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDa3lCLFVBQVU7SUFDekQsSUFBTUMsUUFBUSxHQUFHamtDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDbXlCLFFBQVE7SUFDckQsSUFBTUMsY0FBYyxHQUFHbGtDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDZ3lCLFdBQVcsS0FBSyxVQUFVLElBQ3pFOWpDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDbk8sT0FBTyxLQUFLLFVBQVUsQ0FBQyxDQUFDO0lBQ3hELElBQU13Z0MsUUFBUSxHQUFHbmtDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ3d5QixRQUFRO0lBQ2hELElBQU1DLFVBQVUsR0FBR2xDLCtFQUFvQixDQUFDLENBQUMsS0FBSyxNQUFNO0lBQ3BELElBQU1tQyxlQUFlLEdBQUdya0MsTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDRyxJQUFJLENBQUN3eUIsbUJBQW1CO0lBQ3ZFLElBQU1DLG9CQUFvQixHQUFHM0Isa0JBQWtCLENBQUMsQ0FBQztJQUNqRDtJQUNBLElBQU07TUFBRTRCO0lBQU8sQ0FBQyxHQUFHeGtDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSTtJQUM5QyxJQUFNMnlCLGNBQWMsR0FBR0QsTUFBTSxDQUFDOWtCLFVBQVUsQ0FBQyxXQUFXLENBQUM7SUFDckQsSUFBTWdsQixzQkFBc0IsR0FBR0YsTUFBTSxDQUFDeDhCLFFBQVEsQ0FBQyxXQUFXLENBQUMsSUFDdkR3OEIsTUFBTSxDQUFDeDhCLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFDeEJ3OEIsTUFBTSxDQUFDeDhCLFFBQVEsQ0FBQyxVQUFVLENBQUMsSUFDM0J3OEIsTUFBTSxDQUFDeDhCLFFBQVEsQ0FBQyxTQUFTLENBQUMsSUFDMUJ3OEIsTUFBTSxDQUFDeDhCLFFBQVEsQ0FBQyxRQUFRLENBQUM7SUFDN0IsSUFBSSxDQUFDMjhCLHVCQUF1QixHQUFHRixjQUFjLElBQUlDLHNCQUFzQjtJQUN2RSxJQUFJLENBQUNFLGVBQWUsR0FBRyxDQUNuQiwrREFBK0QsRUFDL0QsdURBQXVELENBQzFELENBQUNqOUIsUUFBUSxDQUFDM0gsTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDRyxJQUFJLENBQUMweUIsTUFBTSxDQUFDO0lBQzlDO0lBQ0EsSUFBSSxDQUFDSyxNQUFNLEdBQUcsQ0FBQyxDQUFDdkIsV0FBVyxJQUFJTCxZQUFZLENBQUMsQ0FBQztJQUM3QyxJQUFJLENBQUM2QixrQkFBa0IsR0FBRyxDQUFDLElBQUksQ0FBQ0QsTUFBTSxJQUFJLENBQUNuQixnQkFBZ0I7SUFDM0QsSUFBTXFCLGlDQUFpQyxHQUFHO01BQ3RDLDhCQUE4QixFQUFFLENBQUMsQ0FBQ1osUUFBUSxDQUFDYSxtQkFBbUI7TUFDOUR2QjtJQUNKLENBQUM7SUFDRCxJQUFNd0Isa0NBQWtDLEdBQUc7TUFDdkN2QixnQkFBZ0I7TUFDaEJRLGNBQWM7TUFDZFcsTUFBTSxFQUFFLElBQUksQ0FBQ0EsTUFBTTtNQUNuQk47SUFDSixDQUFDO0lBQ0QsSUFBSSxDQUFDUyxtQkFBbUIsR0FDcEJ6QixRQUFRLElBQ0h6ekIsTUFBTSxDQUFDRSxNQUFNLENBQUMrMEIsaUNBQWlDLENBQUMsQ0FBQzkwQixLQUFLLENBQUNDLE9BQU8sQ0FBQyxJQUM1RCxDQUFDSixNQUFNLENBQUNFLE1BQU0sQ0FBQ2kxQixrQ0FBa0MsQ0FBQyxDQUFDdmhDLElBQUksQ0FBQ3dNLE9BQU8sQ0FBRTtJQUM3RSxJQUFJLENBQUMsSUFBSSxDQUFDODBCLG1CQUFtQixFQUFFO01BQzNCN0MsaUJBQWlCLENBQUM0QyxpQ0FBaUMsRUFBRUUsa0NBQWtDLENBQUM7SUFDNUY7SUFDQSxJQUFNQyxnQ0FBZ0MsR0FBRztNQUNyQ3JCO0lBQ0osQ0FBQztJQUNELElBQU1zQixpQ0FBaUMsR0FBRztNQUN0Q3ZCLGVBQWU7TUFDZkksVUFBVSxFQUFFLENBQUMsQ0FBQ0EsVUFBVTtNQUN4QkMsUUFBUTtNQUNSSSxlQUFlLEVBQUUsQ0FBQyxDQUFDQTtJQUN2QixDQUFDO0lBQ0QsSUFBSSxDQUFDZSxrQkFBa0IsR0FDbkIsSUFBSSxDQUFDSixtQkFBbUIsSUFDcEIsQ0FBQyxJQUFJLENBQUNILE1BQU0sSUFDWi8wQixNQUFNLENBQUNFLE1BQU0sQ0FBQ2sxQixnQ0FBZ0MsQ0FBQyxDQUFDajFCLEtBQUssQ0FBQ0MsT0FBTyxDQUFDLElBQzlELENBQUNKLE1BQU0sQ0FBQ0UsTUFBTSxDQUFDbTFCLGlDQUFpQyxDQUFDLENBQUN6aEMsSUFBSSxDQUFDd00sT0FBTyxDQUFDO0lBQ3ZFLElBQUkyekIsU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDdUIsa0JBQWtCLEVBQUU7TUFDdkM7TUFDQWpELGlCQUFpQixDQUFDK0MsZ0NBQWdDLEVBQUVDLGlDQUFpQyxDQUFDO0lBQzFGO0lBQ0EsSUFBSSxDQUFDRSxtQkFBbUIsR0FDcEIsQ0FBQyxJQUFJLENBQUNSLE1BQU0sSUFDUixJQUFJLENBQUNPLGtCQUFrQixJQUN2QixDQUFDcGxDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ0csSUFBSSxDQUFDd3pCLGFBQWE7SUFDbEQsSUFBSSxDQUFDQyxTQUFTLEdBQ1YsSUFBSSxDQUFDUCxtQkFBbUIsSUFDcEIsQ0FBQyxJQUFJLENBQUNILE1BQU0sSUFDWixDQUFDakIsZUFBZSxJQUNoQixDQUFDSyxRQUFRLElBQ1QsQ0FBQ0YsYUFBYSxJQUNkLENBQUMvakMsTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDRyxJQUFJLENBQUMwekIsT0FBTyxJQUNwQyxDQUFDeGxDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQzh6QixpQkFBaUIsSUFDekMsQ0FBQ3BCLGVBQWU7SUFDeEIsSUFBSSxDQUFDcUIsY0FBYyxHQUNmLENBQUMsSUFBSSxDQUFDYixNQUFNLElBQ1JwQixtQkFBbUIsSUFDbkIsQ0FBQ1MsY0FBYyxJQUNmLENBQUMsSUFBSSxDQUFDVSxlQUFlO0lBQzdCLElBQUksQ0FBQ2UsY0FBYyxHQUNmLElBQUksQ0FBQ1gsbUJBQW1CLElBQ3BCLENBQUMsSUFBSSxDQUFDSCxNQUFNLElBQ1osQ0FBQ2pCLGVBQWUsSUFDaEIsQ0FBQyxDQUFDNWpDLE1BQU0sQ0FBQzRJLFFBQVEsQ0FBQytJLE1BQU0sQ0FBQ3d5QixRQUFRLENBQUN5QixzQkFBc0IsSUFDeEQ1bEMsTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDRyxJQUFJLENBQUMrekIsV0FBVyxLQUN0QyxDQUFDN0IsVUFBVSxJQUFJSSxVQUFVLENBQUM7SUFDbkMsSUFBSSxDQUFDMEIsZUFBZSxHQUNoQixDQUFDLENBQUM5QixVQUFVLElBQUksSUFBSSxDQUFDZ0IsbUJBQW1CLElBQUksQ0FBQyxJQUFJLENBQUNILE1BQU07SUFDNUQsSUFBSSxDQUFDeG5CLFFBQVEsR0FDVCxDQUFDLENBQUNyZCxNQUFNLENBQUM0SSxRQUFRLENBQUMrSSxNQUFNLENBQUN3eUIsUUFBUSxDQUFDOW1CLFFBQVEsSUFDdEMsQ0FBQzZtQixjQUFjLElBQ2YsQ0FBQyxJQUFJLENBQUNVLGVBQWU7RUFDakM7QUFDSjtBQUNPLElBQU1tQixrQkFBa0IsR0FBRyxJQUFJNUMsa0JBQWtCLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3SnNCO0FBQ2hDO0FBQ2hELElBQU16ZCxXQUFXLEdBQUc7RUFDaEJHLE1BQU0sRUFBRW1nQixxRUFBaUIsQ0FBQyxRQUFRLENBQUM7RUFDbkMvZixNQUFNLEVBQUUrZixxRUFBaUIsQ0FBQyxRQUFRLENBQUM7RUFDbkNyZ0IsT0FBTyxFQUFFcWdCLHFFQUFpQixDQUFDLFNBQVMsQ0FBQztFQUNyQzlmLElBQUksRUFBRThmLHFFQUFpQixDQUFDLE1BQU07QUFDbEMsQ0FBQztBQUNELElBQU1FLGtCQUFrQixHQUFJQyxLQUFLLElBQUtBLEtBQUssSUFBSUgscUVBQWlCO0FBQ2hFLElBQU1JLFlBQVksR0FBSUQsS0FBSyxJQUFLQSxLQUFLLElBQUl6Z0IsV0FBVztBQUNwRCxJQUFNMmdCLFdBQVcsR0FBRztFQUNoQnRnQixZQUFZLEVBQUVpZ0IscUVBQWlCLENBQUMsY0FBYyxDQUFDO0VBQy9DbGdCLGVBQWUsRUFBRWtnQixxRUFBaUIsQ0FBQyxpQkFBaUIsQ0FBQztFQUNyRGhnQixPQUFPLEVBQUVnZ0IscUVBQWlCLENBQUMsU0FBUyxDQUFDO0VBQ3JDcGdCLE9BQU8sRUFBRW9nQixxRUFBaUIsQ0FBQyxTQUFTO0FBQ3hDLENBQUM7QUFDRCxJQUFNTSxxQkFBcUIsR0FBRyxDQUMxQixNQUFNLEVBQ04sU0FBUyxFQUNULFNBQVMsRUFDVCxRQUFRLEVBQ1IsU0FBUyxFQUNULGlCQUFpQixFQUNqQixjQUFjLEVBQ2QsUUFBUSxDQUNYO0FBQ0QsSUFBSUMsaUJBQWlCO0FBQ3JCLElBQUlDLGlCQUFpQjtBQUNyQjtBQUNBLElBQU1DLFFBQVEsR0FBR0EsQ0FBQ0MsaUJBQWlCLEVBQUUxTixLQUFLLEtBQUs7RUFDM0MsSUFBTW1OLEtBQUssR0FBR0cscUJBQXFCLENBQUNoaUMsSUFBSSxDQUFFNmhDLEtBQUssSUFBSztJQUNoRCxJQUFJQyxZQUFZLENBQUNELEtBQUssQ0FBQyxFQUFFO01BQ3JCLE9BQU9uTixLQUFLLElBQUl0VCxXQUFXLENBQUN5Z0IsS0FBSyxDQUFDO0lBQ3RDLENBQUMsTUFDSSxJQUFJTyxpQkFBaUIsRUFBRTtNQUN4QixPQUFPMU4sS0FBSyxJQUFJcU4sV0FBVyxDQUFDRixLQUFLLENBQUM7SUFDdEM7SUFDQSxPQUFPLEtBQUs7RUFDaEIsQ0FBQyxDQUFDO0VBQ0Y7RUFDQSxPQUFRQSxLQUFLLGFBQUxBLEtBQUssY0FBTEEsS0FBSyxHQUFJLFFBQVE7QUFDN0IsQ0FBQztBQUNELElBQU1RLGFBQWEsR0FBSTNOLEtBQUssSUFBS3lOLFFBQVEsQ0FBQyxLQUFLLEVBQUV6TixLQUFLLENBQUM7QUFDdkQsSUFBTTROLGFBQWEsR0FBSTVOLEtBQUssSUFBS3lOLFFBQVEsQ0FBQyxJQUFJLEVBQUV6TixLQUFLLENBQUM7QUFDdEQsSUFBTWtKLG9CQUFvQixHQUFHQSxDQUFBLEtBQU1xRSxpQkFBaUIsYUFBakJBLGlCQUFpQixjQUFqQkEsaUJBQWlCLEdBQUlJLGFBQWEsQ0FBQ1YsNkRBQVcsQ0FBQyxDQUFDLENBQUNqTixLQUFLLENBQUM7QUFDMUYsSUFBTTZOLG9CQUFvQixHQUFHQSxDQUFBLEtBQU1MLGlCQUFpQixhQUFqQkEsaUJBQWlCLGNBQWpCQSxpQkFBaUIsR0FBSUksYUFBYSxDQUFDWCw2REFBVyxDQUFDLENBQUMsQ0FBQ2pOLEtBQUssQ0FBQztBQUMxRjtBQUNBLElBQU04TixhQUFhLEdBQUd0bUMsSUFBQSxJQUFtQjtFQUFBLElBQWxCO0lBQUV1bUMsR0FBRztJQUFFQztFQUFLLENBQUMsR0FBQXhtQyxJQUFBO0VBQ2hDLElBQU15bUMsUUFBUSxHQUFHRixHQUFHLEdBQ2QsT0FBT0EsR0FBRyxLQUFLLFFBQVEsR0FDbkJBLEdBQUcsR0FDSGYscUVBQWlCLENBQUNlLEdBQUcsQ0FBQyxHQUMxQixJQUFJO0VBQ1YsSUFBTUcsUUFBUSxHQUFHRixHQUFHLEdBQ2QsT0FBT0EsR0FBRyxLQUFLLFFBQVEsR0FDbkJBLEdBQUcsR0FDSGhCLHFFQUFpQixDQUFDZ0IsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUM5QixJQUFJO0VBQ1YsSUFBTUcsUUFBUSxHQUFHRixRQUFRLGtCQUFBNW1DLE1BQUEsQ0FBa0I0bUMsUUFBUSxXQUFRLElBQUk7RUFDL0QsSUFBTUcsUUFBUSxHQUFHRixRQUFRLGtCQUFBN21DLE1BQUEsQ0FBa0I2bUMsUUFBUSxXQUFRLElBQUk7RUFDL0QsT0FBTyxDQUFDQyxRQUFRLEVBQUVDLFFBQVEsQ0FBQyxDQUFDbjZCLE1BQU0sQ0FBQ2lELE9BQU8sQ0FBQyxDQUFDOFAsSUFBSSxDQUFDLE9BQU8sQ0FBQztBQUM3RCxDQUFDO0FBQ0QsSUFBTXFuQixnQkFBZ0IsR0FBSUMsVUFBVSxJQUFLO0VBQ3JDZCxpQkFBaUIsR0FBR2MsVUFBVTtFQUM5QmYsaUJBQWlCLEdBQUdFLFFBQVEsQ0FBQyxLQUFLLEVBQUVULHFFQUFpQixDQUFDUSxpQkFBaUIsQ0FBQyxDQUFDO0FBQzdFLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1lLHVCQUF1QixHQUFHQSxDQUFBLEtBQU07RUFDbEMsQ0FBQyxHQUFHakIscUJBQXFCLENBQUMsQ0FBQ2tCLE9BQU8sQ0FBQyxDQUFDLENBQUNuM0IsT0FBTyxDQUFDLENBQUNvM0IsRUFBRSxFQUFFMWlCLEtBQUssRUFBRTJpQixHQUFHLEtBQUs7SUFDN0QsSUFBSXhCLGtCQUFrQixDQUFDdUIsRUFBRSxDQUFDLEVBQUU7TUFDeEIsSUFBTUUsTUFBTSxHQUFHRCxHQUFHLENBQUMzaUIsS0FBSyxHQUFHLENBQUMsQ0FBQztNQUM3QixJQUFNNmlCLEdBQUcsR0FBRzVuQyxNQUFNLENBQUM2bkMsVUFBVSxDQUFDZixhQUFhLENBQUM7UUFDeENDLEdBQUcsRUFBRVUsRUFBRTtRQUNQVCxHQUFHLEVBQUVXLE1BQU0sR0FBRzNCLHFFQUFpQixDQUFDMkIsTUFBTSxDQUFDLEdBQUduM0I7TUFDOUMsQ0FBQyxDQUFDLENBQUM7TUFDSCxJQUFNdVosUUFBUSxHQUFJNmQsR0FBRyxJQUFLQSxHQUFHLENBQUNFLE9BQU8sSUFBSVQsZ0JBQWdCLENBQUNJLEVBQUUsQ0FBQztNQUM3RDtNQUNBO01BQ0EsSUFBSSxPQUFPRyxHQUFHLENBQUN2ekIsZ0JBQWdCLEtBQUssV0FBVyxFQUFFO1FBQzdDdXpCLEdBQUcsQ0FBQ3Z6QixnQkFBZ0IsQ0FBQyxRQUFRLEVBQUUwVixRQUFRLENBQUM7TUFDNUMsQ0FBQyxNQUNJLElBQUksT0FBTzZkLEdBQUcsQ0FBQ3BjLFdBQVcsS0FBSyxXQUFXLEVBQUU7UUFDN0NvYyxHQUFHLENBQUNwYyxXQUFXLENBQUN6QixRQUFRLENBQUM7TUFDN0I7TUFDQUEsUUFBUSxDQUFDNmQsR0FBRyxDQUFDO0lBQ2pCO0VBQ0osQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNELElBQU1HLGtCQUFrQixHQUFHdDhCLEtBQUE7RUFBQSxJQUFDO0lBQUVzN0IsR0FBRztJQUFFQztFQUFLLENBQUMsR0FBQXY3QixLQUFBO0VBQUEsT0FBS3pMLE1BQU0sQ0FBQzZuQyxVQUFVLENBQUNmLGFBQWEsQ0FBQztJQUFFQyxHQUFHO0lBQUVDO0VBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQ2MsT0FBTztBQUFBO0FBQ3BHLElBQU1FLG9CQUFvQixHQUFJdEIsaUJBQWlCLElBQUs7RUFDaEQsSUFBSXVCLEdBQUcsR0FBR3ZCLGlCQUFpQixHQUNyQkcsb0JBQW9CLENBQUMsQ0FBQyxHQUN0QjNFLG9CQUFvQixDQUFDLENBQUM7RUFDNUIsT0FBUTd5QixRQUFRLElBQUs7SUFDakIsSUFBTTY0QixFQUFFLEdBQUd4QixpQkFBaUIsR0FDdEJHLG9CQUFvQixDQUFDLENBQUMsR0FDdEIzRSxvQkFBb0IsQ0FBQyxDQUFDO0lBQzVCLElBQUlnRyxFQUFFLEtBQUtELEdBQUcsRUFBRTtNQUNaNTRCLFFBQVEsQ0FBQzY0QixFQUFFLEVBQUVELEdBQUcsQ0FBQztNQUNqQkEsR0FBRyxHQUFHQyxFQUFFO0lBQ1o7RUFDSixDQUFDO0FBQ0wsQ0FBQztBQUNEWCx1QkFBdUIsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUMxR3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU10QixXQUFXLEdBQUdBLENBQUEsS0FBTTtFQUN0QixPQUFPO0lBQ0hqTixLQUFLLEVBQUVoNUIsTUFBTSxDQUFDbW9DLFVBQVUsSUFBSWxsQyxRQUFRLENBQUNpTCxJQUFJLENBQUNrNkIsV0FBVyxJQUFJLENBQUM7SUFDMURuUCxNQUFNLEVBQUVqNUIsTUFBTSxDQUFDcW9DLFdBQVcsSUFBSXBsQyxRQUFRLENBQUNpTCxJQUFJLENBQUNvNkIsWUFBWSxJQUFJO0VBQ2hFLENBQUM7QUFDTCxDQUFDOzs7Ozs7O1VDWEQ7VUFDQTs7VUFFQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTtVQUNBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOztVQUVBO1VBQ0E7VUFDQTs7VUFFQTtVQUNBOzs7OztXQ3pCQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDLFdBQVc7V0FDNUM7V0FDQSxFOzs7OztXQ1BBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EseUNBQXlDLHdDQUF3QztXQUNqRjtXQUNBO1dBQ0EsRTs7Ozs7V0NQQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLEVBQUU7V0FDRixFOzs7OztXQ1JBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsRTs7Ozs7V0NKQSxzRDs7Ozs7V0NBQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLEdBQUc7V0FDSDtXQUNBO1dBQ0EsQ0FBQyxJOzs7OztXQ1BELHdGOzs7OztXQ0FBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsdUJBQXVCLDRCQUE0QjtXQUNuRDtXQUNBO1dBQ0E7V0FDQSxpQkFBaUIsb0JBQW9CO1dBQ3JDO1dBQ0EsbUdBQW1HLFlBQVk7V0FDL0c7V0FDQTtXQUNBO1dBQ0E7V0FDQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7O1dBRUE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQSxtRUFBbUUsaUNBQWlDO1dBQ3BHO1dBQ0E7V0FDQTtXQUNBLEU7Ozs7O1dDekNBO1dBQ0E7V0FDQTtXQUNBLHVEQUF1RCxpQkFBaUI7V0FDeEU7V0FDQSxnREFBZ0QsYUFBYTtXQUM3RCxFOzs7OztXQ05BO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBLGtDOzs7OztXQ2xCQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7O1dBRUE7V0FDQTtXQUNBO1dBQ0EsaUNBQWlDOztXQUVqQztXQUNBO1dBQ0E7V0FDQSxLQUFLO1dBQ0wsZUFBZTtXQUNmO1dBQ0E7V0FDQTs7V0FFQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7O1dBRUE7O1dBRUE7O1dBRUE7O1dBRUE7O1dBRUE7O1dBRUE7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBO1dBQ0EsTUFBTSxxQkFBcUI7V0FDM0I7V0FDQTtXQUNBO1dBQ0E7V0FDQTtXQUNBOztXQUVBOztXQUVBO1dBQ0E7V0FDQSw0Rzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckZBLFNBQVN0ZixPQUFPQSxDQUFDaFUsQ0FBQyxFQUFFc0MsQ0FBQyxFQUFFO0VBQUUsSUFBSXBDLENBQUMsR0FBR3BGLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDaUYsQ0FBQyxDQUFDO0VBQUUsSUFBSWxGLE1BQU0sQ0FBQ21aLHFCQUFxQixFQUFFO0lBQy9FLElBQUl6UixDQUFDLEdBQUcxSCxNQUFNLENBQUNtWixxQkFBcUIsQ0FBQ2pVLENBQUMsQ0FBQztJQUN2Q3NDLENBQUMsS0FBS0UsQ0FBQyxHQUFHQSxDQUFDLENBQUN2SyxNQUFNLENBQUMsVUFBVXFLLENBQUMsRUFBRTtNQUFFLE9BQU94SCxNQUFNLENBQUN1bEIsd0JBQXdCLENBQUNyZ0IsQ0FBQyxFQUFFc0MsQ0FBQyxDQUFDLENBQUNTLFVBQVU7SUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFN0MsQ0FBQyxDQUFDeEUsSUFBSSxDQUFDM1AsS0FBSyxDQUFDbVUsQ0FBQyxFQUFFc0MsQ0FBQyxDQUFDO0VBQ3RIO0VBQUUsT0FBT3RDLENBQUM7QUFBRTtBQUNaLFNBQVN0RixhQUFhQSxDQUFDb0YsQ0FBQyxFQUFFO0VBQUUsS0FBSyxJQUFJc0MsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHdFcsU0FBUyxDQUFDa0QsTUFBTSxFQUFFb1QsQ0FBQyxFQUFFLEVBQUU7SUFDbkUsSUFBSXBDLENBQUMsR0FBRyxJQUFJLElBQUlsVSxTQUFTLENBQUNzVyxDQUFDLENBQUMsR0FBR3RXLFNBQVMsQ0FBQ3NXLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNoREEsQ0FBQyxHQUFHLENBQUMsR0FBRzBSLE9BQU8sQ0FBQ2xaLE1BQU0sQ0FBQ29GLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM3RSxPQUFPLENBQUMsVUFBVWlILENBQUMsRUFBRTtNQUFFZ2UsZUFBZSxDQUFDdGdCLENBQUMsRUFBRXNDLENBQUMsRUFBRXBDLENBQUMsQ0FBQ29DLENBQUMsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDLEdBQUd4SCxNQUFNLENBQUN5bEIseUJBQXlCLEdBQUd6bEIsTUFBTSxDQUFDMGxCLGdCQUFnQixDQUFDeGdCLENBQUMsRUFBRWxGLE1BQU0sQ0FBQ3lsQix5QkFBeUIsQ0FBQ3JnQixDQUFDLENBQUMsQ0FBQyxHQUFHOFQsT0FBTyxDQUFDbFosTUFBTSxDQUFDb0YsQ0FBQyxDQUFDLENBQUMsQ0FBQzdFLE9BQU8sQ0FBQyxVQUFVaUgsQ0FBQyxFQUFFO01BQUV4SCxNQUFNLENBQUNnSSxjQUFjLENBQUM5QyxDQUFDLEVBQUVzQyxDQUFDLEVBQUV4SCxNQUFNLENBQUN1bEIsd0JBQXdCLENBQUNuZ0IsQ0FBQyxFQUFFb0MsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUM7RUFDalQ7RUFBRSxPQUFPdEMsQ0FBQztBQUFFO0FBQ1osU0FBU3NnQixlQUFlQSxDQUFDdGdCLENBQUMsRUFBRXNDLENBQUMsRUFBRXBDLENBQUMsRUFBRTtFQUFFLE9BQU8sQ0FBQ29DLENBQUMsR0FBR3VXLGNBQWMsQ0FBQ3ZXLENBQUMsQ0FBQyxLQUFLdEMsQ0FBQyxHQUFHbEYsTUFBTSxDQUFDZ0ksY0FBYyxDQUFDOUMsQ0FBQyxFQUFFc0MsQ0FBQyxFQUFFO0lBQUUxTixLQUFLLEVBQUVzTCxDQUFDO0lBQUU2QyxVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBQUU0QixZQUFZLEVBQUUsQ0FBQyxDQUFDO0lBQUV5SixRQUFRLEVBQUUsQ0FBQztFQUFFLENBQUMsQ0FBQyxHQUFHcE8sQ0FBQyxDQUFDc0MsQ0FBQyxDQUFDLEdBQUdwQyxDQUFDLEVBQUVGLENBQUM7QUFBRTtBQUNuTCxTQUFTNlksY0FBY0EsQ0FBQzNZLENBQUMsRUFBRTtFQUFFLElBQUl3QixDQUFDLEdBQUdxWCxZQUFZLENBQUM3WSxDQUFDLEVBQUUsUUFBUSxDQUFDO0VBQUUsT0FBTyxRQUFRLElBQUl1WSxPQUFPLENBQUMvVyxDQUFDLENBQUMsR0FBR0EsQ0FBQyxHQUFHQSxDQUFDLEdBQUcsRUFBRTtBQUFFO0FBQzVHLFNBQVNxWCxZQUFZQSxDQUFDN1ksQ0FBQyxFQUFFb0MsQ0FBQyxFQUFFO0VBQUUsSUFBSSxRQUFRLElBQUltVyxPQUFPLENBQUN2WSxDQUFDLENBQUMsSUFBSSxDQUFDQSxDQUFDLEVBQzFELE9BQU9BLENBQUM7RUFBRSxJQUFJRixDQUFDLEdBQUdFLENBQUMsQ0FBQzhDLE1BQU0sQ0FBQ2dXLFdBQVcsQ0FBQztFQUFFLElBQUksS0FBSyxDQUFDLEtBQUtoWixDQUFDLEVBQUU7SUFDM0QsSUFBSTBCLENBQUMsR0FBRzFCLENBQUMsQ0FBQ3JTLElBQUksQ0FBQ3VTLENBQUMsRUFBRW9DLENBQUMsSUFBSSxTQUFTLENBQUM7SUFDakMsSUFBSSxRQUFRLElBQUltVyxPQUFPLENBQUMvVyxDQUFDLENBQUMsRUFDdEIsT0FBT0EsQ0FBQztJQUNaLE1BQU0sSUFBSW1ELFNBQVMsQ0FBQyw4Q0FBOEMsQ0FBQztFQUN2RTtFQUFFLE9BQU8sQ0FBQyxRQUFRLEtBQUt2QyxDQUFDLEdBQUcyQyxNQUFNLEdBQUdxUCxNQUFNLEVBQUVwVSxDQUFDLENBQUM7QUFBRTtBQUNoRCxTQUFTdVksT0FBT0EsQ0FBQ2pXLENBQUMsRUFBRTtFQUNoQix5QkFBeUI7O0VBQ3pCLE9BQU9pVyxPQUFPLEdBQUcsVUFBVSxJQUFJLE9BQU96VixNQUFNLElBQUksUUFBUSxJQUFJLE9BQU9BLE1BQU0sQ0FBQzBWLFFBQVEsR0FBRyxVQUFVbFcsQ0FBQyxFQUFFO0lBQUUsT0FBTyxPQUFPQSxDQUFDO0VBQUUsQ0FBQyxHQUFHLFVBQVVBLENBQUMsRUFBRTtJQUFFLE9BQU9BLENBQUMsSUFBSSxVQUFVLElBQUksT0FBT1EsTUFBTSxJQUFJUixDQUFDLENBQUMwTSxXQUFXLEtBQUtsTSxNQUFNLElBQUlSLENBQUMsS0FBS1EsTUFBTSxDQUFDTyxTQUFTLEdBQUcsUUFBUSxHQUFHLE9BQU9mLENBQUM7RUFBRSxDQUFDLEVBQUVpVyxPQUFPLENBQUNqVyxDQUFDLENBQUM7QUFDOVE7QUFDQTtBQUNBO0FBQytDO0FBQ0M7QUFDZjtBQUMyQjtBQUNWO0FBQ0Q7QUFDMEI7QUFDM0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJa3hCLG9CQUFvQixHQUFHLFNBQVNBLG9CQUFvQkEsQ0FBQ0MsY0FBYyxFQUFFO0VBQ3JFLElBQUlsYixPQUFPLENBQUNrYixjQUFjLENBQUMsS0FBSyxRQUFRLEVBQUU7SUFDdEMsQ0FBQyxVQUFVLEVBQUUsUUFBUSxFQUFFLGVBQWUsQ0FBQyxDQUFDdDRCLE9BQU8sQ0FBQyxVQUFVdTRCLFFBQVEsRUFBRTtNQUNoRSxJQUFJLE9BQU9ELGNBQWMsQ0FBQ0MsUUFBUSxDQUFDLEtBQUssUUFBUSxFQUFFO1FBQzlDLElBQUlDLDJCQUEyQixHQUFHQyxrQkFBa0IsQ0FBQ0gsY0FBYyxDQUFDQyxRQUFRLENBQUMsQ0FBQztRQUM5RTtRQUNBRCxjQUFjLENBQUNDLFFBQVEsQ0FBQyxHQUFHLElBQUludkIsUUFBUSxDQUFDLFNBQVMsRUFBRSxpQkFBaUIsQ0FBQ3BaLE1BQU0sQ0FBQ3dvQywyQkFBMkIsRUFBRSxvQ0FBb0MsQ0FBQyxDQUFDO01BQ25KO0lBQ0osQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBSTFZLE1BQU0sR0FBRztFQUNUNFksV0FBVyxFQUFFLEtBQUs7RUFDbEI7RUFDQUMsV0FBVyxFQUFFQyx1QkFBZ0JBO0FBQ2pDLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxJQUFJQyxzQkFBc0IsR0FBRyxTQUFTQSxzQkFBc0JBLENBQUEsRUFBRztFQUMzRDtFQUNBO0VBQ0EsSUFBSWptQyxRQUFRLENBQUNrbUMsYUFBYSxFQUFFO0lBQ3hCLE9BQU9sbUMsUUFBUSxDQUFDa21DLGFBQWEsQ0FBQ3hKLFlBQVksQ0FBQyxLQUFLLENBQUM7RUFDckQ7RUFDQTtFQUNBLElBQUl5SixjQUFjLEdBQUdubUMsUUFBUSxDQUFDb21DLE9BQU8sSUFBSSxFQUFFO0VBQzNDLElBQUlDLHFCQUFxQixHQUFHdndCLEtBQUssQ0FBQ1IsU0FBUyxDQUFDdEwsTUFBTSxDQUFDdEssSUFBSSxDQUFDeW1DLGNBQWMsRUFBRSxVQUFVcE8sT0FBTyxFQUFFO0lBQ3ZGLE9BQU9BLE9BQU8sQ0FBQzJFLFlBQVksQ0FBQyxLQUFLLENBQUM7RUFDdEMsQ0FBQyxDQUFDO0VBQ0YsSUFBSTJKLHFCQUFxQixDQUFDcGxDLE1BQU0sR0FBRyxDQUFDLEVBQUU7SUFDbEMsSUFBSWlsQyxhQUFhLEdBQUdHLHFCQUFxQixDQUFDQSxxQkFBcUIsQ0FBQ3BsQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO0lBQzNFLE9BQU9pbEMsYUFBYSxDQUFDeEosWUFBWSxDQUFDLEtBQUssQ0FBQztFQUM1QztFQUNBO0VBQ0EsTUFBTSxJQUFJdi9CLEtBQUssQ0FBQywyREFBMkQsQ0FBQztBQUNoRixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFJbXBDLFFBQVEsR0FBRyxTQUFTQSxRQUFRQSxDQUFDQyxhQUFhLEVBQUU7RUFDNUM7RUFDQSxJQUFJdHBDLE1BQU0sR0FBRyxDQUFDLENBQUM7RUFDZixJQUFJLE9BQU9zcEMsYUFBYSxLQUFLLFFBQVEsSUFBSUEsYUFBYSxLQUFLLEVBQUUsRUFBRTtJQUMzRCxJQUFJQyxZQUFZLEdBQUdELGFBQWEsQ0FBQzV5QixLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMySSxLQUFLLENBQUMsR0FBRyxDQUFDO0lBQ3BELEtBQUssSUFBSTdJLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRyt5QixZQUFZLENBQUN2bEMsTUFBTSxFQUFFd1MsQ0FBQyxFQUFFLEVBQUU7TUFDMUMsSUFBSWd6QixJQUFJLEdBQUdELFlBQVksQ0FBQy95QixDQUFDLENBQUMsQ0FBQzZJLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFDckNyZixNQUFNLENBQUN3cEMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUdaLGtCQUFrQixDQUFDWSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDakQ7RUFDSixDQUFDLE1BQ0k7SUFDRDtJQUNBLElBQUlDLFlBQVksR0FBR1Qsc0JBQXNCLENBQUMsQ0FBQztJQUMzQyxJQUFJVSxlQUFlO0lBQ25CLElBQUk7TUFDQTtNQUNBO01BQ0E7TUFDQUEsZUFBZSxHQUFHLElBQUlDLEdBQUcsQ0FBQ0YsWUFBWSxFQUFFM3ZCLElBQUksQ0FBQ2xTLFFBQVEsQ0FBQ2dpQyxJQUFJLENBQUM7SUFDL0QsQ0FBQyxDQUNELE9BQU90MUIsS0FBSyxFQUFFO01BQ1Y7TUFDQTtJQUFBO0lBRUosSUFBSW8xQixlQUFlLEVBQUU7TUFDakIxcEMsTUFBTSxHQUFHMHBDLGVBQWU7TUFDeEIxcEMsTUFBTSxDQUFDNnBDLGlCQUFpQixHQUFHLElBQUk7SUFDbkM7RUFDSjtFQUNBLE9BQU83cEMsTUFBTTtBQUNqQixDQUFDO0FBQ0QsSUFBSThwQyxtQkFBbUIsR0FBR1QsUUFBUSxDQUFDVSxlQUFlLENBQUM7QUFDbkQsSUFBSUMsZUFBZSxHQUFHO0VBQ2xCLHdCQUF3QixFQUFFLEtBQUs7RUFDL0IsZ0JBQWdCLEVBQUUsS0FBSztFQUN2QkMsUUFBUSxFQUFFLEtBQUs7RUFDZkMsT0FBTyxFQUFFO0FBQ2IsQ0FBQztBQUNEO0FBQ0EsSUFBSXhWLE9BQU8sR0FBRztFQUNWeVYsR0FBRyxFQUFFLEtBQUs7RUFDVkMsVUFBVSxFQUFFLEtBQUs7RUFDakJDLFFBQVEsRUFBRSxLQUFLO0VBQ2ZDLE9BQU8sRUFBRTtBQUNiLENBQUM7QUFDRCxJQUFJUixtQkFBbUIsQ0FBQ0ssR0FBRyxLQUFLLE1BQU0sRUFBRTtFQUNwQ3pWLE9BQU8sQ0FBQ3lWLEdBQUcsR0FBRyxJQUFJO0VBQ2xCSCxlQUFlLENBQUMsd0JBQXdCLENBQUMsR0FBRyxJQUFJO0FBQ3BEO0FBQ0EsSUFBSUYsbUJBQW1CLENBQUMsYUFBYSxDQUFDLEtBQUssTUFBTSxFQUFFO0VBQy9DcFYsT0FBTyxDQUFDMFYsVUFBVSxHQUFHLElBQUk7RUFDekJKLGVBQWUsQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLElBQUk7QUFDNUM7QUFDQSxJQUFJRixtQkFBbUIsQ0FBQ08sUUFBUSxLQUFLLE1BQU0sRUFBRTtFQUN6QzNWLE9BQU8sQ0FBQzJWLFFBQVEsR0FBRyxJQUFJO0VBQ3ZCTCxlQUFlLENBQUNDLFFBQVEsR0FBRyxJQUFJO0FBQ25DO0FBQ0EsSUFBSUgsbUJBQW1CLENBQUNRLE9BQU8sRUFBRTtFQUM3QixJQUFJO0lBQ0E1VixPQUFPLENBQUM0VixPQUFPLEdBQUcxOEIsSUFBSSxDQUFDQyxLQUFLLENBQUNpOEIsbUJBQW1CLENBQUNRLE9BQU8sQ0FBQztFQUM3RCxDQUFDLENBQ0QsT0FBT3gxQixDQUFDLEVBQUU7SUFDTmxRLDhDQUFHLENBQUMwUCxLQUFLLENBQUMsb0RBQW9ELEVBQUVRLENBQUMsQ0FBQztFQUN0RTtFQUNBO0VBQ0EsSUFBSXlZLE9BQU8sQ0FBQ21ILE9BQU8sQ0FBQzRWLE9BQU8sQ0FBQyxLQUFLLFFBQVEsRUFBRTtJQUN2QzVWLE9BQU8sQ0FBQzRWLE9BQU8sR0FBRzU2QixhQUFhLENBQUM7TUFDNUI2NkIsTUFBTSxFQUFFLElBQUk7TUFDWkMsUUFBUSxFQUFFLElBQUk7TUFDZEMsYUFBYSxFQUFFO0lBQ25CLENBQUMsRUFBRS9WLE9BQU8sQ0FBQzRWLE9BQU8sQ0FBQztJQUNuQjlCLG9CQUFvQixDQUFDOVQsT0FBTyxDQUFDNFYsT0FBTyxDQUFDO0VBQ3pDO0VBQ0FOLGVBQWUsQ0FBQ0UsT0FBTyxHQUFHeFYsT0FBTyxDQUFDNFYsT0FBTyxLQUFLLEtBQUs7QUFDdkQ7QUFDQSxJQUFJUixtQkFBbUIsQ0FBQ1ksT0FBTyxFQUFFO0VBQzdCaFcsT0FBTyxDQUFDZ1csT0FBTyxHQUFHWixtQkFBbUIsQ0FBQ1ksT0FBTztBQUNqRDtBQUNBLElBQUksT0FBT1osbUJBQW1CLENBQUM5SSxTQUFTLEtBQUssV0FBVyxFQUFFO0VBQ3REdE0sT0FBTyxDQUFDc00sU0FBUyxHQUFHNVgsTUFBTSxDQUFDMGdCLG1CQUFtQixDQUFDOUksU0FBUyxDQUFDO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSTJKLGNBQWMsR0FBRyxTQUFTQSxjQUFjQSxDQUFDdFgsS0FBSyxFQUFFO0VBQ2hEO0VBQ0FnVixxRUFBeUIsQ0FBQ2hWLEtBQUssS0FBSyxTQUFTLElBQUlBLEtBQUssS0FBSyxLQUFLLEdBQUcsTUFBTSxHQUFHQSxLQUFLLENBQUM7RUFDbEZpTywwREFBVyxDQUFDak8sS0FBSyxDQUFDO0FBQ3RCLENBQUM7QUFDRCxJQUFJcUIsT0FBTyxDQUFDZ1csT0FBTyxFQUFFO0VBQ2pCQyxjQUFjLENBQUNqVyxPQUFPLENBQUNnVyxPQUFPLENBQUM7QUFDbkM7QUFDQSxJQUFJRSxrQkFBa0IsR0FBRyxTQUFTQSxrQkFBa0JBLENBQUNDLFFBQVEsRUFBRTtFQUMzRCxJQUFJQyxtQkFBbUIsR0FBR2w3QixNQUFNLENBQUNDLElBQUksQ0FBQ2c3QixRQUFRLENBQUM7RUFDL0MsSUFBSSxDQUFDQSxRQUFRLElBQUlDLG1CQUFtQixDQUFDOW1DLE1BQU0sS0FBSyxDQUFDLEVBQUU7SUFDL0M7RUFDSjtFQUNBLElBQUkrbUMsU0FBUyxHQUFHLGlCQUFpQjtFQUNqQztFQUNBLEtBQUssSUFBSXYwQixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdzMEIsbUJBQW1CLENBQUM5bUMsTUFBTSxFQUFFd1MsQ0FBQyxFQUFFLEVBQUU7SUFDakQsSUFBSXlNLEdBQUcsR0FBRzZuQixtQkFBbUIsQ0FBQ3QwQixDQUFDLENBQUM7SUFDaEN1MEIsU0FBUyxJQUFJLEdBQUcsQ0FBQzVxQyxNQUFNLENBQUM4aUIsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDOWlCLE1BQU0sQ0FBQzBxQyxRQUFRLENBQUM1bkIsR0FBRyxDQUFDLEdBQUcsU0FBUyxHQUFHLFVBQVUsRUFBRSxHQUFHLENBQUM7RUFDekY7RUFDQTtFQUNBOG5CLFNBQVMsR0FBR0EsU0FBUyxDQUFDcjBCLEtBQUssQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQ3ZXLE1BQU0sQ0FBQyxHQUFHLENBQUM7RUFDOUN5RSw4Q0FBRyxDQUFDNHFCLElBQUksQ0FBQ3ViLFNBQVMsQ0FBQztBQUN2QixDQUFDO0FBQ0RILGtCQUFrQixDQUFDWixlQUFlLENBQUM7QUFDbkNsd0IsSUFBSSxDQUFDM0YsZ0JBQWdCLENBQUMsY0FBYyxFQUFFLFlBQVk7RUFDOUM4YixNQUFNLENBQUM0WSxXQUFXLEdBQUcsSUFBSTtBQUM3QixDQUFDLENBQUM7QUFDRixJQUFJeUIsT0FBTyxHQUFHLE9BQU94cUMsTUFBTSxLQUFLLFdBQVcsR0FBR3k2QiwwREFBYSxDQUFDaE4sT0FBTyxDQUFDbUgsT0FBTyxDQUFDNFYsT0FBTyxDQUFDLEtBQUssUUFBUSxHQUFHO0VBQ2hHdFAsc0JBQXNCLEVBQUV0RyxPQUFPLENBQUM0VixPQUFPLENBQUN0UCxzQkFBc0I7RUFDOUR5QixpQkFBaUIsRUFBRS9ILE9BQU8sQ0FBQzRWLE9BQU8sQ0FBQ0c7QUFDdkMsQ0FBQyxHQUFHO0VBQ0F6UCxzQkFBc0IsRUFBRSxLQUFLO0VBQzdCeUIsaUJBQWlCLEVBQUUvSCxPQUFPLENBQUM0VjtBQUMvQixDQUFDLENBQUMsR0FBRztFQUNEelQsSUFBSSxFQUFFLFNBQVNBLElBQUlBLENBQUEsRUFBRyxDQUFFO0FBQzVCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUltVSxTQUFTLEdBQUcsU0FBU0EsU0FBU0EsQ0FBQzFxQyxJQUFJLEVBQUUycUMsYUFBYSxFQUFFO0VBQ3BELElBQUlkLEdBQUcsR0FBRzdwQyxJQUFJLENBQUM2cEMsR0FBRztJQUFFQyxVQUFVLEdBQUc5cEMsSUFBSSxDQUFDOHBDLFVBQVU7RUFDaEQsSUFBSWEsYUFBYSxDQUFDcEMsV0FBVyxFQUFFO0lBQzNCO0VBQ0o7RUFDQSxJQUFJQyxXQUFXLEdBQUdtQyxhQUFhLENBQUNuQyxXQUFXO0lBQUVvQyxZQUFZLEdBQUdELGFBQWEsQ0FBQ0MsWUFBWTtFQUN0RixJQUFJQyxTQUFTLEdBQUdyQyxXQUFXLENBQUN2aEIsT0FBTyxDQUFDLHFCQUFzQjJqQixZQUFZLENBQUMsSUFBSSxDQUFDO0VBQzVFLElBQUlDLFNBQVMsRUFBRTtJQUNYO0VBQ0o7RUFDQTtBQUNKO0FBQ0E7QUFDQTtFQUNJLFNBQVNDLFdBQVdBLENBQUNDLFVBQVUsRUFBRUMsVUFBVSxFQUFFO0lBQ3pDQyxhQUFhLENBQUNELFVBQVUsQ0FBQztJQUN6QjFtQyw4Q0FBRyxDQUFDNHFCLElBQUksQ0FBQywyQkFBMkIsQ0FBQztJQUNyQzZiLFVBQVUsQ0FBQ3pqQyxRQUFRLENBQUM0akMsTUFBTSxDQUFDLENBQUM7RUFDaEM7RUFDQSxJQUFJbEksTUFBTSxHQUFHeHBCLElBQUksQ0FBQ2xTLFFBQVEsQ0FBQzA3QixNQUFNLENBQUM1RCxXQUFXLENBQUMsQ0FBQztFQUMvQyxJQUFJK0wsVUFBVSxHQUFHbkksTUFBTSxDQUFDL2IsT0FBTyxDQUFDLDhCQUE4QixDQUFDLEtBQUssQ0FBQyxDQUFDO0VBQ3RFLElBQUlta0IsaUJBQWlCLEdBQUdwSSxNQUFNLENBQUMvYixPQUFPLENBQUMsc0NBQXNDLENBQUMsS0FBSyxDQUFDLENBQUM7RUFDckYsSUFBSTRpQixHQUFHLElBQUlzQixVQUFVLEVBQUU7SUFDbkI3bUMsOENBQUcsQ0FBQzRxQixJQUFJLENBQUMsbUJBQW1CLENBQUM7SUFDN0I4WSxrRUFBZSxDQUFDLGtCQUFrQixFQUFFMkMsYUFBYSxDQUFDbkMsV0FBVyxDQUFDO0lBQzlELElBQUksT0FBT2h2QixJQUFJLEtBQUssV0FBVyxJQUFJQSxJQUFJLENBQUNoYSxNQUFNLEVBQUU7TUFDNUM7TUFDQWdhLElBQUksQ0FBQzNDLFdBQVcsQ0FBQyxrQkFBa0IsQ0FBQ2hYLE1BQU0sQ0FBQzhxQyxhQUFhLENBQUNuQyxXQUFXLENBQUMsRUFBRSxHQUFHLENBQUM7SUFDL0U7RUFDSjtFQUNBO0VBQUEsS0FDSyxJQUFJc0IsVUFBVSxJQUFJc0IsaUJBQWlCLEVBQUU7SUFDdEMsSUFBSUwsVUFBVSxHQUFHdnhCLElBQUk7SUFDckI7SUFDQSxJQUFJd3hCLFVBQVUsR0FBR3h4QixJQUFJLENBQUM2eEIsV0FBVyxDQUFDLFlBQVk7TUFDMUMsSUFBSU4sVUFBVSxDQUFDempDLFFBQVEsQ0FBQ2drQyxRQUFRLEtBQUssUUFBUSxFQUFFO1FBQzNDO1FBQ0FSLFdBQVcsQ0FBQ0MsVUFBVSxFQUFFQyxVQUFVLENBQUM7TUFDdkMsQ0FBQyxNQUNJO1FBQ0RELFVBQVUsR0FBR0EsVUFBVSxDQUFDUSxNQUFNO1FBQzlCLElBQUlSLFVBQVUsQ0FBQ1EsTUFBTSxLQUFLUixVQUFVLEVBQUU7VUFDbEM7VUFDQUQsV0FBVyxDQUFDQyxVQUFVLEVBQUVDLFVBQVUsQ0FBQztRQUN2QztNQUNKO0lBQ0osQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0QsSUFBSVEsU0FBUyxHQUFHLElBQUkzb0MsTUFBTSxDQUFDLENBQUMsOEhBQThILEVBQUUsMERBQTBELENBQUMsQ0FBQzJjLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxHQUFHLENBQUM7QUFDdk87QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSWlzQixTQUFTLEdBQUcsU0FBU0EsU0FBU0EsQ0FBQ0MsTUFBTSxFQUFFO0VBQ3ZDLElBQUksT0FBT0EsTUFBTSxLQUFLLFFBQVEsRUFBRTtJQUM1QixNQUFNLElBQUlyeUIsU0FBUyxDQUFDLDRCQUE0QixDQUFDeFosTUFBTSxDQUFDb3RCLE9BQU8sQ0FBQ3llLE1BQU0sQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0VBQ2xGO0VBQ0EsT0FBT0EsTUFBTSxDQUFDanNCLE9BQU8sQ0FBQytyQixTQUFTLEVBQUUsRUFBRSxDQUFDO0FBQ3hDLENBQUM7QUFDRCxJQUFJRyxlQUFlLEdBQUc7RUFDbEI5QixHQUFHLEVBQUUsU0FBU0EsR0FBR0EsQ0FBQSxFQUFHO0lBQ2hCLElBQUlMLG1CQUFtQixDQUFDSyxHQUFHLEtBQUssT0FBTyxFQUFFO01BQ3JDO0lBQ0o7SUFDQXpWLE9BQU8sQ0FBQ3lWLEdBQUcsR0FBRyxJQUFJO0VBQ3RCLENBQUM7RUFDREMsVUFBVSxFQUFFLFNBQVNBLFVBQVVBLENBQUEsRUFBRztJQUM5QixJQUFJTixtQkFBbUIsQ0FBQyxhQUFhLENBQUMsS0FBSyxPQUFPLEVBQUU7TUFDaEQ7SUFDSjtJQUNBcFYsT0FBTyxDQUFDMFYsVUFBVSxHQUFHLElBQUk7RUFDN0IsQ0FBQztFQUNEOEIsT0FBTyxFQUFFLFNBQVNBLE9BQU9BLENBQUEsRUFBRztJQUN4QnRuQyw4Q0FBRyxDQUFDNHFCLElBQUksQ0FBQyw2QkFBNkIsQ0FBQztJQUN2QztJQUNBLElBQUlrRixPQUFPLENBQUM0VixPQUFPLEVBQUU7TUFDakJBLE9BQU8sQ0FBQ3pULElBQUksQ0FBQztRQUNUek0sSUFBSSxFQUFFO01BQ1YsQ0FBQyxDQUFDO0lBQ047SUFDQW1lLGlFQUFXLENBQUMsU0FBUyxDQUFDO0VBQzFCLENBQUM7RUFDRDtBQUNKO0FBQ0E7RUFDSXBGLElBQUksRUFBRSxTQUFTQSxJQUFJQSxDQUFDZ0osS0FBSyxFQUFFO0lBQ3ZCbGMsTUFBTSxDQUFDaWIsWUFBWSxHQUFHamIsTUFBTSxDQUFDNlksV0FBVztJQUN4QzdZLE1BQU0sQ0FBQzZZLFdBQVcsR0FBR3FELEtBQUs7RUFDOUIsQ0FBQztFQUNEekIsT0FBTyxFQUFFQyxjQUFjO0VBQ3ZCO0FBQ0o7QUFDQTtFQUNJTCxPQUFPLEVBQUUsU0FBU0EsT0FBT0EsQ0FBQzVnQyxLQUFLLEVBQUU7SUFDN0IsSUFBSSxPQUFPM0csUUFBUSxLQUFLLFdBQVcsRUFBRTtNQUNqQztJQUNKO0lBQ0EyeEIsT0FBTyxDQUFDNFYsT0FBTyxHQUFHNWdDLEtBQUs7SUFDdkI4K0Isb0JBQW9CLENBQUM5VCxPQUFPLENBQUM0VixPQUFPLENBQUM7RUFDekMsQ0FBQztFQUNEO0FBQ0o7QUFDQTtFQUNJdEosU0FBUyxFQUFFLFNBQVNBLFNBQVNBLENBQUN0M0IsS0FBSyxFQUFFO0lBQ2pDLElBQUlvZ0MsbUJBQW1CLENBQUM5SSxTQUFTLEtBQUssT0FBTyxFQUFFO01BQzNDO0lBQ0o7SUFDQXRNLE9BQU8sQ0FBQ3NNLFNBQVMsR0FBR3QzQixLQUFLO0VBQzdCLENBQUM7RUFDRDtBQUNKO0FBQ0E7RUFDSTJnQyxRQUFRLEVBQUUsU0FBU0EsUUFBUUEsQ0FBQzNnQyxLQUFLLEVBQUU7SUFDL0JnckIsT0FBTyxDQUFDMlYsUUFBUSxHQUFHM2dDLEtBQUs7RUFDNUIsQ0FBQztFQUNEO0FBQ0o7QUFDQTtFQUNJLGlCQUFpQixFQUFFLFNBQVMwaUMsY0FBY0EsQ0FBQ25nQyxJQUFJLEVBQUU7SUFDN0MsSUFBSXlvQixPQUFPLENBQUMyVixRQUFRLEVBQUU7TUFDbEJ6bEMsOENBQUcsQ0FBQzRxQixJQUFJLENBQUMsRUFBRSxDQUFDcnZCLE1BQU0sQ0FBQzhMLElBQUksQ0FBQ29nQyxVQUFVLEdBQUcsR0FBRyxDQUFDbHNDLE1BQU0sQ0FBQzhMLElBQUksQ0FBQ29nQyxVQUFVLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUNsc0MsTUFBTSxDQUFDOEwsSUFBSSxDQUFDOHpCLE9BQU8sRUFBRSxNQUFNLENBQUMsQ0FBQzUvQixNQUFNLENBQUM4TCxJQUFJLENBQUM2VyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDcEk7SUFDQSxJQUFJb2IsaUVBQW1CLENBQUMsQ0FBQyxFQUFFO01BQ3ZCLElBQUksT0FBT3hKLE9BQU8sQ0FBQzJWLFFBQVEsS0FBSyxRQUFRLEVBQUU7UUFDdEMsSUFBSUEsUUFBUSxHQUFHdG5DLFFBQVEsQ0FBQ2k5QixhQUFhLENBQUMsY0FBYyxDQUFDO1FBQ3JELElBQUksQ0FBQ3FLLFFBQVEsRUFBRTtVQUNYaE0sbUVBQXFCLENBQUMsQ0FBQztVQUN2QmdNLFFBQVEsR0FBR3RuQyxRQUFRLENBQUNtUixhQUFhLENBQUMsY0FBYyxDQUFDO1VBQ2pEblIsUUFBUSxDQUFDaUwsSUFBSSxDQUFDeUcsV0FBVyxDQUFDNDFCLFFBQVEsQ0FBQztRQUN2QztRQUNBQSxRQUFRLENBQUMvTixZQUFZLENBQUMsVUFBVSxFQUFFcndCLElBQUksQ0FBQzh6QixPQUFPLENBQUM7UUFDL0NzSyxRQUFRLENBQUMvTixZQUFZLENBQUMsTUFBTSxFQUFFNUgsT0FBTyxDQUFDMlYsUUFBUSxDQUFDO01BQ25EO0lBQ0o7SUFDQTlCLGlFQUFXLENBQUMsVUFBVSxFQUFFdDhCLElBQUksQ0FBQztFQUNqQyxDQUFDO0VBQ0QsVUFBVSxFQUFFLFNBQVNxZ0MsT0FBT0EsQ0FBQSxFQUFHO0lBQzNCMW5DLDhDQUFHLENBQUM0cUIsSUFBSSxDQUFDLGtCQUFrQixDQUFDO0lBQzVCLElBQUlrRixPQUFPLENBQUM0VixPQUFPLEVBQUU7TUFDakJBLE9BQU8sQ0FBQ3pULElBQUksQ0FBQztRQUNUek0sSUFBSSxFQUFFO01BQ1YsQ0FBQyxDQUFDO0lBQ047SUFDQW1lLGlFQUFXLENBQUMsU0FBUyxDQUFDO0VBQzFCLENBQUM7RUFDRGdFLEVBQUUsRUFBRSxTQUFTQSxFQUFFQSxDQUFBLEVBQUc7SUFDZGhFLGlFQUFXLENBQUMsSUFBSSxDQUFDO0lBQ2pCLElBQUk3VCxPQUFPLENBQUM0VixPQUFPLEVBQUU7TUFDakJBLE9BQU8sQ0FBQ3pULElBQUksQ0FBQztRQUNUek0sSUFBSSxFQUFFO01BQ1YsQ0FBQyxDQUFDO0lBQ047SUFDQTRnQixTQUFTLENBQUN0VyxPQUFPLEVBQUV6RSxNQUFNLENBQUM7RUFDOUIsQ0FBQztFQUNEO0FBQ0o7QUFDQTtFQUNJLGdCQUFnQixFQUFFLFNBQVN1YyxhQUFhQSxDQUFDcFMsSUFBSSxFQUFFO0lBQzNDeDFCLDhDQUFHLENBQUM0cUIsSUFBSSxDQUFDLEVBQUUsQ0FBQ3J2QixNQUFNLENBQUNpNkIsSUFBSSxHQUFHLElBQUksQ0FBQ2o2QixNQUFNLENBQUNpNkIsSUFBSSxFQUFFLElBQUksQ0FBQyxHQUFHLFNBQVMsRUFBRSxrREFBa0QsQ0FBQyxDQUFDO0lBQ25IdGdCLElBQUksQ0FBQ2xTLFFBQVEsQ0FBQzRqQyxNQUFNLENBQUMsQ0FBQztFQUMxQixDQUFDO0VBQ0Q7QUFDSjtBQUNBO0FBQ0E7RUFDSWhCLFFBQVEsRUFBRSxTQUFTQSxRQUFRQSxDQUFDaUMsU0FBUyxFQUFFckwsTUFBTSxFQUFFO0lBQzNDeDhCLDhDQUFHLENBQUNGLElBQUksQ0FBQywyQkFBMkIsQ0FBQztJQUNyQyxJQUFJZ29DLGlCQUFpQixHQUFHRCxTQUFTLENBQUNuZ0MsR0FBRyxDQUFDLFVBQVVnSSxLQUFLLEVBQUU7TUFDbkQsSUFBSThuQixjQUFjLEdBQUdsQywwREFBYSxDQUFDLFNBQVMsRUFBRTVsQixLQUFLLENBQUM7UUFBRTZsQixNQUFNLEdBQUdpQyxjQUFjLENBQUNqQyxNQUFNO1FBQUVuc0IsSUFBSSxHQUFHb3VCLGNBQWMsQ0FBQ3B1QixJQUFJO01BQ2hILE9BQU8sRUFBRSxDQUFDN04sTUFBTSxDQUFDZzZCLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQ2g2QixNQUFNLENBQUM0ckMsU0FBUyxDQUFDLzlCLElBQUksQ0FBQyxDQUFDO0lBQzFELENBQUMsQ0FBQztJQUNGdTZCLGlFQUFXLENBQUMsVUFBVSxFQUFFbUUsaUJBQWlCLENBQUM7SUFDMUMsS0FBSyxJQUFJbDJCLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR2syQixpQkFBaUIsQ0FBQzFvQyxNQUFNLEVBQUV3UyxDQUFDLEVBQUUsRUFBRTtNQUMvQzVSLDhDQUFHLENBQUNGLElBQUksQ0FBQ2dvQyxpQkFBaUIsQ0FBQ2wyQixDQUFDLENBQUMsQ0FBQztJQUNsQztJQUNBLElBQUltMkIsc0JBQXNCLEdBQUcsT0FBT2pZLE9BQU8sQ0FBQzRWLE9BQU8sS0FBSyxTQUFTLEdBQUc1VixPQUFPLENBQUM0VixPQUFPLEdBQUc1VixPQUFPLENBQUM0VixPQUFPLElBQUk1VixPQUFPLENBQUM0VixPQUFPLENBQUNFLFFBQVE7SUFDakksSUFBSW1DLHNCQUFzQixFQUFFO01BQ3hCLElBQUlDLGlCQUFpQixHQUFHLE9BQU9ELHNCQUFzQixLQUFLLFVBQVUsR0FBR0YsU0FBUyxDQUFDMS9CLE1BQU0sQ0FBQzQvQixzQkFBc0IsQ0FBQyxHQUFHRixTQUFTO01BQzNILElBQUlHLGlCQUFpQixDQUFDNW9DLE1BQU0sRUFBRTtRQUMxQnNtQyxPQUFPLENBQUN6VCxJQUFJLENBQUM7VUFDVHpNLElBQUksRUFBRSxhQUFhO1VBQ25CaUosS0FBSyxFQUFFLFNBQVM7VUFDaEJrRSxRQUFRLEVBQUVrVjtRQUNkLENBQUMsQ0FBQztNQUNOO0lBQ0o7SUFDQSxJQUFJckwsTUFBTSxJQUFJQSxNQUFNLENBQUN5TCxnQkFBZ0IsRUFBRTtNQUNuQztJQUNKO0lBQ0E3QixTQUFTLENBQUN0VyxPQUFPLEVBQUV6RSxNQUFNLENBQUM7RUFDOUIsQ0FBQztFQUNEO0FBQ0o7QUFDQTtFQUNJc2EsTUFBTSxFQUFFLFNBQVNBLE1BQU1BLENBQUN1QyxPQUFPLEVBQUU7SUFDN0Jsb0MsOENBQUcsQ0FBQzBQLEtBQUssQ0FBQywyQ0FBMkMsQ0FBQztJQUN0RCxJQUFJeTRCLGVBQWUsR0FBR0QsT0FBTyxDQUFDeGdDLEdBQUcsQ0FBQyxVQUFVZ0ksS0FBSyxFQUFFO01BQy9DLElBQUkwNEIsZUFBZSxHQUFHOVMsMERBQWEsQ0FBQyxPQUFPLEVBQUU1bEIsS0FBSyxDQUFDO1FBQUU2bEIsTUFBTSxHQUFHNlMsZUFBZSxDQUFDN1MsTUFBTTtRQUFFbnNCLElBQUksR0FBR2cvQixlQUFlLENBQUNoL0IsSUFBSTtNQUNqSCxPQUFPLEVBQUUsQ0FBQzdOLE1BQU0sQ0FBQ2c2QixNQUFNLEVBQUUsSUFBSSxDQUFDLENBQUNoNkIsTUFBTSxDQUFDNHJDLFNBQVMsQ0FBQy85QixJQUFJLENBQUMsQ0FBQztJQUMxRCxDQUFDLENBQUM7SUFDRnU2QixpRUFBVyxDQUFDLFFBQVEsRUFBRXdFLGVBQWUsQ0FBQztJQUN0QyxLQUFLLElBQUl2MkIsQ0FBQyxHQUFHLENBQUMsRUFBRUEsQ0FBQyxHQUFHdTJCLGVBQWUsQ0FBQy9vQyxNQUFNLEVBQUV3UyxDQUFDLEVBQUUsRUFBRTtNQUM3QzVSLDhDQUFHLENBQUMwUCxLQUFLLENBQUN5NEIsZUFBZSxDQUFDdjJCLENBQUMsQ0FBQyxDQUFDO0lBQ2pDO0lBQ0EsSUFBSXkyQixxQkFBcUIsR0FBRyxPQUFPdlksT0FBTyxDQUFDNFYsT0FBTyxLQUFLLFNBQVMsR0FBRzVWLE9BQU8sQ0FBQzRWLE9BQU8sR0FBRzVWLE9BQU8sQ0FBQzRWLE9BQU8sSUFBSTVWLE9BQU8sQ0FBQzRWLE9BQU8sQ0FBQ0MsTUFBTTtJQUM5SCxJQUFJMEMscUJBQXFCLEVBQUU7TUFDdkIsSUFBSUMsZUFBZSxHQUFHLE9BQU9ELHFCQUFxQixLQUFLLFVBQVUsR0FBR0gsT0FBTyxDQUFDLy9CLE1BQU0sQ0FBQ2tnQyxxQkFBcUIsQ0FBQyxHQUFHSCxPQUFPO01BQ25ILElBQUlJLGVBQWUsQ0FBQ2xwQyxNQUFNLEVBQUU7UUFDeEJzbUMsT0FBTyxDQUFDelQsSUFBSSxDQUFDO1VBQ1R6TSxJQUFJLEVBQUUsYUFBYTtVQUNuQmlKLEtBQUssRUFBRSxPQUFPO1VBQ2RrRSxRQUFRLEVBQUV1VjtRQUNkLENBQUMsQ0FBQztNQUNOO0lBQ0o7RUFDSixDQUFDO0VBQ0Q7QUFDSjtBQUNBO0VBQ0l4NEIsS0FBSyxFQUFFLFNBQVNBLEtBQUtBLENBQUM2NEIsTUFBTSxFQUFFO0lBQzFCdm9DLDhDQUFHLENBQUMwUCxLQUFLLENBQUM2NEIsTUFBTSxDQUFDO0VBQ3JCLENBQUM7RUFDRC9rQixLQUFLLEVBQUUsU0FBU0EsS0FBS0EsQ0FBQSxFQUFHO0lBQ3BCeGpCLDhDQUFHLENBQUM0cUIsSUFBSSxDQUFDLGVBQWUsQ0FBQztJQUN6QixJQUFJa0YsT0FBTyxDQUFDNFYsT0FBTyxFQUFFO01BQ2pCQSxPQUFPLENBQUN6VCxJQUFJLENBQUM7UUFDVHpNLElBQUksRUFBRTtNQUNWLENBQUMsQ0FBQztJQUNOO0lBQ0FtZSxpRUFBVyxDQUFDLE9BQU8sQ0FBQztFQUN4QjtBQUNKLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUk2RSxTQUFTLEdBQUcsU0FBU0EsU0FBU0EsQ0FBQ0MsTUFBTSxFQUFFO0VBQ3ZDLElBQUl6QixRQUFRLEdBQUd5QixNQUFNLENBQUN6QixRQUFRLElBQUksRUFBRTtFQUNwQyxJQUFJQSxRQUFRLElBQUlBLFFBQVEsQ0FBQzBCLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtJQUN6QzFCLFFBQVEsSUFBSSxHQUFHO0VBQ25CO0VBQ0EsSUFBSTJCLElBQUksR0FBR0YsTUFBTSxDQUFDRSxJQUFJLElBQUksRUFBRTtFQUM1QixJQUFJQSxJQUFJLEVBQUU7SUFDTkEsSUFBSSxHQUFHQyxrQkFBa0IsQ0FBQ0QsSUFBSSxDQUFDO0lBQy9CQSxJQUFJLEdBQUdBLElBQUksQ0FBQ3h0QixPQUFPLENBQUMsTUFBTSxFQUFFLEdBQUcsQ0FBQztJQUNoQ3d0QixJQUFJLElBQUksR0FBRztFQUNmO0VBQ0EsSUFBSTFsQyxJQUFJLEdBQUcsRUFBRTtFQUNiLElBQUl3bEMsTUFBTSxDQUFDSSxRQUFRLEVBQUU7SUFDakI1bEMsSUFBSSxHQUFHMGxDLElBQUksSUFBSUYsTUFBTSxDQUFDSSxRQUFRLENBQUNsbUIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsQ0FBQyxHQUFHOGxCLE1BQU0sQ0FBQ0ksUUFBUSxHQUFHLEdBQUcsQ0FBQ3R0QyxNQUFNLENBQUNrdEMsTUFBTSxDQUFDSSxRQUFRLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDeEcsSUFBSUosTUFBTSxDQUFDSyxJQUFJLEVBQUU7TUFDYjdsQyxJQUFJLElBQUksR0FBRyxDQUFDMUgsTUFBTSxDQUFDa3RDLE1BQU0sQ0FBQ0ssSUFBSSxDQUFDO0lBQ25DO0VBQ0o7RUFDQSxJQUFJQyxRQUFRLEdBQUdOLE1BQU0sQ0FBQ00sUUFBUSxJQUFJLEVBQUU7RUFDcEMsSUFBSU4sTUFBTSxDQUFDTyxPQUFPLEVBQUU7SUFDaEIvbEMsSUFBSSxHQUFHLElBQUksQ0FBQzFILE1BQU0sQ0FBQzBILElBQUksSUFBSSxFQUFFLENBQUM7SUFDOUIsSUFBSThsQyxRQUFRLElBQUlBLFFBQVEsQ0FBQ2h0QyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssR0FBRyxFQUFFO01BQ3hDZ3RDLFFBQVEsR0FBRyxHQUFHLENBQUN4dEMsTUFBTSxDQUFDd3RDLFFBQVEsQ0FBQztJQUNuQztFQUNKLENBQUMsTUFDSSxJQUFJLENBQUM5bEMsSUFBSSxFQUFFO0lBQ1pBLElBQUksR0FBRyxFQUFFO0VBQ2I7RUFDQSxJQUFJeTdCLE1BQU0sR0FBRytKLE1BQU0sQ0FBQy9KLE1BQU0sSUFBSSxFQUFFO0VBQ2hDLElBQUlBLE1BQU0sSUFBSUEsTUFBTSxDQUFDM2lDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLEVBQUU7SUFDcEMyaUMsTUFBTSxHQUFHLEdBQUcsQ0FBQ25qQyxNQUFNLENBQUNtakMsTUFBTSxDQUFDO0VBQy9CO0VBQ0EsSUFBSUgsSUFBSSxHQUFHa0ssTUFBTSxDQUFDbEssSUFBSSxJQUFJLEVBQUU7RUFDNUIsSUFBSUEsSUFBSSxJQUFJQSxJQUFJLENBQUN4aUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEdBQUcsRUFBRTtJQUNoQ3dpQyxJQUFJLEdBQUcsR0FBRyxDQUFDaGpDLE1BQU0sQ0FBQ2dqQyxJQUFJLENBQUM7RUFDM0I7RUFDQXdLLFFBQVEsR0FBR0EsUUFBUSxDQUFDNXRCLE9BQU8sQ0FBQyxPQUFPO0VBQ25DO0FBQ0o7QUFDQTtBQUNBO0VBQ0ksVUFBVXJHLEtBQUssRUFBRTtJQUNiLE9BQU84ekIsa0JBQWtCLENBQUM5ekIsS0FBSyxDQUFDO0VBQ3BDLENBQUMsQ0FBQztFQUNGNHBCLE1BQU0sR0FBR0EsTUFBTSxDQUFDdmpCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsS0FBSyxDQUFDO0VBQ25DLE9BQU8sRUFBRSxDQUFDNWYsTUFBTSxDQUFDeXJDLFFBQVEsQ0FBQyxDQUFDenJDLE1BQU0sQ0FBQzBILElBQUksQ0FBQyxDQUFDMUgsTUFBTSxDQUFDd3RDLFFBQVEsQ0FBQyxDQUFDeHRDLE1BQU0sQ0FBQ21qQyxNQUFNLENBQUMsQ0FBQ25qQyxNQUFNLENBQUNnakMsSUFBSSxDQUFDO0FBQ3hGLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUkwSyxlQUFlLEdBQUcsU0FBU0EsZUFBZUEsQ0FBQ0MsU0FBUyxFQUFFO0VBQ3RELElBQUlMLFFBQVEsR0FBR0ssU0FBUyxDQUFDTCxRQUFRO0VBQ2pDO0VBQ0E7RUFDQSxJQUFJTSxXQUFXLEdBQUdOLFFBQVEsS0FBSyxTQUFTLElBQUlBLFFBQVEsS0FBSyxJQUFJLElBQUlBLFFBQVEsS0FBSyxNQUFNO0VBQ3BGO0VBQ0E7RUFDQTtFQUNBLElBQUlNLFdBQVcsSUFBSWowQixJQUFJLENBQUNsUyxRQUFRLENBQUM2bEMsUUFBUSxJQUFJM3pCLElBQUksQ0FBQ2xTLFFBQVEsQ0FBQ2drQyxRQUFRLENBQUNya0IsT0FBTyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRTtJQUN2RmttQixRQUFRLEdBQUczekIsSUFBSSxDQUFDbFMsUUFBUSxDQUFDNmxDLFFBQVE7RUFDckM7RUFDQSxJQUFJTyxpQkFBaUIsR0FBR0YsU0FBUyxDQUFDbEMsUUFBUSxJQUFJOXhCLElBQUksQ0FBQ2xTLFFBQVEsQ0FBQ2drQyxRQUFRO0VBQ3BFO0VBQ0EsSUFBSW9DLGlCQUFpQixLQUFLLE9BQU8sSUFBSVAsUUFBUSxJQUFJTSxXQUFXLElBQUlqMEIsSUFBSSxDQUFDbFMsUUFBUSxDQUFDZ2tDLFFBQVEsS0FBSyxRQUFRLEVBQUU7SUFDakdvQyxpQkFBaUIsR0FBR2wwQixJQUFJLENBQUNsUyxRQUFRLENBQUNna0MsUUFBUTtFQUM5QztFQUNBb0MsaUJBQWlCLEdBQUdBLGlCQUFpQixDQUFDanVCLE9BQU8sQ0FBQyw4QkFBOEIsRUFBRSxJQUFJLENBQUM7RUFDbkYsSUFBSWt1QixhQUFhLEdBQUcsRUFBRTtFQUN0QjtFQUNBO0VBQ0EsSUFBSUgsU0FBUyxDQUFDSSxRQUFRLEVBQUU7SUFDcEJELGFBQWEsR0FBR0gsU0FBUyxDQUFDSSxRQUFRO0lBQ2xDO0lBQ0E7SUFDQSxJQUFJSixTQUFTLENBQUNLLFFBQVEsRUFBRTtNQUNwQjtNQUNBRixhQUFhLEdBQUdBLGFBQWEsQ0FBQzl0QyxNQUFNLENBQUMsR0FBRyxFQUFFMnRDLFNBQVMsQ0FBQ0ssUUFBUSxDQUFDO0lBQ2pFO0VBQ0o7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBO0VBQ0EsSUFBSUMsaUJBQWlCLEdBQUcsQ0FBQ1gsUUFBUSxJQUFJM3pCLElBQUksQ0FBQ2xTLFFBQVEsQ0FBQzZsQyxRQUFRLElBQUksV0FBVyxFQUFFMXRCLE9BQU8sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDO0VBQ3ZHLElBQUlzdUIsYUFBYSxHQUFHUCxTQUFTLENBQUNKLElBQUk7RUFDbEMsSUFBSSxDQUFDVyxhQUFhLElBQUlBLGFBQWEsS0FBSyxHQUFHLEVBQUU7SUFDekNBLGFBQWEsR0FBR3YwQixJQUFJLENBQUNsUyxRQUFRLENBQUM4bEMsSUFBSTtFQUN0QztFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlZLGlCQUFpQixHQUFHLEtBQUs7RUFDN0IsSUFBSVIsU0FBUyxDQUFDSCxRQUFRLElBQUksQ0FBQ0csU0FBUyxDQUFDakUsaUJBQWlCLEVBQUU7SUFDcER5RSxpQkFBaUIsR0FBR1IsU0FBUyxDQUFDSCxRQUFRO0VBQzFDO0VBQ0EsT0FBT1AsU0FBUyxDQUFDO0lBQ2J4QixRQUFRLEVBQUVvQyxpQkFBaUI7SUFDM0JULElBQUksRUFBRVUsYUFBYTtJQUNuQlIsUUFBUSxFQUFFVyxpQkFBaUI7SUFDM0JWLElBQUksRUFBRVcsYUFBYTtJQUNuQlYsUUFBUSxFQUFFVyxpQkFBaUI7SUFDM0JWLE9BQU8sRUFBRTtFQUNiLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxJQUFJVyxTQUFTLEdBQUdWLGVBQWUsQ0FBQy9ELG1CQUFtQixDQUFDO0FBQ3BEakosc0RBQU0sQ0FBQzBOLFNBQVMsRUFBRXRDLGVBQWUsRUFBRXZYLE9BQU8sQ0FBQ3NNLFNBQVMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7QUMvakJLO0FBQ0s7QUFDL0QsSUFBTXdOLHFCQUFxQixHQUFJcGdDLFlBQVksSUFBSztFQUM1QyxPQUFRdE8sTUFBTSxDQUFDNEksUUFBUSxDQUFDK0ksTUFBTSxDQUFDd3lCLFFBQVEsQ0FBQ3dLLGlCQUFpQixJQUNyRHJnQyxZQUFZLENBQUM3SixLQUFLLElBQ2xCLENBQUNaLDZEQUFhLENBQUMsV0FBVyxFQUFFeUssWUFBWSxDQUFDLElBQ3pDLENBQUN5M0Isd0VBQWtCLENBQUNsQixNQUFNO0FBQ2xDLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQSxLQUFLcGtDLGlCQUFBLENBQUMsYUFBWTtFQUNkLElBQU02TixZQUFZLFNBQVNsSix5REFBUyxDQUFDLENBQUM7RUFDdEM7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlzcEMscUJBQXFCLENBQUNwZ0MsWUFBWSxDQUFDLEVBQUU7SUFDckMsS0FBSywydEJBRTRCLENBQUMzSCxJQUFJLENBQUM4RSxLQUFBO01BQUEsSUFBQztRQUFFbWpDO01BQWdCLENBQUMsR0FBQW5qQyxLQUFBO01BQUEsT0FBS21qQyxlQUFlLENBQUN0Z0MsWUFBWSxDQUFDO0lBQUEsRUFBQztFQUNsRyxDQUFDLE1BQ0ksSUFBSXkzQix3RUFBa0IsQ0FBQ2xCLE1BQU0sRUFBRTtJQUNoQyxLQUFLLDRoQkFFWSxDQUFDbCtCLElBQUksQ0FBQ3lHLEtBQUE7TUFBQSxJQUFDO1FBQUV5aEM7TUFBd0IsQ0FBQyxHQUFBemhDLEtBQUE7TUFBQSxPQUFLeWhDLHVCQUF1QixDQUFDLENBQUM7SUFBQSxFQUFDO0VBQ3RGLENBQUMsTUFDSTtJQUNELEtBQUssazFCQUUwQixDQUFDbG9DLElBQUksQ0FBQzhHLEtBQUE7TUFBQSxJQUFDO1FBQUVvaEM7TUFBd0IsQ0FBQyxHQUFBcGhDLEtBQUE7TUFBQSxPQUFLb2hDLHVCQUF1QixDQUFDLENBQUM7SUFBQSxFQUFDO0VBQ3BHO0FBQ0osQ0FBQyxFQUFFLENBQUMsQyIsInNvdXJjZXMiOlsid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL2F1cy9hcGkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vYXVzL2dldENvbnNlbnRTdGF0ZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9jbXAuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vZGlzYWJsZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9leGNsdXNpb25MaXN0LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL2dldENvbnNlbnRGb3IuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vZ2V0Q3VycmVudEZyYW1ld29yay5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9nZXRGcmFtZXdvcmsuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vaW5kZXguanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vaXNDb25zZW50T3JQYXkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vbGliL2RvbWFpbi5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9saWIvbWFyay5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9saWIvb3BoYW4uanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vbGliL3NpZ25hbHMuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vbGliL3NvdXJjZXBvaW50Q29uZmlnLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL21lcmdlVXNlckNvbnNlbnQuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vb25Db25zZW50LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL29uQ29uc2VudENoYW5nZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9zZXJ2ZXIuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vc291cmNlcG9pbnQuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vc3R1Yi5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9zdHViX2dwcF91c25hdC5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS9zdHViX3RjZnYyLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL3N0dWJfdXNwYXBpX2NjcGEuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vdGNmdjIvYXBpLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL3RjZnYyL2dldENvbnNlbnRTdGF0ZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2NvbnNlbnQtbWFuYWdlbWVudC1wbGF0Zm9ybS91c25hdC9hcGkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vdXNuYXQvZ2V0Q29uc2VudFN0YXRlLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL3ZlbmRvckRhdGFNYW5hZ2VyLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29uc2VudC1tYW5hZ2VtZW50LXBsYXRmb3JtL3ZlbmRvclN0b3JhZ2VJZHMuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vdmVuZG9ycy5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2Nvb2tpZXMvZ2V0Q29va2llLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29va2llcy9nZXRDb29raWVWYWx1ZXMuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb29raWVzL2dldFNob3J0RG9tYWluLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29va2llcy9tZW1vaXplZENvb2tpZXMuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9jb29raWVzL3JlbW92ZUNvb2tpZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2lzT2JqZWN0L2lzT2JqZWN0LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvaXNTdHJpbmcvaXNTdHJpbmcuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9pc1VuZGVmaW5lZC9pc1VuZGVmaW5lZC5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L2xvZ2dlci9sb2dnZXIuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9sb2dnZXIvc3RvcmFnZS1rZXkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9sb2dnZXIvc3Vic2NyaXB0aW9ucy5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L3BhY2thZ2UuanNvbi5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L3N0b3JhZ2Uvc3RvcmFnZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitzb3VyY2VAMTEuMS4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9zb3VyY2UvZGlzdC9mb3VuZGF0aW9ucy9fX2dlbmVyYXRlZF9fL2JyZWFrcG9pbnRzLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vYW5zaS1odG1sLWNvbW11bml0eUAwLjAuOC9ub2RlX21vZHVsZXMvYW5zaS1odG1sLWNvbW11bml0eS9pbmRleC5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2V2ZW50c0AzLjMuMC9ub2RlX21vZHVsZXMvZXZlbnRzL2V2ZW50cy5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3dlYnBhY2stZGV2LXNlcnZlckA1LjIuMl93ZWJwYWNrLWNsaUA2LjAuMV93ZWJwYWNrQDUuMTAxLjAvbm9kZV9tb2R1bGVzL3dlYnBhY2stZGV2LXNlcnZlci9jbGllbnQvY2xpZW50cy9XZWJTb2NrZXRDbGllbnQuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS93ZWJwYWNrLWRldi1zZXJ2ZXJANS4yLjJfd2VicGFjay1jbGlANi4wLjFfd2VicGFja0A1LjEwMS4wL25vZGVfbW9kdWxlcy93ZWJwYWNrLWRldi1zZXJ2ZXIvY2xpZW50L21vZHVsZXMvbG9nZ2VyL2luZGV4LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vd2VicGFjay1kZXYtc2VydmVyQDUuMi4yX3dlYnBhY2stY2xpQDYuMC4xX3dlYnBhY2tANS4xMDEuMC9ub2RlX21vZHVsZXMvd2VicGFjay1kZXYtc2VydmVyL2NsaWVudC9vdmVybGF5LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vd2VicGFjay1kZXYtc2VydmVyQDUuMi4yX3dlYnBhY2stY2xpQDYuMC4xX3dlYnBhY2tANS4xMDEuMC9ub2RlX21vZHVsZXMvd2VicGFjay1kZXYtc2VydmVyL2NsaWVudC9wcm9ncmVzcy5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3dlYnBhY2stZGV2LXNlcnZlckA1LjIuMl93ZWJwYWNrLWNsaUA2LjAuMV93ZWJwYWNrQDUuMTAxLjAvbm9kZV9tb2R1bGVzL3dlYnBhY2stZGV2LXNlcnZlci9jbGllbnQvc29ja2V0LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vd2VicGFjay1kZXYtc2VydmVyQDUuMi4yX3dlYnBhY2stY2xpQDYuMC4xX3dlYnBhY2tANS4xMDEuMC9ub2RlX21vZHVsZXMvd2VicGFjay1kZXYtc2VydmVyL2NsaWVudC91dGlscy9sb2cuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS93ZWJwYWNrLWRldi1zZXJ2ZXJANS4yLjJfd2VicGFjay1jbGlANi4wLjFfd2VicGFja0A1LjEwMS4wL25vZGVfbW9kdWxlcy93ZWJwYWNrLWRldi1zZXJ2ZXIvY2xpZW50L3V0aWxzL3NlbmRNZXNzYWdlLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vd2VicGFja0A1LjEwMS4wX3dlYnBhY2stY2xpQDYuMC4xL25vZGVfbW9kdWxlcy93ZWJwYWNrL2hvdC9lbWl0dGVyLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vd2VicGFja0A1LjEwMS4wX3dlYnBhY2stY2xpQDYuMC4xL25vZGVfbW9kdWxlcy93ZWJwYWNrL2hvdC9sb2cuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvZGV0ZWN0L2RldGVjdC1icmVha3BvaW50LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvZGV0ZWN0L2RldGVjdC12aWV3cG9ydC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlL3dlYnBhY2svcnVudGltZS9lbnN1cmUgY2h1bmsiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlL3dlYnBhY2svcnVudGltZS9nZXQgamF2YXNjcmlwdCBjaHVuayBmaWxlbmFtZSIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvd2VicGFjay9ydW50aW1lL2dldEZ1bGxIYXNoIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS93ZWJwYWNrL3J1bnRpbWUvZ2xvYmFsIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS93ZWJwYWNrL3J1bnRpbWUvbG9hZCBzY3JpcHQiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlL3dlYnBhY2svcnVudGltZS9wdWJsaWNQYXRoIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS93ZWJwYWNrL3J1bnRpbWUvanNvbnAgY2h1bmsgbG9hZGluZyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3dlYnBhY2stZGV2LXNlcnZlckA1LjIuMl93ZWJwYWNrLWNsaUA2LjAuMV93ZWJwYWNrQDUuMTAxLjAvbm9kZV9tb2R1bGVzL3dlYnBhY2stZGV2LXNlcnZlci9jbGllbnQvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2NvbW1lcmNpYWwudHMiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgYXBpID0gKGNvbW1hbmQpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBpZiAod2luZG93Ll9fdXNwYXBpKSB7XG4gICAgICAgIHdpbmRvdy5fX3VzcGFwaShjb21tYW5kLCAxLCAocmVzdWx0LCBzdWNjZXNzKSA9PiBzdWNjZXNzID8gcmVzb2x2ZShyZXN1bHQpIDogKFxuICAgICAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICAgICAgICByZWplY3QobmV3IEVycm9yKGBVbmFibGUgdG8gZ2V0ICR7Y29tbWFuZH0gZGF0YWApKSkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmVqZWN0KG5ldyBFcnJvcihcIk5vIF9fdXNwYXBpIGZvdW5kIG9uIHdpbmRvd1wiKSk7XG4gICAgfVxufSk7XG5jb25zdCBnZXRVU1BEYXRhID0gKCkgPT4gYXBpKFwiZ2V0VVNQRGF0YVwiKTtcbmV4cG9ydCB7IGdldFVTUERhdGEgfTtcbiIsImltcG9ydCB7IGdldFVTUERhdGEgfSBmcm9tICcuL2FwaS5qcyc7XG5jb25zdCBnZXRDb25zZW50U3RhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNwRGF0YSA9IGF3YWl0IGdldFVTUERhdGEoKTtcbiAgICBjb25zdCBvcHRlZE91dCA9IHVzcERhdGEudXNwU3RyaW5nLmNoYXJBdCgyKSA9PT0gXCJZXCI7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgcGVyc29uYWxpc2VkQWR2ZXJ0aXNpbmc6ICFvcHRlZE91dFxuICAgIH07XG59O1xuZXhwb3J0IHsgZ2V0Q29uc2VudFN0YXRlIH07XG4iLCJpbXBvcnQgeyBnZXRDdXJyZW50RnJhbWV3b3JrIH0gZnJvbSAnLi9nZXRDdXJyZW50RnJhbWV3b3JrLmpzJztcbmltcG9ydCB7IGdldElzQ29uc2VudE9yUGF5IH0gZnJvbSAnLi9pc0NvbnNlbnRPclBheS5qcyc7XG5pbXBvcnQgeyBtYXJrIH0gZnJvbSAnLi9saWIvbWFyay5qcyc7XG5pbXBvcnQgeyBQUklWQUNZX01BTkFHRVJfQVVTVFJBTElBLCBQUklWQUNZX01BTkFHRVJfVVNOQVQsIFBSSVZBQ1lfTUFOQUdFUl9UQ0ZWMiwgUFJJVkFDWV9NQU5BR0VSX1RDRlYyX0NPTlNFTlRfT1JfUEFZIH0gZnJvbSAnLi9saWIvc291cmNlcG9pbnRDb25maWcuanMnO1xuaW1wb3J0IHsgd2lsbFNob3dQcml2YWN5TWVzc2FnZSBhcyB3aWxsU2hvd1ByaXZhY3lNZXNzYWdlJDEsIGluaXQgYXMgaW5pdCQxIH0gZnJvbSAnLi9zb3VyY2Vwb2ludC5qcyc7XG5jb25zdCBpbml0ID0gKGZyYW1ld29yaywgY291bnRyeUNvZGUsIGlzVXNlclNpZ25lZEluLCB1c2VOb25BZHZlcnRpc2VkTGlzdCwgcHViRGF0YSkgPT4ge1xuICAgIG1hcmsoXCJjbXAtaW5pdFwiKTtcbiAgICBpbml0JDEoZnJhbWV3b3JrLCBjb3VudHJ5Q29kZSwgaXNVc2VyU2lnbmVkSW4sIHVzZU5vbkFkdmVydGlzZWRMaXN0LCBwdWJEYXRhKTtcbn07XG5jb25zdCB3aWxsU2hvd1ByaXZhY3lNZXNzYWdlID0gKCkgPT4gd2lsbFNob3dQcml2YWN5TWVzc2FnZSQxO1xuZnVuY3Rpb24gc2hvd1ByaXZhY3lNYW5hZ2VyKCkge1xuICAgIHN3aXRjaCAoZ2V0Q3VycmVudEZyYW1ld29yaygpKSB7XG4gICAgICAgIGNhc2UgXCJ0Y2Z2MlwiOlxuICAgICAgICAgICAgd2luZG93Ll9zcF8/LmdkcHI/LmxvYWRQcml2YWN5TWFuYWdlck1vZGFsPy4oZ2V0SXNDb25zZW50T3JQYXkoKSA/IFBSSVZBQ1lfTUFOQUdFUl9UQ0ZWMl9DT05TRU5UX09SX1BBWSA6IFBSSVZBQ1lfTUFOQUdFUl9UQ0ZWMik7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInVzbmF0XCI6XG4gICAgICAgICAgICB3aW5kb3cuX3NwXz8udXNuYXQ/LmxvYWRQcml2YWN5TWFuYWdlck1vZGFsPy4oUFJJVkFDWV9NQU5BR0VSX1VTTkFUKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiYXVzXCI6XG4gICAgICAgICAgICB3aW5kb3cuX3NwXz8uY2NwYT8ubG9hZFByaXZhY3lNYW5hZ2VyTW9kYWw/LihQUklWQUNZX01BTkFHRVJfQVVTVFJBTElBKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbn1cbmNvbnN0IENNUCA9IHtcbiAgICBpbml0LFxuICAgIHdpbGxTaG93UHJpdmFjeU1lc3NhZ2UsXG4gICAgc2hvd1ByaXZhY3lNYW5hZ2VyXG59O1xuZXhwb3J0IHsgQ01QIH07XG4iLCJjb25zdCBDT09LSUVfTkFNRSA9IFwiZ3UtY21wLWRpc2FibGVkXCI7XG5jb25zdCBkaXNhYmxlID0gKCkgPT4ge1xuICAgIGRvY3VtZW50LmNvb2tpZSA9IGAke0NPT0tJRV9OQU1FfT10cnVlYDtcbn07XG5jb25zdCBlbmFibGUgPSAoKSA9PiB7XG4gICAgZG9jdW1lbnQuY29va2llID0gYCR7Q09PS0lFX05BTUV9PWZhbHNlYDtcbn07XG5jb25zdCBpc0Rpc2FibGVkID0gKCkgPT4gbmV3IFJlZ0V4cChgJHtDT09LSUVfTkFNRX09dHJ1ZShcXFxcVyt8JClgKS50ZXN0KGRvY3VtZW50LmNvb2tpZSk7XG5leHBvcnQgeyBkaXNhYmxlLCBlbmFibGUsIGlzRGlzYWJsZWQgfTtcbiIsImNvbnN0IHNlY3Rpb25FeGNsdXNpb25MaXN0ID0gW1wiaW5mb1wiLCBcImhlbHBcIl07XG5jb25zdCBpc0V4Y2x1ZGVkRnJvbUNNUCA9IChwYWdlU2VjdGlvbikgPT4ge1xuICAgIHJldHVybiBzZWN0aW9uRXhjbHVzaW9uTGlzdC5zb21lKChzZWN0aW9uKSA9PiBzZWN0aW9uID09PSBwYWdlU2VjdGlvbik7XG59O1xuZXhwb3J0IHsgaXNFeGNsdWRlZEZyb21DTVAgfTtcbiIsImltcG9ydCB7IFZlbmRvcklEcyB9IGZyb20gJy4vdmVuZG9ycy5qcyc7XG5jb25zdCBnZXRDb25zZW50Rm9yID0gKHZlbmRvciwgY29uc2VudCkgPT4ge1xuICAgIGNvbnN0IHNvdXJjZXBvaW50SWRzID0gVmVuZG9ySURzW3ZlbmRvcl07XG4gICAgaWYgKHR5cGVvZiBzb3VyY2Vwb2ludElkcyA9PT0gXCJ1bmRlZmluZWRcIiB8fCBzb3VyY2Vwb2ludElkcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBWZW5kb3IgJyR7dmVuZG9yfScgbm90IGZvdW5kLCBvciB3aXRoIG5vIFNvdXJjZXBvaW50IElELiBJZiBpdCBzaG91bGQgYmUgYWRkZWQsIHJhaXNlIGFuIGlzc3VlIGF0IGh0dHBzOi8vZ2l0aHViLmNvbS9ndWFyZGlhbi9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm0vaXNzdWVzYCk7XG4gICAgfVxuICAgIGlmIChjb25zZW50LnVzbmF0KSB7XG4gICAgICAgIHJldHVybiAhY29uc2VudC51c25hdC5kb05vdFNlbGw7XG4gICAgfVxuICAgIGlmIChjb25zZW50LmF1cykge1xuICAgICAgICByZXR1cm4gY29uc2VudC5hdXMucGVyc29uYWxpc2VkQWR2ZXJ0aXNpbmc7XG4gICAgfVxuICAgIGNvbnN0IGZvdW5kU291cmNlcG9pbnRJZCA9IHNvdXJjZXBvaW50SWRzLmZpbmQoKGlkKSA9PiB0eXBlb2YgY29uc2VudC50Y2Z2Mj8udmVuZG9yQ29uc2VudHNbaWRdICE9PSBcInVuZGVmaW5lZFwiKTtcbiAgICBpZiAodHlwZW9mIGZvdW5kU291cmNlcG9pbnRJZCA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBjb25zb2xlLndhcm4oYE5vIGNvbnNlbnQgcmV0dXJuZWQgZnJvbSBTb3VyY2Vwb2ludCBmb3IgdmVuZG9yOiAnJHt2ZW5kb3J9J2ApO1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHRjZnYyQ29uc2VudCA9IGNvbnNlbnQudGNmdjI/LnZlbmRvckNvbnNlbnRzW2ZvdW5kU291cmNlcG9pbnRJZF07XG4gICAgaWYgKHR5cGVvZiB0Y2Z2MkNvbnNlbnQgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgY29uc29sZS53YXJuKGBObyBjb25zZW50IHJldHVybmVkIGZyb20gU291cmNlcG9pbnQgZm9yIHZlbmRvcjogJyR7dmVuZG9yfSdgKTtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICByZXR1cm4gdGNmdjJDb25zZW50O1xufTtcbmV4cG9ydCB7IGdldENvbnNlbnRGb3IgfTtcbiIsImltcG9ydCB7IGxvZyB9IGZyb20gJy4uL2xvZ2dlci9sb2dnZXIuanMnO1xubGV0IGN1cnJlbnRGcmFtZXdvcms7XG5jb25zdCBzZXRDdXJyZW50RnJhbWV3b3JrID0gKGZyYW1ld29yaykgPT4ge1xuICAgIGxvZyhcImNtcFwiLCBgRnJhbWV3b3JrIHNldCB0byAke2ZyYW1ld29ya31gKTtcbiAgICBjdXJyZW50RnJhbWV3b3JrID0gZnJhbWV3b3JrO1xufTtcbmNvbnN0IGdldEN1cnJlbnRGcmFtZXdvcmsgPSAoKSA9PiBjdXJyZW50RnJhbWV3b3JrO1xuZXhwb3J0IHsgZ2V0Q3VycmVudEZyYW1ld29yaywgc2V0Q3VycmVudEZyYW1ld29yayB9O1xuIiwiY29uc3QgZ2V0RnJhbWV3b3JrID0gKGNvdW50cnlDb2RlKSA9PiB7XG4gICAgbGV0IGZyYW1ld29yaztcbiAgICBzd2l0Y2ggKGNvdW50cnlDb2RlKSB7XG4gICAgICAgIGNhc2UgXCJVU1wiOlxuICAgICAgICAgICAgZnJhbWV3b3JrID0gXCJ1c25hdFwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJBVVwiOlxuICAgICAgICAgICAgZnJhbWV3b3JrID0gXCJhdXNcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiR0JcIjpcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIGZyYW1ld29yayA9IFwidGNmdjJcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICByZXR1cm4gZnJhbWV3b3JrO1xufTtcbmV4cG9ydCB7IGdldEZyYW1ld29yayB9O1xuIiwiaW1wb3J0IHsgdmVyc2lvbiB9IGZyb20gJy4uL3BhY2thZ2UuanNvbi5qcyc7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICcuLi9sb2dnZXIvbG9nZ2VyLmpzJztcbmltcG9ydCB7IENNUCB9IGZyb20gJy4vY21wLmpzJztcbmltcG9ydCB7IGRpc2FibGUsIGVuYWJsZSwgaXNEaXNhYmxlZCB9IGZyb20gJy4vZGlzYWJsZS5qcyc7XG5pbXBvcnQgeyBnZXRDb25zZW50Rm9yIGFzIGdldENvbnNlbnRGb3IkMiB9IGZyb20gJy4vZ2V0Q29uc2VudEZvci5qcyc7XG5pbXBvcnQgeyBnZXRGcmFtZXdvcmsgfSBmcm9tICcuL2dldEZyYW1ld29yay5qcyc7XG5pbXBvcnQgeyBvbkNvbnNlbnQgYXMgb25Db25zZW50JDIgfSBmcm9tICcuL29uQ29uc2VudC5qcyc7XG5pbXBvcnQgeyBvbkNvbnNlbnRDaGFuZ2UgYXMgb25Db25zZW50Q2hhbmdlJDIgfSBmcm9tICcuL29uQ29uc2VudENoYW5nZS5qcyc7XG5pbXBvcnQgeyBpc1NlcnZlclNpZGUsIGNtcCBhcyBjbXAkMSwgb25Db25zZW50IGFzIG9uQ29uc2VudCQxLCBvbkNvbnNlbnRDaGFuZ2UgYXMgb25Db25zZW50Q2hhbmdlJDEsIGdldENvbnNlbnRGb3IgYXMgZ2V0Q29uc2VudEZvciQxIH0gZnJvbSAnLi9zZXJ2ZXIuanMnO1xuaW1wb3J0IHsgaW5pdFZlbmRvckRhdGFNYW5hZ2VyIH0gZnJvbSAnLi92ZW5kb3JEYXRhTWFuYWdlci5qcyc7XG52YXIgX2EsIF9iLCBfYywgX2Q7XG5pZiAoIWlzU2VydmVyU2lkZSkge1xuICAgIGlmICh0eXBlb2Ygd2luZG93Lmd1Q21wSG90Rml4ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIHdpbmRvdy5ndUNtcEhvdEZpeCA9IHt9O1xuICAgIH1cbn1cbmxldCBfd2lsbFNob3dQcml2YWN5TWVzc2FnZTtcbmxldCBpbml0Q29tcGxldGUgPSBmYWxzZTtcbmxldCByZXNvbHZlSW5pdGlhbGlzZWQ7XG5jb25zdCBpbml0aWFsaXNlZCA9IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgcmVzb2x2ZUluaXRpYWxpc2VkID0gcmVzb2x2ZTtcbn0pO1xuY29uc3QgaW5pdCA9ICh7IHB1YkRhdGEsIGNvdW50cnksIGlzVXNlclNpZ25lZEluID0gZmFsc2UsIHVzZU5vbkFkdmVydGlzZWRMaXN0ID0gZmFsc2UgfSkgPT4ge1xuICAgIGlmIChpc0Rpc2FibGVkKCkgfHwgaXNTZXJ2ZXJTaWRlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHdpbmRvdy5ndUNtcEhvdEZpeC5pbml0aWFsaXNlZCkge1xuICAgICAgICBpZiAod2luZG93Lmd1Q21wSG90Rml4LmNtcD8udmVyc2lvbiAhPT0gdmVyc2lvbikge1xuICAgICAgICAgICAgY29uc29sZS53YXJuKFwiVHdvIGRpZmZlcmVudCB2ZXJzaW9ucyBvZiB0aGUgQ01QIGFyZSBydW5uaW5nOlwiLCBbXG4gICAgICAgICAgICAgICAgdmVyc2lvbixcbiAgICAgICAgICAgICAgICB3aW5kb3cuZ3VDbXBIb3RGaXguY21wPy52ZXJzaW9uXG4gICAgICAgICAgICBdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIHdpbmRvdy5ndUNtcEhvdEZpeC5pbml0aWFsaXNlZCA9IHRydWU7XG4gICAgaWYgKHR5cGVvZiBjb3VudHJ5ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIkNNUCBpbml0aWFsaXNlZCB3aXRob3V0IGBjb3VudHJ5YCBwcm9wZXJ0eS4gQSAyLWxldHRlciwgSVNPIElTT18zMTY2LTEgY291bnRyeSBjb2RlIGlzIHJlcXVpcmVkLlwiKTtcbiAgICB9XG4gICAgY29uc3QgZnJhbWV3b3JrID0gZ2V0RnJhbWV3b3JrKGNvdW50cnkpO1xuICAgIENNUC5pbml0KGZyYW1ld29yaywgY291bnRyeSwgaXNVc2VyU2lnbmVkSW4sIHVzZU5vbkFkdmVydGlzZWRMaXN0LCBwdWJEYXRhID8/IHt9KTtcbiAgICB2b2lkIENNUC53aWxsU2hvd1ByaXZhY3lNZXNzYWdlKCkudGhlbigod2lsbFNob3dWYWx1ZSkgPT4ge1xuICAgICAgICBfd2lsbFNob3dQcml2YWN5TWVzc2FnZSA9IHdpbGxTaG93VmFsdWU7XG4gICAgICAgIGluaXRDb21wbGV0ZSA9IHRydWU7XG4gICAgICAgIGxvZyhcImNtcFwiLCBcImluaXRDb21wbGV0ZVwiKTtcbiAgICB9KTtcbiAgICByZXNvbHZlSW5pdGlhbGlzZWQoKTtcbiAgICBpbml0VmVuZG9yRGF0YU1hbmFnZXIoKTtcbn07XG5jb25zdCB3aWxsU2hvd1ByaXZhY3lNZXNzYWdlID0gKCkgPT4gaW5pdGlhbGlzZWQudGhlbigoKSA9PiBDTVAud2lsbFNob3dQcml2YWN5TWVzc2FnZSgpKTtcbmNvbnN0IHdpbGxTaG93UHJpdmFjeU1lc3NhZ2VTeW5jID0gKCkgPT4ge1xuICAgIGlmIChfd2lsbFNob3dQcml2YWN5TWVzc2FnZSAhPT0gdm9pZCAwKSB7XG4gICAgICAgIHJldHVybiBfd2lsbFNob3dQcml2YWN5TWVzc2FnZTtcbiAgICB9XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiQ01QIGhhcyBub3QgYmVlbiBpbml0aWFsaXNlZC4gVXNlIHRoZSBhc3luYyB3aWxsU2hvd1ByaXZhY3lNZXNzYWdlKCkgaW5zdGVhZC5cIik7XG59O1xuY29uc3QgaGFzSW5pdGlhbGlzZWQgPSAoKSA9PiBpbml0Q29tcGxldGU7XG5jb25zdCBzaG93UHJpdmFjeU1hbmFnZXIgPSAoKSA9PiB7XG4gICAgdm9pZCBpbml0aWFsaXNlZC50aGVuKENNUC5zaG93UHJpdmFjeU1hbmFnZXIpO1xufTtcbmNvbnN0IGNtcCA9IGlzU2VydmVyU2lkZSA/IGNtcCQxIDogKF9hID0gd2luZG93Lmd1Q21wSG90Rml4KS5jbXAgPz8gKF9hLmNtcCA9IHtcbiAgICBpbml0LFxuICAgIHdpbGxTaG93UHJpdmFjeU1lc3NhZ2UsXG4gICAgd2lsbFNob3dQcml2YWN5TWVzc2FnZVN5bmMsXG4gICAgaGFzSW5pdGlhbGlzZWQsXG4gICAgc2hvd1ByaXZhY3lNYW5hZ2VyLFxuICAgIHZlcnNpb24sXG4gICAgLy8gc3BlY2lhbCBoZWxwZXIgbWV0aG9kcyBmb3IgZGlzYWJsaW5nIENNUFxuICAgIF9faXNEaXNhYmxlZDogaXNEaXNhYmxlZCxcbiAgICBfX2VuYWJsZTogZW5hYmxlLFxuICAgIF9fZGlzYWJsZTogZGlzYWJsZVxufSk7XG5jb25zdCBvbkNvbnNlbnQgPSBpc1NlcnZlclNpZGUgPyBvbkNvbnNlbnQkMSA6IChfYiA9IHdpbmRvdy5ndUNtcEhvdEZpeCkub25Db25zZW50ID8/IChfYi5vbkNvbnNlbnQgPSBvbkNvbnNlbnQkMik7XG5jb25zdCBvbkNvbnNlbnRDaGFuZ2UgPSBpc1NlcnZlclNpZGUgPyBvbkNvbnNlbnRDaGFuZ2UkMSA6IChfYyA9IHdpbmRvdy5ndUNtcEhvdEZpeCkub25Db25zZW50Q2hhbmdlID8/IChfYy5vbkNvbnNlbnRDaGFuZ2UgPSBvbkNvbnNlbnRDaGFuZ2UkMik7XG5jb25zdCBnZXRDb25zZW50Rm9yID0gaXNTZXJ2ZXJTaWRlID8gZ2V0Q29uc2VudEZvciQxIDogKF9kID0gd2luZG93Lmd1Q21wSG90Rml4KS5nZXRDb25zZW50Rm9yID8/IChfZC5nZXRDb25zZW50Rm9yID0gZ2V0Q29uc2VudEZvciQyKTtcbmV4cG9ydCB7IGNtcCwgZ2V0Q29uc2VudEZvciwgb25Db25zZW50LCBvbkNvbnNlbnRDaGFuZ2UgfTtcbiIsImltcG9ydCAnLi9zZXJ2ZXIuanMnO1xuaW1wb3J0IHsgY29uc2VudE9yUGF5Q291bnRyaWVzIH0gZnJvbSAnLi9saWIvc291cmNlcG9pbnRDb25maWcuanMnO1xubGV0IF9pc0NvbnNlbnRPclBheSA9IGZhbHNlO1xuY29uc3Qgc2V0SXNDb25zZW50T3JQYXkgPSAoaXNDb25zZW50T3JQYXkpID0+IHtcbiAgICBfaXNDb25zZW50T3JQYXkgPSBpc0NvbnNlbnRPclBheTtcbn07XG5jb25zdCBnZXRJc0NvbnNlbnRPclBheSA9ICgpID0+IHtcbiAgICByZXR1cm4gX2lzQ29uc2VudE9yUGF5O1xufTtcbmNvbnN0IGlzQ29uc2VudE9yUGF5Q291bnRyeSA9IChjb3VudHJ5Q29kZSkgPT4ge1xuICAgIHJldHVybiBjb25zZW50T3JQYXlDb3VudHJpZXMuaW5jbHVkZXMoY291bnRyeUNvZGUpO1xufTtcbmV4cG9ydCB7IGdldElzQ29uc2VudE9yUGF5LCBpc0NvbnNlbnRPclBheUNvdW50cnksIHNldElzQ29uc2VudE9yUGF5IH07XG4iLCJpbXBvcnQgeyBpc1NlcnZlclNpZGUgfSBmcm9tICcuLi9zZXJ2ZXIuanMnO1xubGV0IGlzR3VhcmRpYW47XG5jb25zdCBpc0d1YXJkaWFuRG9tYWluID0gKCkgPT4ge1xuICAgIGlmICh0eXBlb2YgaXNHdWFyZGlhbiA9PT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICBpZiAoaXNTZXJ2ZXJTaWRlKSB7XG4gICAgICAgICAgICBpc0d1YXJkaWFuID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGlzR3VhcmRpYW4gPSB3aW5kb3cubG9jYXRpb24uaG9zdC5lbmRzV2l0aChcIi50aGVndWFyZGlhbi5jb21cIik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGlzR3VhcmRpYW47XG59O1xuZXhwb3J0IHsgaXNHdWFyZGlhbkRvbWFpbiB9O1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnLi4vLi4vbG9nZ2VyL2xvZ2dlci5qcyc7XG5jb25zdCBtYXJrID0gKGxhYmVsKSA9PiB7XG4gICAgd2luZG93LnBlcmZvcm1hbmNlPy5tYXJrPy4obGFiZWwpO1xuICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gXCJ0ZXN0XCIpIHtcbiAgICAgICAgbG9nKFwiY21wXCIsIFwiW2V2ZW50XVwiLCBsYWJlbCk7XG4gICAgfVxufTtcbmV4cG9ydCB7IG1hcmsgfTtcbiIsImltcG9ydCB7IGdldElzQ29uc2VudE9yUGF5IH0gZnJvbSAnLi4vaXNDb25zZW50T3JQYXkuanMnO1xuaW1wb3J0IHsgU291cmNlUG9pbnRDaG9pY2VUeXBlcyB9IGZyb20gJy4vc291cmNlcG9pbnRDb25maWcuanMnO1xuY29uc3QgZ2V0T3BoYW5SZWNvcmRGdW5jdGlvbiA9ICgpID0+IHtcbiAgICBjb25zdCByZWNvcmQgPSB3aW5kb3cuZ3VhcmRpYW4/Lm9waGFuPy5yZWNvcmQ7XG4gICAgaWYgKHJlY29yZCkge1xuICAgICAgICByZXR1cm4gcmVjb3JkO1xuICAgIH1cbiAgICBjb25zb2xlLmxvZyhcIndpbmRvdy5ndWFyZGlhbi5vcGhhbi5yZWNvcmQgaXMgbm90IGF2YWlsYWJsZVwiKTtcbiAgICByZXR1cm4gKCkgPT4ge1xuICAgIH07XG59O1xuY29uc3QgY29uc3RydWN0QmFubmVyTWVzc2FnZUlkID0gKG1lc3NhZ2VJZCkgPT4ge1xuICAgIGNvbnN0IG1lc3NhZ2VUeXBlID0gZ2V0SXNDb25zZW50T3JQYXkoKSA/IFwiQ09OU0VOVF9PUl9QQVlfQkFOTkVSXCIgOiBcIkFDQ0VQVF9SRUpFQ1RcIjtcbiAgICByZXR1cm4gYCR7bWVzc2FnZVR5cGV9LSR7bWVzc2FnZUlkfWA7XG59O1xuY29uc3Qgc2VuZENvbnNlbnRDaG9pY2VzVG9PcGhhbiA9IChjaG9pY2VUeXBlLCBtZXNzYWdlSWQpID0+IHtcbiAgICBsZXQgYWN0aW9uVmFsdWU7XG4gICAgc3dpdGNoIChjaG9pY2VUeXBlKSB7XG4gICAgICAgIGNhc2UgU291cmNlUG9pbnRDaG9pY2VUeXBlcy5BY2NlcHRBbGw6XG4gICAgICAgICAgICBhY3Rpb25WYWx1ZSA9IFwiYWNjZXB0XCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBTb3VyY2VQb2ludENob2ljZVR5cGVzLlJlamVjdEFsbDpcbiAgICAgICAgICAgIGFjdGlvblZhbHVlID0gXCJyZWplY3RcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFNvdXJjZVBvaW50Q2hvaWNlVHlwZXMuRGlzbWlzczpcbiAgICAgICAgICAgIGFjdGlvblZhbHVlID0gXCJkaXNtaXNzXCI7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBTb3VyY2VQb2ludENob2ljZVR5cGVzLk1hbmFnZUNvb2tpZXM6XG4gICAgICAgICAgICBhY3Rpb25WYWx1ZSA9IFwibWFuYWdlLWNvb2tpZXNcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjb25zdCBjb21wb25lbnRFdmVudCA9IHtcbiAgICAgICAgY29tcG9uZW50OiB7XG4gICAgICAgICAgICBjb21wb25lbnRUeXBlOiBcIkNPTlNFTlRcIixcbiAgICAgICAgICAgIGlkOiBtZXNzYWdlSWRcbiAgICAgICAgfSxcbiAgICAgICAgYWN0aW9uOiBcIkNMSUNLXCIsXG4gICAgICAgIHZhbHVlOiBhY3Rpb25WYWx1ZVxuICAgIH07XG4gICAgY29uc3QgcmVjb3JkID0gZ2V0T3BoYW5SZWNvcmRGdW5jdGlvbigpO1xuICAgIHJlY29yZCh7IGNvbXBvbmVudEV2ZW50IH0pO1xufTtcbmNvbnN0IHNlbmRNZXNzYWdlUmVhZHlUb09waGFuID0gKG1lc3NhZ2VJZCkgPT4ge1xuICAgIGNvbnN0IGNvbXBvbmVudEV2ZW50ID0ge1xuICAgICAgICBjb21wb25lbnQ6IHtcbiAgICAgICAgICAgIGNvbXBvbmVudFR5cGU6IFwiQ09OU0VOVFwiLFxuICAgICAgICAgICAgaWQ6IG1lc3NhZ2VJZFxuICAgICAgICB9LFxuICAgICAgICBhY3Rpb246IFwiVklFV1wiXG4gICAgfTtcbiAgICBjb25zdCByZWNvcmQgPSBnZXRPcGhhblJlY29yZEZ1bmN0aW9uKCk7XG4gICAgcmVjb3JkKHsgY29tcG9uZW50RXZlbnQgfSk7XG59O1xuY29uc3Qgc2VuZEp1cmlzZGljdGlvbk1pc21hdGNoVG9PcGhhbiA9ICh2YWx1ZSkgPT4ge1xuICAgIGNvbnN0IGNvbXBvbmVudEV2ZW50ID0ge1xuICAgICAgICBjb21wb25lbnQ6IHtcbiAgICAgICAgICAgIGNvbXBvbmVudFR5cGU6IFwiQ09OU0VOVFwiXG4gICAgICAgIH0sXG4gICAgICAgIHZhbHVlLFxuICAgICAgICBhY3Rpb246IFwiQ09OU0VOVF9HRU9MT0NBVElPTl9NSVNNQVRDSFwiXG4gICAgfTtcbiAgICBjb25zdCByZWNvcmQgPSBnZXRPcGhhblJlY29yZEZ1bmN0aW9uKCk7XG4gICAgcmVjb3JkKHsgY29tcG9uZW50RXZlbnQgfSk7XG59O1xuZXhwb3J0IHsgY29uc3RydWN0QmFubmVyTWVzc2FnZUlkLCBzZW5kQ29uc2VudENob2ljZXNUb09waGFuLCBzZW5kSnVyaXNkaWN0aW9uTWlzbWF0Y2hUb09waGFuLCBzZW5kTWVzc2FnZVJlYWR5VG9PcGhhbiB9O1xuIiwiaW1wb3J0IHsgaXNTZXJ2ZXJTaWRlIH0gZnJvbSAnLi4vc2VydmVyLmpzJztcbmNvbnN0IGdldEdwY1NpZ25hbCA9ICgpID0+IHtcbiAgICByZXR1cm4gaXNTZXJ2ZXJTaWRlID8gdm9pZCAwIDogbmF2aWdhdG9yLmdsb2JhbFByaXZhY3lDb250cm9sO1xufTtcbmV4cG9ydCB7IGdldEdwY1NpZ25hbCB9O1xuIiwiaW1wb3J0IHsgaXNHdWFyZGlhbkRvbWFpbiB9IGZyb20gJy4vZG9tYWluLmpzJztcbmNvbnN0IEFDQ09VTlRfSUQgPSAxMjU3O1xuY29uc3QgUFJJVkFDWV9NQU5BR0VSX1VTTkFUID0gMTA2ODMyOTtcbmNvbnN0IFBST1BFUlRZX0lEX01BSU4gPSA3NDE3O1xuY29uc3QgUFJPUEVSVFlfSURfU1VCRE9NQUlOID0gMzgxNjE7XG5jb25zdCBQUk9QRVJUWV9JRF9BVVNUUkFMSUEgPSAxMzM0ODtcbmNvbnN0IFBST1BFUlRZX0hSRUZfU1VCRE9NQUlOID0gXCJodHRwczovL3N1YmRvbWFpbi50aGVndWFyZGlhbi5jb21cIjtcbmNvbnN0IFBST1BFUlRZX0hSRUZfTUFJTiA9IFwiaHR0cHM6Ly90ZXN0LnRoZWd1YXJkaWFuLmNvbVwiO1xuY29uc3QgUFJJVkFDWV9NQU5BR0VSX1RDRlYyID0gMTA2ODQyO1xuY29uc3QgUFJJVkFDWV9NQU5BR0VSX1RDRlYyX0NPTlNFTlRfT1JfUEFZID0gMTI2MzQ0OTtcbmNvbnN0IFBSSVZBQ1lfTUFOQUdFUl9BVVNUUkFMSUEgPSAxMTc4NDg2O1xuY29uc3QgRU5EUE9JTlQgPSBpc0d1YXJkaWFuRG9tYWluKCkgPyBcImh0dHBzOi8vc291cmNlcG9pbnQudGhlZ3VhcmRpYW4uY29tXCIgOiBcImh0dHBzOi8vY2RuLnByaXZhY3ktbWdtdC5jb21cIjtcbmNvbnN0IFNvdXJjZVBvaW50Q2hvaWNlVHlwZXMgPSB7XG4gICAgQWNjZXB0QWxsOiAxMSxcbiAgICBNYW5hZ2VDb29raWVzOiAxMixcbiAgICBSZWplY3RBbGw6IDEzLFxuICAgIERpc21pc3M6IDE1XG59O1xuY29uc3QgY29uc2VudE9yUGF5Q291bnRyaWVzID0gW1wiR0JcIl07XG5leHBvcnQgeyBBQ0NPVU5UX0lELCBFTkRQT0lOVCwgUFJJVkFDWV9NQU5BR0VSX0FVU1RSQUxJQSwgUFJJVkFDWV9NQU5BR0VSX1RDRlYyLCBQUklWQUNZX01BTkFHRVJfVENGVjJfQ09OU0VOVF9PUl9QQVksIFBSSVZBQ1lfTUFOQUdFUl9VU05BVCwgUFJPUEVSVFlfSFJFRl9NQUlOLCBQUk9QRVJUWV9IUkVGX1NVQkRPTUFJTiwgUFJPUEVSVFlfSURfQVVTVFJBTElBLCBQUk9QRVJUWV9JRF9NQUlOLCBQUk9QRVJUWV9JRF9TVUJET01BSU4sIFNvdXJjZVBvaW50Q2hvaWNlVHlwZXMsIGNvbnNlbnRPclBheUNvdW50cmllcyB9O1xuIiwiaW1wb3J0IHsgZ2V0Q29va2llIH0gZnJvbSAnLi4vY29va2llcy9nZXRDb29raWUuanMnO1xuaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICcuLi9pc1N0cmluZy9pc1N0cmluZy5qcyc7XG5pbXBvcnQgeyBpc1VuZGVmaW5lZCB9IGZyb20gJy4uL2lzVW5kZWZpbmVkL2lzVW5kZWZpbmVkLmpzJztcbmltcG9ydCB7IFBST1BFUlRZX0lEX01BSU4sIFBST1BFUlRZX0lEX1NVQkRPTUFJTiB9IGZyb20gJy4vbGliL3NvdXJjZXBvaW50Q29uZmlnLmpzJztcbmNvbnN0IHB1cnBvc2VJZFRvTm9uQWR2ZXJ0aXNpbmdQdXJwb3Nlc01hcCA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKFtcbiAgICBbMSwgXCI2NzdlMzM4N2IyNjVkYzA3MzMyOTA5ZGFcIl0sXG4gICAgLy8gMVxuICAgIFsyLCBcIjY3N2UzMzg2YjI2NWRjMDczMzI4ZjY4NlwiXSxcbiAgICAvLzJcbiAgICBbMywgXCI2NzdlMzM4NmIyNjVkYzA3MzMyOGY5NmZcIl0sXG4gICAgLy8gM1xuICAgIFs0LCBcIjY3N2UzMzg2YjI2NWRjMDczMzI4ZmMwMVwiXSxcbiAgICAvLzRcbiAgICBbNSwgXCI2NzdlMzM4NmIyNjVkYzA3MzMyOGZlNzJcIl0sXG4gICAgLy8gNVxuICAgIFs2LCBcIjY3N2UzMzg2YjI2NWRjMDczMzI4ZmY3MFwiXSxcbiAgICAvLzZcbiAgICBbNywgXCI2NzdlMzM4NmIyNjVkYzA3MzMyOTAwNTBcIl0sXG4gICAgLy83XG4gICAgWzgsIFwiNjc3ZTMzODZiMjY1ZGMwNzMzMjkwM2M4XCJdLFxuICAgIC8vOFxuICAgIFs5LCBcIjY3N2UzMzg2YjI2NWRjMDczMzI5MDUwMlwiXSxcbiAgICAvLzlcbiAgICBbMTAsIFwiNjc3ZTMzODZiMjY1ZGMwNzMzMjkwNzFhXCJdLFxuICAgIC8vMTBcbiAgICBbMTEsIFwiNjc3ZTMzODZiMjY1ZGMwNzMzMjkwOWMyXCJdXG4gICAgLy8xMVxuXSk7XG5jb25zdCBzcEJhc2VVcmwgPSBcImh0dHBzOi8vY2RuLnByaXZhY3ktbWdtdC5jb20vY29uc2VudC90Y2Z2Mi9jb25zZW50L3YzXCI7XG5jb25zdCBtZXJnZVZlbmRvckxpc3QgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgdXNlckNvbnNlbnQgPSBhd2FpdCBnZXRVc2VyQ29uc2VudEZvckFkdmVydGlzaW5nVmVuZG9yTGlzdCgpO1xuICAgIGNvbnN0IHB1cnBvc2VzQW5kVmVuZG9ycyA9IGdldENvbnNlbnRlZFB1cnBvc2VzYW5kVmVuZG9yc1N0cmluZ3ModXNlckNvbnNlbnQpO1xuICAgIGlmICghaXNVbmRlZmluZWQocHVycG9zZXNBbmRWZW5kb3JzKSkge1xuICAgICAgICBhd2FpdCBzZW5kVXNlckN1c3RvbUNvbnNlbnRUb05vbkFkdmVydGlzaW5nVmVuZG9yTGlzdChwdXJwb3Nlc0FuZFZlbmRvcnMudmVuZG9ycywgcHVycG9zZXNBbmRWZW5kb3JzLnB1cnBvc2VzLCBwdXJwb3Nlc0FuZFZlbmRvcnMubGVnaXRpbWF0ZUludGVyZXN0UHVycG9zZUlkcyk7XG4gICAgICAgIGF3YWl0IHNlbmRVc2VyQ29uc2VudFN0cmluZ1RvTm9uQWR2ZXJ0aXNpbmdWZW5kb3JMaXN0KCk7XG4gICAgfVxufTtcbmNvbnN0IGdldFVzZXJDb25zZW50Rm9yQWR2ZXJ0aXNpbmdWZW5kb3JMaXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGNvbnNlbnRVVUlEID0gZ2V0Q29va2llKHsgbmFtZTogXCJjb25zZW50VVVJRFwiIH0pO1xuICAgIGNvbnN0IHVybCA9IGAke3NwQmFzZVVybH0vaGlzdG9yeS8ke1BST1BFUlRZX0lEX01BSU59P2NvbnNlbnRVVUlEPSR7Y29uc2VudFVVSUR9YDtcbiAgICBjb25zdCBnZXRVc2VyQ29uc2VudE9uQWR2ZXJ0aXNpbmdMaXN0UmVzcG9uc2UgPSBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgbWV0aG9kOiBcIkdFVFwiLFxuICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICBBY2NlcHQ6IFwiYXBwbGljYXRpb24vanNvblwiLFxuICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi9qc29uXCJcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBhd2FpdCBnZXRVc2VyQ29uc2VudE9uQWR2ZXJ0aXNpbmdMaXN0UmVzcG9uc2UuanNvbigpO1xufTtcbmNvbnN0IGdldENvbnNlbnRlZFB1cnBvc2VzYW5kVmVuZG9yc1N0cmluZ3MgPSAoZGF0YSkgPT4ge1xuICAgIGNvbnN0IHZlbmRvcklkcyA9IGRhdGFbMF0/LnZlbmRvcnMubWFwKCh2ZW5kb3IpID0+IHZlbmRvci5faWQpO1xuICAgIGNvbnN0IHB1cnBvc2VJZHMgPSBkYXRhWzBdPy5jYXRlZ29yaWVzLm1hcCgoY2F0ZWdvcnkpID0+IHB1cnBvc2VJZFRvTm9uQWR2ZXJ0aXNpbmdQdXJwb3Nlc01hcC5nZXQoY2F0ZWdvcnkuaWFiUHVycG9zZVJlZi5pYWJJZCkgPz8gXCJcIikuZmlsdGVyKGlzU3RyaW5nKTtcbiAgICBjb25zdCBsZWdpdGltYXRlSW50ZXJlc3RQdXJwb3NlSWRzID0gZGF0YVswXT8ubGVnSW50Q2F0ZWdvcmllcy5tYXAoKGNhdGVnb3J5KSA9PiBwdXJwb3NlSWRUb05vbkFkdmVydGlzaW5nUHVycG9zZXNNYXAuZ2V0KGNhdGVnb3J5LmlhYlB1cnBvc2VSZWYuaWFiSWQpID8/IFwiXCIpLmZpbHRlcihpc1N0cmluZyk7XG4gICAgaWYgKHZlbmRvcklkcyAmJiBwdXJwb3NlSWRzICYmIGxlZ2l0aW1hdGVJbnRlcmVzdFB1cnBvc2VJZHMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHZlbmRvcnM6IHZlbmRvcklkcyxcbiAgICAgICAgICAgIHB1cnBvc2VzOiBwdXJwb3NlSWRzLFxuICAgICAgICAgICAgbGVnaXRpbWF0ZUludGVyZXN0UHVycG9zZUlkc1xuICAgICAgICB9O1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICB9XG59O1xuY29uc3Qgc2VuZFVzZXJDdXN0b21Db25zZW50VG9Ob25BZHZlcnRpc2luZ1ZlbmRvckxpc3QgPSBhc3luYyAodmVuZG9ySWRzLCBwdXJwb3NlSWRzLCBsZWdpdGltYXRlSW50ZXJlc3RQdXJwb3NlSWRzKSA9PiB7XG4gICAgY29uc3QgY29uc2VudFVVSUQgPSBnZXRDb29raWUoeyBuYW1lOiBcImNvbnNlbnRVVUlEXCIgfSk7XG4gICAgY29uc3QgdXJsID0gYCR7c3BCYXNlVXJsfS9jdXN0b20vJHtQUk9QRVJUWV9JRF9TVUJET01BSU59P2hhc0NzcD10cnVlJmNvbnNlbnRVVUlEPSR7Y29uc2VudFVVSUR9YDtcbiAgICBhd2FpdCBtYWtlUE9TVFJlcXVlc3QodXJsLCB7XG4gICAgICAgIHZlbmRvcnM6IHZlbmRvcklkcyxcbiAgICAgICAgY2F0ZWdvcmllczogcHVycG9zZUlkcyxcbiAgICAgICAgbGVnSW50Q2F0ZWdvcmllczogbGVnaXRpbWF0ZUludGVyZXN0UHVycG9zZUlkc1xuICAgIH0pO1xufTtcbmNvbnN0IHNlbmRVc2VyQ29uc2VudFN0cmluZ1RvTm9uQWR2ZXJ0aXNpbmdWZW5kb3JMaXN0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGNvbnNlbnRVVUlEID0gZ2V0Q29va2llKHsgbmFtZTogXCJjb25zZW50VVVJRFwiIH0pO1xuICAgIGNvbnN0IHVybCA9IGAke3NwQmFzZVVybH0vJHtQUk9QRVJUWV9JRF9TVUJET01BSU59L3Rjc3RyaW5nP2NvbnNlbnRVVUlEPSR7Y29uc2VudFVVSUR9YDtcbiAgICBjb25zdCBzcFVzZXJDb25zZW50U3RyaW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oYF9zcF91c2VyX2NvbnNlbnRfJHtQUk9QRVJUWV9JRF9NQUlOfWApO1xuICAgIGNvbnN0IHVzZXJDb25zZW50ID0gSlNPTi5wYXJzZShzcFVzZXJDb25zZW50U3RyaW5nID8/IFwie31cIik7XG4gICAgYXdhaXQgbWFrZVBPU1RSZXF1ZXN0KHVybCwge1xuICAgICAgICBldWNvbnNlbnQ6IHVzZXJDb25zZW50LmdkcHI/LmV1Y29uc2VudFxuICAgIH0pO1xufTtcbmNvbnN0IG1ha2VQT1NUUmVxdWVzdCA9IGFzeW5jICh1cmwsIGJvZHkpID0+IHtcbiAgICBhd2FpdCBmZXRjaCh1cmwsIHtcbiAgICAgICAgbWV0aG9kOiBcIlBPU1RcIixcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgQWNjZXB0OiBcImFwcGxpY2F0aW9uL2pzb25cIixcbiAgICAgICAgICAgIFwiQ29udGVudC1UeXBlXCI6IFwiYXBwbGljYXRpb24vanNvblwiXG4gICAgICAgIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KGJvZHkpXG4gICAgfSk7XG59O1xuZXhwb3J0IHsgbWVyZ2VWZW5kb3JMaXN0IH07XG4iLCJpbXBvcnQgeyBvbkNvbnNlbnRDaGFuZ2UgfSBmcm9tICcuL29uQ29uc2VudENoYW5nZS5qcyc7XG5jb25zdCBvbkNvbnNlbnQgPSAoKSA9PiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgb25Db25zZW50Q2hhbmdlKChjb25zZW50U3RhdGUpID0+IHtcbiAgICAgICAgaWYgKGNvbnNlbnRTdGF0ZS50Y2Z2MiA/PyBjb25zZW50U3RhdGUudXNuYXQgPz8gY29uc2VudFN0YXRlLmF1cykge1xuICAgICAgICAgICAgcmVzb2x2ZShjb25zZW50U3RhdGUpO1xuICAgICAgICB9XG4gICAgICAgIHJlamVjdChcIlVua25vd24gZnJhbWV3b3JrXCIpO1xuICAgIH0pO1xufSk7XG5leHBvcnQgeyBvbkNvbnNlbnQgfTtcbiIsImltcG9ydCB7IGdldENvbnNlbnRTdGF0ZSBhcyBnZXRDb25zZW50U3RhdGUkMyB9IGZyb20gJy4vYXVzL2dldENvbnNlbnRTdGF0ZS5qcyc7XG5pbXBvcnQgeyBnZXRDdXJyZW50RnJhbWV3b3JrIH0gZnJvbSAnLi9nZXRDdXJyZW50RnJhbWV3b3JrLmpzJztcbmltcG9ydCB7IGdldEdwY1NpZ25hbCB9IGZyb20gJy4vbGliL3NpZ25hbHMuanMnO1xuaW1wb3J0IHsgZ2V0Q29uc2VudFN0YXRlIGFzIGdldENvbnNlbnRTdGF0ZSQxIH0gZnJvbSAnLi90Y2Z2Mi9nZXRDb25zZW50U3RhdGUuanMnO1xuaW1wb3J0IHsgZ2V0Q29uc2VudFN0YXRlIGFzIGdldENvbnNlbnRTdGF0ZSQyIH0gZnJvbSAnLi91c25hdC9nZXRDb25zZW50U3RhdGUuanMnO1xuY29uc3QgY2FsbEJhY2tRdWV1ZSA9IFtdO1xuY29uc3QgZmluYWxDYWxsYmFja1F1ZXVlID0gW107XG5jb25zdCBhd2FpdGluZ1VzZXJJbnRlcmFjdGlvbkluVENGdjIgPSAoc3RhdGUpID0+IHN0YXRlLnRjZnYyPy5ldmVudFN0YXR1cyA9PT0gXCJjbXB1aXNob3duXCI7XG5jb25zdCBhd2FpdGluZ1VzZXJJbnRlcmFjdGlvbkluVVNOQVQgPSAoc3RhdGUpID0+IHN0YXRlLnVzbmF0Py5zaWduYWxTdGF0dXMgPT09IFwibm90IHJlYWR5XCI7XG5jb25zdCBpbnZva2VDYWxsYmFjayA9IChjYWxsYmFjaywgc3RhdGUpID0+IHtcbiAgICBpZiAoYXdhaXRpbmdVc2VySW50ZXJhY3Rpb25JblRDRnYyKHN0YXRlKSB8fCBhd2FpdGluZ1VzZXJJbnRlcmFjdGlvbkluVVNOQVQoc3RhdGUpKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3Qgc3RhdGVTdHJpbmcgPSBKU09OLnN0cmluZ2lmeShzdGF0ZSk7XG4gICAgaWYgKHN0YXRlU3RyaW5nICE9PSBjYWxsYmFjay5sYXN0U3RhdGUpIHtcbiAgICAgICAgY2FsbGJhY2suZm4oc3RhdGUpO1xuICAgICAgICBjYWxsYmFjay5sYXN0U3RhdGUgPSBzdGF0ZVN0cmluZztcbiAgICB9XG59O1xuY29uc3QgZW5oYW5jZUNvbnNlbnRTdGF0ZSA9IChjb25zZW50U3RhdGUpID0+IHtcbiAgICBjb25zdCBncGNTaWduYWwgPSBnZXRHcGNTaWduYWwoKTtcbiAgICBpZiAoY29uc2VudFN0YXRlLnRjZnYyKSB7XG4gICAgICAgIGNvbnN0IGNvbnNlbnRzID0gY29uc2VudFN0YXRlLnRjZnYyLmNvbnNlbnRzO1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uY29uc2VudFN0YXRlLFxuICAgICAgICAgICAgY2FuVGFyZ2V0OiBPYmplY3Qua2V5cyhjb25zZW50cykubGVuZ3RoID4gMCAmJiBPYmplY3QudmFsdWVzKGNvbnNlbnRzKS5ldmVyeShCb29sZWFuKSxcbiAgICAgICAgICAgIGZyYW1ld29yazogXCJ0Y2Z2MlwiLFxuICAgICAgICAgICAgZ3BjU2lnbmFsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGVsc2UgaWYgKGNvbnNlbnRTdGF0ZS51c25hdCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgLi4uY29uc2VudFN0YXRlLFxuICAgICAgICAgICAgY2FuVGFyZ2V0OiAhY29uc2VudFN0YXRlLnVzbmF0LmRvTm90U2VsbCxcbiAgICAgICAgICAgIGZyYW1ld29yazogXCJ1c25hdFwiLFxuICAgICAgICAgICAgZ3BjU2lnbmFsXG4gICAgICAgIH07XG4gICAgfVxuICAgIGVsc2UgaWYgKGNvbnNlbnRTdGF0ZS5hdXMpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIC4uLmNvbnNlbnRTdGF0ZSxcbiAgICAgICAgICAgIGNhblRhcmdldDogY29uc2VudFN0YXRlLmF1cy5wZXJzb25hbGlzZWRBZHZlcnRpc2luZyxcbiAgICAgICAgICAgIGZyYW1ld29yazogXCJhdXNcIixcbiAgICAgICAgICAgIGdwY1NpZ25hbFxuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICAuLi5jb25zZW50U3RhdGUsXG4gICAgICAgIGNhblRhcmdldDogZmFsc2UsXG4gICAgICAgIGZyYW1ld29yazogbnVsbCxcbiAgICAgICAgZ3BjU2lnbmFsXG4gICAgfTtcbn07XG5jb25zdCBnZXRDb25zZW50U3RhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgc3dpdGNoIChnZXRDdXJyZW50RnJhbWV3b3JrKCkpIHtcbiAgICAgICAgY2FzZSBcImF1c1wiOlxuICAgICAgICAgICAgcmV0dXJuIGVuaGFuY2VDb25zZW50U3RhdGUoeyBhdXM6IGF3YWl0IGdldENvbnNlbnRTdGF0ZSQzKCkgfSk7XG4gICAgICAgIGNhc2UgXCJ1c25hdFwiOiB7XG4gICAgICAgICAgICByZXR1cm4gZW5oYW5jZUNvbnNlbnRTdGF0ZSh7XG4gICAgICAgICAgICAgICAgdXNuYXQ6IGF3YWl0IGdldENvbnNlbnRTdGF0ZSQyKClcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNhc2UgXCJ0Y2Z2MlwiOlxuICAgICAgICAgICAgcmV0dXJuIGVuaGFuY2VDb25zZW50U3RhdGUoeyB0Y2Z2MjogYXdhaXQgZ2V0Q29uc2VudFN0YXRlJDEoKSB9KTtcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIm5vIElBQiBjb25zZW50IGZyYW1ld29yayBmb3VuZCBvbiB0aGUgcGFnZVwiKTtcbiAgICB9XG59O1xuY29uc3QgaW52b2tlQ2FsbGJhY2tzID0gKCkgPT4ge1xuICAgIGNvbnN0IGNhbGxiYWNrc1RvSW52b2tlID0gY2FsbEJhY2tRdWV1ZS5jb25jYXQoZmluYWxDYWxsYmFja1F1ZXVlKTtcbiAgICBpZiAoY2FsbGJhY2tzVG9JbnZva2UubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdm9pZCBnZXRDb25zZW50U3RhdGUoKS50aGVuKChzdGF0ZSkgPT4ge1xuICAgICAgICBpZiAoYXdhaXRpbmdVc2VySW50ZXJhY3Rpb25JblRDRnYyKHN0YXRlKSB8fCBhd2FpdGluZ1VzZXJJbnRlcmFjdGlvbkluVVNOQVQoc3RhdGUpKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY2FsbGJhY2tzVG9JbnZva2UuZm9yRWFjaCgoY2FsbGJhY2spID0+IGludm9rZUNhbGxiYWNrKGNhbGxiYWNrLCBzdGF0ZSkpO1xuICAgIH0pO1xufTtcbmNvbnN0IG9uQ29uc2VudENoYW5nZSA9IChjYWxsQmFjaywgZmluYWwgPSBmYWxzZSkgPT4ge1xuICAgIGNvbnN0IG5ld0NhbGxiYWNrID0geyBmbjogY2FsbEJhY2sgfTtcbiAgICBpZiAoZmluYWwpIHtcbiAgICAgICAgZmluYWxDYWxsYmFja1F1ZXVlLnB1c2gobmV3Q2FsbGJhY2spO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgY2FsbEJhY2tRdWV1ZS5wdXNoKG5ld0NhbGxiYWNrKTtcbiAgICB9XG4gICAgdm9pZCBnZXRDb25zZW50U3RhdGUoKS50aGVuKChjb25zZW50U3RhdGUpID0+IHtcbiAgICAgICAgaW52b2tlQ2FsbGJhY2sobmV3Q2FsbGJhY2ssIGNvbnNlbnRTdGF0ZSk7XG4gICAgfSkuY2F0Y2goKCkgPT4ge1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IGludm9rZUNhbGxiYWNrcywgb25Db25zZW50Q2hhbmdlIH07XG4iLCJjb25zdCBpc1NlcnZlclNpZGUgPSB0eXBlb2Ygd2luZG93ID09PSBcInVuZGVmaW5lZFwiO1xuY29uc3Qgc2VydmVyU2lkZVdhcm4gPSAoKSA9PiB7XG4gICAgY29uc29sZS53YXJuKFwiVGhpcyBpcyBhIHNlcnZlci1zaWRlIHZlcnNpb24gb2YgdGhlIEBndWFyZGlhbi9jb25zZW50LW1hbmFnZW1lbnQtcGxhdGZvcm1cIiwgXCJObyBjb25zZW50IHNpZ25hbHMgd2lsbCBiZSByZWNlaXZlZC5cIik7XG59O1xuY29uc3Qgc2VydmVyU2lkZVdhcm5BbmRSZXR1cm4gPSAoYXJnKSA9PiB7XG4gICAgcmV0dXJuICgpID0+IHtcbiAgICAgICAgc2VydmVyU2lkZVdhcm4oKTtcbiAgICAgICAgcmV0dXJuIGFyZztcbiAgICB9O1xufTtcbmNvbnN0IGNtcCA9IHtcbiAgICBfX2Rpc2FibGU6IHNlcnZlclNpZGVXYXJuLFxuICAgIF9fZW5hYmxlOiBzZXJ2ZXJTaWRlV2FybkFuZFJldHVybihmYWxzZSksXG4gICAgX19pc0Rpc2FibGVkOiBzZXJ2ZXJTaWRlV2FybkFuZFJldHVybihmYWxzZSksXG4gICAgaGFzSW5pdGlhbGlzZWQ6IHNlcnZlclNpZGVXYXJuQW5kUmV0dXJuKGZhbHNlKSxcbiAgICBpbml0OiBzZXJ2ZXJTaWRlV2FybixcbiAgICBzaG93UHJpdmFjeU1hbmFnZXI6IHNlcnZlclNpZGVXYXJuLFxuICAgIHZlcnNpb246IFwibi9hXCIsXG4gICAgd2lsbFNob3dQcml2YWN5TWVzc2FnZTogc2VydmVyU2lkZVdhcm5BbmRSZXR1cm4oUHJvbWlzZS5yZXNvbHZlKGZhbHNlKSksXG4gICAgd2lsbFNob3dQcml2YWN5TWVzc2FnZVN5bmM6IHNlcnZlclNpZGVXYXJuQW5kUmV0dXJuKGZhbHNlKVxufTtcbmNvbnN0IG9uQ29uc2VudCA9ICgpID0+IHtcbiAgICBzZXJ2ZXJTaWRlV2FybigpO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe1xuICAgICAgICBjYW5UYXJnZXQ6IGZhbHNlLFxuICAgICAgICBmcmFtZXdvcms6IG51bGxcbiAgICB9KTtcbn07XG5jb25zdCBvbkNvbnNlbnRDaGFuZ2UgPSAoKSA9PiB7XG4gICAgcmV0dXJuIHNlcnZlclNpZGVXYXJuKCk7XG59O1xuY29uc3QgZ2V0Q29uc2VudEZvciA9ICh2ZW5kb3IsIGNvbnNlbnQpID0+IHtcbiAgICBjb25zb2xlLmxvZyhgU2VydmVyLXNpZGUgY2FsbCBmb3IgZ2V0Q29uc2VudEZvcigke3ZlbmRvcn0sICR7SlNPTi5zdHJpbmdpZnkoY29uc2VudCl9KWAsIFwiZ2V0Q29uc2VudEZvciB3aWxsIGFsd2F5cyByZXR1cm4gZmFsc2Ugc2VydmVyLXNpZGVcIik7XG4gICAgc2VydmVyU2lkZVdhcm4oKTtcbiAgICByZXR1cm4gZmFsc2U7XG59O1xuZXhwb3J0IHsgY21wLCBnZXRDb25zZW50Rm9yLCBpc1NlcnZlclNpZGUsIG9uQ29uc2VudCwgb25Db25zZW50Q2hhbmdlLCBzZXJ2ZXJTaWRlV2Fybiwgc2VydmVyU2lkZVdhcm5BbmRSZXR1cm4gfTtcbiIsImltcG9ydCB7IGxvZyB9IGZyb20gJy4uL2xvZ2dlci9sb2dnZXIuanMnO1xuaW1wb3J0IHsgaXNFeGNsdWRlZEZyb21DTVAgfSBmcm9tICcuL2V4Y2x1c2lvbkxpc3QuanMnO1xuaW1wb3J0IHsgc2V0Q3VycmVudEZyYW1ld29yayB9IGZyb20gJy4vZ2V0Q3VycmVudEZyYW1ld29yay5qcyc7XG5pbXBvcnQgeyBpc0NvbnNlbnRPclBheUNvdW50cnksIHNldElzQ29uc2VudE9yUGF5IH0gZnJvbSAnLi9pc0NvbnNlbnRPclBheS5qcyc7XG5pbXBvcnQgeyBtYXJrIH0gZnJvbSAnLi9saWIvbWFyay5qcyc7XG5pbXBvcnQgeyBzZW5kQ29uc2VudENob2ljZXNUb09waGFuLCBjb25zdHJ1Y3RCYW5uZXJNZXNzYWdlSWQsIHNlbmRNZXNzYWdlUmVhZHlUb09waGFuLCBzZW5kSnVyaXNkaWN0aW9uTWlzbWF0Y2hUb09waGFuIH0gZnJvbSAnLi9saWIvb3BoYW4uanMnO1xuaW1wb3J0IHsgQUNDT1VOVF9JRCwgRU5EUE9JTlQsIFNvdXJjZVBvaW50Q2hvaWNlVHlwZXMsIFBST1BFUlRZX0hSRUZfU1VCRE9NQUlOLCBQUk9QRVJUWV9IUkVGX01BSU4sIFBST1BFUlRZX0lEX0FVU1RSQUxJQSwgUFJPUEVSVFlfSURfTUFJTiwgUFJPUEVSVFlfSURfU1VCRE9NQUlOIH0gZnJvbSAnLi9saWIvc291cmNlcG9pbnRDb25maWcuanMnO1xuaW1wb3J0IHsgbWVyZ2VWZW5kb3JMaXN0IH0gZnJvbSAnLi9tZXJnZVVzZXJDb25zZW50LmpzJztcbmltcG9ydCB7IGludm9rZUNhbGxiYWNrcyB9IGZyb20gJy4vb25Db25zZW50Q2hhbmdlLmpzJztcbmltcG9ydCB7IGxvYWRTdHVic0ZvciB9IGZyb20gJy4vc3R1Yi5qcyc7XG5sZXQgcmVzb2x2ZVdpbGxTaG93UHJpdmFjeU1lc3NhZ2U7XG5jb25zdCB3aWxsU2hvd1ByaXZhY3lNZXNzYWdlID0gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICByZXNvbHZlV2lsbFNob3dQcml2YWN5TWVzc2FnZSA9IHJlc29sdmU7XG59KTtcbmNvbnN0IGdldFByb3BlcnR5SHJlZiA9IChmcmFtZXdvcmssIHVzZU5vbkFkdmVydGlzZWRMaXN0KSA9PiB7XG4gICAgaWYgKGZyYW1ld29yayA9PSBcImF1c1wiKSB7XG4gICAgICAgIHJldHVybiBcImh0dHBzOi8vYXUudGhlZ3VhcmRpYW4uY29tXCI7XG4gICAgfVxuICAgIGlmIChmcmFtZXdvcmsgPT0gXCJ1c25hdFwiKSB7XG4gICAgICAgIHJldHVybiBcImh0dHBzOi8vd3d3LnRoZWd1YXJkaWFuLmNvbVwiO1xuICAgIH1cbiAgICByZXR1cm4gdXNlTm9uQWR2ZXJ0aXNlZExpc3QgPyBQUk9QRVJUWV9IUkVGX1NVQkRPTUFJTiA6IFBST1BFUlRZX0hSRUZfTUFJTjtcbn07XG5jb25zdCBnZXRQcm9wZXJ0eUlkID0gKGZyYW1ld29yaywgdXNlTm9uQWR2ZXJ0aXNlZExpc3QpID0+IHtcbiAgICBpZiAoZnJhbWV3b3JrID09IFwiYXVzXCIpIHtcbiAgICAgICAgcmV0dXJuIFBST1BFUlRZX0lEX0FVU1RSQUxJQTtcbiAgICB9XG4gICAgaWYgKGZyYW1ld29yayA9PSBcInVzbmF0XCIpIHtcbiAgICAgICAgcmV0dXJuIFBST1BFUlRZX0lEX01BSU47XG4gICAgfVxuICAgIHJldHVybiB1c2VOb25BZHZlcnRpc2VkTGlzdCA/IFBST1BFUlRZX0lEX1NVQkRPTUFJTiA6IFBST1BFUlRZX0lEX01BSU47XG59O1xuY29uc3QgaGFzQ29uc2VudGVkVG9Ob25BZHZlcnRpc2VkTGlzdCA9ICgpID0+IHtcbiAgICBjb25zdCBzcFVzZXJDb25zZW50U3RyaW5nID0gbG9jYWxTdG9yYWdlLmdldEl0ZW0oYF9zcF91c2VyX2NvbnNlbnRfJHtQUk9QRVJUWV9JRF9TVUJET01BSU59YCk7XG4gICAgY29uc3QgdXNlckNvbnNlbnQgPSBKU09OLnBhcnNlKHNwVXNlckNvbnNlbnRTdHJpbmcgPz8gXCJ7fVwiKTtcbiAgICByZXR1cm4gdXNlckNvbnNlbnQuZ2Rwcj8uY29uc2VudFN0YXR1cz8uaGFzQ29uc2VudERhdGEgPz8gZmFsc2U7XG59O1xuY29uc3Qgc2hvdWxkTWVyZ2VWZW5kb3JMaXN0ID0gKGNvdW50cnlDb2RlLCB1c2VOb25BZHZlcnRpc2VkTGlzdCkgPT4ge1xuICAgIHJldHVybiBpc0NvbnNlbnRPclBheUNvdW50cnkoY291bnRyeUNvZGUpICYmIHVzZU5vbkFkdmVydGlzZWRMaXN0ICYmICFoYXNDb25zZW50ZWRUb05vbkFkdmVydGlzZWRMaXN0KCk7XG59O1xuY29uc3QgaW5pdCA9IChmcmFtZXdvcmssIGNvdW50cnlDb2RlLCBpc1VzZXJTaWduZWRJbiwgdXNlTm9uQWR2ZXJ0aXNlZExpc3QsIHB1YkRhdGEgPSB7fSkgPT4ge1xuICAgIGxvYWRTdHVic0ZvcihmcmFtZXdvcmspO1xuICAgIGlmICh3aW5kb3cuX3NwXykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJTb3VyY2Vwb2ludCBnbG9iYWwgKHdpbmRvdy5fc3BfKSBpcyBhbHJlYWR5IGRlZmluZWQhXCIpO1xuICAgIH1cbiAgICBzZXRDdXJyZW50RnJhbWV3b3JrKGZyYW1ld29yayk7XG4gICAgaWYgKCFpc0NvbnNlbnRPclBheUNvdW50cnkoY291bnRyeUNvZGUpKSB7XG4gICAgICAgIHVzZU5vbkFkdmVydGlzZWRMaXN0ID0gZmFsc2U7XG4gICAgfVxuICAgIHNldElzQ29uc2VudE9yUGF5KGlzQ29uc2VudE9yUGF5Q291bnRyeShjb3VudHJ5Q29kZSkgJiYgIXVzZU5vbkFkdmVydGlzZWRMaXN0KTtcbiAgICBpbnZva2VDYWxsYmFja3MoKTtcbiAgICBsZXQgZnJhbWV3b3JrTWVzc2FnZVR5cGU7XG4gICAgc3dpdGNoIChmcmFtZXdvcmspIHtcbiAgICAgICAgY2FzZSBcInVzbmF0XCI6XG4gICAgICAgICAgICBmcmFtZXdvcmtNZXNzYWdlVHlwZSA9IFwidXNuYXRcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiYXVzXCI6XG4gICAgICAgICAgICBmcmFtZXdvcmtNZXNzYWdlVHlwZSA9IFwiY2NwYVwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJ0Y2Z2MlwiOlxuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgZnJhbWV3b3JrTWVzc2FnZVR5cGUgPSBcImdkcHJcIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBsZXQgbWVzc2FnZUlkO1xuICAgIGNvbnN0IGlzSW5Qcm9wZXJ0eUlkQUJUZXN0ID0gd2luZG93Lmd1YXJkaWFuPy5jb25maWc/LnRlc3RzPy51c2VTb3VyY2Vwb2ludFByb3BlcnR5SWRWYXJpYW50ID09PSBcInZhcmlhbnRcIjtcbiAgICBsb2coXCJjbXBcIiwgYGZyYW1ld29yazogJHtmcmFtZXdvcmt9YCk7XG4gICAgbG9nKFwiY21wXCIsIGBmcmFtZXdvcmtNZXNzYWdlVHlwZTogJHtmcmFtZXdvcmtNZXNzYWdlVHlwZX1gKTtcbiAgICBjb25zdCBwYWdlU2VjdGlvbiA9IHdpbmRvdy5ndWFyZGlhbj8uY29uZmlnPy5wYWdlPy5zZWN0aW9uO1xuICAgIHdpbmRvdy5fc3BfcXVldWUgPSBbXTtcbiAgICB3aW5kb3cuX3NwXyA9IHtcbiAgICAgICAgY29uZmlnOiB7XG4gICAgICAgICAgICBiYXNlRW5kcG9pbnQ6IEVORFBPSU5ULFxuICAgICAgICAgICAgYWNjb3VudElkOiBBQ0NPVU5UX0lELFxuICAgICAgICAgICAgcHJvcGVydHlJZDogZ2V0UHJvcGVydHlJZChmcmFtZXdvcmssIHVzZU5vbkFkdmVydGlzZWRMaXN0KSxcbiAgICAgICAgICAgIHByb3BlcnR5SHJlZjogZ2V0UHJvcGVydHlIcmVmKGZyYW1ld29yaywgdXNlTm9uQWR2ZXJ0aXNlZExpc3QpLFxuICAgICAgICAgICAgam9pbkhyZWY6IHRydWUsXG4gICAgICAgICAgICBpc1NQQTogdHJ1ZSxcbiAgICAgICAgICAgIHRhcmdldGluZ1BhcmFtczoge1xuICAgICAgICAgICAgICAgIGZyYW1ld29yayxcbiAgICAgICAgICAgICAgICBleGNsdWRlUGFnZTogaXNFeGNsdWRlZEZyb21DTVAocGFnZVNlY3Rpb24pXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgcHViRGF0YTogeyAuLi5wdWJEYXRhLCBjbXBJbml0VGltZVV0YzogKCAvKiBAX19QVVJFX18gKi9uZXcgRGF0ZSgpKS5nZXRUaW1lKCkgfSxcbiAgICAgICAgICAgIC8vIGNjcGEgb3IgZ2RwciBvYmplY3QgYWRkZWQgYmVsb3dcbiAgICAgICAgICAgIGV2ZW50czoge1xuICAgICAgICAgICAgICAgIG9uQ29uc2VudFJlYWR5OiAobWVzc2FnZV90eXBlLCBjb25zZW50VVVJRCwgZXVjb25zZW50KSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGxvZyhcImNtcFwiLCBgb25Db25zZW50UmVhZHkgJHttZXNzYWdlX3R5cGV9YCk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChtZXNzYWdlX3R5cGUgIT0gZnJhbWV3b3JrTWVzc2FnZVR5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbmRKdXJpc2RpY3Rpb25NaXNtYXRjaFRvT3BoYW4oSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNwOiBtZXNzYWdlX3R5cGUsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZ3U6IGZyYW1ld29ya01lc3NhZ2VUeXBlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGd1X2NvdW50cnk6IGNvdW50cnlDb2RlXG4gICAgICAgICAgICAgICAgICAgICAgICB9KSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2coXCJjbXBcIiwgYG9uTWVzc2FnZVJlY2VpdmVEYXRhIERhdGEgbWlzbWF0Y2ggO3NwOiR7bWVzc2FnZV90eXBlfTtmYXN0bHk6JHtmcmFtZXdvcmtNZXNzYWdlVHlwZX07YCk7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBjb25zZW50VVVJRCAke2NvbnNlbnRVVUlEfWApO1xuICAgICAgICAgICAgICAgICAgICBsb2coXCJjbXBcIiwgYGV1Y29uc2VudCAke2V1Y29uc2VudH1gKTtcbiAgICAgICAgICAgICAgICAgICAgbWFyayhcImNtcC1nb3QtY29uc2VudFwiKTtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChpbnZva2VDYWxsYmFja3MsIDApO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25NZXNzYWdlUmVhZHk6IChtZXNzYWdlX3R5cGUpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvbk1lc3NhZ2VSZWFkeSAke21lc3NhZ2VfdHlwZX1gKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2VfdHlwZSAhPSBmcmFtZXdvcmtNZXNzYWdlVHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIG1hcmsoXCJjbXAtdWktZGlzcGxheWVkXCIpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25NZXNzYWdlUmVjZWl2ZURhdGE6IChtZXNzYWdlX3R5cGUsIGRhdGEpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvbk1lc3NhZ2VSZWNlaXZlRGF0YSAke21lc3NhZ2VfdHlwZX1gKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGRhdGEubWVzc2FnZUlkICE9PSAwKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlSWQgPSBkYXRhLm1lc3NhZ2VJZDtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNlbmRNZXNzYWdlUmVhZHlUb09waGFuKGNvbnN0cnVjdEJhbm5lck1lc3NhZ2VJZChtZXNzYWdlSWQudG9TdHJpbmcoKSkpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGxvZyhcImNtcFwiLCBcIm9uTWVzc2FnZVJlY2VpdmVEYXRhIFwiLCBkYXRhKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2VfdHlwZSAhPSBmcmFtZXdvcmtNZXNzYWdlVHlwZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHZvaWQgcmVzb2x2ZVdpbGxTaG93UHJpdmFjeU1lc3NhZ2UoZGF0YS5tZXNzYWdlSWQgIT09IDApO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25NZXNzYWdlQ2hvaWNlU2VsZWN0OiAobWVzc2FnZV90eXBlLCBjaG9pY2VfaWQsIGNob2ljZVR5cGVJRCkgPT4ge1xuICAgICAgICAgICAgICAgICAgICBsb2coXCJjbXBcIiwgYG9uTWVzc2FnZUNob2ljZVNlbGVjdCBtZXNzYWdlX3R5cGU6ICR7bWVzc2FnZV90eXBlfWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZV90eXBlICE9IGZyYW1ld29ya01lc3NhZ2VUeXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvbk1lc3NhZ2VDaG9pY2VTZWxlY3QgY2hvaWNlX2lkOiAke2Nob2ljZV9pZH1gKTtcbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvbk1lc3NhZ2VDaG9pY2VTZWxlY3QgY2hvaWNlX3R5cGVfaWQ6ICR7Y2hvaWNlVHlwZUlEfWApO1xuICAgICAgICAgICAgICAgICAgICBzZW5kQ29uc2VudENob2ljZXNUb09waGFuKGNob2ljZVR5cGVJRCwgY29uc3RydWN0QmFubmVyTWVzc2FnZUlkKG1lc3NhZ2VJZC50b1N0cmluZygpKSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChjaG9pY2VUeXBlSUQgPT09IFNvdXJjZVBvaW50Q2hvaWNlVHlwZXMuQWNjZXB0QWxsIHx8IGNob2ljZVR5cGVJRCA9PT0gU291cmNlUG9pbnRDaG9pY2VUeXBlcy5SZWplY3RBbGwgfHwgY2hvaWNlVHlwZUlEID09PSBTb3VyY2VQb2ludENob2ljZVR5cGVzLkRpc21pc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQoaW52b2tlQ2FsbGJhY2tzLCAwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25Qcml2YWN5TWFuYWdlckFjdGlvbjogZnVuY3Rpb24gKG1lc3NhZ2VfdHlwZSwgcG1EYXRhKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZyhcImNtcFwiLCBgb25Qcml2YWN5TWFuYWdlckFjdGlvbiBtZXNzYWdlX3R5cGU6ICR7bWVzc2FnZV90eXBlfWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZV90eXBlICE9IGZyYW1ld29ya01lc3NhZ2VUeXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvblByaXZhY3lNYW5hZ2VyQWN0aW9uICR7cG1EYXRhfWApO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25NZXNzYWdlQ2hvaWNlRXJyb3I6IGZ1bmN0aW9uIChtZXNzYWdlX3R5cGUsIGVycikge1xuICAgICAgICAgICAgICAgICAgICBsb2coXCJjbXBcIiwgYG9uTWVzc2FnZUNob2ljZUVycm9yICR7bWVzc2FnZV90eXBlfWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZV90eXBlICE9IGZyYW1ld29ya01lc3NhZ2VUeXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvbk1lc3NhZ2VDaG9pY2VFcnJvciAke2Vycn1gKTtcbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG9uUE1DYW5jZWw6IGZ1bmN0aW9uIChtZXNzYWdlX3R5cGUpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBvblBNQ2FuY2VsICR7bWVzc2FnZV90eXBlfWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZV90eXBlICE9IGZyYW1ld29ya01lc3NhZ2VUeXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgIG9uU1BQTU9iamVjdFJlYWR5OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZyhcImNtcFwiLCBcIm9uU1BQTU9iamVjdFJlYWR5XCIpO1xuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgb25FcnJvcjogZnVuY3Rpb24gKG1lc3NhZ2VfdHlwZSwgZXJyb3JDb2RlLCBlcnJvck9iamVjdCwgdXNlclJlc2V0KSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZyhcImNtcFwiLCBgZXJyb3JDb2RlOiAke21lc3NhZ2VfdHlwZX1gKTtcbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGBlcnJvckNvZGU6ICR7ZXJyb3JDb2RlfWApO1xuICAgICAgICAgICAgICAgICAgICBpZiAobWVzc2FnZV90eXBlICE9IGZyYW1ld29ya01lc3NhZ2VUeXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGVycm9yT2JqZWN0KTtcbiAgICAgICAgICAgICAgICAgICAgbG9nKFwiY21wXCIsIGB1c2VyUmVzZXQ6ICR7dXNlclJlc2V0fWApO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH07XG4gICAgaWYgKGlzSW5Qcm9wZXJ0eUlkQUJUZXN0KSB7XG4gICAgICAgIHdpbmRvdy5fc3BfLmNvbmZpZy5wcm9wZXJ0eUlkID0gZ2V0UHJvcGVydHlJZChmcmFtZXdvcmssIHVzZU5vbkFkdmVydGlzZWRMaXN0KTtcbiAgICB9XG4gICAgc3dpdGNoIChmcmFtZXdvcmspIHtcbiAgICAgICAgY2FzZSBcInRjZnYyXCI6XG4gICAgICAgICAgICB3aW5kb3cuX3NwXy5jb25maWcuZ2RwciA9IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRpbmdQYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgZnJhbWV3b3JrLFxuICAgICAgICAgICAgICAgICAgICBleGNsdWRlUGFnZTogaXNFeGNsdWRlZEZyb21DTVAocGFnZVNlY3Rpb24pLFxuICAgICAgICAgICAgICAgICAgICBpc0NvclA6IGlzQ29uc2VudE9yUGF5Q291bnRyeShjb3VudHJ5Q29kZSksXG4gICAgICAgICAgICAgICAgICAgIGlzVXNlclNpZ25lZEluXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwidXNuYXRcIjpcbiAgICAgICAgICAgIHdpbmRvdy5fc3BfLmNvbmZpZy51c25hdCA9IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRpbmdQYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgZnJhbWV3b3JrXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIFwiYXVzXCI6XG4gICAgICAgICAgICB3aW5kb3cuX3NwXy5jb25maWcuY2NwYSA9IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRpbmdQYXJhbXM6IHtcbiAgICAgICAgICAgICAgICAgICAgZnJhbWV3b3JrXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbiAgICBjb25zdCBzcExpYiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJzY3JpcHRcIik7XG4gICAgc3BMaWIuaWQgPSBcInNvdXJjZXBvaW50LWxpYlwiO1xuICAgIHNwTGliLmFkZEV2ZW50TGlzdGVuZXIoXCJsb2FkXCIsICgpID0+IHtcbiAgICAgICAgaWYgKHNob3VsZE1lcmdlVmVuZG9yTGlzdChjb3VudHJ5Q29kZSwgdXNlTm9uQWR2ZXJ0aXNlZExpc3QpKSB7XG4gICAgICAgICAgICBtZXJnZVZlbmRvckxpc3QoKS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuX3NwXz8uZXhlY3V0ZU1lc3NhZ2luZz8uKCk7XG4gICAgICAgICAgICB9KS5jYXRjaCgoZXJyb3IpID0+IHtcbiAgICAgICAgICAgICAgICBsb2coXCJjbXBcIiwgYCdGYWlsZWQgdG8gbWVyZ2UgdmVuZG9yIGxpc3QnOiAke2Vycm9yfWApO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICB3aW5kb3cuX3NwXz8uZXhlY3V0ZU1lc3NhZ2luZz8uKCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBzcExpYi5zcmMgPSBgJHtFTkRQT0lOVH0vdW5pZmllZC93cmFwcGVyTWVzc2FnaW5nV2l0aG91dERldGVjdGlvbi5qc2A7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChzcExpYik7XG59O1xuZXhwb3J0IHsgaW5pdCwgd2lsbFNob3dQcml2YWN5TWVzc2FnZSB9O1xuIiwiaW1wb3J0IHsgc3R1Yl9ncHBfdXNuYXQgfSBmcm9tICcuL3N0dWJfZ3BwX3VzbmF0LmpzJztcbmltcG9ydCB7IHN0dWJfdGNmdjIgfSBmcm9tICcuL3N0dWJfdGNmdjIuanMnO1xuaW1wb3J0IHsgc3R1Yl91c3BhcGlfY2NwYSB9IGZyb20gJy4vc3R1Yl91c3BhcGlfY2NwYS5qcyc7XG5jb25zdCBsb2FkU3R1YnNGb3IgPSAoZnJhbWV3b3JrKSA9PiB7XG4gICAgc3dpdGNoIChmcmFtZXdvcmspIHtcbiAgICAgICAgY2FzZSBcInRjZnYyXCI6XG4gICAgICAgICAgICBzdHViX3RjZnYyKCk7XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSBcInVzbmF0XCI6XG4gICAgICAgICAgICBzdHViX2dwcF91c25hdCgpO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgXCJhdXNcIjpcbiAgICAgICAgICAgIHN0dWJfdXNwYXBpX2NjcGEoKTtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgIH1cbn07XG5leHBvcnQgeyBsb2FkU3R1YnNGb3IgfTtcbiIsImNvbnN0IHN0dWJfZ3BwX3VzbmF0ID0gKCkgPT4ge1xuICAgIHdpbmRvdy5fX2dwcF9hZGRGcmFtZSA9IGZ1bmN0aW9uIChlKSB7XG4gICAgICAgIGlmICghd2luZG93LmZyYW1lc1tlXSlcbiAgICAgICAgICAgIGlmIChkb2N1bWVudC5ib2R5KSB7XG4gICAgICAgICAgICAgICAgdmFyIHQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaWZyYW1lXCIpO1xuICAgICAgICAgICAgICAgIHQuc3R5bGUuY3NzVGV4dCA9IFwiZGlzcGxheTpub25lXCIsIHQubmFtZSA9IGUsIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQodCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgd2luZG93LnNldFRpbWVvdXQod2luZG93Ll9fZ3BwX2FkZEZyYW1lLCAxMCwgZSk7XG4gICAgfSwgd2luZG93Ll9fZ3BwX3N0dWIgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBlID0gYXJndW1lbnRzO1xuICAgICAgICBpZiAoX19ncHAucXVldWUgPSBfX2dwcC5xdWV1ZSB8fCBbXSwgX19ncHAuZXZlbnRzID0gX19ncHAuZXZlbnRzIHx8IFtdLCAhZS5sZW5ndGggfHwgMSA9PSBlLmxlbmd0aCAmJiBcInF1ZXVlXCIgPT0gZVswXSlcbiAgICAgICAgICAgIHJldHVybiBfX2dwcC5xdWV1ZTtcbiAgICAgICAgaWYgKDEgPT0gZS5sZW5ndGggJiYgXCJldmVudHNcIiA9PSBlWzBdKVxuICAgICAgICAgICAgcmV0dXJuIF9fZ3BwLmV2ZW50cztcbiAgICAgICAgdmFyIHQgPSBlWzBdLCBwID0gZS5sZW5ndGggPiAxID8gZVsxXSA6IG51bGwsIHMgPSBlLmxlbmd0aCA+IDIgPyBlWzJdIDogbnVsbDtcbiAgICAgICAgaWYgKFwicGluZ1wiID09PSB0KVxuICAgICAgICAgICAgcCh7XG4gICAgICAgICAgICAgICAgZ3BwVmVyc2lvbjogXCIxLjFcIixcbiAgICAgICAgICAgICAgICBjbXBTdGF0dXM6IFwic3R1YlwiLFxuICAgICAgICAgICAgICAgIGNtcERpc3BsYXlTdGF0dXM6IFwiaGlkZGVuXCIsXG4gICAgICAgICAgICAgICAgc2lnbmFsU3RhdHVzOiBcIm5vdCByZWFkeVwiLFxuICAgICAgICAgICAgICAgIHN1cHBvcnRlZEFQSXM6IFtcbiAgICAgICAgICAgICAgICAgICAgXCIyOnRjZmV1djJcIixcbiAgICAgICAgICAgICAgICAgICAgXCI1OnRjZmNhdjFcIixcbiAgICAgICAgICAgICAgICAgICAgXCI2OnVzcHYxXCIsXG4gICAgICAgICAgICAgICAgICAgIFwiNzp1c25hdHYxXCIsXG4gICAgICAgICAgICAgICAgICAgIFwiODp1c2NhdjFcIixcbiAgICAgICAgICAgICAgICAgICAgXCI5OnVzdmF2MVwiLFxuICAgICAgICAgICAgICAgICAgICBcIjEwOnVzY292MVwiLFxuICAgICAgICAgICAgICAgICAgICBcIjExOnVzdXR2MVwiLFxuICAgICAgICAgICAgICAgICAgICBcIjEyOnVzY3R2MVwiXG4gICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICBjbXBJZDogMCxcbiAgICAgICAgICAgICAgICBzZWN0aW9uTGlzdDogW10sXG4gICAgICAgICAgICAgICAgYXBwbGljYWJsZVNlY3Rpb25zOiBbXSxcbiAgICAgICAgICAgICAgICBncHBTdHJpbmc6IFwiXCIsXG4gICAgICAgICAgICAgICAgcGFyc2VkU2VjdGlvbnM6IHt9XG4gICAgICAgICAgICB9LCB0cnVlKTtcbiAgICAgICAgZWxzZSBpZiAoXCJhZGRFdmVudExpc3RlbmVyXCIgPT09IHQpIHtcbiAgICAgICAgICAgIFwibGFzdElkXCIgaW4gX19ncHAgfHwgKF9fZ3BwLmxhc3RJZCA9IDApLCBfX2dwcC5sYXN0SWQrKztcbiAgICAgICAgICAgIHZhciBuID0gX19ncHAubGFzdElkO1xuICAgICAgICAgICAgX19ncHAuZXZlbnRzLnB1c2goeyBpZDogbiwgY2FsbGJhY2s6IHAsIHBhcmFtZXRlcjogcyB9KSwgcCh7XG4gICAgICAgICAgICAgICAgZXZlbnROYW1lOiBcImxpc3RlbmVyUmVnaXN0ZXJlZFwiLFxuICAgICAgICAgICAgICAgIGxpc3RlbmVySWQ6IG4sXG4gICAgICAgICAgICAgICAgZGF0YTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBwaW5nRGF0YToge1xuICAgICAgICAgICAgICAgICAgICBncHBWZXJzaW9uOiBcIjEuMVwiLFxuICAgICAgICAgICAgICAgICAgICBjbXBTdGF0dXM6IFwic3R1YlwiLFxuICAgICAgICAgICAgICAgICAgICBjbXBEaXNwbGF5U3RhdHVzOiBcImhpZGRlblwiLFxuICAgICAgICAgICAgICAgICAgICBzaWduYWxTdGF0dXM6IFwibm90IHJlYWR5XCIsXG4gICAgICAgICAgICAgICAgICAgIHN1cHBvcnRlZEFQSXM6IFtcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiMjp0Y2ZldXYyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjU6dGNmY2F2MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCI2OnVzcHYxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjc6dXNuYXR2MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCI4OnVzY2F2MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCI5OnVzdmF2MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCIxMDp1c2NvdjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiMTE6dXN1dHYxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjEyOnVzY3R2MVwiXG4gICAgICAgICAgICAgICAgICAgIF0sXG4gICAgICAgICAgICAgICAgICAgIGNtcElkOiAwLFxuICAgICAgICAgICAgICAgICAgICBzZWN0aW9uTGlzdDogW10sXG4gICAgICAgICAgICAgICAgICAgIGFwcGxpY2FibGVTZWN0aW9uczogW10sXG4gICAgICAgICAgICAgICAgICAgIGdwcFN0cmluZzogXCJcIixcbiAgICAgICAgICAgICAgICAgICAgcGFyc2VkU2VjdGlvbnM6IHt9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSwgdHJ1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoXCJyZW1vdmVFdmVudExpc3RlbmVyXCIgPT09IHQpIHtcbiAgICAgICAgICAgIGZvciAodmFyIGEgPSBmYWxzZSwgaSA9IDA7IGkgPCBfX2dwcC5ldmVudHMubGVuZ3RoOyBpKyspXG4gICAgICAgICAgICAgICAgaWYgKF9fZ3BwLmV2ZW50c1tpXS5pZCA9PSBzKSB7XG4gICAgICAgICAgICAgICAgICAgIF9fZ3BwLmV2ZW50cy5zcGxpY2UoaSwgMSksIGEgPSB0cnVlO1xuICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICBwKHtcbiAgICAgICAgICAgICAgICBldmVudE5hbWU6IFwibGlzdGVuZXJSZW1vdmVkXCIsXG4gICAgICAgICAgICAgICAgbGlzdGVuZXJJZDogcyxcbiAgICAgICAgICAgICAgICBkYXRhOiBhLFxuICAgICAgICAgICAgICAgIHBpbmdEYXRhOiB7XG4gICAgICAgICAgICAgICAgICAgIGdwcFZlcnNpb246IFwiMS4xXCIsXG4gICAgICAgICAgICAgICAgICAgIGNtcFN0YXR1czogXCJzdHViXCIsXG4gICAgICAgICAgICAgICAgICAgIGNtcERpc3BsYXlTdGF0dXM6IFwiaGlkZGVuXCIsXG4gICAgICAgICAgICAgICAgICAgIHNpZ25hbFN0YXR1czogXCJub3QgcmVhZHlcIixcbiAgICAgICAgICAgICAgICAgICAgc3VwcG9ydGVkQVBJczogW1xuICAgICAgICAgICAgICAgICAgICAgICAgXCIyOnRjZmV1djJcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiNTp0Y2ZjYXYxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjY6dXNwdjFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiNzp1c25hdHYxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjg6dXNjYXYxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjk6dXN2YXYxXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBcIjEwOnVzY292MVwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgXCIxMTp1c3V0djFcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIFwiMTI6dXNjdHYxXCJcbiAgICAgICAgICAgICAgICAgICAgXSxcbiAgICAgICAgICAgICAgICAgICAgY21wSWQ6IDAsXG4gICAgICAgICAgICAgICAgICAgIHNlY3Rpb25MaXN0OiBbXSxcbiAgICAgICAgICAgICAgICAgICAgYXBwbGljYWJsZVNlY3Rpb25zOiBbXSxcbiAgICAgICAgICAgICAgICAgICAgZ3BwU3RyaW5nOiBcIlwiLFxuICAgICAgICAgICAgICAgICAgICBwYXJzZWRTZWN0aW9uczoge31cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCB0cnVlKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlXG4gICAgICAgICAgICBcImhhc1NlY3Rpb25cIiA9PT0gdCA/IHAoZmFsc2UsIHRydWUpIDogXCJnZXRTZWN0aW9uXCIgPT09IHQgfHwgXCJnZXRGaWVsZFwiID09PSB0ID8gcChudWxsLCB0cnVlKSA6IF9fZ3BwLnF1ZXVlLnB1c2goW10uc2xpY2UuYXBwbHkoZSkpO1xuICAgIH0sIHdpbmRvdy5fX2dwcF9tc2doYW5kbGVyID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgdmFyIHQgPSBcInN0cmluZ1wiID09IHR5cGVvZiBlLmRhdGE7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICB2YXIgcCA9IHQgPyBKU09OLnBhcnNlKGUuZGF0YSkgOiBlLmRhdGE7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUyKSB7XG4gICAgICAgICAgICBwID0gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICBpZiAoXCJvYmplY3RcIiA9PSB0eXBlb2YgcCAmJiBudWxsICE9PSBwICYmIFwiX19ncHBDYWxsXCIgaW4gcCkge1xuICAgICAgICAgICAgdmFyIHMgPSBwLl9fZ3BwQ2FsbDtcbiAgICAgICAgICAgIHdpbmRvdy5fX2dwcChzLmNvbW1hbmQsIGZ1bmN0aW9uIChwMiwgbikge1xuICAgICAgICAgICAgICAgIHZhciBhID0ge1xuICAgICAgICAgICAgICAgICAgICBfX2dwcFJldHVybjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuVmFsdWU6IHAyLFxuICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogbixcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxJZDogcy5jYWxsSWRcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgZS5zb3VyY2UucG9zdE1lc3NhZ2UodCA/IEpTT04uc3RyaW5naWZ5KGEpIDogYSwgXCIqXCIpO1xuICAgICAgICAgICAgfSwgXCJwYXJhbWV0ZXJcIiBpbiBzID8gcy5wYXJhbWV0ZXIgOiBudWxsLCBcInZlcnNpb25cIiBpbiBzID8gcy52ZXJzaW9uIDogXCIxLjFcIik7XG4gICAgICAgIH1cbiAgICB9LCBcIl9fZ3BwXCIgaW4gd2luZG93ICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2Ygd2luZG93Ll9fZ3BwIHx8ICh3aW5kb3cuX19ncHAgPSB3aW5kb3cuX19ncHBfc3R1Yiwgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHdpbmRvdy5fX2dwcF9tc2doYW5kbGVyLCBmYWxzZSksIHdpbmRvdy5fX2dwcF9hZGRGcmFtZShcIl9fZ3BwTG9jYXRvclwiKSk7XG59O1xuZXhwb3J0IHsgc3R1Yl9ncHBfdXNuYXQgfTtcbiIsImNvbnN0IHN0dWJfdGNmdjIgPSAoKSA9PiB7XG4gICAgIWZ1bmN0aW9uICh0KSB7XG4gICAgICAgIHZhciBlID0ge307XG4gICAgICAgIGZ1bmN0aW9uIG4ocikge1xuICAgICAgICAgICAgaWYgKGVbcl0pXG4gICAgICAgICAgICAgICAgcmV0dXJuIGVbcl0uZXhwb3J0cztcbiAgICAgICAgICAgIHZhciBvID0gZVtyXSA9IHsgaTogciwgbDogZmFsc2UsIGV4cG9ydHM6IHt9IH07XG4gICAgICAgICAgICByZXR1cm4gdFtyXS5jYWxsKG8uZXhwb3J0cywgbywgby5leHBvcnRzLCBuKSwgby5sID0gdHJ1ZSwgby5leHBvcnRzO1xuICAgICAgICB9XG4gICAgICAgIG4ubSA9IHQsIG4uYyA9IGUsIG4uZCA9IGZ1bmN0aW9uICh0MiwgZTIsIHIpIHtcbiAgICAgICAgICAgIG4ubyh0MiwgZTIpIHx8IE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0MiwgZTIsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiByIH0pO1xuICAgICAgICB9LCBuLnIgPSBmdW5jdGlvbiAodDIpIHtcbiAgICAgICAgICAgIFwidW5kZWZpbmVkXCIgIT0gdHlwZW9mIFN5bWJvbCAmJiBTeW1ib2wudG9TdHJpbmdUYWcgJiYgT2JqZWN0LmRlZmluZVByb3BlcnR5KHQyLCBTeW1ib2wudG9TdHJpbmdUYWcsIHtcbiAgICAgICAgICAgICAgICB2YWx1ZTogXCJNb2R1bGVcIlxuICAgICAgICAgICAgfSksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eSh0MiwgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG4gICAgICAgIH0sIG4udCA9IGZ1bmN0aW9uICh0MiwgZTIpIHtcbiAgICAgICAgICAgIGlmICgxICYgZTIgJiYgKHQyID0gbih0MikpLCA4ICYgZTIpXG4gICAgICAgICAgICAgICAgcmV0dXJuIHQyO1xuICAgICAgICAgICAgaWYgKDQgJiBlMiAmJiBcIm9iamVjdFwiID09IHR5cGVvZiB0MiAmJiB0MiAmJiB0Mi5fX2VzTW9kdWxlKVxuICAgICAgICAgICAgICAgIHJldHVybiB0MjtcbiAgICAgICAgICAgIHZhciByID0gLyogQF9fUFVSRV9fICovIE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgICAgICBpZiAobi5yKHIpLCBPYmplY3QuZGVmaW5lUHJvcGVydHkociwgXCJkZWZhdWx0XCIsIHtcbiAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIHZhbHVlOiB0MlxuICAgICAgICAgICAgfSksIDIgJiBlMiAmJiBcInN0cmluZ1wiICE9IHR5cGVvZiB0MilcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBvIGluIHQyKVxuICAgICAgICAgICAgICAgICAgICBuLmQociwgbywgZnVuY3Rpb24gKGUzKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gdDJbZTNdO1xuICAgICAgICAgICAgICAgICAgICB9LmJpbmQobnVsbCwgbykpO1xuICAgICAgICAgICAgcmV0dXJuIHI7XG4gICAgICAgIH0sIG4ubiA9IGZ1bmN0aW9uICh0Mikge1xuICAgICAgICAgICAgdmFyIGUyID0gdDIgJiYgdDIuX19lc01vZHVsZSA/IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdDIuZGVmYXVsdDtcbiAgICAgICAgICAgIH0gOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHQyO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJldHVybiBuLmQoZTIsIFwiYVwiLCBlMiksIGUyO1xuICAgICAgICB9LCBuLm8gPSBmdW5jdGlvbiAodDIsIGUyKSB7XG4gICAgICAgICAgICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQyLCBlMik7XG4gICAgICAgIH0sIG4ucCA9IFwiXCIsIG4obi5zID0gMyk7XG4gICAgfShbXG4gICAgICAgIGZ1bmN0aW9uICh0LCBlLCBuKSB7XG4gICAgICAgICAgICB2YXIgciA9IG4oMik7XG4gICAgICAgICAgICB0LmV4cG9ydHMgPSAhcihmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIDcgIT0gT2JqZWN0LmRlZmluZVByb3BlcnR5KHt9LCBcImFcIiwge1xuICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA3O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSkuYTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBmdW5jdGlvbiAodCwgZSkge1xuICAgICAgICAgICAgdC5leHBvcnRzID0gZnVuY3Rpb24gKHQyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwib2JqZWN0XCIgPT0gdHlwZW9mIHQyID8gbnVsbCAhPT0gdDIgOiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIHQyO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgZnVuY3Rpb24gKHQsIGUpIHtcbiAgICAgICAgICAgIHQuZXhwb3J0cyA9IGZ1bmN0aW9uICh0Mikge1xuICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAhIXQyKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNhdGNoICh0Mykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgICAgICBmdW5jdGlvbiAodCwgZSwgbikge1xuICAgICAgICAgICAgbig0KSwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGlmIChcImZ1bmN0aW9uXCIgIT0gdHlwZW9mIHdpbmRvdy5fX3RjZmFwaSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgdDIsIGUyID0gW10sIG4yID0gd2luZG93LCByID0gbjIuZG9jdW1lbnQ7XG4gICAgICAgICAgICAgICAgICAgICFuMi5fX3RjZmFwaSAmJiBmdW5jdGlvbiB0MygpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBlMyA9ICEhbjIuZnJhbWVzLl9fdGNmYXBpTG9jYXRvcjtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZTMpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHIuYm9keSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbyA9IHIuY3JlYXRlRWxlbWVudChcImlmcmFtZVwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgby5zdHlsZS5jc3NUZXh0ID0gXCJkaXNwbGF5Om5vbmVcIiwgby5uYW1lID0gXCJfX3RjZmFwaUxvY2F0b3JcIiwgci5ib2R5LmFwcGVuZENoaWxkKG8pO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNldFRpbWVvdXQodDMsIDUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuICFlMztcbiAgICAgICAgICAgICAgICAgICAgfSgpICYmIChuMi5fX3RjZmFwaSA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIG4zID0gYXJndW1lbnRzLmxlbmd0aCwgcjIgPSBuZXcgQXJyYXkobjMpLCBvID0gMDsgbyA8IG4zOyBvKyspXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcjJbb10gPSBhcmd1bWVudHNbb107XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXIyLmxlbmd0aClcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gZTI7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAoXCJzZXRHZHByQXBwbGllc1wiID09PSByMlswXSlcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICByMi5sZW5ndGggPiAzICYmIDIgPT09IHBhcnNlSW50KHIyWzFdLCAxMCkgJiYgXCJib29sZWFuXCIgPT0gdHlwZW9mIHIyWzNdICYmICh0MiA9IHIyWzNdLCBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIHIyWzJdICYmIHIyWzJdKFwic2V0XCIsIHRydWUpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKFwicGluZ1wiID09PSByMlswXSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBpID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBnZHByQXBwbGllczogdDIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNtcExvYWRlZDogZmFsc2UsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFwaVZlcnNpb246IFwiMi4wXCJcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgcjJbMl0gJiYgcjJbMl0oaSwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBlbHNlXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZTIucHVzaChyMik7XG4gICAgICAgICAgICAgICAgICAgIH0sIG4yLmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIGZ1bmN0aW9uICh0Mykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGUzID0gXCJzdHJpbmdcIiA9PSB0eXBlb2YgdDMuZGF0YSwgcjIgPSB7fTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcjIgPSBlMyA/IEpTT04ucGFyc2UodDMuZGF0YSkgOiB0My5kYXRhO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKHQ0KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgbyA9IHIyLl9fdGNmYXBpQ2FsbDtcbiAgICAgICAgICAgICAgICAgICAgICAgIG8gJiYgbjIuX190Y2ZhcGkoby5jb21tYW5kLCBvLnZlcnNpb24sIGZ1bmN0aW9uIChuMywgcjMpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgaSA9IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgX190Y2ZhcGlSZXR1cm46IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVyblZhbHVlOiBuMyxcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN1Y2Nlc3M6IHIzLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY2FsbElkOiBvLmNhbGxJZFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBlMyAmJiAoaSA9IEpTT04uc3RyaW5naWZ5KGkpKSwgdDMuc291cmNlLnBvc3RNZXNzYWdlKGksIFwiKlwiKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH0sIG8ucGFyYW1ldGVyKTtcbiAgICAgICAgICAgICAgICAgICAgfSwgZmFsc2UpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9KCk7XG4gICAgICAgIH0sXG4gICAgICAgIGZ1bmN0aW9uICh0LCBlLCBuKSB7XG4gICAgICAgICAgICB2YXIgciA9IG4oMCksIG8gPSBuKDUpLmYsIGkgPSBGdW5jdGlvbi5wcm90b3R5cGUsIGMgPSBpLnRvU3RyaW5nLCB1ID0gL15zKmZ1bmN0aW9uIChbXiAoXSopLztcbiAgICAgICAgICAgIHIgJiYgIShcIm5hbWVcIiBpbiBpKSAmJiBvKGksIFwibmFtZVwiLCB7XG4gICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgIGdldDogZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGMuY2FsbCh0aGlzKS5tYXRjaCh1KVsxXTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXRjaCAodDIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0sXG4gICAgICAgIGZ1bmN0aW9uICh0LCBlLCBuKSB7XG4gICAgICAgICAgICB2YXIgciA9IG4oMCksIG8gPSBuKDYpLCBpID0gbigxMCksIGMgPSBuKDExKSwgdSA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbiAgICAgICAgICAgIGUuZiA9IHIgPyB1IDogZnVuY3Rpb24gKHQyLCBlMiwgbjIpIHtcbiAgICAgICAgICAgICAgICBpZiAoaSh0MiksIGUyID0gYyhlMiwgdHJ1ZSksIGkobjIpLCBvKVxuICAgICAgICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHUodDIsIGUyLCBuMik7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKHQzKSB7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoXCJnZXRcIiBpbiBuMiB8fCBcInNldFwiIGluIG4yKVxuICAgICAgICAgICAgICAgICAgICB0aHJvdyBUeXBlRXJyb3IoXCJBY2Nlc3NvcnMgbm90IHN1cHBvcnRlZFwiKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJ2YWx1ZVwiIGluIG4yICYmICh0MltlMl0gPSBuMi52YWx1ZSksIHQyO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgZnVuY3Rpb24gKHQsIGUsIG4pIHtcbiAgICAgICAgICAgIHZhciByID0gbigwKSwgbyA9IG4oMiksIGkgPSBuKDcpO1xuICAgICAgICAgICAgdC5leHBvcnRzID0gIXIgJiYgIW8oZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiA3ICE9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShpKFwiZGl2XCIpLCBcImFcIiwge1xuICAgICAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiA3O1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgfSkuYTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9LFxuICAgICAgICBmdW5jdGlvbiAodCwgZSwgbikge1xuICAgICAgICAgICAgdmFyIHIgPSBuKDgpLCBvID0gbigxKSwgaSA9IHIuZG9jdW1lbnQsIGMgPSBvKGkpICYmIG8oaS5jcmVhdGVFbGVtZW50KTtcbiAgICAgICAgICAgIHQuZXhwb3J0cyA9IGZ1bmN0aW9uICh0Mikge1xuICAgICAgICAgICAgICAgIHJldHVybiBjID8gaS5jcmVhdGVFbGVtZW50KHQyKSA6IHt9O1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfSxcbiAgICAgICAgZnVuY3Rpb24gKHQsIGUsIG4pIHtcbiAgICAgICAgICAgIChmdW5jdGlvbiAoZTIpIHtcbiAgICAgICAgICAgICAgICB2YXIgbjIgPSBmdW5jdGlvbiAodDIpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHQyICYmIHQyLk1hdGggPT0gTWF0aCAmJiB0MjtcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIHQuZXhwb3J0cyA9IG4yKFwib2JqZWN0XCIgPT0gdHlwZW9mIGdsb2JhbFRoaXMgJiYgZ2xvYmFsVGhpcykgfHwgbjIoXCJvYmplY3RcIiA9PSB0eXBlb2Ygd2luZG93ICYmIHdpbmRvdykgfHwgbjIoXCJvYmplY3RcIiA9PSB0eXBlb2Ygc2VsZiAmJiBzZWxmKSB8fCBuMihcIm9iamVjdFwiID09IHR5cGVvZiBlMiAmJiBlMikgfHwgRnVuY3Rpb24oXCJyZXR1cm4gdGhpc1wiKSgpO1xuICAgICAgICAgICAgfSkuY2FsbCh0aGlzLCBuKDkpKTtcbiAgICAgICAgfSxcbiAgICAgICAgZnVuY3Rpb24gKHQsIGUpIHtcbiAgICAgICAgICAgIHZhciBuO1xuICAgICAgICAgICAgbiA9IC8qIEBfX1BVUkVfXyAqLyBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgICB9KCk7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIG4gPSBuIHx8IG5ldyBGdW5jdGlvbihcInJldHVybiB0aGlzXCIpKCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAodDIpIHtcbiAgICAgICAgICAgICAgICBcIm9iamVjdFwiID09IHR5cGVvZiB3aW5kb3cgJiYgKG4gPSB3aW5kb3cpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdC5leHBvcnRzID0gbjtcbiAgICAgICAgfSxcbiAgICAgICAgZnVuY3Rpb24gKHQsIGUsIG4pIHtcbiAgICAgICAgICAgIHZhciByID0gbigxKTtcbiAgICAgICAgICAgIHQuZXhwb3J0cyA9IGZ1bmN0aW9uICh0Mikge1xuICAgICAgICAgICAgICAgIGlmICghcih0MikpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IFR5cGVFcnJvcihTdHJpbmcodDIpICsgXCIgaXMgbm90IGFuIG9iamVjdFwiKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gdDI7XG4gICAgICAgICAgICB9O1xuICAgICAgICB9LFxuICAgICAgICBmdW5jdGlvbiAodCwgZSwgbikge1xuICAgICAgICAgICAgdmFyIHIgPSBuKDEpO1xuICAgICAgICAgICAgdC5leHBvcnRzID0gZnVuY3Rpb24gKHQyLCBlMikge1xuICAgICAgICAgICAgICAgIGlmICghcih0MikpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0MjtcbiAgICAgICAgICAgICAgICB2YXIgbjIsIG87XG4gICAgICAgICAgICAgICAgaWYgKGUyICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgKG4yID0gdDIudG9TdHJpbmcpICYmICFyKG8gPSBuMi5jYWxsKHQyKSkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvO1xuICAgICAgICAgICAgICAgIGlmIChcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIChuMiA9IHQyLnZhbHVlT2YpICYmICFyKG8gPSBuMi5jYWxsKHQyKSkpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvO1xuICAgICAgICAgICAgICAgIGlmICghZTIgJiYgXCJmdW5jdGlvblwiID09IHR5cGVvZiAobjIgPSB0Mi50b1N0cmluZykgJiYgIXIobyA9IG4yLmNhbGwodDIpKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG87XG4gICAgICAgICAgICAgICAgdGhyb3cgVHlwZUVycm9yKFwiQ2FuJ3QgY29udmVydCBvYmplY3QgdG8gcHJpbWl0aXZlIHZhbHVlXCIpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgIF0pO1xufTtcbmV4cG9ydCB7IHN0dWJfdGNmdjIgfTtcbiIsImNvbnN0IHN0dWJfdXNwYXBpX2NjcGEgPSAoKSA9PiB7XG4gICAgKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgdmFyIGUgPSBmYWxzZTtcbiAgICAgICAgdmFyIGMgPSB3aW5kb3c7XG4gICAgICAgIHZhciB0ID0gZG9jdW1lbnQ7XG4gICAgICAgIGZ1bmN0aW9uIHIoKSB7XG4gICAgICAgICAgICBpZiAoIWMuZnJhbWVzW1wiX191c3BhcGlMb2NhdG9yXCJdKSB7XG4gICAgICAgICAgICAgICAgaWYgKHQuYm9keSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgYSA9IHQuYm9keTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGUyID0gdC5jcmVhdGVFbGVtZW50KFwiaWZyYW1lXCIpO1xuICAgICAgICAgICAgICAgICAgICBlMi5zdHlsZS5jc3NUZXh0ID0gXCJkaXNwbGF5Om5vbmVcIjtcbiAgICAgICAgICAgICAgICAgICAgZTIubmFtZSA9IFwiX191c3BhcGlMb2NhdG9yXCI7XG4gICAgICAgICAgICAgICAgICAgIGEuYXBwZW5kQ2hpbGQoZTIpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgc2V0VGltZW91dChyLCA1KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcigpO1xuICAgICAgICBmdW5jdGlvbiBwKCkge1xuICAgICAgICAgICAgdmFyIGEgPSBhcmd1bWVudHM7XG4gICAgICAgICAgICBfX3VzcGFwaS5hID0gX191c3BhcGkuYSB8fCBbXTtcbiAgICAgICAgICAgIGlmICghYS5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX191c3BhcGkuYTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGFbMF0gPT09IFwicGluZ1wiKSB7XG4gICAgICAgICAgICAgICAgYVsyXSh7IGdkcHJBcHBsaWVzR2xvYmFsbHk6IGUsIGNtcExvYWRlZDogZmFsc2UgfSwgdHJ1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBfX3VzcGFwaS5hLnB1c2goW10uc2xpY2UuYXBwbHkoYSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIGwodDIpIHtcbiAgICAgICAgICAgIHZhciByMiA9IHR5cGVvZiB0Mi5kYXRhID09PSBcInN0cmluZ1wiO1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB2YXIgYSA9IHIyID8gSlNPTi5wYXJzZSh0Mi5kYXRhKSA6IHQyLmRhdGE7XG4gICAgICAgICAgICAgICAgaWYgKGEuX19jbXBDYWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBuID0gYS5fX2NtcENhbGw7XG4gICAgICAgICAgICAgICAgICAgIGMuX191c3BhcGkobi5jb21tYW5kLCBuLnBhcmFtZXRlciwgZnVuY3Rpb24gKGEyLCBlMikge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGMyID0ge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIF9fY21wUmV0dXJuOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVyblZhbHVlOiBhMixcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgc3VjY2VzczogZTIsXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxJZDogbi5jYWxsSWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgICAgICAgICAgdDIuc291cmNlLnBvc3RNZXNzYWdlKHIyID8gSlNPTi5zdHJpbmdpZnkoYzIpIDogYzIsIFwiKlwiKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY2F0Y2ggKGEyKSB7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiBfX3VzcGFwaSAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICBjLl9fdXNwYXBpID0gcDtcbiAgICAgICAgICAgIF9fdXNwYXBpLm1zZ0hhbmRsZXIgPSBsO1xuICAgICAgICAgICAgYy5hZGRFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCBsLCBmYWxzZSk7XG4gICAgICAgIH1cbiAgICB9KSgpO1xufTtcbmV4cG9ydCB7IHN0dWJfdXNwYXBpX2NjcGEgfTtcbiIsImNvbnN0IGFwaSA9IChjb21tYW5kLCB2ZW5kb3JJZHMsIHB1cnBvc2VJZHMsIGxlZ2l0aW1hdGVJbnRlcmVzdFB1cnBvc2VJZHMpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICBpZiAod2luZG93Ll9fdGNmYXBpKSB7XG4gICAgICAgIHdpbmRvdy5fX3RjZmFwaShjb21tYW5kLCAyLCAocmVzdWx0LCBzdWNjZXNzKSA9PiBzdWNjZXNzID8gcmVzb2x2ZShyZXN1bHQpIDogKFxuICAgICAgICAvKiBpc3RhbmJ1bCBpZ25vcmUgbmV4dCAqL1xuICAgICAgICByZWplY3QobmV3IEVycm9yKGBVbmFibGUgdG8gZ2V0ICR7Y29tbWFuZH0gZGF0YWApKSksIHZlbmRvcklkcywgcHVycG9zZUlkcywgbGVnaXRpbWF0ZUludGVyZXN0UHVycG9zZUlkcyk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZWplY3QobmV3IEVycm9yKFwiTm8gX190Y2ZhcGkgZm91bmQgb24gd2luZG93XCIpKTtcbiAgICB9XG59KTtcbmNvbnN0IGdldFRDRGF0YSA9ICgpID0+IGFwaShcImFkZEV2ZW50TGlzdGVuZXJcIik7XG5jb25zdCBnZXRDdXN0b21WZW5kb3JDb25zZW50cyA9ICgpID0+IGFwaShcImdldEN1c3RvbVZlbmRvckNvbnNlbnRzXCIpO1xuZXhwb3J0IHsgZ2V0Q3VzdG9tVmVuZG9yQ29uc2VudHMsIGdldFRDRGF0YSB9O1xuIiwiaW1wb3J0IHsgZ2V0Q3VycmVudEZyYW1ld29yayB9IGZyb20gJy4uL2dldEN1cnJlbnRGcmFtZXdvcmsuanMnO1xuaW1wb3J0IHsgZ2V0VENEYXRhLCBnZXRDdXN0b21WZW5kb3JDb25zZW50cyB9IGZyb20gJy4vYXBpLmpzJztcbmNvbnN0IGRlZmF1bHRDb25zZW50cyA9IHtcbiAgICBcIjFcIjogZmFsc2UsXG4gICAgXCIyXCI6IGZhbHNlLFxuICAgIFwiM1wiOiBmYWxzZSxcbiAgICBcIjRcIjogZmFsc2UsXG4gICAgXCI1XCI6IGZhbHNlLFxuICAgIFwiNlwiOiBmYWxzZSxcbiAgICBcIjdcIjogZmFsc2UsXG4gICAgXCI4XCI6IGZhbHNlLFxuICAgIFwiOVwiOiBmYWxzZSxcbiAgICBcIjEwXCI6IGZhbHNlLFxuICAgIFwiMTFcIjogZmFsc2Vcbn07XG5jb25zdCBnZXRDb25zZW50U3RhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgW3RjRGF0YSwgY3VzdG9tVmVuZG9yc10gPSBhd2FpdCBQcm9taXNlLmFsbChbXG4gICAgICAgIGdldFRDRGF0YSgpLFxuICAgICAgICBnZXRDdXN0b21WZW5kb3JDb25zZW50cygpXG4gICAgXSk7XG4gICAgaWYgKHR5cGVvZiB0Y0RhdGEgPT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICAgICAgY29uc3QgY3VycmVudEZyYW1ld29yayA9IGdldEN1cnJlbnRGcmFtZXdvcmsoKSA/PyBcInVuZGVmaW5lZFwiO1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYE5vIFRDIERhdGEgZm91bmQgd2l0aCBjdXJyZW50IGZyYW1ld29yazogJHtjdXJyZW50RnJhbWV3b3JrfWApO1xuICAgIH1cbiAgICBjb25zdCBjb25zZW50cyA9IHtcbiAgICAgICAgLi4uZGVmYXVsdENvbnNlbnRzLFxuICAgICAgICAuLi50Y0RhdGEucHVycG9zZS5jb25zZW50c1xuICAgIH07XG4gICAgY29uc3QgeyBldmVudFN0YXR1cywgZ2RwckFwcGxpZXMsIHRjU3RyaW5nLCBhZGR0bENvbnNlbnQgfSA9IHRjRGF0YTtcbiAgICBjb25zdCB7IGdyYW50cyB9ID0gY3VzdG9tVmVuZG9ycztcbiAgICBjb25zdCB2ZW5kb3JDb25zZW50cyA9IE9iamVjdC5rZXlzKGdyYW50cykuc29ydCgpLnJlZHVjZSgoYWNjLCBjdXIpID0+ICh7IC4uLmFjYywgW2N1cl06IGdyYW50c1tjdXJdPy52ZW5kb3JHcmFudCB9KSwge30pO1xuICAgIHJldHVybiB7XG4gICAgICAgIGNvbnNlbnRzLFxuICAgICAgICBldmVudFN0YXR1cyxcbiAgICAgICAgdmVuZG9yQ29uc2VudHMsXG4gICAgICAgIGFkZHRsQ29uc2VudCxcbiAgICAgICAgZ2RwckFwcGxpZXMsXG4gICAgICAgIHRjU3RyaW5nXG4gICAgfTtcbn07XG5leHBvcnQgeyBnZXRDb25zZW50U3RhdGUgfTtcbiIsImNvbnN0IGFwaSA9ICgpID0+IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgaWYgKHdpbmRvdy5fc3BfPy51c25hdD8uZ2V0VXNlckNvbnNlbnRzKSB7XG4gICAgICAgIHdpbmRvdy5fc3BfLnVzbmF0LmdldFVzZXJDb25zZW50cygodXNOYXREYXRhKSA9PiB7XG4gICAgICAgICAgICByZXR1cm4gcmVzb2x2ZSh7IC4uLnVzTmF0RGF0YSwgc2lnbmFsU3RhdHVzOiBcInJlYWR5XCIgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmVzb2x2ZSh7XG4gICAgICAgICAgICBhcHBsaWVzOiBmYWxzZSxcbiAgICAgICAgICAgIGNhdGVnb3JpZXM6IFtdLFxuICAgICAgICAgICAgdmVuZG9yczogW10sXG4gICAgICAgICAgICBzaWduYWxTdGF0dXM6IFwibm90IHJlYWR5XCJcbiAgICAgICAgfSk7XG4gICAgfVxufSk7XG5jb25zdCBnZXRVc25hdERhdGEgPSAoKSA9PiBhcGkoKTtcbmV4cG9ydCB7IGFwaSwgZ2V0VXNuYXREYXRhIH07XG4iLCJpbXBvcnQgeyBnZXRVc25hdERhdGEgfSBmcm9tICcuL2FwaS5qcyc7XG5jb25zdCBnZXRDb25zZW50U3RhdGUgPSBhc3luYyAoKSA9PiB7XG4gICAgbGV0IGRvTm90U2VsbCA9IGZhbHNlO1xuICAgIGNvbnN0IHVzbmF0RGF0YSA9IGF3YWl0IGdldFVzbmF0RGF0YSgpO1xuICAgIGRvTm90U2VsbCA9IHVzbmF0RGF0YS5jYXRlZ29yaWVzPy5maW5kKChjYXRlZ29yeSkgPT4gY2F0ZWdvcnkuc3lzdGVtSWQgPT09IDMpPy5jb25zZW50ZWQgPT09IGZhbHNlO1xuICAgIHJldHVybiB7XG4gICAgICAgIGRvTm90U2VsbCxcbiAgICAgICAgc2lnbmFsU3RhdHVzOiB1c25hdERhdGEuc2lnbmFsU3RhdHVzXG4gICAgfTtcbn07XG5leHBvcnQgeyBnZXRDb25zZW50U3RhdGUgfTtcbiIsImltcG9ydCB7IHJlbW92ZUNvb2tpZSB9IGZyb20gJy4uL2Nvb2tpZXMvcmVtb3ZlQ29va2llLmpzJztcbmltcG9ydCB7IHN0b3JhZ2UgfSBmcm9tICcuLi9zdG9yYWdlL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHsgZ2V0Q29uc2VudEZvciB9IGZyb20gJy4vZ2V0Q29uc2VudEZvci5qcyc7XG5pbXBvcnQgeyBvbkNvbnNlbnRDaGFuZ2UgfSBmcm9tICcuL29uQ29uc2VudENoYW5nZS5qcyc7XG5pbXBvcnQgeyB2ZW5kb3JTdG9yYWdlSWRzLCBkZXByZWNhdGVkVmVuZG9yU3RvcmFnZUlkcyB9IGZyb20gJy4vdmVuZG9yU3RvcmFnZUlkcy5qcyc7XG5jb25zdCByZW1vdmVEYXRhID0gKHsgY29va2llcyA9IFtdLCBsb2NhbFN0b3JhZ2UgPSBbXSwgc2Vzc2lvblN0b3JhZ2UgPSBbXSB9KSA9PiB7XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIGNvb2tpZXMpIHtcbiAgICAgICAgcmVtb3ZlQ29va2llKHsgbmFtZSB9KTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIGxvY2FsU3RvcmFnZSkge1xuICAgICAgICBzdG9yYWdlLmxvY2FsLnJlbW92ZShuYW1lKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBuYW1lIG9mIHNlc3Npb25TdG9yYWdlKSB7XG4gICAgICAgIHN0b3JhZ2Uuc2Vzc2lvbi5yZW1vdmUobmFtZSk7XG4gICAgfVxufTtcbmNvbnN0IHJlbW92ZVVuY29uc2VudGVkRGF0YSA9IChjb25zZW50KSA9PiB7XG4gICAgT2JqZWN0LmtleXModmVuZG9yU3RvcmFnZUlkcykuZm9yRWFjaCgodmVuZG9yKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbnNlbnRGb3JWZW5kb3IgPSBnZXRDb25zZW50Rm9yKHZlbmRvciwgY29uc2VudCk7XG4gICAgICAgIGNvbnN0IHZlbmRvckRhdGEgPSB2ZW5kb3JTdG9yYWdlSWRzW3ZlbmRvcl07XG4gICAgICAgIGlmICghY29uc2VudEZvclZlbmRvcikge1xuICAgICAgICAgICAgcmVtb3ZlRGF0YSh2ZW5kb3JEYXRhKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIE9iamVjdC5lbnRyaWVzKGRlcHJlY2F0ZWRWZW5kb3JTdG9yYWdlSWRzKS5mb3JFYWNoKChbLCB2ZW5kb3JEYXRhXSkgPT4gcmVtb3ZlRGF0YSh2ZW5kb3JEYXRhKSk7XG59O1xuY29uc3QgaW5pdFZlbmRvckRhdGFNYW5hZ2VyID0gKCkgPT4ge1xuICAgIG9uQ29uc2VudENoYW5nZSgoY29uc2VudCkgPT4ge1xuICAgICAgICBpZiAoXCJyZXF1ZXN0SWRsZUNhbGxiYWNrXCIgaW4gd2luZG93KSB7XG4gICAgICAgICAgICByZXF1ZXN0SWRsZUNhbGxiYWNrKCgpID0+IHtcbiAgICAgICAgICAgICAgICByZW1vdmVVbmNvbnNlbnRlZERhdGEoY29uc2VudCk7XG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgdGltZW91dDogMmUzXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlbW92ZVVuY29uc2VudGVkRGF0YShjb25zZW50KTtcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbmV4cG9ydCB7IGluaXRWZW5kb3JEYXRhTWFuYWdlciB9O1xuIiwiY29uc3QgdmVuZG9yU3RvcmFnZUlkcyA9IHtcbiAgICBhOToge1xuICAgICAgICBsb2NhbFN0b3JhZ2U6IFtcImFwc3RhZ1VzZXJBZ2VudENsaWVudEhpbnRzXCIsIFwiYXBzdGFnQ3hNRW5hYmxlZFwiXVxuICAgIH0sXG4gICAgaW5pemlvOiB7XG4gICAgICAgIGxvY2FsU3RvcmFnZTogW1wiX19ibV9zXCIsIFwiX19ibV9tXCJdXG4gICAgfSxcbiAgICBjcml0ZW86IHtcbiAgICAgICAgY29va2llczogW1wiY3RvX2J1bmRsZVwiXSxcbiAgICAgICAgbG9jYWxTdG9yYWdlOiBbXG4gICAgICAgICAgICBcImNyaXRlb19mYXN0X2JpZF9leHBpcmVzXCIsXG4gICAgICAgICAgICBcImN0b19idW5kbGVcIixcbiAgICAgICAgICAgIFwiY3JpdGVvX2Zhc3RfYmlkXCIsXG4gICAgICAgICAgICBcImNyaXRlb19wdF9jZGJfbW5ncl9tZXRyaWNzXCIsXG4gICAgICAgICAgICBcIl9fYW5zeW5jM3JkcF9jcml0ZW9cIlxuICAgICAgICBdXG4gICAgfSxcbiAgICBjb21zY29yZToge1xuICAgICAgICBjb29raWVzOiBbXCJjb21TY29yZVwiLCBcIl9zY29yX3VpZFwiXVxuICAgIH0sXG4gICAgaXBzb3M6IHtcbiAgICAgICAgY29va2llczogW1wiRE1fU2l0SWQxMDczXCIsIFwiRE1fU2l0SWQxMDczU2VjSWQ1ODAyXCIsIFwiRG90TWV0cmljcy5BbXBDb29raWVcIl0sXG4gICAgICAgIGxvY2FsU3RvcmFnZTogW1xuICAgICAgICAgICAgXCJEb3RtZXRyaWNzU2l0ZURhdGFcIixcbiAgICAgICAgICAgIFwiRG90TWV0cmljc1RpbWVPblBhZ2VcIixcbiAgICAgICAgICAgIFwiRG90TWV0cmljc1VzZXJJZFwiLFxuICAgICAgICAgICAgXCJEb3RNZXRyaWNzRGV2aWNlR3VpZElkXCJcbiAgICAgICAgXVxuICAgIH0sXG4gICAgcGVybXV0aXZlOiB7XG4gICAgICAgIGNvb2tpZXM6IFtcInBlcm11dGl2ZS1pZFwiXSxcbiAgICAgICAgbG9jYWxTdG9yYWdlOiBbXG4gICAgICAgICAgICBcInBlcm11dGl2ZS1kYXRhLXF1ZXJpZXNcIixcbiAgICAgICAgICAgIFwiX3B1YmNpZFwiLFxuICAgICAgICAgICAgXCJwZXJtdXRpdmUtcHZjXCIsXG4gICAgICAgICAgICBcInBlcm11dGl2ZS1kYXRhLWVucmljaGVyc1wiLFxuICAgICAgICAgICAgXCJwZXJtdXRpdmUtc2Vzc2lvblwiLFxuICAgICAgICAgICAgXCJwZXJtdXRpdmUtZGF0YS1taXNjXCIsXG4gICAgICAgICAgICBcInBlcm11dGl2ZS11bnByb2Nlc3NlZC1wYmFcIixcbiAgICAgICAgICAgIFwicGVybXV0aXZlLWFwcFwiLFxuICAgICAgICAgICAgXCJwZXJtdXRpdmUtZGF0YS1tb2RlbHNcIixcbiAgICAgICAgICAgIFwicGVybXV0aXZlLWlkXCIsXG4gICAgICAgICAgICBcInBlcm11dGl2ZS1jb25zZW50XCIsXG4gICAgICAgICAgICBcInBlcm11dGl2ZS1ldmVudHMtY2FjaGVcIixcbiAgICAgICAgICAgIFwicGVybXV0aXZlLWRhdGEtcXVlcmllc1wiLFxuICAgICAgICAgICAgXCJwZXJtdXRpdmUtZXZlbnRzLWZvci1wYWdlXCIsXG4gICAgICAgICAgICBcIl9fcGVybXV0aXZlQ29uZmlnUXVlcnlQYXJhbXNcIixcbiAgICAgICAgICAgIFwiX3BzZWdzXCJcbiAgICAgICAgXSxcbiAgICAgICAgc2Vzc2lvblN0b3JhZ2U6IFtcIl9fcGVybXV0aXZlQ29uZmlnUXVlcnlQYXJhbXNcIl1cbiAgICB9LFxuICAgIGdvb2dsZXRhZzogeyBjb29raWVzOiBbXCJfX2dwaVwiLCBcIl9fZ2Fkc1wiXSB9XG59O1xuY29uc3QgZGVwcmVjYXRlZFZlbmRvclN0b3JhZ2VJZHMgPSB7XG4gICAgXCJnb29nbGUtYW5hbHl0aWNzXCI6IHtcbiAgICAgICAgY29va2llczogW1wiX2dpZFwiLCBcIl9nYVwiXVxuICAgIH1cbn07XG5leHBvcnQgeyBkZXByZWNhdGVkVmVuZG9yU3RvcmFnZUlkcywgdmVuZG9yU3RvcmFnZUlkcyB9O1xuIiwiY29uc3QgVENGVjJWZW5kb3JJRHMgPSB7XG4gICAgLy8ga2VlcCB0aGUgbGlzdCBpbiBSRUFETUUubWQgdXAgdG8gZGF0ZSB3aXRoIHRoZXNlIHZhbHVlc1xuICAgIGE5OiBbXCI1ZjM2OWEwMmI4ZTA1YzMwODcwMWY4MjlcIl0sXG4gICAgYWNhc3Q6IFtcIjVmMjAzZGNiMWYwZGVhNzkwNTYyZTIwZlwiXSxcbiAgICBhZFlvdUxpa2U6IFtcIjVmMmQyMmE1YjhlMDVjMDI4ZTVjMmU5N1wiXSxcbiAgICBicmF6ZTogW1wiNWVkOGM0OWM0YjhjZTQ1NzFjN2FkODAxXCJdLFxuICAgIGNvbXNjb3JlOiBbXCI1ZWZlZmUyNWI4ZTA1YzA2NTQyYjJhNzdcIl0sXG4gICAgY3JpdGVvOiBbXCI1ZTk4ZTdmMWI4ZTA1YzExMWQwMWI0NjJcIl0sXG4gICAgXCJnb29nbGUtbW9iaWxlLWFkc1wiOiBbXCI1ZjFhYWRhNmI4ZTA1YzMwNmMwNTk3ZDdcIl0sXG4gICAgXCJnb29nbGUtdGFnLW1hbmFnZXJcIjogW1wiNWU5NTJmNjEwN2Q5ZDIwYzg4ZTdjOTc1XCJdLFxuICAgIGdvb2dsZXRhZzogW1wiNWYxYWFkYTZiOGUwNWMzMDZjMDU5N2Q3XCJdLFxuICAgIGdyb3VwTTogW1wiNWUzN2ZjM2U1NmE1ZTY2MTQ3NzY3MjMxXCJdLFxuICAgIGlhczogW1wiNWU3Y2VkNTdiOGUwNWM0ODUyNDZjY2YzXCJdLFxuICAgIGlkNTogW1wiNWVlMTViYzdiOGUwNWMxNjM2NjU5OWNiXCJdLFxuICAgIGluaXppbzogW1wiNWUzN2ZjM2U1NmE1ZTY2MTU1MDJmOWM5XCJdLFxuICAgIGlwc29zOiBbXCI1ZmE1MWIyOWEyMjg2MzhiNGExOTgwZTRcIl0sXG4gICAgaW5kZXhFeGNoYW5nZTogW1wiNWU3Y2VkNTdiOGUwNWM0ODUyNDZjY2Q4XCJdLFxuICAgIG1hZ25pdGU6IFtcIjVlN2NlZDU3YjhlMDVjNDg1MjQ2Y2NlNVwiXSxcbiAgICBuaWVsc2VuOiBbXCI1ZWY1YzNhNWI4ZTA1YzY5OTgwZWFhNWJcIl0sXG4gICAgb3BoYW46IFtcIjVmMjAzZGJlZWFhYWE4NzY4ZmQzMjI2YVwiXSxcbiAgICBvcGVuWDogW1wiNWU4NjViMzZiOGUwNWM2Zjk4NGEzN2U2XCJdLFxuICAgIG96b25lOiBbXCI1ZTdjZWQ1N2I4ZTA1YzVhN2QxNzFjZDNcIl0sXG4gICAgcGVybXV0aXZlOiBbXCI1ZjM2OWEwMmI4ZTA1YzJmMmQ1NDZhNDBcIl0sXG4gICAgcHVibWF0aWM6IFtcIjVlYWIzZDVhYjhlMDVjMjQxYTYzYzVkYlwiXSxcbiAgICBxbTogW1wiNWYyOTVmYTRiOGUwNWM3NmE0NGMzMTQ5XCJdLFxuICAgIHJlbWFya2V0aW5nOiBbXCI1ZWQwZWI2ODhhNzY1MDNmMTAxNjU3OGZcIl0sXG4gICAgc2VudHJ5OiBbXCI1ZjBmMzkwMTRlZmZkYTZlOGJiZDIwMDZcIl0sXG4gICAgdGVhZHM6IFtcIjVlYWIzZDVhYjhlMDVjMmJiZTMzZjM5OVwiXSxcbiAgICB0aGVUcmFkZURlc2s6IFtcIjVlODY1YjM2YjhlMDVjNDg1MzdmNjBhN1wiXSxcbiAgICB0d2l0dGVyOiBbXCI1ZTcxNzYwYjY5OTY2NTQwZTQ1NTRmMDFcIl0sXG4gICAgeGFuZHI6IFtcIjVlN2NlZDU3YjhlMDVjNDg1NDIyMWJiYVwiXSxcbiAgICBcInlvdXR1YmUtcGxheWVyXCI6IFtcIjVlN2FjM2ZhZTMwZTdkMWJjMWViZjVlOFwiXVxufTtcbmNvbnN0IEF1c1ZlbmRvcklEcyA9IHtcbiAgICByZWRwbGFuZXQ6IFtcIm5vdC10Y2Z2Mi12ZW5kb3JcIl1cbn07XG5jb25zdCBVc1ZlbmRvcklEcyA9IHtcbiAgICBhZG1pcmFsOiBbXCJub3QtdGNmdjItdmVuZG9yXCJdXG59O1xuY29uc3QgVmVuZG9ySURzID0ge1xuICAgIC4uLlRDRlYyVmVuZG9ySURzLFxuICAgIC4uLkF1c1ZlbmRvcklEcyxcbiAgICAuLi5Vc1ZlbmRvcklEc1xufTtcbmV4cG9ydCB7IEF1c1ZlbmRvcklEcywgVENGVjJWZW5kb3JJRHMsIFVzVmVuZG9ySURzLCBWZW5kb3JJRHMgfTtcbiIsImltcG9ydCB7IGdldENvb2tpZVZhbHVlcyB9IGZyb20gJy4vZ2V0Q29va2llVmFsdWVzLmpzJztcbmltcG9ydCB7IG1lbW9pemVkQ29va2llcyB9IGZyb20gJy4vbWVtb2l6ZWRDb29raWVzLmpzJztcbmNvbnN0IGdldENvb2tpZSA9ICh7IG5hbWUsIHNob3VsZE1lbW9pemUgPSBmYWxzZSB9KSA9PiB7XG4gICAgY29uc3QgbWVtb2l6ZWRDb29raWUgPSBtZW1vaXplZENvb2tpZXMuZ2V0KG5hbWUpO1xuICAgIGlmIChtZW1vaXplZENvb2tpZSkge1xuICAgICAgICByZXR1cm4gbWVtb2l6ZWRDb29raWU7XG4gICAgfVxuICAgIGNvbnN0IFt2YWx1ZV0gPSBnZXRDb29raWVWYWx1ZXMobmFtZSk7XG4gICAgaWYgKHZhbHVlKSB7XG4gICAgICAgIGlmIChzaG91bGRNZW1vaXplKSB7XG4gICAgICAgICAgICBtZW1vaXplZENvb2tpZXMuc2V0KG5hbWUsIHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIHJldHVybiBudWxsO1xufTtcbmV4cG9ydCB7IGdldENvb2tpZSB9O1xuIiwiY29uc3QgZ2V0Q29va2llVmFsdWVzID0gKG5hbWUpID0+IHtcbiAgICBjb25zdCBuYW1lRXEgPSBgJHtuYW1lfT1gO1xuICAgIGNvbnN0IGNvb2tpZXMgPSBkb2N1bWVudC5jb29raWUuc3BsaXQoXCI7XCIpO1xuICAgIHJldHVybiBjb29raWVzLnJlZHVjZSgoYWNjLCBjb29raWUpID0+IHtcbiAgICAgICAgY29uc3QgY29va2llVHJpbW1lZCA9IGNvb2tpZS50cmltKCk7XG4gICAgICAgIGlmIChjb29raWVUcmltbWVkLnN0YXJ0c1dpdGgobmFtZUVxKSkge1xuICAgICAgICAgICAgYWNjLnB1c2goY29va2llVHJpbW1lZC5zdWJzdHJpbmcobmFtZUVxLmxlbmd0aCwgY29va2llVHJpbW1lZC5sZW5ndGgpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjO1xuICAgIH0sIFtdKTtcbn07XG5leHBvcnQgeyBnZXRDb29raWVWYWx1ZXMgfTtcbiIsImNvbnN0IGdldFNob3J0RG9tYWluID0gKHsgaXNDcm9zc1N1YmRvbWFpbiA9IGZhbHNlIH0gPSB7fSkgPT4ge1xuICAgIGNvbnN0IGRvbWFpbiA9IGRvY3VtZW50LmRvbWFpbiB8fCBcIlwiO1xuICAgIGlmIChkb21haW4gPT09IFwibG9jYWxob3N0XCIgfHwgd2luZG93Lmd1YXJkaWFuPy5jb25maWc/LnBhZ2U/LmlzUHJldmlldykge1xuICAgICAgICByZXR1cm4gZG9tYWluO1xuICAgIH1cbiAgICBpZiAoaXNDcm9zc1N1YmRvbWFpbikge1xuICAgICAgICByZXR1cm4gW1wiXCIsIC4uLmRvbWFpbi5zcGxpdChcIi5cIikuc2xpY2UoLTIpXS5qb2luKFwiLlwiKTtcbiAgICB9XG4gICAgcmV0dXJuIGRvbWFpbi5yZXBsYWNlKC9eKHd3d3xtXFwuY29kZXxkZXZ8bSlcXC4vLCBcIi5cIik7XG59O1xuZXhwb3J0IHsgZ2V0U2hvcnREb21haW4gfTtcbiIsImNvbnN0IG1lbW9pemVkQ29va2llcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgTWFwKCk7XG5leHBvcnQgeyBtZW1vaXplZENvb2tpZXMgfTtcbiIsImltcG9ydCB7IGdldFNob3J0RG9tYWluIH0gZnJvbSAnLi9nZXRTaG9ydERvbWFpbi5qcyc7XG5jb25zdCByZW1vdmVDb29raWUgPSAoeyBuYW1lLCBjdXJyZW50RG9tYWluT25seSA9IGZhbHNlIH0pID0+IHtcbiAgICBjb25zdCBleHBpcmVzID0gXCJleHBpcmVzPVRodSwgMDEgSmFuIDE5NzAgMDA6MDA6MDEgR01UO1wiO1xuICAgIGNvbnN0IHBhdGggPSBcInBhdGg9LztcIjtcbiAgICBkb2N1bWVudC5jb29raWUgPSBgJHtuYW1lfT07JHtwYXRofSR7ZXhwaXJlc31gO1xuICAgIGlmICghY3VycmVudERvbWFpbk9ubHkpIHtcbiAgICAgICAgZG9jdW1lbnQuY29va2llID0gYCR7bmFtZX09OyR7cGF0aH0ke2V4cGlyZXN9IGRvbWFpbj0ke2dldFNob3J0RG9tYWluKCl9O2A7XG4gICAgfVxufTtcbmV4cG9ydCB7IHJlbW92ZUNvb2tpZSB9O1xuIiwiY29uc3QgaXNPYmplY3QgPSAodmFsdWUpID0+IHtcbiAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKHZhbHVlKSAhPT0gXCJbb2JqZWN0IE9iamVjdF1cIikge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGNvbnN0IHByb3RvdHlwZSA9IE9iamVjdC5nZXRQcm90b3R5cGVPZih2YWx1ZSk7XG4gICAgcmV0dXJuIHByb3RvdHlwZSA9PT0gbnVsbCB8fCBwcm90b3R5cGUgPT09IE9iamVjdC5wcm90b3R5cGU7XG59O1xuZXhwb3J0IHsgaXNPYmplY3QgfTtcbiIsImNvbnN0IGlzU3RyaW5nID0gKF8pID0+IHtcbiAgICByZXR1cm4gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZy5jYWxsKF8pID09PSBcIltvYmplY3QgU3RyaW5nXVwiO1xufTtcbmV4cG9ydCB7IGlzU3RyaW5nIH07XG4iLCJjb25zdCBpc1VuZGVmaW5lZCA9IChfKSA9PiBfID09PSB2b2lkIDA7XG5leHBvcnQgeyBpc1VuZGVmaW5lZCB9O1xuIiwiaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICcuLi9pc1N0cmluZy9pc1N0cmluZy5qcyc7XG5pbXBvcnQgeyBpc1VuZGVmaW5lZCB9IGZyb20gJy4uL2lzVW5kZWZpbmVkL2lzVW5kZWZpbmVkLmpzJztcbmltcG9ydCB7IHN0b3JhZ2UgfSBmcm9tICcuLi9zdG9yYWdlL3N0b3JhZ2UuanMnO1xuaW1wb3J0IHsgU1RPUkFHRV9LRVkgfSBmcm9tICcuL3N0b3JhZ2Uta2V5LmpzJztcbmltcG9ydCB7IHN1YnNjcmlwdGlvblN0eWxlcywgaXNTdWJzY3JpcHRpb24sIGNvbW1vblN0eWxlIH0gZnJvbSAnLi9zdWJzY3JpcHRpb25zLmpzJztcbnZhciBfYTtcbmxldCBTVUJTQ1JJUFRJT05TX0NBQ0hFO1xuY29uc3QgZ2V0U3Vic2NyaXB0aW9ucyA9ICgpID0+IHtcbiAgICBpZiAoaXNVbmRlZmluZWQoU1VCU0NSSVBUSU9OU19DQUNIRSkpIHtcbiAgICAgICAgY29uc3Qgc3RvcmVkU3Vic2NyaXB0aW9ucyA9IHN0b3JhZ2UubG9jYWwuZ2V0KFNUT1JBR0VfS0VZKTtcbiAgICAgICAgaWYgKGlzU3RyaW5nKHN0b3JlZFN1YnNjcmlwdGlvbnMpKSB7XG4gICAgICAgICAgICBTVUJTQ1JJUFRJT05TX0NBQ0hFID0gbmV3IFNldChzdG9yZWRTdWJzY3JpcHRpb25zLnNwbGl0KFwiLFwiKS5maWx0ZXIoaXNTdWJzY3JpcHRpb24pKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIFNVQlNDUklQVElPTlNfQ0FDSEUgPSAvKiBAX19QVVJFX18gKi8gbmV3IFNldCgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBTVUJTQ1JJUFRJT05TX0NBQ0hFO1xufTtcbmNvbnN0IHN1YnNjcmliZVRvID0gKHN1YnNjcmlwdGlvbikgPT4ge1xuICAgIGNvbnN0IHN1YnNjcmlwdGlvbnMgPSBnZXRTdWJzY3JpcHRpb25zKCk7XG4gICAgc3Vic2NyaXB0aW9ucy5hZGQoc3Vic2NyaXB0aW9uKTtcbiAgICBzdG9yYWdlLmxvY2FsLnNldChTVE9SQUdFX0tFWSwgQXJyYXkuZnJvbShzdWJzY3JpcHRpb25zKS5qb2luKFwiLFwiKSk7XG4gICAgbG9nKHN1YnNjcmlwdGlvbiwgXCJcXHV7MUY1MTR9IFN1YnNjcmliZWQsIGhlbGxvIVwiKTtcbn07XG5jb25zdCB1bnN1YnNjcmliZUZyb20gPSAoc3Vic2NyaXB0aW9uKSA9PiB7XG4gICAgY29uc3Qgc3Vic2NyaXB0aW9ucyA9IGdldFN1YnNjcmlwdGlvbnMoKTtcbiAgICBzdWJzY3JpcHRpb25zLmRlbGV0ZShzdWJzY3JpcHRpb24pO1xuICAgIHN0b3JhZ2UubG9jYWwuc2V0KFNUT1JBR0VfS0VZLCBBcnJheS5mcm9tKHN1YnNjcmlwdGlvbnMpLmpvaW4oXCIsXCIpKTtcbiAgICBsb2coc3Vic2NyaXB0aW9uLCBcIlxcdXsxRjUxNX0gVW5zdWJzY3JpYmVkLCBnb29kLWJ5ZSFcIik7XG59O1xuY29uc3QgaXNTdWJzY3JpYmVkVG8gPSAoc3Vic2NyaXB0aW9uKSA9PiBnZXRTdWJzY3JpcHRpb25zKCkuaGFzKHN1YnNjcmlwdGlvbik7XG5jb25zdCBsb2dTdHlsZXMgPSB7IC4uLnN1YnNjcmlwdGlvblN0eWxlcywgLi4uY29tbW9uU3R5bGUgfTtcbmNvbnN0IG1lc3NhZ2VTdHlsZSA9IChzdWJzY3JpcHRpb25TdHlsZSkgPT4ge1xuICAgIGNvbnN0IHsgYmFja2dyb3VuZCwgZm9udCB9ID0gbG9nU3R5bGVzW3N1YnNjcmlwdGlvblN0eWxlXTtcbiAgICByZXR1cm4gYGJhY2tncm91bmQ6ICR7YmFja2dyb3VuZH07IGNvbG9yOiAke2ZvbnR9OyBwYWRkaW5nOiAycHggNnB4OyBib3JkZXItcmFkaXVzOjIwcHhgO1xufTtcbmNvbnN0IGxvZyA9IChzdWJzY3JpcHRpb24sIC4uLmFyZ3MpID0+IHtcbiAgICBpZiAoaXNTdWJzY3JpYmVkVG8oc3Vic2NyaXB0aW9uKSkge1xuICAgICAgICBjb25zdCBzdHlsZXMgPSBbbWVzc2FnZVN0eWxlKFwiY29tbW9uXCIpLCBcIlwiLCBtZXNzYWdlU3R5bGUoc3Vic2NyaXB0aW9uKSwgXCJcIl07XG4gICAgICAgIGNvbnNvbGUubG9nKGAlY0BndWFyZGlhbiVjICVjJHtzdWJzY3JpcHRpb259JWNgLCAuLi5zdHlsZXMsIC4uLmFyZ3MpO1xuICAgIH1cbn07XG5pZiAodHlwZW9mIHdpbmRvdyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIHdpbmRvdy5ndWFyZGlhbiA/PyAod2luZG93Lmd1YXJkaWFuID0ge30pO1xuICAgIChfYSA9IHdpbmRvdy5ndWFyZGlhbikubG9nZ2VyID8/IChfYS5sb2dnZXIgPSB7XG4gICAgICAgIHN1YnNjcmliZVRvLFxuICAgICAgICB1bnN1YnNjcmliZUZyb20sXG4gICAgICAgIHRlYW1zOiAoKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLndhcm4oXCJndWFyZGlhbi5sb2dnZXIudGVhbXMoKSBpcyBkZXByZWNhdGVkIC0gdXNlIHN1YnNjcmlwdGlvbnMoKVwiKTtcbiAgICAgICAgICAgIHJldHVybiBPYmplY3Qua2V5cyhzdWJzY3JpcHRpb25TdHlsZXMpO1xuICAgICAgICB9LFxuICAgICAgICBzdWJzY3JpcHRpb25zOiAoKSA9PiBPYmplY3Qua2V5cyhzdWJzY3JpcHRpb25TdHlsZXMpXG4gICAgfSk7XG59XG5leHBvcnQgeyBpc1N1YnNjcmliZWRUbywgbG9nLCBtZXNzYWdlU3R5bGUgfTtcbiIsImNvbnN0IFNUT1JBR0VfS0VZID0gXCJndS5sb2dnZXJcIjtcbmV4cG9ydCB7IFNUT1JBR0VfS0VZIH07XG4iLCJjb25zdCBjb21tb25TdHlsZSA9IHtcbiAgICBjb21tb246IHtcbiAgICAgICAgYmFja2dyb3VuZDogXCIjQzFEOEZDXCIsXG4gICAgICAgIGZvbnQ6IFwiIzA1Mjk2MlwiXG4gICAgfVxufTtcbmNvbnN0IHN1YnNjcmlwdGlvblN0eWxlcyA9IHtcbiAgICBjb21tZXJjaWFsOiB7XG4gICAgICAgIGJhY2tncm91bmQ6IFwiIzc3RUVBQVwiLFxuICAgICAgICBmb250OiBcIiMwMDQ0MDBcIlxuICAgIH0sXG4gICAgY21wOiB7XG4gICAgICAgIGJhY2tncm91bmQ6IFwiI0ZGNkJCNVwiLFxuICAgICAgICBmb250OiBcIiMyRjA0MDRcIlxuICAgIH0sXG4gICAgZG90Y29tOiB7XG4gICAgICAgIGJhY2tncm91bmQ6IFwiIzAwMDAwMFwiLFxuICAgICAgICBmb250OiBcIiNmZjczMDBcIlxuICAgIH0sXG4gICAgZGVzaWduOiB7XG4gICAgICAgIGJhY2tncm91bmQ6IFwiIzE4NUUzNlwiLFxuICAgICAgICBmb250OiBcIiNGRkY0RjJcIlxuICAgIH0sXG4gICAgdHg6IHtcbiAgICAgICAgYmFja2dyb3VuZDogXCIjMkY0RjRGXCIsXG4gICAgICAgIGZvbnQ6IFwiI0ZGRkZGRlwiXG4gICAgfSxcbiAgICBzdXBwb3J0ZXJSZXZlbnVlOiB7XG4gICAgICAgIGJhY2tncm91bmQ6IFwiIzBGNzBCN1wiLFxuICAgICAgICBmb250OiBcIiNmZmZmZmZcIlxuICAgIH0sXG4gICAgaWRlbnRpdHk6IHtcbiAgICAgICAgYmFja2dyb3VuZDogXCIjNkY1RjhGXCIsXG4gICAgICAgIGZvbnQ6IFwiI2ZmZmZmZlwiXG4gICAgfSxcbiAgICBvcGVuSm91cm5hbGlzbToge1xuICAgICAgICBiYWNrZ3JvdW5kOiBcIiNDNzQ2MDBcIixcbiAgICAgICAgZm9udDogXCIjRkVGOUY1XCJcbiAgICB9LFxuICAgIHBlcmY6IHtcbiAgICAgICAgYmFja2dyb3VuZDogXCIjRkZENzAwXCIsXG4gICAgICAgIGZvbnQ6IFwiIzAwMDAwMFwiXG4gICAgfVxufTtcbmNvbnN0IGlzU3Vic2NyaXB0aW9uID0gKHN1YnNjcmlwdGlvbikgPT4gT2JqZWN0LmtleXMoc3Vic2NyaXB0aW9uU3R5bGVzKS5pbmNsdWRlcyhzdWJzY3JpcHRpb24pO1xuZXhwb3J0IHsgY29tbW9uU3R5bGUsIGlzU3Vic2NyaXB0aW9uLCBzdWJzY3JpcHRpb25TdHlsZXMgfTtcbiIsInZhciB2ZXJzaW9uID0gXCIyNS4yLjBcIjtcbmV4cG9ydCB7IHZlcnNpb24gfTtcbiIsImltcG9ydCB7IGlzT2JqZWN0IH0gZnJvbSAnLi4vaXNPYmplY3QvaXNPYmplY3QuanMnO1xuaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICcuLi9pc1N0cmluZy9pc1N0cmluZy5qcyc7XG52YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fdHlwZUVycm9yID0gKG1zZykgPT4ge1xuICAgIHRocm93IFR5cGVFcnJvcihtc2cpO1xufTtcbnZhciBfX2RlZk5vcm1hbFByb3AgPSAob2JqLCBrZXksIHZhbHVlKSA9PiBrZXkgaW4gb2JqID8gX19kZWZQcm9wKG9iaiwga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGNvbmZpZ3VyYWJsZTogdHJ1ZSwgd3JpdGFibGU6IHRydWUsIHZhbHVlIH0pIDogb2JqW2tleV0gPSB2YWx1ZTtcbnZhciBfX3B1YmxpY0ZpZWxkID0gKG9iaiwga2V5LCB2YWx1ZSkgPT4gX19kZWZOb3JtYWxQcm9wKG9iaiwgdHlwZW9mIGtleSAhPT0gXCJzeW1ib2xcIiA/IGtleSArIFwiXCIgOiBrZXksIHZhbHVlKTtcbnZhciBfX2FjY2Vzc0NoZWNrID0gKG9iaiwgbWVtYmVyLCBtc2cpID0+IG1lbWJlci5oYXMob2JqKSB8fCBfX3R5cGVFcnJvcihcIkNhbm5vdCBcIiArIG1zZyk7XG52YXIgX19wcml2YXRlR2V0ID0gKG9iaiwgbWVtYmVyLCBnZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcInJlYWQgZnJvbSBwcml2YXRlIGZpZWxkXCIpLCBnZXR0ZXIgPyBnZXR0ZXIuY2FsbChvYmopIDogbWVtYmVyLmdldChvYmopKTtcbnZhciBfX3ByaXZhdGVBZGQgPSAob2JqLCBtZW1iZXIsIHZhbHVlKSA9PiBtZW1iZXIuaGFzKG9iaikgPyBfX3R5cGVFcnJvcihcIkNhbm5vdCBhZGQgdGhlIHNhbWUgcHJpdmF0ZSBtZW1iZXIgbW9yZSB0aGFuIG9uY2VcIikgOiBtZW1iZXIgaW5zdGFuY2VvZiBXZWFrU2V0ID8gbWVtYmVyLmFkZChvYmopIDogbWVtYmVyLnNldChvYmosIHZhbHVlKTtcbnZhciBfX3ByaXZhdGVTZXQgPSAob2JqLCBtZW1iZXIsIHZhbHVlLCBzZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcIndyaXRlIHRvIHByaXZhdGUgZmllbGRcIiksIG1lbWJlci5zZXQob2JqLCB2YWx1ZSksIHZhbHVlKTtcbnZhciBfc3RvcmFnZSwgX2xvY2FsLCBfc2Vzc2lvbiwgX2E7XG5jbGFzcyBTdG9yYWdlRmFjdG9yeSB7XG4gICAgLy8gaHR0cHM6Ly9tZG4uaW8vUHJpdmF0ZV9jbGFzc19maWVsZHNcbiAgICBjb25zdHJ1Y3RvcihzdG9yYWdlSGFuZGxlcikge1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX3N0b3JhZ2UpO1xuICAgICAgICAvKipcbiAgICAgICAgICogQ2hlY2sgd2hldGhlciBzdG9yYWdlIGlzIGF2YWlsYWJsZS5cbiAgICAgICAgICovXG4gICAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJpc0F2YWlsYWJsZVwiLCAoKSA9PiBCb29sZWFuKF9fcHJpdmF0ZUdldCh0aGlzLCBfc3RvcmFnZSkpKTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJldHJpZXZlIGFuIGl0ZW0gZnJvbSBzdG9yYWdlLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ga2V5IC0gdGhlIG5hbWUgb2YgdGhlIGl0ZW1cbiAgICAgICAgICovXG4gICAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJnZXRcIiwgKGtleSkgPT4ge1xuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gSlNPTi5wYXJzZShfX3ByaXZhdGVHZXQodGhpcywgX3N0b3JhZ2UpPy5nZXRJdGVtKGtleSkgPz8gXCJcIik7XG4gICAgICAgICAgICAgICAgaWYgKCFpc09iamVjdChkYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgY29uc3QgeyB2YWx1ZSwgZXhwaXJlcyB9ID0gZGF0YTtcbiAgICAgICAgICAgICAgICBpZiAoKGlzU3RyaW5nKGV4cGlyZXMpIHx8IHR5cGVvZiBleHBpcmVzID09PSBcIm51bWJlclwiKSAmJiAvKiBAX19QVVJFX18gKi8gbmV3IERhdGUoKSA+IG5ldyBEYXRlKGV4cGlyZXMpKSB7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMucmVtb3ZlKGtleSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBudWxsO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFNhdmUgYSB2YWx1ZSB0byBzdG9yYWdlLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ga2V5IC0gdGhlIG5hbWUgb2YgdGhlIGl0ZW1cbiAgICAgICAgICogQHBhcmFtIHZhbHVlIC0gdGhlIGRhdGEgdG8gc2F2ZVxuICAgICAgICAgKiBAcGFyYW0gZXhwaXJlcyAtIG9wdGlvbmFsIGRhdGUgb24gd2hpY2ggdGhpcyBkYXRhIHdpbGwgZXhwaXJlXG4gICAgICAgICAqL1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwic2V0XCIsIChrZXksIHZhbHVlLCBleHBpcmVzKSA9PiBfX3ByaXZhdGVHZXQodGhpcywgX3N0b3JhZ2UpPy5zZXRJdGVtKGtleSwgSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICAgICAgdmFsdWUsXG4gICAgICAgICAgICBleHBpcmVzOiBleHBpcmVzID8gbmV3IERhdGUoZXhwaXJlcykgOiB2b2lkIDBcbiAgICAgICAgfSkpKTtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIFJlbW92ZSBhbiBpdGVtIGZyb20gc3RvcmFnZS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIGtleSAtIHRoZSBuYW1lIG9mIHRoZSBpdGVtXG4gICAgICAgICAqL1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwicmVtb3ZlXCIsIChrZXkpID0+IF9fcHJpdmF0ZUdldCh0aGlzLCBfc3RvcmFnZSk/LnJlbW92ZUl0ZW0oa2V5KSk7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZW1vdmVzIGFsbCBpdGVtcyBmcm9tIHN0b3JhZ2UuXG4gICAgICAgICAqL1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiY2xlYXJcIiwgKCkgPT4gX19wcml2YXRlR2V0KHRoaXMsIF9zdG9yYWdlKT8uY2xlYXIoKSk7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBSZXRyaWV2ZSBhbiBpdGVtIGZyb20gc3RvcmFnZSBpbiBpdHMgcmF3IHN0YXRlLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ga2V5IC0gdGhlIG5hbWUgb2YgdGhlIGl0ZW1cbiAgICAgICAgICovXG4gICAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJnZXRSYXdcIiwgKGtleSkgPT4gX19wcml2YXRlR2V0KHRoaXMsIF9zdG9yYWdlKT8uZ2V0SXRlbShrZXkpID8/IG51bGwpO1xuICAgICAgICAvKipcbiAgICAgICAgICogU2F2ZSBhIHJhdyB2YWx1ZSB0byBzdG9yYWdlLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0ga2V5IC0gdGhlIG5hbWUgb2YgdGhlIGl0ZW1cbiAgICAgICAgICogQHBhcmFtIHZhbHVlIC0gdGhlIGRhdGEgdG8gc2F2ZVxuICAgICAgICAgKi9cbiAgICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcInNldFJhd1wiLCAoa2V5LCB2YWx1ZSkgPT4gX19wcml2YXRlR2V0KHRoaXMsIF9zdG9yYWdlKT8uc2V0SXRlbShrZXksIHZhbHVlKSk7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBHZXQga2V5IGJ5IGluZGV4LlxuICAgICAgICAgKiBAcmV0dXJucyB0aGUgbmFtZSBvZiB0aGUga2V5IGF0IHRoYXQgaW5kZXggKGBzdHJpbmdgKSwgb3IgYG51bGxgIChpZlxuICAgICAgICAgKiAgICAgIGluZGV4IGlzIG91dCBvZiByYW5nZSBvZiBpZiBzdG9yYWdlIGlzIHVuYXZhaWxhYmxlKSAtIGlmIHRoZSBpbmRleFxuICAgICAgICAgKiAgICAgIGlzIG91dCBvZiByYW5nZSwgb3IgaWYgc3RvcmFnZSBpcyBub3QgYXZhaWxhYmxlLlxuICAgICAgICAgKlxuICAgICAgICAgKiBXcmFwcGVyIGZvciB0aGUgYGtleWAgbWV0aG9kIG9uIHRoZSBuYXRpdmUgYFN0b3JhZ2VgIG9iamVjdCwgd2l0aFxuICAgICAgICAgKiBhZGRpdGlvbmFsIGNoZWNrIGZvciBhdmFpbGFiaWxpdHkgb2Ygc3RvcmFnZS4gTm90ZSB0aGF0IHRoZSBfb3JkZXJfIG9mXG4gICAgICAgICAqIGtleXMgaW4gc3RvcmFnZSBpcyBkZXBlbmRlbnQgb24gdXNlci1hZ2VudCBpbXBsZW1lbnRhdGlvbiwgYW5kIHNvIHlvdVxuICAgICAgICAgKiBzaG91bGQgbm90IGFzc3VtZSB0aGF0IGtleXMgd2lsbCBiZSBzdG9yZWQgaW4gYW55IHBhcnRpY3VsYXIgb3JkZXIgKGUuZy5cbiAgICAgICAgICogb3JkZXIgb2YgaW5zZXJ0aW9uKS5cbiAgICAgICAgICogQHNlZSBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvU3RvcmFnZS9rZXlcbiAgICAgICAgICovXG4gICAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJrZXlcIiwgKGluZGV4KSA9PiBfX3ByaXZhdGVHZXQodGhpcywgX3N0b3JhZ2UpPy5rZXkoaW5kZXgpID8/IG51bGwpO1xuICAgICAgICAvKipcbiAgICAgICAgICogR2V0IHRoZSBudW1iZXIgb2YgaXRlbXMgaW4gc3RvcmFnZS5cbiAgICAgICAgICogQHJldHVybnMgdGhlIG51bWJlciBvZiBpdGVtcyBpbiBzdG9yYWdlLCBvciBgbnVsbGAgaWYgc3RvcmFnZSBpc1xuICAgICAgICAgKiBcdG5vdCBhdmFpbGFibGUuXG4gICAgICAgICAqL1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwibGVuZ3RoXCIsICgpID0+IF9fcHJpdmF0ZUdldCh0aGlzLCBfc3RvcmFnZSk/Lmxlbmd0aCA/PyBudWxsKTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHN0b3JhZ2UyID0gd2luZG93W3N0b3JhZ2VIYW5kbGVyXTtcbiAgICAgICAgICAgIGNvbnN0IHVpZCA9ICggLyogQF9fUFVSRV9fICovbmV3IERhdGUoKSkudG9TdHJpbmcoKTtcbiAgICAgICAgICAgIHN0b3JhZ2UyLnNldEl0ZW0odWlkLCB1aWQpO1xuICAgICAgICAgICAgY29uc3QgYXZhaWxhYmxlID0gc3RvcmFnZTIuZ2V0SXRlbSh1aWQpID09IHVpZDtcbiAgICAgICAgICAgIHN0b3JhZ2UyLnJlbW92ZUl0ZW0odWlkKTtcbiAgICAgICAgICAgIGlmIChhdmFpbGFibGUpIHtcbiAgICAgICAgICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX3N0b3JhZ2UsIHN0b3JhZ2UyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICB9XG4gICAgfVxufVxuX3N0b3JhZ2UgPSBuZXcgV2Vha01hcCgpO1xuY29uc3Qgc3RvcmFnZSA9IG5ldyAoX2EgPSBjbGFzcyB7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfbG9jYWwpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX3Nlc3Npb24pO1xuICAgIH1cbiAgICAvLyBjcmVhdGluZyB0aGUgaW5zdGFuY2UgcmVxdWlyZXMgdGVzdGluZyB0aGUgbmF0aXZlIGltcGxlbWVudGF0aW9uXG4gICAgLy8gd2hpY2ggaXMgYmxvY2tpbmcuIHRoZXJlZm9yZSwgb25seSBjcmVhdGUgbmV3IGluc3RhbmNlcyBvZiB0aGUgZmFjdG9yeVxuICAgIC8vIHdoZW4gaXQncyBhY2Nlc3NlZCBpLmUuIHdlIGtub3cgd2UncmUgZ29pbmcgdG8gdXNlIGl0XG4gICAgZ2V0IGxvY2FsKCkge1xuICAgICAgICByZXR1cm4gX19wcml2YXRlR2V0KHRoaXMsIF9sb2NhbCkgPz8gX19wcml2YXRlU2V0KHRoaXMsIF9sb2NhbCwgbmV3IFN0b3JhZ2VGYWN0b3J5KFwibG9jYWxTdG9yYWdlXCIpKTtcbiAgICB9XG4gICAgZ2V0IHNlc3Npb24oKSB7XG4gICAgICAgIHJldHVybiBfX3ByaXZhdGVHZXQodGhpcywgX3Nlc3Npb24pID8/IF9fcHJpdmF0ZVNldCh0aGlzLCBfc2Vzc2lvbiwgbmV3IFN0b3JhZ2VGYWN0b3J5KFwic2Vzc2lvblN0b3JhZ2VcIikpO1xuICAgIH1cbn0sIF9sb2NhbCA9IG5ldyBXZWFrTWFwKCksIF9zZXNzaW9uID0gbmV3IFdlYWtNYXAoKSwgX2EpKCk7XG5leHBvcnQgeyBzdG9yYWdlIH07XG4iLCJjb25zdCBicmVha3BvaW50cyA9IHtcbiAgICBkZXNrdG9wOiA5ODAsXG4gICAgbGVmdENvbDogMTE0MCxcbiAgICBtb2JpbGU6IDMyMCxcbiAgICBtb2JpbGVMYW5kc2NhcGU6IDQ4MCxcbiAgICBtb2JpbGVNZWRpdW06IDM3NSxcbiAgICBwaGFibGV0OiA2NjAsXG4gICAgdGFibGV0OiA3NDAsXG4gICAgd2lkZTogMTMwMFxufTtcbmV4cG9ydCB7IGJyZWFrcG9pbnRzIH07XG4iLCIndXNlIHN0cmljdCc7XG5tb2R1bGUuZXhwb3J0cyA9IGFuc2lIVE1MO1xuLy8gUmVmZXJlbmNlIHRvIGh0dHBzOi8vZ2l0aHViLmNvbS9zaW5kcmVzb3JodXMvYW5zaS1yZWdleFxudmFyIF9yZWdBTlNJID0gLyg/Oig/OlxcdTAwMWJcXFspfFxcdTAwOWIpKD86KD86WzAtOV17MSwzfSk/KD86KD86O1swLTldezAsM30pKik/W0EtTXxmLW1dKXxcXHUwMDFiW0EtTV0vO1xudmFyIF9kZWZDb2xvcnMgPSB7XG4gICAgcmVzZXQ6IFsnZmZmJywgJzAwMCddLCAvLyBbRk9SRUdST1VEX0NPTE9SLCBCQUNLR1JPVU5EX0NPTE9SXVxuICAgIGJsYWNrOiAnMDAwJyxcbiAgICByZWQ6ICdmZjAwMDAnLFxuICAgIGdyZWVuOiAnMjA5ODA1JyxcbiAgICB5ZWxsb3c6ICdlOGJmMDMnLFxuICAgIGJsdWU6ICcwMDAwZmYnLFxuICAgIG1hZ2VudGE6ICdmZjAwZmYnLFxuICAgIGN5YW46ICcwMGZmZWUnLFxuICAgIGxpZ2h0Z3JleTogJ2YwZjBmMCcsXG4gICAgZGFya2dyZXk6ICc4ODgnXG59O1xudmFyIF9zdHlsZXMgPSB7XG4gICAgMzA6ICdibGFjaycsXG4gICAgMzE6ICdyZWQnLFxuICAgIDMyOiAnZ3JlZW4nLFxuICAgIDMzOiAneWVsbG93JyxcbiAgICAzNDogJ2JsdWUnLFxuICAgIDM1OiAnbWFnZW50YScsXG4gICAgMzY6ICdjeWFuJyxcbiAgICAzNzogJ2xpZ2h0Z3JleSdcbn07XG52YXIgX29wZW5UYWdzID0ge1xuICAgICcxJzogJ2ZvbnQtd2VpZ2h0OmJvbGQnLCAvLyBib2xkXG4gICAgJzInOiAnb3BhY2l0eTowLjUnLCAvLyBkaW1cbiAgICAnMyc6ICc8aT4nLCAvLyBpdGFsaWNcbiAgICAnNCc6ICc8dT4nLCAvLyB1bmRlcnNjb3JlXG4gICAgJzgnOiAnZGlzcGxheTpub25lJywgLy8gaGlkZGVuXG4gICAgJzknOiAnPGRlbD4nIC8vIGRlbGV0ZVxufTtcbnZhciBfY2xvc2VUYWdzID0ge1xuICAgICcyMyc6ICc8L2k+JywgLy8gcmVzZXQgaXRhbGljXG4gICAgJzI0JzogJzwvdT4nLCAvLyByZXNldCB1bmRlcnNjb3JlXG4gICAgJzI5JzogJzwvZGVsPicgLy8gcmVzZXQgZGVsZXRlXG59O1xuWzAsIDIxLCAyMiwgMjcsIDI4LCAzOSwgNDldLmZvckVhY2goZnVuY3Rpb24gKG4pIHtcbiAgICBfY2xvc2VUYWdzW25dID0gJzwvc3Bhbj4nO1xufSk7XG4vKipcbiAqIENvbnZlcnRzIHRleHQgd2l0aCBBTlNJIGNvbG9yIGNvZGVzIHRvIEhUTUwgbWFya3VwLlxuICogQHBhcmFtIHtTdHJpbmd9IHRleHRcbiAqIEByZXR1cm5zIHsqfVxuICovXG5mdW5jdGlvbiBhbnNpSFRNTCh0ZXh0KSB7XG4gICAgLy8gUmV0dXJucyB0aGUgdGV4dCBpZiB0aGUgc3RyaW5nIGhhcyBubyBBTlNJIGVzY2FwZSBjb2RlLlxuICAgIGlmICghX3JlZ0FOU0kudGVzdCh0ZXh0KSkge1xuICAgICAgICByZXR1cm4gdGV4dDtcbiAgICB9XG4gICAgLy8gQ2FjaGUgb3BlbmVkIHNlcXVlbmNlLlxuICAgIHZhciBhbnNpQ29kZXMgPSBbXTtcbiAgICAvLyBSZXBsYWNlIHdpdGggbWFya3VwLlxuICAgIHZhciByZXQgPSB0ZXh0LnJlcGxhY2UoL1xcMDMzXFxbKFxcZCspbS9nLCBmdW5jdGlvbiAobWF0Y2gsIHNlcSkge1xuICAgICAgICB2YXIgb3QgPSBfb3BlblRhZ3Nbc2VxXTtcbiAgICAgICAgaWYgKG90KSB7XG4gICAgICAgICAgICAvLyBJZiBjdXJyZW50IHNlcXVlbmNlIGhhcyBiZWVuIG9wZW5lZCwgY2xvc2UgaXQuXG4gICAgICAgICAgICBpZiAoISF+YW5zaUNvZGVzLmluZGV4T2Yoc2VxKSkgeyAvLyBlc2xpbnQtZGlzYWJsZS1saW5lIG5vLWV4dHJhLWJvb2xlYW4tY2FzdFxuICAgICAgICAgICAgICAgIGFuc2lDb2Rlcy5wb3AoKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gJzwvc3Bhbj4nO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLy8gT3BlbiB0YWcuXG4gICAgICAgICAgICBhbnNpQ29kZXMucHVzaChzZXEpO1xuICAgICAgICAgICAgcmV0dXJuIG90WzBdID09PSAnPCcgPyBvdCA6ICc8c3BhbiBzdHlsZT1cIicgKyBvdCArICc7XCI+JztcbiAgICAgICAgfVxuICAgICAgICB2YXIgY3QgPSBfY2xvc2VUYWdzW3NlcV07XG4gICAgICAgIGlmIChjdCkge1xuICAgICAgICAgICAgLy8gUG9wIHNlcXVlbmNlXG4gICAgICAgICAgICBhbnNpQ29kZXMucG9wKCk7XG4gICAgICAgICAgICByZXR1cm4gY3Q7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuICcnO1xuICAgIH0pO1xuICAgIC8vIE1ha2Ugc3VyZSB0YWdzIGFyZSBjbG9zZWQuXG4gICAgdmFyIGwgPSBhbnNpQ29kZXMubGVuZ3RoO1xuICAgIChsID4gMCkgJiYgKHJldCArPSBBcnJheShsICsgMSkuam9pbignPC9zcGFuPicpKTtcbiAgICByZXR1cm4gcmV0O1xufVxuLyoqXG4gKiBDdXN0b21pemUgY29sb3JzLlxuICogQHBhcmFtIHtPYmplY3R9IGNvbG9ycyByZWZlcmVuY2UgdG8gX2RlZkNvbG9yc1xuICovXG5hbnNpSFRNTC5zZXRDb2xvcnMgPSBmdW5jdGlvbiAoY29sb3JzKSB7XG4gICAgaWYgKHR5cGVvZiBjb2xvcnMgIT09ICdvYmplY3QnKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignYGNvbG9yc2AgcGFyYW1ldGVyIG11c3QgYmUgYW4gT2JqZWN0LicpO1xuICAgIH1cbiAgICB2YXIgX2ZpbmFsQ29sb3JzID0ge307XG4gICAgZm9yICh2YXIga2V5IGluIF9kZWZDb2xvcnMpIHtcbiAgICAgICAgdmFyIGhleCA9IGNvbG9ycy5oYXNPd25Qcm9wZXJ0eShrZXkpID8gY29sb3JzW2tleV0gOiBudWxsO1xuICAgICAgICBpZiAoIWhleCkge1xuICAgICAgICAgICAgX2ZpbmFsQ29sb3JzW2tleV0gPSBfZGVmQ29sb3JzW2tleV07XG4gICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoJ3Jlc2V0JyA9PT0ga2V5KSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGhleCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICBoZXggPSBbaGV4XTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghQXJyYXkuaXNBcnJheShoZXgpIHx8IGhleC5sZW5ndGggPT09IDAgfHwgaGV4LnNvbWUoZnVuY3Rpb24gKGgpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIGggIT09ICdzdHJpbmcnO1xuICAgICAgICAgICAgfSkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ1RoZSB2YWx1ZSBvZiBgJyArIGtleSArICdgIHByb3BlcnR5IG11c3QgYmUgYW4gQXJyYXkgYW5kIGVhY2ggaXRlbSBjb3VsZCBvbmx5IGJlIGEgaGV4IHN0cmluZywgZS5nLjogRkYwMDAwJyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgZGVmSGV4Q29sb3IgPSBfZGVmQ29sb3JzW2tleV07XG4gICAgICAgICAgICBpZiAoIWhleFswXSkge1xuICAgICAgICAgICAgICAgIGhleFswXSA9IGRlZkhleENvbG9yWzBdO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGhleC5sZW5ndGggPT09IDEgfHwgIWhleFsxXSkge1xuICAgICAgICAgICAgICAgIGhleCA9IFtoZXhbMF1dO1xuICAgICAgICAgICAgICAgIGhleC5wdXNoKGRlZkhleENvbG9yWzFdKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGhleCA9IGhleC5zbGljZSgwLCAyKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh0eXBlb2YgaGV4ICE9PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdUaGUgdmFsdWUgb2YgYCcgKyBrZXkgKyAnYCBwcm9wZXJ0eSBtdXN0IGJlIGEgaGV4IHN0cmluZywgZS5nLjogRkYwMDAwJyk7XG4gICAgICAgIH1cbiAgICAgICAgX2ZpbmFsQ29sb3JzW2tleV0gPSBoZXg7XG4gICAgfVxuICAgIF9zZXRUYWdzKF9maW5hbENvbG9ycyk7XG59O1xuLyoqXG4gKiBSZXNldCBjb2xvcnMuXG4gKi9cbmFuc2lIVE1MLnJlc2V0ID0gZnVuY3Rpb24gKCkge1xuICAgIF9zZXRUYWdzKF9kZWZDb2xvcnMpO1xufTtcbi8qKlxuICogRXhwb3NlIHRhZ3MsIGluY2x1ZGluZyBvcGVuIGFuZCBjbG9zZS5cbiAqIEB0eXBlIHtPYmplY3R9XG4gKi9cbmFuc2lIVE1MLnRhZ3MgPSB7fTtcbmlmIChPYmplY3QuZGVmaW5lUHJvcGVydHkpIHtcbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoYW5zaUhUTUwudGFncywgJ29wZW4nLCB7XG4gICAgICAgIGdldDogZnVuY3Rpb24gKCkgeyByZXR1cm4gX29wZW5UYWdzOyB9XG4gICAgfSk7XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KGFuc2lIVE1MLnRhZ3MsICdjbG9zZScsIHtcbiAgICAgICAgZ2V0OiBmdW5jdGlvbiAoKSB7IHJldHVybiBfY2xvc2VUYWdzOyB9XG4gICAgfSk7XG59XG5lbHNlIHtcbiAgICBhbnNpSFRNTC50YWdzLm9wZW4gPSBfb3BlblRhZ3M7XG4gICAgYW5zaUhUTUwudGFncy5jbG9zZSA9IF9jbG9zZVRhZ3M7XG59XG5mdW5jdGlvbiBfc2V0VGFncyhjb2xvcnMpIHtcbiAgICAvLyByZXNldCBhbGxcbiAgICBfb3BlblRhZ3NbJzAnXSA9ICdmb250LXdlaWdodDpub3JtYWw7b3BhY2l0eToxO2NvbG9yOiMnICsgY29sb3JzLnJlc2V0WzBdICsgJztiYWNrZ3JvdW5kOiMnICsgY29sb3JzLnJlc2V0WzFdO1xuICAgIC8vIGludmVyc2VcbiAgICBfb3BlblRhZ3NbJzcnXSA9ICdjb2xvcjojJyArIGNvbG9ycy5yZXNldFsxXSArICc7YmFja2dyb3VuZDojJyArIGNvbG9ycy5yZXNldFswXTtcbiAgICAvLyBkYXJrIGdyZXlcbiAgICBfb3BlblRhZ3NbJzkwJ10gPSAnY29sb3I6IycgKyBjb2xvcnMuZGFya2dyZXk7XG4gICAgZm9yICh2YXIgY29kZSBpbiBfc3R5bGVzKSB7XG4gICAgICAgIHZhciBjb2xvciA9IF9zdHlsZXNbY29kZV07XG4gICAgICAgIHZhciBvcmlDb2xvciA9IGNvbG9yc1tjb2xvcl0gfHwgJzAwMCc7XG4gICAgICAgIF9vcGVuVGFnc1tjb2RlXSA9ICdjb2xvcjojJyArIG9yaUNvbG9yO1xuICAgICAgICBjb2RlID0gcGFyc2VJbnQoY29kZSk7XG4gICAgICAgIF9vcGVuVGFnc1soY29kZSArIDEwKS50b1N0cmluZygpXSA9ICdiYWNrZ3JvdW5kOiMnICsgb3JpQ29sb3I7XG4gICAgfVxufVxuYW5zaUhUTUwucmVzZXQoKTtcbiIsIi8vIENvcHlyaWdodCBKb3llbnQsIEluYy4gYW5kIG90aGVyIE5vZGUgY29udHJpYnV0b3JzLlxuLy9cbi8vIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhXG4vLyBjb3B5IG9mIHRoaXMgc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlXG4vLyBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZSB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmdcbi8vIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LCBtZXJnZSwgcHVibGlzaCxcbi8vIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0byBwZXJtaXRcbi8vIHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLCBzdWJqZWN0IHRvIHRoZVxuLy8gZm9sbG93aW5nIGNvbmRpdGlvbnM6XG4vL1xuLy8gVGhlIGFib3ZlIGNvcHlyaWdodCBub3RpY2UgYW5kIHRoaXMgcGVybWlzc2lvbiBub3RpY2Ugc2hhbGwgYmUgaW5jbHVkZWRcbi8vIGluIGFsbCBjb3BpZXMgb3Igc3Vic3RhbnRpYWwgcG9ydGlvbnMgb2YgdGhlIFNvZnR3YXJlLlxuLy9cbi8vIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1Ncbi8vIE9SIElNUExJRUQsIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0Zcbi8vIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQSBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU5cbi8vIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVCBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLFxuLy8gREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OIE9GIENPTlRSQUNULCBUT1JUIE9SXG4vLyBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEUgU09GVFdBUkUgT1IgVEhFXG4vLyBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuJ3VzZSBzdHJpY3QnO1xudmFyIFIgPSB0eXBlb2YgUmVmbGVjdCA9PT0gJ29iamVjdCcgPyBSZWZsZWN0IDogbnVsbDtcbnZhciBSZWZsZWN0QXBwbHkgPSBSICYmIHR5cGVvZiBSLmFwcGx5ID09PSAnZnVuY3Rpb24nXG4gICAgPyBSLmFwcGx5XG4gICAgOiBmdW5jdGlvbiBSZWZsZWN0QXBwbHkodGFyZ2V0LCByZWNlaXZlciwgYXJncykge1xuICAgICAgICByZXR1cm4gRnVuY3Rpb24ucHJvdG90eXBlLmFwcGx5LmNhbGwodGFyZ2V0LCByZWNlaXZlciwgYXJncyk7XG4gICAgfTtcbnZhciBSZWZsZWN0T3duS2V5cztcbmlmIChSICYmIHR5cGVvZiBSLm93bktleXMgPT09ICdmdW5jdGlvbicpIHtcbiAgICBSZWZsZWN0T3duS2V5cyA9IFIub3duS2V5cztcbn1cbmVsc2UgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICBSZWZsZWN0T3duS2V5cyA9IGZ1bmN0aW9uIFJlZmxlY3RPd25LZXlzKHRhcmdldCkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGFyZ2V0KVxuICAgICAgICAgICAgLmNvbmNhdChPYmplY3QuZ2V0T3duUHJvcGVydHlTeW1ib2xzKHRhcmdldCkpO1xuICAgIH07XG59XG5lbHNlIHtcbiAgICBSZWZsZWN0T3duS2V5cyA9IGZ1bmN0aW9uIFJlZmxlY3RPd25LZXlzKHRhcmdldCkge1xuICAgICAgICByZXR1cm4gT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGFyZ2V0KTtcbiAgICB9O1xufVxuZnVuY3Rpb24gUHJvY2Vzc0VtaXRXYXJuaW5nKHdhcm5pbmcpIHtcbiAgICBpZiAoY29uc29sZSAmJiBjb25zb2xlLndhcm4pXG4gICAgICAgIGNvbnNvbGUud2Fybih3YXJuaW5nKTtcbn1cbnZhciBOdW1iZXJJc05hTiA9IE51bWJlci5pc05hTiB8fCBmdW5jdGlvbiBOdW1iZXJJc05hTih2YWx1ZSkge1xuICAgIHJldHVybiB2YWx1ZSAhPT0gdmFsdWU7XG59O1xuZnVuY3Rpb24gRXZlbnRFbWl0dGVyKCkge1xuICAgIEV2ZW50RW1pdHRlci5pbml0LmNhbGwodGhpcyk7XG59XG5tb2R1bGUuZXhwb3J0cyA9IEV2ZW50RW1pdHRlcjtcbm1vZHVsZS5leHBvcnRzLm9uY2UgPSBvbmNlO1xuLy8gQmFja3dhcmRzLWNvbXBhdCB3aXRoIG5vZGUgMC4xMC54XG5FdmVudEVtaXR0ZXIuRXZlbnRFbWl0dGVyID0gRXZlbnRFbWl0dGVyO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5fZXZlbnRzID0gdW5kZWZpbmVkO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5fZXZlbnRzQ291bnQgPSAwO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5fbWF4TGlzdGVuZXJzID0gdW5kZWZpbmVkO1xuLy8gQnkgZGVmYXVsdCBFdmVudEVtaXR0ZXJzIHdpbGwgcHJpbnQgYSB3YXJuaW5nIGlmIG1vcmUgdGhhbiAxMCBsaXN0ZW5lcnMgYXJlXG4vLyBhZGRlZCB0byBpdC4gVGhpcyBpcyBhIHVzZWZ1bCBkZWZhdWx0IHdoaWNoIGhlbHBzIGZpbmRpbmcgbWVtb3J5IGxlYWtzLlxudmFyIGRlZmF1bHRNYXhMaXN0ZW5lcnMgPSAxMDtcbmZ1bmN0aW9uIGNoZWNrTGlzdGVuZXIobGlzdGVuZXIpIHtcbiAgICBpZiAodHlwZW9mIGxpc3RlbmVyICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoJ1RoZSBcImxpc3RlbmVyXCIgYXJndW1lbnQgbXVzdCBiZSBvZiB0eXBlIEZ1bmN0aW9uLiBSZWNlaXZlZCB0eXBlICcgKyB0eXBlb2YgbGlzdGVuZXIpO1xuICAgIH1cbn1cbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShFdmVudEVtaXR0ZXIsICdkZWZhdWx0TWF4TGlzdGVuZXJzJywge1xuICAgIGVudW1lcmFibGU6IHRydWUsXG4gICAgZ2V0OiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHJldHVybiBkZWZhdWx0TWF4TGlzdGVuZXJzO1xuICAgIH0sXG4gICAgc2V0OiBmdW5jdGlvbiAoYXJnKSB7XG4gICAgICAgIGlmICh0eXBlb2YgYXJnICE9PSAnbnVtYmVyJyB8fCBhcmcgPCAwIHx8IE51bWJlcklzTmFOKGFyZykpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBSYW5nZUVycm9yKCdUaGUgdmFsdWUgb2YgXCJkZWZhdWx0TWF4TGlzdGVuZXJzXCIgaXMgb3V0IG9mIHJhbmdlLiBJdCBtdXN0IGJlIGEgbm9uLW5lZ2F0aXZlIG51bWJlci4gUmVjZWl2ZWQgJyArIGFyZyArICcuJyk7XG4gICAgICAgIH1cbiAgICAgICAgZGVmYXVsdE1heExpc3RlbmVycyA9IGFyZztcbiAgICB9XG59KTtcbkV2ZW50RW1pdHRlci5pbml0ID0gZnVuY3Rpb24gKCkge1xuICAgIGlmICh0aGlzLl9ldmVudHMgPT09IHVuZGVmaW5lZCB8fFxuICAgICAgICB0aGlzLl9ldmVudHMgPT09IE9iamVjdC5nZXRQcm90b3R5cGVPZih0aGlzKS5fZXZlbnRzKSB7XG4gICAgICAgIHRoaXMuX2V2ZW50cyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIHRoaXMuX2V2ZW50c0NvdW50ID0gMDtcbiAgICB9XG4gICAgdGhpcy5fbWF4TGlzdGVuZXJzID0gdGhpcy5fbWF4TGlzdGVuZXJzIHx8IHVuZGVmaW5lZDtcbn07XG4vLyBPYnZpb3VzbHkgbm90IGFsbCBFbWl0dGVycyBzaG91bGQgYmUgbGltaXRlZCB0byAxMC4gVGhpcyBmdW5jdGlvbiBhbGxvd3Ncbi8vIHRoYXQgdG8gYmUgaW5jcmVhc2VkLiBTZXQgdG8gemVybyBmb3IgdW5saW1pdGVkLlxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5zZXRNYXhMaXN0ZW5lcnMgPSBmdW5jdGlvbiBzZXRNYXhMaXN0ZW5lcnMobikge1xuICAgIGlmICh0eXBlb2YgbiAhPT0gJ251bWJlcicgfHwgbiA8IDAgfHwgTnVtYmVySXNOYU4obikpIHtcbiAgICAgICAgdGhyb3cgbmV3IFJhbmdlRXJyb3IoJ1RoZSB2YWx1ZSBvZiBcIm5cIiBpcyBvdXQgb2YgcmFuZ2UuIEl0IG11c3QgYmUgYSBub24tbmVnYXRpdmUgbnVtYmVyLiBSZWNlaXZlZCAnICsgbiArICcuJyk7XG4gICAgfVxuICAgIHRoaXMuX21heExpc3RlbmVycyA9IG47XG4gICAgcmV0dXJuIHRoaXM7XG59O1xuZnVuY3Rpb24gX2dldE1heExpc3RlbmVycyh0aGF0KSB7XG4gICAgaWYgKHRoYXQuX21heExpc3RlbmVycyA9PT0gdW5kZWZpbmVkKVxuICAgICAgICByZXR1cm4gRXZlbnRFbWl0dGVyLmRlZmF1bHRNYXhMaXN0ZW5lcnM7XG4gICAgcmV0dXJuIHRoYXQuX21heExpc3RlbmVycztcbn1cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuZ2V0TWF4TGlzdGVuZXJzID0gZnVuY3Rpb24gZ2V0TWF4TGlzdGVuZXJzKCkge1xuICAgIHJldHVybiBfZ2V0TWF4TGlzdGVuZXJzKHRoaXMpO1xufTtcbkV2ZW50RW1pdHRlci5wcm90b3R5cGUuZW1pdCA9IGZ1bmN0aW9uIGVtaXQodHlwZSkge1xuICAgIHZhciBhcmdzID0gW107XG4gICAgZm9yICh2YXIgaSA9IDE7IGkgPCBhcmd1bWVudHMubGVuZ3RoOyBpKyspXG4gICAgICAgIGFyZ3MucHVzaChhcmd1bWVudHNbaV0pO1xuICAgIHZhciBkb0Vycm9yID0gKHR5cGUgPT09ICdlcnJvcicpO1xuICAgIHZhciBldmVudHMgPSB0aGlzLl9ldmVudHM7XG4gICAgaWYgKGV2ZW50cyAhPT0gdW5kZWZpbmVkKVxuICAgICAgICBkb0Vycm9yID0gKGRvRXJyb3IgJiYgZXZlbnRzLmVycm9yID09PSB1bmRlZmluZWQpO1xuICAgIGVsc2UgaWYgKCFkb0Vycm9yKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgLy8gSWYgdGhlcmUgaXMgbm8gJ2Vycm9yJyBldmVudCBsaXN0ZW5lciB0aGVuIHRocm93LlxuICAgIGlmIChkb0Vycm9yKSB7XG4gICAgICAgIHZhciBlcjtcbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID4gMClcbiAgICAgICAgICAgIGVyID0gYXJnc1swXTtcbiAgICAgICAgaWYgKGVyIGluc3RhbmNlb2YgRXJyb3IpIHtcbiAgICAgICAgICAgIC8vIE5vdGU6IFRoZSBjb21tZW50cyBvbiB0aGUgYHRocm93YCBsaW5lcyBhcmUgaW50ZW50aW9uYWwsIHRoZXkgc2hvd1xuICAgICAgICAgICAgLy8gdXAgaW4gTm9kZSdzIG91dHB1dCBpZiB0aGlzIHJlc3VsdHMgaW4gYW4gdW5oYW5kbGVkIGV4Y2VwdGlvbi5cbiAgICAgICAgICAgIHRocm93IGVyOyAvLyBVbmhhbmRsZWQgJ2Vycm9yJyBldmVudFxuICAgICAgICB9XG4gICAgICAgIC8vIEF0IGxlYXN0IGdpdmUgc29tZSBraW5kIG9mIGNvbnRleHQgdG8gdGhlIHVzZXJcbiAgICAgICAgdmFyIGVyciA9IG5ldyBFcnJvcignVW5oYW5kbGVkIGVycm9yLicgKyAoZXIgPyAnICgnICsgZXIubWVzc2FnZSArICcpJyA6ICcnKSk7XG4gICAgICAgIGVyci5jb250ZXh0ID0gZXI7XG4gICAgICAgIHRocm93IGVycjsgLy8gVW5oYW5kbGVkICdlcnJvcicgZXZlbnRcbiAgICB9XG4gICAgdmFyIGhhbmRsZXIgPSBldmVudHNbdHlwZV07XG4gICAgaWYgKGhhbmRsZXIgPT09IHVuZGVmaW5lZClcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIGlmICh0eXBlb2YgaGFuZGxlciA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBSZWZsZWN0QXBwbHkoaGFuZGxlciwgdGhpcywgYXJncyk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB2YXIgbGVuID0gaGFuZGxlci5sZW5ndGg7XG4gICAgICAgIHZhciBsaXN0ZW5lcnMgPSBhcnJheUNsb25lKGhhbmRsZXIsIGxlbik7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgbGVuOyArK2kpXG4gICAgICAgICAgICBSZWZsZWN0QXBwbHkobGlzdGVuZXJzW2ldLCB0aGlzLCBhcmdzKTtcbiAgICB9XG4gICAgcmV0dXJuIHRydWU7XG59O1xuZnVuY3Rpb24gX2FkZExpc3RlbmVyKHRhcmdldCwgdHlwZSwgbGlzdGVuZXIsIHByZXBlbmQpIHtcbiAgICB2YXIgbTtcbiAgICB2YXIgZXZlbnRzO1xuICAgIHZhciBleGlzdGluZztcbiAgICBjaGVja0xpc3RlbmVyKGxpc3RlbmVyKTtcbiAgICBldmVudHMgPSB0YXJnZXQuX2V2ZW50cztcbiAgICBpZiAoZXZlbnRzID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgZXZlbnRzID0gdGFyZ2V0Ll9ldmVudHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICB0YXJnZXQuX2V2ZW50c0NvdW50ID0gMDtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIFRvIGF2b2lkIHJlY3Vyc2lvbiBpbiB0aGUgY2FzZSB0aGF0IHR5cGUgPT09IFwibmV3TGlzdGVuZXJcIiEgQmVmb3JlXG4gICAgICAgIC8vIGFkZGluZyBpdCB0byB0aGUgbGlzdGVuZXJzLCBmaXJzdCBlbWl0IFwibmV3TGlzdGVuZXJcIi5cbiAgICAgICAgaWYgKGV2ZW50cy5uZXdMaXN0ZW5lciAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICB0YXJnZXQuZW1pdCgnbmV3TGlzdGVuZXInLCB0eXBlLCBsaXN0ZW5lci5saXN0ZW5lciA/IGxpc3RlbmVyLmxpc3RlbmVyIDogbGlzdGVuZXIpO1xuICAgICAgICAgICAgLy8gUmUtYXNzaWduIGBldmVudHNgIGJlY2F1c2UgYSBuZXdMaXN0ZW5lciBoYW5kbGVyIGNvdWxkIGhhdmUgY2F1c2VkIHRoZVxuICAgICAgICAgICAgLy8gdGhpcy5fZXZlbnRzIHRvIGJlIGFzc2lnbmVkIHRvIGEgbmV3IG9iamVjdFxuICAgICAgICAgICAgZXZlbnRzID0gdGFyZ2V0Ll9ldmVudHM7XG4gICAgICAgIH1cbiAgICAgICAgZXhpc3RpbmcgPSBldmVudHNbdHlwZV07XG4gICAgfVxuICAgIGlmIChleGlzdGluZyA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIC8vIE9wdGltaXplIHRoZSBjYXNlIG9mIG9uZSBsaXN0ZW5lci4gRG9uJ3QgbmVlZCB0aGUgZXh0cmEgYXJyYXkgb2JqZWN0LlxuICAgICAgICBleGlzdGluZyA9IGV2ZW50c1t0eXBlXSA9IGxpc3RlbmVyO1xuICAgICAgICArK3RhcmdldC5fZXZlbnRzQ291bnQ7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBpZiAodHlwZW9mIGV4aXN0aW5nID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAvLyBBZGRpbmcgdGhlIHNlY29uZCBlbGVtZW50LCBuZWVkIHRvIGNoYW5nZSB0byBhcnJheS5cbiAgICAgICAgICAgIGV4aXN0aW5nID0gZXZlbnRzW3R5cGVdID1cbiAgICAgICAgICAgICAgICBwcmVwZW5kID8gW2xpc3RlbmVyLCBleGlzdGluZ10gOiBbZXhpc3RpbmcsIGxpc3RlbmVyXTtcbiAgICAgICAgICAgIC8vIElmIHdlJ3ZlIGFscmVhZHkgZ290IGFuIGFycmF5LCBqdXN0IGFwcGVuZC5cbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChwcmVwZW5kKSB7XG4gICAgICAgICAgICBleGlzdGluZy51bnNoaWZ0KGxpc3RlbmVyKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGV4aXN0aW5nLnB1c2gobGlzdGVuZXIpO1xuICAgICAgICB9XG4gICAgICAgIC8vIENoZWNrIGZvciBsaXN0ZW5lciBsZWFrXG4gICAgICAgIG0gPSBfZ2V0TWF4TGlzdGVuZXJzKHRhcmdldCk7XG4gICAgICAgIGlmIChtID4gMCAmJiBleGlzdGluZy5sZW5ndGggPiBtICYmICFleGlzdGluZy53YXJuZWQpIHtcbiAgICAgICAgICAgIGV4aXN0aW5nLndhcm5lZCA9IHRydWU7XG4gICAgICAgICAgICAvLyBObyBlcnJvciBjb2RlIGZvciB0aGlzIHNpbmNlIGl0IGlzIGEgV2FybmluZ1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXJlc3RyaWN0ZWQtc3ludGF4XG4gICAgICAgICAgICB2YXIgdyA9IG5ldyBFcnJvcignUG9zc2libGUgRXZlbnRFbWl0dGVyIG1lbW9yeSBsZWFrIGRldGVjdGVkLiAnICtcbiAgICAgICAgICAgICAgICBleGlzdGluZy5sZW5ndGggKyAnICcgKyBTdHJpbmcodHlwZSkgKyAnIGxpc3RlbmVycyAnICtcbiAgICAgICAgICAgICAgICAnYWRkZWQuIFVzZSBlbWl0dGVyLnNldE1heExpc3RlbmVycygpIHRvICcgK1xuICAgICAgICAgICAgICAgICdpbmNyZWFzZSBsaW1pdCcpO1xuICAgICAgICAgICAgdy5uYW1lID0gJ01heExpc3RlbmVyc0V4Y2VlZGVkV2FybmluZyc7XG4gICAgICAgICAgICB3LmVtaXR0ZXIgPSB0YXJnZXQ7XG4gICAgICAgICAgICB3LnR5cGUgPSB0eXBlO1xuICAgICAgICAgICAgdy5jb3VudCA9IGV4aXN0aW5nLmxlbmd0aDtcbiAgICAgICAgICAgIFByb2Nlc3NFbWl0V2FybmluZyh3KTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdGFyZ2V0O1xufVxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5hZGRMaXN0ZW5lciA9IGZ1bmN0aW9uIGFkZExpc3RlbmVyKHR5cGUsIGxpc3RlbmVyKSB7XG4gICAgcmV0dXJuIF9hZGRMaXN0ZW5lcih0aGlzLCB0eXBlLCBsaXN0ZW5lciwgZmFsc2UpO1xufTtcbkV2ZW50RW1pdHRlci5wcm90b3R5cGUub24gPSBFdmVudEVtaXR0ZXIucHJvdG90eXBlLmFkZExpc3RlbmVyO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5wcmVwZW5kTGlzdGVuZXIgPVxuICAgIGZ1bmN0aW9uIHByZXBlbmRMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcikge1xuICAgICAgICByZXR1cm4gX2FkZExpc3RlbmVyKHRoaXMsIHR5cGUsIGxpc3RlbmVyLCB0cnVlKTtcbiAgICB9O1xuZnVuY3Rpb24gb25jZVdyYXBwZXIoKSB7XG4gICAgaWYgKCF0aGlzLmZpcmVkKSB7XG4gICAgICAgIHRoaXMudGFyZ2V0LnJlbW92ZUxpc3RlbmVyKHRoaXMudHlwZSwgdGhpcy53cmFwRm4pO1xuICAgICAgICB0aGlzLmZpcmVkID0gdHJ1ZTtcbiAgICAgICAgaWYgKGFyZ3VtZW50cy5sZW5ndGggPT09IDApXG4gICAgICAgICAgICByZXR1cm4gdGhpcy5saXN0ZW5lci5jYWxsKHRoaXMudGFyZ2V0KTtcbiAgICAgICAgcmV0dXJuIHRoaXMubGlzdGVuZXIuYXBwbHkodGhpcy50YXJnZXQsIGFyZ3VtZW50cyk7XG4gICAgfVxufVxuZnVuY3Rpb24gX29uY2VXcmFwKHRhcmdldCwgdHlwZSwgbGlzdGVuZXIpIHtcbiAgICB2YXIgc3RhdGUgPSB7IGZpcmVkOiBmYWxzZSwgd3JhcEZuOiB1bmRlZmluZWQsIHRhcmdldDogdGFyZ2V0LCB0eXBlOiB0eXBlLCBsaXN0ZW5lcjogbGlzdGVuZXIgfTtcbiAgICB2YXIgd3JhcHBlZCA9IG9uY2VXcmFwcGVyLmJpbmQoc3RhdGUpO1xuICAgIHdyYXBwZWQubGlzdGVuZXIgPSBsaXN0ZW5lcjtcbiAgICBzdGF0ZS53cmFwRm4gPSB3cmFwcGVkO1xuICAgIHJldHVybiB3cmFwcGVkO1xufVxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5vbmNlID0gZnVuY3Rpb24gb25jZSh0eXBlLCBsaXN0ZW5lcikge1xuICAgIGNoZWNrTGlzdGVuZXIobGlzdGVuZXIpO1xuICAgIHRoaXMub24odHlwZSwgX29uY2VXcmFwKHRoaXMsIHR5cGUsIGxpc3RlbmVyKSk7XG4gICAgcmV0dXJuIHRoaXM7XG59O1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5wcmVwZW5kT25jZUxpc3RlbmVyID1cbiAgICBmdW5jdGlvbiBwcmVwZW5kT25jZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVyKSB7XG4gICAgICAgIGNoZWNrTGlzdGVuZXIobGlzdGVuZXIpO1xuICAgICAgICB0aGlzLnByZXBlbmRMaXN0ZW5lcih0eXBlLCBfb25jZVdyYXAodGhpcywgdHlwZSwgbGlzdGVuZXIpKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbi8vIEVtaXRzIGEgJ3JlbW92ZUxpc3RlbmVyJyBldmVudCBpZiBhbmQgb25seSBpZiB0aGUgbGlzdGVuZXIgd2FzIHJlbW92ZWQuXG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyID1cbiAgICBmdW5jdGlvbiByZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcikge1xuICAgICAgICB2YXIgbGlzdCwgZXZlbnRzLCBwb3NpdGlvbiwgaSwgb3JpZ2luYWxMaXN0ZW5lcjtcbiAgICAgICAgY2hlY2tMaXN0ZW5lcihsaXN0ZW5lcik7XG4gICAgICAgIGV2ZW50cyA9IHRoaXMuX2V2ZW50cztcbiAgICAgICAgaWYgKGV2ZW50cyA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIGxpc3QgPSBldmVudHNbdHlwZV07XG4gICAgICAgIGlmIChsaXN0ID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgaWYgKGxpc3QgPT09IGxpc3RlbmVyIHx8IGxpc3QubGlzdGVuZXIgPT09IGxpc3RlbmVyKSB7XG4gICAgICAgICAgICBpZiAoLS10aGlzLl9ldmVudHNDb3VudCA9PT0gMClcbiAgICAgICAgICAgICAgICB0aGlzLl9ldmVudHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZGVsZXRlIGV2ZW50c1t0eXBlXTtcbiAgICAgICAgICAgICAgICBpZiAoZXZlbnRzLnJlbW92ZUxpc3RlbmVyKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLmVtaXQoJ3JlbW92ZUxpc3RlbmVyJywgdHlwZSwgbGlzdC5saXN0ZW5lciB8fCBsaXN0ZW5lcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodHlwZW9mIGxpc3QgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHBvc2l0aW9uID0gLTE7XG4gICAgICAgICAgICBmb3IgKGkgPSBsaXN0Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICAgICAgaWYgKGxpc3RbaV0gPT09IGxpc3RlbmVyIHx8IGxpc3RbaV0ubGlzdGVuZXIgPT09IGxpc3RlbmVyKSB7XG4gICAgICAgICAgICAgICAgICAgIG9yaWdpbmFsTGlzdGVuZXIgPSBsaXN0W2ldLmxpc3RlbmVyO1xuICAgICAgICAgICAgICAgICAgICBwb3NpdGlvbiA9IGk7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChwb3NpdGlvbiA8IDApXG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgICAgICBpZiAocG9zaXRpb24gPT09IDApXG4gICAgICAgICAgICAgICAgbGlzdC5zaGlmdCgpO1xuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgc3BsaWNlT25lKGxpc3QsIHBvc2l0aW9uKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChsaXN0Lmxlbmd0aCA9PT0gMSlcbiAgICAgICAgICAgICAgICBldmVudHNbdHlwZV0gPSBsaXN0WzBdO1xuICAgICAgICAgICAgaWYgKGV2ZW50cy5yZW1vdmVMaXN0ZW5lciAhPT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgICAgIHRoaXMuZW1pdCgncmVtb3ZlTGlzdGVuZXInLCB0eXBlLCBvcmlnaW5hbExpc3RlbmVyIHx8IGxpc3RlbmVyKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9O1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5vZmYgPSBFdmVudEVtaXR0ZXIucHJvdG90eXBlLnJlbW92ZUxpc3RlbmVyO1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5yZW1vdmVBbGxMaXN0ZW5lcnMgPVxuICAgIGZ1bmN0aW9uIHJlbW92ZUFsbExpc3RlbmVycyh0eXBlKSB7XG4gICAgICAgIHZhciBsaXN0ZW5lcnMsIGV2ZW50cywgaTtcbiAgICAgICAgZXZlbnRzID0gdGhpcy5fZXZlbnRzO1xuICAgICAgICBpZiAoZXZlbnRzID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgLy8gbm90IGxpc3RlbmluZyBmb3IgcmVtb3ZlTGlzdGVuZXIsIG5vIG5lZWQgdG8gZW1pdFxuICAgICAgICBpZiAoZXZlbnRzLnJlbW92ZUxpc3RlbmVyID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGlmIChhcmd1bWVudHMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5fZXZlbnRzID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgICAgICAgICB0aGlzLl9ldmVudHNDb3VudCA9IDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChldmVudHNbdHlwZV0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGlmICgtLXRoaXMuX2V2ZW50c0NvdW50ID09PSAwKVxuICAgICAgICAgICAgICAgICAgICB0aGlzLl9ldmVudHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICAgICAgICAgIGVsc2VcbiAgICAgICAgICAgICAgICAgICAgZGVsZXRlIGV2ZW50c1t0eXBlXTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIC8vIGVtaXQgcmVtb3ZlTGlzdGVuZXIgZm9yIGFsbCBsaXN0ZW5lcnMgb24gYWxsIGV2ZW50c1xuICAgICAgICBpZiAoYXJndW1lbnRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICAgICAgdmFyIGtleXMgPSBPYmplY3Qua2V5cyhldmVudHMpO1xuICAgICAgICAgICAgdmFyIGtleTtcbiAgICAgICAgICAgIGZvciAoaSA9IDA7IGkgPCBrZXlzLmxlbmd0aDsgKytpKSB7XG4gICAgICAgICAgICAgICAga2V5ID0ga2V5c1tpXTtcbiAgICAgICAgICAgICAgICBpZiAoa2V5ID09PSAncmVtb3ZlTGlzdGVuZXInKVxuICAgICAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZUFsbExpc3RlbmVycyhrZXkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgdGhpcy5yZW1vdmVBbGxMaXN0ZW5lcnMoJ3JlbW92ZUxpc3RlbmVyJyk7XG4gICAgICAgICAgICB0aGlzLl9ldmVudHMgPSBPYmplY3QuY3JlYXRlKG51bGwpO1xuICAgICAgICAgICAgdGhpcy5fZXZlbnRzQ291bnQgPSAwO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICAgICAgbGlzdGVuZXJzID0gZXZlbnRzW3R5cGVdO1xuICAgICAgICBpZiAodHlwZW9mIGxpc3RlbmVycyA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdGhpcy5yZW1vdmVMaXN0ZW5lcih0eXBlLCBsaXN0ZW5lcnMpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGxpc3RlbmVycyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAvLyBMSUZPIG9yZGVyXG4gICAgICAgICAgICBmb3IgKGkgPSBsaXN0ZW5lcnMubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgICAgICB0aGlzLnJlbW92ZUxpc3RlbmVyKHR5cGUsIGxpc3RlbmVyc1tpXSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfTtcbmZ1bmN0aW9uIF9saXN0ZW5lcnModGFyZ2V0LCB0eXBlLCB1bndyYXApIHtcbiAgICB2YXIgZXZlbnRzID0gdGFyZ2V0Ll9ldmVudHM7XG4gICAgaWYgKGV2ZW50cyA9PT0gdW5kZWZpbmVkKVxuICAgICAgICByZXR1cm4gW107XG4gICAgdmFyIGV2bGlzdGVuZXIgPSBldmVudHNbdHlwZV07XG4gICAgaWYgKGV2bGlzdGVuZXIgPT09IHVuZGVmaW5lZClcbiAgICAgICAgcmV0dXJuIFtdO1xuICAgIGlmICh0eXBlb2YgZXZsaXN0ZW5lciA9PT0gJ2Z1bmN0aW9uJylcbiAgICAgICAgcmV0dXJuIHVud3JhcCA/IFtldmxpc3RlbmVyLmxpc3RlbmVyIHx8IGV2bGlzdGVuZXJdIDogW2V2bGlzdGVuZXJdO1xuICAgIHJldHVybiB1bndyYXAgP1xuICAgICAgICB1bndyYXBMaXN0ZW5lcnMoZXZsaXN0ZW5lcikgOiBhcnJheUNsb25lKGV2bGlzdGVuZXIsIGV2bGlzdGVuZXIubGVuZ3RoKTtcbn1cbkV2ZW50RW1pdHRlci5wcm90b3R5cGUubGlzdGVuZXJzID0gZnVuY3Rpb24gbGlzdGVuZXJzKHR5cGUpIHtcbiAgICByZXR1cm4gX2xpc3RlbmVycyh0aGlzLCB0eXBlLCB0cnVlKTtcbn07XG5FdmVudEVtaXR0ZXIucHJvdG90eXBlLnJhd0xpc3RlbmVycyA9IGZ1bmN0aW9uIHJhd0xpc3RlbmVycyh0eXBlKSB7XG4gICAgcmV0dXJuIF9saXN0ZW5lcnModGhpcywgdHlwZSwgZmFsc2UpO1xufTtcbkV2ZW50RW1pdHRlci5saXN0ZW5lckNvdW50ID0gZnVuY3Rpb24gKGVtaXR0ZXIsIHR5cGUpIHtcbiAgICBpZiAodHlwZW9mIGVtaXR0ZXIubGlzdGVuZXJDb3VudCA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICByZXR1cm4gZW1pdHRlci5saXN0ZW5lckNvdW50KHR5cGUpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGxpc3RlbmVyQ291bnQuY2FsbChlbWl0dGVyLCB0eXBlKTtcbiAgICB9XG59O1xuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5saXN0ZW5lckNvdW50ID0gbGlzdGVuZXJDb3VudDtcbmZ1bmN0aW9uIGxpc3RlbmVyQ291bnQodHlwZSkge1xuICAgIHZhciBldmVudHMgPSB0aGlzLl9ldmVudHM7XG4gICAgaWYgKGV2ZW50cyAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgIHZhciBldmxpc3RlbmVyID0gZXZlbnRzW3R5cGVdO1xuICAgICAgICBpZiAodHlwZW9mIGV2bGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHJldHVybiAxO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGV2bGlzdGVuZXIgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgcmV0dXJuIGV2bGlzdGVuZXIubGVuZ3RoO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiAwO1xufVxuRXZlbnRFbWl0dGVyLnByb3RvdHlwZS5ldmVudE5hbWVzID0gZnVuY3Rpb24gZXZlbnROYW1lcygpIHtcbiAgICByZXR1cm4gdGhpcy5fZXZlbnRzQ291bnQgPiAwID8gUmVmbGVjdE93bktleXModGhpcy5fZXZlbnRzKSA6IFtdO1xufTtcbmZ1bmN0aW9uIGFycmF5Q2xvbmUoYXJyLCBuKSB7XG4gICAgdmFyIGNvcHkgPSBuZXcgQXJyYXkobik7XG4gICAgZm9yICh2YXIgaSA9IDA7IGkgPCBuOyArK2kpXG4gICAgICAgIGNvcHlbaV0gPSBhcnJbaV07XG4gICAgcmV0dXJuIGNvcHk7XG59XG5mdW5jdGlvbiBzcGxpY2VPbmUobGlzdCwgaW5kZXgpIHtcbiAgICBmb3IgKDsgaW5kZXggKyAxIDwgbGlzdC5sZW5ndGg7IGluZGV4KyspXG4gICAgICAgIGxpc3RbaW5kZXhdID0gbGlzdFtpbmRleCArIDFdO1xuICAgIGxpc3QucG9wKCk7XG59XG5mdW5jdGlvbiB1bndyYXBMaXN0ZW5lcnMoYXJyKSB7XG4gICAgdmFyIHJldCA9IG5ldyBBcnJheShhcnIubGVuZ3RoKTtcbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJldC5sZW5ndGg7ICsraSkge1xuICAgICAgICByZXRbaV0gPSBhcnJbaV0ubGlzdGVuZXIgfHwgYXJyW2ldO1xuICAgIH1cbiAgICByZXR1cm4gcmV0O1xufVxuZnVuY3Rpb24gb25jZShlbWl0dGVyLCBuYW1lKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKGZ1bmN0aW9uIChyZXNvbHZlLCByZWplY3QpIHtcbiAgICAgICAgZnVuY3Rpb24gZXJyb3JMaXN0ZW5lcihlcnIpIHtcbiAgICAgICAgICAgIGVtaXR0ZXIucmVtb3ZlTGlzdGVuZXIobmFtZSwgcmVzb2x2ZXIpO1xuICAgICAgICAgICAgcmVqZWN0KGVycik7XG4gICAgICAgIH1cbiAgICAgICAgZnVuY3Rpb24gcmVzb2x2ZXIoKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIGVtaXR0ZXIucmVtb3ZlTGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICBlbWl0dGVyLnJlbW92ZUxpc3RlbmVyKCdlcnJvcicsIGVycm9yTGlzdGVuZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVzb2x2ZShbXS5zbGljZS5jYWxsKGFyZ3VtZW50cykpO1xuICAgICAgICB9XG4gICAgICAgIDtcbiAgICAgICAgZXZlbnRUYXJnZXRBZ25vc3RpY0FkZExpc3RlbmVyKGVtaXR0ZXIsIG5hbWUsIHJlc29sdmVyLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICAgIGlmIChuYW1lICE9PSAnZXJyb3InKSB7XG4gICAgICAgICAgICBhZGRFcnJvckhhbmRsZXJJZkV2ZW50RW1pdHRlcihlbWl0dGVyLCBlcnJvckxpc3RlbmVyLCB7IG9uY2U6IHRydWUgfSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn1cbmZ1bmN0aW9uIGFkZEVycm9ySGFuZGxlcklmRXZlbnRFbWl0dGVyKGVtaXR0ZXIsIGhhbmRsZXIsIGZsYWdzKSB7XG4gICAgaWYgKHR5cGVvZiBlbWl0dGVyLm9uID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIGV2ZW50VGFyZ2V0QWdub3N0aWNBZGRMaXN0ZW5lcihlbWl0dGVyLCAnZXJyb3InLCBoYW5kbGVyLCBmbGFncyk7XG4gICAgfVxufVxuZnVuY3Rpb24gZXZlbnRUYXJnZXRBZ25vc3RpY0FkZExpc3RlbmVyKGVtaXR0ZXIsIG5hbWUsIGxpc3RlbmVyLCBmbGFncykge1xuICAgIGlmICh0eXBlb2YgZW1pdHRlci5vbiA9PT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICBpZiAoZmxhZ3Mub25jZSkge1xuICAgICAgICAgICAgZW1pdHRlci5vbmNlKG5hbWUsIGxpc3RlbmVyKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGVtaXR0ZXIub24obmFtZSwgbGlzdGVuZXIpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2UgaWYgKHR5cGVvZiBlbWl0dGVyLmFkZEV2ZW50TGlzdGVuZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgLy8gRXZlbnRUYXJnZXQgZG9lcyBub3QgaGF2ZSBgZXJyb3JgIGV2ZW50IHNlbWFudGljcyBsaWtlIE5vZGVcbiAgICAgICAgLy8gRXZlbnRFbWl0dGVycywgd2UgZG8gbm90IGxpc3RlbiBmb3IgYGVycm9yYCBldmVudHMgaGVyZS5cbiAgICAgICAgZW1pdHRlci5hZGRFdmVudExpc3RlbmVyKG5hbWUsIGZ1bmN0aW9uIHdyYXBMaXN0ZW5lcihhcmcpIHtcbiAgICAgICAgICAgIC8vIElFIGRvZXMgbm90IGhhdmUgYnVpbHRpbiBgeyBvbmNlOiB0cnVlIH1gIHN1cHBvcnQgc28gd2VcbiAgICAgICAgICAgIC8vIGhhdmUgdG8gZG8gaXQgbWFudWFsbHkuXG4gICAgICAgICAgICBpZiAoZmxhZ3Mub25jZSkge1xuICAgICAgICAgICAgICAgIGVtaXR0ZXIucmVtb3ZlRXZlbnRMaXN0ZW5lcihuYW1lLCB3cmFwTGlzdGVuZXIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgbGlzdGVuZXIoYXJnKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKCdUaGUgXCJlbWl0dGVyXCIgYXJndW1lbnQgbXVzdCBiZSBvZiB0eXBlIEV2ZW50RW1pdHRlci4gUmVjZWl2ZWQgdHlwZSAnICsgdHlwZW9mIGVtaXR0ZXIpO1xuICAgIH1cbn1cbiIsImZ1bmN0aW9uIF90eXBlb2Yobykge1xuICAgIFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjtcbiAgICByZXR1cm4gX3R5cGVvZiA9IFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIFwic3ltYm9sXCIgPT0gdHlwZW9mIFN5bWJvbC5pdGVyYXRvciA/IGZ1bmN0aW9uIChvKSB7IHJldHVybiB0eXBlb2YgbzsgfSA6IGZ1bmN0aW9uIChvKSB7IHJldHVybiBvICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgU3ltYm9sICYmIG8uY29uc3RydWN0b3IgPT09IFN5bWJvbCAmJiBvICE9PSBTeW1ib2wucHJvdG90eXBlID8gXCJzeW1ib2xcIiA6IHR5cGVvZiBvOyB9LCBfdHlwZW9mKG8pO1xufVxuZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGEsIG4pIHsgaWYgKCEoYSBpbnN0YW5jZW9mIG4pKVxuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb25cIik7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0aWVzKGUsIHIpIHsgZm9yICh2YXIgdCA9IDA7IHQgPCByLmxlbmd0aDsgdCsrKSB7XG4gICAgdmFyIG8gPSByW3RdO1xuICAgIG8uZW51bWVyYWJsZSA9IG8uZW51bWVyYWJsZSB8fCAhMSwgby5jb25maWd1cmFibGUgPSAhMCwgXCJ2YWx1ZVwiIGluIG8gJiYgKG8ud3JpdGFibGUgPSAhMCksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCBfdG9Qcm9wZXJ0eUtleShvLmtleSksIG8pO1xufSB9XG5mdW5jdGlvbiBfY3JlYXRlQ2xhc3MoZSwgciwgdCkgeyByZXR1cm4gciAmJiBfZGVmaW5lUHJvcGVydGllcyhlLnByb3RvdHlwZSwgciksIHQgJiYgX2RlZmluZVByb3BlcnRpZXMoZSwgdCksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCBcInByb3RvdHlwZVwiLCB7IHdyaXRhYmxlOiAhMSB9KSwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gX3R5cGVvZihpKSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZih0KSB8fCAhdClcbiAgICByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHtcbiAgICB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTtcbiAgICBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKGkpKVxuICAgICAgICByZXR1cm4gaTtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7XG59IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbmltcG9ydCB7IGxvZyB9IGZyb20gXCIuLi91dGlscy9sb2cuanNcIjtcbnZhciBXZWJTb2NrZXRDbGllbnQgPSAvKiNfX1BVUkVfXyovIGZ1bmN0aW9uICgpIHtcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gdXJsXG4gICAgICovXG4gICAgZnVuY3Rpb24gV2ViU29ja2V0Q2xpZW50KHVybCkge1xuICAgICAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgV2ViU29ja2V0Q2xpZW50KTtcbiAgICAgICAgdGhpcy5jbGllbnQgPSBuZXcgV2ViU29ja2V0KHVybCk7XG4gICAgICAgIHRoaXMuY2xpZW50Lm9uZXJyb3IgPSBmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgIGxvZy5lcnJvcihlcnJvcik7XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7KC4uLmFyZ3M6IGFueVtdKSA9PiB2b2lkfSBmXG4gICAgICovXG4gICAgcmV0dXJuIF9jcmVhdGVDbGFzcyhXZWJTb2NrZXRDbGllbnQsIFt7XG4gICAgICAgICAgICBrZXk6IFwib25PcGVuXCIsXG4gICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gb25PcGVuKGYpIHtcbiAgICAgICAgICAgICAgICB0aGlzLmNsaWVudC5vbm9wZW4gPSBmO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBAcGFyYW0geyguLi5hcmdzOiBhbnlbXSkgPT4gdm9pZH0gZlxuICAgICAgICAgICAgICovXG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgIGtleTogXCJvbkNsb3NlXCIsXG4gICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gb25DbG9zZShmKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jbGllbnQub25jbG9zZSA9IGY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBjYWxsIGYgd2l0aCB0aGUgbWVzc2FnZSBzdHJpbmcgYXMgdGhlIGZpcnN0IGFyZ3VtZW50XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEBwYXJhbSB7KC4uLmFyZ3M6IGFueVtdKSA9PiB2b2lkfSBmXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgfSwge1xuICAgICAgICAgICAga2V5OiBcIm9uTWVzc2FnZVwiLFxuICAgICAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIG9uTWVzc2FnZShmKSB7XG4gICAgICAgICAgICAgICAgdGhpcy5jbGllbnQub25tZXNzYWdlID0gZnVuY3Rpb24gKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgZihlLmRhdGEpO1xuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICB9XG4gICAgICAgIH1dKTtcbn0oKTtcbmV4cG9ydCB7IFdlYlNvY2tldENsaWVudCBhcyBkZWZhdWx0IH07XG4iLCJcInVzZSBzdHJpY3RcIjtcbi8qKioqKiovIChmdW5jdGlvbiAoKSB7XG4gICAgLyoqKioqKi8gXCJ1c2Ugc3RyaWN0XCI7XG4gICAgLyoqKioqKi8gdmFyIF9fd2VicGFja19tb2R1bGVzX18gPSAoe1xuICAgICAgICAvKioqLyBcIi4vY2xpZW50LXNyYy9tb2R1bGVzL2xvZ2dlci90YXBhYmxlLmpzXCI6IFxuICAgICAgICAvKiEqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqISpcXFxuICAgICAgICAgICEqKiogLi9jbGllbnQtc3JjL21vZHVsZXMvbG9nZ2VyL3RhcGFibGUuanMgKioqIVxuICAgICAgICAgIFxcKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgICAgICAgLyoqKi8gKGZ1bmN0aW9uIChfX3VudXNlZF93ZWJwYWNrX21vZHVsZSwgX193ZWJwYWNrX2V4cG9ydHNfXywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuICAgICAgICAgICAgX193ZWJwYWNrX3JlcXVpcmVfXy5yKF9fd2VicGFja19leHBvcnRzX18pO1xuICAgICAgICAgICAgLyogaGFybW9ueSBleHBvcnQgKi8gX193ZWJwYWNrX3JlcXVpcmVfXy5kKF9fd2VicGFja19leHBvcnRzX18sIHtcbiAgICAgICAgICAgICAgICAvKiBoYXJtb255IGV4cG9ydCAqLyBTeW5jQmFpbEhvb2s6IGZ1bmN0aW9uICgpIHsgcmV0dXJuIC8qIGJpbmRpbmcgKi8gU3luY0JhaWxIb29rOyB9XG4gICAgICAgICAgICAgICAgLyogaGFybW9ueSBleHBvcnQgKi8gXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGZ1bmN0aW9uIFN5bmNCYWlsSG9vaygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBjYWxsOiBmdW5jdGlvbiBjYWxsKCkgeyB9XG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ2xpZW50IHN0dWIgZm9yIHRhcGFibGUgU3luY0JhaWxIb29rXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBpbXBvcnQvcHJlZmVyLWRlZmF1bHQtZXhwb3J0XG4gICAgICAgICAgICAvKioqLyBcbiAgICAgICAgfSksXG4gICAgICAgIC8qKiovIFwiLi9ub2RlX21vZHVsZXMvd2VicGFjay9saWIvbG9nZ2luZy9Mb2dnZXIuanNcIjogXG4gICAgICAgIC8qISoqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiohKlxcXG4gICAgICAgICAgISoqKiAuL25vZGVfbW9kdWxlcy93ZWJwYWNrL2xpYi9sb2dnaW5nL0xvZ2dlci5qcyAqKiohXG4gICAgICAgICAgXFwqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgICAgICAvKioqLyAoZnVuY3Rpb24gKG1vZHVsZSkge1xuICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICBNSVQgTGljZW5zZSBodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocFxuICAgICAgICAgICAgICAgIEF1dGhvciBUb2JpYXMgS29wcGVycyBAc29rcmFcbiAgICAgICAgICAgICovXG4gICAgICAgICAgICBmdW5jdGlvbiBfdHlwZW9mKG8pIHtcbiAgICAgICAgICAgICAgICBcIkBiYWJlbC9oZWxwZXJzIC0gdHlwZW9mXCI7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiID8gU3ltYm9sIDogZnVuY3Rpb24gKGkpIHsgcmV0dXJuIGk7IH0pICYmIFwic3ltYm9sXCIgPT0gdHlwZW9mICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiID8gU3ltYm9sIDogZnVuY3Rpb24gKGkpIHsgcmV0dXJuIGk7IH0pLml0ZXJhdG9yID8gZnVuY3Rpb24gKG8pIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHR5cGVvZiBvO1xuICAgICAgICAgICAgICAgIH0gOiBmdW5jdGlvbiAobykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiID8gU3ltYm9sIDogZnVuY3Rpb24gKGkpIHsgcmV0dXJuIGk7IH0pICYmIG8uY29uc3RydWN0b3IgPT09ICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiID8gU3ltYm9sIDogZnVuY3Rpb24gKGkpIHsgcmV0dXJuIGk7IH0pICYmIG8gIT09ICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiID8gU3ltYm9sIDogZnVuY3Rpb24gKGkpIHsgcmV0dXJuIGk7IH0pLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbztcbiAgICAgICAgICAgICAgICB9LCBfdHlwZW9mKG8pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX3RvQ29uc3VtYWJsZUFycmF5KHIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2FycmF5V2l0aG91dEhvbGVzKHIpIHx8IF9pdGVyYWJsZVRvQXJyYXkocikgfHwgX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KHIpIHx8IF9ub25JdGVyYWJsZVNwcmVhZCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX25vbkl0ZXJhYmxlU3ByZWFkKCkge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJJbnZhbGlkIGF0dGVtcHQgdG8gc3ByZWFkIG5vbi1pdGVyYWJsZSBpbnN0YW5jZS5cXG5JbiBvcmRlciB0byBiZSBpdGVyYWJsZSwgbm9uLWFycmF5IG9iamVjdHMgbXVzdCBoYXZlIGEgW1N5bWJvbC5pdGVyYXRvcl0oKSBtZXRob2QuXCIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KHIsIGEpIHtcbiAgICAgICAgICAgICAgICBpZiAocikge1xuICAgICAgICAgICAgICAgICAgICBpZiAoXCJzdHJpbmdcIiA9PSB0eXBlb2YgcilcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBfYXJyYXlMaWtlVG9BcnJheShyLCBhKTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIHQgPSB7fS50b1N0cmluZy5jYWxsKHIpLnNsaWNlKDgsIC0xKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFwiT2JqZWN0XCIgPT09IHQgJiYgci5jb25zdHJ1Y3RvciAmJiAodCA9IHIuY29uc3RydWN0b3IubmFtZSksIFwiTWFwXCIgPT09IHQgfHwgXCJTZXRcIiA9PT0gdCA/IEFycmF5LmZyb20ocikgOiBcIkFyZ3VtZW50c1wiID09PSB0IHx8IC9eKD86VWl8SSludCg/Ojh8MTZ8MzIpKD86Q2xhbXBlZCk/QXJyYXkkLy50ZXN0KHQpID8gX2FycmF5TGlrZVRvQXJyYXkociwgYSkgOiB2b2lkIDA7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX2l0ZXJhYmxlVG9BcnJheShyKSB7XG4gICAgICAgICAgICAgICAgaWYgKFwidW5kZWZpbmVkXCIgIT0gdHlwZW9mICh0eXBlb2YgU3ltYm9sICE9PSBcInVuZGVmaW5lZFwiID8gU3ltYm9sIDogZnVuY3Rpb24gKGkpIHsgcmV0dXJuIGk7IH0pICYmIG51bGwgIT0gclsodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiA/IFN5bWJvbCA6IGZ1bmN0aW9uIChpKSB7IHJldHVybiBpOyB9KS5pdGVyYXRvcl0gfHwgbnVsbCAhPSByW1wiQEBpdGVyYXRvclwiXSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIEFycmF5LmZyb20ocik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmdW5jdGlvbiBfYXJyYXlXaXRob3V0SG9sZXMocikge1xuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHIpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gX2FycmF5TGlrZVRvQXJyYXkocik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmdW5jdGlvbiBfYXJyYXlMaWtlVG9BcnJheShyLCBhKSB7XG4gICAgICAgICAgICAgICAgKG51bGwgPT0gYSB8fCBhID4gci5sZW5ndGgpICYmIChhID0gci5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIGZvciAodmFyIGUgPSAwLCBuID0gQXJyYXkoYSk7IGUgPCBhOyBlKyspXG4gICAgICAgICAgICAgICAgICAgIG5bZV0gPSByW2VdO1xuICAgICAgICAgICAgICAgIHJldHVybiBuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX2NsYXNzQ2FsbENoZWNrKGEsIG4pIHtcbiAgICAgICAgICAgICAgICBpZiAoIShhIGluc3RhbmNlb2YgbikpXG4gICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJDYW5ub3QgY2FsbCBhIGNsYXNzIGFzIGEgZnVuY3Rpb25cIik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmdW5jdGlvbiBfZGVmaW5lUHJvcGVydGllcyhlLCByKSB7XG4gICAgICAgICAgICAgICAgZm9yICh2YXIgdCA9IDA7IHQgPCByLmxlbmd0aDsgdCsrKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvID0gclt0XTtcbiAgICAgICAgICAgICAgICAgICAgby5lbnVtZXJhYmxlID0gby5lbnVtZXJhYmxlIHx8ICExLCBvLmNvbmZpZ3VyYWJsZSA9ICEwLCBcInZhbHVlXCIgaW4gbyAmJiAoby53cml0YWJsZSA9ICEwKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIF90b1Byb3BlcnR5S2V5KG8ua2V5KSwgbyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX2NyZWF0ZUNsYXNzKGUsIHIsIHQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gciAmJiBfZGVmaW5lUHJvcGVydGllcyhlLnByb3RvdHlwZSwgciksIHQgJiYgX2RlZmluZVByb3BlcnRpZXMoZSwgdCksIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCBcInByb3RvdHlwZVwiLCB7XG4gICAgICAgICAgICAgICAgICAgIHdyaXRhYmxlOiAhMVxuICAgICAgICAgICAgICAgIH0pLCBlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkge1xuICAgICAgICAgICAgICAgIHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpO1xuICAgICAgICAgICAgICAgIHJldHVybiBcInN5bWJvbFwiID09IF90eXBlb2YoaSkgPyBpIDogaSArIFwiXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikge1xuICAgICAgICAgICAgICAgIGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YodCkgfHwgIXQpXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0O1xuICAgICAgICAgICAgICAgIHZhciBlID0gdFsodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiA/IFN5bWJvbCA6IGZ1bmN0aW9uIChpKSB7IHJldHVybiBpOyB9KS50b1ByaW1pdGl2ZV07XG4gICAgICAgICAgICAgICAgaWYgKHZvaWQgMCAhPT0gZSkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZihpKSlcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpO1xuICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgTG9nVHlwZSA9IE9iamVjdC5mcmVlemUoe1xuICAgICAgICAgICAgICAgIGVycm9yOiAoIC8qKiBAdHlwZSB7XCJlcnJvclwifSAqL1wiZXJyb3JcIiksXG4gICAgICAgICAgICAgICAgLy8gbWVzc2FnZSwgYyBzdHlsZSBhcmd1bWVudHNcbiAgICAgICAgICAgICAgICB3YXJuOiAoIC8qKiBAdHlwZSB7XCJ3YXJuXCJ9ICovXCJ3YXJuXCIpLFxuICAgICAgICAgICAgICAgIC8vIG1lc3NhZ2UsIGMgc3R5bGUgYXJndW1lbnRzXG4gICAgICAgICAgICAgICAgaW5mbzogKCAvKiogQHR5cGUge1wiaW5mb1wifSAqL1wiaW5mb1wiKSxcbiAgICAgICAgICAgICAgICAvLyBtZXNzYWdlLCBjIHN0eWxlIGFyZ3VtZW50c1xuICAgICAgICAgICAgICAgIGxvZzogKCAvKiogQHR5cGUge1wibG9nXCJ9ICovXCJsb2dcIiksXG4gICAgICAgICAgICAgICAgLy8gbWVzc2FnZSwgYyBzdHlsZSBhcmd1bWVudHNcbiAgICAgICAgICAgICAgICBkZWJ1ZzogKCAvKiogQHR5cGUge1wiZGVidWdcIn0gKi9cImRlYnVnXCIpLFxuICAgICAgICAgICAgICAgIC8vIG1lc3NhZ2UsIGMgc3R5bGUgYXJndW1lbnRzXG4gICAgICAgICAgICAgICAgdHJhY2U6ICggLyoqIEB0eXBlIHtcInRyYWNlXCJ9ICovXCJ0cmFjZVwiKSxcbiAgICAgICAgICAgICAgICAvLyBubyBhcmd1bWVudHNcbiAgICAgICAgICAgICAgICBncm91cDogKCAvKiogQHR5cGUge1wiZ3JvdXBcIn0gKi9cImdyb3VwXCIpLFxuICAgICAgICAgICAgICAgIC8vIFtsYWJlbF1cbiAgICAgICAgICAgICAgICBncm91cENvbGxhcHNlZDogKCAvKiogQHR5cGUge1wiZ3JvdXBDb2xsYXBzZWRcIn0gKi9cImdyb3VwQ29sbGFwc2VkXCIpLFxuICAgICAgICAgICAgICAgIC8vIFtsYWJlbF1cbiAgICAgICAgICAgICAgICBncm91cEVuZDogKCAvKiogQHR5cGUge1wiZ3JvdXBFbmRcIn0gKi9cImdyb3VwRW5kXCIpLFxuICAgICAgICAgICAgICAgIC8vIFtsYWJlbF1cbiAgICAgICAgICAgICAgICBwcm9maWxlOiAoIC8qKiBAdHlwZSB7XCJwcm9maWxlXCJ9ICovXCJwcm9maWxlXCIpLFxuICAgICAgICAgICAgICAgIC8vIFtwcm9maWxlTmFtZV1cbiAgICAgICAgICAgICAgICBwcm9maWxlRW5kOiAoIC8qKiBAdHlwZSB7XCJwcm9maWxlRW5kXCJ9ICovXCJwcm9maWxlRW5kXCIpLFxuICAgICAgICAgICAgICAgIC8vIFtwcm9maWxlTmFtZV1cbiAgICAgICAgICAgICAgICB0aW1lOiAoIC8qKiBAdHlwZSB7XCJ0aW1lXCJ9ICovXCJ0aW1lXCIpLFxuICAgICAgICAgICAgICAgIC8vIG5hbWUsIHRpbWUgYXMgW3NlY29uZHMsIG5hbm9zZWNvbmRzXVxuICAgICAgICAgICAgICAgIGNsZWFyOiAoIC8qKiBAdHlwZSB7XCJjbGVhclwifSAqL1wiY2xlYXJcIiksXG4gICAgICAgICAgICAgICAgLy8gbm8gYXJndW1lbnRzXG4gICAgICAgICAgICAgICAgc3RhdHVzOiAoIC8qKiBAdHlwZSB7XCJzdGF0dXNcIn0gKi9cInN0YXR1c1wiKSAvLyBtZXNzYWdlLCBhcmd1bWVudHNcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbW9kdWxlLmV4cG9ydHMuTG9nVHlwZSA9IExvZ1R5cGU7XG4gICAgICAgICAgICAvKiogQHR5cGVkZWYge3R5cGVvZiBMb2dUeXBlW2tleW9mIHR5cGVvZiBMb2dUeXBlXX0gTG9nVHlwZUVudW0gKi9cbiAgICAgICAgICAgIHZhciBMT0dfU1lNQk9MID0gKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkoXCJ3ZWJwYWNrIGxvZ2dlciByYXcgbG9nIG1ldGhvZFwiKTtcbiAgICAgICAgICAgIHZhciBUSU1FUlNfU1lNQk9MID0gKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkoXCJ3ZWJwYWNrIGxvZ2dlciB0aW1lc1wiKTtcbiAgICAgICAgICAgIHZhciBUSU1FUlNfQUdHUkVHQVRFU19TWU1CT0wgPSAodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiA/IFN5bWJvbCA6IGZ1bmN0aW9uIChpKSB7IHJldHVybiBpOyB9KShcIndlYnBhY2sgbG9nZ2VyIGFnZ3JlZ2F0ZWQgdGltZXNcIik7XG4gICAgICAgICAgICB2YXIgV2VicGFja0xvZ2dlciA9IC8qI19fUFVSRV9fKi8gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7KHR5cGU6IExvZ1R5cGVFbnVtLCBhcmdzPzogRVhQRUNURURfQU5ZW10pID0+IHZvaWR9IGxvZyBsb2cgZnVuY3Rpb25cbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0geyhuYW1lOiBzdHJpbmcgfCAoKCkgPT4gc3RyaW5nKSkgPT4gV2VicGFja0xvZ2dlcn0gZ2V0Q2hpbGRMb2dnZXIgZnVuY3Rpb24gdG8gY3JlYXRlIGNoaWxkIGxvZ2dlclxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGZ1bmN0aW9uIFdlYnBhY2tMb2dnZXIobG9nLCBnZXRDaGlsZExvZ2dlcikge1xuICAgICAgICAgICAgICAgICAgICBfY2xhc3NDYWxsQ2hlY2sodGhpcywgV2VicGFja0xvZ2dlcik7XG4gICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0gPSBsb2c7XG4gICAgICAgICAgICAgICAgICAgIHRoaXMuZ2V0Q2hpbGRMb2dnZXIgPSBnZXRDaGlsZExvZ2dlcjtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogQHBhcmFtIHsuLi5FWFBFQ1RFRF9BTll9IGFyZ3MgYXJnc1xuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIHJldHVybiBfY3JlYXRlQ2xhc3MoV2VicGFja0xvZ2dlciwgW3tcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJlcnJvclwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIGVycm9yKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmdzW19rZXldID0gYXJndW1lbnRzW19rZXldO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW0xPR19TWU1CT0xdKExvZ1R5cGUuZXJyb3IsIGFyZ3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAgICAgKiBAcGFyYW0gey4uLkVYUEVDVEVEX0FOWX0gYXJncyBhcmdzXG4gICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcIndhcm5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiB3YXJuKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9sZW4yID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuMiksIF9rZXkyID0gMDsgX2tleTIgPCBfbGVuMjsgX2tleTIrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmdzW19rZXkyXSA9IGFyZ3VtZW50c1tfa2V5Ml07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0oTG9nVHlwZS53YXJuLCBhcmdzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHsuLi5FWFBFQ1RFRF9BTll9IGFyZ3MgYXJnc1xuICAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJpbmZvXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gaW5mbygpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfbGVuMyA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbjMpLCBfa2V5MyA9IDA7IF9rZXkzIDwgX2xlbjM7IF9rZXkzKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJnc1tfa2V5M10gPSBhcmd1bWVudHNbX2tleTNdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW0xPR19TWU1CT0xdKExvZ1R5cGUuaW5mbywgYXJncyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7Li4uRVhQRUNURURfQU5ZfSBhcmdzIGFyZ3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwibG9nXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gbG9nKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9sZW40ID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuNCksIF9rZXk0ID0gMDsgX2tleTQgPCBfbGVuNDsgX2tleTQrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmdzW19rZXk0XSA9IGFyZ3VtZW50c1tfa2V5NF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0oTG9nVHlwZS5sb2csIGFyZ3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAgICAgKiBAcGFyYW0gey4uLkVYUEVDVEVEX0FOWX0gYXJncyBhcmdzXG4gICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcImRlYnVnXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gZGVidWcoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2xlbjUgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW41KSwgX2tleTUgPSAwOyBfa2V5NSA8IF9sZW41OyBfa2V5NSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3NbX2tleTVdID0gYXJndW1lbnRzW19rZXk1XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tMT0dfU1lNQk9MXShMb2dUeXBlLmRlYnVnLCBhcmdzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHtFWFBFQ1RFRF9BTll9IGFzc2VydGlvbiBhc3NlcnRpb25cbiAgICAgICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7Li4uRVhQRUNURURfQU5ZfSBhcmdzIGFyZ3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiYXNzZXJ0XCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gYXNzZXJ0KGFzc2VydGlvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghYXNzZXJ0aW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9sZW42ID0gYXJndW1lbnRzLmxlbmd0aCwgYXJncyA9IG5ldyBBcnJheShfbGVuNiA+IDEgPyBfbGVuNiAtIDEgOiAwKSwgX2tleTYgPSAxOyBfa2V5NiA8IF9sZW42OyBfa2V5NisrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBhcmdzW19rZXk2IC0gMV0gPSBhcmd1bWVudHNbX2tleTZdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0oTG9nVHlwZS5lcnJvciwgYXJncyk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwidHJhY2VcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiB0cmFjZSgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW0xPR19TWU1CT0xdKExvZ1R5cGUudHJhY2UsIFtcIlRyYWNlXCJdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcImNsZWFyXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gY2xlYXIoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tMT0dfU1lNQk9MXShMb2dUeXBlLmNsZWFyKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHsuLi5FWFBFQ1RFRF9BTll9IGFyZ3MgYXJnc1xuICAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJzdGF0dXNcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiBzdGF0dXMoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2xlbjcgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW43KSwgX2tleTcgPSAwOyBfa2V5NyA8IF9sZW43OyBfa2V5NysrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3NbX2tleTddID0gYXJndW1lbnRzW19rZXk3XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tMT0dfU1lNQk9MXShMb2dUeXBlLnN0YXR1cywgYXJncyk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7Li4uRVhQRUNURURfQU5ZfSBhcmdzIGFyZ3NcbiAgICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwiZ3JvdXBcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiBncm91cCgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBfbGVuOCA9IGFyZ3VtZW50cy5sZW5ndGgsIGFyZ3MgPSBuZXcgQXJyYXkoX2xlbjgpLCBfa2V5OCA9IDA7IF9rZXk4IDwgX2xlbjg7IF9rZXk4KyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgYXJnc1tfa2V5OF0gPSBhcmd1bWVudHNbX2tleThdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW0xPR19TWU1CT0xdKExvZ1R5cGUuZ3JvdXAsIGFyZ3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAgICAgKiBAcGFyYW0gey4uLkVYUEVDVEVEX0FOWX0gYXJncyBhcmdzXG4gICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcImdyb3VwQ29sbGFwc2VkXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gZ3JvdXBDb2xsYXBzZWQoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZm9yICh2YXIgX2xlbjkgPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW45KSwgX2tleTkgPSAwOyBfa2V5OSA8IF9sZW45OyBfa2V5OSsrKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFyZ3NbX2tleTldID0gYXJndW1lbnRzW19rZXk5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tMT0dfU1lNQk9MXShMb2dUeXBlLmdyb3VwQ29sbGFwc2VkLCBhcmdzKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcImdyb3VwRW5kXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gZ3JvdXBFbmQoKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tMT0dfU1lNQk9MXShMb2dUeXBlLmdyb3VwRW5kKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHtzdHJpbmc9fSBsYWJlbCBsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJwcm9maWxlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gcHJvZmlsZShsYWJlbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0oTG9nVHlwZS5wcm9maWxlLCBbbGFiZWxdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHtzdHJpbmc9fSBsYWJlbCBsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJwcm9maWxlRW5kXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gcHJvZmlsZUVuZChsYWJlbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0oTG9nVHlwZS5wcm9maWxlRW5kLCBbbGFiZWxdKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHtzdHJpbmd9IGxhYmVsIGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcInRpbWVcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiB0aW1lKGxhYmVsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLyoqIEB0eXBlIHtNYXA8c3RyaW5nIHwgdW5kZWZpbmVkLCBbbnVtYmVyLCBudW1iZXJdPn0gKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW1RJTUVSU19TWU1CT0xdID0gdGhpc1tUSU1FUlNfU1lNQk9MXSB8fCBuZXcgTWFwKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tUSU1FUlNfU1lNQk9MXS5zZXQobGFiZWwsIHByb2Nlc3MuaHJ0aW1lKCkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge3N0cmluZz19IGxhYmVsIGxhYmVsXG4gICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgICAgICAgICAga2V5OiBcInRpbWVMb2dcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiB0aW1lTG9nKGxhYmVsKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHByZXYgPSB0aGlzW1RJTUVSU19TWU1CT0xdICYmIHRoaXNbVElNRVJTX1NZTUJPTF0uZ2V0KGxhYmVsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIXByZXYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm8gc3VjaCBsYWJlbCAnXCIuY29uY2F0KGxhYmVsLCBcIicgZm9yIFdlYnBhY2tMb2dnZXIudGltZUxvZygpXCIpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHRpbWUgPSBwcm9jZXNzLmhydGltZShwcmV2KTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW0xPR19TWU1CT0xdKExvZ1R5cGUudGltZSwgW2xhYmVsXS5jb25jYXQoX3RvQ29uc3VtYWJsZUFycmF5KHRpbWUpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nPX0gbGFiZWwgbGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwidGltZUVuZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRpbWVFbmQobGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgcHJldiA9IHRoaXNbVElNRVJTX1NZTUJPTF0gJiYgdGhpc1tUSU1FUlNfU1lNQk9MXS5nZXQobGFiZWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghcHJldikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJObyBzdWNoIGxhYmVsICdcIi5jb25jYXQobGFiZWwsIFwiJyBmb3IgV2VicGFja0xvZ2dlci50aW1lRW5kKClcIikpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdGltZSA9IHByb2Nlc3MuaHJ0aW1lKHByZXYpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIC8qKiBAdHlwZSB7TWFwPHN0cmluZyB8IHVuZGVmaW5lZCwgW251bWJlciwgbnVtYmVyXT59ICovXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tUSU1FUlNfU1lNQk9MXS5kZWxldGUobGFiZWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRoaXNbTE9HX1NZTUJPTF0oTG9nVHlwZS50aW1lLCBbbGFiZWxdLmNvbmNhdChfdG9Db25zdW1hYmxlQXJyYXkodGltZSkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAgICAgICAgICogQHBhcmFtIHtzdHJpbmc9fSBsYWJlbCBsYWJlbFxuICAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGtleTogXCJ0aW1lQWdncmVnYXRlXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gdGltZUFnZ3JlZ2F0ZShsYWJlbCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBwcmV2ID0gdGhpc1tUSU1FUlNfU1lNQk9MXSAmJiB0aGlzW1RJTUVSU19TWU1CT0xdLmdldChsYWJlbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFwcmV2KSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihcIk5vIHN1Y2ggbGFiZWwgJ1wiLmNvbmNhdChsYWJlbCwgXCInIGZvciBXZWJwYWNrTG9nZ2VyLnRpbWVBZ2dyZWdhdGUoKVwiKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciB0aW1lID0gcHJvY2Vzcy5ocnRpbWUocHJldik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLyoqIEB0eXBlIHtNYXA8c3RyaW5nIHwgdW5kZWZpbmVkLCBbbnVtYmVyLCBudW1iZXJdPn0gKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW1RJTUVSU19TWU1CT0xdLmRlbGV0ZShsYWJlbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgLyoqIEB0eXBlIHtNYXA8c3RyaW5nIHwgdW5kZWZpbmVkLCBbbnVtYmVyLCBudW1iZXJdPn0gKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW1RJTUVSU19BR0dSRUdBVEVTX1NZTUJPTF0gPSB0aGlzW1RJTUVSU19BR0dSRUdBVEVTX1NZTUJPTF0gfHwgbmV3IE1hcCgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHZhciBjdXJyZW50ID0gdGhpc1tUSU1FUlNfQUdHUkVHQVRFU19TWU1CT0xdLmdldChsYWJlbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKGN1cnJlbnQgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGltZVsxXSArIGN1cnJlbnRbMV0gPiAxZTkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpbWVbMF0gKz0gY3VycmVudFswXSArIDE7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lWzFdID0gdGltZVsxXSAtIDFlOSArIGN1cnJlbnRbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lWzBdICs9IGN1cnJlbnRbMF07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aW1lWzFdICs9IGN1cnJlbnRbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpc1tUSU1FUlNfQUdHUkVHQVRFU19TWU1CT0xdLnNldChsYWJlbCwgdGltZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nPX0gbGFiZWwgbGFiZWxcbiAgICAgICAgICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBrZXk6IFwidGltZUFnZ3JlZ2F0ZUVuZFwiLFxuICAgICAgICAgICAgICAgICAgICAgICAgdmFsdWU6IGZ1bmN0aW9uIHRpbWVBZ2dyZWdhdGVFbmQobGFiZWwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodGhpc1tUSU1FUlNfQUdHUkVHQVRFU19TWU1CT0xdID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgdGltZSA9IHRoaXNbVElNRVJTX0FHR1JFR0FURVNfU1lNQk9MXS5nZXQobGFiZWwpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0aW1lID09PSB1bmRlZmluZWQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW1RJTUVSU19BR0dSRUdBVEVTX1NZTUJPTF0uZGVsZXRlKGxhYmVsKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzW0xPR19TWU1CT0xdKExvZ1R5cGUudGltZSwgW2xhYmVsXS5jb25jYXQoX3RvQ29uc3VtYWJsZUFycmF5KHRpbWUpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1dKTtcbiAgICAgICAgICAgIH0oKTtcbiAgICAgICAgICAgIG1vZHVsZS5leHBvcnRzLkxvZ2dlciA9IFdlYnBhY2tMb2dnZXI7XG4gICAgICAgICAgICAvKioqLyBcbiAgICAgICAgfSksXG4gICAgICAgIC8qKiovIFwiLi9ub2RlX21vZHVsZXMvd2VicGFjay9saWIvbG9nZ2luZy9jcmVhdGVDb25zb2xlTG9nZ2VyLmpzXCI6IFxuICAgICAgICAvKiEqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiEqXFxcbiAgICAgICAgICAhKioqIC4vbm9kZV9tb2R1bGVzL3dlYnBhY2svbGliL2xvZ2dpbmcvY3JlYXRlQ29uc29sZUxvZ2dlci5qcyAqKiohXG4gICAgICAgICAgXFwqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgICAgICAgLyoqKi8gKGZ1bmN0aW9uIChtb2R1bGUsIF9fdW51c2VkX3dlYnBhY2tfZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICBNSVQgTGljZW5zZSBodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocFxuICAgICAgICAgICAgICAgIEF1dGhvciBUb2JpYXMgS29wcGVycyBAc29rcmFcbiAgICAgICAgICAgICovXG4gICAgICAgICAgICBmdW5jdGlvbiBfc2xpY2VkVG9BcnJheShyLCBlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9hcnJheVdpdGhIb2xlcyhyKSB8fCBfaXRlcmFibGVUb0FycmF5TGltaXQociwgZSkgfHwgX3Vuc3VwcG9ydGVkSXRlcmFibGVUb0FycmF5KHIsIGUpIHx8IF9ub25JdGVyYWJsZVJlc3QoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF9ub25JdGVyYWJsZVJlc3QoKSB7XG4gICAgICAgICAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkludmFsaWQgYXR0ZW1wdCB0byBkZXN0cnVjdHVyZSBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF9pdGVyYWJsZVRvQXJyYXlMaW1pdChyLCBsKSB7XG4gICAgICAgICAgICAgICAgdmFyIHQgPSBudWxsID09IHIgPyBudWxsIDogXCJ1bmRlZmluZWRcIiAhPSB0eXBlb2YgKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkgJiYgclsodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiA/IFN5bWJvbCA6IGZ1bmN0aW9uIChpKSB7IHJldHVybiBpOyB9KS5pdGVyYXRvcl0gfHwgcltcIkBAaXRlcmF0b3JcIl07XG4gICAgICAgICAgICAgICAgaWYgKG51bGwgIT0gdCkge1xuICAgICAgICAgICAgICAgICAgICB2YXIgZSwgbiwgaSwgdSwgYSA9IFtdLCBmID0gITAsIG8gPSAhMTtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChpID0gKHQgPSB0LmNhbGwocikpLm5leHQsIDAgPT09IGwpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoT2JqZWN0KHQpICE9PSB0KVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZiA9ICExO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgZWxzZVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGZvciAoOyAhKGYgPSAoZSA9IGkuY2FsbCh0KSkuZG9uZSkgJiYgKGEucHVzaChlLnZhbHVlKSwgYS5sZW5ndGggIT09IGwpOyBmID0gITApXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIDtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBjYXRjaCAocikge1xuICAgICAgICAgICAgICAgICAgICAgICAgbyA9ICEwLCBuID0gcjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFmICYmIG51bGwgIT0gdC5yZXR1cm4gJiYgKHUgPSB0LnJldHVybigpLCBPYmplY3QodSkgIT09IHUpKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBmaW5hbGx5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAobylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhyb3cgbjtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gYTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmdW5jdGlvbiBfYXJyYXlXaXRoSG9sZXMocikge1xuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHIpKVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF90b0NvbnN1bWFibGVBcnJheShyKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIF9hcnJheVdpdGhvdXRIb2xlcyhyKSB8fCBfaXRlcmFibGVUb0FycmF5KHIpIHx8IF91bnN1cHBvcnRlZEl0ZXJhYmxlVG9BcnJheShyKSB8fCBfbm9uSXRlcmFibGVTcHJlYWQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF9ub25JdGVyYWJsZVNwcmVhZCgpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiSW52YWxpZCBhdHRlbXB0IHRvIHNwcmVhZCBub24taXRlcmFibGUgaW5zdGFuY2UuXFxuSW4gb3JkZXIgdG8gYmUgaXRlcmFibGUsIG5vbi1hcnJheSBvYmplY3RzIG11c3QgaGF2ZSBhIFtTeW1ib2wuaXRlcmF0b3JdKCkgbWV0aG9kLlwiKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF91bnN1cHBvcnRlZEl0ZXJhYmxlVG9BcnJheShyLCBhKSB7XG4gICAgICAgICAgICAgICAgaWYgKHIpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKFwic3RyaW5nXCIgPT0gdHlwZW9mIHIpXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gX2FycmF5TGlrZVRvQXJyYXkociwgYSk7XG4gICAgICAgICAgICAgICAgICAgIHZhciB0ID0ge30udG9TdHJpbmcuY2FsbChyKS5zbGljZSg4LCAtMSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBcIk9iamVjdFwiID09PSB0ICYmIHIuY29uc3RydWN0b3IgJiYgKHQgPSByLmNvbnN0cnVjdG9yLm5hbWUpLCBcIk1hcFwiID09PSB0IHx8IFwiU2V0XCIgPT09IHQgPyBBcnJheS5mcm9tKHIpIDogXCJBcmd1bWVudHNcIiA9PT0gdCB8fCAvXig/OlVpfEkpbnQoPzo4fDE2fDMyKSg/OkNsYW1wZWQpP0FycmF5JC8udGVzdCh0KSA/IF9hcnJheUxpa2VUb0FycmF5KHIsIGEpIDogdm9pZCAwO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF9pdGVyYWJsZVRvQXJyYXkocikge1xuICAgICAgICAgICAgICAgIGlmIChcInVuZGVmaW5lZFwiICE9IHR5cGVvZiAodHlwZW9mIFN5bWJvbCAhPT0gXCJ1bmRlZmluZWRcIiA/IFN5bWJvbCA6IGZ1bmN0aW9uIChpKSB7IHJldHVybiBpOyB9KSAmJiBudWxsICE9IHJbKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkuaXRlcmF0b3JdIHx8IG51bGwgIT0gcltcIkBAaXRlcmF0b3JcIl0pXG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBBcnJheS5mcm9tKHIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX2FycmF5V2l0aG91dEhvbGVzKHIpIHtcbiAgICAgICAgICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShyKSlcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIF9hcnJheUxpa2VUb0FycmF5KHIpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZnVuY3Rpb24gX2FycmF5TGlrZVRvQXJyYXkociwgYSkge1xuICAgICAgICAgICAgICAgIChudWxsID09IGEgfHwgYSA+IHIubGVuZ3RoKSAmJiAoYSA9IHIubGVuZ3RoKTtcbiAgICAgICAgICAgICAgICBmb3IgKHZhciBlID0gMCwgbiA9IEFycmF5KGEpOyBlIDwgYTsgZSsrKVxuICAgICAgICAgICAgICAgICAgICBuW2VdID0gcltlXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZ1bmN0aW9uIF90eXBlb2Yobykge1xuICAgICAgICAgICAgICAgIFwiQGJhYmVsL2hlbHBlcnMgLSB0eXBlb2ZcIjtcbiAgICAgICAgICAgICAgICByZXR1cm4gX3R5cGVvZiA9IFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkgJiYgXCJzeW1ib2xcIiA9PSB0eXBlb2YgKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHlwZW9mIG87XG4gICAgICAgICAgICAgICAgfSA6IGZ1bmN0aW9uIChvKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBvICYmIFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkgJiYgby5jb25zdHJ1Y3RvciA9PT0gKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkgJiYgbyAhPT0gKHR5cGVvZiBTeW1ib2wgIT09IFwidW5kZWZpbmVkXCIgPyBTeW1ib2wgOiBmdW5jdGlvbiAoaSkgeyByZXR1cm4gaTsgfSkucHJvdG90eXBlID8gXCJzeW1ib2xcIiA6IHR5cGVvZiBvO1xuICAgICAgICAgICAgICAgIH0sIF90eXBlb2Yobyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgX3JlcXVpcmUgPSBfX3dlYnBhY2tfcmVxdWlyZV9fKC8qISAuL0xvZ2dlciAqLyBcIi4vbm9kZV9tb2R1bGVzL3dlYnBhY2svbGliL2xvZ2dpbmcvTG9nZ2VyLmpzXCIpLCBMb2dUeXBlID0gX3JlcXVpcmUuTG9nVHlwZTtcbiAgICAgICAgICAgIC8qKiBAdHlwZWRlZiB7aW1wb3J0KFwiLi4vLi4vZGVjbGFyYXRpb25zL1dlYnBhY2tPcHRpb25zXCIpLkZpbHRlckl0ZW1UeXBlc30gRmlsdGVySXRlbVR5cGVzICovXG4gICAgICAgICAgICAvKiogQHR5cGVkZWYge2ltcG9ydChcIi4uLy4uL2RlY2xhcmF0aW9ucy9XZWJwYWNrT3B0aW9uc1wiKS5GaWx0ZXJUeXBlc30gRmlsdGVyVHlwZXMgKi9cbiAgICAgICAgICAgIC8qKiBAdHlwZWRlZiB7aW1wb3J0KFwiLi9Mb2dnZXJcIikuTG9nVHlwZUVudW19IExvZ1R5cGVFbnVtICovXG4gICAgICAgICAgICAvKiogQHR5cGVkZWYgeyhpdGVtOiBzdHJpbmcpID0+IGJvb2xlYW59IEZpbHRlckZ1bmN0aW9uICovXG4gICAgICAgICAgICAvKiogQHR5cGVkZWYgeyh2YWx1ZTogc3RyaW5nLCB0eXBlOiBMb2dUeXBlRW51bSwgYXJncz86IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkfSBMb2dnaW5nRnVuY3Rpb24gKi9cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQHR5cGVkZWYge29iamVjdH0gTG9nZ2VyQ29uc29sZVxuICAgICAgICAgICAgICogQHByb3BlcnR5IHsoKSA9PiB2b2lkfSBjbGVhclxuICAgICAgICAgICAgICogQHByb3BlcnR5IHsoKSA9PiB2b2lkfSB0cmFjZVxuICAgICAgICAgICAgICogQHByb3BlcnR5IHsoLi4uYXJnczogRVhQRUNURURfQU5ZW10pID0+IHZvaWR9IGluZm9cbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkfSBsb2dcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkfSB3YXJuXG4gICAgICAgICAgICAgKiBAcHJvcGVydHkgeyguLi5hcmdzOiBFWFBFQ1RFRF9BTllbXSkgPT4gdm9pZH0gZXJyb3JcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkPX0gZGVidWdcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkPX0gZ3JvdXBcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkPX0gZ3JvdXBDb2xsYXBzZWRcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkPX0gZ3JvdXBFbmRcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkPX0gc3RhdHVzXG4gICAgICAgICAgICAgKiBAcHJvcGVydHkgeyguLi5hcmdzOiBFWFBFQ1RFRF9BTllbXSkgPT4gdm9pZD19IHByb2ZpbGVcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7KC4uLmFyZ3M6IEVYUEVDVEVEX0FOWVtdKSA9PiB2b2lkPX0gcHJvZmlsZUVuZFxuICAgICAgICAgICAgICogQHByb3BlcnR5IHsoLi4uYXJnczogRVhQRUNURURfQU5ZW10pID0+IHZvaWQ9fSBsb2dUaW1lXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQHR5cGVkZWYge29iamVjdH0gTG9nZ2VyT3B0aW9uc1xuICAgICAgICAgICAgICogQHByb3BlcnR5IHtmYWxzZXx0cnVlfFwibm9uZVwifFwiZXJyb3JcInxcIndhcm5cInxcImluZm9cInxcImxvZ1wifFwidmVyYm9zZVwifSBsZXZlbCBsb2dsZXZlbFxuICAgICAgICAgICAgICogQHByb3BlcnR5IHtGaWx0ZXJUeXBlc3xib29sZWFufSBkZWJ1ZyBmaWx0ZXIgZm9yIGRlYnVnIGxvZ2dpbmdcbiAgICAgICAgICAgICAqIEBwcm9wZXJ0eSB7TG9nZ2VyQ29uc29sZX0gY29uc29sZSB0aGUgY29uc29sZSB0byBsb2cgdG9cbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBAcGFyYW0ge0ZpbHRlckl0ZW1UeXBlc30gaXRlbSBhbiBpbnB1dCBpdGVtXG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7RmlsdGVyRnVuY3Rpb24gfCB1bmRlZmluZWR9IGZpbHRlciBmdW5jdGlvblxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICB2YXIgZmlsdGVyVG9GdW5jdGlvbiA9IGZ1bmN0aW9uIGZpbHRlclRvRnVuY3Rpb24oaXRlbSkge1xuICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlbSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICAgICAgICAgICAgICB2YXIgcmVnRXhwID0gbmV3IFJlZ0V4cChcIltcXFxcXFxcXC9dXCIuY29uY2F0KGl0ZW0ucmVwbGFjZSgvWy1bXFxde30oKSorPy5cXFxcXiR8XS9nLCBcIlxcXFwkJlwiKSwgXCIoW1xcXFxcXFxcL118JHwhfFxcXFw/KVwiKSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoaWRlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiByZWdFeHAudGVzdChpZGVudCk7XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChpdGVtICYmIF90eXBlb2YoaXRlbSkgPT09IFwib2JqZWN0XCIgJiYgdHlwZW9mIGl0ZW0udGVzdCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmdW5jdGlvbiAoaWRlbnQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBpdGVtLnRlc3QoaWRlbnQpO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGl0ZW0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gaXRlbTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVtID09PSBcImJvb2xlYW5cIikge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGl0ZW07XG4gICAgICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQGVudW0ge251bWJlcn1cbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgdmFyIExvZ0xldmVsID0ge1xuICAgICAgICAgICAgICAgIG5vbmU6IDYsXG4gICAgICAgICAgICAgICAgZmFsc2U6IDYsXG4gICAgICAgICAgICAgICAgZXJyb3I6IDUsXG4gICAgICAgICAgICAgICAgd2FybjogNCxcbiAgICAgICAgICAgICAgICBpbmZvOiAzLFxuICAgICAgICAgICAgICAgIGxvZzogMixcbiAgICAgICAgICAgICAgICB0cnVlOiAyLFxuICAgICAgICAgICAgICAgIHZlcmJvc2U6IDFcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEBwYXJhbSB7TG9nZ2VyT3B0aW9uc30gb3B0aW9ucyBvcHRpb25zIG9iamVjdFxuICAgICAgICAgICAgICogQHJldHVybnMge0xvZ2dpbmdGdW5jdGlvbn0gbG9nZ2luZyBmdW5jdGlvblxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBtb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChfcmVmKSB7XG4gICAgICAgICAgICAgICAgdmFyIF9yZWYkbGV2ZWwgPSBfcmVmLmxldmVsLCBsZXZlbCA9IF9yZWYkbGV2ZWwgPT09IHZvaWQgMCA/IFwiaW5mb1wiIDogX3JlZiRsZXZlbCwgX3JlZiRkZWJ1ZyA9IF9yZWYuZGVidWcsIGRlYnVnID0gX3JlZiRkZWJ1ZyA9PT0gdm9pZCAwID8gZmFsc2UgOiBfcmVmJGRlYnVnLCBjb25zb2xlID0gX3JlZi5jb25zb2xlO1xuICAgICAgICAgICAgICAgIHZhciBkZWJ1Z0ZpbHRlcnMgPSAvKiogQHR5cGUge0ZpbHRlckZ1bmN0aW9uW119ICovIHR5cGVvZiBkZWJ1ZyA9PT0gXCJib29sZWFuXCIgPyBbZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGRlYnVnO1xuICAgICAgICAgICAgICAgICAgICB9XSA6IC8qKiBAdHlwZSB7RmlsdGVySXRlbVR5cGVzW119ICovIFtdLmNvbmNhdChkZWJ1ZykubWFwKGZpbHRlclRvRnVuY3Rpb24pO1xuICAgICAgICAgICAgICAgIHZhciBsb2dsZXZlbCA9IExvZ0xldmVsW1wiXCIuY29uY2F0KGxldmVsKV0gfHwgMDtcbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZSBuYW1lIG9mIHRoZSBsb2dnZXJcbiAgICAgICAgICAgICAgICAgKiBAcGFyYW0ge0xvZ1R5cGVFbnVtfSB0eXBlIHR5cGUgb2YgdGhlIGxvZyBlbnRyeVxuICAgICAgICAgICAgICAgICAqIEBwYXJhbSB7RVhQRUNURURfQU5ZW109fSBhcmdzIGFyZ3VtZW50cyBvZiB0aGUgbG9nIGVudHJ5XG4gICAgICAgICAgICAgICAgICogQHJldHVybnMge3ZvaWR9XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgdmFyIGxvZ2dlciA9IGZ1bmN0aW9uIGxvZ2dlcihuYW1lLCB0eXBlLCBhcmdzKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBsYWJlbGVkQXJncyA9IGZ1bmN0aW9uIGxhYmVsZWRBcmdzKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoYXJncykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoYXJncy5sZW5ndGggPiAwICYmIHR5cGVvZiBhcmdzWzBdID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbXCJbXCIuY29uY2F0KG5hbWUsIFwiXSBcIikuY29uY2F0KGFyZ3NbMF0pXS5jb25jYXQoX3RvQ29uc3VtYWJsZUFycmF5KGFyZ3Muc2xpY2UoMSkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtcIltcIi5jb25jYXQobmFtZSwgXCJdXCIpXS5jb25jYXQoX3RvQ29uc3VtYWJsZUFycmF5KGFyZ3MpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBbXTtcbiAgICAgICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGRlYnVnID0gZGVidWdGaWx0ZXJzLnNvbWUoZnVuY3Rpb24gKGYpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBmKG5hbWUpO1xuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAgICAgc3dpdGNoICh0eXBlKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIExvZ1R5cGUuZGVidWc6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFkZWJ1ZylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29uc29sZS5kZWJ1ZyA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZGVidWcuYXBwbHkoY29uc29sZSwgX3RvQ29uc3VtYWJsZUFycmF5KGxhYmVsZWRBcmdzKCkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nLmFwcGx5KGNvbnNvbGUsIF90b0NvbnN1bWFibGVBcnJheShsYWJlbGVkQXJncygpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLmxvZzpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYnVnICYmIGxvZ2xldmVsID4gTG9nTGV2ZWwubG9nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cuYXBwbHkoY29uc29sZSwgX3RvQ29uc3VtYWJsZUFycmF5KGxhYmVsZWRBcmdzKCkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgTG9nVHlwZS5pbmZvOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZGVidWcgJiYgbG9nbGV2ZWwgPiBMb2dMZXZlbC5pbmZvKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5pbmZvLmFwcGx5KGNvbnNvbGUsIF90b0NvbnN1bWFibGVBcnJheShsYWJlbGVkQXJncygpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIExvZ1R5cGUud2FybjpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYnVnICYmIGxvZ2xldmVsID4gTG9nTGV2ZWwud2FybilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUud2Fybi5hcHBseShjb25zb2xlLCBfdG9Db25zdW1hYmxlQXJyYXkobGFiZWxlZEFyZ3MoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLmVycm9yOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZGVidWcgJiYgbG9nbGV2ZWwgPiBMb2dMZXZlbC5lcnJvcilcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IuYXBwbHkoY29uc29sZSwgX3RvQ29uc3VtYWJsZUFycmF5KGxhYmVsZWRBcmdzKCkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgTG9nVHlwZS50cmFjZTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYnVnKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS50cmFjZSgpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLmdyb3VwQ29sbGFwc2VkOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZGVidWcgJiYgbG9nbGV2ZWwgPiBMb2dMZXZlbC5sb2cpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYnVnICYmIGxvZ2xldmVsID4gTG9nTGV2ZWwudmVyYm9zZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5ncm91cENvbGxhcHNlZC5hcHBseShjb25zb2xlLCBfdG9Db25zdW1hYmxlQXJyYXkobGFiZWxlZEFyZ3MoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cuYXBwbHkoY29uc29sZSwgX3RvQ29uc3VtYWJsZUFycmF5KGxhYmVsZWRBcmdzKCkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBmYWxscyB0aHJvdWdoXG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIExvZ1R5cGUuZ3JvdXA6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaWYgKCFkZWJ1ZyAmJiBsb2dsZXZlbCA+IExvZ0xldmVsLmxvZylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29uc29sZS5ncm91cCA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuZ3JvdXAuYXBwbHkoY29uc29sZSwgX3RvQ29uc3VtYWJsZUFycmF5KGxhYmVsZWRBcmdzKCkpKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nLmFwcGx5KGNvbnNvbGUsIF90b0NvbnN1bWFibGVBcnJheShsYWJlbGVkQXJncygpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLmdyb3VwRW5kOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZGVidWcgJiYgbG9nbGV2ZWwgPiBMb2dMZXZlbC5sb2cpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUuZ3JvdXBFbmQgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmdyb3VwRW5kKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLnRpbWU6XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYnVnICYmIGxvZ2xldmVsID4gTG9nTGV2ZWwubG9nKVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgX2FyZ3MgPSBfc2xpY2VkVG9BcnJheSgvKiogQHR5cGUge1tzdHJpbmcsIG51bWJlciwgbnVtYmVyXX0gKi8gYXJncywgMyksIGxhYmVsID0gX2FyZ3NbMF0sIHN0YXJ0ID0gX2FyZ3NbMV0sIGVuZCA9IF9hcmdzWzJdO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbXMgPSBzdGFydCAqIDEwMDAgKyBlbmQgLyAxMDAwMDAwO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB2YXIgbXNnID0gXCJbXCIuY29uY2F0KG5hbWUsIFwiXSBcIikuY29uY2F0KGxhYmVsLCBcIjogXCIpLmNvbmNhdChtcywgXCIgbXNcIik7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29uc29sZS5sb2dUaW1lID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUubG9nVGltZShtc2cpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5sb2cobXNnKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICBjYXNlIExvZ1R5cGUucHJvZmlsZTpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUucHJvZmlsZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUucHJvZmlsZS5hcHBseShjb25zb2xlLCBfdG9Db25zdW1hYmxlQXJyYXkobGFiZWxlZEFyZ3MoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhc2UgTG9nVHlwZS5wcm9maWxlRW5kOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29uc29sZS5wcm9maWxlRW5kID09PSBcImZ1bmN0aW9uXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5wcm9maWxlRW5kLmFwcGx5KGNvbnNvbGUsIF90b0NvbnN1bWFibGVBcnJheShsYWJlbGVkQXJncygpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLmNsZWFyOlxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICghZGVidWcgJiYgbG9nbGV2ZWwgPiBMb2dMZXZlbC5sb2cpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNvbnNvbGUuY2xlYXIgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLmNsZWFyKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgY2FzZSBMb2dUeXBlLnN0YXR1czpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWRlYnVnICYmIGxvZ2xldmVsID4gTG9nTGV2ZWwuaW5mbylcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgY29uc29sZS5zdGF0dXMgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoIWFyZ3MgfHwgYXJncy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnNvbGUuc3RhdHVzKCk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zb2xlLnN0YXR1cy5hcHBseShjb25zb2xlLCBfdG9Db25zdW1hYmxlQXJyYXkobGFiZWxlZEFyZ3MoKSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGFyZ3MgJiYgYXJncy5sZW5ndGggIT09IDApIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc29sZS5pbmZvLmFwcGx5KGNvbnNvbGUsIF90b0NvbnN1bWFibGVBcnJheShsYWJlbGVkQXJncygpKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJVbmV4cGVjdGVkIExvZ1R5cGUgXCIuY29uY2F0KHR5cGUpKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH07XG4gICAgICAgICAgICAgICAgcmV0dXJuIGxvZ2dlcjtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICAvKioqLyBcbiAgICAgICAgfSksXG4gICAgICAgIC8qKiovIFwiLi9ub2RlX21vZHVsZXMvd2VicGFjay9saWIvbG9nZ2luZy9ydW50aW1lLmpzXCI6IFxuICAgICAgICAvKiEqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiEqXFxcbiAgICAgICAgICAhKioqIC4vbm9kZV9tb2R1bGVzL3dlYnBhY2svbGliL2xvZ2dpbmcvcnVudGltZS5qcyAqKiohXG4gICAgICAgICAgXFwqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKi9cbiAgICAgICAgLyoqKi8gKGZ1bmN0aW9uIChtb2R1bGUsIF9fdW51c2VkX3dlYnBhY2tfZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXykge1xuICAgICAgICAgICAgLypcbiAgICAgICAgICAgICAgICBNSVQgTGljZW5zZSBodHRwOi8vd3d3Lm9wZW5zb3VyY2Uub3JnL2xpY2Vuc2VzL21pdC1saWNlbnNlLnBocFxuICAgICAgICAgICAgICAgIEF1dGhvciBUb2JpYXMgS29wcGVycyBAc29rcmFcbiAgICAgICAgICAgICovXG4gICAgICAgICAgICBmdW5jdGlvbiBfZXh0ZW5kcygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduID8gT2JqZWN0LmFzc2lnbi5iaW5kKCkgOiBmdW5jdGlvbiAobikge1xuICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciBlID0gMTsgZSA8IGFyZ3VtZW50cy5sZW5ndGg7IGUrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIHQgPSBhcmd1bWVudHNbZV07XG4gICAgICAgICAgICAgICAgICAgICAgICBmb3IgKHZhciByIGluIHQpXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgKHt9KS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHQsIHIpICYmIChuW3JdID0gdFtyXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG47XG4gICAgICAgICAgICAgICAgfSwgX2V4dGVuZHMuYXBwbHkobnVsbCwgYXJndW1lbnRzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHZhciBfcmVxdWlyZSA9IF9fd2VicGFja19yZXF1aXJlX18oLyohIHRhcGFibGUgKi8gXCIuL2NsaWVudC1zcmMvbW9kdWxlcy9sb2dnZXIvdGFwYWJsZS5qc1wiKSwgU3luY0JhaWxIb29rID0gX3JlcXVpcmUuU3luY0JhaWxIb29rO1xuICAgICAgICAgICAgdmFyIF9yZXF1aXJlMiA9IF9fd2VicGFja19yZXF1aXJlX18oLyohIC4vTG9nZ2VyICovIFwiLi9ub2RlX21vZHVsZXMvd2VicGFjay9saWIvbG9nZ2luZy9Mb2dnZXIuanNcIiksIExvZ2dlciA9IF9yZXF1aXJlMi5Mb2dnZXI7XG4gICAgICAgICAgICB2YXIgY3JlYXRlQ29uc29sZUxvZ2dlciA9IF9fd2VicGFja19yZXF1aXJlX18oLyohIC4vY3JlYXRlQ29uc29sZUxvZ2dlciAqLyBcIi4vbm9kZV9tb2R1bGVzL3dlYnBhY2svbGliL2xvZ2dpbmcvY3JlYXRlQ29uc29sZUxvZ2dlci5qc1wiKTtcbiAgICAgICAgICAgIC8qKiBAdHlwZSB7Y3JlYXRlQ29uc29sZUxvZ2dlci5Mb2dnZXJPcHRpb25zfSAqL1xuICAgICAgICAgICAgdmFyIGN1cnJlbnREZWZhdWx0TG9nZ2VyT3B0aW9ucyA9IHtcbiAgICAgICAgICAgICAgICBsZXZlbDogXCJpbmZvXCIsXG4gICAgICAgICAgICAgICAgZGVidWc6IGZhbHNlLFxuICAgICAgICAgICAgICAgIGNvbnNvbGU6IGNvbnNvbGVcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICB2YXIgY3VycmVudERlZmF1bHRMb2dnZXIgPSBjcmVhdGVDb25zb2xlTG9nZ2VyKGN1cnJlbnREZWZhdWx0TG9nZ2VyT3B0aW9ucyk7XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEBwYXJhbSB7c3RyaW5nfSBuYW1lIG5hbWUgb2YgdGhlIGxvZ2dlclxuICAgICAgICAgICAgICogQHJldHVybnMge0xvZ2dlcn0gYSBsb2dnZXJcbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgbW9kdWxlLmV4cG9ydHMuZ2V0TG9nZ2VyID0gZnVuY3Rpb24gKG5hbWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gbmV3IExvZ2dlcihmdW5jdGlvbiAodHlwZSwgYXJncykge1xuICAgICAgICAgICAgICAgICAgICBpZiAobW9kdWxlLmV4cG9ydHMuaG9va3MubG9nLmNhbGwobmFtZSwgdHlwZSwgYXJncykgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgY3VycmVudERlZmF1bHRMb2dnZXIobmFtZSwgdHlwZSwgYXJncyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9LCBmdW5jdGlvbiAoY2hpbGROYW1lKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBtb2R1bGUuZXhwb3J0cy5nZXRMb2dnZXIoXCJcIi5jb25jYXQobmFtZSwgXCIvXCIpLmNvbmNhdChjaGlsZE5hbWUpKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEBwYXJhbSB7Y3JlYXRlQ29uc29sZUxvZ2dlci5Mb2dnZXJPcHRpb25zfSBvcHRpb25zIG5ldyBvcHRpb25zLCBtZXJnZSB3aXRoIG9sZCBvcHRpb25zXG4gICAgICAgICAgICAgKiBAcmV0dXJucyB7dm9pZH1cbiAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgbW9kdWxlLmV4cG9ydHMuY29uZmlndXJlRGVmYXVsdExvZ2dlciA9IGZ1bmN0aW9uIChvcHRpb25zKSB7XG4gICAgICAgICAgICAgICAgX2V4dGVuZHMoY3VycmVudERlZmF1bHRMb2dnZXJPcHRpb25zLCBvcHRpb25zKTtcbiAgICAgICAgICAgICAgICBjdXJyZW50RGVmYXVsdExvZ2dlciA9IGNyZWF0ZUNvbnNvbGVMb2dnZXIoY3VycmVudERlZmF1bHRMb2dnZXJPcHRpb25zKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgICBtb2R1bGUuZXhwb3J0cy5ob29rcyA9IHtcbiAgICAgICAgICAgICAgICBsb2c6IG5ldyBTeW5jQmFpbEhvb2soW1wib3JpZ2luXCIsIFwidHlwZVwiLCBcImFyZ3NcIl0pXG4gICAgICAgICAgICB9O1xuICAgICAgICAgICAgLyoqKi8gXG4gICAgICAgIH0pXG4gICAgICAgIC8qKioqKiovIFxuICAgIH0pO1xuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgLyoqKioqKi8gLy8gVGhlIG1vZHVsZSBjYWNoZVxuICAgIC8qKioqKiovIHZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcbiAgICAvKioqKioqL1xuICAgIC8qKioqKiovIC8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG4gICAgLyoqKioqKi8gZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuICAgICAgICAvKioqKioqLyAvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiAgICAgICAgLyoqKioqKi8gdmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG4gICAgICAgIC8qKioqKiovIGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgLyoqKioqKi8gcmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuICAgICAgICAgICAgLyoqKioqKi8gfVxuICAgICAgICAvKioqKioqLyAvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuICAgICAgICAvKioqKioqLyB2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcbiAgICAgICAgICAgIC8qKioqKiovIC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcbiAgICAgICAgICAgIC8qKioqKiovIC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG4gICAgICAgICAgICAvKioqKioqLyBleHBvcnRzOiB7fVxuICAgICAgICAgICAgLyoqKioqKi8gXG4gICAgICAgIH07XG4gICAgICAgIC8qKioqKiovXG4gICAgICAgIC8qKioqKiovIC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuICAgICAgICAvKioqKioqLyBfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXShtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiAgICAgICAgLyoqKioqKi9cbiAgICAgICAgLyoqKioqKi8gLy8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcbiAgICAgICAgLyoqKioqKi8gcmV0dXJuIG1vZHVsZS5leHBvcnRzO1xuICAgICAgICAvKioqKioqLyBcbiAgICB9XG4gICAgLyoqKioqKi9cbiAgICAvKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqL1xuICAgIC8qKioqKiovIC8qIHdlYnBhY2svcnVudGltZS9kZWZpbmUgcHJvcGVydHkgZ2V0dGVycyAqL1xuICAgIC8qKioqKiovICFmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8qKioqKiovIC8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbiAgICAgICAgLyoqKioqKi8gX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gZnVuY3Rpb24gKGV4cG9ydHMsIGRlZmluaXRpb24pIHtcbiAgICAgICAgICAgIC8qKioqKiovIGZvciAodmFyIGtleSBpbiBkZWZpbml0aW9uKSB7XG4gICAgICAgICAgICAgICAgLyoqKioqKi8gaWYgKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuICAgICAgICAgICAgICAgICAgICAvKioqKioqLyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywga2V5LCB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZGVmaW5pdGlvbltrZXldIH0pO1xuICAgICAgICAgICAgICAgICAgICAvKioqKioqLyB9XG4gICAgICAgICAgICAgICAgLyoqKioqKi8gfVxuICAgICAgICAgICAgLyoqKioqKi8gXG4gICAgICAgIH07XG4gICAgICAgIC8qKioqKiovIFxuICAgIH0oKTtcbiAgICAvKioqKioqL1xuICAgIC8qKioqKiovIC8qIHdlYnBhY2svcnVudGltZS9oYXNPd25Qcm9wZXJ0eSBzaG9ydGhhbmQgKi9cbiAgICAvKioqKioqLyAhZnVuY3Rpb24gKCkge1xuICAgICAgICAvKioqKioqLyBfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbiAob2JqLCBwcm9wKSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKTsgfTtcbiAgICAgICAgLyoqKioqKi8gXG4gICAgfSgpO1xuICAgIC8qKioqKiovXG4gICAgLyoqKioqKi8gLyogd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCAqL1xuICAgIC8qKioqKiovICFmdW5jdGlvbiAoKSB7XG4gICAgICAgIC8qKioqKiovIC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiAgICAgICAgLyoqKioqKi8gX193ZWJwYWNrX3JlcXVpcmVfXy5yID0gZnVuY3Rpb24gKGV4cG9ydHMpIHtcbiAgICAgICAgICAgIC8qKioqKiovIGlmICh0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcbiAgICAgICAgICAgICAgICAvKioqKioqLyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcbiAgICAgICAgICAgICAgICAvKioqKioqLyB9XG4gICAgICAgICAgICAvKioqKioqLyBPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xuICAgICAgICAgICAgLyoqKioqKi8gXG4gICAgICAgIH07XG4gICAgICAgIC8qKioqKiovIFxuICAgIH0oKTtcbiAgICAvKioqKioqL1xuICAgIC8qKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgdmFyIF9fd2VicGFja19leHBvcnRzX18gPSB7fTtcbiAgICAvLyBUaGlzIGVudHJ5IG5lZWRzIHRvIGJlIHdyYXBwZWQgaW4gYW4gSUlGRSBiZWNhdXNlIGl0IG5lZWRzIHRvIGJlIGlzb2xhdGVkIGFnYWluc3Qgb3RoZXIgbW9kdWxlcyBpbiB0aGUgY2h1bmsuXG4gICAgIWZ1bmN0aW9uICgpIHtcbiAgICAgICAgLyohKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiohKlxcXG4gICAgICAgICAgISoqKiAuL2NsaWVudC1zcmMvbW9kdWxlcy9sb2dnZXIvaW5kZXguanMgKioqIVxuICAgICAgICAgIFxcKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKioqKiovXG4gICAgICAgIF9fd2VicGFja19yZXF1aXJlX18ucihfX3dlYnBhY2tfZXhwb3J0c19fKTtcbiAgICAgICAgLyogaGFybW9ueSBleHBvcnQgKi8gX193ZWJwYWNrX3JlcXVpcmVfXy5kKF9fd2VicGFja19leHBvcnRzX18sIHtcbiAgICAgICAgICAgIC8qIGhhcm1vbnkgZXhwb3J0ICovIFwiZGVmYXVsdFwiOiBmdW5jdGlvbiAoKSB7IHJldHVybiAvKiByZWV4cG9ydCBkZWZhdWx0IGV4cG9ydCBmcm9tIG5hbWVkIG1vZHVsZSAqLyB3ZWJwYWNrX2xpYl9sb2dnaW5nX3J1bnRpbWVfanNfX1dFQlBBQ0tfSU1QT1JURURfTU9EVUxFXzBfXzsgfVxuICAgICAgICAgICAgLyogaGFybW9ueSBleHBvcnQgKi8gXG4gICAgICAgIH0pO1xuICAgICAgICAvKiBoYXJtb255IGltcG9ydCAqLyB2YXIgd2VicGFja19saWJfbG9nZ2luZ19ydW50aW1lX2pzX19XRUJQQUNLX0lNUE9SVEVEX01PRFVMRV8wX18gPSBfX3dlYnBhY2tfcmVxdWlyZV9fKC8qISB3ZWJwYWNrL2xpYi9sb2dnaW5nL3J1bnRpbWUuanMgKi8gXCIuL25vZGVfbW9kdWxlcy93ZWJwYWNrL2xpYi9sb2dnaW5nL3J1bnRpbWUuanNcIik7XG4gICAgfSgpO1xuICAgIHZhciBfX3dlYnBhY2tfZXhwb3J0X3RhcmdldF9fID0gZXhwb3J0cztcbiAgICBmb3IgKHZhciBfX3dlYnBhY2tfaV9fIGluIF9fd2VicGFja19leHBvcnRzX18pXG4gICAgICAgIF9fd2VicGFja19leHBvcnRfdGFyZ2V0X19bX193ZWJwYWNrX2lfX10gPSBfX3dlYnBhY2tfZXhwb3J0c19fW19fd2VicGFja19pX19dO1xuICAgIGlmIChfX3dlYnBhY2tfZXhwb3J0c19fLl9fZXNNb2R1bGUpXG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShfX3dlYnBhY2tfZXhwb3J0X3RhcmdldF9fLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbiAgICAvKioqKioqLyBcbn0pKCk7XG4iLCJmdW5jdGlvbiBfdHlwZW9mKG8pIHtcbiAgICBcIkBiYWJlbC9oZWxwZXJzIC0gdHlwZW9mXCI7XG4gICAgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykgeyByZXR1cm4gdHlwZW9mIG87IH0gOiBmdW5jdGlvbiAobykgeyByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbzsgfSwgX3R5cGVvZihvKTtcbn1cbmZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgIHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTtcbiAgICByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7XG59IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHtcbiAgICB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307XG4gICAgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTtcbn0gcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0KSB7IHJldHVybiAociA9IF90b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHsgdmFsdWU6IHQsIGVudW1lcmFibGU6ICEwLCBjb25maWd1cmFibGU6ICEwLCB3cml0YWJsZTogITAgfSkgOiBlW3JdID0gdCwgZTsgfVxuZnVuY3Rpb24gX3RvUHJvcGVydHlLZXkodCkgeyB2YXIgaSA9IF90b1ByaW1pdGl2ZSh0LCBcInN0cmluZ1wiKTsgcmV0dXJuIFwic3ltYm9sXCIgPT0gX3R5cGVvZihpKSA/IGkgOiBpICsgXCJcIjsgfVxuZnVuY3Rpb24gX3RvUHJpbWl0aXZlKHQsIHIpIHsgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZih0KSB8fCAhdClcbiAgICByZXR1cm4gdDsgdmFyIGUgPSB0W1N5bWJvbC50b1ByaW1pdGl2ZV07IGlmICh2b2lkIDAgIT09IGUpIHtcbiAgICB2YXIgaSA9IGUuY2FsbCh0LCByIHx8IFwiZGVmYXVsdFwiKTtcbiAgICBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKGkpKVxuICAgICAgICByZXR1cm4gaTtcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQEB0b1ByaW1pdGl2ZSBtdXN0IHJldHVybiBhIHByaW1pdGl2ZSB2YWx1ZS5cIik7XG59IHJldHVybiAoXCJzdHJpbmdcIiA9PT0gciA/IFN0cmluZyA6IE51bWJlcikodCk7IH1cbi8vIFRoZSBlcnJvciBvdmVybGF5IGlzIGluc3BpcmVkIChhbmQgbW9zdGx5IGNvcGllZCkgZnJvbSBDcmVhdGUgUmVhY3QgQXBwIChodHRwczovL2dpdGh1Yi5jb20vZmFjZWJvb2tpbmN1YmF0b3IvY3JlYXRlLXJlYWN0LWFwcClcbi8vIFRoZXksIGluIHR1cm4sIGdvdCBpbnNwaXJlZCBieSB3ZWJwYWNrLWhvdC1taWRkbGV3YXJlIChodHRwczovL2dpdGh1Yi5jb20vZ2xlbmphbWluL3dlYnBhY2staG90LW1pZGRsZXdhcmUpLlxuaW1wb3J0IGFuc2lIVE1MIGZyb20gXCJhbnNpLWh0bWwtY29tbXVuaXR5XCI7XG4vKipcbiAqIEB0eXBlIHsoaW5wdXQ6IHN0cmluZywgcG9zaXRpb246IG51bWJlcikgPT4gc3RyaW5nfVxuICovXG52YXIgZ2V0Q29kZVBvaW50ID0gU3RyaW5nLnByb3RvdHlwZS5jb2RlUG9pbnRBdCA/IGZ1bmN0aW9uIChpbnB1dCwgcG9zaXRpb24pIHtcbiAgICByZXR1cm4gaW5wdXQuY29kZVBvaW50QXQocG9zaXRpb24pO1xufSA6IGZ1bmN0aW9uIChpbnB1dCwgcG9zaXRpb24pIHtcbiAgICByZXR1cm4gKGlucHV0LmNoYXJDb2RlQXQocG9zaXRpb24pIC0gMHhkODAwKSAqIDB4NDAwICsgaW5wdXQuY2hhckNvZGVBdChwb3NpdGlvbiArIDEpIC0gMHhkYzAwICsgMHgxMDAwMDtcbn07XG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSBtYWNyb1RleHRcbiAqIEBwYXJhbSB7UmVnRXhwfSBtYWNyb1JlZ0V4cFxuICogQHBhcmFtIHsoaW5wdXQ6IHN0cmluZykgPT4gc3RyaW5nfSBtYWNyb1JlcGxhY2VyXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG52YXIgcmVwbGFjZVVzaW5nUmVnRXhwID0gZnVuY3Rpb24gcmVwbGFjZVVzaW5nUmVnRXhwKG1hY3JvVGV4dCwgbWFjcm9SZWdFeHAsIG1hY3JvUmVwbGFjZXIpIHtcbiAgICBtYWNyb1JlZ0V4cC5sYXN0SW5kZXggPSAwO1xuICAgIHZhciByZXBsYWNlTWF0Y2ggPSBtYWNyb1JlZ0V4cC5leGVjKG1hY3JvVGV4dCk7XG4gICAgdmFyIHJlcGxhY2VSZXN1bHQ7XG4gICAgaWYgKHJlcGxhY2VNYXRjaCkge1xuICAgICAgICByZXBsYWNlUmVzdWx0ID0gXCJcIjtcbiAgICAgICAgdmFyIHJlcGxhY2VMYXN0SW5kZXggPSAwO1xuICAgICAgICBkbyB7XG4gICAgICAgICAgICBpZiAocmVwbGFjZUxhc3RJbmRleCAhPT0gcmVwbGFjZU1hdGNoLmluZGV4KSB7XG4gICAgICAgICAgICAgICAgcmVwbGFjZVJlc3VsdCArPSBtYWNyb1RleHQuc3Vic3RyaW5nKHJlcGxhY2VMYXN0SW5kZXgsIHJlcGxhY2VNYXRjaC5pbmRleCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB2YXIgcmVwbGFjZUlucHV0ID0gcmVwbGFjZU1hdGNoWzBdO1xuICAgICAgICAgICAgcmVwbGFjZVJlc3VsdCArPSBtYWNyb1JlcGxhY2VyKHJlcGxhY2VJbnB1dCk7XG4gICAgICAgICAgICByZXBsYWNlTGFzdEluZGV4ID0gcmVwbGFjZU1hdGNoLmluZGV4ICsgcmVwbGFjZUlucHV0Lmxlbmd0aDtcbiAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25kLWFzc2lnblxuICAgICAgICB9IHdoaWxlIChyZXBsYWNlTWF0Y2ggPSBtYWNyb1JlZ0V4cC5leGVjKG1hY3JvVGV4dCkpO1xuICAgICAgICBpZiAocmVwbGFjZUxhc3RJbmRleCAhPT0gbWFjcm9UZXh0Lmxlbmd0aCkge1xuICAgICAgICAgICAgcmVwbGFjZVJlc3VsdCArPSBtYWNyb1RleHQuc3Vic3RyaW5nKHJlcGxhY2VMYXN0SW5kZXgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZXBsYWNlUmVzdWx0ID0gbWFjcm9UZXh0O1xuICAgIH1cbiAgICByZXR1cm4gcmVwbGFjZVJlc3VsdDtcbn07XG52YXIgcmVmZXJlbmNlcyA9IHtcbiAgICBcIjxcIjogXCImbHQ7XCIsXG4gICAgXCI+XCI6IFwiJmd0O1wiLFxuICAgICdcIic6IFwiJnF1b3Q7XCIsXG4gICAgXCInXCI6IFwiJmFwb3M7XCIsXG4gICAgXCImXCI6IFwiJmFtcDtcIlxufTtcbi8qKlxuICogQHBhcmFtIHtzdHJpbmd9IHRleHQgdGV4dFxuICogQHJldHVybnMge3N0cmluZ31cbiAqL1xuZnVuY3Rpb24gZW5jb2RlKHRleHQpIHtcbiAgICBpZiAoIXRleHQpIHtcbiAgICAgICAgcmV0dXJuIFwiXCI7XG4gICAgfVxuICAgIHJldHVybiByZXBsYWNlVXNpbmdSZWdFeHAodGV4dCwgL1s8PidcIiZdL2csIGZ1bmN0aW9uIChpbnB1dCkge1xuICAgICAgICB2YXIgcmVzdWx0ID0gcmVmZXJlbmNlc1tpbnB1dF07XG4gICAgICAgIGlmICghcmVzdWx0KSB7XG4gICAgICAgICAgICB2YXIgY29kZSA9IGlucHV0Lmxlbmd0aCA+IDEgPyBnZXRDb2RlUG9pbnQoaW5wdXQsIDApIDogaW5wdXQuY2hhckNvZGVBdCgwKTtcbiAgICAgICAgICAgIHJlc3VsdCA9IFwiJiNcIi5jb25jYXQoY29kZSwgXCI7XCIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfSk7XG59XG4vKipcbiAqIEB0eXBlZGVmIHtPYmplY3R9IFN0YXRlRGVmaW5pdGlvbnNcbiAqIEBwcm9wZXJ0eSB7e1tldmVudDogc3RyaW5nXTogeyB0YXJnZXQ6IHN0cmluZzsgYWN0aW9ucz86IEFycmF5PHN0cmluZz4gfX19IFtvbl1cbiAqL1xuLyoqXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBPcHRpb25zXG4gKiBAcHJvcGVydHkge3tbc3RhdGU6IHN0cmluZ106IFN0YXRlRGVmaW5pdGlvbnN9fSBzdGF0ZXNcbiAqIEBwcm9wZXJ0eSB7b2JqZWN0fSBjb250ZXh0O1xuICogQHByb3BlcnR5IHtzdHJpbmd9IGluaXRpYWxcbiAqL1xuLyoqXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBJbXBsZW1lbnRhdGlvblxuICogQHByb3BlcnR5IHt7W2FjdGlvbk5hbWU6IHN0cmluZ106IChjdHg6IG9iamVjdCwgZXZlbnQ6IGFueSkgPT4gb2JqZWN0fX0gYWN0aW9uc1xuICovXG4vKipcbiAqIEEgc2ltcGxpZmllZCBgY3JlYXRlTWFjaGluZWAgZnJvbSBgQHhzdGF0ZS9mc21gIHdpdGggdGhlIGZvbGxvd2luZyBkaWZmZXJlbmNlczpcbiAqXG4gKiAgLSB0aGUgcmV0dXJuZWQgbWFjaGluZSBpcyB0ZWNobmljYWxseSBhIFwic2VydmljZVwiLiBObyBgaW50ZXJwcmV0KG1hY2hpbmUpLnN0YXJ0KClgIGlzIG5lZWRlZC5cbiAqICAtIHRoZSBzdGF0ZSBkZWZpbml0aW9uIG9ubHkgc3VwcG9ydCBgb25gIGFuZCB0YXJnZXQgbXVzdCBiZSBkZWNsYXJlZCB3aXRoIHsgdGFyZ2V0OiAnbmV4dFN0YXRlJywgYWN0aW9uczogW10gfSBleHBsaWNpdGx5LlxuICogIC0gZXZlbnQgcGFzc2VkIHRvIGBzZW5kYCBtdXN0IGJlIGFuIG9iamVjdCB3aXRoIGB0eXBlYCBwcm9wZXJ0eS5cbiAqICAtIGFjdGlvbnMgaW1wbGVtZW50YXRpb24gd2lsbCBiZSBbYXNzaWduIGFjdGlvbl0oaHR0cHM6Ly94c3RhdGUuanMub3JnL2RvY3MvZ3VpZGVzL2NvbnRleHQuaHRtbCNhc3NpZ24tYWN0aW9uKSBpZiB5b3UgcmV0dXJuIGFueSB2YWx1ZS5cbiAqICBEbyBub3QgcmV0dXJuIGFueXRoaW5nIGlmIHlvdSBqdXN0IHdhbnQgdG8gaW52b2tlIHNpZGUgZWZmZWN0LlxuICpcbiAqIFRoZSBnb2FsIG9mIHRoaXMgY3VzdG9tIGZ1bmN0aW9uIGlzIHRvIGF2b2lkIGluc3RhbGxpbmcgdGhlIGVudGlyZSBgJ3hzdGF0ZS9mc20nYCBwYWNrYWdlLCB3aGlsZSBlbmFibGluZyBtb2RlbGluZyB1c2luZ1xuICogc3RhdGUgbWFjaGluZS4gWW91IGNhbiBjb3B5IHRoZSBmaXJzdCBwYXJhbWV0ZXIgaW50byB0aGUgZWRpdG9yIGF0IGh0dHBzOi8vc3RhdGVseS5haS92aXogdG8gdmlzdWFsaXplIHRoZSBzdGF0ZSBtYWNoaW5lLlxuICpcbiAqIEBwYXJhbSB7T3B0aW9uc30gb3B0aW9uc1xuICogQHBhcmFtIHtJbXBsZW1lbnRhdGlvbn0gaW1wbGVtZW50YXRpb25cbiAqL1xuZnVuY3Rpb24gY3JlYXRlTWFjaGluZShfcmVmLCBfcmVmMikge1xuICAgIHZhciBzdGF0ZXMgPSBfcmVmLnN0YXRlcywgY29udGV4dCA9IF9yZWYuY29udGV4dCwgaW5pdGlhbCA9IF9yZWYuaW5pdGlhbDtcbiAgICB2YXIgYWN0aW9ucyA9IF9yZWYyLmFjdGlvbnM7XG4gICAgdmFyIGN1cnJlbnRTdGF0ZSA9IGluaXRpYWw7XG4gICAgdmFyIGN1cnJlbnRDb250ZXh0ID0gY29udGV4dDtcbiAgICByZXR1cm4ge1xuICAgICAgICBzZW5kOiBmdW5jdGlvbiBzZW5kKGV2ZW50KSB7XG4gICAgICAgICAgICB2YXIgY3VycmVudFN0YXRlT24gPSBzdGF0ZXNbY3VycmVudFN0YXRlXS5vbjtcbiAgICAgICAgICAgIHZhciB0cmFuc2l0aW9uQ29uZmlnID0gY3VycmVudFN0YXRlT24gJiYgY3VycmVudFN0YXRlT25bZXZlbnQudHlwZV07XG4gICAgICAgICAgICBpZiAodHJhbnNpdGlvbkNvbmZpZykge1xuICAgICAgICAgICAgICAgIGN1cnJlbnRTdGF0ZSA9IHRyYW5zaXRpb25Db25maWcudGFyZ2V0O1xuICAgICAgICAgICAgICAgIGlmICh0cmFuc2l0aW9uQ29uZmlnLmFjdGlvbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgdHJhbnNpdGlvbkNvbmZpZy5hY3Rpb25zLmZvckVhY2goZnVuY3Rpb24gKGFjdE5hbWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBhY3Rpb25JbXBsID0gYWN0aW9uc1thY3ROYW1lXTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhciBuZXh0Q29udGV4dFZhbHVlID0gYWN0aW9uSW1wbCAmJiBhY3Rpb25JbXBsKGN1cnJlbnRDb250ZXh0LCBldmVudCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBpZiAobmV4dENvbnRleHRWYWx1ZSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGN1cnJlbnRDb250ZXh0ID0gX29iamVjdFNwcmVhZChfb2JqZWN0U3ByZWFkKHt9LCBjdXJyZW50Q29udGV4dCksIG5leHRDb250ZXh0VmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xufVxuLyoqXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBTaG93T3ZlcmxheURhdGFcbiAqIEBwcm9wZXJ0eSB7J3dhcm5pbmcnIHwgJ2Vycm9yJ30gbGV2ZWxcbiAqIEBwcm9wZXJ0eSB7QXJyYXk8c3RyaW5nICB8IHsgbW9kdWxlSWRlbnRpZmllcj86IHN0cmluZywgbW9kdWxlTmFtZT86IHN0cmluZywgbG9jPzogc3RyaW5nLCBtZXNzYWdlPzogc3RyaW5nIH0+fSBtZXNzYWdlc1xuICogQHByb3BlcnR5IHsnYnVpbGQnIHwgJ3J1bnRpbWUnfSBtZXNzYWdlU291cmNlXG4gKi9cbi8qKlxuICogQHR5cGVkZWYge09iamVjdH0gQ3JlYXRlT3ZlcmxheU1hY2hpbmVPcHRpb25zXG4gKiBAcHJvcGVydHkgeyhkYXRhOiBTaG93T3ZlcmxheURhdGEpID0+IHZvaWR9IHNob3dPdmVybGF5XG4gKiBAcHJvcGVydHkgeygpID0+IHZvaWR9IGhpZGVPdmVybGF5XG4gKi9cbi8qKlxuICogQHBhcmFtIHtDcmVhdGVPdmVybGF5TWFjaGluZU9wdGlvbnN9IG9wdGlvbnNcbiAqL1xudmFyIGNyZWF0ZU92ZXJsYXlNYWNoaW5lID0gZnVuY3Rpb24gY3JlYXRlT3ZlcmxheU1hY2hpbmUob3B0aW9ucykge1xuICAgIHZhciBoaWRlT3ZlcmxheSA9IG9wdGlvbnMuaGlkZU92ZXJsYXksIHNob3dPdmVybGF5ID0gb3B0aW9ucy5zaG93T3ZlcmxheTtcbiAgICByZXR1cm4gY3JlYXRlTWFjaGluZSh7XG4gICAgICAgIGluaXRpYWw6IFwiaGlkZGVuXCIsXG4gICAgICAgIGNvbnRleHQ6IHtcbiAgICAgICAgICAgIGxldmVsOiBcImVycm9yXCIsXG4gICAgICAgICAgICBtZXNzYWdlczogW10sXG4gICAgICAgICAgICBtZXNzYWdlU291cmNlOiBcImJ1aWxkXCJcbiAgICAgICAgfSxcbiAgICAgICAgc3RhdGVzOiB7XG4gICAgICAgICAgICBoaWRkZW46IHtcbiAgICAgICAgICAgICAgICBvbjoge1xuICAgICAgICAgICAgICAgICAgICBCVUlMRF9FUlJPUjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiBcImRpc3BsYXlCdWlsZEVycm9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJzZXRNZXNzYWdlc1wiLCBcInNob3dPdmVybGF5XCJdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIFJVTlRJTUVfRVJST1I6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogXCJkaXNwbGF5UnVudGltZUVycm9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJzZXRNZXNzYWdlc1wiLCBcInNob3dPdmVybGF5XCJdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZGlzcGxheUJ1aWxkRXJyb3I6IHtcbiAgICAgICAgICAgICAgICBvbjoge1xuICAgICAgICAgICAgICAgICAgICBESVNNSVNTOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IFwiaGlkZGVuXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJkaXNtaXNzTWVzc2FnZXNcIiwgXCJoaWRlT3ZlcmxheVwiXVxuICAgICAgICAgICAgICAgICAgICB9LFxuICAgICAgICAgICAgICAgICAgICBCVUlMRF9FUlJPUjoge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGFyZ2V0OiBcImRpc3BsYXlCdWlsZEVycm9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhcHBlbmRNZXNzYWdlc1wiLCBcInNob3dPdmVybGF5XCJdXG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZGlzcGxheVJ1bnRpbWVFcnJvcjoge1xuICAgICAgICAgICAgICAgIG9uOiB7XG4gICAgICAgICAgICAgICAgICAgIERJU01JU1M6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogXCJoaWRkZW5cIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbnM6IFtcImRpc21pc3NNZXNzYWdlc1wiLCBcImhpZGVPdmVybGF5XCJdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIFJVTlRJTUVfRVJST1I6IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRhcmdldDogXCJkaXNwbGF5UnVudGltZUVycm9yXCIsXG4gICAgICAgICAgICAgICAgICAgICAgICBhY3Rpb25zOiBbXCJhcHBlbmRNZXNzYWdlc1wiLCBcInNob3dPdmVybGF5XCJdXG4gICAgICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgICAgICAgIEJVSUxEX0VSUk9SOiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXQ6IFwiZGlzcGxheUJ1aWxkRXJyb3JcIixcbiAgICAgICAgICAgICAgICAgICAgICAgIGFjdGlvbnM6IFtcInNldE1lc3NhZ2VzXCIsIFwic2hvd092ZXJsYXlcIl1cbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sIHtcbiAgICAgICAgYWN0aW9uczoge1xuICAgICAgICAgICAgZGlzbWlzc01lc3NhZ2VzOiBmdW5jdGlvbiBkaXNtaXNzTWVzc2FnZXMoKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAgICAgbWVzc2FnZXM6IFtdLFxuICAgICAgICAgICAgICAgICAgICBsZXZlbDogXCJlcnJvclwiLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlU291cmNlOiBcImJ1aWxkXCJcbiAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIGFwcGVuZE1lc3NhZ2VzOiBmdW5jdGlvbiBhcHBlbmRNZXNzYWdlcyhjb250ZXh0LCBldmVudCkge1xuICAgICAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2VzOiBjb250ZXh0Lm1lc3NhZ2VzLmNvbmNhdChldmVudC5tZXNzYWdlcyksXG4gICAgICAgICAgICAgICAgICAgIGxldmVsOiBldmVudC5sZXZlbCB8fCBjb250ZXh0LmxldmVsLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlU291cmNlOiBldmVudC50eXBlID09PSBcIlJVTlRJTUVfRVJST1JcIiA/IFwicnVudGltZVwiIDogXCJidWlsZFwiXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBzZXRNZXNzYWdlczogZnVuY3Rpb24gc2V0TWVzc2FnZXMoY29udGV4dCwgZXZlbnQpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlczogZXZlbnQubWVzc2FnZXMsXG4gICAgICAgICAgICAgICAgICAgIGxldmVsOiBldmVudC5sZXZlbCB8fCBjb250ZXh0LmxldmVsLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlU291cmNlOiBldmVudC50eXBlID09PSBcIlJVTlRJTUVfRVJST1JcIiA/IFwicnVudGltZVwiIDogXCJidWlsZFwiXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBoaWRlT3ZlcmxheTogaGlkZU92ZXJsYXksXG4gICAgICAgICAgICBzaG93T3ZlcmxheTogc2hvd092ZXJsYXlcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbi8qKlxuICpcbiAqIEBwYXJhbSB7RXJyb3J9IGVycm9yXG4gKi9cbnZhciBwYXJzZUVycm9yVG9TdGFja3MgPSBmdW5jdGlvbiBwYXJzZUVycm9yVG9TdGFja3MoZXJyb3IpIHtcbiAgICBpZiAoIWVycm9yIHx8ICEoZXJyb3IgaW5zdGFuY2VvZiBFcnJvcikpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwicGFyc2VFcnJvclRvU3RhY2tzIGV4cGVjdHMgRXJyb3Igb2JqZWN0XCIpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIGVycm9yLnN0YWNrID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgIHJldHVybiBlcnJvci5zdGFjay5zcGxpdChcIlxcblwiKS5maWx0ZXIoZnVuY3Rpb24gKHN0YWNrKSB7XG4gICAgICAgICAgICByZXR1cm4gc3RhY2sgIT09IFwiRXJyb3I6IFwiLmNvbmNhdChlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgfSk7XG4gICAgfVxufTtcbi8qKlxuICogQGNhbGxiYWNrIEVycm9yQ2FsbGJhY2tcbiAqIEBwYXJhbSB7RXJyb3JFdmVudH0gZXJyb3JcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG4vKipcbiAqIEBwYXJhbSB7RXJyb3JDYWxsYmFja30gY2FsbGJhY2tcbiAqL1xudmFyIGxpc3RlblRvUnVudGltZUVycm9yID0gZnVuY3Rpb24gbGlzdGVuVG9SdW50aW1lRXJyb3IoY2FsbGJhY2spIHtcbiAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcihcImVycm9yXCIsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gZnVuY3Rpb24gY2xlYW51cCgpIHtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJlcnJvclwiLCBjYWxsYmFjayk7XG4gICAgfTtcbn07XG4vKipcbiAqIEBjYWxsYmFjayBVbmhhbmRsZWRSZWplY3Rpb25DYWxsYmFja1xuICogQHBhcmFtIHtQcm9taXNlUmVqZWN0aW9uRXZlbnR9IHJlamVjdGlvbkV2ZW50XG4gKiBAcmV0dXJucyB7dm9pZH1cbiAqL1xuLyoqXG4gKiBAcGFyYW0ge1VuaGFuZGxlZFJlamVjdGlvbkNhbGxiYWNrfSBjYWxsYmFja1xuICovXG52YXIgbGlzdGVuVG9VbmhhbmRsZWRSZWplY3Rpb24gPSBmdW5jdGlvbiBsaXN0ZW5Ub1VuaGFuZGxlZFJlamVjdGlvbihjYWxsYmFjaykge1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKFwidW5oYW5kbGVkcmVqZWN0aW9uXCIsIGNhbGxiYWNrKTtcbiAgICByZXR1cm4gZnVuY3Rpb24gY2xlYW51cCgpIHtcbiAgICAgICAgd2luZG93LnJlbW92ZUV2ZW50TGlzdGVuZXIoXCJ1bmhhbmRsZWRyZWplY3Rpb25cIiwgY2FsbGJhY2spO1xuICAgIH07XG59O1xuLy8gU3R5bGVzIGFyZSBpbnNwaXJlZCBieSBgcmVhY3QtZXJyb3Itb3ZlcmxheWBcbnZhciBtc2dTdHlsZXMgPSB7XG4gICAgZXJyb3I6IHtcbiAgICAgICAgYmFja2dyb3VuZENvbG9yOiBcInJnYmEoMjA2LCAxNywgMzgsIDAuMSlcIixcbiAgICAgICAgY29sb3I6IFwiI2ZjY2ZjZlwiXG4gICAgfSxcbiAgICB3YXJuaW5nOiB7XG4gICAgICAgIGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDI1MSwgMjQ1LCAxODAsIDAuMSlcIixcbiAgICAgICAgY29sb3I6IFwiI2ZiZjViNFwiXG4gICAgfVxufTtcbnZhciBpZnJhbWVTdHlsZSA9IHtcbiAgICBwb3NpdGlvbjogXCJmaXhlZFwiLFxuICAgIHRvcDogMCxcbiAgICBsZWZ0OiAwLFxuICAgIHJpZ2h0OiAwLFxuICAgIGJvdHRvbTogMCxcbiAgICB3aWR0aDogXCIxMDB2d1wiLFxuICAgIGhlaWdodDogXCIxMDB2aFwiLFxuICAgIGJvcmRlcjogXCJub25lXCIsXG4gICAgXCJ6LWluZGV4XCI6IDk5OTk5OTk5OTlcbn07XG52YXIgY29udGFpbmVyU3R5bGUgPSB7XG4gICAgcG9zaXRpb246IFwiZml4ZWRcIixcbiAgICBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiLFxuICAgIGxlZnQ6IDAsXG4gICAgdG9wOiAwLFxuICAgIHJpZ2h0OiAwLFxuICAgIGJvdHRvbTogMCxcbiAgICB3aWR0aDogXCIxMDB2d1wiLFxuICAgIGhlaWdodDogXCIxMDB2aFwiLFxuICAgIGZvbnRTaXplOiBcImxhcmdlXCIsXG4gICAgcGFkZGluZzogXCIycmVtIDJyZW0gNHJlbSAycmVtXCIsXG4gICAgbGluZUhlaWdodDogXCIxLjJcIixcbiAgICB3aGl0ZVNwYWNlOiBcInByZS13cmFwXCIsXG4gICAgb3ZlcmZsb3c6IFwiYXV0b1wiLFxuICAgIGJhY2tncm91bmRDb2xvcjogXCJyZ2JhKDAsIDAsIDAsIDAuOSlcIixcbiAgICBjb2xvcjogXCJ3aGl0ZVwiXG59O1xudmFyIGhlYWRlclN0eWxlID0ge1xuICAgIGNvbG9yOiBcIiNlODNiNDZcIixcbiAgICBmb250U2l6ZTogXCIyZW1cIixcbiAgICB3aGl0ZVNwYWNlOiBcInByZS13cmFwXCIsXG4gICAgZm9udEZhbWlseTogXCJzYW5zLXNlcmlmXCIsXG4gICAgbWFyZ2luOiBcIjAgMnJlbSAycmVtIDBcIixcbiAgICBmbGV4OiBcIjAgMCBhdXRvXCIsXG4gICAgbWF4SGVpZ2h0OiBcIjUwJVwiLFxuICAgIG92ZXJmbG93OiBcImF1dG9cIlxufTtcbnZhciBkaXNtaXNzQnV0dG9uU3R5bGUgPSB7XG4gICAgY29sb3I6IFwiI2ZmZmZmZlwiLFxuICAgIGxpbmVIZWlnaHQ6IFwiMXJlbVwiLFxuICAgIGZvbnRTaXplOiBcIjEuNXJlbVwiLFxuICAgIHBhZGRpbmc6IFwiMXJlbVwiLFxuICAgIGN1cnNvcjogXCJwb2ludGVyXCIsXG4gICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICByaWdodDogMCxcbiAgICB0b3A6IDAsXG4gICAgYmFja2dyb3VuZENvbG9yOiBcInRyYW5zcGFyZW50XCIsXG4gICAgYm9yZGVyOiBcIm5vbmVcIlxufTtcbnZhciBtc2dUeXBlU3R5bGUgPSB7XG4gICAgY29sb3I6IFwiI2U4M2I0NlwiLFxuICAgIGZvbnRTaXplOiBcIjEuMmVtXCIsXG4gICAgbWFyZ2luQm90dG9tOiBcIjFyZW1cIixcbiAgICBmb250RmFtaWx5OiBcInNhbnMtc2VyaWZcIlxufTtcbnZhciBtc2dUZXh0U3R5bGUgPSB7XG4gICAgbGluZUhlaWdodDogXCIxLjVcIixcbiAgICBmb250U2l6ZTogXCIxcmVtXCIsXG4gICAgZm9udEZhbWlseTogXCJNZW5sbywgQ29uc29sYXMsIG1vbm9zcGFjZVwiXG59O1xuLy8gQU5TSSBIVE1MXG52YXIgY29sb3JzID0ge1xuICAgIHJlc2V0OiBbXCJ0cmFuc3BhcmVudFwiLCBcInRyYW5zcGFyZW50XCJdLFxuICAgIGJsYWNrOiBcIjE4MTgxOFwiLFxuICAgIHJlZDogXCJFMzYwNDlcIixcbiAgICBncmVlbjogXCJCM0NCNzRcIixcbiAgICB5ZWxsb3c6IFwiRkZEMDgwXCIsXG4gICAgYmx1ZTogXCI3Q0FGQzJcIixcbiAgICBtYWdlbnRhOiBcIjdGQUNDQVwiLFxuICAgIGN5YW46IFwiQzNDMkVGXCIsXG4gICAgbGlnaHRncmV5OiBcIkVCRTdFM1wiLFxuICAgIGRhcmtncmV5OiBcIjZENzg5MVwiXG59O1xuYW5zaUhUTUwuc2V0Q29sb3JzKGNvbG9ycyk7XG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB0eXBlXG4gKiBAcGFyYW0ge3N0cmluZyAgfCB7IGZpbGU/OiBzdHJpbmcsIG1vZHVsZU5hbWU/OiBzdHJpbmcsIGxvYz86IHN0cmluZywgbWVzc2FnZT86IHN0cmluZzsgc3RhY2s/OiBzdHJpbmdbXSB9fSBpdGVtXG4gKiBAcmV0dXJucyB7eyBoZWFkZXI6IHN0cmluZywgYm9keTogc3RyaW5nIH19XG4gKi9cbnZhciBmb3JtYXRQcm9ibGVtID0gZnVuY3Rpb24gZm9ybWF0UHJvYmxlbSh0eXBlLCBpdGVtKSB7XG4gICAgdmFyIGhlYWRlciA9IHR5cGUgPT09IFwid2FybmluZ1wiID8gXCJXQVJOSU5HXCIgOiBcIkVSUk9SXCI7XG4gICAgdmFyIGJvZHkgPSBcIlwiO1xuICAgIGlmICh0eXBlb2YgaXRlbSA9PT0gXCJzdHJpbmdcIikge1xuICAgICAgICBib2R5ICs9IGl0ZW07XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICB2YXIgZmlsZSA9IGl0ZW0uZmlsZSB8fCBcIlwiO1xuICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmVzdGVkLXRlcm5hcnlcbiAgICAgICAgdmFyIG1vZHVsZU5hbWUgPSBpdGVtLm1vZHVsZU5hbWUgPyBpdGVtLm1vZHVsZU5hbWUuaW5kZXhPZihcIiFcIikgIT09IC0xID8gXCJcIi5jb25jYXQoaXRlbS5tb2R1bGVOYW1lLnJlcGxhY2UoL14oXFxzfFxcUykqIS8sIFwiXCIpLCBcIiAoXCIpLmNvbmNhdChpdGVtLm1vZHVsZU5hbWUsIFwiKVwiKSA6IFwiXCIuY29uY2F0KGl0ZW0ubW9kdWxlTmFtZSkgOiBcIlwiO1xuICAgICAgICB2YXIgbG9jID0gaXRlbS5sb2M7XG4gICAgICAgIGhlYWRlciArPSBcIlwiLmNvbmNhdChtb2R1bGVOYW1lIHx8IGZpbGUgPyBcIiBpbiBcIi5jb25jYXQobW9kdWxlTmFtZSA/IFwiXCIuY29uY2F0KG1vZHVsZU5hbWUpLmNvbmNhdChmaWxlID8gXCIgKFwiLmNvbmNhdChmaWxlLCBcIilcIikgOiBcIlwiKSA6IGZpbGUpLmNvbmNhdChsb2MgPyBcIiBcIi5jb25jYXQobG9jKSA6IFwiXCIpIDogXCJcIik7XG4gICAgICAgIGJvZHkgKz0gaXRlbS5tZXNzYWdlIHx8IFwiXCI7XG4gICAgfVxuICAgIGlmIChBcnJheS5pc0FycmF5KGl0ZW0uc3RhY2spKSB7XG4gICAgICAgIGl0ZW0uc3RhY2suZm9yRWFjaChmdW5jdGlvbiAoc3RhY2spIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygc3RhY2sgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgICBib2R5ICs9IFwiXFxyXFxuXCIuY29uY2F0KHN0YWNrKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIGhlYWRlcjogaGVhZGVyLFxuICAgICAgICBib2R5OiBib2R5XG4gICAgfTtcbn07XG4vKipcbiAqIEB0eXBlZGVmIHtPYmplY3R9IENyZWF0ZU92ZXJsYXlPcHRpb25zXG4gKiBAcHJvcGVydHkge3N0cmluZyB8IG51bGx9IHRydXN0ZWRUeXBlc1BvbGljeU5hbWVcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbiB8IChlcnJvcjogRXJyb3IpID0+IHZvaWR9IFtjYXRjaFJ1bnRpbWVFcnJvcl1cbiAqL1xuLyoqXG4gKlxuICogQHBhcmFtIHtDcmVhdGVPdmVybGF5T3B0aW9uc30gb3B0aW9uc1xuICovXG52YXIgY3JlYXRlT3ZlcmxheSA9IGZ1bmN0aW9uIGNyZWF0ZU92ZXJsYXkob3B0aW9ucykge1xuICAgIC8qKiBAdHlwZSB7SFRNTElGcmFtZUVsZW1lbnQgfCBudWxsIHwgdW5kZWZpbmVkfSAqL1xuICAgIHZhciBpZnJhbWVDb250YWluZXJFbGVtZW50O1xuICAgIC8qKiBAdHlwZSB7SFRNTERpdkVsZW1lbnQgfCBudWxsIHwgdW5kZWZpbmVkfSAqL1xuICAgIHZhciBjb250YWluZXJFbGVtZW50O1xuICAgIC8qKiBAdHlwZSB7SFRNTERpdkVsZW1lbnQgfCBudWxsIHwgdW5kZWZpbmVkfSAqL1xuICAgIHZhciBoZWFkZXJFbGVtZW50O1xuICAgIC8qKiBAdHlwZSB7QXJyYXk8KGVsZW1lbnQ6IEhUTUxEaXZFbGVtZW50KSA9PiB2b2lkPn0gKi9cbiAgICB2YXIgb25Mb2FkUXVldWUgPSBbXTtcbiAgICAvKiogQHR5cGUge1RydXN0ZWRUeXBlUG9saWN5IHwgdW5kZWZpbmVkfSAqL1xuICAgIHZhciBvdmVybGF5VHJ1c3RlZFR5cGVzUG9saWN5O1xuICAgIC8qKlxuICAgICAqXG4gICAgICogQHBhcmFtIHtIVE1MRWxlbWVudH0gZWxlbWVudFxuICAgICAqIEBwYXJhbSB7Q1NTU3R5bGVEZWNsYXJhdGlvbn0gc3R5bGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBhcHBseVN0eWxlKGVsZW1lbnQsIHN0eWxlKSB7XG4gICAgICAgIE9iamVjdC5rZXlzKHN0eWxlKS5mb3JFYWNoKGZ1bmN0aW9uIChwcm9wKSB7XG4gICAgICAgICAgICBlbGVtZW50LnN0eWxlW3Byb3BdID0gc3R5bGVbcHJvcF07XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZyB8IG51bGx9IHRydXN0ZWRUeXBlc1BvbGljeU5hbWVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjcmVhdGVDb250YWluZXIodHJ1c3RlZFR5cGVzUG9saWN5TmFtZSkge1xuICAgICAgICAvLyBFbmFibGUgVHJ1c3RlZCBUeXBlcyBpZiB0aGV5IGFyZSBhdmFpbGFibGUgaW4gdGhlIGN1cnJlbnQgYnJvd3Nlci5cbiAgICAgICAgaWYgKHdpbmRvdy50cnVzdGVkVHlwZXMpIHtcbiAgICAgICAgICAgIG92ZXJsYXlUcnVzdGVkVHlwZXNQb2xpY3kgPSB3aW5kb3cudHJ1c3RlZFR5cGVzLmNyZWF0ZVBvbGljeSh0cnVzdGVkVHlwZXNQb2xpY3lOYW1lIHx8IFwid2VicGFjay1kZXYtc2VydmVyI292ZXJsYXlcIiwge1xuICAgICAgICAgICAgICAgIGNyZWF0ZUhUTUw6IGZ1bmN0aW9uIGNyZWF0ZUhUTUwodmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGlmcmFtZUNvbnRhaW5lckVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiaWZyYW1lXCIpO1xuICAgICAgICBpZnJhbWVDb250YWluZXJFbGVtZW50LmlkID0gXCJ3ZWJwYWNrLWRldi1zZXJ2ZXItY2xpZW50LW92ZXJsYXlcIjtcbiAgICAgICAgaWZyYW1lQ29udGFpbmVyRWxlbWVudC5zcmMgPSBcImFib3V0OmJsYW5rXCI7XG4gICAgICAgIGFwcGx5U3R5bGUoaWZyYW1lQ29udGFpbmVyRWxlbWVudCwgaWZyYW1lU3R5bGUpO1xuICAgICAgICBpZnJhbWVDb250YWluZXJFbGVtZW50Lm9ubG9hZCA9IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIHZhciBjb250ZW50RWxlbWVudCA9IC8qKiBAdHlwZSB7RG9jdW1lbnR9ICovICggLyoqIEB0eXBlIHtIVE1MSUZyYW1lRWxlbWVudH0gKi9pZnJhbWVDb250YWluZXJFbGVtZW50LmNvbnRlbnREb2N1bWVudCkuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIGNvbnRhaW5lckVsZW1lbnQgPSAvKiogQHR5cGUge0RvY3VtZW50fSAqL1xuICAgICAgICAgICAgICAgICggLyoqIEB0eXBlIHtIVE1MSUZyYW1lRWxlbWVudH0gKi9pZnJhbWVDb250YWluZXJFbGVtZW50LmNvbnRlbnREb2N1bWVudCkuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIGNvbnRlbnRFbGVtZW50LmlkID0gXCJ3ZWJwYWNrLWRldi1zZXJ2ZXItY2xpZW50LW92ZXJsYXktZGl2XCI7XG4gICAgICAgICAgICBhcHBseVN0eWxlKGNvbnRlbnRFbGVtZW50LCBjb250YWluZXJTdHlsZSk7XG4gICAgICAgICAgICBoZWFkZXJFbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgIGhlYWRlckVsZW1lbnQuaW5uZXJUZXh0ID0gXCJDb21waWxlZCB3aXRoIHByb2JsZW1zOlwiO1xuICAgICAgICAgICAgYXBwbHlTdHlsZShoZWFkZXJFbGVtZW50LCBoZWFkZXJTdHlsZSk7XG4gICAgICAgICAgICB2YXIgY2xvc2VCdXR0b25FbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImJ1dHRvblwiKTtcbiAgICAgICAgICAgIGFwcGx5U3R5bGUoY2xvc2VCdXR0b25FbGVtZW50LCBkaXNtaXNzQnV0dG9uU3R5bGUpO1xuICAgICAgICAgICAgY2xvc2VCdXR0b25FbGVtZW50LmlubmVyVGV4dCA9IFwiw5dcIjtcbiAgICAgICAgICAgIGNsb3NlQnV0dG9uRWxlbWVudC5hcmlhTGFiZWwgPSBcIkRpc21pc3NcIjtcbiAgICAgICAgICAgIGNsb3NlQnV0dG9uRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby11c2UtYmVmb3JlLWRlZmluZVxuICAgICAgICAgICAgICAgIG92ZXJsYXlTZXJ2aWNlLnNlbmQoe1xuICAgICAgICAgICAgICAgICAgICB0eXBlOiBcIkRJU01JU1NcIlxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBjb250ZW50RWxlbWVudC5hcHBlbmRDaGlsZChoZWFkZXJFbGVtZW50KTtcbiAgICAgICAgICAgIGNvbnRlbnRFbGVtZW50LmFwcGVuZENoaWxkKGNsb3NlQnV0dG9uRWxlbWVudCk7XG4gICAgICAgICAgICBjb250ZW50RWxlbWVudC5hcHBlbmRDaGlsZChjb250YWluZXJFbGVtZW50KTtcbiAgICAgICAgICAgIC8qKiBAdHlwZSB7RG9jdW1lbnR9ICovXG4gICAgICAgICAgICAoIC8qKiBAdHlwZSB7SFRNTElGcmFtZUVsZW1lbnR9ICovaWZyYW1lQ29udGFpbmVyRWxlbWVudC5jb250ZW50RG9jdW1lbnQpLmJvZHkuYXBwZW5kQ2hpbGQoY29udGVudEVsZW1lbnQpO1xuICAgICAgICAgICAgb25Mb2FkUXVldWUuZm9yRWFjaChmdW5jdGlvbiAob25Mb2FkKSB7XG4gICAgICAgICAgICAgICAgb25Mb2FkKC8qKiBAdHlwZSB7SFRNTERpdkVsZW1lbnR9ICovIGNvbnRlbnRFbGVtZW50KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgb25Mb2FkUXVldWUgPSBbXTtcbiAgICAgICAgICAgIC8qKiBAdHlwZSB7SFRNTElGcmFtZUVsZW1lbnR9ICovXG4gICAgICAgICAgICBpZnJhbWVDb250YWluZXJFbGVtZW50Lm9ubG9hZCA9IG51bGw7XG4gICAgICAgIH07XG4gICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoaWZyYW1lQ29udGFpbmVyRWxlbWVudCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7KGVsZW1lbnQ6IEhUTUxEaXZFbGVtZW50KSA9PiB2b2lkfSBjYWxsYmFja1xuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgbnVsbH0gdHJ1c3RlZFR5cGVzUG9saWN5TmFtZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGVuc3VyZU92ZXJsYXlFeGlzdHMoY2FsbGJhY2ssIHRydXN0ZWRUeXBlc1BvbGljeU5hbWUpIHtcbiAgICAgICAgaWYgKGNvbnRhaW5lckVsZW1lbnQpIHtcbiAgICAgICAgICAgIGNvbnRhaW5lckVsZW1lbnQuaW5uZXJIVE1MID0gb3ZlcmxheVRydXN0ZWRUeXBlc1BvbGljeSA/IG92ZXJsYXlUcnVzdGVkVHlwZXNQb2xpY3kuY3JlYXRlSFRNTChcIlwiKSA6IFwiXCI7XG4gICAgICAgICAgICAvLyBFdmVyeXRoaW5nIGlzIHJlYWR5LCBjYWxsIHRoZSBjYWxsYmFjayByaWdodCBhd2F5LlxuICAgICAgICAgICAgY2FsbGJhY2soY29udGFpbmVyRWxlbWVudCk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb25Mb2FkUXVldWUucHVzaChjYWxsYmFjayk7XG4gICAgICAgIGlmIChpZnJhbWVDb250YWluZXJFbGVtZW50KSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY3JlYXRlQ29udGFpbmVyKHRydXN0ZWRUeXBlc1BvbGljeU5hbWUpO1xuICAgIH1cbiAgICAvLyBTdWNjZXNzZnVsIGNvbXBpbGF0aW9uLlxuICAgIGZ1bmN0aW9uIGhpZGUoKSB7XG4gICAgICAgIGlmICghaWZyYW1lQ29udGFpbmVyRWxlbWVudCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIC8vIENsZWFuIHVwIGFuZCByZXNldCBpbnRlcm5hbCBzdGF0ZS5cbiAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChpZnJhbWVDb250YWluZXJFbGVtZW50KTtcbiAgICAgICAgaWZyYW1lQ29udGFpbmVyRWxlbWVudCA9IG51bGw7XG4gICAgICAgIGNvbnRhaW5lckVsZW1lbnQgPSBudWxsO1xuICAgIH1cbiAgICAvLyBDb21waWxhdGlvbiB3aXRoIGVycm9ycyAoZS5nLiBzeW50YXggZXJyb3Igb3IgbWlzc2luZyBtb2R1bGVzKS5cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gdHlwZVxuICAgICAqIEBwYXJhbSB7QXJyYXk8c3RyaW5nICB8IHsgbW9kdWxlSWRlbnRpZmllcj86IHN0cmluZywgbW9kdWxlTmFtZT86IHN0cmluZywgbG9jPzogc3RyaW5nLCBtZXNzYWdlPzogc3RyaW5nIH0+fSBtZXNzYWdlc1xuICAgICAqIEBwYXJhbSB7c3RyaW5nIHwgbnVsbH0gdHJ1c3RlZFR5cGVzUG9saWN5TmFtZVxuICAgICAqIEBwYXJhbSB7J2J1aWxkJyB8ICdydW50aW1lJ30gbWVzc2FnZVNvdXJjZVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHNob3codHlwZSwgbWVzc2FnZXMsIHRydXN0ZWRUeXBlc1BvbGljeU5hbWUsIG1lc3NhZ2VTb3VyY2UpIHtcbiAgICAgICAgZW5zdXJlT3ZlcmxheUV4aXN0cyhmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBoZWFkZXJFbGVtZW50LmlubmVyVGV4dCA9IG1lc3NhZ2VTb3VyY2UgPT09IFwicnVudGltZVwiID8gXCJVbmNhdWdodCBydW50aW1lIGVycm9yczpcIiA6IFwiQ29tcGlsZWQgd2l0aCBwcm9ibGVtczpcIjtcbiAgICAgICAgICAgIG1lc3NhZ2VzLmZvckVhY2goZnVuY3Rpb24gKG1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICB2YXIgZW50cnlFbGVtZW50ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcImRpdlwiKTtcbiAgICAgICAgICAgICAgICB2YXIgbXNnU3R5bGUgPSB0eXBlID09PSBcIndhcm5pbmdcIiA/IG1zZ1N0eWxlcy53YXJuaW5nIDogbXNnU3R5bGVzLmVycm9yO1xuICAgICAgICAgICAgICAgIGFwcGx5U3R5bGUoZW50cnlFbGVtZW50LCBfb2JqZWN0U3ByZWFkKF9vYmplY3RTcHJlYWQoe30sIG1zZ1N0eWxlKSwge30sIHtcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZzogXCIxcmVtIDFyZW0gMS41cmVtIDFyZW1cIlxuICAgICAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgICAgICB2YXIgdHlwZUVsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KFwiZGl2XCIpO1xuICAgICAgICAgICAgICAgIHZhciBfZm9ybWF0UHJvYmxlbSA9IGZvcm1hdFByb2JsZW0odHlwZSwgbWVzc2FnZSksIGhlYWRlciA9IF9mb3JtYXRQcm9ibGVtLmhlYWRlciwgYm9keSA9IF9mb3JtYXRQcm9ibGVtLmJvZHk7XG4gICAgICAgICAgICAgICAgdHlwZUVsZW1lbnQuaW5uZXJUZXh0ID0gaGVhZGVyO1xuICAgICAgICAgICAgICAgIGFwcGx5U3R5bGUodHlwZUVsZW1lbnQsIG1zZ1R5cGVTdHlsZSk7XG4gICAgICAgICAgICAgICAgaWYgKG1lc3NhZ2UubW9kdWxlSWRlbnRpZmllcikge1xuICAgICAgICAgICAgICAgICAgICBhcHBseVN0eWxlKHR5cGVFbGVtZW50LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjdXJzb3I6IFwicG9pbnRlclwiXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgICAgICAvLyBlbGVtZW50LmRhdGFzZXQgbm90IHN1cHBvcnRlZCBpbiBJRVxuICAgICAgICAgICAgICAgICAgICB0eXBlRWxlbWVudC5zZXRBdHRyaWJ1dGUoXCJkYXRhLWNhbi1vcGVuXCIsIHRydWUpO1xuICAgICAgICAgICAgICAgICAgICB0eXBlRWxlbWVudC5hZGRFdmVudExpc3RlbmVyKFwiY2xpY2tcIiwgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgZmV0Y2goXCIvd2VicGFjay1kZXYtc2VydmVyL29wZW4tZWRpdG9yP2ZpbGVOYW1lPVwiLmNvbmNhdChtZXNzYWdlLm1vZHVsZUlkZW50aWZpZXIpKTtcbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIC8vIE1ha2UgaXQgbG9vayBzaW1pbGFyIHRvIG91ciB0ZXJtaW5hbC5cbiAgICAgICAgICAgICAgICB2YXIgdGV4dCA9IGFuc2lIVE1MKGVuY29kZShib2R5KSk7XG4gICAgICAgICAgICAgICAgdmFyIG1lc3NhZ2VUZXh0Tm9kZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJkaXZcIik7XG4gICAgICAgICAgICAgICAgYXBwbHlTdHlsZShtZXNzYWdlVGV4dE5vZGUsIG1zZ1RleHRTdHlsZSk7XG4gICAgICAgICAgICAgICAgbWVzc2FnZVRleHROb2RlLmlubmVySFRNTCA9IG92ZXJsYXlUcnVzdGVkVHlwZXNQb2xpY3kgPyBvdmVybGF5VHJ1c3RlZFR5cGVzUG9saWN5LmNyZWF0ZUhUTUwodGV4dCkgOiB0ZXh0O1xuICAgICAgICAgICAgICAgIGVudHJ5RWxlbWVudC5hcHBlbmRDaGlsZCh0eXBlRWxlbWVudCk7XG4gICAgICAgICAgICAgICAgZW50cnlFbGVtZW50LmFwcGVuZENoaWxkKG1lc3NhZ2VUZXh0Tm9kZSk7XG4gICAgICAgICAgICAgICAgLyoqIEB0eXBlIHtIVE1MRGl2RWxlbWVudH0gKi9cbiAgICAgICAgICAgICAgICBjb250YWluZXJFbGVtZW50LmFwcGVuZENoaWxkKGVudHJ5RWxlbWVudCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSwgdHJ1c3RlZFR5cGVzUG9saWN5TmFtZSk7XG4gICAgfVxuICAgIHZhciBvdmVybGF5U2VydmljZSA9IGNyZWF0ZU92ZXJsYXlNYWNoaW5lKHtcbiAgICAgICAgc2hvd092ZXJsYXk6IGZ1bmN0aW9uIHNob3dPdmVybGF5KF9yZWYzKSB7XG4gICAgICAgICAgICB2YXIgX3JlZjMkbGV2ZWwgPSBfcmVmMy5sZXZlbCwgbGV2ZWwgPSBfcmVmMyRsZXZlbCA9PT0gdm9pZCAwID8gXCJlcnJvclwiIDogX3JlZjMkbGV2ZWwsIG1lc3NhZ2VzID0gX3JlZjMubWVzc2FnZXMsIG1lc3NhZ2VTb3VyY2UgPSBfcmVmMy5tZXNzYWdlU291cmNlO1xuICAgICAgICAgICAgcmV0dXJuIHNob3cobGV2ZWwsIG1lc3NhZ2VzLCBvcHRpb25zLnRydXN0ZWRUeXBlc1BvbGljeU5hbWUsIG1lc3NhZ2VTb3VyY2UpO1xuICAgICAgICB9LFxuICAgICAgICBoaWRlT3ZlcmxheTogaGlkZVxuICAgIH0pO1xuICAgIGlmIChvcHRpb25zLmNhdGNoUnVudGltZUVycm9yKSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBAcGFyYW0ge0Vycm9yIHwgdW5kZWZpbmVkfSBlcnJvclxuICAgICAgICAgKiBAcGFyYW0ge3N0cmluZ30gZmFsbGJhY2tNZXNzYWdlXG4gICAgICAgICAqL1xuICAgICAgICB2YXIgaGFuZGxlRXJyb3IgPSBmdW5jdGlvbiBoYW5kbGVFcnJvcihlcnJvciwgZmFsbGJhY2tNZXNzYWdlKSB7XG4gICAgICAgICAgICB2YXIgZXJyb3JPYmplY3QgPSBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IgOiBuZXcgRXJyb3IoZXJyb3IgfHwgZmFsbGJhY2tNZXNzYWdlKTtcbiAgICAgICAgICAgIHZhciBzaG91bGREaXNwbGF5ID0gdHlwZW9mIG9wdGlvbnMuY2F0Y2hSdW50aW1lRXJyb3IgPT09IFwiZnVuY3Rpb25cIiA/IG9wdGlvbnMuY2F0Y2hSdW50aW1lRXJyb3IoZXJyb3JPYmplY3QpIDogdHJ1ZTtcbiAgICAgICAgICAgIGlmIChzaG91bGREaXNwbGF5KSB7XG4gICAgICAgICAgICAgICAgb3ZlcmxheVNlcnZpY2Uuc2VuZCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiUlVOVElNRV9FUlJPUlwiLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlczogW3tcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBtZXNzYWdlOiBlcnJvck9iamVjdC5tZXNzYWdlLFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHN0YWNrOiBwYXJzZUVycm9yVG9TdGFja3MoZXJyb3JPYmplY3QpXG4gICAgICAgICAgICAgICAgICAgICAgICB9XVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBsaXN0ZW5Ub1J1bnRpbWVFcnJvcihmdW5jdGlvbiAoZXJyb3JFdmVudCkge1xuICAgICAgICAgICAgLy8gZXJyb3IgcHJvcGVydHkgbWF5IGJlIGVtcHR5IGluIG9sZGVyIGJyb3dzZXIgbGlrZSBJRVxuICAgICAgICAgICAgdmFyIGVycm9yID0gZXJyb3JFdmVudC5lcnJvciwgbWVzc2FnZSA9IGVycm9yRXZlbnQubWVzc2FnZTtcbiAgICAgICAgICAgIGlmICghZXJyb3IgJiYgIW1lc3NhZ2UpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyBpZiBlcnJvciBzdGFjayBpbmRpY2F0ZXMgYSBSZWFjdCBlcnJvciBib3VuZGFyeSBjYXVnaHQgdGhlIGVycm9yLCBkbyBub3Qgc2hvdyBvdmVybGF5LlxuICAgICAgICAgICAgaWYgKGVycm9yICYmIGVycm9yLnN0YWNrICYmIGVycm9yLnN0YWNrLmluY2x1ZGVzKFwiaW52b2tlR3VhcmRlZENhbGxiYWNrRGV2XCIpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaGFuZGxlRXJyb3IoZXJyb3IsIG1lc3NhZ2UpO1xuICAgICAgICB9KTtcbiAgICAgICAgbGlzdGVuVG9VbmhhbmRsZWRSZWplY3Rpb24oZnVuY3Rpb24gKHByb21pc2VSZWplY3Rpb25FdmVudCkge1xuICAgICAgICAgICAgdmFyIHJlYXNvbiA9IHByb21pc2VSZWplY3Rpb25FdmVudC5yZWFzb247XG4gICAgICAgICAgICBoYW5kbGVFcnJvcihyZWFzb24sIFwiVW5rbm93biBwcm9taXNlIHJlamVjdGlvbiByZWFzb25cIik7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gb3ZlcmxheVNlcnZpY2U7XG59O1xuZXhwb3J0IHsgZm9ybWF0UHJvYmxlbSwgY3JlYXRlT3ZlcmxheSB9O1xuIiwiZnVuY3Rpb24gX3R5cGVvZihvKSB7XG4gICAgXCJAYmFiZWwvaGVscGVycyAtIHR5cGVvZlwiO1xuICAgIHJldHVybiBfdHlwZW9mID0gXCJmdW5jdGlvblwiID09IHR5cGVvZiBTeW1ib2wgJiYgXCJzeW1ib2xcIiA9PSB0eXBlb2YgU3ltYm9sLml0ZXJhdG9yID8gZnVuY3Rpb24gKG8pIHsgcmV0dXJuIHR5cGVvZiBvOyB9IDogZnVuY3Rpb24gKG8pIHsgcmV0dXJuIG8gJiYgXCJmdW5jdGlvblwiID09IHR5cGVvZiBTeW1ib2wgJiYgby5jb25zdHJ1Y3RvciA9PT0gU3ltYm9sICYmIG8gIT09IFN5bWJvbC5wcm90b3R5cGUgPyBcInN5bWJvbFwiIDogdHlwZW9mIG87IH0sIF90eXBlb2Yobyk7XG59XG5mdW5jdGlvbiBfY2xhc3NDYWxsQ2hlY2soYSwgbikgeyBpZiAoIShhIGluc3RhbmNlb2YgbikpXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBjYWxsIGEgY2xhc3MgYXMgYSBmdW5jdGlvblwiKTsgfVxuZnVuY3Rpb24gX2RlZmluZVByb3BlcnRpZXMoZSwgcikgeyBmb3IgKHZhciB0ID0gMDsgdCA8IHIubGVuZ3RoOyB0KyspIHtcbiAgICB2YXIgbyA9IHJbdF07XG4gICAgby5lbnVtZXJhYmxlID0gby5lbnVtZXJhYmxlIHx8ICExLCBvLmNvbmZpZ3VyYWJsZSA9ICEwLCBcInZhbHVlXCIgaW4gbyAmJiAoby53cml0YWJsZSA9ICEwKSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIF90b1Byb3BlcnR5S2V5KG8ua2V5KSwgbyk7XG59IH1cbmZ1bmN0aW9uIF9jcmVhdGVDbGFzcyhlLCByLCB0KSB7IHJldHVybiByICYmIF9kZWZpbmVQcm9wZXJ0aWVzKGUucHJvdG90eXBlLCByKSwgdCAmJiBfZGVmaW5lUHJvcGVydGllcyhlLCB0KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIFwicHJvdG90eXBlXCIsIHsgd3JpdGFibGU6ICExIH0pLCBlOyB9XG5mdW5jdGlvbiBfdG9Qcm9wZXJ0eUtleSh0KSB7IHZhciBpID0gX3RvUHJpbWl0aXZlKHQsIFwic3RyaW5nXCIpOyByZXR1cm4gXCJzeW1ib2xcIiA9PSBfdHlwZW9mKGkpID8gaSA6IGkgKyBcIlwiOyB9XG5mdW5jdGlvbiBfdG9QcmltaXRpdmUodCwgcikgeyBpZiAoXCJvYmplY3RcIiAhPSBfdHlwZW9mKHQpIHx8ICF0KVxuICAgIHJldHVybiB0OyB2YXIgZSA9IHRbU3ltYm9sLnRvUHJpbWl0aXZlXTsgaWYgKHZvaWQgMCAhPT0gZSkge1xuICAgIHZhciBpID0gZS5jYWxsKHQsIHIgfHwgXCJkZWZhdWx0XCIpO1xuICAgIGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YoaSkpXG4gICAgICAgIHJldHVybiBpO1xuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJAQHRvUHJpbWl0aXZlIG11c3QgcmV0dXJuIGEgcHJpbWl0aXZlIHZhbHVlLlwiKTtcbn0gcmV0dXJuIChcInN0cmluZ1wiID09PSByID8gU3RyaW5nIDogTnVtYmVyKSh0KTsgfVxuZnVuY3Rpb24gX2NhbGxTdXBlcih0LCBvLCBlKSB7IHJldHVybiBvID0gX2dldFByb3RvdHlwZU9mKG8pLCBfcG9zc2libGVDb25zdHJ1Y3RvclJldHVybih0LCBfaXNOYXRpdmVSZWZsZWN0Q29uc3RydWN0KCkgPyBSZWZsZWN0LmNvbnN0cnVjdChvLCBlIHx8IFtdLCBfZ2V0UHJvdG90eXBlT2YodCkuY29uc3RydWN0b3IpIDogby5hcHBseSh0LCBlKSk7IH1cbmZ1bmN0aW9uIF9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuKHQsIGUpIHsgaWYgKGUgJiYgKFwib2JqZWN0XCIgPT0gX3R5cGVvZihlKSB8fCBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIGUpKVxuICAgIHJldHVybiBlOyBpZiAodm9pZCAwICE9PSBlKVxuICAgIHRocm93IG5ldyBUeXBlRXJyb3IoXCJEZXJpdmVkIGNvbnN0cnVjdG9ycyBtYXkgb25seSByZXR1cm4gb2JqZWN0IG9yIHVuZGVmaW5lZFwiKTsgcmV0dXJuIF9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQodCk7IH1cbmZ1bmN0aW9uIF9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQoZSkgeyBpZiAodm9pZCAwID09PSBlKVxuICAgIHRocm93IG5ldyBSZWZlcmVuY2VFcnJvcihcInRoaXMgaGFzbid0IGJlZW4gaW5pdGlhbGlzZWQgLSBzdXBlcigpIGhhc24ndCBiZWVuIGNhbGxlZFwiKTsgcmV0dXJuIGU7IH1cbmZ1bmN0aW9uIF9pbmhlcml0cyh0LCBlKSB7IGlmIChcImZ1bmN0aW9uXCIgIT0gdHlwZW9mIGUgJiYgbnVsbCAhPT0gZSlcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3VwZXIgZXhwcmVzc2lvbiBtdXN0IGVpdGhlciBiZSBudWxsIG9yIGEgZnVuY3Rpb25cIik7IHQucHJvdG90eXBlID0gT2JqZWN0LmNyZWF0ZShlICYmIGUucHJvdG90eXBlLCB7IGNvbnN0cnVjdG9yOiB7IHZhbHVlOiB0LCB3cml0YWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAgfSB9KSwgT2JqZWN0LmRlZmluZVByb3BlcnR5KHQsIFwicHJvdG90eXBlXCIsIHsgd3JpdGFibGU6ICExIH0pLCBlICYmIF9zZXRQcm90b3R5cGVPZih0LCBlKTsgfVxuZnVuY3Rpb24gX3dyYXBOYXRpdmVTdXBlcih0KSB7IHZhciByID0gXCJmdW5jdGlvblwiID09IHR5cGVvZiBNYXAgPyBuZXcgTWFwKCkgOiB2b2lkIDA7IHJldHVybiBfd3JhcE5hdGl2ZVN1cGVyID0gZnVuY3Rpb24gX3dyYXBOYXRpdmVTdXBlcih0KSB7IGlmIChudWxsID09PSB0IHx8ICFfaXNOYXRpdmVGdW5jdGlvbih0KSlcbiAgICByZXR1cm4gdDsgaWYgKFwiZnVuY3Rpb25cIiAhPSB0eXBlb2YgdClcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiU3VwZXIgZXhwcmVzc2lvbiBtdXN0IGVpdGhlciBiZSBudWxsIG9yIGEgZnVuY3Rpb25cIik7IGlmICh2b2lkIDAgIT09IHIpIHtcbiAgICBpZiAoci5oYXModCkpXG4gICAgICAgIHJldHVybiByLmdldCh0KTtcbiAgICByLnNldCh0LCBXcmFwcGVyKTtcbn0gZnVuY3Rpb24gV3JhcHBlcigpIHsgcmV0dXJuIF9jb25zdHJ1Y3QodCwgYXJndW1lbnRzLCBfZ2V0UHJvdG90eXBlT2YodGhpcykuY29uc3RydWN0b3IpOyB9IHJldHVybiBXcmFwcGVyLnByb3RvdHlwZSA9IE9iamVjdC5jcmVhdGUodC5wcm90b3R5cGUsIHsgY29uc3RydWN0b3I6IHsgdmFsdWU6IFdyYXBwZXIsIGVudW1lcmFibGU6ICExLCB3cml0YWJsZTogITAsIGNvbmZpZ3VyYWJsZTogITAgfSB9KSwgX3NldFByb3RvdHlwZU9mKFdyYXBwZXIsIHQpOyB9LCBfd3JhcE5hdGl2ZVN1cGVyKHQpOyB9XG5mdW5jdGlvbiBfY29uc3RydWN0KHQsIGUsIHIpIHsgaWYgKF9pc05hdGl2ZVJlZmxlY3RDb25zdHJ1Y3QoKSlcbiAgICByZXR1cm4gUmVmbGVjdC5jb25zdHJ1Y3QuYXBwbHkobnVsbCwgYXJndW1lbnRzKTsgdmFyIG8gPSBbbnVsbF07IG8ucHVzaC5hcHBseShvLCBlKTsgdmFyIHAgPSBuZXcgKHQuYmluZC5hcHBseSh0LCBvKSkoKTsgcmV0dXJuIHIgJiYgX3NldFByb3RvdHlwZU9mKHAsIHIucHJvdG90eXBlKSwgcDsgfVxuZnVuY3Rpb24gX2lzTmF0aXZlUmVmbGVjdENvbnN0cnVjdCgpIHsgdHJ5IHtcbiAgICB2YXIgdCA9ICFCb29sZWFuLnByb3RvdHlwZS52YWx1ZU9mLmNhbGwoUmVmbGVjdC5jb25zdHJ1Y3QoQm9vbGVhbiwgW10sIGZ1bmN0aW9uICgpIHsgfSkpO1xufVxuY2F0Y2ggKHQpIHsgfSByZXR1cm4gKF9pc05hdGl2ZVJlZmxlY3RDb25zdHJ1Y3QgPSBmdW5jdGlvbiBfaXNOYXRpdmVSZWZsZWN0Q29uc3RydWN0KCkgeyByZXR1cm4gISF0OyB9KSgpOyB9XG5mdW5jdGlvbiBfaXNOYXRpdmVGdW5jdGlvbih0KSB7IHRyeSB7XG4gICAgcmV0dXJuIC0xICE9PSBGdW5jdGlvbi50b1N0cmluZy5jYWxsKHQpLmluZGV4T2YoXCJbbmF0aXZlIGNvZGVdXCIpO1xufVxuY2F0Y2ggKG4pIHtcbiAgICByZXR1cm4gXCJmdW5jdGlvblwiID09IHR5cGVvZiB0O1xufSB9XG5mdW5jdGlvbiBfc2V0UHJvdG90eXBlT2YodCwgZSkgeyByZXR1cm4gX3NldFByb3RvdHlwZU9mID0gT2JqZWN0LnNldFByb3RvdHlwZU9mID8gT2JqZWN0LnNldFByb3RvdHlwZU9mLmJpbmQoKSA6IGZ1bmN0aW9uICh0LCBlKSB7IHJldHVybiB0Ll9fcHJvdG9fXyA9IGUsIHQ7IH0sIF9zZXRQcm90b3R5cGVPZih0LCBlKTsgfVxuZnVuY3Rpb24gX2dldFByb3RvdHlwZU9mKHQpIHsgcmV0dXJuIF9nZXRQcm90b3R5cGVPZiA9IE9iamVjdC5zZXRQcm90b3R5cGVPZiA/IE9iamVjdC5nZXRQcm90b3R5cGVPZi5iaW5kKCkgOiBmdW5jdGlvbiAodCkgeyByZXR1cm4gdC5fX3Byb3RvX18gfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKHQpOyB9LCBfZ2V0UHJvdG90eXBlT2YodCk7IH1cbmZ1bmN0aW9uIF9jbGFzc1ByaXZhdGVNZXRob2RJbml0U3BlYyhlLCBhKSB7IF9jaGVja1ByaXZhdGVSZWRlY2xhcmF0aW9uKGUsIGEpLCBhLmFkZChlKTsgfVxuZnVuY3Rpb24gX2NoZWNrUHJpdmF0ZVJlZGVjbGFyYXRpb24oZSwgdCkgeyBpZiAodC5oYXMoZSkpXG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkNhbm5vdCBpbml0aWFsaXplIHRoZSBzYW1lIHByaXZhdGUgZWxlbWVudHMgdHdpY2Ugb24gYW4gb2JqZWN0XCIpOyB9XG5mdW5jdGlvbiBfYXNzZXJ0Q2xhc3NCcmFuZChlLCB0LCBuKSB7IGlmIChcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIGUgPyBlID09PSB0IDogZS5oYXModCkpXG4gICAgcmV0dXJuIGFyZ3VtZW50cy5sZW5ndGggPCAzID8gdCA6IG47IHRocm93IG5ldyBUeXBlRXJyb3IoXCJQcml2YXRlIGVsZW1lbnQgaXMgbm90IHByZXNlbnQgb24gdGhpcyBvYmplY3RcIik7IH1cbmV4cG9ydCBmdW5jdGlvbiBpc1Byb2dyZXNzU3VwcG9ydGVkKCkge1xuICAgIHJldHVybiBcImN1c3RvbUVsZW1lbnRzXCIgaW4gc2VsZiAmJiAhIUhUTUxFbGVtZW50LnByb3RvdHlwZS5hdHRhY2hTaGFkb3c7XG59XG5leHBvcnQgZnVuY3Rpb24gZGVmaW5lUHJvZ3Jlc3NFbGVtZW50KCkge1xuICAgIHZhciBfV2VicGFja0RldlNlcnZlclByb2dyZXNzO1xuICAgIGlmIChjdXN0b21FbGVtZW50cy5nZXQoXCJ3ZHMtcHJvZ3Jlc3NcIikpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgX1dlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzc19icmFuZCA9IC8qI19fUFVSRV9fKi8gbmV3IFdlYWtTZXQoKTtcbiAgICB2YXIgV2VicGFja0RldlNlcnZlclByb2dyZXNzID0gLyojX19QVVJFX18qLyBmdW5jdGlvbiAoX0hUTUxFbGVtZW50KSB7XG4gICAgICAgIGZ1bmN0aW9uIFdlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzcygpIHtcbiAgICAgICAgICAgIHZhciBfdGhpcztcbiAgICAgICAgICAgIF9jbGFzc0NhbGxDaGVjayh0aGlzLCBXZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3MpO1xuICAgICAgICAgICAgX3RoaXMgPSBfY2FsbFN1cGVyKHRoaXMsIFdlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzcyk7XG4gICAgICAgICAgICBfY2xhc3NQcml2YXRlTWV0aG9kSW5pdFNwZWMoX3RoaXMsIF9XZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3NfYnJhbmQpO1xuICAgICAgICAgICAgX3RoaXMuYXR0YWNoU2hhZG93KHtcbiAgICAgICAgICAgICAgICBtb2RlOiBcIm9wZW5cIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICBfdGhpcy5tYXhEYXNoT2Zmc2V0ID0gLTIxOS45OTA3ODM2OTE0MDYyNTtcbiAgICAgICAgICAgIF90aGlzLmFuaW1hdGlvblRpbWVyID0gbnVsbDtcbiAgICAgICAgICAgIHJldHVybiBfdGhpcztcbiAgICAgICAgfVxuICAgICAgICBfaW5oZXJpdHMoV2VicGFja0RldlNlcnZlclByb2dyZXNzLCBfSFRNTEVsZW1lbnQpO1xuICAgICAgICByZXR1cm4gX2NyZWF0ZUNsYXNzKFdlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzcywgW3tcbiAgICAgICAgICAgICAgICBrZXk6IFwiY29ubmVjdGVkQ2FsbGJhY2tcIixcbiAgICAgICAgICAgICAgICB2YWx1ZTogZnVuY3Rpb24gY29ubmVjdGVkQ2FsbGJhY2soKSB7XG4gICAgICAgICAgICAgICAgICAgIF9hc3NlcnRDbGFzc0JyYW5kKF9XZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3NfYnJhbmQsIHRoaXMsIF9yZXNldCkuY2FsbCh0aGlzKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAga2V5OiBcImF0dHJpYnV0ZUNoYW5nZWRDYWxsYmFja1wiLFxuICAgICAgICAgICAgICAgIHZhbHVlOiBmdW5jdGlvbiBhdHRyaWJ1dGVDaGFuZ2VkQ2FsbGJhY2sobmFtZSwgb2xkVmFsdWUsIG5ld1ZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChuYW1lID09PSBcInByb2dyZXNzXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hc3NlcnRDbGFzc0JyYW5kKF9XZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3NfYnJhbmQsIHRoaXMsIF91cGRhdGUpLmNhbGwodGhpcywgTnVtYmVyKG5ld1ZhbHVlKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAobmFtZSA9PT0gXCJ0eXBlXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9hc3NlcnRDbGFzc0JyYW5kKF9XZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3NfYnJhbmQsIHRoaXMsIF9yZXNldCkuY2FsbCh0aGlzKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1dLCBbe1xuICAgICAgICAgICAgICAgIGtleTogXCJvYnNlcnZlZEF0dHJpYnV0ZXNcIixcbiAgICAgICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uIGdldCgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFtcInByb2dyZXNzXCIsIFwidHlwZVwiXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XSk7XG4gICAgfSgvKiNfX1BVUkVfXyovIF93cmFwTmF0aXZlU3VwZXIoSFRNTEVsZW1lbnQpKTtcbiAgICBfV2VicGFja0RldlNlcnZlclByb2dyZXNzID0gV2VicGFja0RldlNlcnZlclByb2dyZXNzO1xuICAgIGZ1bmN0aW9uIF9yZXNldCgpIHtcbiAgICAgICAgdmFyIF90aGlzJGdldEF0dHJpYnV0ZSwgX051bWJlcjtcbiAgICAgICAgY2xlYXJUaW1lb3V0KHRoaXMuYW5pbWF0aW9uVGltZXIpO1xuICAgICAgICB0aGlzLmFuaW1hdGlvblRpbWVyID0gbnVsbDtcbiAgICAgICAgdmFyIHR5cGVBdHRyID0gKF90aGlzJGdldEF0dHJpYnV0ZSA9IHRoaXMuZ2V0QXR0cmlidXRlKFwidHlwZVwiKSkgPT09IG51bGwgfHwgX3RoaXMkZ2V0QXR0cmlidXRlID09PSB2b2lkIDAgPyB2b2lkIDAgOiBfdGhpcyRnZXRBdHRyaWJ1dGUudG9Mb3dlckNhc2UoKTtcbiAgICAgICAgdGhpcy50eXBlID0gdHlwZUF0dHIgPT09IFwiY2lyY3VsYXJcIiA/IFwiY2lyY3VsYXJcIiA6IFwibGluZWFyXCI7XG4gICAgICAgIHZhciBpbm5lckhUTUwgPSB0aGlzLnR5cGUgPT09IFwiY2lyY3VsYXJcIiA/IF9jaXJjdWxhclRlbXBsYXRlLmNhbGwoX1dlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzcykgOiBfbGluZWFyVGVtcGxhdGUuY2FsbChfV2VicGFja0RldlNlcnZlclByb2dyZXNzKTtcbiAgICAgICAgdGhpcy5zaGFkb3dSb290LmlubmVySFRNTCA9IGlubmVySFRNTDtcbiAgICAgICAgdGhpcy5pbml0aWFsUHJvZ3Jlc3MgPSAoX051bWJlciA9IE51bWJlcih0aGlzLmdldEF0dHJpYnV0ZShcInByb2dyZXNzXCIpKSkgIT09IG51bGwgJiYgX051bWJlciAhPT0gdm9pZCAwID8gX051bWJlciA6IDA7XG4gICAgICAgIF9hc3NlcnRDbGFzc0JyYW5kKF9XZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3NfYnJhbmQsIHRoaXMsIF91cGRhdGUpLmNhbGwodGhpcywgdGhpcy5pbml0aWFsUHJvZ3Jlc3MpO1xuICAgIH1cbiAgICBmdW5jdGlvbiBfY2lyY3VsYXJUZW1wbGF0ZSgpIHtcbiAgICAgICAgcmV0dXJuIFwiXFxuICAgICAgICA8c3R5bGU+XFxuICAgICAgICA6aG9zdCB7XFxuICAgICAgICAgICAgd2lkdGg6IDIwMHB4O1xcbiAgICAgICAgICAgIGhlaWdodDogMjAwcHg7XFxuICAgICAgICAgICAgcG9zaXRpb246IGZpeGVkO1xcbiAgICAgICAgICAgIHJpZ2h0OiA1JTtcXG4gICAgICAgICAgICB0b3A6IDUlO1xcbiAgICAgICAgICAgIHRyYW5zaXRpb246IG9wYWNpdHkgLjI1cyBlYXNlLWluLW91dDtcXG4gICAgICAgICAgICB6LWluZGV4OiAyMTQ3NDgzNjQ1O1xcbiAgICAgICAgfVxcblxcbiAgICAgICAgY2lyY2xlIHtcXG4gICAgICAgICAgICBmaWxsOiAjMjgyZDM1O1xcbiAgICAgICAgfVxcblxcbiAgICAgICAgcGF0aCB7XFxuICAgICAgICAgICAgZmlsbDogcmdiYSgwLCAwLCAwLCAwKTtcXG4gICAgICAgICAgICBzdHJva2U6IHJnYigxODYsIDIyMywgMTcyKTtcXG4gICAgICAgICAgICBzdHJva2UtZGFzaGFycmF5OiAyMTkuOTkwNzgzNjkxNDA2MjU7XFxuICAgICAgICAgICAgc3Ryb2tlLWRhc2hvZmZzZXQ6IC0yMTkuOTkwNzgzNjkxNDA2MjU7XFxuICAgICAgICAgICAgc3Ryb2tlLXdpZHRoOiAxMDtcXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHJvdGF0ZSg5MGRlZykgdHJhbnNsYXRlKDBweCwgLTgwcHgpO1xcbiAgICAgICAgfVxcblxcbiAgICAgICAgdGV4dCB7XFxuICAgICAgICAgICAgZm9udC1mYW1pbHk6ICdPcGVuIFNhbnMnLCBzYW5zLXNlcmlmO1xcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMThweDtcXG4gICAgICAgICAgICBmaWxsOiAjZmZmZmZmO1xcbiAgICAgICAgICAgIGRvbWluYW50LWJhc2VsaW5lOiBtaWRkbGU7XFxuICAgICAgICAgICAgdGV4dC1hbmNob3I6IG1pZGRsZTtcXG4gICAgICAgIH1cXG5cXG4gICAgICAgIHRzcGFuI3BlcmNlbnQtc3VwZXIge1xcbiAgICAgICAgICAgIGZpbGw6ICNiZGMzYzc7XFxuICAgICAgICAgICAgZm9udC1zaXplOiAwLjQ1ZW07XFxuICAgICAgICAgICAgYmFzZWxpbmUtc2hpZnQ6IDEwJTtcXG4gICAgICAgIH1cXG5cXG4gICAgICAgIEBrZXlmcmFtZXMgZmFkZSB7XFxuICAgICAgICAgICAgMCUgeyBvcGFjaXR5OiAxOyB0cmFuc2Zvcm06IHNjYWxlKDEpOyB9XFxuICAgICAgICAgICAgMTAwJSB7IG9wYWNpdHk6IDA7IHRyYW5zZm9ybTogc2NhbGUoMCk7IH1cXG4gICAgICAgIH1cXG5cXG4gICAgICAgIC5kaXNhcHBlYXIge1xcbiAgICAgICAgICAgIGFuaW1hdGlvbjogZmFkZSAwLjNzO1xcbiAgICAgICAgICAgIGFuaW1hdGlvbi1maWxsLW1vZGU6IGZvcndhcmRzO1xcbiAgICAgICAgICAgIGFuaW1hdGlvbi1kZWxheTogMC41cztcXG4gICAgICAgIH1cXG5cXG4gICAgICAgIC5oaWRkZW4ge1xcbiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7XFxuICAgICAgICB9XFxuICAgICAgICA8L3N0eWxlPlxcbiAgICAgICAgPHN2ZyBpZD1cXFwicHJvZ3Jlc3NcXFwiIGNsYXNzPVxcXCJoaWRkZW4gbm9zZWxlY3RcXFwiIHZpZXdCb3g9XFxcIjAgMCA4MCA4MFxcXCI+XFxuICAgICAgICA8Y2lyY2xlIGN4PVxcXCI1MCVcXFwiIGN5PVxcXCI1MCVcXFwiIHI9XFxcIjM1XFxcIj48L2NpcmNsZT5cXG4gICAgICAgIDxwYXRoIGQ9XFxcIk01LDQwYTM1LDM1IDAgMSwwIDcwLDBhMzUsMzUgMCAxLDAgLTcwLDBcXFwiPjwvcGF0aD5cXG4gICAgICAgIDx0ZXh0IHg9XFxcIjUwJVxcXCIgeT1cXFwiNTElXFxcIj5cXG4gICAgICAgICAgICA8dHNwYW4gaWQ9XFxcInBlcmNlbnQtdmFsdWVcXFwiPjA8L3RzcGFuPlxcbiAgICAgICAgICAgIDx0c3BhbiBpZD1cXFwicGVyY2VudC1zdXBlclxcXCI+JTwvdHNwYW4+XFxuICAgICAgICA8L3RleHQ+XFxuICAgICAgICA8L3N2Zz5cXG4gICAgICBcIjtcbiAgICB9XG4gICAgZnVuY3Rpb24gX2xpbmVhclRlbXBsYXRlKCkge1xuICAgICAgICByZXR1cm4gXCJcXG4gICAgICAgIDxzdHlsZT5cXG4gICAgICAgIDpob3N0IHtcXG4gICAgICAgICAgICBwb3NpdGlvbjogZml4ZWQ7XFxuICAgICAgICAgICAgdG9wOiAwO1xcbiAgICAgICAgICAgIGxlZnQ6IDA7XFxuICAgICAgICAgICAgaGVpZ2h0OiA0cHg7XFxuICAgICAgICAgICAgd2lkdGg6IDEwMHZ3O1xcbiAgICAgICAgICAgIHotaW5kZXg6IDIxNDc0ODM2NDU7XFxuICAgICAgICB9XFxuXFxuICAgICAgICAjYmFyIHtcXG4gICAgICAgICAgICB3aWR0aDogMCU7XFxuICAgICAgICAgICAgaGVpZ2h0OiA0cHg7XFxuICAgICAgICAgICAgYmFja2dyb3VuZC1jb2xvcjogcmdiKDE4NiwgMjIzLCAxNzIpO1xcbiAgICAgICAgfVxcblxcbiAgICAgICAgQGtleWZyYW1lcyBmYWRlIHtcXG4gICAgICAgICAgICAwJSB7IG9wYWNpdHk6IDE7IH1cXG4gICAgICAgICAgICAxMDAlIHsgb3BhY2l0eTogMDsgfVxcbiAgICAgICAgfVxcblxcbiAgICAgICAgLmRpc2FwcGVhciB7XFxuICAgICAgICAgICAgYW5pbWF0aW9uOiBmYWRlIDAuM3M7XFxuICAgICAgICAgICAgYW5pbWF0aW9uLWZpbGwtbW9kZTogZm9yd2FyZHM7XFxuICAgICAgICAgICAgYW5pbWF0aW9uLWRlbGF5OiAwLjVzO1xcbiAgICAgICAgfVxcblxcbiAgICAgICAgLmhpZGRlbiB7XFxuICAgICAgICAgICAgZGlzcGxheTogbm9uZTtcXG4gICAgICAgIH1cXG4gICAgICAgIDwvc3R5bGU+XFxuICAgICAgICA8ZGl2IGlkPVxcXCJwcm9ncmVzc1xcXCI+PC9kaXY+XFxuICAgICAgICBcIjtcbiAgICB9XG4gICAgZnVuY3Rpb24gX3VwZGF0ZShwZXJjZW50KSB7XG4gICAgICAgIHZhciBlbGVtZW50ID0gdGhpcy5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoXCIjcHJvZ3Jlc3NcIik7XG4gICAgICAgIGlmICh0aGlzLnR5cGUgPT09IFwiY2lyY3VsYXJcIikge1xuICAgICAgICAgICAgdmFyIHBhdGggPSB0aGlzLnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvcihcInBhdGhcIik7XG4gICAgICAgICAgICB2YXIgdmFsdWUgPSB0aGlzLnNoYWRvd1Jvb3QucXVlcnlTZWxlY3RvcihcIiNwZXJjZW50LXZhbHVlXCIpO1xuICAgICAgICAgICAgdmFyIG9mZnNldCA9ICgxMDAgLSBwZXJjZW50KSAvIDEwMCAqIHRoaXMubWF4RGFzaE9mZnNldDtcbiAgICAgICAgICAgIHBhdGguc3R5bGUuc3Ryb2tlRGFzaG9mZnNldCA9IG9mZnNldDtcbiAgICAgICAgICAgIHZhbHVlLnRleHRDb250ZW50ID0gcGVyY2VudDtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGVsZW1lbnQuc3R5bGUud2lkdGggPSBcIlwiLmNvbmNhdChwZXJjZW50LCBcIiVcIik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBlcmNlbnQgPj0gMTAwKSB7XG4gICAgICAgICAgICBfYXNzZXJ0Q2xhc3NCcmFuZChfV2VicGFja0RldlNlcnZlclByb2dyZXNzX2JyYW5kLCB0aGlzLCBfaGlkZSkuY2FsbCh0aGlzKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChwZXJjZW50ID4gMCkge1xuICAgICAgICAgICAgX2Fzc2VydENsYXNzQnJhbmQoX1dlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzc19icmFuZCwgdGhpcywgX3Nob3cpLmNhbGwodGhpcyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gX3Nob3coKSB7XG4gICAgICAgIHZhciBlbGVtZW50ID0gdGhpcy5zaGFkb3dSb290LnF1ZXJ5U2VsZWN0b3IoXCIjcHJvZ3Jlc3NcIik7XG4gICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShcImhpZGRlblwiKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gX2hpZGUoKSB7XG4gICAgICAgIHZhciBfdGhpczIgPSB0aGlzO1xuICAgICAgICB2YXIgZWxlbWVudCA9IHRoaXMuc2hhZG93Um9vdC5xdWVyeVNlbGVjdG9yKFwiI3Byb2dyZXNzXCIpO1xuICAgICAgICBpZiAodGhpcy50eXBlID09PSBcImNpcmN1bGFyXCIpIHtcbiAgICAgICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LmFkZChcImRpc2FwcGVhclwiKTtcbiAgICAgICAgICAgIGVsZW1lbnQuYWRkRXZlbnRMaXN0ZW5lcihcImFuaW1hdGlvbmVuZFwiLCBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiaGlkZGVuXCIpO1xuICAgICAgICAgICAgICAgIF9hc3NlcnRDbGFzc0JyYW5kKF9XZWJwYWNrRGV2U2VydmVyUHJvZ3Jlc3NfYnJhbmQsIF90aGlzMiwgX3VwZGF0ZSkuY2FsbChfdGhpczIsIDApO1xuICAgICAgICAgICAgfSwge1xuICAgICAgICAgICAgICAgIG9uY2U6IHRydWVcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKHRoaXMudHlwZSA9PT0gXCJsaW5lYXJcIikge1xuICAgICAgICAgICAgZWxlbWVudC5jbGFzc0xpc3QuYWRkKFwiZGlzYXBwZWFyXCIpO1xuICAgICAgICAgICAgdGhpcy5hbmltYXRpb25UaW1lciA9IHNldFRpbWVvdXQoZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIGVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZShcImRpc2FwcGVhclwiKTtcbiAgICAgICAgICAgICAgICBlbGVtZW50LmNsYXNzTGlzdC5hZGQoXCJoaWRkZW5cIik7XG4gICAgICAgICAgICAgICAgZWxlbWVudC5zdHlsZS53aWR0aCA9IFwiMCVcIjtcbiAgICAgICAgICAgICAgICBfdGhpczIuYW5pbWF0aW9uVGltZXIgPSBudWxsO1xuICAgICAgICAgICAgfSwgODAwKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjdXN0b21FbGVtZW50cy5kZWZpbmUoXCJ3ZHMtcHJvZ3Jlc3NcIiwgV2VicGFja0RldlNlcnZlclByb2dyZXNzKTtcbn1cbiIsIi8qIGdsb2JhbCBfX3dlYnBhY2tfZGV2X3NlcnZlcl9jbGllbnRfXyAqL1xuaW1wb3J0IFdlYlNvY2tldENsaWVudCBmcm9tIFwiLi9jbGllbnRzL1dlYlNvY2tldENsaWVudC5qc1wiO1xuaW1wb3J0IHsgbG9nIH0gZnJvbSBcIi4vdXRpbHMvbG9nLmpzXCI7XG4vLyB0aGlzIFdlYnNvY2tldENsaWVudCBpcyBoZXJlIGFzIGEgZGVmYXVsdCBmYWxsYmFjaywgaW4gY2FzZSB0aGUgY2xpZW50IGlzIG5vdCBpbmplY3RlZFxuLyogZXNsaW50LWRpc2FibGUgY2FtZWxjYXNlICovXG52YXIgQ2xpZW50ID0gXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tbmVzdGVkLXRlcm5hcnlcbnR5cGVvZiBfX3dlYnBhY2tfZGV2X3NlcnZlcl9jbGllbnRfXyAhPT0gXCJ1bmRlZmluZWRcIiA/IHR5cGVvZiBfX3dlYnBhY2tfZGV2X3NlcnZlcl9jbGllbnRfXy5kZWZhdWx0ICE9PSBcInVuZGVmaW5lZFwiID8gX193ZWJwYWNrX2Rldl9zZXJ2ZXJfY2xpZW50X18uZGVmYXVsdCA6IF9fd2VicGFja19kZXZfc2VydmVyX2NsaWVudF9fIDogV2ViU29ja2V0Q2xpZW50O1xuLyogZXNsaW50LWVuYWJsZSBjYW1lbGNhc2UgKi9cbnZhciByZXRyaWVzID0gMDtcbnZhciBtYXhSZXRyaWVzID0gMTA7XG4vLyBJbml0aWFsaXplZCBjbGllbnQgaXMgZXhwb3J0ZWQgc28gZXh0ZXJuYWwgY29uc3VtZXJzIGNhbiB1dGlsaXplIHRoZSBzYW1lIGluc3RhbmNlXG4vLyBJdCBpcyBtdXRhYmxlIHRvIGVuZm9yY2Ugc2luZ2xldG9uXG4vLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgaW1wb3J0L25vLW11dGFibGUtZXhwb3J0c1xuZXhwb3J0IHZhciBjbGllbnQgPSBudWxsO1xudmFyIHRpbWVvdXQ7XG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmxcbiAqIEBwYXJhbSB7eyBbaGFuZGxlcjogc3RyaW5nXTogKGRhdGE/OiBhbnksIHBhcmFtcz86IGFueSkgPT4gYW55IH19IGhhbmRsZXJzXG4gKiBAcGFyYW0ge251bWJlcn0gW3JlY29ubmVjdF1cbiAqL1xudmFyIHNvY2tldCA9IGZ1bmN0aW9uIGluaXRTb2NrZXQodXJsLCBoYW5kbGVycywgcmVjb25uZWN0KSB7XG4gICAgY2xpZW50ID0gbmV3IENsaWVudCh1cmwpO1xuICAgIGNsaWVudC5vbk9wZW4oZnVuY3Rpb24gKCkge1xuICAgICAgICByZXRyaWVzID0gMDtcbiAgICAgICAgaWYgKHRpbWVvdXQpIHtcbiAgICAgICAgICAgIGNsZWFyVGltZW91dCh0aW1lb3V0KTtcbiAgICAgICAgfVxuICAgICAgICBpZiAodHlwZW9mIHJlY29ubmVjdCAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgICAgICAgICAgbWF4UmV0cmllcyA9IHJlY29ubmVjdDtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIGNsaWVudC5vbkNsb3NlKGZ1bmN0aW9uICgpIHtcbiAgICAgICAgaWYgKHJldHJpZXMgPT09IDApIHtcbiAgICAgICAgICAgIGhhbmRsZXJzLmNsb3NlKCk7XG4gICAgICAgIH1cbiAgICAgICAgLy8gVHJ5IHRvIHJlY29ubmVjdC5cbiAgICAgICAgY2xpZW50ID0gbnVsbDtcbiAgICAgICAgLy8gQWZ0ZXIgMTAgcmV0cmllcyBzdG9wIHRyeWluZywgdG8gcHJldmVudCBsb2dzcGFtLlxuICAgICAgICBpZiAocmV0cmllcyA8IG1heFJldHJpZXMpIHtcbiAgICAgICAgICAgIC8vIEV4cG9uZW50aWFsbHkgaW5jcmVhc2UgdGltZW91dCB0byByZWNvbm5lY3QuXG4gICAgICAgICAgICAvLyBSZXNwZWN0ZnVsbHkgY29waWVkIGZyb20gdGhlIHBhY2thZ2UgYGdvdGAuXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tcmVzdHJpY3RlZC1wcm9wZXJ0aWVzXG4gICAgICAgICAgICB2YXIgcmV0cnlJbk1zID0gMTAwMCAqIE1hdGgucG93KDIsIHJldHJpZXMpICsgTWF0aC5yYW5kb20oKSAqIDEwMDtcbiAgICAgICAgICAgIHJldHJpZXMgKz0gMTtcbiAgICAgICAgICAgIGxvZy5pbmZvKFwiVHJ5aW5nIHRvIHJlY29ubmVjdC4uLlwiKTtcbiAgICAgICAgICAgIHRpbWVvdXQgPSBzZXRUaW1lb3V0KGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBzb2NrZXQodXJsLCBoYW5kbGVycywgcmVjb25uZWN0KTtcbiAgICAgICAgICAgIH0sIHJldHJ5SW5Ncyk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICBjbGllbnQub25NZXNzYWdlKFxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7YW55fSBkYXRhXG4gICAgICovXG4gICAgZnVuY3Rpb24gKGRhdGEpIHtcbiAgICAgICAgdmFyIG1lc3NhZ2UgPSBKU09OLnBhcnNlKGRhdGEpO1xuICAgICAgICBpZiAoaGFuZGxlcnNbbWVzc2FnZS50eXBlXSkge1xuICAgICAgICAgICAgaGFuZGxlcnNbbWVzc2FnZS50eXBlXShtZXNzYWdlLmRhdGEsIG1lc3NhZ2UucGFyYW1zKTtcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbmV4cG9ydCBkZWZhdWx0IHNvY2tldDtcbiIsImltcG9ydCBsb2dnZXIgZnJvbSBcIi4uL21vZHVsZXMvbG9nZ2VyL2luZGV4LmpzXCI7XG52YXIgbmFtZSA9IFwid2VicGFjay1kZXYtc2VydmVyXCI7XG4vLyBkZWZhdWx0IGxldmVsIGlzIHNldCBvbiB0aGUgY2xpZW50IHNpZGUsIHNvIGl0IGRvZXMgbm90IG5lZWRcbi8vIHRvIGJlIHNldCBieSB0aGUgQ0xJIG9yIEFQSVxudmFyIGRlZmF1bHRMZXZlbCA9IFwiaW5mb1wiO1xuLy8gb3B0aW9ucyBuZXcgb3B0aW9ucywgbWVyZ2Ugd2l0aCBvbGQgb3B0aW9uc1xuLyoqXG4gKiBAcGFyYW0ge2ZhbHNlIHwgdHJ1ZSB8IFwibm9uZVwiIHwgXCJlcnJvclwiIHwgXCJ3YXJuXCIgfCBcImluZm9cIiB8IFwibG9nXCIgfCBcInZlcmJvc2VcIn0gbGV2ZWxcbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5mdW5jdGlvbiBzZXRMb2dMZXZlbChsZXZlbCkge1xuICAgIGxvZ2dlci5jb25maWd1cmVEZWZhdWx0TG9nZ2VyKHtcbiAgICAgICAgbGV2ZWw6IGxldmVsXG4gICAgfSk7XG59XG5zZXRMb2dMZXZlbChkZWZhdWx0TGV2ZWwpO1xudmFyIGxvZyA9IGxvZ2dlci5nZXRMb2dnZXIobmFtZSk7XG5leHBvcnQgeyBsb2csIHNldExvZ0xldmVsIH07XG4iLCIvKiBnbG9iYWwgX19yZXNvdXJjZVF1ZXJ5IFdvcmtlckdsb2JhbFNjb3BlICovXG4vLyBTZW5kIG1lc3NhZ2VzIHRvIHRoZSBvdXRzaWRlLCBzbyBwbHVnaW5zIGNhbiBjb25zdW1lIGl0LlxuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gdHlwZVxuICogQHBhcmFtIHthbnl9IFtkYXRhXVxuICovXG5mdW5jdGlvbiBzZW5kTXNnKHR5cGUsIGRhdGEpIHtcbiAgICBpZiAodHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgJiYgKHR5cGVvZiBXb3JrZXJHbG9iYWxTY29wZSA9PT0gXCJ1bmRlZmluZWRcIiB8fCAhKHNlbGYgaW5zdGFuY2VvZiBXb3JrZXJHbG9iYWxTY29wZSkpKSB7XG4gICAgICAgIHNlbGYucG9zdE1lc3NhZ2Uoe1xuICAgICAgICAgICAgdHlwZTogXCJ3ZWJwYWNrXCIuY29uY2F0KHR5cGUpLFxuICAgICAgICAgICAgZGF0YTogZGF0YVxuICAgICAgICB9LCBcIipcIik7XG4gICAgfVxufVxuZXhwb3J0IGRlZmF1bHQgc2VuZE1zZztcbiIsIlwidXNlIHN0cmljdFwiO1xudmFyIEV2ZW50RW1pdHRlciA9IHJlcXVpcmUoXCJldmVudHNcIik7XG5tb2R1bGUuZXhwb3J0cyA9IG5ldyBFdmVudEVtaXR0ZXIoKTtcbiIsIlwidXNlIHN0cmljdFwiO1xuLyoqIEB0eXBlZGVmIHtcImluZm9cIiB8IFwid2FybmluZ1wiIHwgXCJlcnJvclwifSBMb2dMZXZlbCAqL1xuLyoqIEB0eXBlIHtMb2dMZXZlbH0gKi9cbnZhciBsb2dMZXZlbCA9IFwiaW5mb1wiO1xuZnVuY3Rpb24gZHVtbXkoKSB7IH1cbi8qKlxuICogQHBhcmFtIHtMb2dMZXZlbH0gbGV2ZWwgbG9nIGxldmVsXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gdHJ1ZSwgaWYgc2hvdWxkIGxvZ1xuICovXG5mdW5jdGlvbiBzaG91bGRMb2cobGV2ZWwpIHtcbiAgICB2YXIgc2hvdWxkTG9nID0gKGxvZ0xldmVsID09PSBcImluZm9cIiAmJiBsZXZlbCA9PT0gXCJpbmZvXCIpIHx8XG4gICAgICAgIChbXCJpbmZvXCIsIFwid2FybmluZ1wiXS5pbmRleE9mKGxvZ0xldmVsKSA+PSAwICYmIGxldmVsID09PSBcIndhcm5pbmdcIikgfHxcbiAgICAgICAgKFtcImluZm9cIiwgXCJ3YXJuaW5nXCIsIFwiZXJyb3JcIl0uaW5kZXhPZihsb2dMZXZlbCkgPj0gMCAmJiBsZXZlbCA9PT0gXCJlcnJvclwiKTtcbiAgICByZXR1cm4gc2hvdWxkTG9nO1xufVxuLyoqXG4gKiBAcGFyYW0geyhtc2c/OiBzdHJpbmcpID0+IHZvaWR9IGxvZ0ZuIGxvZyBmdW5jdGlvblxuICogQHJldHVybnMgeyhsZXZlbDogTG9nTGV2ZWwsIG1zZz86IHN0cmluZykgPT4gdm9pZH0gZnVuY3Rpb24gdGhhdCBsb2dzIHdoZW4gbG9nIGxldmVsIGlzIHN1ZmZpY2llbnRcbiAqL1xuZnVuY3Rpb24gbG9nR3JvdXAobG9nRm4pIHtcbiAgICByZXR1cm4gZnVuY3Rpb24gKGxldmVsLCBtc2cpIHtcbiAgICAgICAgaWYgKHNob3VsZExvZyhsZXZlbCkpIHtcbiAgICAgICAgICAgIGxvZ0ZuKG1zZyk7XG4gICAgICAgIH1cbiAgICB9O1xufVxuLyoqXG4gKiBAcGFyYW0ge0xvZ0xldmVsfSBsZXZlbCBsb2cgbGV2ZWxcbiAqIEBwYXJhbSB7c3RyaW5nfEVycm9yfSBtc2cgbWVzc2FnZVxuICovXG5tb2R1bGUuZXhwb3J0cyA9IGZ1bmN0aW9uIChsZXZlbCwgbXNnKSB7XG4gICAgaWYgKHNob3VsZExvZyhsZXZlbCkpIHtcbiAgICAgICAgaWYgKGxldmVsID09PSBcImluZm9cIikge1xuICAgICAgICAgICAgY29uc29sZS5sb2cobXNnKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmIChsZXZlbCA9PT0gXCJ3YXJuaW5nXCIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUud2Fybihtc2cpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGxldmVsID09PSBcImVycm9yXCIpIHtcbiAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IobXNnKTtcbiAgICAgICAgfVxuICAgIH1cbn07XG4vKipcbiAqIEBwYXJhbSB7RXJyb3J9IGVyciBlcnJvclxuICogQHJldHVybnMge3N0cmluZ30gZm9ybWF0dGVkIGVycm9yXG4gKi9cbm1vZHVsZS5leHBvcnRzLmZvcm1hdEVycm9yID0gZnVuY3Rpb24gKGVycikge1xuICAgIHZhciBtZXNzYWdlID0gZXJyLm1lc3NhZ2U7XG4gICAgdmFyIHN0YWNrID0gZXJyLnN0YWNrO1xuICAgIGlmICghc3RhY2spIHtcbiAgICAgICAgcmV0dXJuIG1lc3NhZ2U7XG4gICAgfVxuICAgIGVsc2UgaWYgKHN0YWNrLmluZGV4T2YobWVzc2FnZSkgPCAwKSB7XG4gICAgICAgIHJldHVybiBtZXNzYWdlICsgXCJcXG5cIiArIHN0YWNrO1xuICAgIH1cbiAgICByZXR1cm4gc3RhY2s7XG59O1xudmFyIGdyb3VwID0gY29uc29sZS5ncm91cCB8fCBkdW1teTtcbnZhciBncm91cENvbGxhcHNlZCA9IGNvbnNvbGUuZ3JvdXBDb2xsYXBzZWQgfHwgZHVtbXk7XG52YXIgZ3JvdXBFbmQgPSBjb25zb2xlLmdyb3VwRW5kIHx8IGR1bW15O1xubW9kdWxlLmV4cG9ydHMuZ3JvdXAgPSBsb2dHcm91cChncm91cCk7XG5tb2R1bGUuZXhwb3J0cy5ncm91cENvbGxhcHNlZCA9IGxvZ0dyb3VwKGdyb3VwQ29sbGFwc2VkKTtcbm1vZHVsZS5leHBvcnRzLmdyb3VwRW5kID0gbG9nR3JvdXAoZ3JvdXBFbmQpO1xuLyoqXG4gKiBAcGFyYW0ge0xvZ0xldmVsfSBsZXZlbCBsb2cgbGV2ZWxcbiAqL1xubW9kdWxlLmV4cG9ydHMuc2V0TG9nTGV2ZWwgPSBmdW5jdGlvbiAobGV2ZWwpIHtcbiAgICBsb2dMZXZlbCA9IGxldmVsO1xufTtcbiIsImltcG9ydCB7IGdldENvb2tpZSwgbG9nLCBzdG9yYWdlIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgZ2V0Q3VycmVudEJyZWFrcG9pbnQgfSBmcm9tICcuL2RldGVjdC9kZXRlY3QtYnJlYWtwb2ludCc7XG4vKipcbiAqIExvZyB0aGUgcmVhc29uIHdoeSBhZHZlcnRzIGFyZSBkaXNhYmxlZFxuICpcbiAqIEBwYXJhbSB0cnVlQ29uZGl0aW9ucyAtIG5vcm1hbGx5IHRydWUgY29uZGl0aW9ucywgbG9nIGlmIGZhbHNlXG4gKiBAcGFyYW0gZmFsc2VDb25kaXRpb25zIC0gbm9ybWFsbHkgZmFsc2UgY29uZGl0aW9ucywgbG9nIGlmIHRydWVcbiAqL1xuZnVuY3Rpb24gYWRzRGlzYWJsZWRMb2dnZXIodHJ1ZUNvbmRpdGlvbnMsIGZhbHNlQ29uZGl0aW9ucykge1xuICAgIGNvbnN0IG5vQWRzTG9nID0gKGNvbmRpdGlvbiwgdmFsdWUpID0+IGxvZygnY29tbWVyY2lhbCcsIGBBZHZlcnRzIGFyZSBub3Qgc2hvd24gYmVjYXVzZSAke2NvbmRpdGlvbn0gPSAke1N0cmluZyh2YWx1ZSl9YCk7XG4gICAgZm9yIChjb25zdCBbY29uZGl0aW9uLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXModHJ1ZUNvbmRpdGlvbnMpKSB7XG4gICAgICAgIGlmICghdmFsdWUpXG4gICAgICAgICAgICBub0Fkc0xvZyhjb25kaXRpb24sIHZhbHVlKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBbY29uZGl0aW9uLCB2YWx1ZV0gb2YgT2JqZWN0LmVudHJpZXMoZmFsc2VDb25kaXRpb25zKSkge1xuICAgICAgICBpZiAodmFsdWUpXG4gICAgICAgICAgICBub0Fkc0xvZyhjb25kaXRpb24sIHZhbHVlKTtcbiAgICB9XG59XG4vKipcbiAqIEFkIGZyZWUgY29va2llIGhlbHBlcnNcbiAqL1xuY29uc3QgQURfRlJFRV9VU0VSX0NPT0tJRSA9ICdHVV9BRjEnO1xuY29uc3QgZ2V0QWRGcmVlQ29va2llID0gKCkgPT4gZ2V0Q29va2llKHsgbmFtZTogQURfRlJFRV9VU0VSX0NPT0tJRSB9KTtcbmNvbnN0IGFkRnJlZURhdGFJc1ByZXNlbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgY29va2llVmFsID0gZ2V0QWRGcmVlQ29va2llKCk7XG4gICAgaWYgKCFjb29raWVWYWwpXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICByZXR1cm4gIU51bWJlci5pc05hTihwYXJzZUludChjb29raWVWYWwsIDEwKSk7XG59O1xuLyoqXG4gKiBEZXRlcm1pbmUgd2hldGhlciBjdXJyZW50IGJyb3dzZXIgaXMgYSB2ZXJzaW9uIG9mIEludGVybmV0IEV4cGxvcmVyXG4gKi9cbmNvbnN0IGlzSW50ZXJuZXRFeHBsb3JlciA9ICgpID0+IHtcbiAgICByZXR1cm4gISFuYXZpZ2F0b3IudXNlckFnZW50Lm1hdGNoKC9NU0lFfFRyaWRlbnQvZyk/Lmxlbmd0aDtcbn07XG5jb25zdCBESUdJVEFMX1NVQlNDUklCRVJfQ09PS0lFID0gJ2d1X2RpZ2l0YWxfc3Vic2NyaWJlcic7XG5jb25zdCBpc0RpZ2l0YWxTdWJzY3JpYmVyID0gKCkgPT4gZ2V0Q29va2llKHsgbmFtZTogRElHSVRBTF9TVUJTQ1JJQkVSX0NPT0tJRSB9KSA9PT0gJ3RydWUnO1xuY29uc3QgaXNBZEZyZWVVc2VyID0gKCkgPT4gaXNEaWdpdGFsU3Vic2NyaWJlcigpIHx8IGFkRnJlZURhdGFJc1ByZXNlbnQoKTtcbmNvbnN0IGlzVXNlclByZWZzQWRzT2ZmID0gKCkgPT4gc3RvcmFnZS5sb2NhbC5nZXQoYGd1LnByZWZzLnN3aXRjaC5hZHZlcnRzYCkgPT09IGZhbHNlO1xuLy8gSGF2aW5nIGEgY29uc3RydWN0b3IgbWVhbnMgd2UgY2FuIGVhc2lseSByZS1pbnN0YW50aWF0ZSB0aGUgb2JqZWN0IGluIGEgdGVzdFxuY2xhc3MgQ29tbWVyY2lhbEZlYXR1cmVzIHtcbiAgICBzaG91bGRMb2FkR29vZ2xldGFnO1xuICAgIGlzU2VjdXJlQ29udGFjdDtcbiAgICBhcnRpY2xlQm9keUFkdmVydHM7XG4gICAgY2Fycm90VHJhZmZpY0RyaXZlcjtcbiAgICBoaWdoTWVyY2g7XG4gICAgdGhpcmRQYXJ0eVRhZ3M7XG4gICAgY29tbWVudEFkdmVydHM7XG4gICAgbGl2ZWJsb2dBZHZlcnRzO1xuICAgIGFkRnJlZTtcbiAgICBjb21zY29yZTtcbiAgICB5b3V0dWJlQWR2ZXJ0aXNpbmc7XG4gICAgZm9vdGJhbGxGaXh0dXJlc0FkdmVydHM7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIC8vIHRoaXMgaXMgdXNlZCBmb3IgU3BlZWRDdXJ2ZSB0ZXN0c1xuICAgICAgICBjb25zdCBub2Fkc1VybCA9IC9bIyZdbm9hZHMoJi4qKT8kLy50ZXN0KHdpbmRvdy5sb2NhdGlvbi5oYXNoKTtcbiAgICAgICAgY29uc3QgZm9yY2VBZEZyZWUgPSAvWyMmXW5vYWRzYWYoJi4qKT8kLy50ZXN0KHdpbmRvdy5sb2NhdGlvbi5oYXNoKTtcbiAgICAgICAgY29uc3QgZm9yY2VBZHMgPSAvWz8mXWZvcmNlYWRzKCYuKik/JC8udGVzdCh3aW5kb3cubG9jYXRpb24uc2VhcmNoKTtcbiAgICAgICAgY29uc3QgZXh0ZXJuYWxBZHZlcnRpc2luZyA9ICFub2Fkc1VybCAmJiAhaXNVc2VyUHJlZnNBZHNPZmYoKTtcbiAgICAgICAgY29uc3Qgc2Vuc2l0aXZlQ29udGVudCA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5zaG91bGRIaWRlQWR2ZXJ0cyB8fFxuICAgICAgICAgICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNlY3Rpb24gPT09ICdjaGlsZHJlbnMtYm9va3Mtc2l0ZSc7XG4gICAgICAgIGNvbnN0IGlzTWludXRlQXJ0aWNsZSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5pc01pbnV0ZUFydGljbGU7XG4gICAgICAgIGNvbnN0IGlzQXJ0aWNsZSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5jb250ZW50VHlwZSA9PT0gJ0FydGljbGUnO1xuICAgICAgICBjb25zdCBpc0ludGVyYWN0aXZlID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmNvbnRlbnRUeXBlID09PSAnSW50ZXJhY3RpdmUnO1xuICAgICAgICBjb25zdCBpc0xpdmVCbG9nID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzTGl2ZUJsb2c7XG4gICAgICAgIGNvbnN0IGlzSG9zdGVkID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzSG9zdGVkO1xuICAgICAgICBjb25zdCBpc0lkZW50aXR5UGFnZSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5jb250ZW50VHlwZSA9PT0gJ0lkZW50aXR5JyB8fFxuICAgICAgICAgICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNlY3Rpb24gPT09ICdpZGVudGl0eSc7IC8vIG5lZWRlZCBmb3IgcGFnZXMgdW5kZXIgcHJvZmlsZS4qIHN1YmRvbWFpblxuICAgICAgICBjb25zdCBzd2l0Y2hlcyA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcuc3dpdGNoZXM7XG4gICAgICAgIGNvbnN0IGlzV2lkZVBhZ2UgPSBnZXRDdXJyZW50QnJlYWtwb2ludCgpID09PSAnd2lkZSc7XG4gICAgICAgIGNvbnN0IG5ld1JlY2lwZURlc2lnbiA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5zaG93TmV3UmVjaXBlRGVzaWduO1xuICAgICAgICBjb25zdCBpc1Vuc3VwcG9ydGVkQnJvd3NlciA9IGlzSW50ZXJuZXRFeHBsb3JlcigpO1xuICAgICAgICAvLyBEZXRlY3QgcHJlc2VuY2Ugb2Ygc3BhY2UgZm9yIGZvb3RiYWxsLXJpZ2h0IGFkIHNsb3RcbiAgICAgICAgY29uc3QgeyBwYWdlSWQgfSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZTtcbiAgICAgICAgY29uc3QgaXNGb290YmFsbFBhZ2UgPSBwYWdlSWQuc3RhcnRzV2l0aCgnZm9vdGJhbGwvJyk7XG4gICAgICAgIGNvbnN0IGlzUGFnZVdpdGhSaWdodEFkU3BhY2UgPSBwYWdlSWQuZW5kc1dpdGgoJy9maXh0dXJlcycpIHx8XG4gICAgICAgICAgICBwYWdlSWQuZW5kc1dpdGgoJy9saXZlJykgfHxcbiAgICAgICAgICAgIHBhZ2VJZC5lbmRzV2l0aCgnL3Jlc3VsdHMnKSB8fFxuICAgICAgICAgICAgcGFnZUlkLmVuZHNXaXRoKCcvdGFibGVzJykgfHxcbiAgICAgICAgICAgIHBhZ2VJZC5lbmRzV2l0aCgnL3RhYmxlJyk7XG4gICAgICAgIHRoaXMuZm9vdGJhbGxGaXh0dXJlc0FkdmVydHMgPSBpc0Zvb3RiYWxsUGFnZSAmJiBpc1BhZ2VXaXRoUmlnaHRBZFNwYWNlO1xuICAgICAgICB0aGlzLmlzU2VjdXJlQ29udGFjdCA9IFtcbiAgICAgICAgICAgICdoZWxwL25nLWludGVyYWN0aXZlLzIwMTcvbWFyLzE3L2NvbnRhY3QtdGhlLWd1YXJkaWFuLXNlY3VyZWx5JyxcbiAgICAgICAgICAgICdoZWxwLzIwMTYvc2VwLzE5L2hvdy10by1jb250YWN0LXRoZS1ndWFyZGlhbi1zZWN1cmVseScsXG4gICAgICAgIF0uaW5jbHVkZXMod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnBhZ2VJZCk7XG4gICAgICAgIC8vIEZlYXR1cmUgc3dpdGNoZXNcbiAgICAgICAgdGhpcy5hZEZyZWUgPSAhIWZvcmNlQWRGcmVlIHx8IGlzQWRGcmVlVXNlcigpO1xuICAgICAgICB0aGlzLnlvdXR1YmVBZHZlcnRpc2luZyA9ICF0aGlzLmFkRnJlZSAmJiAhc2Vuc2l0aXZlQ29udGVudDtcbiAgICAgICAgY29uc3Qgc2hvdWxkTG9hZEdvb2dsZXRhZ1RydWVDb25kaXRpb25zID0ge1xuICAgICAgICAgICAgJ3N3aXRjaGVzLnNob3VsZExvYWRHb29nbGV0YWcnOiAhIXN3aXRjaGVzLnNob3VsZExvYWRHb29nbGV0YWcsXG4gICAgICAgICAgICBleHRlcm5hbEFkdmVydGlzaW5nLFxuICAgICAgICB9O1xuICAgICAgICBjb25zdCBzaG91bGRMb2FkR29vZ2xldGFnRmFsc2VDb25kaXRpb25zID0ge1xuICAgICAgICAgICAgc2Vuc2l0aXZlQ29udGVudCxcbiAgICAgICAgICAgIGlzSWRlbnRpdHlQYWdlLFxuICAgICAgICAgICAgYWRGcmVlOiB0aGlzLmFkRnJlZSxcbiAgICAgICAgICAgIGlzVW5zdXBwb3J0ZWRCcm93c2VyLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLnNob3VsZExvYWRHb29nbGV0YWcgPVxuICAgICAgICAgICAgZm9yY2VBZHMgfHxcbiAgICAgICAgICAgICAgICAoT2JqZWN0LnZhbHVlcyhzaG91bGRMb2FkR29vZ2xldGFnVHJ1ZUNvbmRpdGlvbnMpLmV2ZXJ5KEJvb2xlYW4pICYmXG4gICAgICAgICAgICAgICAgICAgICFPYmplY3QudmFsdWVzKHNob3VsZExvYWRHb29nbGV0YWdGYWxzZUNvbmRpdGlvbnMpLnNvbWUoQm9vbGVhbikpO1xuICAgICAgICBpZiAoIXRoaXMuc2hvdWxkTG9hZEdvb2dsZXRhZykge1xuICAgICAgICAgICAgYWRzRGlzYWJsZWRMb2dnZXIoc2hvdWxkTG9hZEdvb2dsZXRhZ1RydWVDb25kaXRpb25zLCBzaG91bGRMb2FkR29vZ2xldGFnRmFsc2VDb25kaXRpb25zKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBhcnRpY2xlQm9keUFkdmVydHNUcnVlQ29uZGl0aW9ucyA9IHtcbiAgICAgICAgICAgIGlzQXJ0aWNsZSxcbiAgICAgICAgfTtcbiAgICAgICAgY29uc3QgYXJ0aWNsZUJvZHlBZHZlcnRzRmFsc2VDb25kaXRpb25zID0ge1xuICAgICAgICAgICAgaXNNaW51dGVBcnRpY2xlLFxuICAgICAgICAgICAgaXNMaXZlQmxvZzogISFpc0xpdmVCbG9nLFxuICAgICAgICAgICAgaXNIb3N0ZWQsXG4gICAgICAgICAgICBuZXdSZWNpcGVEZXNpZ246ICEhbmV3UmVjaXBlRGVzaWduLFxuICAgICAgICB9O1xuICAgICAgICB0aGlzLmFydGljbGVCb2R5QWR2ZXJ0cyA9XG4gICAgICAgICAgICB0aGlzLnNob3VsZExvYWRHb29nbGV0YWcgJiZcbiAgICAgICAgICAgICAgICAhdGhpcy5hZEZyZWUgJiZcbiAgICAgICAgICAgICAgICBPYmplY3QudmFsdWVzKGFydGljbGVCb2R5QWR2ZXJ0c1RydWVDb25kaXRpb25zKS5ldmVyeShCb29sZWFuKSAmJlxuICAgICAgICAgICAgICAgICFPYmplY3QudmFsdWVzKGFydGljbGVCb2R5QWR2ZXJ0c0ZhbHNlQ29uZGl0aW9ucykuc29tZShCb29sZWFuKTtcbiAgICAgICAgaWYgKGlzQXJ0aWNsZSAmJiAhdGhpcy5hcnRpY2xlQm9keUFkdmVydHMpIHtcbiAgICAgICAgICAgIC8vIExvZyB3aHkgYXJ0aWNsZSBhZHZlcnRzIGFyZSBkaXNhYmxlZFxuICAgICAgICAgICAgYWRzRGlzYWJsZWRMb2dnZXIoYXJ0aWNsZUJvZHlBZHZlcnRzVHJ1ZUNvbmRpdGlvbnMsIGFydGljbGVCb2R5QWR2ZXJ0c0ZhbHNlQ29uZGl0aW9ucyk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5jYXJyb3RUcmFmZmljRHJpdmVyID1cbiAgICAgICAgICAgICF0aGlzLmFkRnJlZSAmJlxuICAgICAgICAgICAgICAgIHRoaXMuYXJ0aWNsZUJvZHlBZHZlcnRzICYmXG4gICAgICAgICAgICAgICAgIXdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5pc1BhaWRDb250ZW50O1xuICAgICAgICB0aGlzLmhpZ2hNZXJjaCA9XG4gICAgICAgICAgICB0aGlzLnNob3VsZExvYWRHb29nbGV0YWcgJiZcbiAgICAgICAgICAgICAgICAhdGhpcy5hZEZyZWUgJiZcbiAgICAgICAgICAgICAgICAhaXNNaW51dGVBcnRpY2xlICYmXG4gICAgICAgICAgICAgICAgIWlzSG9zdGVkICYmXG4gICAgICAgICAgICAgICAgIWlzSW50ZXJhY3RpdmUgJiZcbiAgICAgICAgICAgICAgICAhd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmlzRnJvbnQgJiZcbiAgICAgICAgICAgICAgICAhd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5pc0RvdGNvbVJlbmRlcmluZyAmJlxuICAgICAgICAgICAgICAgICFuZXdSZWNpcGVEZXNpZ247XG4gICAgICAgIHRoaXMudGhpcmRQYXJ0eVRhZ3MgPVxuICAgICAgICAgICAgIXRoaXMuYWRGcmVlICYmXG4gICAgICAgICAgICAgICAgZXh0ZXJuYWxBZHZlcnRpc2luZyAmJlxuICAgICAgICAgICAgICAgICFpc0lkZW50aXR5UGFnZSAmJlxuICAgICAgICAgICAgICAgICF0aGlzLmlzU2VjdXJlQ29udGFjdDtcbiAgICAgICAgdGhpcy5jb21tZW50QWR2ZXJ0cyA9XG4gICAgICAgICAgICB0aGlzLnNob3VsZExvYWRHb29nbGV0YWcgJiZcbiAgICAgICAgICAgICAgICAhdGhpcy5hZEZyZWUgJiZcbiAgICAgICAgICAgICAgICAhaXNNaW51dGVBcnRpY2xlICYmXG4gICAgICAgICAgICAgICAgISF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLmVuYWJsZURpc2N1c3Npb25Td2l0Y2ggJiZcbiAgICAgICAgICAgICAgICB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuY29tbWVudGFibGUgJiZcbiAgICAgICAgICAgICAgICAoIWlzTGl2ZUJsb2cgfHwgaXNXaWRlUGFnZSk7XG4gICAgICAgIHRoaXMubGl2ZWJsb2dBZHZlcnRzID1cbiAgICAgICAgICAgICEhaXNMaXZlQmxvZyAmJiB0aGlzLnNob3VsZExvYWRHb29nbGV0YWcgJiYgIXRoaXMuYWRGcmVlO1xuICAgICAgICB0aGlzLmNvbXNjb3JlID1cbiAgICAgICAgICAgICEhd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlcy5jb21zY29yZSAmJlxuICAgICAgICAgICAgICAgICFpc0lkZW50aXR5UGFnZSAmJlxuICAgICAgICAgICAgICAgICF0aGlzLmlzU2VjdXJlQ29udGFjdDtcbiAgICB9XG59XG5leHBvcnQgY29uc3QgY29tbWVyY2lhbEZlYXR1cmVzID0gbmV3IENvbW1lcmNpYWxGZWF0dXJlcygpO1xuIiwiaW1wb3J0IHsgYnJlYWtwb2ludHMgYXMgc291cmNlQnJlYWtwb2ludHMgfSBmcm9tICdAZ3VhcmRpYW4vc291cmNlL2ZvdW5kYXRpb25zJztcbmltcG9ydCB7IGdldFZpZXdwb3J0IH0gZnJvbSAnLi9kZXRlY3Qtdmlld3BvcnQnO1xuY29uc3QgYnJlYWtwb2ludHMgPSB7XG4gICAgbW9iaWxlOiBzb3VyY2VCcmVha3BvaW50c1snbW9iaWxlJ10sXG4gICAgdGFibGV0OiBzb3VyY2VCcmVha3BvaW50c1sndGFibGV0J10sXG4gICAgZGVza3RvcDogc291cmNlQnJlYWtwb2ludHNbJ2Rlc2t0b3AnXSxcbiAgICB3aWRlOiBzb3VyY2VCcmVha3BvaW50c1snd2lkZSddLFxufTtcbmNvbnN0IGlzU291cmNlQnJlYWtwb2ludCA9IChwb2ludCkgPT4gcG9pbnQgaW4gc291cmNlQnJlYWtwb2ludHM7XG5jb25zdCBpc0JyZWFrcG9pbnQgPSAocG9pbnQpID0+IHBvaW50IGluIGJyZWFrcG9pbnRzO1xuY29uc3QgdHdlYWtwb2ludHMgPSB7XG4gICAgbW9iaWxlTWVkaXVtOiBzb3VyY2VCcmVha3BvaW50c1snbW9iaWxlTWVkaXVtJ10sXG4gICAgbW9iaWxlTGFuZHNjYXBlOiBzb3VyY2VCcmVha3BvaW50c1snbW9iaWxlTGFuZHNjYXBlJ10sXG4gICAgcGhhYmxldDogc291cmNlQnJlYWtwb2ludHNbJ3BoYWJsZXQnXSxcbiAgICBsZWZ0Q29sOiBzb3VyY2VCcmVha3BvaW50c1snbGVmdENvbCddLFxufTtcbmNvbnN0IHNvdXJjZUJyZWFrcG9pbnROYW1lcyA9IFtcbiAgICAnd2lkZScsXG4gICAgJ2xlZnRDb2wnLFxuICAgICdkZXNrdG9wJyxcbiAgICAndGFibGV0JyxcbiAgICAncGhhYmxldCcsXG4gICAgJ21vYmlsZUxhbmRzY2FwZScsXG4gICAgJ21vYmlsZU1lZGl1bScsXG4gICAgJ21vYmlsZScsXG5dO1xubGV0IGN1cnJlbnRCcmVha3BvaW50O1xubGV0IGN1cnJlbnRUd2Vha3BvaW50O1xuLy8gR2V0IHRoZSBjbG9zZXN0IGJyZWFrcG9pbnQgdG8gYSBnaXZlbiB3aWR0aFxuY29uc3QgZ2V0UG9pbnQgPSAoaW5jbHVkZVR3ZWFrcG9pbnQsIHdpZHRoKSA9PiB7XG4gICAgY29uc3QgcG9pbnQgPSBzb3VyY2VCcmVha3BvaW50TmFtZXMuZmluZCgocG9pbnQpID0+IHtcbiAgICAgICAgaWYgKGlzQnJlYWtwb2ludChwb2ludCkpIHtcbiAgICAgICAgICAgIHJldHVybiB3aWR0aCA+PSBicmVha3BvaW50c1twb2ludF07XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoaW5jbHVkZVR3ZWFrcG9pbnQpIHtcbiAgICAgICAgICAgIHJldHVybiB3aWR0aCA+PSB0d2Vha3BvaW50c1twb2ludF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH0pO1xuICAgIC8vIFRoaXMgYXNzZXJ0aW9uIGlzIGNhcHR1cmVkIGluIHRlc3RzXG4gICAgcmV0dXJuIChwb2ludCA/PyAnbW9iaWxlJyk7XG59O1xuY29uc3QgZ2V0QnJlYWtwb2ludCA9ICh3aWR0aCkgPT4gZ2V0UG9pbnQoZmFsc2UsIHdpZHRoKTtcbmNvbnN0IGdldFR3ZWFrcG9pbnQgPSAod2lkdGgpID0+IGdldFBvaW50KHRydWUsIHdpZHRoKTtcbmNvbnN0IGdldEN1cnJlbnRCcmVha3BvaW50ID0gKCkgPT4gY3VycmVudEJyZWFrcG9pbnQgPz8gZ2V0QnJlYWtwb2ludChnZXRWaWV3cG9ydCgpLndpZHRoKTtcbmNvbnN0IGdldEN1cnJlbnRUd2Vha3BvaW50ID0gKCkgPT4gY3VycmVudFR3ZWFrcG9pbnQgPz8gZ2V0VHdlYWtwb2ludChnZXRWaWV3cG9ydCgpLndpZHRoKTtcbi8vIGNyZWF0ZSBhIG1lZGlhIHF1ZXJ5IHN0cmluZyBmcm9tIGEgbWluIGFuZCBtYXggYnJlYWtwb2ludFxuY29uc3QgZ2V0TWVkaWFRdWVyeSA9ICh7IG1pbiwgbWF4LCB9KSA9PiB7XG4gICAgY29uc3QgbWluV2lkdGggPSBtaW5cbiAgICAgICAgPyB0eXBlb2YgbWluID09PSAnbnVtYmVyJ1xuICAgICAgICAgICAgPyBtaW5cbiAgICAgICAgICAgIDogc291cmNlQnJlYWtwb2ludHNbbWluXVxuICAgICAgICA6IG51bGw7XG4gICAgY29uc3QgbWF4V2lkdGggPSBtYXhcbiAgICAgICAgPyB0eXBlb2YgbWF4ID09PSAnbnVtYmVyJ1xuICAgICAgICAgICAgPyBtYXhcbiAgICAgICAgICAgIDogc291cmNlQnJlYWtwb2ludHNbbWF4XSAtIDFcbiAgICAgICAgOiBudWxsO1xuICAgIGNvbnN0IG1pblF1ZXJ5ID0gbWluV2lkdGggPyBgKG1pbi13aWR0aDogJHttaW5XaWR0aH1weClgIDogbnVsbDtcbiAgICBjb25zdCBtYXhRdWVyeSA9IG1heFdpZHRoID8gYChtYXgtd2lkdGg6ICR7bWF4V2lkdGh9cHgpYCA6IG51bGw7XG4gICAgcmV0dXJuIFttaW5RdWVyeSwgbWF4UXVlcnldLmZpbHRlcihCb29sZWFuKS5qb2luKCcgYW5kICcpO1xufTtcbmNvbnN0IHVwZGF0ZUJyZWFrcG9pbnQgPSAoYnJlYWtwb2ludCkgPT4ge1xuICAgIGN1cnJlbnRUd2Vha3BvaW50ID0gYnJlYWtwb2ludDtcbiAgICBjdXJyZW50QnJlYWtwb2ludCA9IGdldFBvaW50KGZhbHNlLCBzb3VyY2VCcmVha3BvaW50c1tjdXJyZW50VHdlYWtwb2ludF0pO1xufTtcbi8qKlxuICogV2UgdXNlIG1lZGlhIHF1ZXJpZXMgdG8ga2VlcCB0cmFjayBvZiB3aGF0IGJyZWFrcG9pbnQgd2UncmUgaW4uIFRoaXMgaXMgdG8gYXZvaWRcbiAqIHVzaW5nIGdldFZpZXdQb3J0LCB3aGljaCB1dGlsaXplcyB3aW5kb3cuaW5uZXJXaWR0aCB3aGljaCBjYXVzZXMgYSByZWZsb3cuXG4gKi9cbmNvbnN0IGluaXRNZWRpYVF1ZXJ5TGlzdGVuZXJzID0gKCkgPT4ge1xuICAgIFsuLi5zb3VyY2VCcmVha3BvaW50TmFtZXNdLnJldmVyc2UoKS5mb3JFYWNoKChicCwgaW5kZXgsIGJwcykgPT4ge1xuICAgICAgICBpZiAoaXNTb3VyY2VCcmVha3BvaW50KGJwKSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dEJwID0gYnBzW2luZGV4ICsgMV07XG4gICAgICAgICAgICBjb25zdCBtcWwgPSB3aW5kb3cubWF0Y2hNZWRpYShnZXRNZWRpYVF1ZXJ5KHtcbiAgICAgICAgICAgICAgICBtaW46IGJwLFxuICAgICAgICAgICAgICAgIG1heDogbmV4dEJwID8gc291cmNlQnJlYWtwb2ludHNbbmV4dEJwXSA6IHVuZGVmaW5lZCxcbiAgICAgICAgICAgIH0pKTtcbiAgICAgICAgICAgIGNvbnN0IGxpc3RlbmVyID0gKG1xbCkgPT4gbXFsLm1hdGNoZXMgJiYgdXBkYXRlQnJlYWtwb2ludChicCk7XG4gICAgICAgICAgICAvL2FkZExpc3RlbmVyIGlzIGEgZGVwcmVjYXRlZCBtZXRob2QgYnV0IFNhZmFyaSAxMyBhbmQgZWFybGllciB2ZXJzaW9ucyBkbyBub3Qgc3VwcG9ydCB0aGUgbmV3XG4gICAgICAgICAgICAvL21ldGhvZCwgc28gd2UgbmVlZCBpdCBoZXJlIGFzIGEgZmFsbGJhY2sgdG8gbG9hZCBhZHMgb24gdGhvc2UgdmVyc2lvbnMgb2YgU2FmYXJpXG4gICAgICAgICAgICBpZiAodHlwZW9mIG1xbC5hZGRFdmVudExpc3RlbmVyICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIG1xbC5hZGRFdmVudExpc3RlbmVyKCdjaGFuZ2UnLCBsaXN0ZW5lcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgbXFsLmFkZExpc3RlbmVyICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICAgIG1xbC5hZGRMaXN0ZW5lcihsaXN0ZW5lcik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBsaXN0ZW5lcihtcWwpO1xuICAgICAgICB9XG4gICAgfSk7XG59O1xuY29uc3QgbWF0Y2hlc0JyZWFrcG9pbnRzID0gKHsgbWluLCBtYXgsIH0pID0+IHdpbmRvdy5tYXRjaE1lZGlhKGdldE1lZGlhUXVlcnkoeyBtaW4sIG1heCB9KSkubWF0Y2hlcztcbmNvbnN0IGhhc0Nyb3NzZWRCcmVha3BvaW50ID0gKGluY2x1ZGVUd2Vha3BvaW50KSA9PiB7XG4gICAgbGV0IHdhcyA9IGluY2x1ZGVUd2Vha3BvaW50XG4gICAgICAgID8gZ2V0Q3VycmVudFR3ZWFrcG9pbnQoKVxuICAgICAgICA6IGdldEN1cnJlbnRCcmVha3BvaW50KCk7XG4gICAgcmV0dXJuIChjYWxsYmFjaykgPT4ge1xuICAgICAgICBjb25zdCBpcyA9IGluY2x1ZGVUd2Vha3BvaW50XG4gICAgICAgICAgICA/IGdldEN1cnJlbnRUd2Vha3BvaW50KClcbiAgICAgICAgICAgIDogZ2V0Q3VycmVudEJyZWFrcG9pbnQoKTtcbiAgICAgICAgaWYgKGlzICE9PSB3YXMpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKGlzLCB3YXMpO1xuICAgICAgICAgICAgd2FzID0gaXM7XG4gICAgICAgIH1cbiAgICB9O1xufTtcbmluaXRNZWRpYVF1ZXJ5TGlzdGVuZXJzKCk7XG5leHBvcnQgeyBnZXRCcmVha3BvaW50LCBnZXRUd2Vha3BvaW50LCBnZXRDdXJyZW50QnJlYWtwb2ludCwgZ2V0Q3VycmVudFR3ZWFrcG9pbnQsIG1hdGNoZXNCcmVha3BvaW50cywgaGFzQ3Jvc3NlZEJyZWFrcG9pbnQsIH07XG4iLCIvKipcbiAqIEV4cGVjdHMgYHdpbmRvdy5pbm5lcldpZHRoYCBvciBgZG9jdW1lbnQuYm9keS5jbGllbnRXaWR0aGAgdG8gcmV0dXJuXG4gKiBhIHZhbHVlXG4gKlxuICogQHJldHVybnNcbiAqL1xuY29uc3QgZ2V0Vmlld3BvcnQgPSAoKSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgd2lkdGg6IHdpbmRvdy5pbm5lcldpZHRoIHx8IGRvY3VtZW50LmJvZHkuY2xpZW50V2lkdGggfHwgMCxcbiAgICAgICAgaGVpZ2h0OiB3aW5kb3cuaW5uZXJIZWlnaHQgfHwgZG9jdW1lbnQuYm9keS5jbGllbnRIZWlnaHQgfHwgMCxcbiAgICB9O1xufTtcbmV4cG9ydCB7IGdldFZpZXdwb3J0IH07XG4iLCIvLyBUaGUgbW9kdWxlIGNhY2hlXG52YXIgX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fID0ge307XG5cbi8vIFRoZSByZXF1aXJlIGZ1bmN0aW9uXG5mdW5jdGlvbiBfX3dlYnBhY2tfcmVxdWlyZV9fKG1vZHVsZUlkKSB7XG5cdC8vIENoZWNrIGlmIG1vZHVsZSBpcyBpbiBjYWNoZVxuXHR2YXIgY2FjaGVkTW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXTtcblx0aWYgKGNhY2hlZE1vZHVsZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0cmV0dXJuIGNhY2hlZE1vZHVsZS5leHBvcnRzO1xuXHR9XG5cdC8vIENyZWF0ZSBhIG5ldyBtb2R1bGUgKGFuZCBwdXQgaXQgaW50byB0aGUgY2FjaGUpXG5cdHZhciBtb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdID0ge1xuXHRcdC8vIG5vIG1vZHVsZS5pZCBuZWVkZWRcblx0XHQvLyBubyBtb2R1bGUubG9hZGVkIG5lZWRlZFxuXHRcdGV4cG9ydHM6IHt9XG5cdH07XG5cblx0Ly8gRXhlY3V0ZSB0aGUgbW9kdWxlIGZ1bmN0aW9uXG5cdF9fd2VicGFja19tb2R1bGVzX19bbW9kdWxlSWRdLmNhbGwobW9kdWxlLmV4cG9ydHMsIG1vZHVsZSwgbW9kdWxlLmV4cG9ydHMsIF9fd2VicGFja19yZXF1aXJlX18pO1xuXG5cdC8vIFJldHVybiB0aGUgZXhwb3J0cyBvZiB0aGUgbW9kdWxlXG5cdHJldHVybiBtb2R1bGUuZXhwb3J0cztcbn1cblxuLy8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbl9fd2VicGFja19yZXF1aXJlX18ubSA9IF9fd2VicGFja19tb2R1bGVzX187XG5cbiIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5mID0ge307XG4vLyBUaGlzIGZpbGUgY29udGFpbnMgb25seSB0aGUgZW50cnkgY2h1bmsuXG4vLyBUaGUgY2h1bmsgbG9hZGluZyBmdW5jdGlvbiBmb3IgYWRkaXRpb25hbCBjaHVua3Ncbl9fd2VicGFja19yZXF1aXJlX18uZSA9IChjaHVua0lkKSA9PiB7XG5cdHJldHVybiBQcm9taXNlLmFsbChPYmplY3Qua2V5cyhfX3dlYnBhY2tfcmVxdWlyZV9fLmYpLnJlZHVjZSgocHJvbWlzZXMsIGtleSkgPT4ge1xuXHRcdF9fd2VicGFja19yZXF1aXJlX18uZltrZXldKGNodW5rSWQsIHByb21pc2VzKTtcblx0XHRyZXR1cm4gcHJvbWlzZXM7XG5cdH0sIFtdKSk7XG59OyIsIi8vIFRoaXMgZnVuY3Rpb24gYWxsb3cgdG8gcmVmZXJlbmNlIGFzeW5jIGNodW5rc1xuX193ZWJwYWNrX3JlcXVpcmVfXy51ID0gKGNodW5rSWQpID0+IHtcblx0Ly8gcmV0dXJuIHVybCBmb3IgZmlsZW5hbWVzIGJhc2VkIG9uIHRlbXBsYXRlXG5cdHJldHVybiBcImdyYXVuLlwiICsgY2h1bmtJZCArIFwiLmNvbW1lcmNpYWwuanNcIjtcbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5oID0gKCkgPT4gKFwiYjUwMTFjYTVmMmIyN2M4NGU1MjBcIikiLCJfX3dlYnBhY2tfcmVxdWlyZV9fLmcgPSAoZnVuY3Rpb24oKSB7XG5cdGlmICh0eXBlb2YgZ2xvYmFsVGhpcyA9PT0gJ29iamVjdCcpIHJldHVybiBnbG9iYWxUaGlzO1xuXHR0cnkge1xuXHRcdHJldHVybiB0aGlzIHx8IG5ldyBGdW5jdGlvbigncmV0dXJuIHRoaXMnKSgpO1xuXHR9IGNhdGNoIChlKSB7XG5cdFx0aWYgKHR5cGVvZiB3aW5kb3cgPT09ICdvYmplY3QnKSByZXR1cm4gd2luZG93O1xuXHR9XG59KSgpOyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCJ2YXIgaW5Qcm9ncmVzcyA9IHt9O1xudmFyIGRhdGFXZWJwYWNrUHJlZml4ID0gXCJAZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGU6XCI7XG4vLyBsb2FkU2NyaXB0IGZ1bmN0aW9uIHRvIGxvYWQgYSBzY3JpcHQgdmlhIHNjcmlwdCB0YWdcbl9fd2VicGFja19yZXF1aXJlX18ubCA9ICh1cmwsIGRvbmUsIGtleSwgY2h1bmtJZCkgPT4ge1xuXHRpZihpblByb2dyZXNzW3VybF0pIHsgaW5Qcm9ncmVzc1t1cmxdLnB1c2goZG9uZSk7IHJldHVybjsgfVxuXHR2YXIgc2NyaXB0LCBuZWVkQXR0YWNoO1xuXHRpZihrZXkgIT09IHVuZGVmaW5lZCkge1xuXHRcdHZhciBzY3JpcHRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG5cdFx0Zm9yKHZhciBpID0gMDsgaSA8IHNjcmlwdHMubGVuZ3RoOyBpKyspIHtcblx0XHRcdHZhciBzID0gc2NyaXB0c1tpXTtcblx0XHRcdGlmKHMuZ2V0QXR0cmlidXRlKFwic3JjXCIpID09IHVybCB8fCBzLmdldEF0dHJpYnV0ZShcImRhdGEtd2VicGFja1wiKSA9PSBkYXRhV2VicGFja1ByZWZpeCArIGtleSkgeyBzY3JpcHQgPSBzOyBicmVhazsgfVxuXHRcdH1cblx0fVxuXHRpZighc2NyaXB0KSB7XG5cdFx0bmVlZEF0dGFjaCA9IHRydWU7XG5cdFx0c2NyaXB0ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnc2NyaXB0Jyk7XG5cblx0XHRzY3JpcHQuY2hhcnNldCA9ICd1dGYtOCc7XG5cdFx0c2NyaXB0LnRpbWVvdXQgPSAxMjA7XG5cdFx0aWYgKF9fd2VicGFja19yZXF1aXJlX18ubmMpIHtcblx0XHRcdHNjcmlwdC5zZXRBdHRyaWJ1dGUoXCJub25jZVwiLCBfX3dlYnBhY2tfcmVxdWlyZV9fLm5jKTtcblx0XHR9XG5cdFx0c2NyaXB0LnNldEF0dHJpYnV0ZShcImRhdGEtd2VicGFja1wiLCBkYXRhV2VicGFja1ByZWZpeCArIGtleSk7XG5cblx0XHRzY3JpcHQuc3JjID0gdXJsO1xuXHR9XG5cdGluUHJvZ3Jlc3NbdXJsXSA9IFtkb25lXTtcblx0dmFyIG9uU2NyaXB0Q29tcGxldGUgPSAocHJldiwgZXZlbnQpID0+IHtcblx0XHQvLyBhdm9pZCBtZW0gbGVha3MgaW4gSUUuXG5cdFx0c2NyaXB0Lm9uZXJyb3IgPSBzY3JpcHQub25sb2FkID0gbnVsbDtcblx0XHRjbGVhclRpbWVvdXQodGltZW91dCk7XG5cdFx0dmFyIGRvbmVGbnMgPSBpblByb2dyZXNzW3VybF07XG5cdFx0ZGVsZXRlIGluUHJvZ3Jlc3NbdXJsXTtcblx0XHRzY3JpcHQucGFyZW50Tm9kZSAmJiBzY3JpcHQucGFyZW50Tm9kZS5yZW1vdmVDaGlsZChzY3JpcHQpO1xuXHRcdGRvbmVGbnMgJiYgZG9uZUZucy5mb3JFYWNoKChmbikgPT4gKGZuKGV2ZW50KSkpO1xuXHRcdGlmKHByZXYpIHJldHVybiBwcmV2KGV2ZW50KTtcblx0fVxuXHR2YXIgdGltZW91dCA9IHNldFRpbWVvdXQob25TY3JpcHRDb21wbGV0ZS5iaW5kKG51bGwsIHVuZGVmaW5lZCwgeyB0eXBlOiAndGltZW91dCcsIHRhcmdldDogc2NyaXB0IH0pLCAxMjAwMDApO1xuXHRzY3JpcHQub25lcnJvciA9IG9uU2NyaXB0Q29tcGxldGUuYmluZChudWxsLCBzY3JpcHQub25lcnJvcik7XG5cdHNjcmlwdC5vbmxvYWQgPSBvblNjcmlwdENvbXBsZXRlLmJpbmQobnVsbCwgc2NyaXB0Lm9ubG9hZCk7XG5cdG5lZWRBdHRhY2ggJiYgZG9jdW1lbnQuaGVhZC5hcHBlbmRDaGlsZChzY3JpcHQpO1xufTsiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCJ2YXIgc2NyaXB0VXJsO1xuaWYgKF9fd2VicGFja19yZXF1aXJlX18uZy5pbXBvcnRTY3JpcHRzKSBzY3JpcHRVcmwgPSBfX3dlYnBhY2tfcmVxdWlyZV9fLmcubG9jYXRpb24gKyBcIlwiO1xudmFyIGRvY3VtZW50ID0gX193ZWJwYWNrX3JlcXVpcmVfXy5nLmRvY3VtZW50O1xuaWYgKCFzY3JpcHRVcmwgJiYgZG9jdW1lbnQpIHtcblx0aWYgKGRvY3VtZW50LmN1cnJlbnRTY3JpcHQgJiYgZG9jdW1lbnQuY3VycmVudFNjcmlwdC50YWdOYW1lLnRvVXBwZXJDYXNlKCkgPT09ICdTQ1JJUFQnKVxuXHRcdHNjcmlwdFVybCA9IGRvY3VtZW50LmN1cnJlbnRTY3JpcHQuc3JjO1xuXHRpZiAoIXNjcmlwdFVybCkge1xuXHRcdHZhciBzY3JpcHRzID0gZG9jdW1lbnQuZ2V0RWxlbWVudHNCeVRhZ05hbWUoXCJzY3JpcHRcIik7XG5cdFx0aWYoc2NyaXB0cy5sZW5ndGgpIHtcblx0XHRcdHZhciBpID0gc2NyaXB0cy5sZW5ndGggLSAxO1xuXHRcdFx0d2hpbGUgKGkgPiAtMSAmJiAoIXNjcmlwdFVybCB8fCAhL15odHRwKHM/KTovLnRlc3Qoc2NyaXB0VXJsKSkpIHNjcmlwdFVybCA9IHNjcmlwdHNbaS0tXS5zcmM7XG5cdFx0fVxuXHR9XG59XG4vLyBXaGVuIHN1cHBvcnRpbmcgYnJvd3NlcnMgd2hlcmUgYW4gYXV0b21hdGljIHB1YmxpY1BhdGggaXMgbm90IHN1cHBvcnRlZCB5b3UgbXVzdCBzcGVjaWZ5IGFuIG91dHB1dC5wdWJsaWNQYXRoIG1hbnVhbGx5IHZpYSBjb25maWd1cmF0aW9uXG4vLyBvciBwYXNzIGFuIGVtcHR5IHN0cmluZyAoXCJcIikgYW5kIHNldCB0aGUgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gdmFyaWFibGUgZnJvbSB5b3VyIGNvZGUgdG8gdXNlIHlvdXIgb3duIGxvZ2ljLlxuaWYgKCFzY3JpcHRVcmwpIHRocm93IG5ldyBFcnJvcihcIkF1dG9tYXRpYyBwdWJsaWNQYXRoIGlzIG5vdCBzdXBwb3J0ZWQgaW4gdGhpcyBicm93c2VyXCIpO1xuc2NyaXB0VXJsID0gc2NyaXB0VXJsLnJlcGxhY2UoL15ibG9iOi8sIFwiXCIpLnJlcGxhY2UoLyMuKiQvLCBcIlwiKS5yZXBsYWNlKC9cXD8uKiQvLCBcIlwiKS5yZXBsYWNlKC9cXC9bXlxcL10rJC8sIFwiL1wiKTtcbl9fd2VicGFja19yZXF1aXJlX18ucCA9IHNjcmlwdFVybDsiLCIvLyBubyBiYXNlVVJJXG5cbi8vIG9iamVjdCB0byBzdG9yZSBsb2FkZWQgYW5kIGxvYWRpbmcgY2h1bmtzXG4vLyB1bmRlZmluZWQgPSBjaHVuayBub3QgbG9hZGVkLCBudWxsID0gY2h1bmsgcHJlbG9hZGVkL3ByZWZldGNoZWRcbi8vIFtyZXNvbHZlLCByZWplY3QsIFByb21pc2VdID0gY2h1bmsgbG9hZGluZywgMCA9IGNodW5rIGxvYWRlZFxudmFyIGluc3RhbGxlZENodW5rcyA9IHtcblx0XCJjb21tZXJjaWFsLXN0YW5kYWxvbmVcIjogMFxufTtcblxuX193ZWJwYWNrX3JlcXVpcmVfXy5mLmogPSAoY2h1bmtJZCwgcHJvbWlzZXMpID0+IHtcblx0XHQvLyBKU09OUCBjaHVuayBsb2FkaW5nIGZvciBqYXZhc2NyaXB0XG5cdFx0dmFyIGluc3RhbGxlZENodW5rRGF0YSA9IF9fd2VicGFja19yZXF1aXJlX18ubyhpbnN0YWxsZWRDaHVua3MsIGNodW5rSWQpID8gaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdIDogdW5kZWZpbmVkO1xuXHRcdGlmKGluc3RhbGxlZENodW5rRGF0YSAhPT0gMCkgeyAvLyAwIG1lYW5zIFwiYWxyZWFkeSBpbnN0YWxsZWRcIi5cblxuXHRcdFx0Ly8gYSBQcm9taXNlIG1lYW5zIFwiY3VycmVudGx5IGxvYWRpbmdcIi5cblx0XHRcdGlmKGluc3RhbGxlZENodW5rRGF0YSkge1xuXHRcdFx0XHRwcm9taXNlcy5wdXNoKGluc3RhbGxlZENodW5rRGF0YVsyXSk7XG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHRpZih0cnVlKSB7IC8vIGFsbCBjaHVua3MgaGF2ZSBKU1xuXHRcdFx0XHRcdC8vIHNldHVwIFByb21pc2UgaW4gY2h1bmsgY2FjaGVcblx0XHRcdFx0XHR2YXIgcHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IChpbnN0YWxsZWRDaHVua0RhdGEgPSBpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPSBbcmVzb2x2ZSwgcmVqZWN0XSkpO1xuXHRcdFx0XHRcdHByb21pc2VzLnB1c2goaW5zdGFsbGVkQ2h1bmtEYXRhWzJdID0gcHJvbWlzZSk7XG5cblx0XHRcdFx0XHQvLyBzdGFydCBjaHVuayBsb2FkaW5nXG5cdFx0XHRcdFx0dmFyIHVybCA9IF9fd2VicGFja19yZXF1aXJlX18ucCArIF9fd2VicGFja19yZXF1aXJlX18udShjaHVua0lkKTtcblx0XHRcdFx0XHQvLyBjcmVhdGUgZXJyb3IgYmVmb3JlIHN0YWNrIHVud291bmQgdG8gZ2V0IHVzZWZ1bCBzdGFja3RyYWNlIGxhdGVyXG5cdFx0XHRcdFx0dmFyIGVycm9yID0gbmV3IEVycm9yKCk7XG5cdFx0XHRcdFx0dmFyIGxvYWRpbmdFbmRlZCA9IChldmVudCkgPT4ge1xuXHRcdFx0XHRcdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKGluc3RhbGxlZENodW5rcywgY2h1bmtJZCkpIHtcblx0XHRcdFx0XHRcdFx0aW5zdGFsbGVkQ2h1bmtEYXRhID0gaW5zdGFsbGVkQ2h1bmtzW2NodW5rSWRdO1xuXHRcdFx0XHRcdFx0XHRpZihpbnN0YWxsZWRDaHVua0RhdGEgIT09IDApIGluc3RhbGxlZENodW5rc1tjaHVua0lkXSA9IHVuZGVmaW5lZDtcblx0XHRcdFx0XHRcdFx0aWYoaW5zdGFsbGVkQ2h1bmtEYXRhKSB7XG5cdFx0XHRcdFx0XHRcdFx0dmFyIGVycm9yVHlwZSA9IGV2ZW50ICYmIChldmVudC50eXBlID09PSAnbG9hZCcgPyAnbWlzc2luZycgOiBldmVudC50eXBlKTtcblx0XHRcdFx0XHRcdFx0XHR2YXIgcmVhbFNyYyA9IGV2ZW50ICYmIGV2ZW50LnRhcmdldCAmJiBldmVudC50YXJnZXQuc3JjO1xuXHRcdFx0XHRcdFx0XHRcdGVycm9yLm1lc3NhZ2UgPSAnTG9hZGluZyBjaHVuayAnICsgY2h1bmtJZCArICcgZmFpbGVkLlxcbignICsgZXJyb3JUeXBlICsgJzogJyArIHJlYWxTcmMgKyAnKSc7XG5cdFx0XHRcdFx0XHRcdFx0ZXJyb3IubmFtZSA9ICdDaHVua0xvYWRFcnJvcic7XG5cdFx0XHRcdFx0XHRcdFx0ZXJyb3IudHlwZSA9IGVycm9yVHlwZTtcblx0XHRcdFx0XHRcdFx0XHRlcnJvci5yZXF1ZXN0ID0gcmVhbFNyYztcblx0XHRcdFx0XHRcdFx0XHRpbnN0YWxsZWRDaHVua0RhdGFbMV0oZXJyb3IpO1xuXHRcdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0fTtcblx0XHRcdFx0XHRfX3dlYnBhY2tfcmVxdWlyZV9fLmwodXJsLCBsb2FkaW5nRW5kZWQsIFwiY2h1bmstXCIgKyBjaHVua0lkLCBjaHVua0lkKTtcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cbn07XG5cbi8vIG5vIHByZWZldGNoaW5nXG5cbi8vIG5vIHByZWxvYWRlZFxuXG4vLyBubyBITVJcblxuLy8gbm8gSE1SIG1hbmlmZXN0XG5cbi8vIG5vIG9uIGNodW5rcyBsb2FkZWRcblxuLy8gaW5zdGFsbCBhIEpTT05QIGNhbGxiYWNrIGZvciBjaHVuayBsb2FkaW5nXG52YXIgd2VicGFja0pzb25wQ2FsbGJhY2sgPSAocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24sIGRhdGEpID0+IHtcblx0dmFyIFtjaHVua0lkcywgbW9yZU1vZHVsZXMsIHJ1bnRpbWVdID0gZGF0YTtcblx0Ly8gYWRkIFwibW9yZU1vZHVsZXNcIiB0byB0aGUgbW9kdWxlcyBvYmplY3QsXG5cdC8vIHRoZW4gZmxhZyBhbGwgXCJjaHVua0lkc1wiIGFzIGxvYWRlZCBhbmQgZmlyZSBjYWxsYmFja1xuXHR2YXIgbW9kdWxlSWQsIGNodW5rSWQsIGkgPSAwO1xuXHRpZihjaHVua0lkcy5zb21lKChpZCkgPT4gKGluc3RhbGxlZENodW5rc1tpZF0gIT09IDApKSkge1xuXHRcdGZvcihtb2R1bGVJZCBpbiBtb3JlTW9kdWxlcykge1xuXHRcdFx0aWYoX193ZWJwYWNrX3JlcXVpcmVfXy5vKG1vcmVNb2R1bGVzLCBtb2R1bGVJZCkpIHtcblx0XHRcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5tW21vZHVsZUlkXSA9IG1vcmVNb2R1bGVzW21vZHVsZUlkXTtcblx0XHRcdH1cblx0XHR9XG5cdFx0aWYocnVudGltZSkgdmFyIHJlc3VsdCA9IHJ1bnRpbWUoX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cdH1cblx0aWYocGFyZW50Q2h1bmtMb2FkaW5nRnVuY3Rpb24pIHBhcmVudENodW5rTG9hZGluZ0Z1bmN0aW9uKGRhdGEpO1xuXHRmb3IoO2kgPCBjaHVua0lkcy5sZW5ndGg7IGkrKykge1xuXHRcdGNodW5rSWQgPSBjaHVua0lkc1tpXTtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oaW5zdGFsbGVkQ2h1bmtzLCBjaHVua0lkKSAmJiBpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0pIHtcblx0XHRcdGluc3RhbGxlZENodW5rc1tjaHVua0lkXVswXSgpO1xuXHRcdH1cblx0XHRpbnN0YWxsZWRDaHVua3NbY2h1bmtJZF0gPSAwO1xuXHR9XG5cbn1cblxudmFyIGNodW5rTG9hZGluZ0dsb2JhbCA9IHNlbGZbXCJ3ZWJwYWNrQ2h1bmtfZ3VhcmRpYW5fY29tbWVyY2lhbF9idW5kbGVcIl0gPSBzZWxmW1wid2VicGFja0NodW5rX2d1YXJkaWFuX2NvbW1lcmNpYWxfYnVuZGxlXCJdIHx8IFtdO1xuY2h1bmtMb2FkaW5nR2xvYmFsLmZvckVhY2god2VicGFja0pzb25wQ2FsbGJhY2suYmluZChudWxsLCAwKSk7XG5jaHVua0xvYWRpbmdHbG9iYWwucHVzaCA9IHdlYnBhY2tKc29ucENhbGxiYWNrLmJpbmQobnVsbCwgY2h1bmtMb2FkaW5nR2xvYmFsLnB1c2guYmluZChjaHVua0xvYWRpbmdHbG9iYWwpKTsiLCJmdW5jdGlvbiBvd25LZXlzKGUsIHIpIHsgdmFyIHQgPSBPYmplY3Qua2V5cyhlKTsgaWYgKE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMpIHtcbiAgICB2YXIgbyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eVN5bWJvbHMoZSk7XG4gICAgciAmJiAobyA9IG8uZmlsdGVyKGZ1bmN0aW9uIChyKSB7IHJldHVybiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKGUsIHIpLmVudW1lcmFibGU7IH0pKSwgdC5wdXNoLmFwcGx5KHQsIG8pO1xufSByZXR1cm4gdDsgfVxuZnVuY3Rpb24gX29iamVjdFNwcmVhZChlKSB7IGZvciAodmFyIHIgPSAxOyByIDwgYXJndW1lbnRzLmxlbmd0aDsgcisrKSB7XG4gICAgdmFyIHQgPSBudWxsICE9IGFyZ3VtZW50c1tyXSA/IGFyZ3VtZW50c1tyXSA6IHt9O1xuICAgIHIgJSAyID8gb3duS2V5cyhPYmplY3QodCksICEwKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IF9kZWZpbmVQcm9wZXJ0eShlLCByLCB0W3JdKTsgfSkgOiBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9ycyA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGUsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzKHQpKSA6IG93bktleXMoT2JqZWN0KHQpKS5mb3JFYWNoKGZ1bmN0aW9uIChyKSB7IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKHQsIHIpKTsgfSk7XG59IHJldHVybiBlOyB9XG5mdW5jdGlvbiBfZGVmaW5lUHJvcGVydHkoZSwgciwgdCkgeyByZXR1cm4gKHIgPSBfdG9Qcm9wZXJ0eUtleShyKSkgaW4gZSA/IE9iamVjdC5kZWZpbmVQcm9wZXJ0eShlLCByLCB7IHZhbHVlOiB0LCBlbnVtZXJhYmxlOiAhMCwgY29uZmlndXJhYmxlOiAhMCwgd3JpdGFibGU6ICEwIH0pIDogZVtyXSA9IHQsIGU7IH1cbmZ1bmN0aW9uIF90b1Byb3BlcnR5S2V5KHQpIHsgdmFyIGkgPSBfdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7IHJldHVybiBcInN5bWJvbFwiID09IF90eXBlb2YoaSkgPyBpIDogaSArIFwiXCI7IH1cbmZ1bmN0aW9uIF90b1ByaW1pdGl2ZSh0LCByKSB7IGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YodCkgfHwgIXQpXG4gICAgcmV0dXJuIHQ7IHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdOyBpZiAodm9pZCAwICE9PSBlKSB7XG4gICAgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7XG4gICAgaWYgKFwib2JqZWN0XCIgIT0gX3R5cGVvZihpKSlcbiAgICAgICAgcmV0dXJuIGk7XG4gICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpO1xufSByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpOyB9XG5mdW5jdGlvbiBfdHlwZW9mKG8pIHtcbiAgICBcIkBiYWJlbC9oZWxwZXJzIC0gdHlwZW9mXCI7XG4gICAgcmV0dXJuIF90eXBlb2YgPSBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBcInN5bWJvbFwiID09IHR5cGVvZiBTeW1ib2wuaXRlcmF0b3IgPyBmdW5jdGlvbiAobykgeyByZXR1cm4gdHlwZW9mIG87IH0gOiBmdW5jdGlvbiAobykgeyByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbzsgfSwgX3R5cGVvZihvKTtcbn1cbi8qIGdsb2JhbCBfX3Jlc291cmNlUXVlcnksIF9fd2VicGFja19oYXNoX18gKi9cbi8vLyA8cmVmZXJlbmNlIHR5cGVzPVwid2VicGFjay9tb2R1bGVcIiAvPlxuaW1wb3J0IHdlYnBhY2tIb3RMb2cgZnJvbSBcIndlYnBhY2svaG90L2xvZy5qc1wiO1xuaW1wb3J0IGhvdEVtaXR0ZXIgZnJvbSBcIndlYnBhY2svaG90L2VtaXR0ZXIuanNcIjtcbmltcG9ydCBzb2NrZXQgZnJvbSBcIi4vc29ja2V0LmpzXCI7XG5pbXBvcnQgeyBmb3JtYXRQcm9ibGVtLCBjcmVhdGVPdmVybGF5IH0gZnJvbSBcIi4vb3ZlcmxheS5qc1wiO1xuaW1wb3J0IHsgbG9nLCBzZXRMb2dMZXZlbCB9IGZyb20gXCIuL3V0aWxzL2xvZy5qc1wiO1xuaW1wb3J0IHNlbmRNZXNzYWdlIGZyb20gXCIuL3V0aWxzL3NlbmRNZXNzYWdlLmpzXCI7XG5pbXBvcnQgeyBpc1Byb2dyZXNzU3VwcG9ydGVkLCBkZWZpbmVQcm9ncmVzc0VsZW1lbnQgfSBmcm9tIFwiLi9wcm9ncmVzcy5qc1wiO1xuLyoqXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBPdmVybGF5T3B0aW9uc1xuICogQHByb3BlcnR5IHtib29sZWFuIHwgKGVycm9yOiBFcnJvcikgPT4gYm9vbGVhbn0gW3dhcm5pbmdzXVxuICogQHByb3BlcnR5IHtib29sZWFuIHwgKGVycm9yOiBFcnJvcikgPT4gYm9vbGVhbn0gW2Vycm9yc11cbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbiB8IChlcnJvcjogRXJyb3IpID0+IGJvb2xlYW59IFtydW50aW1lRXJyb3JzXVxuICogQHByb3BlcnR5IHtzdHJpbmd9IFt0cnVzdGVkVHlwZXNQb2xpY3lOYW1lXVxuICovXG4vKipcbiAqIEB0eXBlZGVmIHtPYmplY3R9IE9wdGlvbnNcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gaG90XG4gKiBAcHJvcGVydHkge2Jvb2xlYW59IGxpdmVSZWxvYWRcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gcHJvZ3Jlc3NcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbiB8IE92ZXJsYXlPcHRpb25zfSBvdmVybGF5XG4gKiBAcHJvcGVydHkge3N0cmluZ30gW2xvZ2dpbmddXG4gKiBAcHJvcGVydHkge251bWJlcn0gW3JlY29ubmVjdF1cbiAqL1xuLyoqXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBTdGF0dXNcbiAqIEBwcm9wZXJ0eSB7Ym9vbGVhbn0gaXNVbmxvYWRpbmdcbiAqIEBwcm9wZXJ0eSB7c3RyaW5nfSBjdXJyZW50SGFzaFxuICogQHByb3BlcnR5IHtzdHJpbmd9IFtwcmV2aW91c0hhc2hdXG4gKi9cbi8qKlxuICogQHBhcmFtIHtib29sZWFuIHwgeyB3YXJuaW5ncz86IGJvb2xlYW4gfCBzdHJpbmc7IGVycm9ycz86IGJvb2xlYW4gfCBzdHJpbmc7IHJ1bnRpbWVFcnJvcnM/OiBib29sZWFuIHwgc3RyaW5nOyB9fSBvdmVybGF5T3B0aW9uc1xuICovXG52YXIgZGVjb2RlT3ZlcmxheU9wdGlvbnMgPSBmdW5jdGlvbiBkZWNvZGVPdmVybGF5T3B0aW9ucyhvdmVybGF5T3B0aW9ucykge1xuICAgIGlmIChfdHlwZW9mKG92ZXJsYXlPcHRpb25zKSA9PT0gXCJvYmplY3RcIikge1xuICAgICAgICBbXCJ3YXJuaW5nc1wiLCBcImVycm9yc1wiLCBcInJ1bnRpbWVFcnJvcnNcIl0uZm9yRWFjaChmdW5jdGlvbiAocHJvcGVydHkpIHtcbiAgICAgICAgICAgIGlmICh0eXBlb2Ygb3ZlcmxheU9wdGlvbnNbcHJvcGVydHldID09PSBcInN0cmluZ1wiKSB7XG4gICAgICAgICAgICAgICAgdmFyIG92ZXJsYXlGaWx0ZXJGdW5jdGlvblN0cmluZyA9IGRlY29kZVVSSUNvbXBvbmVudChvdmVybGF5T3B0aW9uc1twcm9wZXJ0eV0pO1xuICAgICAgICAgICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1uZXctZnVuY1xuICAgICAgICAgICAgICAgIG92ZXJsYXlPcHRpb25zW3Byb3BlcnR5XSA9IG5ldyBGdW5jdGlvbihcIm1lc3NhZ2VcIiwgXCJ2YXIgY2FsbGJhY2sgPSBcIi5jb25jYXQob3ZlcmxheUZpbHRlckZ1bmN0aW9uU3RyaW5nLCBcIlxcbiAgICAgICAgcmV0dXJuIGNhbGxiYWNrKG1lc3NhZ2UpXCIpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufTtcbi8qKlxuICogQHR5cGUge1N0YXR1c31cbiAqL1xudmFyIHN0YXR1cyA9IHtcbiAgICBpc1VubG9hZGluZzogZmFsc2UsXG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIGNhbWVsY2FzZVxuICAgIGN1cnJlbnRIYXNoOiBfX3dlYnBhY2tfaGFzaF9fXG59O1xuLyoqXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG52YXIgZ2V0Q3VycmVudFNjcmlwdFNvdXJjZSA9IGZ1bmN0aW9uIGdldEN1cnJlbnRTY3JpcHRTb3VyY2UoKSB7XG4gICAgLy8gYGRvY3VtZW50LmN1cnJlbnRTY3JpcHRgIGlzIHRoZSBtb3N0IGFjY3VyYXRlIHdheSB0byBmaW5kIHRoZSBjdXJyZW50IHNjcmlwdCxcbiAgICAvLyBidXQgaXMgbm90IHN1cHBvcnRlZCBpbiBhbGwgYnJvd3NlcnMuXG4gICAgaWYgKGRvY3VtZW50LmN1cnJlbnRTY3JpcHQpIHtcbiAgICAgICAgcmV0dXJuIGRvY3VtZW50LmN1cnJlbnRTY3JpcHQuZ2V0QXR0cmlidXRlKFwic3JjXCIpO1xuICAgIH1cbiAgICAvLyBGYWxsYmFjayB0byBnZXR0aW5nIGFsbCBzY3JpcHRzIHJ1bm5pbmcgaW4gdGhlIGRvY3VtZW50LlxuICAgIHZhciBzY3JpcHRFbGVtZW50cyA9IGRvY3VtZW50LnNjcmlwdHMgfHwgW107XG4gICAgdmFyIHNjcmlwdEVsZW1lbnRzV2l0aFNyYyA9IEFycmF5LnByb3RvdHlwZS5maWx0ZXIuY2FsbChzY3JpcHRFbGVtZW50cywgZnVuY3Rpb24gKGVsZW1lbnQpIHtcbiAgICAgICAgcmV0dXJuIGVsZW1lbnQuZ2V0QXR0cmlidXRlKFwic3JjXCIpO1xuICAgIH0pO1xuICAgIGlmIChzY3JpcHRFbGVtZW50c1dpdGhTcmMubGVuZ3RoID4gMCkge1xuICAgICAgICB2YXIgY3VycmVudFNjcmlwdCA9IHNjcmlwdEVsZW1lbnRzV2l0aFNyY1tzY3JpcHRFbGVtZW50c1dpdGhTcmMubGVuZ3RoIC0gMV07XG4gICAgICAgIHJldHVybiBjdXJyZW50U2NyaXB0LmdldEF0dHJpYnV0ZShcInNyY1wiKTtcbiAgICB9XG4gICAgLy8gRmFpbCBhcyB0aGVyZSB3YXMgbm8gc2NyaXB0IHRvIHVzZS5cbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJbd2VicGFjay1kZXYtc2VydmVyXSBGYWlsZWQgdG8gZ2V0IGN1cnJlbnQgc2NyaXB0IHNvdXJjZS5cIik7XG59O1xuLyoqXG4gKiBAcGFyYW0ge3N0cmluZ30gcmVzb3VyY2VRdWVyeVxuICogQHJldHVybnMge3sgW2tleTogc3RyaW5nXTogc3RyaW5nIHwgYm9vbGVhbiB9fVxuICovXG52YXIgcGFyc2VVUkwgPSBmdW5jdGlvbiBwYXJzZVVSTChyZXNvdXJjZVF1ZXJ5KSB7XG4gICAgLyoqIEB0eXBlIHt7IFtrZXk6IHN0cmluZ106IHN0cmluZyB9fSAqL1xuICAgIHZhciByZXN1bHQgPSB7fTtcbiAgICBpZiAodHlwZW9mIHJlc291cmNlUXVlcnkgPT09IFwic3RyaW5nXCIgJiYgcmVzb3VyY2VRdWVyeSAhPT0gXCJcIikge1xuICAgICAgICB2YXIgc2VhcmNoUGFyYW1zID0gcmVzb3VyY2VRdWVyeS5zbGljZSgxKS5zcGxpdChcIiZcIik7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgc2VhcmNoUGFyYW1zLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgICAgICB2YXIgcGFpciA9IHNlYXJjaFBhcmFtc1tpXS5zcGxpdChcIj1cIik7XG4gICAgICAgICAgICByZXN1bHRbcGFpclswXV0gPSBkZWNvZGVVUklDb21wb25lbnQocGFpclsxXSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIEVsc2UsIGdldCB0aGUgdXJsIGZyb20gdGhlIDxzY3JpcHQ+IHRoaXMgZmlsZSB3YXMgY2FsbGVkIHdpdGguXG4gICAgICAgIHZhciBzY3JpcHRTb3VyY2UgPSBnZXRDdXJyZW50U2NyaXB0U291cmNlKCk7XG4gICAgICAgIHZhciBzY3JpcHRTb3VyY2VVUkw7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICAvLyBUaGUgcGxhY2Vob2xkZXIgYGJhc2VVUkxgIHdpdGggYHdpbmRvdy5sb2NhdGlvbi5ocmVmYCxcbiAgICAgICAgICAgIC8vIGlzIHRvIGFsbG93IHBhcnNpbmcgb2YgcGF0aC1yZWxhdGl2ZSBvciBwcm90b2NvbC1yZWxhdGl2ZSBVUkxzLFxuICAgICAgICAgICAgLy8gYW5kIHdpbGwgaGF2ZSBubyBlZmZlY3QgaWYgYHNjcmlwdFNvdXJjZWAgaXMgYSBmdWxseSB2YWxpZCBVUkwuXG4gICAgICAgICAgICBzY3JpcHRTb3VyY2VVUkwgPSBuZXcgVVJMKHNjcmlwdFNvdXJjZSwgc2VsZi5sb2NhdGlvbi5ocmVmKTtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIC8vIFVSTCBwYXJzaW5nIGZhaWxlZCwgZG8gbm90aGluZy5cbiAgICAgICAgICAgIC8vIFdlIHdpbGwgc3RpbGwgcHJvY2VlZCB0byBzZWUgaWYgd2UgY2FuIHJlY292ZXIgdXNpbmcgYHJlc291cmNlUXVlcnlgXG4gICAgICAgIH1cbiAgICAgICAgaWYgKHNjcmlwdFNvdXJjZVVSTCkge1xuICAgICAgICAgICAgcmVzdWx0ID0gc2NyaXB0U291cmNlVVJMO1xuICAgICAgICAgICAgcmVzdWx0LmZyb21DdXJyZW50U2NyaXB0ID0gdHJ1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufTtcbnZhciBwYXJzZWRSZXNvdXJjZVF1ZXJ5ID0gcGFyc2VVUkwoX19yZXNvdXJjZVF1ZXJ5KTtcbnZhciBlbmFibGVkRmVhdHVyZXMgPSB7XG4gICAgXCJIb3QgTW9kdWxlIFJlcGxhY2VtZW50XCI6IGZhbHNlLFxuICAgIFwiTGl2ZSBSZWxvYWRpbmdcIjogZmFsc2UsXG4gICAgUHJvZ3Jlc3M6IGZhbHNlLFxuICAgIE92ZXJsYXk6IGZhbHNlXG59O1xuLyoqIEB0eXBlIHtPcHRpb25zfSAqL1xudmFyIG9wdGlvbnMgPSB7XG4gICAgaG90OiBmYWxzZSxcbiAgICBsaXZlUmVsb2FkOiBmYWxzZSxcbiAgICBwcm9ncmVzczogZmFsc2UsXG4gICAgb3ZlcmxheTogZmFsc2Vcbn07XG5pZiAocGFyc2VkUmVzb3VyY2VRdWVyeS5ob3QgPT09IFwidHJ1ZVwiKSB7XG4gICAgb3B0aW9ucy5ob3QgPSB0cnVlO1xuICAgIGVuYWJsZWRGZWF0dXJlc1tcIkhvdCBNb2R1bGUgUmVwbGFjZW1lbnRcIl0gPSB0cnVlO1xufVxuaWYgKHBhcnNlZFJlc291cmNlUXVlcnlbXCJsaXZlLXJlbG9hZFwiXSA9PT0gXCJ0cnVlXCIpIHtcbiAgICBvcHRpb25zLmxpdmVSZWxvYWQgPSB0cnVlO1xuICAgIGVuYWJsZWRGZWF0dXJlc1tcIkxpdmUgUmVsb2FkaW5nXCJdID0gdHJ1ZTtcbn1cbmlmIChwYXJzZWRSZXNvdXJjZVF1ZXJ5LnByb2dyZXNzID09PSBcInRydWVcIikge1xuICAgIG9wdGlvbnMucHJvZ3Jlc3MgPSB0cnVlO1xuICAgIGVuYWJsZWRGZWF0dXJlcy5Qcm9ncmVzcyA9IHRydWU7XG59XG5pZiAocGFyc2VkUmVzb3VyY2VRdWVyeS5vdmVybGF5KSB7XG4gICAgdHJ5IHtcbiAgICAgICAgb3B0aW9ucy5vdmVybGF5ID0gSlNPTi5wYXJzZShwYXJzZWRSZXNvdXJjZVF1ZXJ5Lm92ZXJsYXkpO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICBsb2cuZXJyb3IoXCJFcnJvciBwYXJzaW5nIG92ZXJsYXkgb3B0aW9ucyBmcm9tIHJlc291cmNlIHF1ZXJ5OlwiLCBlKTtcbiAgICB9XG4gICAgLy8gRmlsbCBpbiBkZWZhdWx0IFwidHJ1ZVwiIHBhcmFtcyBmb3IgcGFydGlhbGx5LXNwZWNpZmllZCBvYmplY3RzLlxuICAgIGlmIChfdHlwZW9mKG9wdGlvbnMub3ZlcmxheSkgPT09IFwib2JqZWN0XCIpIHtcbiAgICAgICAgb3B0aW9ucy5vdmVybGF5ID0gX29iamVjdFNwcmVhZCh7XG4gICAgICAgICAgICBlcnJvcnM6IHRydWUsXG4gICAgICAgICAgICB3YXJuaW5nczogdHJ1ZSxcbiAgICAgICAgICAgIHJ1bnRpbWVFcnJvcnM6IHRydWVcbiAgICAgICAgfSwgb3B0aW9ucy5vdmVybGF5KTtcbiAgICAgICAgZGVjb2RlT3ZlcmxheU9wdGlvbnMob3B0aW9ucy5vdmVybGF5KTtcbiAgICB9XG4gICAgZW5hYmxlZEZlYXR1cmVzLk92ZXJsYXkgPSBvcHRpb25zLm92ZXJsYXkgIT09IGZhbHNlO1xufVxuaWYgKHBhcnNlZFJlc291cmNlUXVlcnkubG9nZ2luZykge1xuICAgIG9wdGlvbnMubG9nZ2luZyA9IHBhcnNlZFJlc291cmNlUXVlcnkubG9nZ2luZztcbn1cbmlmICh0eXBlb2YgcGFyc2VkUmVzb3VyY2VRdWVyeS5yZWNvbm5lY3QgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBvcHRpb25zLnJlY29ubmVjdCA9IE51bWJlcihwYXJzZWRSZXNvdXJjZVF1ZXJ5LnJlY29ubmVjdCk7XG59XG4vKipcbiAqIEBwYXJhbSB7c3RyaW5nfSBsZXZlbFxuICovXG52YXIgc2V0QWxsTG9nTGV2ZWwgPSBmdW5jdGlvbiBzZXRBbGxMb2dMZXZlbChsZXZlbCkge1xuICAgIC8vIFRoaXMgaXMgbmVlZGVkIGJlY2F1c2UgdGhlIEhNUiBsb2dnZXIgb3BlcmF0ZSBzZXBhcmF0ZWx5IGZyb20gZGV2IHNlcnZlciBsb2dnZXJcbiAgICB3ZWJwYWNrSG90TG9nLnNldExvZ0xldmVsKGxldmVsID09PSBcInZlcmJvc2VcIiB8fCBsZXZlbCA9PT0gXCJsb2dcIiA/IFwiaW5mb1wiIDogbGV2ZWwpO1xuICAgIHNldExvZ0xldmVsKGxldmVsKTtcbn07XG5pZiAob3B0aW9ucy5sb2dnaW5nKSB7XG4gICAgc2V0QWxsTG9nTGV2ZWwob3B0aW9ucy5sb2dnaW5nKTtcbn1cbnZhciBsb2dFbmFibGVkRmVhdHVyZXMgPSBmdW5jdGlvbiBsb2dFbmFibGVkRmVhdHVyZXMoZmVhdHVyZXMpIHtcbiAgICB2YXIgbGlzdEVuYWJsZWRGZWF0dXJlcyA9IE9iamVjdC5rZXlzKGZlYXR1cmVzKTtcbiAgICBpZiAoIWZlYXR1cmVzIHx8IGxpc3RFbmFibGVkRmVhdHVyZXMubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIGxvZ1N0cmluZyA9IFwiU2VydmVyIHN0YXJ0ZWQ6XCI7XG4gICAgLy8gU2VydmVyIHN0YXJ0ZWQ6IEhvdCBNb2R1bGUgUmVwbGFjZW1lbnQgZW5hYmxlZCwgTGl2ZSBSZWxvYWRpbmcgZW5hYmxlZCwgT3ZlcmxheSBkaXNhYmxlZC5cbiAgICBmb3IgKHZhciBpID0gMDsgaSA8IGxpc3RFbmFibGVkRmVhdHVyZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgdmFyIGtleSA9IGxpc3RFbmFibGVkRmVhdHVyZXNbaV07XG4gICAgICAgIGxvZ1N0cmluZyArPSBcIiBcIi5jb25jYXQoa2V5LCBcIiBcIikuY29uY2F0KGZlYXR1cmVzW2tleV0gPyBcImVuYWJsZWRcIiA6IFwiZGlzYWJsZWRcIiwgXCIsXCIpO1xuICAgIH1cbiAgICAvLyByZXBsYWNlIGxhc3QgY29tbWEgd2l0aCBhIHBlcmlvZFxuICAgIGxvZ1N0cmluZyA9IGxvZ1N0cmluZy5zbGljZSgwLCAtMSkuY29uY2F0KFwiLlwiKTtcbiAgICBsb2cuaW5mbyhsb2dTdHJpbmcpO1xufTtcbmxvZ0VuYWJsZWRGZWF0dXJlcyhlbmFibGVkRmVhdHVyZXMpO1xuc2VsZi5hZGRFdmVudExpc3RlbmVyKFwiYmVmb3JldW5sb2FkXCIsIGZ1bmN0aW9uICgpIHtcbiAgICBzdGF0dXMuaXNVbmxvYWRpbmcgPSB0cnVlO1xufSk7XG52YXIgb3ZlcmxheSA9IHR5cGVvZiB3aW5kb3cgIT09IFwidW5kZWZpbmVkXCIgPyBjcmVhdGVPdmVybGF5KF90eXBlb2Yob3B0aW9ucy5vdmVybGF5KSA9PT0gXCJvYmplY3RcIiA/IHtcbiAgICB0cnVzdGVkVHlwZXNQb2xpY3lOYW1lOiBvcHRpb25zLm92ZXJsYXkudHJ1c3RlZFR5cGVzUG9saWN5TmFtZSxcbiAgICBjYXRjaFJ1bnRpbWVFcnJvcjogb3B0aW9ucy5vdmVybGF5LnJ1bnRpbWVFcnJvcnNcbn0gOiB7XG4gICAgdHJ1c3RlZFR5cGVzUG9saWN5TmFtZTogZmFsc2UsXG4gICAgY2F0Y2hSdW50aW1lRXJyb3I6IG9wdGlvbnMub3ZlcmxheVxufSkgOiB7XG4gICAgc2VuZDogZnVuY3Rpb24gc2VuZCgpIHsgfVxufTtcbi8qKlxuICogQHBhcmFtIHtPcHRpb25zfSBvcHRpb25zXG4gKiBAcGFyYW0ge1N0YXR1c30gY3VycmVudFN0YXR1c1xuICovXG52YXIgcmVsb2FkQXBwID0gZnVuY3Rpb24gcmVsb2FkQXBwKF9yZWYsIGN1cnJlbnRTdGF0dXMpIHtcbiAgICB2YXIgaG90ID0gX3JlZi5ob3QsIGxpdmVSZWxvYWQgPSBfcmVmLmxpdmVSZWxvYWQ7XG4gICAgaWYgKGN1cnJlbnRTdGF0dXMuaXNVbmxvYWRpbmcpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2YXIgY3VycmVudEhhc2ggPSBjdXJyZW50U3RhdHVzLmN1cnJlbnRIYXNoLCBwcmV2aW91c0hhc2ggPSBjdXJyZW50U3RhdHVzLnByZXZpb3VzSGFzaDtcbiAgICB2YXIgaXNJbml0aWFsID0gY3VycmVudEhhc2guaW5kZXhPZigvKiogQHR5cGUge3N0cmluZ30gKi8gcHJldmlvdXNIYXNoKSA+PSAwO1xuICAgIGlmIChpc0luaXRpYWwpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge1dpbmRvd30gcm9vdFdpbmRvd1xuICAgICAqIEBwYXJhbSB7bnVtYmVyfSBpbnRlcnZhbElkXG4gICAgICovXG4gICAgZnVuY3Rpb24gYXBwbHlSZWxvYWQocm9vdFdpbmRvdywgaW50ZXJ2YWxJZCkge1xuICAgICAgICBjbGVhckludGVydmFsKGludGVydmFsSWQpO1xuICAgICAgICBsb2cuaW5mbyhcIkFwcCB1cGRhdGVkLiBSZWxvYWRpbmcuLi5cIik7XG4gICAgICAgIHJvb3RXaW5kb3cubG9jYXRpb24ucmVsb2FkKCk7XG4gICAgfVxuICAgIHZhciBzZWFyY2ggPSBzZWxmLmxvY2F0aW9uLnNlYXJjaC50b0xvd2VyQ2FzZSgpO1xuICAgIHZhciBhbGxvd1RvSG90ID0gc2VhcmNoLmluZGV4T2YoXCJ3ZWJwYWNrLWRldi1zZXJ2ZXItaG90PWZhbHNlXCIpID09PSAtMTtcbiAgICB2YXIgYWxsb3dUb0xpdmVSZWxvYWQgPSBzZWFyY2guaW5kZXhPZihcIndlYnBhY2stZGV2LXNlcnZlci1saXZlLXJlbG9hZD1mYWxzZVwiKSA9PT0gLTE7XG4gICAgaWYgKGhvdCAmJiBhbGxvd1RvSG90KSB7XG4gICAgICAgIGxvZy5pbmZvKFwiQXBwIGhvdCB1cGRhdGUuLi5cIik7XG4gICAgICAgIGhvdEVtaXR0ZXIuZW1pdChcIndlYnBhY2tIb3RVcGRhdGVcIiwgY3VycmVudFN0YXR1cy5jdXJyZW50SGFzaCk7XG4gICAgICAgIGlmICh0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiAmJiBzZWxmLndpbmRvdykge1xuICAgICAgICAgICAgLy8gYnJvYWRjYXN0IHVwZGF0ZSB0byB3aW5kb3dcbiAgICAgICAgICAgIHNlbGYucG9zdE1lc3NhZ2UoXCJ3ZWJwYWNrSG90VXBkYXRlXCIuY29uY2F0KGN1cnJlbnRTdGF0dXMuY3VycmVudEhhc2gpLCBcIipcIik7XG4gICAgICAgIH1cbiAgICB9XG4gICAgLy8gYWxsb3cgcmVmcmVzaGluZyB0aGUgcGFnZSBvbmx5IGlmIGxpdmVSZWxvYWQgaXNuJ3QgZGlzYWJsZWRcbiAgICBlbHNlIGlmIChsaXZlUmVsb2FkICYmIGFsbG93VG9MaXZlUmVsb2FkKSB7XG4gICAgICAgIHZhciByb290V2luZG93ID0gc2VsZjtcbiAgICAgICAgLy8gdXNlIHBhcmVudCB3aW5kb3cgZm9yIHJlbG9hZCAoaW4gY2FzZSB3ZSdyZSBpbiBhbiBpZnJhbWUgd2l0aCBubyB2YWxpZCBzcmMpXG4gICAgICAgIHZhciBpbnRlcnZhbElkID0gc2VsZi5zZXRJbnRlcnZhbChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICBpZiAocm9vdFdpbmRvdy5sb2NhdGlvbi5wcm90b2NvbCAhPT0gXCJhYm91dDpcIikge1xuICAgICAgICAgICAgICAgIC8vIHJlbG9hZCBpbW1lZGlhdGVseSBpZiBwcm90b2NvbCBpcyB2YWxpZFxuICAgICAgICAgICAgICAgIGFwcGx5UmVsb2FkKHJvb3RXaW5kb3csIGludGVydmFsSWQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcm9vdFdpbmRvdyA9IHJvb3RXaW5kb3cucGFyZW50O1xuICAgICAgICAgICAgICAgIGlmIChyb290V2luZG93LnBhcmVudCA9PT0gcm9vdFdpbmRvdykge1xuICAgICAgICAgICAgICAgICAgICAvLyBpZiBwYXJlbnQgZXF1YWxzIGN1cnJlbnQgd2luZG93IHdlJ3ZlIHJlYWNoZWQgdGhlIHJvb3Qgd2hpY2ggd291bGQgY29udGludWUgZm9yZXZlciwgc28gdHJpZ2dlciBhIHJlbG9hZCBhbnl3YXlzXG4gICAgICAgICAgICAgICAgICAgIGFwcGx5UmVsb2FkKHJvb3RXaW5kb3csIGludGVydmFsSWQpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgfVxufTtcbnZhciBhbnNpUmVnZXggPSBuZXcgUmVnRXhwKFtcIltcXFxcdTAwMUJcXFxcdTAwOUJdW1tcXFxcXSgpIzs/XSooPzooPzooPzooPzo7Wy1hLXpBLVpcXFxcZFxcXFwvIyYuOj0/JUB+X10rKSp8W2EtekEtWlxcXFxkXSsoPzo7Wy1hLXpBLVpcXFxcZFxcXFwvIyYuOj0/JUB+X10qKSopP1xcXFx1MDAwNylcIiwgXCIoPzooPzpcXFxcZHsxLDR9KD86O1xcXFxkezAsNH0pKik/W1xcXFxkQS1QUi1UWmNmLW5xLXV5PT48fl0pKVwiXS5qb2luKFwifFwiKSwgXCJnXCIpO1xuLyoqXG4gKlxuICogU3RyaXAgW0FOU0kgZXNjYXBlIGNvZGVzXShodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9BTlNJX2VzY2FwZV9jb2RlKSBmcm9tIGEgc3RyaW5nLlxuICogQWRhcHRlZCBmcm9tIGNvZGUgb3JpZ2luYWxseSByZWxlYXNlZCBieSBTaW5kcmUgU29yaHVzXG4gKiBMaWNlbnNlZCB0aGUgTUlUIExpY2Vuc2VcbiAqXG4gKiBAcGFyYW0ge3N0cmluZ30gc3RyaW5nXG4gKiBAcmV0dXJuIHtzdHJpbmd9XG4gKi9cbnZhciBzdHJpcEFuc2kgPSBmdW5jdGlvbiBzdHJpcEFuc2koc3RyaW5nKSB7XG4gICAgaWYgKHR5cGVvZiBzdHJpbmcgIT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkV4cGVjdGVkIGEgYHN0cmluZ2AsIGdvdCBgXCIuY29uY2F0KF90eXBlb2Yoc3RyaW5nKSwgXCJgXCIpKTtcbiAgICB9XG4gICAgcmV0dXJuIHN0cmluZy5yZXBsYWNlKGFuc2lSZWdleCwgXCJcIik7XG59O1xudmFyIG9uU29ja2V0TWVzc2FnZSA9IHtcbiAgICBob3Q6IGZ1bmN0aW9uIGhvdCgpIHtcbiAgICAgICAgaWYgKHBhcnNlZFJlc291cmNlUXVlcnkuaG90ID09PSBcImZhbHNlXCIpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBvcHRpb25zLmhvdCA9IHRydWU7XG4gICAgfSxcbiAgICBsaXZlUmVsb2FkOiBmdW5jdGlvbiBsaXZlUmVsb2FkKCkge1xuICAgICAgICBpZiAocGFyc2VkUmVzb3VyY2VRdWVyeVtcImxpdmUtcmVsb2FkXCJdID09PSBcImZhbHNlXCIpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBvcHRpb25zLmxpdmVSZWxvYWQgPSB0cnVlO1xuICAgIH0sXG4gICAgaW52YWxpZDogZnVuY3Rpb24gaW52YWxpZCgpIHtcbiAgICAgICAgbG9nLmluZm8oXCJBcHAgdXBkYXRlZC4gUmVjb21waWxpbmcuLi5cIik7XG4gICAgICAgIC8vIEZpeGVzICMxMDQyLiBvdmVybGF5IGRvZXNuJ3QgY2xlYXIgaWYgZXJyb3JzIGFyZSBmaXhlZCBidXQgd2FybmluZ3MgcmVtYWluLlxuICAgICAgICBpZiAob3B0aW9ucy5vdmVybGF5KSB7XG4gICAgICAgICAgICBvdmVybGF5LnNlbmQoe1xuICAgICAgICAgICAgICAgIHR5cGU6IFwiRElTTUlTU1wiXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBzZW5kTWVzc2FnZShcIkludmFsaWRcIik7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gaGFzaFxuICAgICAqL1xuICAgIGhhc2g6IGZ1bmN0aW9uIGhhc2goX2hhc2gpIHtcbiAgICAgICAgc3RhdHVzLnByZXZpb3VzSGFzaCA9IHN0YXR1cy5jdXJyZW50SGFzaDtcbiAgICAgICAgc3RhdHVzLmN1cnJlbnRIYXNoID0gX2hhc2g7XG4gICAgfSxcbiAgICBsb2dnaW5nOiBzZXRBbGxMb2dMZXZlbCxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IHZhbHVlXG4gICAgICovXG4gICAgb3ZlcmxheTogZnVuY3Rpb24gb3ZlcmxheSh2YWx1ZSkge1xuICAgICAgICBpZiAodHlwZW9mIGRvY3VtZW50ID09PSBcInVuZGVmaW5lZFwiKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgb3B0aW9ucy5vdmVybGF5ID0gdmFsdWU7XG4gICAgICAgIGRlY29kZU92ZXJsYXlPcHRpb25zKG9wdGlvbnMub3ZlcmxheSk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge251bWJlcn0gdmFsdWVcbiAgICAgKi9cbiAgICByZWNvbm5lY3Q6IGZ1bmN0aW9uIHJlY29ubmVjdCh2YWx1ZSkge1xuICAgICAgICBpZiAocGFyc2VkUmVzb3VyY2VRdWVyeS5yZWNvbm5lY3QgPT09IFwiZmFsc2VcIikge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIG9wdGlvbnMucmVjb25uZWN0ID0gdmFsdWU7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IHZhbHVlXG4gICAgICovXG4gICAgcHJvZ3Jlc3M6IGZ1bmN0aW9uIHByb2dyZXNzKHZhbHVlKSB7XG4gICAgICAgIG9wdGlvbnMucHJvZ3Jlc3MgPSB2YWx1ZTtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7eyBwbHVnaW5OYW1lPzogc3RyaW5nLCBwZXJjZW50OiBudW1iZXIsIG1zZzogc3RyaW5nIH19IGRhdGFcbiAgICAgKi9cbiAgICBcInByb2dyZXNzLXVwZGF0ZVwiOiBmdW5jdGlvbiBwcm9ncmVzc1VwZGF0ZShkYXRhKSB7XG4gICAgICAgIGlmIChvcHRpb25zLnByb2dyZXNzKSB7XG4gICAgICAgICAgICBsb2cuaW5mbyhcIlwiLmNvbmNhdChkYXRhLnBsdWdpbk5hbWUgPyBcIltcIi5jb25jYXQoZGF0YS5wbHVnaW5OYW1lLCBcIl0gXCIpIDogXCJcIikuY29uY2F0KGRhdGEucGVyY2VudCwgXCIlIC0gXCIpLmNvbmNhdChkYXRhLm1zZywgXCIuXCIpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNQcm9ncmVzc1N1cHBvcnRlZCgpKSB7XG4gICAgICAgICAgICBpZiAodHlwZW9mIG9wdGlvbnMucHJvZ3Jlc3MgPT09IFwic3RyaW5nXCIpIHtcbiAgICAgICAgICAgICAgICB2YXIgcHJvZ3Jlc3MgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKFwid2RzLXByb2dyZXNzXCIpO1xuICAgICAgICAgICAgICAgIGlmICghcHJvZ3Jlc3MpIHtcbiAgICAgICAgICAgICAgICAgICAgZGVmaW5lUHJvZ3Jlc3NFbGVtZW50KCk7XG4gICAgICAgICAgICAgICAgICAgIHByb2dyZXNzID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudChcIndkcy1wcm9ncmVzc1wiKTtcbiAgICAgICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChwcm9ncmVzcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHByb2dyZXNzLnNldEF0dHJpYnV0ZShcInByb2dyZXNzXCIsIGRhdGEucGVyY2VudCk7XG4gICAgICAgICAgICAgICAgcHJvZ3Jlc3Muc2V0QXR0cmlidXRlKFwidHlwZVwiLCBvcHRpb25zLnByb2dyZXNzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBzZW5kTWVzc2FnZShcIlByb2dyZXNzXCIsIGRhdGEpO1xuICAgIH0sXG4gICAgXCJzdGlsbC1va1wiOiBmdW5jdGlvbiBzdGlsbE9rKCkge1xuICAgICAgICBsb2cuaW5mbyhcIk5vdGhpbmcgY2hhbmdlZC5cIik7XG4gICAgICAgIGlmIChvcHRpb25zLm92ZXJsYXkpIHtcbiAgICAgICAgICAgIG92ZXJsYXkuc2VuZCh7XG4gICAgICAgICAgICAgICAgdHlwZTogXCJESVNNSVNTXCJcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHNlbmRNZXNzYWdlKFwiU3RpbGxPa1wiKTtcbiAgICB9LFxuICAgIG9rOiBmdW5jdGlvbiBvaygpIHtcbiAgICAgICAgc2VuZE1lc3NhZ2UoXCJPa1wiKTtcbiAgICAgICAgaWYgKG9wdGlvbnMub3ZlcmxheSkge1xuICAgICAgICAgICAgb3ZlcmxheS5zZW5kKHtcbiAgICAgICAgICAgICAgICB0eXBlOiBcIkRJU01JU1NcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmVsb2FkQXBwKG9wdGlvbnMsIHN0YXR1cyk7XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge3N0cmluZ30gZmlsZVxuICAgICAqL1xuICAgIFwic3RhdGljLWNoYW5nZWRcIjogZnVuY3Rpb24gc3RhdGljQ2hhbmdlZChmaWxlKSB7XG4gICAgICAgIGxvZy5pbmZvKFwiXCIuY29uY2F0KGZpbGUgPyBcIlxcXCJcIi5jb25jYXQoZmlsZSwgXCJcXFwiXCIpIDogXCJDb250ZW50XCIsIFwiIGZyb20gc3RhdGljIGRpcmVjdG9yeSB3YXMgY2hhbmdlZC4gUmVsb2FkaW5nLi4uXCIpKTtcbiAgICAgICAgc2VsZi5sb2NhdGlvbi5yZWxvYWQoKTtcbiAgICB9LFxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7RXJyb3JbXX0gd2FybmluZ3NcbiAgICAgKiBAcGFyYW0ge2FueX0gcGFyYW1zXG4gICAgICovXG4gICAgd2FybmluZ3M6IGZ1bmN0aW9uIHdhcm5pbmdzKF93YXJuaW5ncywgcGFyYW1zKSB7XG4gICAgICAgIGxvZy53YXJuKFwiV2FybmluZ3Mgd2hpbGUgY29tcGlsaW5nLlwiKTtcbiAgICAgICAgdmFyIHByaW50YWJsZVdhcm5pbmdzID0gX3dhcm5pbmdzLm1hcChmdW5jdGlvbiAoZXJyb3IpIHtcbiAgICAgICAgICAgIHZhciBfZm9ybWF0UHJvYmxlbSA9IGZvcm1hdFByb2JsZW0oXCJ3YXJuaW5nXCIsIGVycm9yKSwgaGVhZGVyID0gX2Zvcm1hdFByb2JsZW0uaGVhZGVyLCBib2R5ID0gX2Zvcm1hdFByb2JsZW0uYm9keTtcbiAgICAgICAgICAgIHJldHVybiBcIlwiLmNvbmNhdChoZWFkZXIsIFwiXFxuXCIpLmNvbmNhdChzdHJpcEFuc2koYm9keSkpO1xuICAgICAgICB9KTtcbiAgICAgICAgc2VuZE1lc3NhZ2UoXCJXYXJuaW5nc1wiLCBwcmludGFibGVXYXJuaW5ncyk7XG4gICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgcHJpbnRhYmxlV2FybmluZ3MubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGxvZy53YXJuKHByaW50YWJsZVdhcm5pbmdzW2ldKTtcbiAgICAgICAgfVxuICAgICAgICB2YXIgb3ZlcmxheVdhcm5pbmdzU2V0dGluZyA9IHR5cGVvZiBvcHRpb25zLm92ZXJsYXkgPT09IFwiYm9vbGVhblwiID8gb3B0aW9ucy5vdmVybGF5IDogb3B0aW9ucy5vdmVybGF5ICYmIG9wdGlvbnMub3ZlcmxheS53YXJuaW5ncztcbiAgICAgICAgaWYgKG92ZXJsYXlXYXJuaW5nc1NldHRpbmcpIHtcbiAgICAgICAgICAgIHZhciB3YXJuaW5nc1RvRGlzcGxheSA9IHR5cGVvZiBvdmVybGF5V2FybmluZ3NTZXR0aW5nID09PSBcImZ1bmN0aW9uXCIgPyBfd2FybmluZ3MuZmlsdGVyKG92ZXJsYXlXYXJuaW5nc1NldHRpbmcpIDogX3dhcm5pbmdzO1xuICAgICAgICAgICAgaWYgKHdhcm5pbmdzVG9EaXNwbGF5Lmxlbmd0aCkge1xuICAgICAgICAgICAgICAgIG92ZXJsYXkuc2VuZCh7XG4gICAgICAgICAgICAgICAgICAgIHR5cGU6IFwiQlVJTERfRVJST1JcIixcbiAgICAgICAgICAgICAgICAgICAgbGV2ZWw6IFwid2FybmluZ1wiLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlczogX3dhcm5pbmdzXG4gICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHBhcmFtcyAmJiBwYXJhbXMucHJldmVudFJlbG9hZGluZykge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHJlbG9hZEFwcChvcHRpb25zLCBzdGF0dXMpO1xuICAgIH0sXG4gICAgLyoqXG4gICAgICogQHBhcmFtIHtFcnJvcltdfSBlcnJvcnNcbiAgICAgKi9cbiAgICBlcnJvcnM6IGZ1bmN0aW9uIGVycm9ycyhfZXJyb3JzKSB7XG4gICAgICAgIGxvZy5lcnJvcihcIkVycm9ycyB3aGlsZSBjb21waWxpbmcuIFJlbG9hZCBwcmV2ZW50ZWQuXCIpO1xuICAgICAgICB2YXIgcHJpbnRhYmxlRXJyb3JzID0gX2Vycm9ycy5tYXAoZnVuY3Rpb24gKGVycm9yKSB7XG4gICAgICAgICAgICB2YXIgX2Zvcm1hdFByb2JsZW0yID0gZm9ybWF0UHJvYmxlbShcImVycm9yXCIsIGVycm9yKSwgaGVhZGVyID0gX2Zvcm1hdFByb2JsZW0yLmhlYWRlciwgYm9keSA9IF9mb3JtYXRQcm9ibGVtMi5ib2R5O1xuICAgICAgICAgICAgcmV0dXJuIFwiXCIuY29uY2F0KGhlYWRlciwgXCJcXG5cIikuY29uY2F0KHN0cmlwQW5zaShib2R5KSk7XG4gICAgICAgIH0pO1xuICAgICAgICBzZW5kTWVzc2FnZShcIkVycm9yc1wiLCBwcmludGFibGVFcnJvcnMpO1xuICAgICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHByaW50YWJsZUVycm9ycy5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgbG9nLmVycm9yKHByaW50YWJsZUVycm9yc1tpXSk7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG92ZXJsYXlFcnJvcnNTZXR0aW5ncyA9IHR5cGVvZiBvcHRpb25zLm92ZXJsYXkgPT09IFwiYm9vbGVhblwiID8gb3B0aW9ucy5vdmVybGF5IDogb3B0aW9ucy5vdmVybGF5ICYmIG9wdGlvbnMub3ZlcmxheS5lcnJvcnM7XG4gICAgICAgIGlmIChvdmVybGF5RXJyb3JzU2V0dGluZ3MpIHtcbiAgICAgICAgICAgIHZhciBlcnJvcnNUb0Rpc3BsYXkgPSB0eXBlb2Ygb3ZlcmxheUVycm9yc1NldHRpbmdzID09PSBcImZ1bmN0aW9uXCIgPyBfZXJyb3JzLmZpbHRlcihvdmVybGF5RXJyb3JzU2V0dGluZ3MpIDogX2Vycm9ycztcbiAgICAgICAgICAgIGlmIChlcnJvcnNUb0Rpc3BsYXkubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgb3ZlcmxheS5zZW5kKHtcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJCVUlMRF9FUlJPUlwiLFxuICAgICAgICAgICAgICAgICAgICBsZXZlbDogXCJlcnJvclwiLFxuICAgICAgICAgICAgICAgICAgICBtZXNzYWdlczogX2Vycm9yc1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSxcbiAgICAvKipcbiAgICAgKiBAcGFyYW0ge0Vycm9yfSBlcnJvclxuICAgICAqL1xuICAgIGVycm9yOiBmdW5jdGlvbiBlcnJvcihfZXJyb3IpIHtcbiAgICAgICAgbG9nLmVycm9yKF9lcnJvcik7XG4gICAgfSxcbiAgICBjbG9zZTogZnVuY3Rpb24gY2xvc2UoKSB7XG4gICAgICAgIGxvZy5pbmZvKFwiRGlzY29ubmVjdGVkIVwiKTtcbiAgICAgICAgaWYgKG9wdGlvbnMub3ZlcmxheSkge1xuICAgICAgICAgICAgb3ZlcmxheS5zZW5kKHtcbiAgICAgICAgICAgICAgICB0eXBlOiBcIkRJU01JU1NcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgc2VuZE1lc3NhZ2UoXCJDbG9zZVwiKTtcbiAgICB9XG59O1xuLyoqXG4gKiBAcGFyYW0ge3sgcHJvdG9jb2w/OiBzdHJpbmcsIGF1dGg/OiBzdHJpbmcsIGhvc3RuYW1lPzogc3RyaW5nLCBwb3J0Pzogc3RyaW5nLCBwYXRobmFtZT86IHN0cmluZywgc2VhcmNoPzogc3RyaW5nLCBoYXNoPzogc3RyaW5nLCBzbGFzaGVzPzogYm9vbGVhbiB9fSBvYmpVUkxcbiAqIEByZXR1cm5zIHtzdHJpbmd9XG4gKi9cbnZhciBmb3JtYXRVUkwgPSBmdW5jdGlvbiBmb3JtYXRVUkwob2JqVVJMKSB7XG4gICAgdmFyIHByb3RvY29sID0gb2JqVVJMLnByb3RvY29sIHx8IFwiXCI7XG4gICAgaWYgKHByb3RvY29sICYmIHByb3RvY29sLnN1YnN0cigtMSkgIT09IFwiOlwiKSB7XG4gICAgICAgIHByb3RvY29sICs9IFwiOlwiO1xuICAgIH1cbiAgICB2YXIgYXV0aCA9IG9ialVSTC5hdXRoIHx8IFwiXCI7XG4gICAgaWYgKGF1dGgpIHtcbiAgICAgICAgYXV0aCA9IGVuY29kZVVSSUNvbXBvbmVudChhdXRoKTtcbiAgICAgICAgYXV0aCA9IGF1dGgucmVwbGFjZSgvJTNBL2ksIFwiOlwiKTtcbiAgICAgICAgYXV0aCArPSBcIkBcIjtcbiAgICB9XG4gICAgdmFyIGhvc3QgPSBcIlwiO1xuICAgIGlmIChvYmpVUkwuaG9zdG5hbWUpIHtcbiAgICAgICAgaG9zdCA9IGF1dGggKyAob2JqVVJMLmhvc3RuYW1lLmluZGV4T2YoXCI6XCIpID09PSAtMSA/IG9ialVSTC5ob3N0bmFtZSA6IFwiW1wiLmNvbmNhdChvYmpVUkwuaG9zdG5hbWUsIFwiXVwiKSk7XG4gICAgICAgIGlmIChvYmpVUkwucG9ydCkge1xuICAgICAgICAgICAgaG9zdCArPSBcIjpcIi5jb25jYXQob2JqVVJMLnBvcnQpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHZhciBwYXRobmFtZSA9IG9ialVSTC5wYXRobmFtZSB8fCBcIlwiO1xuICAgIGlmIChvYmpVUkwuc2xhc2hlcykge1xuICAgICAgICBob3N0ID0gXCIvL1wiLmNvbmNhdChob3N0IHx8IFwiXCIpO1xuICAgICAgICBpZiAocGF0aG5hbWUgJiYgcGF0aG5hbWUuY2hhckF0KDApICE9PSBcIi9cIikge1xuICAgICAgICAgICAgcGF0aG5hbWUgPSBcIi9cIi5jb25jYXQocGF0aG5hbWUpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2UgaWYgKCFob3N0KSB7XG4gICAgICAgIGhvc3QgPSBcIlwiO1xuICAgIH1cbiAgICB2YXIgc2VhcmNoID0gb2JqVVJMLnNlYXJjaCB8fCBcIlwiO1xuICAgIGlmIChzZWFyY2ggJiYgc2VhcmNoLmNoYXJBdCgwKSAhPT0gXCI/XCIpIHtcbiAgICAgICAgc2VhcmNoID0gXCI/XCIuY29uY2F0KHNlYXJjaCk7XG4gICAgfVxuICAgIHZhciBoYXNoID0gb2JqVVJMLmhhc2ggfHwgXCJcIjtcbiAgICBpZiAoaGFzaCAmJiBoYXNoLmNoYXJBdCgwKSAhPT0gXCIjXCIpIHtcbiAgICAgICAgaGFzaCA9IFwiI1wiLmNvbmNhdChoYXNoKTtcbiAgICB9XG4gICAgcGF0aG5hbWUgPSBwYXRobmFtZS5yZXBsYWNlKC9bPyNdL2csIFxuICAgIC8qKlxuICAgICAqIEBwYXJhbSB7c3RyaW5nfSBtYXRjaFxuICAgICAqIEByZXR1cm5zIHtzdHJpbmd9XG4gICAgICovXG4gICAgZnVuY3Rpb24gKG1hdGNoKSB7XG4gICAgICAgIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQobWF0Y2gpO1xuICAgIH0pO1xuICAgIHNlYXJjaCA9IHNlYXJjaC5yZXBsYWNlKFwiI1wiLCBcIiUyM1wiKTtcbiAgICByZXR1cm4gXCJcIi5jb25jYXQocHJvdG9jb2wpLmNvbmNhdChob3N0KS5jb25jYXQocGF0aG5hbWUpLmNvbmNhdChzZWFyY2gpLmNvbmNhdChoYXNoKTtcbn07XG4vKipcbiAqIEBwYXJhbSB7VVJMICYgeyBmcm9tQ3VycmVudFNjcmlwdD86IGJvb2xlYW4gfX0gcGFyc2VkVVJMXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG52YXIgY3JlYXRlU29ja2V0VVJMID0gZnVuY3Rpb24gY3JlYXRlU29ja2V0VVJMKHBhcnNlZFVSTCkge1xuICAgIHZhciBob3N0bmFtZSA9IHBhcnNlZFVSTC5ob3N0bmFtZTtcbiAgICAvLyBOb2RlLmpzIG1vZHVsZSBwYXJzZXMgaXQgYXMgYDo6YFxuICAgIC8vIGBuZXcgVVJMKHVybFN0cmluZywgW2Jhc2VVUkxTdHJpbmddKWAgcGFyc2VzIGl0IGFzICdbOjpdJ1xuICAgIHZhciBpc0luQWRkckFueSA9IGhvc3RuYW1lID09PSBcIjAuMC4wLjBcIiB8fCBob3N0bmFtZSA9PT0gXCI6OlwiIHx8IGhvc3RuYW1lID09PSBcIls6Ol1cIjtcbiAgICAvLyB3aHkgZG8gd2UgbmVlZCB0aGlzIGNoZWNrP1xuICAgIC8vIGhvc3RuYW1lIG4vYSBmb3IgZmlsZSBwcm90b2NvbCAoZXhhbXBsZSwgd2hlbiB1c2luZyBlbGVjdHJvbiwgaW9uaWMpXG4gICAgLy8gc2VlOiBodHRwczovL2dpdGh1Yi5jb20vd2VicGFjay93ZWJwYWNrLWRldi1zZXJ2ZXIvcHVsbC8zODRcbiAgICBpZiAoaXNJbkFkZHJBbnkgJiYgc2VsZi5sb2NhdGlvbi5ob3N0bmFtZSAmJiBzZWxmLmxvY2F0aW9uLnByb3RvY29sLmluZGV4T2YoXCJodHRwXCIpID09PSAwKSB7XG4gICAgICAgIGhvc3RuYW1lID0gc2VsZi5sb2NhdGlvbi5ob3N0bmFtZTtcbiAgICB9XG4gICAgdmFyIHNvY2tldFVSTFByb3RvY29sID0gcGFyc2VkVVJMLnByb3RvY29sIHx8IHNlbGYubG9jYXRpb24ucHJvdG9jb2w7XG4gICAgLy8gV2hlbiBodHRwcyBpcyB1c2VkIGluIHRoZSBhcHAsIHNlY3VyZSB3ZWIgc29ja2V0cyBhcmUgYWx3YXlzIG5lY2Vzc2FyeSBiZWNhdXNlIHRoZSBicm93c2VyIGRvZXNuJ3QgYWNjZXB0IG5vbi1zZWN1cmUgd2ViIHNvY2tldHMuXG4gICAgaWYgKHNvY2tldFVSTFByb3RvY29sID09PSBcImF1dG86XCIgfHwgaG9zdG5hbWUgJiYgaXNJbkFkZHJBbnkgJiYgc2VsZi5sb2NhdGlvbi5wcm90b2NvbCA9PT0gXCJodHRwczpcIikge1xuICAgICAgICBzb2NrZXRVUkxQcm90b2NvbCA9IHNlbGYubG9jYXRpb24ucHJvdG9jb2w7XG4gICAgfVxuICAgIHNvY2tldFVSTFByb3RvY29sID0gc29ja2V0VVJMUHJvdG9jb2wucmVwbGFjZSgvXig/Omh0dHB8ListZXh0ZW5zaW9ufGZpbGUpL2ksIFwid3NcIik7XG4gICAgdmFyIHNvY2tldFVSTEF1dGggPSBcIlwiO1xuICAgIC8vIGBuZXcgVVJMKHVybFN0cmluZywgW2Jhc2VVUkxzdHJpbmddKWAgZG9lc24ndCBoYXZlIGBhdXRoYCBwcm9wZXJ0eVxuICAgIC8vIFBhcnNlIGF1dGhlbnRpY2F0aW9uIGNyZWRlbnRpYWxzIGluIGNhc2Ugd2UgbmVlZCB0aGVtXG4gICAgaWYgKHBhcnNlZFVSTC51c2VybmFtZSkge1xuICAgICAgICBzb2NrZXRVUkxBdXRoID0gcGFyc2VkVVJMLnVzZXJuYW1lO1xuICAgICAgICAvLyBTaW5jZSBIVFRQIGJhc2ljIGF1dGhlbnRpY2F0aW9uIGRvZXMgbm90IGFsbG93IGVtcHR5IHVzZXJuYW1lLFxuICAgICAgICAvLyB3ZSBvbmx5IGluY2x1ZGUgcGFzc3dvcmQgaWYgdGhlIHVzZXJuYW1lIGlzIG5vdCBlbXB0eS5cbiAgICAgICAgaWYgKHBhcnNlZFVSTC5wYXNzd29yZCkge1xuICAgICAgICAgICAgLy8gUmVzdWx0OiA8dXNlcm5hbWU+OjxwYXNzd29yZD5cbiAgICAgICAgICAgIHNvY2tldFVSTEF1dGggPSBzb2NrZXRVUkxBdXRoLmNvbmNhdChcIjpcIiwgcGFyc2VkVVJMLnBhc3N3b3JkKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICAvLyBJbiBjYXNlIHRoZSBob3N0IGlzIGEgcmF3IElQdjYgYWRkcmVzcywgaXQgY2FuIGJlIGVuY2xvc2VkIGluXG4gICAgLy8gdGhlIGJyYWNrZXRzIGFzIHRoZSBicmFja2V0cyBhcmUgbmVlZGVkIGluIHRoZSBmaW5hbCBVUkwgc3RyaW5nLlxuICAgIC8vIE5lZWQgdG8gcmVtb3ZlIHRob3NlIGFzIHVybC5mb3JtYXQgYmxpbmRseSBhZGRzIGl0cyBvd24gc2V0IG9mIGJyYWNrZXRzXG4gICAgLy8gaWYgdGhlIGhvc3Qgc3RyaW5nIGNvbnRhaW5zIGNvbG9ucy4gVGhhdCB3b3VsZCBsZWFkIHRvIG5vbi13b3JraW5nXG4gICAgLy8gZG91YmxlIGJyYWNrZXRzIChlLmcuIFtbOjpdXSkgaG9zdFxuICAgIC8vXG4gICAgLy8gQWxsIG9mIHRoZXNlIHdlYiBzb2NrZXQgdXJsIHBhcmFtcyBhcmUgb3B0aW9uYWxseSBwYXNzZWQgaW4gdGhyb3VnaCByZXNvdXJjZVF1ZXJ5LFxuICAgIC8vIHNvIHdlIG5lZWQgdG8gZmFsbCBiYWNrIHRvIHRoZSBkZWZhdWx0IGlmIHRoZXkgYXJlIG5vdCBwcm92aWRlZFxuICAgIHZhciBzb2NrZXRVUkxIb3N0bmFtZSA9IChob3N0bmFtZSB8fCBzZWxmLmxvY2F0aW9uLmhvc3RuYW1lIHx8IFwibG9jYWxob3N0XCIpLnJlcGxhY2UoL15cXFsoLiopXFxdJC8sIFwiJDFcIik7XG4gICAgdmFyIHNvY2tldFVSTFBvcnQgPSBwYXJzZWRVUkwucG9ydDtcbiAgICBpZiAoIXNvY2tldFVSTFBvcnQgfHwgc29ja2V0VVJMUG9ydCA9PT0gXCIwXCIpIHtcbiAgICAgICAgc29ja2V0VVJMUG9ydCA9IHNlbGYubG9jYXRpb24ucG9ydDtcbiAgICB9XG4gICAgLy8gSWYgcGF0aCBpcyBwcm92aWRlZCBpdCdsbCBiZSBwYXNzZWQgaW4gdmlhIHRoZSByZXNvdXJjZVF1ZXJ5IGFzIGFcbiAgICAvLyBxdWVyeSBwYXJhbSBzbyBpdCBoYXMgdG8gYmUgcGFyc2VkIG91dCBvZiB0aGUgcXVlcnlzdHJpbmcgaW4gb3JkZXIgZm9yIHRoZVxuICAgIC8vIGNsaWVudCB0byBvcGVuIHRoZSBzb2NrZXQgdG8gdGhlIGNvcnJlY3QgbG9jYXRpb24uXG4gICAgdmFyIHNvY2tldFVSTFBhdGhuYW1lID0gXCIvd3NcIjtcbiAgICBpZiAocGFyc2VkVVJMLnBhdGhuYW1lICYmICFwYXJzZWRVUkwuZnJvbUN1cnJlbnRTY3JpcHQpIHtcbiAgICAgICAgc29ja2V0VVJMUGF0aG5hbWUgPSBwYXJzZWRVUkwucGF0aG5hbWU7XG4gICAgfVxuICAgIHJldHVybiBmb3JtYXRVUkwoe1xuICAgICAgICBwcm90b2NvbDogc29ja2V0VVJMUHJvdG9jb2wsXG4gICAgICAgIGF1dGg6IHNvY2tldFVSTEF1dGgsXG4gICAgICAgIGhvc3RuYW1lOiBzb2NrZXRVUkxIb3N0bmFtZSxcbiAgICAgICAgcG9ydDogc29ja2V0VVJMUG9ydCxcbiAgICAgICAgcGF0aG5hbWU6IHNvY2tldFVSTFBhdGhuYW1lLFxuICAgICAgICBzbGFzaGVzOiB0cnVlXG4gICAgfSk7XG59O1xudmFyIHNvY2tldFVSTCA9IGNyZWF0ZVNvY2tldFVSTChwYXJzZWRSZXNvdXJjZVF1ZXJ5KTtcbnNvY2tldChzb2NrZXRVUkwsIG9uU29ja2V0TWVzc2FnZSwgb3B0aW9ucy5yZWNvbm5lY3QpO1xuZXhwb3J0IHsgZ2V0Q3VycmVudFNjcmlwdFNvdXJjZSwgcGFyc2VVUkwsIGNyZWF0ZVNvY2tldFVSTCB9O1xuIiwiaW1wb3J0IHsgZ2V0Q29uc2VudEZvciwgb25Db25zZW50IH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgY29tbWVyY2lhbEZlYXR1cmVzIH0gZnJvbSAnLi9saWIvY29tbWVyY2lhbC1mZWF0dXJlcyc7XG5jb25zdCBzaG91bGRCb290Q29uc2VudGxlc3MgPSAoY29uc2VudFN0YXRlKSA9PiB7XG4gICAgcmV0dXJuICh3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLm9wdE91dEFkdmVydGlzaW5nICYmXG4gICAgICAgIGNvbnNlbnRTdGF0ZS50Y2Z2MiAmJlxuICAgICAgICAhZ2V0Q29uc2VudEZvcignZ29vZ2xldGFnJywgY29uc2VudFN0YXRlKSAmJlxuICAgICAgICAhY29tbWVyY2lhbEZlYXR1cmVzLmFkRnJlZSk7XG59O1xuLyoqXG4gKiBDaG9vc2Ugd2hldGhlciB0byBsYXVuY2ggR29vZ2xldGFnIG9yIE9wdCBPdXQgdGFnIChvb3RhZykgYmFzZWQgb24gY29uc2VudCBzdGF0ZVxuICovXG52b2lkIChhc3luYyAoKSA9PiB7XG4gICAgY29uc3QgY29uc2VudFN0YXRlID0gYXdhaXQgb25Db25zZW50KCk7XG4gICAgLy8gT25seSBsb2FkIHRoZSBPcHQgT3V0IHRhZyBpZjpcbiAgICAvLyAtIE9wdCBPdXQgc3dpdGNoIGlzIG9uXG4gICAgLy8gLSBpbiBUQ0YgcmVnaW9uXG4gICAgLy8gLSBubyBjb25zZW50IGZvciBHb29nbGV0YWdcbiAgICAvLyAtIHRoZSB1c2VyIGlzIG5vdCBhIHN1YnNjcmliZXJcbiAgICBpZiAoc2hvdWxkQm9vdENvbnNlbnRsZXNzKGNvbnNlbnRTdGF0ZSkpIHtcbiAgICAgICAgdm9pZCBpbXBvcnQoXG4gICAgICAgIC8qIHdlYnBhY2tDaHVua05hbWU6IFwiY29uc2VudGxlc3MtYWR2ZXJ0aXNpbmdcIiAqL1xuICAgICAgICAnLi9pbml0L2NvbnNlbnRsZXNzLWFkdmVydGlzaW5nJykudGhlbigoeyBib290Q29uc2VudGxlc3MgfSkgPT4gYm9vdENvbnNlbnRsZXNzKGNvbnNlbnRTdGF0ZSkpO1xuICAgIH1cbiAgICBlbHNlIGlmIChjb21tZXJjaWFsRmVhdHVyZXMuYWRGcmVlKSB7XG4gICAgICAgIHZvaWQgaW1wb3J0KFxuICAgICAgICAvKiB3ZWJwYWNrQ2h1bmtOYW1lOiBcImFkLWZyZWVcIiAqL1xuICAgICAgICAnLi9pbml0L2FkLWZyZWUnKS50aGVuKCh7IGJvb3RDb21tZXJjaWFsV2hlblJlYWR5IH0pID0+IGJvb3RDb21tZXJjaWFsV2hlblJlYWR5KCkpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgdm9pZCBpbXBvcnQoXG4gICAgICAgIC8qIHdlYnBhY2tDaHVua05hbWU6IFwiY29uc2VudGVkLWFkdmVydGlzaW5nXCIgKi9cbiAgICAgICAgJy4vaW5pdC9jb25zZW50ZWQtYWR2ZXJ0aXNpbmcnKS50aGVuKCh7IGJvb3RDb21tZXJjaWFsV2hlblJlYWR5IH0pID0+IGJvb3RDb21tZXJjaWFsV2hlblJlYWR5KCkpO1xuICAgIH1cbn0pKCk7XG4iXSwibmFtZXMiOlsiYXBpIiwiY29tbWFuZCIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0Iiwid2luZG93IiwiX191c3BhcGkiLCJyZXN1bHQiLCJzdWNjZXNzIiwiRXJyb3IiLCJjb25jYXQiLCJnZXRVU1BEYXRhIiwiZ2V0Q29uc2VudFN0YXRlIiwiX3JlZiIsIl9hc3luY1RvR2VuZXJhdG9yIiwidXNwRGF0YSIsIm9wdGVkT3V0IiwidXNwU3RyaW5nIiwiY2hhckF0IiwicGVyc29uYWxpc2VkQWR2ZXJ0aXNpbmciLCJhcHBseSIsImFyZ3VtZW50cyIsImdldEN1cnJlbnRGcmFtZXdvcmsiLCJnZXRJc0NvbnNlbnRPclBheSIsIm1hcmsiLCJQUklWQUNZX01BTkFHRVJfQVVTVFJBTElBIiwiUFJJVkFDWV9NQU5BR0VSX1VTTkFUIiwiUFJJVkFDWV9NQU5BR0VSX1RDRlYyIiwiUFJJVkFDWV9NQU5BR0VSX1RDRlYyX0NPTlNFTlRfT1JfUEFZIiwid2lsbFNob3dQcml2YWN5TWVzc2FnZSIsIndpbGxTaG93UHJpdmFjeU1lc3NhZ2UkMSIsImluaXQiLCJpbml0JDEiLCJmcmFtZXdvcmsiLCJjb3VudHJ5Q29kZSIsImlzVXNlclNpZ25lZEluIiwidXNlTm9uQWR2ZXJ0aXNlZExpc3QiLCJwdWJEYXRhIiwic2hvd1ByaXZhY3lNYW5hZ2VyIiwiX3dpbmRvdyRfc3BfIiwiX3dpbmRvdyRfc3BfJGxvYWRQcml2IiwiX3dpbmRvdyRfc3BfMiIsIl93aW5kb3ckX3NwXzIkbG9hZFByaSIsIl93aW5kb3ckX3NwXzMiLCJfd2luZG93JF9zcF8zJGxvYWRQcmkiLCJfc3BfIiwiZ2RwciIsImxvYWRQcml2YWN5TWFuYWdlck1vZGFsIiwiY2FsbCIsInVzbmF0IiwiY2NwYSIsIkNNUCIsIkNPT0tJRV9OQU1FIiwiZGlzYWJsZSIsImRvY3VtZW50IiwiY29va2llIiwiZW5hYmxlIiwiaXNEaXNhYmxlZCIsIlJlZ0V4cCIsInRlc3QiLCJzZWN0aW9uRXhjbHVzaW9uTGlzdCIsImlzRXhjbHVkZWRGcm9tQ01QIiwicGFnZVNlY3Rpb24iLCJzb21lIiwic2VjdGlvbiIsIlZlbmRvcklEcyIsImdldENvbnNlbnRGb3IiLCJ2ZW5kb3IiLCJjb25zZW50IiwiX2NvbnNlbnQkdGNmdjIiLCJzb3VyY2Vwb2ludElkcyIsImxlbmd0aCIsImRvTm90U2VsbCIsImF1cyIsImZvdW5kU291cmNlcG9pbnRJZCIsImZpbmQiLCJpZCIsIl9jb25zZW50JHRjZnYiLCJ0Y2Z2MiIsInZlbmRvckNvbnNlbnRzIiwiY29uc29sZSIsIndhcm4iLCJ0Y2Z2MkNvbnNlbnQiLCJsb2ciLCJjdXJyZW50RnJhbWV3b3JrIiwic2V0Q3VycmVudEZyYW1ld29yayIsImdldEZyYW1ld29yayIsInZlcnNpb24iLCJnZXRDb25zZW50Rm9yJDIiLCJvbkNvbnNlbnQiLCJvbkNvbnNlbnQkMiIsIm9uQ29uc2VudENoYW5nZSIsIm9uQ29uc2VudENoYW5nZSQyIiwiaXNTZXJ2ZXJTaWRlIiwiY21wIiwiY21wJDEiLCJvbkNvbnNlbnQkMSIsIm9uQ29uc2VudENoYW5nZSQxIiwiZ2V0Q29uc2VudEZvciQxIiwiaW5pdFZlbmRvckRhdGFNYW5hZ2VyIiwiX2EiLCJfYiIsIl9jIiwiX2QiLCJndUNtcEhvdEZpeCIsIl93aWxsU2hvd1ByaXZhY3lNZXNzYWdlIiwiaW5pdENvbXBsZXRlIiwicmVzb2x2ZUluaXRpYWxpc2VkIiwiaW5pdGlhbGlzZWQiLCJjb3VudHJ5IiwiX3dpbmRvdyRndUNtcEhvdEZpeCRjIiwiX3dpbmRvdyRndUNtcEhvdEZpeCRjMiIsInRoZW4iLCJ3aWxsU2hvd1ZhbHVlIiwid2lsbFNob3dQcml2YWN5TWVzc2FnZVN5bmMiLCJoYXNJbml0aWFsaXNlZCIsIl9hJGNtcCIsIl9faXNEaXNhYmxlZCIsIl9fZW5hYmxlIiwiX19kaXNhYmxlIiwiX2Ikb25Db25zZW50IiwiX2Mkb25Db25zZW50Q2hhbmdlIiwiX2QkZ2V0Q29uc2VudEZvciIsImNvbnNlbnRPclBheUNvdW50cmllcyIsIl9pc0NvbnNlbnRPclBheSIsInNldElzQ29uc2VudE9yUGF5IiwiaXNDb25zZW50T3JQYXkiLCJpc0NvbnNlbnRPclBheUNvdW50cnkiLCJpbmNsdWRlcyIsImlzR3VhcmRpYW4iLCJpc0d1YXJkaWFuRG9tYWluIiwibG9jYXRpb24iLCJob3N0IiwiZW5kc1dpdGgiLCJsYWJlbCIsIl93aW5kb3ckcGVyZm9ybWFuY2UiLCJfd2luZG93JHBlcmZvcm1hbmNlJG0iLCJwZXJmb3JtYW5jZSIsInByb2Nlc3MiLCJlbnYiLCJOT0RFX0VOViIsIlNvdXJjZVBvaW50Q2hvaWNlVHlwZXMiLCJnZXRPcGhhblJlY29yZEZ1bmN0aW9uIiwiX3dpbmRvdyRndWFyZGlhbiIsInJlY29yZCIsImd1YXJkaWFuIiwib3BoYW4iLCJjb25zdHJ1Y3RCYW5uZXJNZXNzYWdlSWQiLCJtZXNzYWdlSWQiLCJtZXNzYWdlVHlwZSIsInNlbmRDb25zZW50Q2hvaWNlc1RvT3BoYW4iLCJjaG9pY2VUeXBlIiwiYWN0aW9uVmFsdWUiLCJBY2NlcHRBbGwiLCJSZWplY3RBbGwiLCJEaXNtaXNzIiwiTWFuYWdlQ29va2llcyIsImNvbXBvbmVudEV2ZW50IiwiY29tcG9uZW50IiwiY29tcG9uZW50VHlwZSIsImFjdGlvbiIsInZhbHVlIiwic2VuZE1lc3NhZ2VSZWFkeVRvT3BoYW4iLCJzZW5kSnVyaXNkaWN0aW9uTWlzbWF0Y2hUb09waGFuIiwiZ2V0R3BjU2lnbmFsIiwibmF2aWdhdG9yIiwiZ2xvYmFsUHJpdmFjeUNvbnRyb2wiLCJBQ0NPVU5UX0lEIiwiUFJPUEVSVFlfSURfTUFJTiIsIlBST1BFUlRZX0lEX1NVQkRPTUFJTiIsIlBST1BFUlRZX0lEX0FVU1RSQUxJQSIsIlBST1BFUlRZX0hSRUZfU1VCRE9NQUlOIiwiUFJPUEVSVFlfSFJFRl9NQUlOIiwiRU5EUE9JTlQiLCJnZXRDb29raWUiLCJpc1N0cmluZyIsImlzVW5kZWZpbmVkIiwicHVycG9zZUlkVG9Ob25BZHZlcnRpc2luZ1B1cnBvc2VzTWFwIiwiTWFwIiwic3BCYXNlVXJsIiwibWVyZ2VWZW5kb3JMaXN0IiwidXNlckNvbnNlbnQiLCJnZXRVc2VyQ29uc2VudEZvckFkdmVydGlzaW5nVmVuZG9yTGlzdCIsInB1cnBvc2VzQW5kVmVuZG9ycyIsImdldENvbnNlbnRlZFB1cnBvc2VzYW5kVmVuZG9yc1N0cmluZ3MiLCJzZW5kVXNlckN1c3RvbUNvbnNlbnRUb05vbkFkdmVydGlzaW5nVmVuZG9yTGlzdCIsInZlbmRvcnMiLCJwdXJwb3NlcyIsImxlZ2l0aW1hdGVJbnRlcmVzdFB1cnBvc2VJZHMiLCJzZW5kVXNlckNvbnNlbnRTdHJpbmdUb05vbkFkdmVydGlzaW5nVmVuZG9yTGlzdCIsIl9yZWYyIiwiY29uc2VudFVVSUQiLCJuYW1lIiwidXJsIiwiZ2V0VXNlckNvbnNlbnRPbkFkdmVydGlzaW5nTGlzdFJlc3BvbnNlIiwiZmV0Y2giLCJtZXRob2QiLCJoZWFkZXJzIiwiQWNjZXB0IiwianNvbiIsImRhdGEiLCJfZGF0YSQiLCJfZGF0YSQyIiwiX2RhdGEkMyIsInZlbmRvcklkcyIsIm1hcCIsIl9pZCIsInB1cnBvc2VJZHMiLCJjYXRlZ29yaWVzIiwiY2F0ZWdvcnkiLCJfcHVycG9zZUlkVG9Ob25BZHZlcnQiLCJnZXQiLCJpYWJQdXJwb3NlUmVmIiwiaWFiSWQiLCJmaWx0ZXIiLCJsZWdJbnRDYXRlZ29yaWVzIiwiX3B1cnBvc2VJZFRvTm9uQWR2ZXJ0MiIsIl9yZWYzIiwibWFrZVBPU1RSZXF1ZXN0IiwiX3giLCJfeDIiLCJfeDMiLCJfcmVmNCIsIl91c2VyQ29uc2VudCRnZHByIiwic3BVc2VyQ29uc2VudFN0cmluZyIsImxvY2FsU3RvcmFnZSIsImdldEl0ZW0iLCJKU09OIiwicGFyc2UiLCJldWNvbnNlbnQiLCJfcmVmNSIsImJvZHkiLCJzdHJpbmdpZnkiLCJfeDQiLCJfeDUiLCJjb25zZW50U3RhdGUiLCJfY29uc2VudFN0YXRlJHRjZnYiLCJnZXRDb25zZW50U3RhdGUkMyIsImdldENvbnNlbnRTdGF0ZSQxIiwiZ2V0Q29uc2VudFN0YXRlJDIiLCJjYWxsQmFja1F1ZXVlIiwiZmluYWxDYWxsYmFja1F1ZXVlIiwiYXdhaXRpbmdVc2VySW50ZXJhY3Rpb25JblRDRnYyIiwic3RhdGUiLCJfc3RhdGUkdGNmdiIsImV2ZW50U3RhdHVzIiwiYXdhaXRpbmdVc2VySW50ZXJhY3Rpb25JblVTTkFUIiwiX3N0YXRlJHVzbmF0Iiwic2lnbmFsU3RhdHVzIiwiaW52b2tlQ2FsbGJhY2siLCJjYWxsYmFjayIsInN0YXRlU3RyaW5nIiwibGFzdFN0YXRlIiwiZm4iLCJlbmhhbmNlQ29uc2VudFN0YXRlIiwiZ3BjU2lnbmFsIiwiY29uc2VudHMiLCJfb2JqZWN0U3ByZWFkIiwiY2FuVGFyZ2V0IiwiT2JqZWN0Iiwia2V5cyIsInZhbHVlcyIsImV2ZXJ5IiwiQm9vbGVhbiIsImludm9rZUNhbGxiYWNrcyIsImNhbGxiYWNrc1RvSW52b2tlIiwiZm9yRWFjaCIsImNhbGxCYWNrIiwiZmluYWwiLCJ1bmRlZmluZWQiLCJuZXdDYWxsYmFjayIsInB1c2giLCJjYXRjaCIsInNlcnZlclNpZGVXYXJuIiwic2VydmVyU2lkZVdhcm5BbmRSZXR1cm4iLCJhcmciLCJsb2FkU3R1YnNGb3IiLCJyZXNvbHZlV2lsbFNob3dQcml2YWN5TWVzc2FnZSIsImdldFByb3BlcnR5SHJlZiIsImdldFByb3BlcnR5SWQiLCJoYXNDb25zZW50ZWRUb05vbkFkdmVydGlzZWRMaXN0IiwiX3VzZXJDb25zZW50JGdkcHIkY29uIiwiY29uc2VudFN0YXR1cyIsImhhc0NvbnNlbnREYXRhIiwic2hvdWxkTWVyZ2VWZW5kb3JMaXN0IiwiX3dpbmRvdyRndWFyZGlhbjIiLCJmcmFtZXdvcmtNZXNzYWdlVHlwZSIsImlzSW5Qcm9wZXJ0eUlkQUJUZXN0IiwiY29uZmlnIiwidGVzdHMiLCJ1c2VTb3VyY2Vwb2ludFByb3BlcnR5SWRWYXJpYW50IiwicGFnZSIsIl9zcF9xdWV1ZSIsImJhc2VFbmRwb2ludCIsImFjY291bnRJZCIsInByb3BlcnR5SWQiLCJwcm9wZXJ0eUhyZWYiLCJqb2luSHJlZiIsImlzU1BBIiwidGFyZ2V0aW5nUGFyYW1zIiwiZXhjbHVkZVBhZ2UiLCJjbXBJbml0VGltZVV0YyIsIkRhdGUiLCJnZXRUaW1lIiwiZXZlbnRzIiwib25Db25zZW50UmVhZHkiLCJtZXNzYWdlX3R5cGUiLCJzcCIsImd1IiwiZ3VfY291bnRyeSIsInNldFRpbWVvdXQiLCJvbk1lc3NhZ2VSZWFkeSIsIm9uTWVzc2FnZVJlY2VpdmVEYXRhIiwidG9TdHJpbmciLCJvbk1lc3NhZ2VDaG9pY2VTZWxlY3QiLCJjaG9pY2VfaWQiLCJjaG9pY2VUeXBlSUQiLCJvblByaXZhY3lNYW5hZ2VyQWN0aW9uIiwicG1EYXRhIiwib25NZXNzYWdlQ2hvaWNlRXJyb3IiLCJlcnIiLCJvblBNQ2FuY2VsIiwib25TUFBNT2JqZWN0UmVhZHkiLCJvbkVycm9yIiwiZXJyb3JDb2RlIiwiZXJyb3JPYmplY3QiLCJ1c2VyUmVzZXQiLCJpc0NvclAiLCJzcExpYiIsImNyZWF0ZUVsZW1lbnQiLCJhZGRFdmVudExpc3RlbmVyIiwiX3dpbmRvdyRfc3BfJGV4ZWN1dGVNIiwiZXhlY3V0ZU1lc3NhZ2luZyIsImVycm9yIiwiX3dpbmRvdyRfc3BfMiRleGVjdXRlIiwic3JjIiwiYXBwZW5kQ2hpbGQiLCJzdHViX2dwcF91c25hdCIsInN0dWJfdGNmdjIiLCJzdHViX3VzcGFwaV9jY3BhIiwiX19ncHBfYWRkRnJhbWUiLCJlIiwiZnJhbWVzIiwidCIsInN0eWxlIiwiY3NzVGV4dCIsIl9fZ3BwX3N0dWIiLCJfX2dwcCIsInF1ZXVlIiwicCIsInMiLCJncHBWZXJzaW9uIiwiY21wU3RhdHVzIiwiY21wRGlzcGxheVN0YXR1cyIsInN1cHBvcnRlZEFQSXMiLCJjbXBJZCIsInNlY3Rpb25MaXN0IiwiYXBwbGljYWJsZVNlY3Rpb25zIiwiZ3BwU3RyaW5nIiwicGFyc2VkU2VjdGlvbnMiLCJsYXN0SWQiLCJuIiwicGFyYW1ldGVyIiwiZXZlbnROYW1lIiwibGlzdGVuZXJJZCIsInBpbmdEYXRhIiwiYSIsImkiLCJzcGxpY2UiLCJzbGljZSIsIl9fZ3BwX21zZ2hhbmRsZXIiLCJlMiIsIl9fZ3BwQ2FsbCIsInAyIiwiX19ncHBSZXR1cm4iLCJyZXR1cm5WYWx1ZSIsImNhbGxJZCIsInNvdXJjZSIsInBvc3RNZXNzYWdlIiwiciIsImV4cG9ydHMiLCJvIiwibCIsIm0iLCJjIiwiZCIsInQyIiwiZGVmaW5lUHJvcGVydHkiLCJlbnVtZXJhYmxlIiwiU3ltYm9sIiwidG9TdHJpbmdUYWciLCJfX2VzTW9kdWxlIiwiY3JlYXRlIiwiZTMiLCJiaW5kIiwiZGVmYXVsdCIsInByb3RvdHlwZSIsImhhc093blByb3BlcnR5IiwidDMiLCJfX3RjZmFwaSIsIm4yIiwiX190Y2ZhcGlMb2NhdG9yIiwibjMiLCJyMiIsIkFycmF5IiwicGFyc2VJbnQiLCJnZHByQXBwbGllcyIsImNtcExvYWRlZCIsImFwaVZlcnNpb24iLCJ0NCIsIl9fdGNmYXBpQ2FsbCIsInIzIiwiX190Y2ZhcGlSZXR1cm4iLCJmIiwiRnVuY3Rpb24iLCJ1IiwiY29uZmlndXJhYmxlIiwibWF0Y2giLCJUeXBlRXJyb3IiLCJNYXRoIiwiZ2xvYmFsVGhpcyIsInNlbGYiLCJTdHJpbmciLCJ2YWx1ZU9mIiwiZ2RwckFwcGxpZXNHbG9iYWxseSIsIl9fY21wQ2FsbCIsImEyIiwiYzIiLCJfX2NtcFJldHVybiIsIm1zZ0hhbmRsZXIiLCJnZXRUQ0RhdGEiLCJnZXRDdXN0b21WZW5kb3JDb25zZW50cyIsImRlZmF1bHRDb25zZW50cyIsInRjRGF0YSIsImN1c3RvbVZlbmRvcnMiLCJhbGwiLCJfZ2V0Q3VycmVudEZyYW1ld29yayIsInB1cnBvc2UiLCJ0Y1N0cmluZyIsImFkZHRsQ29uc2VudCIsImdyYW50cyIsInNvcnQiLCJyZWR1Y2UiLCJhY2MiLCJjdXIiLCJfZ3JhbnRzJGN1ciIsInZlbmRvckdyYW50IiwiZ2V0VXNlckNvbnNlbnRzIiwidXNOYXREYXRhIiwiYXBwbGllcyIsImdldFVzbmF0RGF0YSIsIl91c25hdERhdGEkY2F0ZWdvcmllcyIsInVzbmF0RGF0YSIsInN5c3RlbUlkIiwiY29uc2VudGVkIiwicmVtb3ZlQ29va2llIiwic3RvcmFnZSIsInZlbmRvclN0b3JhZ2VJZHMiLCJkZXByZWNhdGVkVmVuZG9yU3RvcmFnZUlkcyIsInJlbW92ZURhdGEiLCJjb29raWVzIiwic2Vzc2lvblN0b3JhZ2UiLCJsb2NhbCIsInJlbW92ZSIsInNlc3Npb24iLCJyZW1vdmVVbmNvbnNlbnRlZERhdGEiLCJjb25zZW50Rm9yVmVuZG9yIiwidmVuZG9yRGF0YSIsImVudHJpZXMiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwidGltZW91dCIsImE5IiwiaW5pemlvIiwiY3JpdGVvIiwiY29tc2NvcmUiLCJpcHNvcyIsInBlcm11dGl2ZSIsImdvb2dsZXRhZyIsIlRDRlYyVmVuZG9ySURzIiwiYWNhc3QiLCJhZFlvdUxpa2UiLCJicmF6ZSIsImdyb3VwTSIsImlhcyIsImlkNSIsImluZGV4RXhjaGFuZ2UiLCJtYWduaXRlIiwibmllbHNlbiIsIm9wZW5YIiwib3pvbmUiLCJwdWJtYXRpYyIsInFtIiwicmVtYXJrZXRpbmciLCJzZW50cnkiLCJ0ZWFkcyIsInRoZVRyYWRlRGVzayIsInR3aXR0ZXIiLCJ4YW5kciIsIkF1c1ZlbmRvcklEcyIsInJlZHBsYW5ldCIsIlVzVmVuZG9ySURzIiwiYWRtaXJhbCIsImdldENvb2tpZVZhbHVlcyIsIm1lbW9pemVkQ29va2llcyIsInNob3VsZE1lbW9pemUiLCJtZW1vaXplZENvb2tpZSIsInNldCIsIm5hbWVFcSIsInNwbGl0IiwiY29va2llVHJpbW1lZCIsInRyaW0iLCJzdGFydHNXaXRoIiwic3Vic3RyaW5nIiwiZ2V0U2hvcnREb21haW4iLCJpc0Nyb3NzU3ViZG9tYWluIiwiZG9tYWluIiwiaXNQcmV2aWV3Iiwiam9pbiIsInJlcGxhY2UiLCJjdXJyZW50RG9tYWluT25seSIsImV4cGlyZXMiLCJwYXRoIiwiaXNPYmplY3QiLCJnZXRQcm90b3R5cGVPZiIsIl8iLCJTVE9SQUdFX0tFWSIsInN1YnNjcmlwdGlvblN0eWxlcyIsImlzU3Vic2NyaXB0aW9uIiwiY29tbW9uU3R5bGUiLCJTVUJTQ1JJUFRJT05TX0NBQ0hFIiwiZ2V0U3Vic2NyaXB0aW9ucyIsInN0b3JlZFN1YnNjcmlwdGlvbnMiLCJTZXQiLCJzdWJzY3JpYmVUbyIsInN1YnNjcmlwdGlvbiIsInN1YnNjcmlwdGlvbnMiLCJhZGQiLCJmcm9tIiwidW5zdWJzY3JpYmVGcm9tIiwiZGVsZXRlIiwiaXNTdWJzY3JpYmVkVG8iLCJoYXMiLCJsb2dTdHlsZXMiLCJtZXNzYWdlU3R5bGUiLCJzdWJzY3JpcHRpb25TdHlsZSIsImJhY2tncm91bmQiLCJmb250Iiwic3R5bGVzIiwiX2xlbiIsImFyZ3MiLCJfa2V5IiwiX2EkbG9nZ2VyIiwibG9nZ2VyIiwidGVhbXMiLCJjb21tb24iLCJjb21tZXJjaWFsIiwiZG90Y29tIiwiZGVzaWduIiwidHgiLCJzdXBwb3J0ZXJSZXZlbnVlIiwiaWRlbnRpdHkiLCJvcGVuSm91cm5hbGlzbSIsInBlcmYiLCJfX2RlZlByb3AiLCJfX3R5cGVFcnJvciIsIm1zZyIsIl9fZGVmTm9ybWFsUHJvcCIsIm9iaiIsImtleSIsIndyaXRhYmxlIiwiX19wdWJsaWNGaWVsZCIsIl9fYWNjZXNzQ2hlY2siLCJtZW1iZXIiLCJfX3ByaXZhdGVHZXQiLCJnZXR0ZXIiLCJfX3ByaXZhdGVBZGQiLCJXZWFrU2V0IiwiX19wcml2YXRlU2V0Iiwic2V0dGVyIiwiX3N0b3JhZ2UiLCJfbG9jYWwiLCJfc2Vzc2lvbiIsIlN0b3JhZ2VGYWN0b3J5IiwiY29uc3RydWN0b3IiLCJzdG9yYWdlSGFuZGxlciIsIl9wcml2YXRlR2V0JGdldEl0ZW0iLCJfcHJpdmF0ZUdldCIsIl9wcml2YXRlR2V0MiIsInNldEl0ZW0iLCJfcHJpdmF0ZUdldDMiLCJyZW1vdmVJdGVtIiwiX3ByaXZhdGVHZXQ0IiwiY2xlYXIiLCJfcHJpdmF0ZUdldCRnZXRJdGVtMiIsIl9wcml2YXRlR2V0NSIsIl9wcml2YXRlR2V0NiIsImluZGV4IiwiX3ByaXZhdGVHZXQka2V5IiwiX3ByaXZhdGVHZXQ3IiwiX3ByaXZhdGVHZXQkbGVuZ3RoIiwiX3ByaXZhdGVHZXQ4Iiwic3RvcmFnZTIiLCJ1aWQiLCJhdmFpbGFibGUiLCJXZWFrTWFwIiwiX3ByaXZhdGVHZXQ5IiwiX3ByaXZhdGVHZXQwIiwiYnJlYWtwb2ludHMiLCJkZXNrdG9wIiwibGVmdENvbCIsIm1vYmlsZSIsIm1vYmlsZUxhbmRzY2FwZSIsIm1vYmlsZU1lZGl1bSIsInBoYWJsZXQiLCJ0YWJsZXQiLCJ3aWRlIiwibW9kdWxlIiwiYW5zaUhUTUwiLCJfcmVnQU5TSSIsIl9kZWZDb2xvcnMiLCJyZXNldCIsImJsYWNrIiwicmVkIiwiZ3JlZW4iLCJ5ZWxsb3ciLCJibHVlIiwibWFnZW50YSIsImN5YW4iLCJsaWdodGdyZXkiLCJkYXJrZ3JleSIsIl9zdHlsZXMiLCJfb3BlblRhZ3MiLCJfY2xvc2VUYWdzIiwidGV4dCIsImFuc2lDb2RlcyIsInJldCIsInNlcSIsIm90IiwiaW5kZXhPZiIsInBvcCIsImN0Iiwic2V0Q29sb3JzIiwiY29sb3JzIiwiX2ZpbmFsQ29sb3JzIiwiaGV4IiwiaXNBcnJheSIsImgiLCJkZWZIZXhDb2xvciIsIl9zZXRUYWdzIiwidGFncyIsIm9wZW4iLCJjbG9zZSIsImNvZGUiLCJjb2xvciIsIm9yaUNvbG9yIiwiUiIsIlJlZmxlY3QiLCJSZWZsZWN0QXBwbHkiLCJ0YXJnZXQiLCJyZWNlaXZlciIsIlJlZmxlY3RPd25LZXlzIiwib3duS2V5cyIsImdldE93blByb3BlcnR5U3ltYm9scyIsImdldE93blByb3BlcnR5TmFtZXMiLCJQcm9jZXNzRW1pdFdhcm5pbmciLCJ3YXJuaW5nIiwiTnVtYmVySXNOYU4iLCJOdW1iZXIiLCJpc05hTiIsIkV2ZW50RW1pdHRlciIsIm9uY2UiLCJfZXZlbnRzIiwiX2V2ZW50c0NvdW50IiwiX21heExpc3RlbmVycyIsImRlZmF1bHRNYXhMaXN0ZW5lcnMiLCJjaGVja0xpc3RlbmVyIiwibGlzdGVuZXIiLCJSYW5nZUVycm9yIiwic2V0TWF4TGlzdGVuZXJzIiwiX2dldE1heExpc3RlbmVycyIsInRoYXQiLCJnZXRNYXhMaXN0ZW5lcnMiLCJlbWl0IiwidHlwZSIsImRvRXJyb3IiLCJlciIsIm1lc3NhZ2UiLCJjb250ZXh0IiwiaGFuZGxlciIsImxlbiIsImxpc3RlbmVycyIsImFycmF5Q2xvbmUiLCJfYWRkTGlzdGVuZXIiLCJwcmVwZW5kIiwiZXhpc3RpbmciLCJuZXdMaXN0ZW5lciIsInVuc2hpZnQiLCJ3YXJuZWQiLCJ3IiwiZW1pdHRlciIsImNvdW50IiwiYWRkTGlzdGVuZXIiLCJvbiIsInByZXBlbmRMaXN0ZW5lciIsIm9uY2VXcmFwcGVyIiwiZmlyZWQiLCJyZW1vdmVMaXN0ZW5lciIsIndyYXBGbiIsIl9vbmNlV3JhcCIsIndyYXBwZWQiLCJwcmVwZW5kT25jZUxpc3RlbmVyIiwibGlzdCIsInBvc2l0aW9uIiwib3JpZ2luYWxMaXN0ZW5lciIsInNoaWZ0Iiwic3BsaWNlT25lIiwib2ZmIiwicmVtb3ZlQWxsTGlzdGVuZXJzIiwiX2xpc3RlbmVycyIsInVud3JhcCIsImV2bGlzdGVuZXIiLCJ1bndyYXBMaXN0ZW5lcnMiLCJyYXdMaXN0ZW5lcnMiLCJsaXN0ZW5lckNvdW50IiwiZXZlbnROYW1lcyIsImFyciIsImNvcHkiLCJlcnJvckxpc3RlbmVyIiwicmVzb2x2ZXIiLCJldmVudFRhcmdldEFnbm9zdGljQWRkTGlzdGVuZXIiLCJhZGRFcnJvckhhbmRsZXJJZkV2ZW50RW1pdHRlciIsImZsYWdzIiwid3JhcExpc3RlbmVyIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsIl90eXBlb2YiLCJpdGVyYXRvciIsIl9jbGFzc0NhbGxDaGVjayIsIl9kZWZpbmVQcm9wZXJ0aWVzIiwiX3RvUHJvcGVydHlLZXkiLCJfY3JlYXRlQ2xhc3MiLCJfdG9QcmltaXRpdmUiLCJ0b1ByaW1pdGl2ZSIsIldlYlNvY2tldENsaWVudCIsImNsaWVudCIsIldlYlNvY2tldCIsIm9uZXJyb3IiLCJvbk9wZW4iLCJvbm9wZW4iLCJvbkNsb3NlIiwib25jbG9zZSIsIm9uTWVzc2FnZSIsIm9ubWVzc2FnZSIsIl9fd2VicGFja19tb2R1bGVzX18iLCIuL2NsaWVudC1zcmMvbW9kdWxlcy9sb2dnZXIvdGFwYWJsZS5qcyIsIl9fdW51c2VkX3dlYnBhY2tfbW9kdWxlIiwiX193ZWJwYWNrX2V4cG9ydHNfXyIsIl9fd2VicGFja19yZXF1aXJlX18iLCJTeW5jQmFpbEhvb2siLCIuL25vZGVfbW9kdWxlcy93ZWJwYWNrL2xpYi9sb2dnaW5nL0xvZ2dlci5qcyIsIl90b0NvbnN1bWFibGVBcnJheSIsIl9hcnJheVdpdGhvdXRIb2xlcyIsIl9pdGVyYWJsZVRvQXJyYXkiLCJfdW5zdXBwb3J0ZWRJdGVyYWJsZVRvQXJyYXkiLCJfbm9uSXRlcmFibGVTcHJlYWQiLCJfYXJyYXlMaWtlVG9BcnJheSIsIkxvZ1R5cGUiLCJmcmVlemUiLCJpbmZvIiwiZGVidWciLCJ0cmFjZSIsImdyb3VwIiwiZ3JvdXBDb2xsYXBzZWQiLCJncm91cEVuZCIsInByb2ZpbGUiLCJwcm9maWxlRW5kIiwidGltZSIsInN0YXR1cyIsIkxPR19TWU1CT0wiLCJUSU1FUlNfU1lNQk9MIiwiVElNRVJTX0FHR1JFR0FURVNfU1lNQk9MIiwiV2VicGFja0xvZ2dlciIsImdldENoaWxkTG9nZ2VyIiwiX2xlbjIiLCJfa2V5MiIsIl9sZW4zIiwiX2tleTMiLCJfbGVuNCIsIl9rZXk0IiwiX2xlbjUiLCJfa2V5NSIsImFzc2VydCIsImFzc2VydGlvbiIsIl9sZW42IiwiX2tleTYiLCJfbGVuNyIsIl9rZXk3IiwiX2xlbjgiLCJfa2V5OCIsIl9sZW45IiwiX2tleTkiLCJocnRpbWUiLCJ0aW1lTG9nIiwicHJldiIsInRpbWVFbmQiLCJ0aW1lQWdncmVnYXRlIiwiY3VycmVudCIsInRpbWVBZ2dyZWdhdGVFbmQiLCJMb2dnZXIiLCIuL25vZGVfbW9kdWxlcy93ZWJwYWNrL2xpYi9sb2dnaW5nL2NyZWF0ZUNvbnNvbGVMb2dnZXIuanMiLCJfX3VudXNlZF93ZWJwYWNrX2V4cG9ydHMiLCJfc2xpY2VkVG9BcnJheSIsIl9hcnJheVdpdGhIb2xlcyIsIl9pdGVyYWJsZVRvQXJyYXlMaW1pdCIsIl9ub25JdGVyYWJsZVJlc3QiLCJuZXh0IiwiZG9uZSIsInJldHVybiIsIl9yZXF1aXJlIiwiZmlsdGVyVG9GdW5jdGlvbiIsIml0ZW0iLCJyZWdFeHAiLCJpZGVudCIsIkxvZ0xldmVsIiwibm9uZSIsImZhbHNlIiwidHJ1ZSIsInZlcmJvc2UiLCJfcmVmJGxldmVsIiwibGV2ZWwiLCJfcmVmJGRlYnVnIiwiZGVidWdGaWx0ZXJzIiwibG9nbGV2ZWwiLCJsYWJlbGVkQXJncyIsIl9hcmdzIiwic3RhcnQiLCJlbmQiLCJtcyIsImxvZ1RpbWUiLCIuL25vZGVfbW9kdWxlcy93ZWJwYWNrL2xpYi9sb2dnaW5nL3J1bnRpbWUuanMiLCJfZXh0ZW5kcyIsImFzc2lnbiIsIl9yZXF1aXJlMiIsImNyZWF0ZUNvbnNvbGVMb2dnZXIiLCJjdXJyZW50RGVmYXVsdExvZ2dlck9wdGlvbnMiLCJjdXJyZW50RGVmYXVsdExvZ2dlciIsImdldExvZ2dlciIsImhvb2tzIiwiY2hpbGROYW1lIiwiY29uZmlndXJlRGVmYXVsdExvZ2dlciIsIm9wdGlvbnMiLCJfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18iLCJtb2R1bGVJZCIsImNhY2hlZE1vZHVsZSIsImRlZmluaXRpb24iLCJwcm9wIiwid2VicGFja19saWJfbG9nZ2luZ19ydW50aW1lX2pzX19XRUJQQUNLX0lNUE9SVEVEX01PRFVMRV8wX18iLCJfX3dlYnBhY2tfZXhwb3J0X3RhcmdldF9fIiwiX193ZWJwYWNrX2lfXyIsImdldE93blByb3BlcnR5RGVzY3JpcHRvciIsIl9kZWZpbmVQcm9wZXJ0eSIsImdldE93blByb3BlcnR5RGVzY3JpcHRvcnMiLCJkZWZpbmVQcm9wZXJ0aWVzIiwiZ2V0Q29kZVBvaW50IiwiY29kZVBvaW50QXQiLCJpbnB1dCIsImNoYXJDb2RlQXQiLCJyZXBsYWNlVXNpbmdSZWdFeHAiLCJtYWNyb1RleHQiLCJtYWNyb1JlZ0V4cCIsIm1hY3JvUmVwbGFjZXIiLCJsYXN0SW5kZXgiLCJyZXBsYWNlTWF0Y2giLCJleGVjIiwicmVwbGFjZVJlc3VsdCIsInJlcGxhY2VMYXN0SW5kZXgiLCJyZXBsYWNlSW5wdXQiLCJyZWZlcmVuY2VzIiwiZW5jb2RlIiwiY3JlYXRlTWFjaGluZSIsInN0YXRlcyIsImluaXRpYWwiLCJhY3Rpb25zIiwiY3VycmVudFN0YXRlIiwiY3VycmVudENvbnRleHQiLCJzZW5kIiwiZXZlbnQiLCJjdXJyZW50U3RhdGVPbiIsInRyYW5zaXRpb25Db25maWciLCJhY3ROYW1lIiwiYWN0aW9uSW1wbCIsIm5leHRDb250ZXh0VmFsdWUiLCJjcmVhdGVPdmVybGF5TWFjaGluZSIsImhpZGVPdmVybGF5Iiwic2hvd092ZXJsYXkiLCJtZXNzYWdlcyIsIm1lc3NhZ2VTb3VyY2UiLCJoaWRkZW4iLCJCVUlMRF9FUlJPUiIsIlJVTlRJTUVfRVJST1IiLCJkaXNwbGF5QnVpbGRFcnJvciIsIkRJU01JU1MiLCJkaXNwbGF5UnVudGltZUVycm9yIiwiZGlzbWlzc01lc3NhZ2VzIiwiYXBwZW5kTWVzc2FnZXMiLCJzZXRNZXNzYWdlcyIsInBhcnNlRXJyb3JUb1N0YWNrcyIsInN0YWNrIiwibGlzdGVuVG9SdW50aW1lRXJyb3IiLCJjbGVhbnVwIiwibGlzdGVuVG9VbmhhbmRsZWRSZWplY3Rpb24iLCJtc2dTdHlsZXMiLCJiYWNrZ3JvdW5kQ29sb3IiLCJpZnJhbWVTdHlsZSIsInRvcCIsImxlZnQiLCJyaWdodCIsImJvdHRvbSIsIndpZHRoIiwiaGVpZ2h0IiwiYm9yZGVyIiwiY29udGFpbmVyU3R5bGUiLCJib3hTaXppbmciLCJmb250U2l6ZSIsInBhZGRpbmciLCJsaW5lSGVpZ2h0Iiwid2hpdGVTcGFjZSIsIm92ZXJmbG93IiwiaGVhZGVyU3R5bGUiLCJmb250RmFtaWx5IiwibWFyZ2luIiwiZmxleCIsIm1heEhlaWdodCIsImRpc21pc3NCdXR0b25TdHlsZSIsImN1cnNvciIsIm1zZ1R5cGVTdHlsZSIsIm1hcmdpbkJvdHRvbSIsIm1zZ1RleHRTdHlsZSIsImZvcm1hdFByb2JsZW0iLCJoZWFkZXIiLCJmaWxlIiwibW9kdWxlTmFtZSIsImxvYyIsImNyZWF0ZU92ZXJsYXkiLCJpZnJhbWVDb250YWluZXJFbGVtZW50IiwiY29udGFpbmVyRWxlbWVudCIsImhlYWRlckVsZW1lbnQiLCJvbkxvYWRRdWV1ZSIsIm92ZXJsYXlUcnVzdGVkVHlwZXNQb2xpY3kiLCJhcHBseVN0eWxlIiwiZWxlbWVudCIsImNyZWF0ZUNvbnRhaW5lciIsInRydXN0ZWRUeXBlc1BvbGljeU5hbWUiLCJ0cnVzdGVkVHlwZXMiLCJjcmVhdGVQb2xpY3kiLCJjcmVhdGVIVE1MIiwib25sb2FkIiwiY29udGVudEVsZW1lbnQiLCJjb250ZW50RG9jdW1lbnQiLCJpbm5lclRleHQiLCJjbG9zZUJ1dHRvbkVsZW1lbnQiLCJhcmlhTGFiZWwiLCJvdmVybGF5U2VydmljZSIsIm9uTG9hZCIsImVuc3VyZU92ZXJsYXlFeGlzdHMiLCJpbm5lckhUTUwiLCJoaWRlIiwicmVtb3ZlQ2hpbGQiLCJzaG93IiwiZW50cnlFbGVtZW50IiwibXNnU3R5bGUiLCJ0eXBlRWxlbWVudCIsIl9mb3JtYXRQcm9ibGVtIiwibW9kdWxlSWRlbnRpZmllciIsInNldEF0dHJpYnV0ZSIsIm1lc3NhZ2VUZXh0Tm9kZSIsIl9yZWYzJGxldmVsIiwiY2F0Y2hSdW50aW1lRXJyb3IiLCJoYW5kbGVFcnJvciIsImZhbGxiYWNrTWVzc2FnZSIsInNob3VsZERpc3BsYXkiLCJlcnJvckV2ZW50IiwicHJvbWlzZVJlamVjdGlvbkV2ZW50IiwicmVhc29uIiwiX2NhbGxTdXBlciIsIl9nZXRQcm90b3R5cGVPZiIsIl9wb3NzaWJsZUNvbnN0cnVjdG9yUmV0dXJuIiwiX2lzTmF0aXZlUmVmbGVjdENvbnN0cnVjdCIsImNvbnN0cnVjdCIsIl9hc3NlcnRUaGlzSW5pdGlhbGl6ZWQiLCJSZWZlcmVuY2VFcnJvciIsIl9pbmhlcml0cyIsIl9zZXRQcm90b3R5cGVPZiIsIl93cmFwTmF0aXZlU3VwZXIiLCJfaXNOYXRpdmVGdW5jdGlvbiIsIldyYXBwZXIiLCJfY29uc3RydWN0Iiwic2V0UHJvdG90eXBlT2YiLCJfX3Byb3RvX18iLCJfY2xhc3NQcml2YXRlTWV0aG9kSW5pdFNwZWMiLCJfY2hlY2tQcml2YXRlUmVkZWNsYXJhdGlvbiIsIl9hc3NlcnRDbGFzc0JyYW5kIiwiaXNQcm9ncmVzc1N1cHBvcnRlZCIsIkhUTUxFbGVtZW50IiwiYXR0YWNoU2hhZG93IiwiZGVmaW5lUHJvZ3Jlc3NFbGVtZW50IiwiX1dlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzcyIsImN1c3RvbUVsZW1lbnRzIiwiX1dlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzc19icmFuZCIsIldlYnBhY2tEZXZTZXJ2ZXJQcm9ncmVzcyIsIl9IVE1MRWxlbWVudCIsIl90aGlzIiwibW9kZSIsIm1heERhc2hPZmZzZXQiLCJhbmltYXRpb25UaW1lciIsImNvbm5lY3RlZENhbGxiYWNrIiwiX3Jlc2V0IiwiYXR0cmlidXRlQ2hhbmdlZENhbGxiYWNrIiwib2xkVmFsdWUiLCJuZXdWYWx1ZSIsIl91cGRhdGUiLCJfdGhpcyRnZXRBdHRyaWJ1dGUiLCJfTnVtYmVyIiwiY2xlYXJUaW1lb3V0IiwidHlwZUF0dHIiLCJnZXRBdHRyaWJ1dGUiLCJ0b0xvd2VyQ2FzZSIsIl9jaXJjdWxhclRlbXBsYXRlIiwiX2xpbmVhclRlbXBsYXRlIiwic2hhZG93Um9vdCIsImluaXRpYWxQcm9ncmVzcyIsInBlcmNlbnQiLCJxdWVyeVNlbGVjdG9yIiwib2Zmc2V0Iiwic3Ryb2tlRGFzaG9mZnNldCIsInRleHRDb250ZW50IiwiX2hpZGUiLCJfc2hvdyIsImNsYXNzTGlzdCIsIl90aGlzMiIsImRlZmluZSIsIkNsaWVudCIsIl9fd2VicGFja19kZXZfc2VydmVyX2NsaWVudF9fIiwicmV0cmllcyIsIm1heFJldHJpZXMiLCJzb2NrZXQiLCJpbml0U29ja2V0IiwiaGFuZGxlcnMiLCJyZWNvbm5lY3QiLCJyZXRyeUluTXMiLCJwb3ciLCJyYW5kb20iLCJwYXJhbXMiLCJkZWZhdWx0TGV2ZWwiLCJzZXRMb2dMZXZlbCIsInNlbmRNc2ciLCJXb3JrZXJHbG9iYWxTY29wZSIsInJlcXVpcmUiLCJsb2dMZXZlbCIsImR1bW15Iiwic2hvdWxkTG9nIiwibG9nR3JvdXAiLCJsb2dGbiIsImZvcm1hdEVycm9yIiwiZ2V0Q3VycmVudEJyZWFrcG9pbnQiLCJhZHNEaXNhYmxlZExvZ2dlciIsInRydWVDb25kaXRpb25zIiwiZmFsc2VDb25kaXRpb25zIiwibm9BZHNMb2ciLCJjb25kaXRpb24iLCJBRF9GUkVFX1VTRVJfQ09PS0lFIiwiZ2V0QWRGcmVlQ29va2llIiwiYWRGcmVlRGF0YUlzUHJlc2VudCIsImNvb2tpZVZhbCIsImlzSW50ZXJuZXRFeHBsb3JlciIsIl9uYXZpZ2F0b3IkdXNlckFnZW50JCIsInVzZXJBZ2VudCIsIkRJR0lUQUxfU1VCU0NSSUJFUl9DT09LSUUiLCJpc0RpZ2l0YWxTdWJzY3JpYmVyIiwiaXNBZEZyZWVVc2VyIiwiaXNVc2VyUHJlZnNBZHNPZmYiLCJDb21tZXJjaWFsRmVhdHVyZXMiLCJub2Fkc1VybCIsImhhc2giLCJmb3JjZUFkRnJlZSIsImZvcmNlQWRzIiwic2VhcmNoIiwiZXh0ZXJuYWxBZHZlcnRpc2luZyIsInNlbnNpdGl2ZUNvbnRlbnQiLCJzaG91bGRIaWRlQWR2ZXJ0cyIsImlzTWludXRlQXJ0aWNsZSIsImlzQXJ0aWNsZSIsImNvbnRlbnRUeXBlIiwiaXNJbnRlcmFjdGl2ZSIsImlzTGl2ZUJsb2ciLCJpc0hvc3RlZCIsImlzSWRlbnRpdHlQYWdlIiwic3dpdGNoZXMiLCJpc1dpZGVQYWdlIiwibmV3UmVjaXBlRGVzaWduIiwic2hvd05ld1JlY2lwZURlc2lnbiIsImlzVW5zdXBwb3J0ZWRCcm93c2VyIiwicGFnZUlkIiwiaXNGb290YmFsbFBhZ2UiLCJpc1BhZ2VXaXRoUmlnaHRBZFNwYWNlIiwiZm9vdGJhbGxGaXh0dXJlc0FkdmVydHMiLCJpc1NlY3VyZUNvbnRhY3QiLCJhZEZyZWUiLCJ5b3V0dWJlQWR2ZXJ0aXNpbmciLCJzaG91bGRMb2FkR29vZ2xldGFnVHJ1ZUNvbmRpdGlvbnMiLCJzaG91bGRMb2FkR29vZ2xldGFnIiwic2hvdWxkTG9hZEdvb2dsZXRhZ0ZhbHNlQ29uZGl0aW9ucyIsImFydGljbGVCb2R5QWR2ZXJ0c1RydWVDb25kaXRpb25zIiwiYXJ0aWNsZUJvZHlBZHZlcnRzRmFsc2VDb25kaXRpb25zIiwiYXJ0aWNsZUJvZHlBZHZlcnRzIiwiY2Fycm90VHJhZmZpY0RyaXZlciIsImlzUGFpZENvbnRlbnQiLCJoaWdoTWVyY2giLCJpc0Zyb250IiwiaXNEb3Rjb21SZW5kZXJpbmciLCJ0aGlyZFBhcnR5VGFncyIsImNvbW1lbnRBZHZlcnRzIiwiZW5hYmxlRGlzY3Vzc2lvblN3aXRjaCIsImNvbW1lbnRhYmxlIiwibGl2ZWJsb2dBZHZlcnRzIiwiY29tbWVyY2lhbEZlYXR1cmVzIiwic291cmNlQnJlYWtwb2ludHMiLCJnZXRWaWV3cG9ydCIsImlzU291cmNlQnJlYWtwb2ludCIsInBvaW50IiwiaXNCcmVha3BvaW50IiwidHdlYWtwb2ludHMiLCJzb3VyY2VCcmVha3BvaW50TmFtZXMiLCJjdXJyZW50QnJlYWtwb2ludCIsImN1cnJlbnRUd2Vha3BvaW50IiwiZ2V0UG9pbnQiLCJpbmNsdWRlVHdlYWtwb2ludCIsImdldEJyZWFrcG9pbnQiLCJnZXRUd2Vha3BvaW50IiwiZ2V0Q3VycmVudFR3ZWFrcG9pbnQiLCJnZXRNZWRpYVF1ZXJ5IiwibWluIiwibWF4IiwibWluV2lkdGgiLCJtYXhXaWR0aCIsIm1pblF1ZXJ5IiwibWF4UXVlcnkiLCJ1cGRhdGVCcmVha3BvaW50IiwiYnJlYWtwb2ludCIsImluaXRNZWRpYVF1ZXJ5TGlzdGVuZXJzIiwicmV2ZXJzZSIsImJwIiwiYnBzIiwibmV4dEJwIiwibXFsIiwibWF0Y2hNZWRpYSIsIm1hdGNoZXMiLCJtYXRjaGVzQnJlYWtwb2ludHMiLCJoYXNDcm9zc2VkQnJlYWtwb2ludCIsIndhcyIsImlzIiwiaW5uZXJXaWR0aCIsImNsaWVudFdpZHRoIiwiaW5uZXJIZWlnaHQiLCJjbGllbnRIZWlnaHQiLCJ3ZWJwYWNrSG90TG9nIiwiaG90RW1pdHRlciIsInNlbmRNZXNzYWdlIiwiZGVjb2RlT3ZlcmxheU9wdGlvbnMiLCJvdmVybGF5T3B0aW9ucyIsInByb3BlcnR5Iiwib3ZlcmxheUZpbHRlckZ1bmN0aW9uU3RyaW5nIiwiZGVjb2RlVVJJQ29tcG9uZW50IiwiaXNVbmxvYWRpbmciLCJjdXJyZW50SGFzaCIsIl9fd2VicGFja19oYXNoX18iLCJnZXRDdXJyZW50U2NyaXB0U291cmNlIiwiY3VycmVudFNjcmlwdCIsInNjcmlwdEVsZW1lbnRzIiwic2NyaXB0cyIsInNjcmlwdEVsZW1lbnRzV2l0aFNyYyIsInBhcnNlVVJMIiwicmVzb3VyY2VRdWVyeSIsInNlYXJjaFBhcmFtcyIsInBhaXIiLCJzY3JpcHRTb3VyY2UiLCJzY3JpcHRTb3VyY2VVUkwiLCJVUkwiLCJocmVmIiwiZnJvbUN1cnJlbnRTY3JpcHQiLCJwYXJzZWRSZXNvdXJjZVF1ZXJ5IiwiX19yZXNvdXJjZVF1ZXJ5IiwiZW5hYmxlZEZlYXR1cmVzIiwiUHJvZ3Jlc3MiLCJPdmVybGF5IiwiaG90IiwibGl2ZVJlbG9hZCIsInByb2dyZXNzIiwib3ZlcmxheSIsImVycm9ycyIsIndhcm5pbmdzIiwicnVudGltZUVycm9ycyIsImxvZ2dpbmciLCJzZXRBbGxMb2dMZXZlbCIsImxvZ0VuYWJsZWRGZWF0dXJlcyIsImZlYXR1cmVzIiwibGlzdEVuYWJsZWRGZWF0dXJlcyIsImxvZ1N0cmluZyIsInJlbG9hZEFwcCIsImN1cnJlbnRTdGF0dXMiLCJwcmV2aW91c0hhc2giLCJpc0luaXRpYWwiLCJhcHBseVJlbG9hZCIsInJvb3RXaW5kb3ciLCJpbnRlcnZhbElkIiwiY2xlYXJJbnRlcnZhbCIsInJlbG9hZCIsImFsbG93VG9Ib3QiLCJhbGxvd1RvTGl2ZVJlbG9hZCIsInNldEludGVydmFsIiwicHJvdG9jb2wiLCJwYXJlbnQiLCJhbnNpUmVnZXgiLCJzdHJpcEFuc2kiLCJzdHJpbmciLCJvblNvY2tldE1lc3NhZ2UiLCJpbnZhbGlkIiwiX2hhc2giLCJwcm9ncmVzc1VwZGF0ZSIsInBsdWdpbk5hbWUiLCJzdGlsbE9rIiwib2siLCJzdGF0aWNDaGFuZ2VkIiwiX3dhcm5pbmdzIiwicHJpbnRhYmxlV2FybmluZ3MiLCJvdmVybGF5V2FybmluZ3NTZXR0aW5nIiwid2FybmluZ3NUb0Rpc3BsYXkiLCJwcmV2ZW50UmVsb2FkaW5nIiwiX2Vycm9ycyIsInByaW50YWJsZUVycm9ycyIsIl9mb3JtYXRQcm9ibGVtMiIsIm92ZXJsYXlFcnJvcnNTZXR0aW5ncyIsImVycm9yc1RvRGlzcGxheSIsIl9lcnJvciIsImZvcm1hdFVSTCIsIm9ialVSTCIsInN1YnN0ciIsImF1dGgiLCJlbmNvZGVVUklDb21wb25lbnQiLCJob3N0bmFtZSIsInBvcnQiLCJwYXRobmFtZSIsInNsYXNoZXMiLCJjcmVhdGVTb2NrZXRVUkwiLCJwYXJzZWRVUkwiLCJpc0luQWRkckFueSIsInNvY2tldFVSTFByb3RvY29sIiwic29ja2V0VVJMQXV0aCIsInVzZXJuYW1lIiwicGFzc3dvcmQiLCJzb2NrZXRVUkxIb3N0bmFtZSIsInNvY2tldFVSTFBvcnQiLCJzb2NrZXRVUkxQYXRobmFtZSIsInNvY2tldFVSTCIsInNob3VsZEJvb3RDb25zZW50bGVzcyIsIm9wdE91dEFkdmVydGlzaW5nIiwiYm9vdENvbnNlbnRsZXNzIiwiYm9vdENvbW1lcmNpYWxXaGVuUmVhZHkiXSwic291cmNlUm9vdCI6IiJ9