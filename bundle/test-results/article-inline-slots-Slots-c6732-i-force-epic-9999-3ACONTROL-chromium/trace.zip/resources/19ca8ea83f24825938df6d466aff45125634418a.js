"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["consented-advertising"],{

/***/ "../core/src/constants/ad-label-height.ts":
/*!************************************************!*\
  !*** ../core/src/constants/ad-label-height.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AD_LABEL_HEIGHT: () => (/* binding */ AD_LABEL_HEIGHT)
/* harmony export */ });
/**
 * Unit: pixels
 */
var AD_LABEL_HEIGHT = 24;

/***/ }),

/***/ "../core/src/constants/index.ts":
/*!**************************************!*\
  !*** ../core/src/constants/index.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AD_LABEL_HEIGHT: () => (/* reexport safe */ _ad_label_height__WEBPACK_IMPORTED_MODULE_0__.AD_LABEL_HEIGHT),
/* harmony export */   PREBID_TIMEOUT: () => (/* reexport safe */ _prebid_timeout__WEBPACK_IMPORTED_MODULE_1__.PREBID_TIMEOUT),
/* harmony export */   TOP_ABOVE_NAV_HEIGHT: () => (/* reexport safe */ _top_above_nav_height__WEBPACK_IMPORTED_MODULE_2__.TOP_ABOVE_NAV_HEIGHT)
/* harmony export */ });
/* harmony import */ var _ad_label_height__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ad-label-height */ "../core/src/constants/ad-label-height.ts");
/* harmony import */ var _prebid_timeout__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./prebid-timeout */ "../core/src/constants/prebid-timeout.ts");
/* harmony import */ var _top_above_nav_height__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./top-above-nav-height */ "../core/src/constants/top-above-nav-height.ts");




/***/ }),

/***/ "../core/src/constants/top-above-nav-height.ts":
/*!*****************************************************!*\
  !*** ../core/src/constants/top-above-nav-height.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TOP_ABOVE_NAV_HEIGHT: () => (/* binding */ TOP_ABOVE_NAV_HEIGHT)
/* harmony export */ });
/**
 * Unit: pixels.
 *
 * The majority of ads in the top banner are 250px high. We ran an experiment
 * in October 2021 to set the minimum height to 250, and let smaller ads be
 * centred in the space. We did not process with this option, as it had a
 * negative impact on viewability and revenue.
 *
 */
var TOP_ABOVE_NAV_HEIGHT = 90;
/*
Further Notes
=============

There was a very positive impact on CLS (Cumulative Layout Shift), which is good
for UX. However, the negative commercial impact meant we kept a height of 90px.

We ran a 1% server-side experiment to measure CLS when dedicating 250px for the
topAboveNav. The experiment showed this change has a significant positive impact
on CLS, and moves average CLS for the page from 0.09 to 0.07 (a 26% improvement
from this one change). The other way we sliced the data was to look at the
percent of pages that Google categorised as having 'good', 'needs improvement'
or 'poor' CLS scores. The viewability for the page dropped by about 1%, and for
that specific slot, by 4-6%.

When the experiment ran, the breakdown was as follows:

- 74% of our pages have a “good” CLS score
- 12% have a “poor” CLS score.
- 70% viewability for top-above-nav

This change resulted in:

- 84% “good”
- 4% “poor”
- 64% viewability for top-above-nav

Relevant Pull Requests
----------------------

- https://github.com/guardian/frontend/pull/24095
- https://github.com/guardian/dotcom-rendering/pull/3497
- https://github.com/guardian/dotcom-rendering/pull/3340

*/

/***/ }),

/***/ "../core/src/detect-ad-blocker.ts":
/*!****************************************!*\
  !*** ../core/src/detect-ad-blocker.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isAdBlockInUse: () => (/* binding */ isAdBlockInUse)
/* harmony export */ });
/**
Detect whether or not the user has an ad blocking extension enabled.
A few ad blockers are not detectable with this approach e.g. Safari / Adblock
Code inspired by just-detect-adblock's:
https://github.com/wmcmurray/just-detect-adblock/blob/master/src/helpers.js
*/
/*istanbul ignore file -- adElementBlocked can't be tested without patching each of the properties of
HTMLElement.prototype that it accesses, defeating the purpose of the test! */
var adBlockInUse = undefined;
function adElementBlocked(ad) {
  if (ad.offsetParent === null || ad.offsetHeight === 0 || ad.offsetLeft === 0 || ad.offsetTop === 0 || ad.offsetWidth === 0 || ad.clientHeight === 0 || ad.clientWidth === 0) {
    return true;
  }
  var adStyles = window.getComputedStyle(ad);
  if (adStyles.getPropertyValue('display') === 'none') return true;
  if (adStyles.getPropertyValue('visibility') === 'hidden') return true;
  var mozBindingProp = adStyles.getPropertyValue('-moz-binding');
  if (mozBindingProp.includes('about:')) return true;
  return false;
}
/**
 * Determines whether or not the user has an ad blocking extension enabled.
 * Note: positive results can be considered reliable while negative ones may not be.
 * @returns Promise
 */
function isAdBlockInUse() {
  if (adBlockInUse !== undefined) {
    return Promise.resolve(adBlockInUse);
  }
  if (typeof window.getComputedStyle !== 'function') {
    // Old browsers not supporting getComputedStyle most likely won't have adBlockers
    adBlockInUse = false;
    return Promise.resolve(adBlockInUse);
  }
  return new Promise(resolve => {
    window.requestAnimationFrame(() => {
      // create a fake ad element and append it to the document
      var ad = document.createElement('div');
      ad.setAttribute('class', 'ad_unit pub_300x250 pub_300x250m pub_728x90 text-ad textAd text_ad text_ads text-ads text-ad-links ad-text adSense adBlock adContent adBanner');
      ad.setAttribute('style', 'width: 1px !important; height: 1px !important; position: absolute !important; left: -10000px !important; top: -1000px !important;');
      document.body.appendChild(ad);
      // avoid a forced layout
      window.requestAnimationFrame(() => {
        // if the ad element has been hidden, an ad blocker is enabled.
        resolve(adElementBlocked(ad));
      });
    });
  });
}

/***/ }),

/***/ "../core/src/index.ts":
/*!****************************!*\
  !*** ../core/src/index.ts ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   EventTimer: () => (/* reexport safe */ _event_timer__WEBPACK_IMPORTED_MODULE_1__.EventTimer),
/* harmony export */   adSizes: () => (/* reexport safe */ _ad_sizes__WEBPACK_IMPORTED_MODULE_2__.adSizes),
/* harmony export */   buildImaAdTagUrl: () => (/* reexport safe */ _targeting_youtube_ima__WEBPACK_IMPORTED_MODULE_7__.buildImaAdTagUrl),
/* harmony export */   buildPageTargeting: () => (/* reexport safe */ _targeting_build_page_targeting__WEBPACK_IMPORTED_MODULE_5__.buildPageTargeting),
/* harmony export */   bypassCommercialMetricsSampling: () => (/* reexport safe */ _send_commercial_metrics__WEBPACK_IMPORTED_MODULE_4__.bypassCommercialMetricsSampling),
/* harmony export */   constants: () => (/* reexport module object */ _constants__WEBPACK_IMPORTED_MODULE_3__),
/* harmony export */   getPermutivePFPSegments: () => (/* reexport safe */ _permutive__WEBPACK_IMPORTED_MODULE_8__.getPermutivePFPSegments),
/* harmony export */   initCommercialMetrics: () => (/* reexport safe */ _send_commercial_metrics__WEBPACK_IMPORTED_MODULE_4__.initCommercialMetrics),
/* harmony export */   isAdBlockInUse: () => (/* reexport safe */ _detect_ad_blocker__WEBPACK_IMPORTED_MODULE_0__.isAdBlockInUse),
/* harmony export */   isEligibleForTeads: () => (/* reexport safe */ _targeting_teads_eligibility__WEBPACK_IMPORTED_MODULE_9__.isEligibleForTeads),
/* harmony export */   postMessage: () => (/* reexport safe */ _messenger_post_message__WEBPACK_IMPORTED_MODULE_6__.postMessage)
/* harmony export */ });
/* harmony import */ var _detect_ad_blocker__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./detect-ad-blocker */ "../core/src/detect-ad-blocker.ts");
/* harmony import */ var _event_timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _ad_sizes__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants */ "../core/src/constants/index.ts");
/* harmony import */ var _send_commercial_metrics__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./send-commercial-metrics */ "../core/src/send-commercial-metrics.ts");
/* harmony import */ var _targeting_build_page_targeting__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./targeting/build-page-targeting */ "../core/src/targeting/build-page-targeting.ts");
/* harmony import */ var _messenger_post_message__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./messenger/post-message */ "../core/src/messenger/post-message.ts");
/* harmony import */ var _targeting_youtube_ima__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./targeting/youtube-ima */ "../core/src/targeting/youtube-ima.ts");
/* harmony import */ var _permutive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./permutive */ "../core/src/permutive.ts");
/* harmony import */ var _targeting_teads_eligibility__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./targeting/teads-eligibility */ "../core/src/targeting/teads-eligibility.ts");












/***/ }),

/***/ "../core/src/targeting/youtube-ima.ts":
/*!********************************************!*\
  !*** ../core/src/targeting/youtube-ima.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildImaAdTagUrl: () => (/* binding */ buildImaAdTagUrl)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _build_page_targeting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./build-page-targeting */ "../core/src/targeting/build-page-targeting.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


/**
 * @param  {Record<string, MaybeArray<string|number|boolean>>
 * Follows https://support.google.com/admanager/answer/1080597
 */
var encodeCustomParams = params => {
  var encodedParams = Object.entries(params).map(_ref => {
    var [key, value] = _ref;
    var queryValue = Array.isArray(value) ? value.join(',') : String(value);
    return "".concat(key, "=").concat(encodeURIComponent(queryValue));
  }).join('&');
  return encodedParams;
};
var mergeCustomParamsWithTargeting = (customParams, consentState, clientSideParticipations, isSignedIn) => {
  var pageTargeting = {};
  try {
    pageTargeting = (0,_build_page_targeting__WEBPACK_IMPORTED_MODULE_1__.buildPageTargeting)({
      adFree: false,
      clientSideParticipations,
      consentState: consentState,
      isSignedIn: isSignedIn
    });
  } catch (e) {
    /**
     * Defensive error handling in case YoutubeAtom is used in an
     * environment where guardian.config, cookies, localstorage etc
     * are not available
     */
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'Error building YouTube IMA custom params', e);
    return customParams;
  }
  var mergedCustomParams = _objectSpread(_objectSpread({}, customParams), pageTargeting);
  return mergedCustomParams;
};
var buildImaAdTagUrl = _ref2 => {
  var {
    adUnit,
    clientSideParticipations,
    consentState,
    customParams,
    isSignedIn
  } = _ref2;
  var mergedCustomParams = mergeCustomParamsWithTargeting(customParams, consentState, clientSideParticipations, isSignedIn);
  var queryParams = {
    iu: adUnit,
    tfcd: '0',
    npa: '0',
    sz: '480x360|480x361|400x300',
    gdfp_req: '1',
    output: 'vast',
    unviewed_position_start: '1',
    env: 'vp',
    impl: 's',
    vad_type: 'linear',
    vpos: 'preroll',
    plcmt: '1',
    description_url: encodeURIComponent("".concat(window.guardian.config.page.host, "/").concat(window.guardian.config.page.pageId)),
    /**
     * cust_params string is encoded
     * cust_params values are also encoded so they will get double encoded
     * this ensures any values with separator chars (=&,) do not conflict with the main string
     */
    cust_params: encodeURIComponent(encodeCustomParams((0,_build_page_targeting__WEBPACK_IMPORTED_MODULE_1__.filterValues)(mergedCustomParams)))
  };
  var queryParamsArray = [];
  for (var [k, v] of Object.entries(queryParams)) {
    queryParamsArray.push("".concat(k, "=").concat(v));
  }
  return 'https://securepubads.g.doubleclick.net/gampad/ads?' + queryParamsArray.join('&');
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isBoolean/isBoolean.js":
/*!*************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isBoolean/isBoolean.js ***!
  \*************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isBoolean: () => (/* binding */ isBoolean)
/* harmony export */ });
var isBoolean = _ => {
  return typeof _ === "boolean";
};


/***/ }),

/***/ "./src/display/display-ads.ts":
/*!************************************!*\
  !*** ./src/display/display-ads.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   displayAds: () => (/* binding */ displayAds)
/* harmony export */ });
/* harmony import */ var _lib_creatives_page_skin__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/creatives/page-skin */ "./src/lib/creatives/page-skin.ts");
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _load_advert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./load-advert */ "./src/display/load-advert.ts");



var displayAds = () => {
  /*
   * We enable Single Request Architecture (SRA) by invoking:
   * googletag.pubads().enableSingleRequest()
   *
   * This instructs googletag.pubads to combine requests for all (fixed) ads into one request
   * From this one request Google Ad Manager will then run all auctions for every slot
   *
   * We trigger SRA by calling googletag.display() on the first slot
   * All other unfetched slots will be included in this first request
   *
   * https://support.google.com/admanager/answer/183282?hl=en
   * https://developers.google.com/publisher-tag/reference#googletag.display
   *
   */
  window.googletag.pubads().enableSingleRequest();
  window.googletag.pubads().collapseEmptyDivs();
  window.googletag.enableServices();
  var firstAdvertToLoad = _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_1__.dfpEnv.advertsToLoad.length ? _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_1__.dfpEnv.advertsToLoad[0] : undefined;
  if (firstAdvertToLoad) {
    (0,_load_advert__WEBPACK_IMPORTED_MODULE_2__.loadAdvert)(firstAdvertToLoad);
    _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_1__.dfpEnv.advertsToLoad = [];
  }
  (0,_lib_creatives_page_skin__WEBPACK_IMPORTED_MODULE_0__.pageSkin)();
};


/***/ }),

/***/ "./src/display/display-lazy-ads.ts":
/*!*****************************************!*\
  !*** ./src/display/display-lazy-ads.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   displayLazyAds: () => (/* binding */ displayLazyAds)
/* harmony export */ });
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _lazy_load__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./lazy-load */ "./src/display/lazy-load.ts");


var displayLazyAds = () => {
  window.googletag.pubads().collapseEmptyDivs();
  window.googletag.enableServices();
  _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_0__.dfpEnv.advertsToLoad.forEach(_lazy_load__WEBPACK_IMPORTED_MODULE_1__.enableLazyLoad);
};


/***/ }),

/***/ "./src/events/on-slot-load.ts":
/*!************************************!*\
  !*** ./src/events/on-slot-load.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   onSlotLoad: () => (/* binding */ onSlotLoad)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_messenger_post_message__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/messenger/post-message */ "../core/src/messenger/post-message.ts");
/* harmony import */ var _lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");


var host = "".concat(window.location.protocol, "//").concat(window.location.host);
/* This is for native ads. We send two pieces of information:
   - the ID of the iframe into which this ad is embedded. This is currently
     the only way to link an incoming message to the iframe it is "coming from"
   - the HOST of the parent frame. Again, inside the embedded document there is
     no way to know if we are running the site in production, dev or local mode.
     But, this information is necessary in the window.postMessage call, and so
     we resort to sending it as a token of welcome :)
*/
var onSlotLoad = event => {
  var advert = (0,_lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_1__.getAdvertById)(event.slot.getSlotElementId());
  if (!advert) {
    return;
  }
  var iframe = advert.node.getElementsByTagName('iframe').item(0);
  if (!(iframe !== null && iframe !== void 0 && iframe.contentWindow)) {
    console.log('No iFrame found for slot', advert.id, advert.slot);
    return;
  }
  (0,_guardian_commercial_core_messenger_post_message__WEBPACK_IMPORTED_MODULE_0__.postMessage)({
    id: iframe.id,
    host
  }, iframe.contentWindow);
};

/***/ }),

/***/ "./src/events/on-slot-render.ts":
/*!**************************************!*\
  !*** ./src/events/on-slot-render.ts ***!
  \**************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   onSlotRender: () => (/* binding */ onSlotRender)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _empty_advert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./empty-advert */ "./src/events/empty-advert.ts");
/* harmony import */ var _render_advert__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./render-advert */ "./src/events/render-advert.ts");






var reportEmptyResponse = (adSlotId, event) => {
  // This empty slot could be caused by a targeting problem,
  // let's report these and diagnose the problem in sentry.
  // Keep the sample rate low, otherwise we'll get rate-limited (report-error will also sample down)
  if (Math.random() < 1 / 10000) {
    var adUnitPath = event.slot.getAdUnitPath();
    var adTargetingKeys = event.slot.getTargetingKeys();
    var adTargetingKValues = adTargetingKeys.includes('k') ? event.slot.getTargeting('k') : [];
    var adKeywords = adTargetingKValues.join(', ');
    (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_3__.reportError)(new Error('dfp returned an empty ad response'), 'commercial', {
      adUnit: adUnitPath,
      adSlot: adSlotId,
      adKeywords
    });
  }
};
var sizeEventToAdSize = size => {
  if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isString)(size)) return 'fluid';
  return (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(Number(size[0]), Number(size[1]));
};
var onSlotRender = event => {
  var advert = (0,_lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__.getAdvertById)(event.slot.getSlotElementId());
  if (!advert) {
    return;
  }
  advert.isEmpty = event.isEmpty;
  if (event.isEmpty) {
    (0,_empty_advert__WEBPACK_IMPORTED_MODULE_4__.emptyAdvert)(advert);
    reportEmptyResponse(advert.id, event);
    advert.finishedRendering(false);
  } else {
    /**
     * if advert.hasPrebidSize is false we use size
     * from the GAM event when adjusting the slot size.
     * */
    if (!advert.hasPrebidSize && event.size) {
      advert.size = sizeEventToAdSize(event.size);
    }
    // Associate the line item id with the advert
    // We'll need it later when the slot becomes viewable
    // in order to determine whether we can refresh the slot
    advert.lineItemId = event.lineItemId;
    advert.creativeId = event.creativeId;
    advert.creativeTemplateId = event.creativeTemplateId;
    void (0,_render_advert__WEBPACK_IMPORTED_MODULE_5__.renderAdvert)(advert, event).then(isRendered => {
      advert.finishedRendering(isRendered);
    });
  }
};

/***/ }),

/***/ "./src/events/on-slot-viewable.ts":
/*!****************************************!*\
  !*** ./src/events/on-slot-viewable.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   onSlotViewableFunction: () => (/* binding */ onSlotViewableFunction)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_commercial_core_constants_ad_label_height__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/constants/ad-label-height */ "../core/src/constants/ad-label-height.ts");
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _define_Advert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../define/Advert */ "./src/define/Advert.ts");
/* harmony import */ var _display_lazy_load__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../display/lazy-load */ "./src/display/lazy-load.ts");
/* harmony import */ var _lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../lib/dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _lib_dfp_non_refreshable_line_items__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../lib/dfp/non-refreshable-line-items */ "./src/lib/dfp/non-refreshable-line-items.ts");
/* harmony import */ var _lib_dfp_should_refresh__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../lib/dfp/should-refresh */ "./src/lib/dfp/should-refresh.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _lib_url__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../lib/url */ "./src/lib/url.ts");











var ADVERT_REFRESH_RATE = 30000; // 30 seconds. The minimum time allowed by Google.
/**
 * Prevent CLS when an advert is refreshed, by setting the
 * min-height of the ad slot to the height of the ad.
 */
var setAdSlotMinHeight = advert => {
  // We need to know the height of the ad to set the min-height
  if (!(0,_define_Advert__WEBPACK_IMPORTED_MODULE_4__.isAdSize)(advert.size)) {
    return;
  }
  var {
    size,
    node
  } = advert;
  // When a passback occurs, a new ad slot is created within the original ad slot.
  // We don't want to set a min-height on the parent ad slot, as the child ad slot
  // may load an ad size that we are not aware of at this point. It may be shorter,
  // which would make the min-height we set here too high.
  // Therefore it is safer to exclude ad slots where a passback may occur.
  var canSlotBePassedBack = Object.values(_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.outstreamSizes).some(_ref => {
    var {
      width,
      height
    } = _ref;
    return width === size.width && height === size.height;
  });
  if (canSlotBePassedBack) {
    return;
  }
  var isStandardAdSize = !size.isProxy();
  if (isStandardAdSize) {
    void _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].measure(() => node.getAttribute('data-label') === 'true').then(hasLabel => {
      var labelHeight = hasLabel ? _guardian_commercial_core_constants_ad_label_height__WEBPACK_IMPORTED_MODULE_1__.AD_LABEL_HEIGHT : 0;
      void _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].mutate(() => {
        var adSlotHeight = size.height + labelHeight;
        node.style.minHeight = "".concat(adSlotHeight, "px");
      });
    });
  } else {
    // For the situation when we load a non-standard size ad, e.g. fluid ad, after
    // previously loading a standard size ad. Ensure that the previously added min-height is
    // removed, so that a smaller fluid ad does not have a min-height larger than it is.
    void _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].mutate(() => {
      node.style.minHeight = '';
    });
  }
};
var setSlotAdRefresh = event => {
  var advert = (0,_lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_6__.getAdvertById)(event.slot.getSlotElementId());
  if (!advert) {
    return;
  }
  void setAdSlotMinHeight(advert);
  // Call the memoized function so we only retrieve the value from the API once
  void (0,_lib_dfp_non_refreshable_line_items__WEBPACK_IMPORTED_MODULE_7__.memoizedFetchNonRefreshableLineItemIds)().then(nonRefreshableLineItemIds => {
    // Determine whether ad should refresh
    // This value will then be checked when the timer has elapsed and
    // we want to know whether to refresh
    advert.shouldRefresh = (0,_lib_dfp_should_refresh__WEBPACK_IMPORTED_MODULE_8__.shouldRefresh)(advert, nonRefreshableLineItemIds);
  }).catch(error => {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', '⚠️ Error fetching non-refreshable line items', error);
  });
  var viewabilityThresholdMs = ADVERT_REFRESH_RATE;
  // Event listener that will load an advert once a document becomes visible
  var onDocumentVisible = () => {
    if (!document.hidden) {
      document.removeEventListener('visibilitychange', onDocumentVisible);
      (0,_display_lazy_load__WEBPACK_IMPORTED_MODULE_5__.enableLazyLoad)(advert);
    }
  };
  setTimeout(() => {
    // During the elapsed time, a 'disable-refresh' message may have been posted.
    // Check the flag again.
    if (!advert.shouldRefresh) {
      return;
    }
    // If the document is hidden don't refresh immediately
    // Instead add an event listener to refresh when document becomes visible again
    if (document.hidden) {
      document.addEventListener('visibilitychange', onDocumentVisible);
    } else {
      (0,_display_lazy_load__WEBPACK_IMPORTED_MODULE_5__.enableLazyLoad)(advert);
    }
  }, viewabilityThresholdMs);
};
/*
  Returns a function to be used as a callback for GTP 'impressionViewable' event
  Uses URL parameters.
 */
var onSlotViewableFunction = () => {
  var queryParams = (0,_lib_url__WEBPACK_IMPORTED_MODULE_10__.getUrlVars)();
  return event => {
    var slot = event.slot.getTargeting('slot')[0];
    _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_2__.EventTimer.get().mark('viewable', slot);
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', 'Slot viewable', slot);
    if (queryParams.adrefresh !== 'false') {
      setSlotAdRefresh(event);
    }
  };
};


/***/ }),

/***/ "./src/events/render-advert.ts":
/*!*************************************!*\
  !*** ./src/events/render-advert.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   renderAdvert: () => (/* binding */ renderAdvert)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _lib_gumgum_winning_bid__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/gumgum-winning-bid */ "./src/lib/gumgum-winning-bid.ts");
/* harmony import */ var _empty_advert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./empty-advert */ "./src/events/empty-advert.ts");
/* harmony import */ var _render_advert_label__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./render-advert-label */ "./src/events/render-advert-label.ts");






/**
 * ADVERT RENDERING
 * ----------------
 *
 * Most adverts come back from DFP ready to display as-is. But sometimes we need more: embedded components that can share
 * Guardian styles, for example, or behaviours like sticky-scrolling. This module helps 'finish' rendering any advert, and
 * decorates them with these behaviours.
 *
 */
/**
 * Types of events that are returned when executing a size change callback
 */
var addClassIfHasClass = newClassNames => function hasClass(classNames) {
  return function onAdvertRendered(advert) {
    if (classNames.some(className => advert.node.classList.contains(className))) {
      return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
        newClassNames.forEach(className => {
          advert.node.classList.add(className);
        });
      });
    }
    return Promise.resolve();
  };
};
var addFluid250 = addClassIfHasClass(['ad-slot--fluid250']);
var addFluid = addClassIfHasClass(['ad-slot--fluid']);
var removeStyleFromAdIframe = (advert, style) => {
  var adIframe = advert.node.querySelector('iframe');
  void _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
    if (adIframe) {
      adIframe.style.removeProperty(style);
    }
  });
};
var sizeCallbacks = {};
/**
 * DFP fluid ads should use existing fluid-250 styles in the top banner position
 * The vertical-align property found on DFP iframes affects the smoothness of
 * CSS transitions when expanding/collapsing various native style formats.
 */
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.fluid.toString()] = advert => addFluid(['ad-slot'])(advert).then(() => removeStyleFromAdIframe(advert, 'vertical-align'));
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.toString()] = advert => advert.updateExtraSlotClasses();
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage.toString()] = advert => advert.updateExtraSlotClasses();
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.skyscraper.toString()] = advert => advert.updateExtraSlotClasses('ad-slot--sky');
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop.toString()] = advert => advert.updateExtraSlotClasses('ad-slot--outstream');
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop.toString()] = advert => advert.updateExtraSlotClasses('ad-slot--outstream');
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamMobile.toString()] = advert => advert.updateExtraSlotClasses('ad-slot--outstream');
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.googleCard.toString()] = advert => advert.updateExtraSlotClasses('ad-slot--gc');
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.pubmaticInterscroller.toString()] = advert => {
  advert.shouldRefresh = false;
  return Promise.resolve();
};
/**
 * Out of page adverts - creatives that aren't directly shown on the page - need to be hidden,
 * and their containers closed up.
 */
var outOfPageCallback = advert => {
  var parent = advert.node.parentNode;
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
    advert.node.classList.add('ad-slot--collapse');
    // top-above-nav and fronts-banner have an extra container
    if (advert.id.includes('top-above-nav')) {
      var adContainer = advert.node.closest('.top-banner-ad-container');
      if (adContainer) {
        adContainer.style.display = 'none';
      }
    }
    if (advert.id.includes('fronts-banner')) {
      var _adContainer = advert.node.closest('.top-fronts-banner-ad-container');
      if (_adContainer) {
        _adContainer.style.display = 'none';
      }
    }
    // if in a slice, add the 'no mpu' class
    if (parent.classList.contains('fc-slice__item--mpu-candidate')) {
      parent.classList.add('fc-slice__item--no-mpu');
    }
  });
};
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outOfPage.toString()] = outOfPageCallback;
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.empty.toString()] = ad => Promise.resolve((0,_empty_advert__WEBPACK_IMPORTED_MODULE_4__.emptyAdvert)(ad));
/**
 * Commercial components with merch sizing get fluid-250 styling
 */
sizeCallbacks[_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.merchandising.toString()] = addFluid250(['ad-slot--commercial-component']);
var addContentClass = adSlotNode => {
  var adSlotContent = adSlotNode.querySelector("#".concat(adSlotNode.id, " > div:not(.ad-slot__label)"));
  if (adSlotContent) {
    void _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
      adSlotContent.classList.add('ad-slot__content');
    });
  }
};
/* Centre certain slots in their containers, this class is added dynamically to avoid rendering quirks with the ad label and variable width ads. */
var addContainerClass = (adSlotNode, isRendered) => {
  var centreAdSlots = ['dfp-ad--top-above-nav', 'dfp-ad--merchandising-high', 'dfp-ad--merchandising'];
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].measure(() => {
    var _adSlotNode$parentEle;
    return isRendered && !adSlotNode.classList.contains('ad-slot--fluid') && ((_adSlotNode$parentEle = adSlotNode.parentElement) === null || _adSlotNode$parentEle === void 0 ? void 0 : _adSlotNode$parentEle.classList.contains('ad-slot-container')) && centreAdSlots.includes(adSlotNode.id);
  }).then(shouldCentre => {
    if (shouldCentre) {
      return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
        var _adSlotNode$parentEle2;
        (_adSlotNode$parentEle2 = adSlotNode.parentElement) === null || _adSlotNode$parentEle2 === void 0 || _adSlotNode$parentEle2.classList.add('ad-slot-container--centre-slot');
      });
    }
  });
};
/**
 * Check if the ad slot has a corresponding iframe to indicte the ad has rendered.
 * @param adSlot
 * @returns
 */
var hasIframe = adSlot => new Promise(resolve => {
  // DFP will sometimes return empty iframes, denoted with a '__hidden__' parameter embedded in its ID.
  // We need to be sure only to select the ad content frame.
  var iFrame = adSlot.querySelector('iframe:not([id*="__hidden__"])');
  resolve(!!iFrame);
});
/**
 * @param advert - as defined in lib/dfp/Advert
 * @param slotRenderEndedEvent - GPT slotRenderEndedEvent
 * @returns {Promise} - resolves once all necessary rendering is queued up
 */
var renderAdvert = (advert, slotRenderEndedEvent) => {
  var _window$guardian$comm;
  var matchingAd = (_window$guardian$comm = window.guardian.commercial) === null || _window$guardian$comm === void 0 || (_window$guardian$comm = _window$guardian$comm.a9WinningBids) === null || _window$guardian$comm === void 0 ? void 0 : _window$guardian$comm.find(bidResponse => bidResponse.slotID == advert.id);
  var isA9GumGum = (matchingAd === null || matchingAd === void 0 ? void 0 : matchingAd.amznp) === '1lsxjb4';
  if (slotRenderEndedEvent.advertiserId === 4751525411 && isA9GumGum) {
    var adSlotId = advert.node.id;
    (0,_lib_gumgum_winning_bid__WEBPACK_IMPORTED_MODULE_3__.logGumGumWinningBid)(adSlotId, slotRenderEndedEvent.advertiserId.toString());
  }
  addContentClass(advert.node);
  return hasIframe(advert.node).then(isRendered => {
    var _slotRenderEndedEvent;
    var creativeTemplateId = (_slotRenderEndedEvent = slotRenderEndedEvent.creativeTemplateId) !== null && _slotRenderEndedEvent !== void 0 ? _slotRenderEndedEvent : undefined;
    var callSizeCallback = () => {
      if (advert.size) {
        /**
         * We reset hasPrebidSize to the default value of false for
         * subsequent ad refreshes as they may not be prebid ads.
         * */
        advert.hasPrebidSize = false;
        var sizeCallback = sizeCallbacks[advert.size.toString()];
        return Promise.resolve(sizeCallback !== undefined ? sizeCallback(advert, slotRenderEndedEvent) : advert.updateExtraSlotClasses());
      }
      return Promise.resolve();
    };
    var addRenderedClass = () => isRendered ? _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
      advert.node.classList.add('ad-slot--rendered');
    }) : Promise.resolve();
    return callSizeCallback().then(() => (0,_render_advert_label__WEBPACK_IMPORTED_MODULE_5__.renderAdvertLabel)(advert.node, creativeTemplateId)).then(() => addContainerClass(advert.node, isRendered)).then(addRenderedClass).then(() => isRendered);
  }).catch(err => {
    (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(err, 'commercial');
    return Promise.resolve(false);
  });
};


/***/ }),

/***/ "./src/init/consented-advertising.ts":
/*!*******************************************!*\
  !*** ./src/init/consented-advertising.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bootCommercialWhenReady: () => (/* binding */ bootCommercialWhenReady)
/* harmony export */ });
/* harmony import */ var _lib_ad_verification_prepare_ad_verification__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/ad-verification/prepare-ad-verification */ "./src/lib/ad-verification/prepare-ad-verification.ts");
/* harmony import */ var _lib_commercial_boot_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/commercial-boot-utils */ "./src/lib/commercial-boot-utils.ts");
/* harmony import */ var _consented_ad_free_slot_remove__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./consented/ad-free-slot-remove */ "./src/init/consented/ad-free-slot-remove.ts");
/* harmony import */ var _consented_comscore__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./consented/comscore */ "./src/init/consented/comscore.ts");
/* harmony import */ var _consented_dfp_listeners__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./consented/dfp-listeners */ "./src/init/consented/dfp-listeners.ts");
/* harmony import */ var _consented_dynamic_ad_slots__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./consented/dynamic-ad-slots */ "./src/init/consented/dynamic-ad-slots.ts");
/* harmony import */ var _consented_fill_slot_listener__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./consented/fill-slot-listener */ "./src/init/consented/fill-slot-listener.ts");
/* harmony import */ var _consented_ipsos_mori__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./consented/ipsos-mori */ "./src/init/consented/ipsos-mori.ts");
/* harmony import */ var _consented_messenger__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./consented/messenger */ "./src/init/consented/messenger.ts");
/* harmony import */ var _consented_opinary__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./consented/opinary */ "./src/init/consented/opinary.ts");
/* harmony import */ var _consented_prepare_a9__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./consented/prepare-a9 */ "./src/init/consented/prepare-a9.ts");
/* harmony import */ var _consented_prepare_admiral__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./consented/prepare-admiral */ "./src/init/consented/prepare-admiral.ts");
/* harmony import */ var _consented_prepare_googletag__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./consented/prepare-googletag */ "./src/init/consented/prepare-googletag.ts");
/* harmony import */ var _consented_prepare_permutive__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./consented/prepare-permutive */ "./src/init/consented/prepare-permutive.ts");
/* harmony import */ var _consented_prepare_prebid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ./consented/prepare-prebid */ "./src/init/consented/prepare-prebid.ts");
/* harmony import */ var _consented_remove_slots__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(/*! ./consented/remove-slots */ "./src/init/consented/remove-slots.ts");
/* harmony import */ var _consented_teads_cookieless__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(/*! ./consented/teads-cookieless */ "./src/init/consented/teads-cookieless.ts");
/* harmony import */ var _consented_third_party_tags__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(/*! ./consented/third-party-tags */ "./src/init/consented/third-party-tags.ts");
/* harmony import */ var _consented_track_gpc_signal__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(/*! ./consented/track-gpc-signal */ "./src/init/consented/track-gpc-signal.ts");
/* harmony import */ var _consented_track_scroll_depth__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(/*! ./consented/track-scroll-depth */ "./src/init/consented/track-scroll-depth.ts");
/* harmony import */ var _shared_reload_page_on_consent_change__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(/*! ./shared/reload-page-on-consent-change */ "./src/init/shared/reload-page-on-consent-change.ts");
/* harmony import */ var _shared_set_adtest_cookie__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(/*! ./shared/set-adtest-cookie */ "./src/init/shared/set-adtest-cookie.ts");
/* harmony import */ var _shared_set_adtest_in_labels_cookie__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(/*! ./shared/set-adtest-in-labels-cookie */ "./src/init/shared/set-adtest-in-labels-cookie.ts");























// all modules needed for commercial code and ads to run
var commercialModules = [_consented_ad_free_slot_remove__WEBPACK_IMPORTED_MODULE_2__.adFreeSlotRemove, _consented_remove_slots__WEBPACK_IMPORTED_MODULE_15__.removeDisabledSlots, _consented_comscore__WEBPACK_IMPORTED_MODULE_3__.init, _consented_ipsos_mori__WEBPACK_IMPORTED_MODULE_7__.init, _consented_teads_cookieless__WEBPACK_IMPORTED_MODULE_16__.initTeadsCookieless, _consented_track_scroll_depth__WEBPACK_IMPORTED_MODULE_19__.init, _consented_track_gpc_signal__WEBPACK_IMPORTED_MODULE_18__.init, _consented_messenger__WEBPACK_IMPORTED_MODULE_8__.init, _shared_set_adtest_cookie__WEBPACK_IMPORTED_MODULE_21__.init, _shared_set_adtest_in_labels_cookie__WEBPACK_IMPORTED_MODULE_22__.init, _shared_reload_page_on_consent_change__WEBPACK_IMPORTED_MODULE_20__.reloadPageOnConsentChange, _consented_prepare_prebid__WEBPACK_IMPORTED_MODULE_14__.init, _consented_dfp_listeners__WEBPACK_IMPORTED_MODULE_4__.initDfpListeners,
// Permutive init code must run before googletag.enableServices() is called
() => (0,_consented_prepare_permutive__WEBPACK_IMPORTED_MODULE_13__.initPermutive)().then(_consented_prepare_googletag__WEBPACK_IMPORTED_MODULE_12__.init), _consented_dynamic_ad_slots__WEBPACK_IMPORTED_MODULE_5__.initDynamicAdSlots, _consented_prepare_a9__WEBPACK_IMPORTED_MODULE_10__.init, _consented_fill_slot_listener__WEBPACK_IMPORTED_MODULE_6__.initFillSlotListener, _lib_ad_verification_prepare_ad_verification__WEBPACK_IMPORTED_MODULE_0__.init, _consented_third_party_tags__WEBPACK_IMPORTED_MODULE_17__.init, _consented_opinary__WEBPACK_IMPORTED_MODULE_9__.initOpinaryPollListener, _consented_prepare_admiral__WEBPACK_IMPORTED_MODULE_11__.initAdmiralAdblockRecovery];
var bootCommercialWhenReady = () => {
  if (!!window.guardian.mustardCut || !!window.guardian.polyfilled) {
    void (0,_lib_commercial_boot_utils__WEBPACK_IMPORTED_MODULE_1__.bootCommercial)(commercialModules);
  } else {
    window.guardian.queue.push(() => (0,_lib_commercial_boot_utils__WEBPACK_IMPORTED_MODULE_1__.bootCommercial)(commercialModules));
  }
};


/***/ }),

/***/ "./src/init/consented/admiral.ts":
/*!***************************************!*\
  !*** ./src/init/consented/admiral.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getAdmiralAbTestVariant: () => (/* binding */ getAdmiralAbTestVariant),
/* harmony export */   recordAdmiralOphanEvent: () => (/* binding */ recordAdmiralOphanEvent),
/* harmony export */   setAdmiralTargeting: () => (/* binding */ setAdmiralTargeting)
/* harmony export */ });
/* harmony import */ var _experiments_ab__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../experiments/ab */ "./src/experiments/ab.ts");
/* harmony import */ var _experiments_tests_admiral_adblocker_recovery__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../experiments/tests/admiral-adblocker-recovery */ "./src/experiments/tests/admiral-adblocker-recovery.ts");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


/**
 * Fetches AB test variant name for Admiral, as there are two variants
 */
var getAdmiralAbTestVariant = () => {
  if ((0,_experiments_ab__WEBPACK_IMPORTED_MODULE_0__.isUserInVariant)(_experiments_tests_admiral_adblocker_recovery__WEBPACK_IMPORTED_MODULE_1__.admiralAdblockRecovery, 'variant-detect')) {
    return 'variant-detect';
  }
  if ((0,_experiments_ab__WEBPACK_IMPORTED_MODULE_0__.isUserInVariant)(_experiments_tests_admiral_adblocker_recovery__WEBPACK_IMPORTED_MODULE_1__.admiralAdblockRecovery, 'variant-recover')) {
    return 'variant-recover';
  }
  if ((0,_experiments_ab__WEBPACK_IMPORTED_MODULE_0__.isUserInVariant)(_experiments_tests_admiral_adblocker_recovery__WEBPACK_IMPORTED_MODULE_1__.admiralAdblockRecovery, 'control')) {
    return 'control';
  }
  return undefined;
};
/**
 * Sends component events to Ophan with the componentType of `AD_BLOCK_RECOVERY`
 * as well as sending the AB test participation
 *
 * @param overrides allows overriding / setting values for `action` and `value`
 */
var recordAdmiralOphanEvent = _ref => {
  var _window$guardian$opha;
  var {
    action,
    value
  } = _ref;
  var abTestVariant = getAdmiralAbTestVariant();
  var componentEvent = _objectSpread(_objectSpread({
    component: {
      componentType: 'AD_BLOCK_RECOVERY',
      id: 'admiral-adblock-recovery'
    },
    action
  }, value ? {
    value
  } : {}), abTestVariant ? {
    abTest: {
      name: 'AdmiralAdblockRecovery',
      variant: abTestVariant
    }
  } : {});
  (_window$guardian$opha = window.guardian.ophan) === null || _window$guardian$opha === void 0 || _window$guardian$opha.record({
    componentEvent
  });
};
/**
 * Sets targeting on the Admiral object
 *
 * @param key targeting key sent to Admiral
 * @param value targeting value sent to Admiral
 */
var setAdmiralTargeting = (key, value) => {
  var _window$admiral, _window;
  return (_window$admiral = (_window = window).admiral) === null || _window$admiral === void 0 ? void 0 : _window$admiral.call(_window, 'targeting', 'set', key, value);
};


/***/ }),

/***/ "./src/init/consented/article-body-adverts.ts":
/*!****************************************************!*\
  !*** ./src/init/consented/article-body-adverts.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initArticleBodyAdverts: () => (/* binding */ initArticleBodyAdverts)
/* harmony export */ });
/* harmony import */ var _insert_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../insert/fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");
/* harmony import */ var _insert_spacefinder_article__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../insert/spacefinder/article */ "./src/insert/spacefinder/article.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


/**
 * Fill an ad slot with a googletag advert
 * @param name The name of the ad slot
 * @param slot The slot element
 * @param additionalSizes Additional sizes to be added to the slot
 */
var fillAdSlot = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (name, slot, additionalSizes) {
    var shouldForceDisplay = ['carrot'].includes(name);
    yield (0,_insert_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_0__.fillDynamicAdSlot)(slot, shouldForceDisplay, additionalSizes);
  });
  return function fillAdSlot(_x, _x2, _x3) {
    return _ref.apply(this, arguments);
  };
}();
/**
 * Initialise article body ad slots
 */
var initArticleBodyAdverts = () => {
  document.addEventListener('article:sign-in-gate-dismissed', () => {
    void (0,_insert_spacefinder_article__WEBPACK_IMPORTED_MODULE_1__.init)(fillAdSlot);
  });
  return (0,_insert_spacefinder_article__WEBPACK_IMPORTED_MODULE_1__.init)(fillAdSlot);
};


/***/ }),

/***/ "./src/init/consented/dfp-listeners.ts":
/*!*********************************************!*\
  !*** ./src/init/consented/dfp-listeners.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initDfpListeners: () => (/* binding */ initDfpListeners)
/* harmony export */ });
/* harmony import */ var _events_on_slot_load__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../events/on-slot-load */ "./src/events/on-slot-load.ts");
/* harmony import */ var _events_on_slot_render__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../events/on-slot-render */ "./src/events/on-slot-render.ts");
/* harmony import */ var _events_on_slot_viewable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../events/on-slot-viewable */ "./src/events/on-slot-viewable.ts");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/error/report-error */ "./src/lib/error/report-error.ts");




var initDfpListeners = () => {
  window.googletag.cmd.push(() => {
    var pubads = window.googletag.pubads();
    pubads.addEventListener('slotRenderEnded', (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_3__.wrapWithErrorReporting)(_events_on_slot_render__WEBPACK_IMPORTED_MODULE_1__.onSlotRender));
    pubads.addEventListener('slotOnload', (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_3__.wrapWithErrorReporting)(_events_on_slot_load__WEBPACK_IMPORTED_MODULE_0__.onSlotLoad));
    pubads.addEventListener('impressionViewable', (0,_events_on_slot_viewable__WEBPACK_IMPORTED_MODULE_2__.onSlotViewableFunction)());
  });
  return Promise.resolve();
};


/***/ }),

/***/ "./src/init/consented/dynamic-ad-slots.ts":
/*!************************************************!*\
  !*** ./src/init/consented/dynamic-ad-slots.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initDynamicAdSlots: () => (/* binding */ initDynamicAdSlots)
/* harmony export */ });
/* harmony import */ var _insert_comments_expanded_advert__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../insert/comments-expanded-advert */ "./src/insert/comments-expanded-advert.ts");
/* harmony import */ var _insert_fixures__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../insert/fixures */ "./src/insert/fixures.ts");
/* harmony import */ var _insert_high_merch__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../insert/high-merch */ "./src/insert/high-merch.ts");
/* harmony import */ var _insert_mobile_sticky__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../insert/mobile-sticky */ "./src/insert/mobile-sticky.ts");
/* harmony import */ var _insert_spacefinder_liveblog_adverts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../insert/spacefinder/liveblog-adverts */ "./src/insert/spacefinder/liveblog-adverts.ts");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _article_body_adverts__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./article-body-adverts */ "./src/init/consented/article-body-adverts.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }







var dynamicAdSlotModules = [['cm-mobileSticky', _insert_mobile_sticky__WEBPACK_IMPORTED_MODULE_3__.init], ['cm-highMerch', _insert_high_merch__WEBPACK_IMPORTED_MODULE_2__.init], ['cm-articleBodyAdverts', _article_body_adverts__WEBPACK_IMPORTED_MODULE_6__.initArticleBodyAdverts], ['cm-liveblogAdverts', _insert_spacefinder_liveblog_adverts__WEBPACK_IMPORTED_MODULE_4__.init], ['cm-commentsExpandedAdverts', _insert_comments_expanded_advert__WEBPACK_IMPORTED_MODULE_0__.initCommentsExpandedAdverts], ['cm-footballRight', _insert_fixures__WEBPACK_IMPORTED_MODULE_1__.init]];
var initDynamicAdSlots = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    return Promise.all(dynamicAdSlotModules.map(/*#__PURE__*/function () {
      var _ref3 = _asyncToGenerator(function* (_ref2) {
        var [name, init] = _ref2;
        try {
          yield init();
        } catch (error) {
          (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_5__.reportError)(error, 'commercial', {
            tag: name
          });
        }
      });
      return function (_x) {
        return _ref3.apply(this, arguments);
      };
    }()));
  });
  return function initDynamicAdSlots() {
    return _ref.apply(this, arguments);
  };
}();

/***/ }),

/***/ "./src/init/consented/fill-slot-listener.ts":
/*!**************************************************!*\
  !*** ./src/init/consented/fill-slot-listener.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initFillSlotListener: () => (/* binding */ initFillSlotListener)
/* harmony export */ });
/* harmony import */ var _insert_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../insert/fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");


var isCustomEvent = event => {
  return 'detail' in event;
};
/**
 * Listen for events to fill an additional slot
 *
 * This is for slots that are not fixed (aka SSR) or dynamic (aka injected from
 * this bundle, e.g. via spacefinder). They are placed on the page by a
 * non-standard route, for example in a thrasher or some other async process
 * that adds the slot at an unknown time but still expects the commercial
 * runtime to fulfill the slot.
 *
 * The extra logic in addition to dynamic slots covers when:
 * - the commercial runtime loads before the slot so we wait for a custom event
 * - the commercial runtime loads after the slot so we fill the slot immediately
 *
 * These events will not be received from a restricted iframe such, such as a
 * cross-origin or safeframe iframe.
 */
var createSlotFillListener = () => {
  document.addEventListener('gu.commercial.slot.fill', event => {
    window.googletag.cmd.push(() => {
      if (isCustomEvent(event)) {
        var {
          slotId,
          additionalSizes
        } = event.detail;
        if (_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_1__.dfpEnv.adverts.has(slotId)) {
          return;
        }
        var slot = document.getElementById(slotId);
        if (slot) {
          void (0,_insert_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_0__.fillDynamicAdSlot)(slot, false, additionalSizes);
        }
      }
    });
  });
};
var initFillSlotListener = () => Promise.resolve(createSlotFillListener());


/***/ }),

/***/ "./src/init/consented/messenger.ts":
/*!*****************************************!*\
  !*** ./src/init/consented/messenger.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _lib_messenger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/messenger */ "./src/lib/messenger.ts");
/* harmony import */ var _lib_messenger_background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/messenger/background */ "./src/lib/messenger/background.ts");
/* harmony import */ var _lib_messenger_disable_refresh__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/messenger/disable-refresh */ "./src/lib/messenger/disable-refresh.ts");
/* harmony import */ var _lib_messenger_full_width__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/messenger/full-width */ "./src/lib/messenger/full-width.ts");
/* harmony import */ var _lib_messenger_get_page_targeting__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/messenger/get-page-targeting */ "./src/lib/messenger/get-page-targeting.ts");
/* harmony import */ var _lib_messenger_get_page_url__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/messenger/get-page-url */ "./src/lib/messenger/get-page-url.ts");
/* harmony import */ var _lib_messenger_get_stylesheet__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/messenger/get-stylesheet */ "./src/lib/messenger/get-stylesheet.ts");
/* harmony import */ var _lib_messenger_measure_ad_load__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../lib/messenger/measure-ad-load */ "./src/lib/messenger/measure-ad-load.ts");
/* harmony import */ var _lib_messenger_passback__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../lib/messenger/passback */ "./src/lib/messenger/passback.ts");
/* harmony import */ var _lib_messenger_passback_refresh__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../lib/messenger/passback-refresh */ "./src/lib/messenger/passback-refresh.ts");
/* harmony import */ var _lib_messenger_resize__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../lib/messenger/resize */ "./src/lib/messenger/resize.ts");
/* harmony import */ var _lib_messenger_scroll__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../../lib/messenger/scroll */ "./src/lib/messenger/scroll.ts");
/* harmony import */ var _lib_messenger_type__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../../lib/messenger/type */ "./src/lib/messenger/type.ts");
/* harmony import */ var _lib_messenger_video__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ../../lib/messenger/video */ "./src/lib/messenger/video.ts");
/* harmony import */ var _lib_messenger_viewport__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! ../../lib/messenger/viewport */ "./src/lib/messenger/viewport.ts");















/**
 * Messenger gets to skip the promise chain and run immediately.
 */
(0,_lib_messenger__WEBPACK_IMPORTED_MODULE_0__.init)([_lib_messenger_type__WEBPACK_IMPORTED_MODULE_12__.init, _lib_messenger_get_stylesheet__WEBPACK_IMPORTED_MODULE_6__.init, _lib_messenger_get_page_targeting__WEBPACK_IMPORTED_MODULE_4__.init, _lib_messenger_get_page_url__WEBPACK_IMPORTED_MODULE_5__.init, _lib_messenger_measure_ad_load__WEBPACK_IMPORTED_MODULE_7__.init, _lib_messenger_passback_refresh__WEBPACK_IMPORTED_MODULE_9__.init, _lib_messenger_resize__WEBPACK_IMPORTED_MODULE_10__.init, _lib_messenger_full_width__WEBPACK_IMPORTED_MODULE_3__.init, _lib_messenger_background__WEBPACK_IMPORTED_MODULE_1__.init, _lib_messenger_disable_refresh__WEBPACK_IMPORTED_MODULE_2__.init, _lib_messenger_passback__WEBPACK_IMPORTED_MODULE_8__.init, _lib_messenger_video__WEBPACK_IMPORTED_MODULE_13__.initMessengerVideoProgressReporting], [_lib_messenger_scroll__WEBPACK_IMPORTED_MODULE_11__.init, _lib_messenger_viewport__WEBPACK_IMPORTED_MODULE_14__.init]);
var init = () => Promise.resolve();


/***/ }),

/***/ "./src/init/consented/opinary.ts":
/*!***************************************!*\
  !*** ./src/init/consented/opinary.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   initOpinaryPollListener: () => (/* binding */ initOpinaryPollListener)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isUndefined/isUndefined.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");

var isOpinaryEvent = e => {
  if (typeof e.data !== 'object' || e.data === null || !('type' in e.data) || !('poll' in e.data)) {
    return false;
  }
  // Type assertion to let TypeScript know the structure
  var data = e.data;
  return data.type === 'opinary.vote' && data.poll.dmpIntegration;
};
var opinaryPollListener = event => {
  if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isUndefined)(window.permutive) || (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isUndefined)(window.permutive.track) || !isOpinaryEvent(event)) {
    return;
  }
  var {
    poll,
    vote
  } = event.data;
  /**
   * IMPORTANT: Do not change the shape of this data before checking with Permutive!
   * This is a Permutive custom event and is documented and specified manually in a schema
   * @see https://support.permutive.com/hc/en-us/articles/10211335253660-Schema-Updates-for-the-Pageview-Event-Custom-Events
   * for more information
   */
  var surveyResponse = {
    survey: {
      id: poll.pollId,
      type: poll.type,
      solution: 'Opinary'
    },
    question: {
      text: poll.header
    },
    answer: {
      text: vote.label,
      posX: vote.x || 0.0,
      posY: vote.y || 0.0,
      optionIdentifier: vote.optionID || '',
      optionPosition: vote.position || 0,
      rawValue: vote.value || 0.0,
      unit: vote.unit || ''
    }
  };
  window.permutive.track('SurveyResponse', surveyResponse);
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Sent survey response to Permutive for poll ID ".concat(poll.pollId));
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', surveyResponse);
};
var initOpinaryPollListener = () => Promise.resolve(window.addEventListener('message', opinaryPollListener));
// Exports for testing only
var _ = {
  isOpinaryEvent
};


/***/ }),

/***/ "./src/init/consented/prepare-a9.ts":
/*!******************************************!*\
  !*** ./src/init/consented/prepare-a9.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _lib_vendor_a9_apstag__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/__vendor/a9-apstag */ "./src/lib/__vendor/a9-apstag.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_detect_detect_google_proxy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/detect/detect-google-proxy */ "./src/lib/detect/detect-google-proxy.ts");
/* harmony import */ var _lib_header_bidding_a9_a9__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../lib/header-bidding/a9/a9 */ "./src/lib/header-bidding/a9/a9.ts");
/* harmony import */ var _lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../lib/header-bidding/utils */ "./src/lib/header-bidding/utils.ts");








var shouldLoadA9 = () => {
  var _ref;
  return (// There are two articles that InfoSec would like to avoid loading scripts on
    (_ref = !_lib_commercial_features__WEBPACK_IMPORTED_MODULE_5__.commercialFeatures.isSecureContact && !(0,_lib_detect_detect_google_proxy__WEBPACK_IMPORTED_MODULE_6__.isGoogleProxy)() && window.guardian.config.switches.a9HeaderBidding && _lib_commercial_features__WEBPACK_IMPORTED_MODULE_5__.commercialFeatures.shouldLoadGoogletag && !_lib_commercial_features__WEBPACK_IMPORTED_MODULE_5__.commercialFeatures.adFree && !window.guardian.config.page.hasPageSkin && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInCanada)()) !== null && _ref !== void 0 ? _ref : false
  );
};
var setupA9 = () => {
  if (shouldLoadA9() || _lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_8__.shouldIncludeOnlyA9) {
    // Load a9 third party stub
    (0,_lib_vendor_a9_apstag__WEBPACK_IMPORTED_MODULE_4__.a9Apstag)();
    _lib_header_bidding_a9_a9__WEBPACK_IMPORTED_MODULE_7__.a9.initialise();
  }
  return Promise.resolve();
};
var setupA9Once = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(setupA9);
/**
 * Initialise A9, Amazon header bidding library
 * https://ams.amazon.com/webpublisher/uam/docs/web-integration-documentation/integration-guide/javascript-guide/display.html
 */
var init = () => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.onConsent)().then(consentState => {
  if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.getConsentFor)('a9', consentState)) {
    return setupA9Once();
  }
  throw Error('No consent for a9');
}).catch(e => {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', '⚠️ Failed to execute a9', e);
});
var _ = {
  setupA9
};

/***/ }),

/***/ "./src/init/consented/prepare-admiral.ts":
/*!***********************************************!*\
  !*** ./src/init/consented/prepare-admiral.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initAdmiralAdblockRecovery: () => (/* binding */ initAdmiralAdblockRecovery)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _admiral__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./admiral */ "./src/init/consented/admiral.ts");


var handleMeasureDetectedEvent = event => {
  var isMeasureDetectedEvent = e => typeof e === 'object' && 'adblocking' in e && 'whitelisted' in e && 'subscribed' in e;
  if (isMeasureDetectedEvent(event)) {
    if (event.adblocking) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', '🛡️ Admiral - user has an adblocker and it is enabled');
      (0,_admiral__WEBPACK_IMPORTED_MODULE_1__.recordAdmiralOphanEvent)({
        action: 'DETECT',
        value: 'blocked'
      });
    }
    if (event.whitelisted) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', '🛡️ Admiral - user has seen Engage and subsequently disabled their adblocker');
      (0,_admiral__WEBPACK_IMPORTED_MODULE_1__.recordAdmiralOphanEvent)({
        action: 'DETECT',
        value: 'whitelisted'
      });
    }
    if (event.subscribed) {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', '🛡️ Admiral - user has an active subscription to a transact plan');
    }
  } else {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "\uD83D\uDEE1\uFE0F Admiral - Event is not of expected format of measure.detected ".concat(JSON.stringify(event)));
  }
};
var handleCandidateShownEvent = event => {
  var isCandidateShownEvent = e => typeof e === 'object' && 'candidateID' in e && 'variantID' in e && 'candidateGroups' in e;
  if (isCandidateShownEvent(event)) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "\uD83D\uDEE1\uFE0F Admiral - Launching candidate ".concat(event.candidateID));
    (0,_admiral__WEBPACK_IMPORTED_MODULE_1__.recordAdmiralOphanEvent)({
      action: 'VIEW',
      value: event.candidateID
    });
  } else {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "\uD83D\uDEE1\uFE0F Admiral - Event is not of expected format of candidate.shown ".concat(JSON.stringify(event)));
  }
};
var handleCandidateDismissedEvent = event => {
  var isCandidateDismissedEvent = e => typeof e === 'object' && 'candidateID' in e && 'candidateGroups' in e;
  if (isCandidateDismissedEvent(event)) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "\uD83D\uDEE1\uFE0F Admiral - Candidate ".concat(event.candidateID, " was dismissed"));
    (0,_admiral__WEBPACK_IMPORTED_MODULE_1__.recordAdmiralOphanEvent)({
      action: 'CLOSE',
      value: event.candidateID
    });
  } else {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "\uD83D\uDEE1\uFE0F Admiral - Event is not of expected format of candidate.dismissed ".concat(JSON.stringify(event)));
  }
};
var setUpAdmiralEventLogger = admiral => {
  admiral('after', 'measure.detected', function (event) {
    handleMeasureDetectedEvent(event);
  });
  admiral('after', 'candidate.shown', function (event) {
    handleCandidateShownEvent(event);
  });
  admiral('after', 'candidate.dismissed', function (event) {
    handleCandidateDismissedEvent(event);
  });
};
/**
 * Admiral Adblock Recovery Init
 *
 * The script is loaded conditionally as a third-party-tag
 * @see /bundle/src/init/consented/third-party-tags.ts
 *
 * This function ensures admiral is available on the window object
 * and sets up Admiral event logging
 */
var initAdmiralAdblockRecovery = () => {
  // Set up window.admiral
  /* eslint-disable -- This is a stub provided by Admiral */
  window.admiral = window.admiral || function () {
    // @ts-expect-error
    (admiral.q = admiral.q || []).push(arguments);
  };
  /* eslint-enable */
  void setUpAdmiralEventLogger(window.admiral);
  return Promise.resolve();
};


/***/ }),

/***/ "./src/init/consented/prepare-googletag.ts":
/*!*************************************************!*\
  !*** ./src/init/consented/prepare-googletag.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/loadScript/loadScript.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_identity_api__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/identity/api */ "./src/lib/identity/api.ts");
/* harmony import */ var _lib_page_targeting__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/page-targeting */ "./src/lib/page-targeting.ts");
/* harmony import */ var _lib_third_party_cookies__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../lib/third-party-cookies */ "./src/lib/third-party-cookies.ts");
/* harmony import */ var _remove_slots__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./remove-slots */ "./src/init/consented/remove-slots.ts");
/* harmony import */ var _static_ad_slots__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./static-ad-slots */ "./src/init/consented/static-ad-slots.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }








var setPageTargeting = (consentState, isSignedIn) => Object.entries((0,_lib_page_targeting__WEBPACK_IMPORTED_MODULE_6__.getPageTargeting)(consentState, isSignedIn)).forEach(_ref => {
  var [key, value] = _ref;
  if (!value) return;
  window.googletag.pubads().setTargeting(key, value);
});
/**
 * Also known as PPID
 */
var setPublisherProvidedId = () => {
  void (0,_lib_identity_api__WEBPACK_IMPORTED_MODULE_5__.getGoogleTagId)().then(googleTagId => {
    if (googleTagId !== null) {
      window.googletag.pubads().setPublisherProvidedId(googleTagId);
    }
  });
};
/**
 * 	Track usage of cookieDeprecationLabel
 */
var setCookieDeprecationLabel = () => {
  if ('cookieDeprecationLabel' in navigator) {
    var _navigator$cookieDepr;
    void ((_navigator$cookieDepr = navigator.cookieDeprecationLabel) === null || _navigator$cookieDepr === void 0 ? void 0 : _navigator$cookieDepr.getValue().then(value => {
      var cookieDeprecationLabel = value || 'empty';
      window.googletag.pubads().setTargeting('cookieDeprecationLabel', cookieDeprecationLabel);
    }));
  }
};
var enableTargeting = consentState => {
  if (consentState.canTarget) {
    window.googletag.cmd.push(setPublisherProvidedId);
    window.googletag.cmd.push(setCookieDeprecationLabel);
    window.googletag.cmd.push(_lib_third_party_cookies__WEBPACK_IMPORTED_MODULE_7__.checkThirdPartyCookiesEnabled);
  }
};
var isGoogleTagAllowed = consentState => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.getConsentFor)('googletag', consentState);
var canRunGoogletag = consentState => {
  if (consentState.tcfv2) {
    return isGoogleTagAllowed(consentState);
  }
  return true;
};
var handleLocalePermissions = consentState => {
  if (consentState.usnat) {
    // US mode- USNAT is a general-purpose consent string for various state laws
    window.googletag.cmd.push(() => {
      window.googletag.pubads().setPrivacySettings({
        restrictDataProcessing: !consentState.canTarget
      });
    });
  } else if (consentState.aus) {
    // AUS mode
    window.googletag.cmd.push(() => {
      window.googletag.pubads().setPrivacySettings({
        nonPersonalizedAds: !isGoogleTagAllowed(consentState)
      });
    });
  }
};
var init = () => {
  var setupAdvertising = /*#__PURE__*/function () {
    var _ref2 = _asyncToGenerator(function* () {
      var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.onConsent)();
      _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('googletagInitStart');
      var canRun = canRunGoogletag(consentState);
      enableTargeting(consentState);
      handleLocalePermissions(consentState);
      // Prebid will already be loaded, and window.googletag is stubbed in `commercial.js`.
      // Just load googletag - it's already added to the window by Prebid.
      if (canRun) {
        var _window$guardian$conf, _window$guardian$conf2;
        var isSignedIn = yield (0,_lib_identity_api__WEBPACK_IMPORTED_MODULE_5__.isUserLoggedIn)();
        window.googletag.cmd.push(() => _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get().mark('googletagInitEnd'), () => setPageTargeting(consentState, isSignedIn),
        // Note: this function isn't synchronous like most buffered cmds, it's a promise. It's put in here to ensure
        // it strictly follows preceding prepare-googletag work (and the module itself ensures dependencies are
        // fulfilled), but don't assume this function is complete when queueing subsequent work using cmd.push
        () => void (0,_static_ad_slots__WEBPACK_IMPORTED_MODULE_9__.fillStaticAdvertSlots)());
        // The DuckDuckGo browser blocks ads from loading by default, so it causes a lot of noise in Sentry.
        // We filter these errors out here - DuckDuckGo is in the user agent string if someone is using the
        // desktop browser, and Ddg is present for those using the mobile browser, so we filter out both.
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.loadScript)((_window$guardian$conf = (_window$guardian$conf2 = window.guardian.config.page.libs) === null || _window$guardian$conf2 === void 0 ? void 0 : _window$guardian$conf2.googletag) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : '//securepubads.g.doubleclick.net/tag/js/gpt.js', {
          async: false
        }).catch(error => {
          if (navigator.userAgent.includes('DuckDuckGo') || navigator.userAgent.includes('Ddg')) {
            (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', '🦆 Caught loadScript error on DuckDuckGo', error);
          } else {
            throw error;
          }
        });
      }
    });
    return function setupAdvertising() {
      return _ref2.apply(this, arguments);
    };
  }();
  if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_4__.commercialFeatures.shouldLoadGoogletag) {
    return setupAdvertising()
    // on error, remove all slots
    .catch(_remove_slots__WEBPACK_IMPORTED_MODULE_8__.removeSlots);
  }
  return (0,_remove_slots__WEBPACK_IMPORTED_MODULE_8__.removeSlots)();
};

/***/ }),

/***/ "./src/init/consented/prepare-permutive.ts":
/*!*************************************************!*\
  !*** ./src/init/consented/prepare-permutive.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   initPermutive: () => (/* binding */ initPermutive)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/error/report-error */ "./src/lib/error/report-error.ts");


var isEmpty = value => value === '' || value === null || typeof value === 'undefined' || Array.isArray(value) && value.length === 0 || typeof value === 'object' && Object.keys(value).length === 0;
var removeEmpty = payload => {
  var key;
  for (key in payload) {
    if (typeof payload[key] === 'object') {
      removeEmpty(payload[key]);
    }
    if (isEmpty(payload[key])) {
      delete payload[key];
    }
  }
  return payload;
};
var generatePayload = _ref => {
  var {
    page,
    user
  } = _ref;
  var {
    isPaidContent,
    pageId,
    headline,
    contentType,
    section,
    author,
    keywords,
    webPublicationDate,
    series,
    edition,
    toneIds
  } = page;
  var safeAuthors = (author && typeof author === 'string' ? author.split(',') : []).map(str => str.trim());
  var safeKeywords = (keywords && typeof keywords === 'string' ? keywords.split(',') : []).map(str => str.trim());
  var safePublishedAt = webPublicationDate && typeof webPublicationDate === 'number' ? new Date(webPublicationDate).toISOString() : '';
  var safeToneIds = (toneIds && typeof toneIds === 'string' ? toneIds.split(',') : []).map(str => str.trim());
  var cleanPayload = removeEmpty({
    content: {
      premium: isPaidContent,
      id: pageId,
      title: headline,
      type: contentType,
      section,
      authors: safeAuthors,
      keywords: safeKeywords,
      publishedAt: safePublishedAt,
      series,
      tone: safeToneIds
    },
    user: {
      edition,
      identity: isEmpty(user) ? false : !isEmpty(user === null || user === void 0 ? void 0 : user.id)
    }
  });
  return cleanPayload;
};
var generatePermutiveIdentities = config => {
  if (typeof config.ophan === 'object' && typeof config.ophan.browserId === 'string' && config.ophan.browserId.length > 0) {
    return [{
      tag: 'ophan',
      id: config.ophan.browserId
    }];
  }
  return [];
};
var runPermutive = (pageConfig, permutiveGlobal) => {
  try {
    if (!(permutiveGlobal !== null && permutiveGlobal !== void 0 && permutiveGlobal.addon)) {
      throw new Error('Global Permutive setup error');
    }
    var permutiveIdentities = generatePermutiveIdentities(pageConfig);
    if (permutiveGlobal.identify && permutiveIdentities.length > 0) {
      permutiveGlobal.identify(permutiveIdentities);
    }
    var payload = generatePayload(pageConfig);
    permutiveGlobal.addon('web', {
      page: payload
    });
  } catch (err) {
    (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(err, 'commercial');
  }
};
/**
 * Initialise Permutive user segmentation - reads data stored by third-party-tags permutive script for ad targeting
 * https://permutive.com/audience-platform/publishers/
 * @returns Promise
 */
var initPermutiveSegmentation = () => {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'Initialising Permutive segmentation');
  /* eslint-disable -- permutive code */
  // From here until we re-enable eslint is the Permutive code
  // that we received from them.
  // Please do not change unless you've consulted with Permutive
  // and confirmed the change is safe.
  (function (n, e, o, r, i) {
    if (!e) {
      e = e || {}, window.permutive = e, e.q = [], e.config = i || {}, e.config.projectId = o, e.config.apiKey = r, e.config.environment = e.config.environment || 'production';
      for (var t = ['addon', 'identify', 'track', 'trigger', 'query', 'segment', 'segments', 'ready', 'on', 'once', 'user', 'consent'], c = 0; c < t.length; c++) {
        var f = t[c];
        // @ts-expect-error -- best not to change this code from permutive
        e[f] = function (n) {
          return function () {
            var o = Array.prototype.slice.call(arguments, 0);
            // @ts-expect-error -- best not to change this code from permutive
            e.q.push({
              functionName: n,
              arguments: o
            });
          };
        }(f);
      }
    }
  })(document, window.permutive, 'd6691a17-6fdb-4d26-85d6-b3dd27f55f08', '359ba275-5edd-4756-84f8-21a24369ce0b', {});
  // This is our code, but not re-enabling ESLint because we'd have to disable it for both following lines anyway
  window.googletag = window.googletag || {};
  // @ts-expect-error -- this is a stub
  window.googletag.cmd = window.googletag.cmd || [];
  /* eslint-enable */
  window.googletag.cmd.push(() => {
    if (window.googletag.pubads().getTargeting('permutive').length === 0) {
      var g = window.localStorage.getItem('_pdfps');
      window.googletag.pubads().setTargeting('permutive', g ? JSON.parse(g) : []);
    }
  });
  var permutiveConfig = {
    user: window.guardian.config.user,
    page: window.guardian.config.page,
    ophan: window.guardian.config.ophan
  };
  runPermutive(permutiveConfig, window.permutive);
};
var initPermutive = () => {
  if (window.guardian.config.switches.permutive) {
    void initPermutiveSegmentation();
  }
  return Promise.resolve();
};
var _ = {
  isEmpty,
  removeEmpty,
  generatePayload,
  generatePermutiveIdentities,
  runPermutive
};

/***/ }),

/***/ "./src/init/consented/prepare-prebid.ts":
/*!**********************************************!*\
  !*** ./src/init/consented/prepare-prebid.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init),
/* harmony export */   setupPrebidOnce: () => (/* binding */ setupPrebidOnce)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/once.js");
/* harmony import */ var _experiments_ab__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../experiments/ab */ "./src/experiments/ab.ts");
/* harmony import */ var _experiments_tests_prebid946__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../experiments/tests/prebid946 */ "./src/experiments/tests/prebid946.ts");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_detect_detect_google_proxy__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../lib/detect/detect-google-proxy */ "./src/lib/detect/detect-google-proxy.ts");
/* harmony import */ var _lib_header_bidding_prebid_prebid__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../lib/header-bidding/prebid/prebid */ "./src/lib/header-bidding/prebid/prebid.ts");
/* harmony import */ var _lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../lib/header-bidding/utils */ "./src/lib/header-bidding/utils.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }









var shouldLoadPrebid = () => !(0,_lib_detect_detect_google_proxy__WEBPACK_IMPORTED_MODULE_7__.isGoogleProxy)() && window.guardian.config.switches.prebidHeaderBidding && _lib_commercial_features__WEBPACK_IMPORTED_MODULE_6__.commercialFeatures.shouldLoadGoogletag && !_lib_commercial_features__WEBPACK_IMPORTED_MODULE_6__.commercialFeatures.adFree && !window.guardian.config.page.hasPageSkin && !_lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_9__.shouldIncludeOnlyA9 && !(0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInCanada)();
var shouldLoadPrebid946 = (0,_experiments_ab__WEBPACK_IMPORTED_MODULE_4__.isUserInVariant)(_experiments_tests_prebid946__WEBPACK_IMPORTED_MODULE_5__.prebid946, 'variant');
var loadPrebid = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (consentState) {
    if (shouldLoadPrebid()) {
      if (shouldLoadPrebid946) {
        yield Promise.all(/*! import() | Prebid@9.46.0.js */[__webpack_require__.e("vendors-node_modules_pnpm_prebid_js_9_27_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-e308f3"), __webpack_require__.e("vendors-node_modules_pnpm_prebid_js_9_46_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-add157"), __webpack_require__.e("src_lib_header-bidding_prebid_modules_analyticsAdapter_ts-src_lib_header-bidding_prebid_modul-2fc7bf"), __webpack_require__.e("Prebid@9.46.0.js")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../lib/header-bidding/prebid/pbjs-v9.46.0 */ "./src/lib/header-bidding/prebid/pbjs-v9.46.0.ts"));
      } else {
        yield Promise.all(/*! import() | Prebid.js */[__webpack_require__.e("vendors-node_modules_pnpm_prebid_js_9_27_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-e308f3"), __webpack_require__.e("vendors-node_modules_pnpm_prebid_js_9_27_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-009776"), __webpack_require__.e("src_lib_header-bidding_prebid_modules_analyticsAdapter_ts-src_lib_header-bidding_prebid_modul-2fc7bf"), __webpack_require__.e("Prebid.js")]).then(__webpack_require__.bind(__webpack_require__, /*! ../../lib/header-bidding/prebid/pbjs */ "./src/lib/header-bidding/prebid/pbjs.ts"));
      }
      _lib_header_bidding_prebid_prebid__WEBPACK_IMPORTED_MODULE_8__.prebid.initialise(window, consentState);
    }
  });
  return function loadPrebid(_x) {
    return _ref.apply(this, arguments);
  };
}();
var throwIfUnconsented = hasConsentForPrebid => {
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', 'Prebid consent:', {
    hasConsentForPrebid
  });
  if (!hasConsentForPrebid) {
    throw new Error('No consent for prebid');
  }
};
var setupPrebid = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* () {
    var _consentState$aus, _consentState$usnat;
    try {
      var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.onConsent)();
      if (!consentState.framework) {
        throw new Error('Unknown framework');
      }
      switch (consentState.framework) {
        case 'aus':
          throwIfUnconsented(!!((_consentState$aus = consentState.aus) !== null && _consentState$aus !== void 0 && _consentState$aus.personalisedAdvertising));
          break;
        case 'usnat':
          throwIfUnconsented(!((_consentState$usnat = consentState.usnat) !== null && _consentState$usnat !== void 0 && _consentState$usnat.doNotSell));
          break;
        case 'tcfv2':
          // We do per-vendor checks for this framework, no requirement for a top-level check for Prebid
          break;
      }
      return loadPrebid(consentState);
    } catch (err) {
      var error = err;
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', '⚠️ Failed to execute prebid', error.message);
    }
  });
  return function setupPrebid() {
    return _ref2.apply(this, arguments);
  };
}();
var setupPrebidOnce = (0,lodash_es__WEBPACK_IMPORTED_MODULE_3__["default"])(setupPrebid);
/**
 * Initialise prebid - header bidding for display and video ads
 * https://docs.prebid.org/overview/intro.html
 * @returns Promise
 */
var init = () => setupPrebidOnce();
var _ = {
  setupPrebid
};

/***/ }),

/***/ "./src/init/consented/static-ad-slots.ts":
/*!***********************************************!*\
  !*** ./src/init/consented/static-ad-slots.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fillStaticAdvertSlots: () => (/* binding */ fillStaticAdvertSlots)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isNonNullable/isNonNullable.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _define_create_advert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../define/create-advert */ "./src/define/create-advert.ts");
/* harmony import */ var _display_display_ads__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../display/display-ads */ "./src/display/display-ads.ts");
/* harmony import */ var _display_display_lazy_ads__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../display/display-lazy-ads */ "./src/display/display-lazy-ads.ts");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../lib/dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");
/* harmony import */ var _lib_dfp_queue_advert__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ../../lib/dfp/queue-advert */ "./src/lib/dfp/queue-advert.ts");
/* harmony import */ var _prepare_prebid__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./prepare-prebid */ "./src/init/consented/prepare-prebid.ts");
/* harmony import */ var _remove_slots__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./remove-slots */ "./src/init/consented/remove-slots.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }












var decideAdditionalSizes = adSlot => {
  var {
    contentType
  } = window.guardian.config.page;
  var {
    name
  } = adSlot.dataset;
  if (contentType === 'Gallery' && name !== null && name !== void 0 && name.includes('inline')) {
    return {
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.billboard, (0,_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.createAdSize)(900, 250)]
    };
  }
  if (contentType === 'LiveBlog' && name !== null && name !== void 0 && name.includes('inline')) {
    return {
      phablet: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop],
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop]
    };
  }
  if (name === 'article-end' && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_1__.isInUsa)()) {
    return {
      mobile: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.fluid]
    };
  }
  return {};
};
/**
 * Static ad slots that were rendered on the page by the server are collected here.
 *
 * For dynamic ad slots that are created at runtime, see:
 *  - article-body-adverts
 *  - high-merch
 */
var fillStaticAdvertSlots = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    // This module has the following strict dependencies. These dependencies must be
    // fulfilled before this function can execute reliably. The bootstrap
    // initiates these dependencies, to speed up the init process. Bootstrap also captures the module performance.
    var dependencies = [(0,_remove_slots__WEBPACK_IMPORTED_MODULE_12__.removeDisabledSlots)()];
    yield Promise.all(dependencies);
    // Prebid might not load if it does not have consent
    // TODO: use Promise.allSettled, once we have Node 12
    yield (0,_prepare_prebid__WEBPACK_IMPORTED_MODULE_11__.setupPrebidOnce)().catch(reason => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', 'could not load Prebid.js', reason));
    // Quit if ad-free
    if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_7__.commercialFeatures.adFree) {
      return Promise.resolve();
    }
    var isDCRMobile = window.guardian.config.isDotcomRendering && (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_8__.getCurrentBreakpoint)() === 'mobile';
    // Get all ad slots
    var adverts = [...document.querySelectorAll(_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_9__.dfpEnv.adSlotSelector)].filter(adSlot => !_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_9__.dfpEnv.adverts.has(adSlot.id))
    // TODO: find cleaner workaround
    // we need to not init top-above-nav on mobile view in DCR
    // as the DOM element needs to be removed and replaced to be inline
    // refer to: 3562dc07-78e9-4507-b922-78b979d4c5cb
    .filter(adSlot => !(isDCRMobile && adSlot.id === 'dfp-ad--top-above-nav')).map(adSlot => {
      var additionalSizes = decideAdditionalSizes(adSlot);
      return (0,_define_create_advert__WEBPACK_IMPORTED_MODULE_4__.createAdvert)(adSlot, additionalSizes);
    }).filter(_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.isNonNullable);
    for (var advert of adverts) {
      _lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_9__.dfpEnv.adverts.set(advert.id, advert);
    }
    adverts.forEach(_lib_dfp_queue_advert__WEBPACK_IMPORTED_MODULE_10__.queueAdvert);
    if (_lib_dfp_dfp_env__WEBPACK_IMPORTED_MODULE_9__.dfpEnv.shouldLazyLoad()) {
      (0,_display_display_lazy_ads__WEBPACK_IMPORTED_MODULE_6__.displayLazyAds)();
    } else {
      (0,_display_display_ads__WEBPACK_IMPORTED_MODULE_5__.displayAds)();
    }
  });
  return function fillStaticAdvertSlots() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/init/consented/third-party-tags.ts":
/*!************************************************!*\
  !*** ./src/init/consented/third-party-tags.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _lib_third_party_tags_admiral__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/third-party-tags/admiral */ "./src/lib/third-party-tags/admiral.ts");
/* harmony import */ var _lib_third_party_tags_ias__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/third-party-tags/ias */ "./src/lib/third-party-tags/ias.ts");
/* harmony import */ var _lib_third_party_tags_imr_worldwide__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/third-party-tags/imr-worldwide */ "./src/lib/third-party-tags/imr-worldwide.ts");
/* harmony import */ var _lib_third_party_tags_imr_worldwide_legacy__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../lib/third-party-tags/imr-worldwide-legacy */ "./src/lib/third-party-tags/imr-worldwide-legacy.ts");
/* harmony import */ var _lib_third_party_tags_inizio__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../../lib/third-party-tags/inizio */ "./src/lib/third-party-tags/inizio.ts");
/* harmony import */ var _lib_third_party_tags_permutive__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../lib/third-party-tags/permutive */ "./src/lib/third-party-tags/permutive.ts");
/* harmony import */ var _lib_third_party_tags_remarketing__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../../lib/third-party-tags/remarketing */ "./src/lib/third-party-tags/remarketing.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
/* A regionalised container for all the commercial tags. */










var createTagScript = tag => {
  var _tag$onLoad;
  var script = document.createElement('script');
  if (typeof tag.url !== 'undefined') {
    script.src = tag.url;
  }
  // script.onload cannot be undefined
  script.onload = (_tag$onLoad = tag.onLoad) !== null && _tag$onLoad !== void 0 ? _tag$onLoad : null;
  if (tag.async === true) {
    script.setAttribute('async', '');
  }
  if (tag.attrs) {
    tag.attrs.forEach(attr => {
      script.setAttribute(attr.name, attr.value);
    });
  }
  return script;
};
var addScripts = tags => {
  var ref = document.scripts[0];
  var frag = document.createDocumentFragment();
  var hasScriptsToInsert = false;
  tags.forEach(tag => {
    var _tag$beforeLoad;
    if (tag.loaded === true) return;
    (_tag$beforeLoad = tag.beforeLoad) === null || _tag$beforeLoad === void 0 || _tag$beforeLoad.call(tag);
    // Tag is either an image, a snippet or a script.
    if (tag.useImage === true && typeof tag.url !== 'undefined') {
      new Image().src = tag.url;
    } else if (tag.insertSnippet) {
      tag.insertSnippet();
    } else {
      hasScriptsToInsert = true;
      var script = createTagScript(tag);
      frag.appendChild(script);
    }
    tag.loaded = true;
  });
  // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- false positive
  if (hasScriptsToInsert) {
    return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
      if (ref !== null && ref !== void 0 && ref.parentNode) {
        ref.parentNode.insertBefore(frag, ref);
      }
    });
  }
  return Promise.resolve();
};
var insertScripts = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (advertisingServices, performanceServices) {
    void addScripts(performanceServices);
    var consentState = yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.onConsent)();
    var consentedAdvertisingServices = advertisingServices.filter(script => {
      if (script.name === undefined) return false;
      return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getConsentFor)(script.name, consentState);
    });
    if (consentedAdvertisingServices.length > 0) {
      void addScripts(consentedAdvertisingServices);
    }
  });
  return function insertScripts(_x, _x2) {
    return _ref.apply(this, arguments);
  };
}();
var loadOther = () => {
  var _window$guardian$conf, _window$guardian$conf2, _window$guardian$conf3;
  var advertisingServices = [(0,_lib_third_party_tags_remarketing__WEBPACK_IMPORTED_MODULE_9__.remarketing)({
    shouldRun: (_window$guardian$conf = window.guardian.config.switches.remarketing) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : false
  }), (0,_lib_third_party_tags_permutive__WEBPACK_IMPORTED_MODULE_8__.permutive)({
    shouldRun: (_window$guardian$conf2 = window.guardian.config.switches.permutive) !== null && _window$guardian$conf2 !== void 0 ? _window$guardian$conf2 : false
  }), _lib_third_party_tags_ias__WEBPACK_IMPORTED_MODULE_4__.ias, (0,_lib_third_party_tags_inizio__WEBPACK_IMPORTED_MODULE_7__.inizio)({
    shouldRun: (_window$guardian$conf3 = window.guardian.config.switches.inizio) !== null && _window$guardian$conf3 !== void 0 ? _window$guardian$conf3 : false
  }), _lib_third_party_tags_admiral__WEBPACK_IMPORTED_MODULE_3__.admiralTag].filter(_ => _.shouldRun);
  var performanceServices = [
  // a.k.a Nielsen Online - provides measurement and analysis of online audiences,
  // advertising, video, consumer-generated media, word of mouth, commerce and consumer behavior.
  _lib_third_party_tags_imr_worldwide__WEBPACK_IMPORTED_MODULE_5__.imrWorldwide,
  // only in AU & NZ
  _lib_third_party_tags_imr_worldwide_legacy__WEBPACK_IMPORTED_MODULE_6__.imrWorldwideLegacy // only in AU & NZ
  ].filter(_ => _.shouldRun);
  return insertScripts(advertisingServices, performanceServices);
};
var init = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* () {
    if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.thirdPartyTags) {
      void loadOther();
      return Promise.resolve(true);
    }
    return Promise.resolve(false);
  });
  return function init() {
    return _ref2.apply(this, arguments);
  };
}();

var _ = {
  insertScripts,
  loadOther
};

/***/ }),

/***/ "./src/insert/comments-expanded-advert.ts":
/*!************************************************!*\
  !*** ./src/insert/comments-expanded-advert.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initCommentsExpandedAdverts: () => (/* binding */ initCommentsExpandedAdverts)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_commercial_core_constants_ad_label_height__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/constants/ad-label-height */ "../core/src/constants/ad-label-height.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _events_empty_advert__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../events/empty-advert */ "./src/events/empty-advert.ts");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_detect_detect_viewport__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ../lib/detect/detect-viewport */ "./src/lib/detect/detect-viewport.ts");
/* harmony import */ var _lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../lib/dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }











var tallestCommentAd = _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.height + _guardian_commercial_core_constants_ad_label_height__WEBPACK_IMPORTED_MODULE_1__.AD_LABEL_HEIGHT;
var tallestCommentsExpandedAd = _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.halfPage.height + _guardian_commercial_core_constants_ad_label_height__WEBPACK_IMPORTED_MODULE_1__.AD_LABEL_HEIGHT;
var insertAd = anchor => {
  var slot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_5__.createAdSlot)('comments-expanded', {
    classes: 'comments-expanded'
  });
  var adSlotContainer = document.createElement('div');
  adSlotContainer.className = 'ad-slot-container';
  adSlotContainer.style.position = 'sticky';
  adSlotContainer.style.top = '0';
  adSlotContainer.appendChild(slot);
  var stickyContainer = document.createElement('div');
  stickyContainer.style.flexGrow = '1';
  stickyContainer.appendChild(adSlotContainer);
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', 'Inserting comments-expanded advert');
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].mutate(() => {
    anchor.appendChild(adSlotContainer);
  }).then(() => (0,_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_10__.fillDynamicAdSlot)(slot, false));
};
var insertAdMobile = (anchor, id) => {
  var slot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_5__.createAdSlot)('comments-expanded', {
    name: "comments-expanded-".concat(id),
    classes: 'comments-expanded'
  });
  slot.style.minHeight = "".concat(_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.height + _guardian_commercial_core_constants_ad_label_height__WEBPACK_IMPORTED_MODULE_1__.AD_LABEL_HEIGHT, "px");
  var adSlotContainer = document.createElement('div');
  adSlotContainer.className = 'ad-slot-container';
  adSlotContainer.style.width = '300px';
  adSlotContainer.style.margin = '20px auto';
  adSlotContainer.appendChild(slot);
  var listElement = document.createElement('li');
  listElement.appendChild(adSlotContainer);
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', "Inserting mobile comments-expanded-".concat(id, " advert"));
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].mutate(() => {
    anchor.after(listElement);
  }).then(() => (0,_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_10__.fillDynamicAdSlot)(slot, false));
};
var getRightColumn = () => {
  var selector = window.guardian.config.isDotcomRendering ? '.commentsRightColumn' : '.js-discussion__ad-slot';
  var rightColumn = document.querySelector(selector);
  if (!rightColumn) throw new Error('Could not find right column.');
  return rightColumn;
};
var getCommentsColumn = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].measure(() => {
      var commentsColumn = document.querySelector('[data-commercial-id="comments-column"]');
      if (!commentsColumn) throw new Error('Comments are not expanded.');
      return commentsColumn;
    });
  });
  return function getCommentsColumn() {
    return _ref.apply(this, arguments);
  };
}();
var isEnoughSpaceForAd = rightColumnNode => {
  // Only insert a second advert into the right-hand column if there is enough space.
  // There is enough space if the right-hand column is larger than:
  // (the largest possible heights of both adverts) + (the gap between the two adverts)
  var minHeightToPlaceAd = tallestCommentAd + tallestCommentsExpandedAd + window.innerHeight;
  return rightColumnNode.offsetHeight >= minHeightToPlaceAd;
};
var isEnoughCommentsForAd = commentsColumn => commentsColumn.childElementCount >= 5;
var commentsExpandedAdsAlreadyExist = () => {
  var commentsExpandedAds = document.querySelectorAll('.ad-slot--comments-expanded');
  return commentsExpandedAds.length > 0 ? true : false;
};
var removeMobileCommentsExpandedAds = () => {
  var currentBreakpoint = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_6__.getBreakpoint)((0,_lib_detect_detect_viewport__WEBPACK_IMPORTED_MODULE_7__.getViewport)().width);
  if (currentBreakpoint !== 'mobile') {
    return Promise.resolve();
  }
  var commentsExpandedAds = document.querySelectorAll('.ad-slot--comments-expanded');
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_9__["default"].mutate(() => commentsExpandedAds.forEach(node => {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', "Removing ad slot: ".concat(node.id));
    var advert = (0,_lib_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_8__.getAdvertById)(node.id);
    if (advert) {
      (0,_events_empty_advert__WEBPACK_IMPORTED_MODULE_3__.emptyAdvert)(advert);
    }
  }));
};
var handleCommentsLoadedEvent = () => {
  var rightColumnNode = getRightColumn();
  if (isEnoughSpaceForAd(rightColumnNode)) {
    void insertAd(rightColumnNode);
  }
};
var handleCommentsLoadedMobileEvent = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* () {
    var commentsColumn = yield getCommentsColumn();
    // On frontend-rendered pages, there is a merchandising-high ad below the comments ad.
    // We want a sufficient amount of content between these two ads.
    var isDcr = window.guardian.config.isDotcomRendering;
    var minCommentsBelowAd = isDcr ? 1 : 3;
    if (isEnoughCommentsForAd(commentsColumn) && !commentsExpandedAdsAlreadyExist()) {
      var counter = 0;
      for (var i = 0; i < commentsColumn.childElementCount; i++) {
        if (commentsColumn.children[i] && (i - 3) % 5 === 0 &&
        // The fourth comment and then every fifth comment
        i + minCommentsBelowAd < commentsColumn.childElementCount) {
          counter++;
          var childElement = commentsColumn.children[i];
          void insertAdMobile(childElement, counter);
        }
      }
    }
  });
  return function handleCommentsLoadedMobileEvent() {
    return _ref2.apply(this, arguments);
  };
}();
var initCommentsExpandedAdverts = () => {
  if (!_lib_commercial_features__WEBPACK_IMPORTED_MODULE_4__.commercialFeatures.commentAdverts) {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.log)('commercial', 'Adverts in comments are disabled in commercialFeatures');
    return Promise.resolve();
  }
  document.addEventListener('comments-loaded', () => {
    var currentBreakpoint = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_6__.getBreakpoint)((0,_lib_detect_detect_viewport__WEBPACK_IMPORTED_MODULE_7__.getViewport)().width);
    if (currentBreakpoint === 'mobile') {
      void handleCommentsLoadedMobileEvent();
    } else {
      void handleCommentsLoadedEvent();
    }
  });
  /**
   * If the page of comments is changed, or the ordering is updated, etc,
   * we need to remove the existing slots and create new slots.
   */
  document.addEventListener('comments-state-change', () => {
    void removeMobileCommentsExpandedAds();
  });
  return Promise.resolve();
};

/***/ }),

/***/ "./src/insert/fixures.ts":
/*!*******************************!*\
  !*** ./src/insert/fixures.ts ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_constants_index__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/constants/index */ "../core/src/constants/index.ts");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_detect_detect_viewport__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../lib/detect/detect-viewport */ "./src/lib/detect/detect-viewport.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");







var LARGEST_AD_SIZE = 600; // px, double mpu
var SPACING = 10; // px, above ad
var insertFootballRightAd = anchor => {
  var slot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.createAdSlot)('football-right');
  var container = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_2__.wrapSlotInContainer)(slot, {
    className: 'ad-slot-container football-right-ad-container'
  });
  /**
   * TODO: Move these to a class in frontend
   */
  container.style.position = 'sticky';
  container.style.top = '0';
  container.style.marginTop = '10px';
  void _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__["default"].mutate(() => {
    anchor.style.height = '100%';
    anchor.appendChild(container);
  }).then(() => (0,_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_6__.fillDynamicAdSlot)(slot, false));
};
/**
 * Inserts an advert on certain football fixtures/results/tables
 * pages in the right column.
 */
var init = () => {
  var _anchor$parentElement;
  if (window.guardian.config.isDotcomRendering) {
    return Promise.resolve();
  }
  var currentBreakpoint = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__.getBreakpoint)((0,_lib_detect_detect_viewport__WEBPACK_IMPORTED_MODULE_4__.getViewport)().width);
  if (currentBreakpoint !== 'desktop' && currentBreakpoint !== 'wide') {
    return Promise.resolve();
  }
  if (!_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.footballFixturesAdverts) {
    return Promise.resolve();
  }
  /**
   * On Football pages, this right-hand column exists in the DOM but does not
   * appear to be used. Can we use it for an advert?
   */
  var anchor = document.querySelector('.content__secondary-column');
  var minSpaceForAd = LARGEST_AD_SIZE + _guardian_commercial_core_constants_index__WEBPACK_IMPORTED_MODULE_0__.AD_LABEL_HEIGHT + SPACING;
  if (anchor === null || (_anchor$parentElement = anchor.parentElement) !== null && _anchor$parentElement !== void 0 && _anchor$parentElement.offsetHeight && anchor.parentElement.offsetHeight < minSpaceForAd) {
    return Promise.resolve();
  }
  insertFootballRightAd(anchor);
  return Promise.resolve();
};

/***/ }),

/***/ "./src/insert/high-merch.ts":
/*!**********************************!*\
  !*** ./src/insert/high-merch.ts ***!
  \**********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");



/**
 * Initialise merchandising-high ad slot on Frontend rendered content
 *
 * On DCR, these ad slots are server side rendered
 *
 * Revisit whether this code is needed once galleries have been migrated to DCR
 */
var init = () => {
  if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_0__.commercialFeatures.highMerch) {
    var anchorSelector = window.guardian.config.page.commentable ? '#comments + *' : '.content-footer > :first-child';
    var anchor = document.querySelector(anchorSelector);
    var slot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__.createAdSlot)('merchandising-high');
    var container = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_1__.wrapSlotInContainer)(slot, {
      className: 'fc-container fc-container--commercial'
    });
    // Remove this once new `ad-slot-container--centre-slot` class is in place
    container.style.display = 'flex';
    container.style.justifyContent = 'center';
    // \Remove this
    return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_2__["default"].mutate(() => {
      if (anchor !== null && anchor !== void 0 && anchor.parentNode) {
        anchor.parentNode.insertBefore(container, anchor);
      }
    });
  }
  return Promise.resolve();
};

/***/ }),

/***/ "./src/insert/mobile-sticky.ts":
/*!*************************************!*\
  !*** ./src/insert/mobile-sticky.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/header-bidding/utils */ "./src/lib/header-bidding/utils.ts");
/* harmony import */ var _fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");




var createAdWrapperClassic = () => {
  var wrapper = document.createElement('div');
  wrapper.className = 'mobilesticky-container';
  var adSlot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_0__.createAdSlot)('mobile-sticky', {});
  wrapper.appendChild(adSlot);
  return wrapper;
};
var createAdWrapperDCR = () => {
  var wrapper = document.querySelector('.mobilesticky-container');
  if (wrapper) {
    var adSlot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_0__.createAdSlot)('mobile-sticky', {});
    wrapper.appendChild(adSlot);
  }
  return wrapper;
};
var createAdWrapper = () => {
  if (!window.guardian.config.isDotcomRendering) {
    return createAdWrapperClassic();
  }
  return createAdWrapperDCR();
};
/**
 * Initialise mobile sticky ad slot
 * @returns Promise
 */
var init = () => {
  if ((0,_lib_header_bidding_utils__WEBPACK_IMPORTED_MODULE_2__.shouldIncludeMobileSticky)()) {
    var mobileStickyWrapper = createAdWrapper();
    return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_1__["default"].mutate(() => {
      // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- Is body really always defined?
      if (document.body && mobileStickyWrapper) {
        document.body.appendChild(mobileStickyWrapper);
      }
    }).then(() => {
      if (mobileStickyWrapper) {
        var mobileStickyAdSlot = mobileStickyWrapper.querySelector('#dfp-ad--mobile-sticky');
        if (mobileStickyAdSlot) {
          void (0,_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_3__.fillDynamicAdSlot)(mobileStickyAdSlot, true);
        }
      }
    });
  }
  return Promise.resolve();
};

/***/ }),

/***/ "./src/insert/spacefinder/liveblog-adverts.ts":
/*!****************************************************!*\
  !*** ./src/insert/spacefinder/liveblog-adverts.ts ***!
  \****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../fill-dynamic-advert-slot */ "./src/insert/fill-dynamic-advert-slot.ts");
/* harmony import */ var _space_filler__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./space-filler */ "./src/insert/spacefinder/space-filler.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }








/**
 * Maximum number of inline ads to display on the page
 */
var MAX_ADS = 8;
/**
 * Multiplier of screen height that determines the minimum distance between any two ads
 */
var AD_GAP_MULTIPLIER = 1.5;
var AD_COUNTER = 0;
var getSlotName = (isMobile, slotCounter) => {
  if (isMobile) {
    return slotCounter === 0 ? 'top-above-nav' : "inline".concat(slotCounter);
  }
  return "inline".concat(slotCounter + 1);
};
var insertAdAtPara = para => {
  var isMobile = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_4__.getCurrentBreakpoint)() === 'mobile';
  var container = document.createElement('div');
  container.className = "ad-slot-container ad-slot-".concat(isMobile ? 'mobile' : 'desktop');
  var ad = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_3__.createAdSlot)('inline', {
    name: getSlotName(isMobile, AD_COUNTER),
    classes: "liveblog-inline".concat(isMobile ? '--mobile' : '')
  });
  container.appendChild(ad);
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__["default"].mutate(() => {
    if (para.parentNode) {
      /* ads are inserted after the block on liveblogs */
      para.parentNode.insertBefore(container, para.nextSibling);
    }
  }).then(/*#__PURE__*/_asyncToGenerator(function* () {
    return (0,_fill_dynamic_advert_slot__WEBPACK_IMPORTED_MODULE_6__.fillDynamicAdSlot)(ad, false, {
      phablet: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop],
      desktop: [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamGoogleDesktop]
    });
  }));
};
var insertAds = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* (paras) {
    var fastdomPromises = [];
    for (var i = 0; i < paras.length && AD_COUNTER < MAX_ADS; i += 1) {
      var para = paras[i];
      if (para !== null && para !== void 0 && para.parentNode) {
        var result = insertAdAtPara(para);
        fastdomPromises.push(result);
        AD_COUNTER += 1;
      }
    }
    yield Promise.all(fastdomPromises);
  });
  return function insertAds(_x) {
    return _ref2.apply(this, arguments);
  };
}();
var fillSpace = rules => {
  var options = {
    pass: 'inline1'
  };
  return _space_filler__WEBPACK_IMPORTED_MODULE_7__.spaceFiller.fillSpace(rules, insertAds, options);
};
var shouldInsertAd = (blockAboveAd, candidateBlock, windowHeight) => Math.abs(blockAboveAd.bottom - candidateBlock.bottom) > windowHeight * AD_GAP_MULTIPLIER;
var getSpaceFillerRules = (startBlock, windowHeight) => {
  // This is always the content block above the highest inline ad slot on the page.
  // When a new ad slot is inserted, this will become the first content block above it.
  var prevSlot;
  var filterSlot = slot => {
    if (!prevSlot) {
      prevSlot = slot;
      return false;
    }
    if (shouldInsertAd(prevSlot, slot, windowHeight)) {
      prevSlot = slot;
      return true;
    }
    return false;
  };
  return {
    bodySelector: '.js-liveblog-body',
    candidateSelector: ':scope > .block',
    fromBottom: true,
    startAt: startBlock,
    absoluteMinDistanceFromTop: 0,
    minDistanceFromTop: 0,
    minDistanceFromBottom: 0,
    clearContentMeta: 0,
    opponentSelectorRules: {},
    filter: filterSlot
  };
};
/**
 * Recursively looks at the next highest element
 * in the page until we find a content block.
 *
 * We cannot be sure that the element above the ad slot is a content
 * block, as there may be other types of elements inserted into the page.
 */
var _getFirstContentBlockAboveAd = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator(function* (topAdvert) {
    var prevElement = topAdvert.previousElementSibling;
    if (prevElement === null) return null;
    if (prevElement.classList.contains('block')) {
      return prevElement;
    }
    return _getFirstContentBlockAboveAd(prevElement);
  });
  return function getFirstContentBlockAboveAd(_x2) {
    return _ref3.apply(this, arguments);
  };
}();
var getLowestContentBlock = /*#__PURE__*/function () {
  var _ref4 = _asyncToGenerator(function* () {
    return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__["default"].measure(() => {
      var _allBlocks;
      var allBlocks = document.querySelectorAll('.js-liveblog-body > .block');
      return (_allBlocks = allBlocks[allBlocks.length - 1]) !== null && _allBlocks !== void 0 ? _allBlocks : null;
    });
  });
  return function getLowestContentBlock() {
    return _ref4.apply(this, arguments);
  };
}();
/**
 * Finds the content block to start with when using Spacefinder.
 *
 * Spacefinder will iterate through blocks looking for spaces to
 * insert ads, so we need to tell it where to start.
 */
var getStartingContentBlock = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator(function* (slotSelector) {
    var topAdvert = document.querySelector(".js-liveblog-body > ".concat(slotSelector));
    if (topAdvert === null) {
      return yield getLowestContentBlock();
    }
    return _getFirstContentBlockAboveAd(topAdvert);
  });
  return function getStartingContentBlock(_x3) {
    return _ref5.apply(this, arguments);
  };
}();
var lookForSpacesForAdSlots = /*#__PURE__*/function () {
  var _ref6 = _asyncToGenerator(function* () {
    var isMobile = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_4__.getCurrentBreakpoint)() === 'mobile';
    var slotSelector = ".ad-slot-container.ad-slot-".concat(isMobile ? 'mobile' : 'desktop');
    return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__["default"].measure(() => {
      var numSlots = document.querySelectorAll(slotSelector).length;
      if (numSlots >= MAX_ADS) {
        throw new Error('Cannot insert any more inline ads. At ad slot limit.');
      }
      AD_COUNTER = numSlots;
    }).then(/*#__PURE__*/_asyncToGenerator(function* () {
      var startContentBlock = yield getStartingContentBlock(slotSelector);
      if (!startContentBlock) {
        throw new Error('Cannot insert new inline ads. Cannot find a content block to start searching');
      }
      return startContentBlock;
    })).then(startContentBlock => {
      return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_5__["default"].measure(() => document.documentElement.clientHeight).then(windowHeight => getSpaceFillerRules(startContentBlock, windowHeight)).then(fillSpace);
    }).catch(error => {
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', error);
    });
  });
  return function lookForSpacesForAdSlots() {
    return _ref6.apply(this, arguments);
  };
}();
var startListening = () => {
  // eslint-disable-next-line no-use-before-define -- circular reference
  document.addEventListener('liveblog:blocks-updated', onUpdate);
};
var stopListening = () => {
  // eslint-disable-next-line no-use-before-define -- circular reference
  document.removeEventListener('liveblog:blocks-updated', onUpdate);
};
var onUpdate = () => {
  stopListening();
  void lookForSpacesForAdSlots();
};
/**
 * Inserts inline ad slots between new content
 * blocks when they are pushed to the page.
 */
var init = () => {
  if (_lib_commercial_features__WEBPACK_IMPORTED_MODULE_2__.commercialFeatures.liveblogAdverts) {
    void startListening();
  }
  return Promise.resolve();
};
var _ = {
  getFirstContentBlockAboveAd: _getFirstContentBlockAboveAd,
  getLowestContentBlock,
  getSlotName,
  getStartingContentBlock
};

/***/ }),

/***/ "./src/lib/__vendor/a9-apstag.js":
/*!***************************************!*\
  !*** ./src/lib/__vendor/a9-apstag.js ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   a9Apstag: () => (/* binding */ a9Apstag)
/* harmony export */ });
/**
 * Load Amazon A9 library as {@link https://ams.amazon.com/webpublisher/uam/docs/web-integration-documentation/integration-guide/javascript-guide/display.html described here}
 */
var a9Apstag = () => {
  (function (a9, a, p, s, t, A, g) {
    if (a[a9]) return;
    function q(c, r) {
      a[a9]._Q.push([c, r]);
    }
    a[a9] = {
      init() {
        q('i', arguments);
      },
      fetchBids() {
        q('f', arguments);
      },
      setDisplayBids() {},
      targetingKeys() {
        return [];
      },
      _Q: []
    };
    A = p.createElement(s);
    A.async = !0;
    A.src = t;
    g = p.getElementsByTagName(s)[0];
    g.parentNode.insertBefore(A, g);
  })('apstag', window, document, 'script', '//c.amazon-adsystem.com/aax2/apstag.js');
};

/***/ }),

/***/ "./src/lib/ad-verification/prepare-ad-verification.ts":
/*!************************************************************!*\
  !*** ./src/lib/ad-verification/prepare-ad-verification.ts ***!
  \************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core */ "../core/src/index.ts");
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/loadScript/loadScript.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _display_load_advert__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../display/load-advert */ "./src/display/load-advert.ts");
/* harmony import */ var _dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _header_bidding_utils__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../header-bidding/utils */ "./src/lib/header-bidding/utils.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }






var errorHandler = error => {
  // Looks like some plugins block ad-verification
  // Avoid barraging Sentry with errors from these pageviews
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', 'Failed to load Confiant:', error);
};
var confiantRefreshedSlots = [];
var maybeRefreshBlockedSlotOnce = (blockingType, blockingId, isBlocked, wrapperId, tagId, impressionsData) => {
  var _impressionsData$preb, _impressionsData$dfp;
  var prebidSlotElementId = impressionsData === null || impressionsData === void 0 || (_impressionsData$preb = impressionsData.prebid) === null || _impressionsData$preb === void 0 ? void 0 : _impressionsData$preb.s;
  var dfpSlotElementId = impressionsData === null || impressionsData === void 0 || (_impressionsData$dfp = impressionsData.dfp) === null || _impressionsData$dfp === void 0 ? void 0 : _impressionsData$dfp.s;
  var blockedSlotPath = prebidSlotElementId !== null && prebidSlotElementId !== void 0 ? prebidSlotElementId : dfpSlotElementId;
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', "".concat(isBlocked ? '🚫 Blocked' : '🚨 Screened', " bad ad with Confiant"), {
    blockedSlotPath,
    blockingType,
    blockingId,
    wrapperId,
    tagId
  });
  // don’t run the logic if the ad is only screened
  if (!isBlocked || !blockedSlotPath) return;
  var advert = (0,_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_5__.getAdvertById)(blockedSlotPath);
  if (!advert) throw new Error("No slot found for ".concat(blockedSlotPath));
  var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_1__.EventTimer.get();
  eventTimer.mark("".concat((0,_header_bidding_utils__WEBPACK_IMPORTED_MODULE_6__.stripDfpAdPrefixFrom)(advert.id), "-blockedByConfiant"));
  void (0,_guardian_commercial_core__WEBPACK_IMPORTED_MODULE_0__.bypassCommercialMetricsSampling)();
  advert.slot.setTargeting('confiant', String(blockingType));
  // if the slot has already been refreshed, don’t do anything
  if (confiantRefreshedSlots.includes(blockedSlotPath)) return;
  // refresh the blocked slot to get new ad
  (0,_display_load_advert__WEBPACK_IMPORTED_MODULE_4__.refreshAdvert)(advert);
  // mark it as refreshed so it won’t refresh multiple time
  confiantRefreshedSlots.push(blockedSlotPath);
};
/**
 * Initialise Confiant - block bad ads
 * https://www.confiant.com/solutions/quality
 * @returns Promise
 */
var init = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var host = 'cdn.confiant-integrations.net';
    var id = '7oDgiTsq88US4rrBG0_Nxpafkrg';
    var remoteScriptUrl = "//".concat(host, "/").concat(id, "/gpt_and_prebid/config.js");
    if (window.guardian.config.switches.confiantAdVerification) {
      var _window$confiant;
      yield (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.loadScript)(remoteScriptUrl, {
        async: true
      }).catch(errorHandler);
      if (!((_window$confiant = window.confiant) !== null && _window$confiant !== void 0 && _window$confiant.settings)) return;
      if (window.location.hash === '#confiantDevMode') {
        window.confiant.settings.devMode = true;
      }
      window.confiant.settings.callback = maybeRefreshBlockedSlotOnce;
    }
    return;
  });
  return function init() {
    return _ref.apply(this, arguments);
  };
}();
var _ = {
  init,
  maybeRefreshBlockedSlotOnce,
  confiantRefreshedSlots
};

/***/ }),

/***/ "./src/lib/creatives/page-skin.ts":
/*!****************************************!*\
  !*** ./src/lib/creatives/page-skin.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   pageSkin: () => (/* binding */ pageSkin)
/* harmony export */ });
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! fastdom */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/fastdom.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(fastdom__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");



var pageSkin = () => {
  var bodyEl = document.body;
  var hasPageSkin = window.guardian.config.page.hasPageSkin;
  var isInAUEdition = window.guardian.config.page.edition.toLowerCase() === 'au';
  var adLabelHeight = 24;
  var topPosition = 0;
  var truskinRendered = false;
  var pageskinRendered = false;
  var togglePageSkinActiveClass = () => {
    fastdom__WEBPACK_IMPORTED_MODULE_0___default().mutate(() => {
      bodyEl.classList.toggle('has-active-pageskin', (0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__.matchesBreakpoints)({
        min: 'wide'
      }));
    });
  };
  var togglePageSkin = () => {
    if (hasPageSkin &&
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- needs to be investigated
    (0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__.hasCrossedBreakpoint)(true) && !_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.adFree) {
      togglePageSkinActiveClass();
    }
  };
  var moveBackgroundVerticalPosition = verticalPos => {
    bodyEl.style.backgroundPosition = "50% ".concat(verticalPos, "px");
  };
  var initTopPositionOnce = () => {
    if (topPosition === 0) {
      var navHeader = document.querySelector('.new-header');
      if (navHeader) {
        topPosition = truskinRendered ? navHeader.offsetTop + adLabelHeight : navHeader.offsetTop + navHeader.offsetHeight;
      }
    }
  };
  var shrinkElement = element => {
    var frontContainer = document.querySelector('.fc-container__inner');
    if (frontContainer) {
      element.style.cssText = "max-width: ".concat(frontContainer.clientWidth, "px; margin-right: auto; margin-left: auto;");
    }
  };
  var repositionTruskin = () => {
    var header = document.querySelector('.new-header');
    var footer = document.querySelector('.l-footer');
    var topBannerAd = document.querySelector('.ad-slot--top-banner-ad');
    if (header && footer && topBannerAd) {
      var topBannerAdContainer = document.querySelector('.top-banner-ad-container');
      if (topBannerAdContainer) {
        topBannerAdContainer.style.borderBottom = 'none';
        topBannerAdContainer.style.minHeight = '0';
      }
      initTopPositionOnce();
      shrinkElement(header);
      shrinkElement(footer);
      if (window.pageYOffset === 0) {
        moveBackgroundVerticalPosition(topPosition);
      }
      var headerBoundaries = header.getBoundingClientRect();
      var topBannerAdBoundaries = topBannerAd.getBoundingClientRect();
      var headerPosition = headerBoundaries.top;
      var topBannerBottom = topBannerAdBoundaries.bottom;
      var fabricScrollStartPosition = topBannerAdBoundaries.height + adLabelHeight - headerBoundaries.height;
      if (headerPosition <= fabricScrollStartPosition && topBannerBottom > 0) {
        moveBackgroundVerticalPosition(topBannerBottom);
      } else if (topBannerBottom <= 0) {
        moveBackgroundVerticalPosition(0);
      }
    }
  };
  var repositionPageSkin = () => {
    initTopPositionOnce();
    if (window.pageYOffset === 0) {
      moveBackgroundVerticalPosition(topPosition);
    } else if (window.pageXOffset <= topPosition) {
      moveBackgroundVerticalPosition(topPosition - window.pageYOffset);
    }
    if (window.pageYOffset > topPosition) {
      moveBackgroundVerticalPosition(0);
    }
  };
  var repositionSkins = () => {
    if (truskinRendered && hasPageSkin) {
      repositionTruskin();
    }
    // This is to reposition the Page Skin to start where the navigation header ends.
    if (pageskinRendered && hasPageSkin && isInAUEdition) {
      repositionPageSkin();
    }
  };
  togglePageSkin();
  window.addEventListener('message', event => {
    // This event is triggered by the commercial template: 'Skin for front pages'
    // Also found in: commercial-templates/src/page-skin/web/index.html
    if (event.data === 'pageskinRendered') {
      pageskinRendered = true;
      repositionSkins();
    }
    // This event is triggered by the commercial template: 'Truskin Template' to indicate the page skin is also a Truskin
    // Also found in: commercial-templates/src/truskin-page-skin/web/index.js
    if (event.data === 'truskinRendered') {
      truskinRendered = true;
      repositionSkins();
    }
  }, false);
};


/***/ }),

/***/ "./src/lib/detect/detect-google-proxy.ts":
/*!***********************************************!*\
  !*** ./src/lib/detect/detect-google-proxy.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isGoogleProxy: () => (/* binding */ isGoogleProxy)
/* harmony export */ });
/**
 * https://developers.google.com/search/docs/advanced/mobile/web-light
 */
var GOOGLE_WEB_LIGHT = 'googleweblight';
/**
 * This one is undocumented, not sure it actually exists.
 */
var GOOGLE_WEB_PREVIEW = 'Google Web Preview';
/**
 * Read more about Google Crawler here: https://developers.google.com/search/docs/advanced/crawling/overview-google-crawlers
 * @returns whether this is a Google Proxy
 */
var isGoogleProxy = () => Boolean(navigator.userAgent.includes(GOOGLE_WEB_PREVIEW) || navigator.userAgent.includes(GOOGLE_WEB_LIGHT));

/***/ }),

/***/ "./src/lib/dfp/non-refreshable-line-items.ts":
/*!***************************************************!*\
  !*** ./src/lib/dfp/non-refreshable-line-items.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   fetchNonRefreshableLineItemIds: () => (/* binding */ fetchNonRefreshableLineItemIds),
/* harmony export */   memoizedFetchNonRefreshableLineItemIds: () => (/* binding */ memoizedFetchNonRefreshableLineItemIds)
/* harmony export */ });
/* harmony import */ var lodash_es__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! lodash-es */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/memoize.js");
/* harmony import */ var _error_report_error__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../error/report-error */ "./src/lib/error/report-error.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var fetchNonRefreshableLineItemIds = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    // When the env is CODE or local, use the CODE env's non-refreshable line items file
    var {
      host,
      isProd
    } = window.guardian.config.page;
    var fileHost = isProd ? host : 'https://m.code.dev-theguardian.com';
    var fileLocation = new URL('/commercial/non-refreshable-line-items.json', fileHost);
    var response = yield fetch(fileLocation.toString());
    if (response.ok) {
      var json = yield response.json();
      if (!Array.isArray(json)) {
        throw Error('Failed to parse non-refreshable line items as an array');
      }
      // Throw an error if any of the elements in the array are not numbers
      var lineItemsOrError = json.reduce((accum, lineItemId) => !(accum instanceof Error) && typeof lineItemId === 'number' ? {
        lineItems: [...accum.lineItems, lineItemId]
      } : Error('Failed to parse element in non-refreshable line item array as number'), {
        lineItems: []
      });
      if (lineItemsOrError instanceof Error) {
        throw lineItemsOrError;
      }
      return lineItemsOrError.lineItems;
    }
    // Report an error to Sentry if we don't get an ok response
    // Note that in other cases (JSON parsing failure) we throw but don't report the error
    var error = Error('Failed to fetch non-refreshable line items');
    (0,_error_report_error__WEBPACK_IMPORTED_MODULE_1__.reportError)(error, 'commercial', {
      status: String(response.status)
    });
    throw error;
  });
  return function fetchNonRefreshableLineItemIds() {
    return _ref.apply(this, arguments);
  };
}();
var memoizedFetchNonRefreshableLineItemIds = (0,lodash_es__WEBPACK_IMPORTED_MODULE_0__["default"])(fetchNonRefreshableLineItemIds);

/***/ }),

/***/ "./src/lib/dfp/should-refresh.ts":
/*!***************************************!*\
  !*** ./src/lib/dfp/should-refresh.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   shouldRefresh: () => (/* binding */ shouldRefresh)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");

/**
 * Determine whether an advert should refresh, taking into account
 * its size, whether there's a pageskin or whether the advert's
 * line item is marked as non-refreshable
 *
 *  - Fluid ads should not refresh
 *  - Outstream ads should not refresh
 *  - Pageskins should not refresh
 *  - Ads that have line items marked as non-refreshable should not be
 * 	  refreshed. This information is retrieved via the non refreshable
 * 	  line item API endpoint
 *
 * @param advert The candidate advert to check
 * @param nonRefreshableLineItemIds The array of line item ids for which
 * adverts should not refresh
 */
var shouldRefresh = function (advert) {
  var _advert$size;
  var nonRefreshableLineItemIds = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : [];
  var sizeString = (_advert$size = advert.size) === null || _advert$size === void 0 ? void 0 : _advert$size.toString();
  // Do not refresh ads in slots labelled data-refresh="false"
  if (advert.node.dataset.refresh === 'false') {
    return false;
  }
  // Fluid adverts should not refresh
  var isFluid = sizeString === 'fluid';
  if (isFluid) return false;
  // Outstream adverts should not refresh
  var isOutstream = Object.values(_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.outstreamSizes).map(size => size.toString()).includes(sizeString);
  if (isOutstream) return false;
  // If the advert has a line item id included in the array of non refreshable
  // line item ids then it should not refresh
  var isNonRefreshableLineItem = advert.lineItemId && nonRefreshableLineItemIds.includes(advert.lineItemId);
  if (isNonRefreshableLineItem) return false;
  // If we have a pageskin then don't refresh
  if (window.guardian.config.page.hasPageSkin) return false;
  // If none of the other conditions are met then the advert should refresh
  return true;
};


/***/ }),

/***/ "./src/lib/gumgum-winning-bid.ts":
/*!***************************************!*\
  !*** ./src/lib/gumgum-winning-bid.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   logGumGumWinningBid: () => (/* binding */ logGumGumWinningBid)
/* harmony export */ });
var logGumGumWinningBid = (slotID, advertiserId) => {
  var endpoint = window.guardian.config.page.isDev ? '//logs.code.dev-guardianapis.com/log' : '//logs.guardianapis.com/log';
  if (!slotID || !advertiserId) {
    return;
  }
  void fetch(endpoint, {
    method: 'POST',
    body: JSON.stringify({
      label: 'commercial.gumgum.winningBid',
      properties: [{
        name: 'slotID',
        value: slotID
      }, {
        name: 'advertiserId',
        value: advertiserId
      }, {
        name: 'gumgumId',
        value: '1lsxjb4'
      }, {
        name: 'pageviewId',
        value: window.guardian.config.ophan.pageViewId
      }]
    }),
    keepalive: true,
    cache: 'no-store',
    mode: 'no-cors'
  });
};


/***/ }),

/***/ "./src/lib/messenger/disable-refresh.ts":
/*!**********************************************!*\
  !*** ./src/lib/messenger/disable-refresh.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _dfp_dfp_env__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../dfp/dfp-env */ "./src/lib/dfp/dfp-env.ts");

// This message is intended to be used with a DFP creative wrapper.
// For reference, the wrapper will post a message, with an iFrameId, like so:
/*
<script>
self.addEventListener('message', function onMessage(evt) {
    var json;
    try {
        json = JSON.parse(evt.data);
    } catch(_) { return; }

    var keys = Object.keys(json);
    if( keys.length < 2 || !keys.includes('id') || !keys.includes('host') ) return;

    window.parent.postMessage(JSON.stringify({
        type: 'disable-refresh',
        value: {},
        iframeId: json.id,
        id: 'aaaa0000-bb11-cc22-dd33-eeeeee444444'
    }), '*');

    self.removeEventListener('message', onMessage);
});
</script>
*/
var init = register => {
  register('disable-refresh', (specs, ret, iframe) => {
    if (iframe) {
      var adSlot = iframe.closest('.js-ad-slot');
      if (adSlot instanceof HTMLElement) {
        var advert = _dfp_dfp_env__WEBPACK_IMPORTED_MODULE_0__.dfpEnv.adverts.get(adSlot.id);
        if (advert) {
          advert.shouldRefresh = false;
        }
      }
    }
  });
};


/***/ }),

/***/ "./src/lib/messenger/full-width.ts":
/*!*****************************************!*\
  !*** ./src/lib/messenger/full-width.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isBoolean/isBoolean.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! fastdom */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/fastdom.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fastdom__WEBPACK_IMPORTED_MODULE_1__);


var fullWidth = (fullWidth, slotContainer) => fastdom__WEBPACK_IMPORTED_MODULE_1___default().mutate(() => {
  if (fullWidth) {
    slotContainer.classList.add('ad-slot--full-width');
  } else {
    slotContainer.classList.remove('ad-slot--full-width');
  }
});
var init = register => {
  register('full-width', (specs, ret, iframe) => {
    if (iframe && specs) {
      var _iframe$closest, _iframe$closest2;
      if (!(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isBoolean)(specs)) {
        return;
      }
      var adSlot = (_iframe$closest = iframe.closest('.js-ad-slot')) !== null && _iframe$closest !== void 0 ? _iframe$closest : undefined;
      // only allow for banner ads
      var name = adSlot === null || adSlot === void 0 ? void 0 : adSlot.dataset.name;
      if (!(name !== null && name !== void 0 && name.startsWith('fronts-banner')) || !adSlot) {
        return;
      }
      var slotContainer = (_iframe$closest2 = iframe.closest('.ad-slot-container')) !== null && _iframe$closest2 !== void 0 ? _iframe$closest2 : undefined;
      if (!slotContainer) {
        return;
      }
      return fullWidth(specs, slotContainer);
    }
  });
};
var _ = {
  fullWidth
};


/***/ }),

/***/ "./src/lib/messenger/get-page-targeting.ts":
/*!*************************************************!*\
  !*** ./src/lib/messenger/get-page-targeting.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/**
 * Register a listener for iframes to request shared ad targeting
 *
 * Allows for ads to be served into SafeFrame whilst retaining the ability to define a passback
 */
var init = register => {
  register('get-page-targeting', () => window.guardian.config.page.sharedAdTargeting);
};


/***/ }),

/***/ "./src/lib/messenger/get-page-url.ts":
/*!*******************************************!*\
  !*** ./src/lib/messenger/get-page-url.ts ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
var init = register => {
  register('get-page-url', () => window.location.origin + window.location.pathname);
};


/***/ }),

/***/ "./src/lib/messenger/get-stylesheet.ts":
/*!*********************************************!*\
  !*** ./src/lib/messenger/get-stylesheet.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");

var isStyleSpecs = specs => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isObject)(specs) && 'selector' in specs;
var getStyles = (specs, styleSheets) => {
  var result = [];
  for (var i = 0; i < styleSheets.length; i += 1) {
    var _styleSheets$i;
    var ownerNode = (_styleSheets$i = styleSheets[i]) === null || _styleSheets$i === void 0 ? void 0 : _styleSheets$i.ownerNode;
    if (ownerNode instanceof HTMLStyleElement && ownerNode.matches(specs.selector) && ownerNode.textContent !== null) {
      result.push(ownerNode.textContent);
    }
    /*
        There could be link elements here too, but we don't care about them as we cannot access the CSS
        text content in them anyway.
        This is due to the fact that they are on separate domains like `assets.guim.co.uk`, accessing the text
        from them results in a CORS error.
     */
  }
  return result;
};
var init = register => {
  register('get-styles', specs => {
    if (isStyleSpecs(specs)) {
      return getStyles(specs, document.styleSheets);
    }
  });
};
var _ = {
  getStyles,
  isStyleSpecs
};


/***/ }),

/***/ "./src/lib/messenger/measure-ad-load.ts":
/*!**********************************************!*\
  !*** ./src/lib/messenger/measure-ad-load.ts ***!
  \**********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/event-timer */ "../core/src/event-timer.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");


// This message is intended to be used with a GAM creative wrapper.
// For reference, the wrapper will post a message, like so:
/*
* <script  id='ad-load-%%CACHEBUSTER%%'>
//send postMessage to commercial bundle
const metaData = {
    slotId: '%%PATTERN:slot%%'
};
top.window.postMessage(JSON.stringify(
    {
        id: 'bf724866-723c-6b0a-e5d7-ad61535f98b7',
        slotId: '%%PATTERN:slot%%',
        type: 'measure-ad-load',
        value: metaData
    }
), '*');
</script>
* */
var getSlotId = specs => (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isObject)(specs) && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.isString)(specs.slotId) ? specs.slotId : undefined;
var eventTimer = _guardian_commercial_core_event_timer__WEBPACK_IMPORTED_MODULE_0__.EventTimer.get();
var init = register => {
  register('measure-ad-load', specs => {
    eventTimer.mark('adOnPage', getSlotId(specs));
    eventTimer.mark('fetchAdEnd', getSlotId(specs));
    eventTimer.mark('adRenderEnd', getSlotId(specs));
  });
};


/***/ }),

/***/ "./src/lib/messenger/passback-refresh.ts":
/*!***********************************************!*\
  !*** ./src/lib/messenger/passback-refresh.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _display_load_advert__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../display/load-advert */ "./src/display/load-advert.ts");
/* harmony import */ var _dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");



var ineligiblePassbacks = ['teadsdesktop', 'teadsmobile', 'teads'];
var passbackRefresh = (specs, adSlot) => {
  var advert = (0,_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_2__.getAdvertById)(adSlot.id);
  if (advert) {
    advert.slot.setTargeting('passback', specs);
    // passbacks with these values are not eligible for teads
    if (ineligiblePassbacks.includes(specs)) {
      advert.slot.setTargeting('teadsEligible', 'false');
    }
    (0,_display_load_advert__WEBPACK_IMPORTED_MODULE_1__.refreshAdvert)(advert);
  }
};
var init = register => {
  register('passback-refresh', (specs, _, iframe) => {
    if (iframe && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isString)(specs)) {
      var _iframe$closest;
      var adSlot = (_iframe$closest = iframe.closest('.js-ad-slot')) !== null && _iframe$closest !== void 0 ? _iframe$closest : undefined;
      if (!adSlot) {
        return;
      }
      return passbackRefresh(specs, adSlot);
    }
  });
};
var _ = {
  passbackRefresh
};


/***/ }),

/***/ "./src/lib/messenger/passback.ts":
/*!***************************************!*\
  !*** ./src/lib/messenger/passback.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/ad-sizes */ "../core/src/ad-sizes.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/source/foundations */ "../node_modules/.pnpm/@guardian+source@11.1.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/source/dist/foundations/__generated__/breakpoints.js");
/* harmony import */ var _detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _dfp_dfp_env_globals__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../dfp/dfp-env-globals */ "./src/lib/dfp/dfp-env-globals.ts");
/* harmony import */ var _dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../dfp/get-advert-by-id */ "./src/lib/dfp/get-advert-by-id.ts");
/* harmony import */ var _fastdom_promise__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../fastdom-promise */ "./src/lib/fastdom-promise.ts");







var adLabelHeight = 24;
/**
 * Passback size mappings
 * https://developers.google.com/publisher-tag/guides/ad-sizes#responsive_ads
 *
 * viewport height is set to 0 to denote any size from 0
 *
 * [
 *   [
 *     [ viewport1-width, viewport1-height],
 *     [ [slot1-width, slot1-height], [slot2-width, slot2-height], ... ]
 *   ]
 * ]
 *
 */
var mpu = [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.width, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mpu.height];
var outstreamDesktop = [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop.width, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop.height];
var outstreamMobile = [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamMobile.width, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamMobile.height];
var outstreamSizes = [mpu, outstreamMobile, outstreamDesktop];
var oustreamSizeMappings = [[[_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.phablet, 0], [mpu, outstreamDesktop]], [[_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.mobile, 0], [mpu, outstreamMobile]]];
var mobileSticky = [_guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mobilesticky.width, _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.mobilesticky.height];
var mobileStickySizes = [mobileSticky];
var mobileStickySizeMappings = [[[_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.mobile, 0], [mobileSticky]]];
var defaultSizeMappings = [[[_guardian_source_foundations__WEBPACK_IMPORTED_MODULE_2__.breakpoints.mobile, 0], [mpu]]];
var decideSizes = source => {
  if (source === 'teads') {
    return {
      sizes: outstreamSizes,
      sizeMappings: oustreamSizeMappings
    };
  }
  if (source === 'ogury') {
    return {
      sizes: mobileStickySizes,
      sizeMappings: mobileStickySizeMappings
    };
  }
  return {
    sizes: [mpu],
    sizeMappings: defaultSizeMappings
  };
};
var mapValues = (keys, valueFn) => keys.map(key => [key, valueFn(key)]);
var getPassbackValue = source => {
  var isMobile = (0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__.getCurrentBreakpoint)() === 'mobile';
  // e.g. 'teadsdesktop' or 'teadsmobile';
  return "".concat(source).concat(isMobile ? 'mobile' : 'desktop');
};
/**
 * A listener for 'passback' messages from ad slot iFrames
 * Ad providers will postMessage a 'passback' message to tell us they have not filled this slot
 * In which case we create a 'passback' slot to fulfil the slot with another ad
 *
 * More details:
 * https://github.com/guardian/frontend/pull/24724
 * https://github.com/guardian/frontend/pull/24903
 * https://github.com/guardian/frontend/pull/25008
 */
var init = register => {
  register('passback', (messagePayload, ret, iframe) => {
    window.googletag.cmd.push(() => {
      /**
       * Get the passback source from the incoming message
       */
      var {
        source
      } = messagePayload;
      if (!source) {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: postMessage does not have source set');
        return;
      }
      if (!iframe) {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: iframe has not been passed by messenger');
        return;
      }
      /**
       * Determine the slot from the calling iFrame as provided by messenger
       */
      var slotElement = iframe.closest('.ad-slot');
      var slotId = slotElement === null || slotElement === void 0 ? void 0 : slotElement.dataset.name;
      if (!slotId) {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: cannot determine the slot from the calling iFrame');
        return;
      }
      var slotIdWithPrefix = "".concat(_dfp_dfp_env_globals__WEBPACK_IMPORTED_MODULE_4__.adSlotIdPrefix).concat(slotId);
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Passback: from source '".concat(source, "' for slot '").concat(slotIdWithPrefix, "'"));
      var iFrameContainer = iframe.closest('.ad-slot__content');
      if (!iFrameContainer) {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: cannot determine the iFrameContainer from the calling iFrame');
        return;
      }
      /**
       * Keep the initial outstream iFrame so they can detect passbacks.
       * Maintain the iFrame initial size by setting visibility hidden to prevent CLS.
       * In a full width column we then just need to resize the height.
       */
      var updateInitialSlotPromise = _fastdom_promise__WEBPACK_IMPORTED_MODULE_6__["default"].mutate(() => {
        iFrameContainer.style.visibility = 'hidden';
        // Allows passback slot to position absolutely over the parent slot
        slotElement.style.position = 'relative';
        // Remove any outstream styling for the parent slot
        slotElement.classList.remove('ad-slot--outstream');
        // Prevent refreshing of the parent slot
        slotElement.setAttribute('data-refresh', 'false');
        var advert = (0,_dfp_get_advert_by_id__WEBPACK_IMPORTED_MODULE_5__.getAdvertById)(slotElement.id);
        if (advert) advert.shouldRefresh = false;
      });
      /**
       * Create a new passback ad slot element
       */
      var createNewSlotElementPromise = updateInitialSlotPromise.then(() => {
        var passbackElement = document.createElement('div');
        passbackElement.id = "".concat(slotIdWithPrefix, "--passback");
        passbackElement.classList.add('ad-slot', 'js-ad-slot');
        passbackElement.setAttribute('aria-hidden', 'true');
        // position absolute to position over the container slot
        passbackElement.style.position = 'absolute';
        // account for the ad label
        passbackElement.style.top = "".concat(adLabelHeight, "px");
        // take the full width so it will center horizontally
        passbackElement.style.width = '100%';
        return _fastdom_promise__WEBPACK_IMPORTED_MODULE_6__["default"].mutate(() => {
          slotElement.insertAdjacentElement('beforeend', passbackElement);
        }).then(() => passbackElement);
      });
      /**
       * Create and display the new passback slot
       */
      void createNewSlotElementPromise.then(passbackElement => {
        /**
         * Find the initial slot object from googletag
         */
        var initialSlot = window.googletag.pubads().getSlots().find(s => s.getSlotElementId() === slotIdWithPrefix);
        if (!initialSlot) {
          (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: cannot determine the googletag slot from the slotId');
          return;
        }
        /**
         * Copy the targeting from the initial slot
         */
        var pageTargeting = mapValues(window.googletag.pubads().getTargetingKeys(), key => window.googletag.pubads().getTargeting(key));
        var slotTargeting = mapValues(initialSlot.getTargetingKeys(), key => initialSlot.getTargeting(key));
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: initial slot targeting', Object.fromEntries([...pageTargeting, ...slotTargeting]));
        /**
         * Create the targeting for the new passback slot
         */
        var passbackTargeting = [...pageTargeting, ...slotTargeting, ['passback', [getPassbackValue(source)]], ['slot', [slotId]]];
        /**
         * Register a listener to adjust the container height once the
         * passback has loaded. We need to do this because the passback
         * ad is absolutely positioned in order to not cause layout shift.
         * So it is taken out of normal document flow and the parent container
         * does not take the height of the child ad element as normal.
         * We set the container height by adding a listener to the googletag
         * slotRenderEnded event which provides the size of the loaded ad.
         * https://developers.google.com/publisher-tag/reference#googletag.events.slotrenderendedevent
         */
        googletag.pubads().addEventListener('slotRenderEnded', function (event) {
          var slotId = event.slot.getSlotElementId();
          if (slotId === passbackElement.id) {
            var size = event.size;
            if (Array.isArray(size) && size[1]) {
              var adHeight = size[1];
              (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Passback: ad height is ".concat(adHeight));
              void _fastdom_promise__WEBPACK_IMPORTED_MODULE_6__["default"].mutate(() => {
                var slotHeight = "".concat(((0,_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_3__.getCurrentBreakpoint)() === 'mobile' ? adHeight : _guardian_commercial_core_ad_sizes__WEBPACK_IMPORTED_MODULE_0__.adSizes.outstreamDesktop.height) + adLabelHeight, "px");
                (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Passback: setting height of passback slot to ".concat(slotHeight));
                slotElement.style.height = slotHeight;
                /**
                 * The centre styling is added in here instead of where the element is created
                 * because googletag removes the display style on the passbackElement
                 */
                passbackElement.style.display = 'flex';
                passbackElement.style.flexDirection = 'column';
                passbackElement.style.justifyContent = 'center';
                passbackElement.style.alignItems = 'center';
                passbackElement.style.height = "calc(100% - ".concat(adLabelHeight, "px)");
                /**
                 * Also resize the initial outstream iframe so it doesn't block text selection
                 * directly under the new ad
                 */
                iframe.style.height = slotHeight;
                iFrameContainer.style.height = slotHeight;
              });
            }
          }
        });
        /**
         * Define and display the new passback slot
         */
        window.googletag.cmd.push(() => {
          var {
            sizes,
            sizeMappings
          } = decideSizes(source);
          // https://developers.google.com/publisher-tag/reference#googletag.defineSlot
          var passbackSlot = googletag.defineSlot(initialSlot.getAdUnitPath(), sizes, passbackElement.id);
          if (passbackSlot) {
            // https://developers.google.com/publisher-tag/guides/ad-sizes#responsive_ads
            passbackSlot.defineSizeMapping(sizeMappings);
            passbackSlot.addService(window.googletag.pubads());
            passbackTargeting.forEach(_ref => {
              var [key, value] = _ref;
              passbackSlot.setTargeting(key, value);
            });
            (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', 'Passback: passback slot targeting map', passbackSlot.getTargetingMap());
            (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', "Passback: displaying slot '".concat(passbackElement.id, "'"));
            googletag.display(passbackElement.id);
          }
        });
      });
    });
  });
};


/***/ }),

/***/ "./src/lib/messenger/scroll.ts":
/*!*************************************!*\
  !*** ./src/lib/messenger/scroll.ts ***!
  \*************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _fastdom_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../fastdom-promise */ "./src/lib/fastdom-promise.ts");

// An intersection observer will allow us to efficiently send slot
// coordinates for only those that are in the viewport.
var taskQueued = false;
var iframes = {};
var iframeCounter = 0;
var observer;
var visibleIframeIds = [];
var reset = () => {
  taskQueued = false;
  iframes = {};
  iframeCounter = 0;
};
// Instances of classes bound to the current view are not serialised correctly
// by JSON.stringify. That's ok, we don't care if it's a DOMRect or some other
// object, as long as the calling view receives the frame coordinates.
var domRectToRect = rect => ({
  width: rect.width,
  height: rect.height,
  top: rect.top,
  bottom: rect.bottom,
  left: rect.left,
  right: rect.right
});
var sendCoordinates = (iframeId, domRect) => {
  var _iframes$iframeId;
  (_iframes$iframeId = iframes[iframeId]) === null || _iframes$iframeId === void 0 || _iframes$iframeId.respond(null, domRectToRect(domRect));
};
var getDimensions = id => {
  var _iframes$id;
  var node = (_iframes$id = iframes[id]) === null || _iframes$id === void 0 ? void 0 : _iframes$id.node;
  return [id, node.getBoundingClientRect()];
};
var onIntersect = changes => {
  visibleIframeIds = changes.filter(_ => _.intersectionRatio > 0).map(_ => _.target.id);
};
// typescript complains about an async event handler, so wrap it in a non-async function
var onScroll = () => {
  if (!taskQueued) {
    taskQueued = true;
    void _fastdom_promise__WEBPACK_IMPORTED_MODULE_0__["default"].measure(() => {
      taskQueued = false;
      visibleIframeIds.map(getDimensions).forEach(data => {
        sendCoordinates(data[0], data[1]);
      });
    });
  }
};
var addScrollListener = (iframe, respond) => {
  if (iframeCounter === 0) {
    window.addEventListener('scroll', onScroll, {
      passive: true
    });
    observer = new IntersectionObserver(onIntersect);
  }
  iframes[iframe.id] = {
    node: iframe,
    visible: false,
    respond
  };
  iframeCounter += 1;
  if (observer) {
    observer.observe(iframe);
  }
  void _fastdom_promise__WEBPACK_IMPORTED_MODULE_0__["default"].measure(() => iframe.getBoundingClientRect()).then(domRect => {
    sendCoordinates(iframe.id, domRect);
  });
};
var removeScrollListener = iframe => {
  if (iframe.id in iframes) {
    if (observer) {
      observer.unobserve(iframe);
    }
    delete iframes[iframe.id];
    iframeCounter -= 1;
  }
  if (iframeCounter === 0) {
    window.removeEventListener('scroll', onScroll);
    if (observer) {
      observer.disconnect();
      observer = null;
    }
  }
};
var isCallable = x => typeof x === 'function';
var init = register => {
  register('scroll', (respond, start, iframe) => {
    if (!iframe) return;
    if (start && isCallable(respond)) {
      addScrollListener(iframe, respond);
    } else {
      removeScrollListener(iframe);
    }
  });
};
var _ = {
  addScrollListener,
  removeScrollListener,
  reset
};


/***/ }),

/***/ "./src/lib/messenger/video.ts":
/*!************************************!*\
  !*** ./src/lib/messenger/video.ts ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initMessengerVideoProgressReporting: () => (/* binding */ initMessengerVideoProgressReporting)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isObject/isObject.js");
/* harmony import */ var _video_progress_reporting__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../video-progress-reporting */ "./src/lib/video-progress-reporting.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var initMessengerVideoProgressReporting = register => {
  register('video-progress', /*#__PURE__*/function () {
    var _ref = _asyncToGenerator(function* (specs, ret, iframe) {
      var adSlot = iframe === null || iframe === void 0 ? void 0 : iframe.closest('.js-ad-slot');
      if (adSlot && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isObject)(specs) && 'progress' in specs && typeof specs.progress === 'number') {
        void (0,_video_progress_reporting__WEBPACK_IMPORTED_MODULE_1__.sendProgressOnUnloadOnce)();
        (0,_video_progress_reporting__WEBPACK_IMPORTED_MODULE_1__.updateVideoProgress)(adSlot.id, specs.progress);
      }
      return Promise.resolve();
    });
    return function (_x, _x2, _x3) {
      return _ref.apply(this, arguments);
    };
  }());
};


/***/ }),

/***/ "./src/lib/messenger/viewport.ts":
/*!***************************************!*\
  !*** ./src/lib/messenger/viewport.ts ***!
  \***************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   init: () => (/* binding */ init)
/* harmony export */ });
/* harmony import */ var _detect_detect_viewport__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../detect/detect-viewport */ "./src/lib/detect/detect-viewport.ts");
/* harmony import */ var _fastdom_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../fastdom-promise */ "./src/lib/fastdom-promise.ts");


var w = window;
var iframes = {};
var iframeCounter = 0;
var taskQueued = false;
var lastViewportRead = () => _fastdom_promise__WEBPACK_IMPORTED_MODULE_1__["default"].measure(() => (0,_detect_detect_viewport__WEBPACK_IMPORTED_MODULE_0__.getViewport)());
var reset = window_ => {
  w = window_ !== null && window_ !== void 0 ? window_ : window;
  taskQueued = false;
  iframes = {};
  iframeCounter = 0;
};
var sendViewportDimensions = (iframeId, viewport) => {
  var _iframes$iframeId;
  (_iframes$iframeId = iframes[iframeId]) === null || _iframes$iframeId === void 0 || _iframes$iframeId.respond(null, viewport);
};
/**
 * When the viewport resizes send viewport dimensions
 *
 * to all registered iFrames
 */
var onResize = () => {
  if (!taskQueued) {
    taskQueued = true;
    void lastViewportRead().then(viewport => {
      Object.keys(iframes).forEach(iframeId => {
        sendViewportDimensions(iframeId, viewport);
      });
      taskQueued = false;
    });
  }
};
var addResizeListener = (iframe, respond) => {
  /**
   * Initialise resize listener
   */
  if (iframeCounter === 0) {
    w.addEventListener('resize', onResize);
  }
  /**
   * Add to the map of all iFrames with their respective
   * respond functions
   */
  iframes[iframe.id] = {
    node: iframe,
    respond
  };
  iframeCounter += 1;
  /**
   * Send viewport dimensions on first request
   */
  return lastViewportRead().then(viewport => {
    sendViewportDimensions(iframe.id, viewport);
  });
};
var removeResizeListener = iframe => {
  delete iframes[iframe.id];
  iframeCounter -= 1;
  if (iframeCounter === 0) {
    w.removeEventListener('resize', onResize);
  }
};
var onMessage = (respond, start, iframe) => {
  if (!iframe) {
    return;
  }
  if (typeof start !== 'boolean') {
    return;
  }
  if (start) {
    void addResizeListener(iframe, respond);
  } else {
    removeResizeListener(iframe);
  }
};
var init = register => {
  register('viewport', onMessage);
};
var _ = {
  addResizeListener,
  removeResizeListener,
  reset,
  onMessage
};


/***/ }),

/***/ "./src/lib/third-party-cookies.ts":
/*!****************************************!*\
  !*** ./src/lib/third-party-cookies.ts ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   checkThirdPartyCookiesEnabled: () => (/* binding */ checkThirdPartyCookiesEnabled)
/* harmony export */ });
var isTPCTestPayload = payload => typeof payload === 'object' && payload !== null && 'tpcTest' in payload && typeof payload.tpcTest === 'boolean';
/**
 * Check if third party cookies are enabled
 * This is done by creating an iframe on another domain and checking if it can access cookies
 **/
var checkThirdPartyCookiesEnabled = () => {
  var crossSiteIrame = document.createElement('iframe');
  crossSiteIrame.style.display = 'none';
  crossSiteIrame.src = "".concat(window.guardian.config.frontendAssetsFullURL, "commercial/tpc-test/v2/index.html");
  window.addEventListener('message', _ref => {
    var {
      data
    } = _ref;
    if (isTPCTestPayload(data)) {
      var {
        hasStorageAccess
      } = data;
      // only set targeting if the value is defined
      if (hasStorageAccess !== undefined) {
        window.googletag.pubads().setTargeting('3pc', [hasStorageAccess ? 't' : 'f']);
      }
    }
  });
  document.body.appendChild(crossSiteIrame);
};


/***/ }),

/***/ "./src/lib/third-party-tags/admiral.ts":
/*!*********************************************!*\
  !*** ./src/lib/third-party-tags/admiral.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   admiralTag: () => (/* binding */ admiralTag)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/consent-management-platform/index.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _init_consented_admiral__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../init/consented/admiral */ "./src/init/consented/admiral.ts");
var _abTestVariant$starts;



var BASE_AJAX_URL = window.guardian.config.stage === 'CODE' ? 'https://code.api.nextgen.guardianapps.co.uk' : 'https://api.nextgen.guardianapps.co.uk';
var abTestVariant = (0,_init_consented_admiral__WEBPACK_IMPORTED_MODULE_4__.getAdmiralAbTestVariant)();
var isInVariant = (_abTestVariant$starts = abTestVariant === null || abTestVariant === void 0 ? void 0 : abTestVariant.startsWith('variant')) !== null && _abTestVariant$starts !== void 0 ? _abTestVariant$starts : false;
/**
 * The Admiral bootstrap script should only run under the following conditions:
 *
 * - Should not run if the CMP is due to show
 * - Should only run in the US
 * - Should only run if in the variant of the AB test
 * - Should not run if the gu_hide_support_messaging cookie is set
 * - Should not run for content marked as: shouldHideAdverts, shouldHideReaderRevenue, isSensitive
 * - Should not run for paid-content sponsorship type (includes Hosted Content)
 * - Should not run for certain sections
 */
var shouldRun = _guardian_libs__WEBPACK_IMPORTED_MODULE_1__.cmp.hasInitialised() && !_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.cmp.willShowPrivacyMessageSync() && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInUsa)() && isInVariant && !(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_2__.getCookie)({
  name: 'gu_hide_support_messaging',
  shouldMemoize: true
}) && !window.guardian.config.page.shouldHideAdverts && !window.guardian.config.page.shouldHideReaderRevenue && !window.guardian.config.page.isSensitive && window.guardian.config.page.sponsorshipType !== 'paid-content' && !['about', 'info', 'membership', 'help', 'guardian-live-australia', 'gnm-archive', 'guardian-labs', 'thefilter'].includes(window.guardian.config.page.section);
/**
 * Admiral adblock recovery tag
 */
var admiralTag = {
  shouldRun,
  name: 'admiral',
  async: true,
  url: "".concat(BASE_AJAX_URL, "/commercial/admiral-bootstrap.js"),
  beforeLoad: () => {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', '🛡️ Admiral - loading script on the page');
    (0,_init_consented_admiral__WEBPACK_IMPORTED_MODULE_4__.recordAdmiralOphanEvent)({
      action: 'INSERT'
    });
    /** Send targeting to Admiral for AB test variants */
    if (isInVariant && abTestVariant) {
      (0,_init_consented_admiral__WEBPACK_IMPORTED_MODULE_4__.setAdmiralTargeting)('guAbTest', abTestVariant);
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_3__.log)('commercial', "\uD83D\uDEE1\uFE0F Admiral - setting targeting: guAbTest = ".concat(abTestVariant));
    }
  }
};


/***/ }),

/***/ "./src/lib/third-party-tags/ias.ts":
/*!*****************************************!*\
  !*** ./src/lib/third-party-tags/ias.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   ias: () => (/* binding */ ias)
/* harmony export */ });
/**
 * IAS script filters bad ads
 * https://integralads.com/uk/
 * @param  {} {shouldRun}
 */
var ias = {
  shouldRun: true,
  url: '//cdn.adsafeprotected.com/iasPET.1.js',
  name: 'ias'
};

/***/ }),

/***/ "./src/lib/third-party-tags/imr-worldwide-legacy.ts":
/*!**********************************************************!*\
  !*** ./src/lib/third-party-tags/imr-worldwide-legacy.ts ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   imrWorldwideLegacy: () => (/* binding */ imrWorldwideLegacy)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");

// nol_t is a global function defined by the IMR worldwide library
var onLoad = () => {
  var pvar = {
    cid: 'au-guardian',
    content: '0',
    server: 'secure-gl'
  };
  var trac = window.nol_t(pvar);
  trac.record().post();
};
var imrWorldwideLegacy = {
  shouldRun: !!window.guardian.config.switches.imrWorldwide && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)(),
  url: '//secure-au.imrworldwide.com/v60.js',
  onLoad
};

/***/ }),

/***/ "./src/lib/third-party-tags/imr-worldwide.ts":
/*!***************************************************!*\
  !*** ./src/lib/third-party-tags/imr-worldwide.ts ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   imrWorldwide: () => (/* binding */ imrWorldwide)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/geo/geo-utils */ "../core/src/geo/geo-utils.ts");

// NOLCMB is a global function defined by the IMR worldwide library
var guMetadata = {
  books: 'P5033A084-E9BF-453A-91D3-C558751D9A85',
  business: 'P5B109609-6223-45BA-B052-55F34A79D7AD',
  commentisfree: 'PA878EFC7-93C8-4352-905E-9E03883FD6BD',
  artanddesign: 'PE5076E6F-B85D-4B45-9536-F150EF3FC853',
  culture: 'PE5076E6F-B85D-4B45-9536-F150EF3FC853',
  stage: 'PE5076E6F-B85D-4B45-9536-F150EF3FC853',
  education: 'P4A01DB74-5B97-435A-89F0-C07EA2C739EC',
  environment: 'P2F34A388-A280-4C3F-AF43-FAF16EFCB7B1',
  cities: 'P2F34A388-A280-4C3F-AF43-FAF16EFCB7B1',
  'global-development': 'P2F34A388-A280-4C3F-AF43-FAF16EFCB7B1',
  'sustainable-business': 'P2F34A388-A280-4C3F-AF43-FAF16EFCB7B1',
  fashion: 'PCF345621-F34D-40B2-852C-6223C9C8F1E2',
  film: 'P878ECFA5-14A7-4038-9924-3696C93706FC',
  law: 'P1FA129DD-9B9E-49BB-98A4-AA7ED8523DFD',
  lifeandstyle: 'PCFE04250-E5F6-48C7-91DB-5CED6854818C',
  media: 'P1434DC6D-6585-4932-AE17-2864CD0AAE99',
  money: 'PB71E7F1E-F231-4F73-9CC8-BE8822ADD0C2',
  music: 'P78382DEE-CC9B-4B36-BD27-809007BFF300',
  international: 'P505182AA-1D71-49D8-8287-AA222CD05424',
  au: 'P505182AA-1D71-49D8-8287-AA222CD05424',
  'australia-news': 'P505182AA-1D71-49D8-8287-AA222CD05424',
  uk: 'P505182AA-1D71-49D8-8287-AA222CD05424',
  'uk-news': 'P505182AA-1D71-49D8-8287-AA222CD05424',
  us: 'P505182AA-1D71-49D8-8287-AA222CD05424',
  'us-news': 'P505182AA-1D71-49D8-8287-AA222CD05424',
  world: 'P505182AA-1D71-49D8-8287-AA222CD05424',
  politics: 'P5B7468E3-CE04-40FD-9444-22FB872FE83E',
  careers: 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'culture-professionals-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'global-development-professionals-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'government-computing-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'guardian-professional': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'healthcare-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'higher-education-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'housing-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'local-government-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'local-leaders-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'public-leaders-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'small-business-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'social-care-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'teacher-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'voluntary-sector-network': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  'women-in-leadership': 'P3637DC6B-E43C-4E92-B22C-3F255CC573DA',
  science: 'PDAD6BC22-C97B-4151-956B-7F069B2C56E9',
  society: 'P7AF4A592-96FB-4255-B33F-352406F4C7D2',
  sport: 'PCC1AEBB6-7D1A-4F34-8256-EFC314E5D0C3',
  football: 'PCC1AEBB6-7D1A-4F34-8256-EFC314E5D0C3',
  technology: 'P29EF991A-3FEE-4215-9F03-58EACA8286B9',
  travel: 'PD1CEDC3E-2653-4CB6-A4FD-8A315DE07548',
  'tv-and-radio': 'P66E48909-8FC9-49E8-A7E6-0D31C61805AD',
  'brand-only': 'P0EE0F4F4-8D7C-4082-A2A4-82C84728DC59'
};
var onLoad = () => {
  var _guMetadata$sectionFr;
  var sectionFromMeta = window.guardian.config.page.section.toLowerCase();
  var subBrandApId = (_guMetadata$sectionFr = guMetadata[sectionFromMeta]) !== null && _guMetadata$sectionFr !== void 0 ? _guMetadata$sectionFr : guMetadata['brand-only'];
  var sectionRef = sectionFromMeta in guMetadata ? sectionFromMeta : 'The Guardian - brand only';
  var nolggGlobalParams = {
    sfcode: 'dcr',
    apid: subBrandApId,
    apn: 'theguardian'
  };
  var nSdkInstance = window.NOLCMB.getInstance(nolggGlobalParams.apid);
  nSdkInstance.ggInitialize(nolggGlobalParams);
  var dcrStaticMetadata = {
    type: 'static',
    assetid: window.guardian.config.page.pageId,
    section: sectionRef
  };
  nSdkInstance.ggPM('staticstart', dcrStaticMetadata);
};
var imrWorldwide = {
  shouldRun: !!window.guardian.config.switches.imrWorldwide && (0,_guardian_commercial_core_geo_geo_utils__WEBPACK_IMPORTED_MODULE_0__.isInAuOrNz)(),
  url: '//secure-dcr.imrworldwide.com/novms/js/2/ggcmb510.js',
  onLoad
};

/***/ }),

/***/ "./src/lib/third-party-tags/inizio.ts":
/*!********************************************!*\
  !*** ./src/lib/third-party-tags/inizio.ts ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   inizio: () => (/* binding */ inizio)
/* harmony export */ });
var handleQuerySurveyDone = (surveyAvailable, survey) => {
  if (surveyAvailable) {
    // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition -- @types/googletag declares it, but it may be missing
    if (window.googletag) {
      window.googletag.cmd.push(() => {
        window.googletag.pubads().setTargeting('inizio', 't');
      });
    }
    console.log("surveyAvailable: ".concat(survey.measurementId));
  }
};
var onLoad = () => {
  var _window, _window$_brandmetrics;
  (_window$_brandmetrics = (_window = window)._brandmetrics) !== null && _window$_brandmetrics !== void 0 ? _window$_brandmetrics : _window._brandmetrics = [];
  window._brandmetrics.push({
    cmd: '_querySurvey',
    val: {
      callback: handleQuerySurveyDone
    }
  });
};
/**
 * Allows creatives to show survey
 * https://trello.com/c/wHffHVF1/171-integrate-and-test-inizio
 * @param  {} {shouldRun}
 */
var inizio = _ref => {
  var {
    shouldRun
  } = _ref;
  return {
    shouldRun,
    url: '//cdn.brandmetrics.com/survey/script/e96d04c832084488a841a06b49b8fb2d.js',
    name: 'inizio',
    onLoad
  };
};
var _ = {
  onLoad,
  handleQuerySurveyDone
};

/***/ }),

/***/ "./src/lib/third-party-tags/permutive.ts":
/*!***********************************************!*\
  !*** ./src/lib/third-party-tags/permutive.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   permutive: () => (/* binding */ permutive)
/* harmony export */ });
/**
 * Permutive script updates local user segmentation data
 * @param  {} {shouldRun}
 */
var permutive = _ref => {
  var {
    shouldRun
  } = _ref;
  return {
    shouldRun,
    url: '//cdn.permutive.com/d6691a17-6fdb-4d26-85d6-b3dd27f55f08-web.js',
    name: 'permutive'
  };
};

/***/ }),

/***/ "./src/lib/third-party-tags/remarketing.ts":
/*!*************************************************!*\
  !*** ./src/lib/third-party-tags/remarketing.ts ***!
  \*************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   remarketing: () => (/* binding */ remarketing)
/* harmony export */ });
var onLoad = () => {
  var _window$google_trackC, _window;
  (_window$google_trackC = (_window = window).google_trackConversion) === null || _window$google_trackC === void 0 || _window$google_trackC.call(_window, {
    google_conversion_id: 971225648,
    google_custom_params: window.google_tag_params,
    google_remarketing_only: true
  });
};
/**
 * Google conversion tracking
 * https://support.google.com/google-ads/answer/6095821
 * @param  {} {shouldRun}
 */
var remarketing = _ref => {
  var {
    shouldRun
  } = _ref;
  return {
    shouldRun,
    url: '//www.googleadservices.com/pagead/conversion_async.js',
    name: 'remarketing',
    onLoad
  };
};

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uY29uc2VudGVkLWFkdmVydGlzaW5nLmNvbW1lcmNpYWwuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNPLElBQU1BLGVBQWUsR0FBRyxFQUFFLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNIbUI7QUFDRjs7Ozs7Ozs7Ozs7Ozs7O0FDRGxEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1FLG9CQUFvQixHQUFHLEVBQUU7QUFDdEM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxFOzs7Ozs7Ozs7Ozs7OztBQzVDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSUMsWUFBWSxHQUFHQyxTQUFTO0FBQzVCLFNBQVNDLGdCQUFnQkEsQ0FBQ0MsRUFBRSxFQUFFO0VBQzFCLElBQUlBLEVBQUUsQ0FBQ0MsWUFBWSxLQUFLLElBQUksSUFDeEJELEVBQUUsQ0FBQ0UsWUFBWSxLQUFLLENBQUMsSUFDckJGLEVBQUUsQ0FBQ0csVUFBVSxLQUFLLENBQUMsSUFDbkJILEVBQUUsQ0FBQ0ksU0FBUyxLQUFLLENBQUMsSUFDbEJKLEVBQUUsQ0FBQ0ssV0FBVyxLQUFLLENBQUMsSUFDcEJMLEVBQUUsQ0FBQ00sWUFBWSxLQUFLLENBQUMsSUFDckJOLEVBQUUsQ0FBQ08sV0FBVyxLQUFLLENBQUMsRUFBRTtJQUN0QixPQUFPLElBQUk7RUFDZjtFQUNBLElBQU1DLFFBQVEsR0FBR0MsTUFBTSxDQUFDQyxnQkFBZ0IsQ0FBQ1YsRUFBRSxDQUFDO0VBQzVDLElBQUlRLFFBQVEsQ0FBQ0csZ0JBQWdCLENBQUMsU0FBUyxDQUFDLEtBQUssTUFBTSxFQUMvQyxPQUFPLElBQUk7RUFDZixJQUFJSCxRQUFRLENBQUNHLGdCQUFnQixDQUFDLFlBQVksQ0FBQyxLQUFLLFFBQVEsRUFDcEQsT0FBTyxJQUFJO0VBQ2YsSUFBTUMsY0FBYyxHQUFHSixRQUFRLENBQUNHLGdCQUFnQixDQUFDLGNBQWMsQ0FBQztFQUNoRSxJQUFJQyxjQUFjLENBQUNDLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFDakMsT0FBTyxJQUFJO0VBQ2YsT0FBTyxLQUFLO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGNBQWNBLENBQUEsRUFBRztFQUM3QixJQUFJakIsWUFBWSxLQUFLQyxTQUFTLEVBQUU7SUFDNUIsT0FBT2lCLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDbkIsWUFBWSxDQUFDO0VBQ3hDO0VBQ0EsSUFBSSxPQUFPWSxNQUFNLENBQUNDLGdCQUFnQixLQUFLLFVBQVUsRUFBRTtJQUMvQztJQUNBYixZQUFZLEdBQUcsS0FBSztJQUNwQixPQUFPa0IsT0FBTyxDQUFDQyxPQUFPLENBQUNuQixZQUFZLENBQUM7RUFDeEM7RUFDQSxPQUFPLElBQUlrQixPQUFPLENBQUVDLE9BQU8sSUFBSztJQUM1QlAsTUFBTSxDQUFDUSxxQkFBcUIsQ0FBQyxNQUFNO01BQy9CO01BQ0EsSUFBTWpCLEVBQUUsR0FBR2tCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztNQUN4Q25CLEVBQUUsQ0FBQ29CLFlBQVksQ0FBQyxPQUFPLEVBQUUsK0lBQStJLENBQUM7TUFDektwQixFQUFFLENBQUNvQixZQUFZLENBQUMsT0FBTyxFQUFFLG1JQUFtSSxDQUFDO01BQzdKRixRQUFRLENBQUNHLElBQUksQ0FBQ0MsV0FBVyxDQUFDdEIsRUFBRSxDQUFDO01BQzdCO01BQ0FTLE1BQU0sQ0FBQ1EscUJBQXFCLENBQUMsTUFBTTtRQUMvQjtRQUNBRCxPQUFPLENBQUNqQixnQkFBZ0IsQ0FBQ0MsRUFBRSxDQUFDLENBQUM7TUFDakMsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDO0VBQ04sQ0FBQyxDQUFDO0FBQ04sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3pEcUQ7QUFDVjtBQUNOO0FBQ0k7QUFBcEI7QUFDK0U7QUFDOUI7QUFDZjtBQUNJO0FBQ0w7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNSakI7QUFDcUM7QUFDMUU7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNb0Msa0JBQWtCLEdBQUlDLE1BQU0sSUFBSztFQUNuQyxJQUFNQyxhQUFhLEdBQUdDLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDSCxNQUFNLENBQUMsQ0FDdkNJLEdBQUcsQ0FBQ0MsSUFBQSxJQUFrQjtJQUFBLElBQWpCLENBQUNDLEdBQUcsRUFBRUMsS0FBSyxDQUFDLEdBQUFGLElBQUE7SUFDbEIsSUFBTUcsVUFBVSxHQUFHQyxLQUFLLENBQUNDLE9BQU8sQ0FBQ0gsS0FBSyxDQUFDLEdBQ2pDQSxLQUFLLENBQUNJLElBQUksQ0FBQyxHQUFHLENBQUMsR0FDZkMsTUFBTSxDQUFDTCxLQUFLLENBQUM7SUFDbkIsVUFBQU0sTUFBQSxDQUFVUCxHQUFHLE9BQUFPLE1BQUEsQ0FBSUMsa0JBQWtCLENBQUNOLFVBQVUsQ0FBQztFQUNuRCxDQUFDLENBQUMsQ0FDR0csSUFBSSxDQUFDLEdBQUcsQ0FBQztFQUNkLE9BQU9WLGFBQWE7QUFDeEIsQ0FBQztBQUNELElBQU1jLDhCQUE4QixHQUFHQSxDQUFDQyxZQUFZLEVBQUVDLFlBQVksRUFBRUMsd0JBQXdCLEVBQUVDLFVBQVUsS0FBSztFQUN6RyxJQUFJQyxhQUFhLEdBQUcsQ0FBQyxDQUFDO0VBQ3RCLElBQUk7SUFDQUEsYUFBYSxHQUFHNUIseUVBQWtCLENBQUM7TUFDL0I2QixNQUFNLEVBQUUsS0FBSztNQUNiSCx3QkFBd0I7TUFDeEJELFlBQVksRUFBRUEsWUFBWTtNQUMxQkUsVUFBVSxFQUFFQTtJQUNoQixDQUFDLENBQUM7RUFDTixDQUFDLENBQ0QsT0FBT0csQ0FBQyxFQUFFO0lBQ047QUFDUjtBQUNBO0FBQ0E7QUFDQTtJQUNRekIsbURBQUcsQ0FBQyxZQUFZLEVBQUUsMENBQTBDLEVBQUV5QixDQUFDLENBQUM7SUFDaEUsT0FBT04sWUFBWTtFQUN2QjtFQUNBLElBQU1PLGtCQUFrQixHQUFBQyxhQUFBLENBQUFBLGFBQUEsS0FDakJSLFlBQVksR0FDWkksYUFBYSxDQUNuQjtFQUNELE9BQU9HLGtCQUFrQjtBQUM3QixDQUFDO0FBQ0QsSUFBTTdCLGdCQUFnQixHQUFHK0IsS0FBQSxJQUFtRjtFQUFBLElBQWxGO0lBQUVDLE1BQU07SUFBRVIsd0JBQXdCO0lBQUVELFlBQVk7SUFBRUQsWUFBWTtJQUFFRztFQUFZLENBQUMsR0FBQU0sS0FBQTtFQUNuRyxJQUFNRixrQkFBa0IsR0FBR1IsOEJBQThCLENBQUNDLFlBQVksRUFBRUMsWUFBWSxFQUFFQyx3QkFBd0IsRUFBRUMsVUFBVSxDQUFDO0VBQzNILElBQU1RLFdBQVcsR0FBRztJQUNoQkMsRUFBRSxFQUFFRixNQUFNO0lBQ1ZHLElBQUksRUFBRSxHQUFHO0lBQ1RDLEdBQUcsRUFBRSxHQUFHO0lBQ1JDLEVBQUUsRUFBRSx5QkFBeUI7SUFDN0JDLFFBQVEsRUFBRSxHQUFHO0lBQ2JDLE1BQU0sRUFBRSxNQUFNO0lBQ2RDLHVCQUF1QixFQUFFLEdBQUc7SUFDNUJDLEdBQUcsRUFBRSxJQUFJO0lBQ1RDLElBQUksRUFBRSxHQUFHO0lBQ1RDLFFBQVEsRUFBRSxRQUFRO0lBQ2xCQyxJQUFJLEVBQUUsU0FBUztJQUNmQyxLQUFLLEVBQUUsR0FBRztJQUNWQyxlQUFlLEVBQUUxQixrQkFBa0IsSUFBQUQsTUFBQSxDQUFJekMsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ0MsSUFBSSxPQUFBL0IsTUFBQSxDQUFJekMsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ0UsTUFBTSxDQUFFLENBQUM7SUFDaEg7QUFDUjtBQUNBO0FBQ0E7QUFDQTtJQUNRQyxXQUFXLEVBQUVoQyxrQkFBa0IsQ0FBQ2Ysa0JBQWtCLENBQUNELG1FQUFZLENBQUN5QixrQkFBa0IsQ0FBQyxDQUFDO0VBQ3hGLENBQUM7RUFDRCxJQUFNd0IsZ0JBQWdCLEdBQUcsRUFBRTtFQUMzQixLQUFLLElBQU0sQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLENBQUMsSUFBSS9DLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDd0IsV0FBVyxDQUFDLEVBQUU7SUFDOUNvQixnQkFBZ0IsQ0FBQ0csSUFBSSxJQUFBckMsTUFBQSxDQUFJbUMsQ0FBQyxPQUFBbkMsTUFBQSxDQUFJb0MsQ0FBQyxDQUFFLENBQUM7RUFDdEM7RUFDQSxPQUFRLG9EQUFvRCxHQUN4REYsZ0JBQWdCLENBQUNwQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ2xDLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ3ZFRCxJQUFNd0MsU0FBUyxHQUFJQyxDQUFDLElBQUs7RUFDckIsT0FBTyxPQUFPQSxDQUFDLEtBQUssU0FBUztBQUNqQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGcUQ7QUFDVjtBQUNEO0FBQzNDLElBQU1JLFVBQVUsR0FBR0EsQ0FBQSxLQUFNO0VBQ3JCO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSXBGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ0MsbUJBQW1CLENBQUMsQ0FBQztFQUMvQ3ZGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ0UsaUJBQWlCLENBQUMsQ0FBQztFQUM3Q3hGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7RUFDakMsSUFBTUMsaUJBQWlCLEdBQUdSLG9EQUFNLENBQUNTLGFBQWEsQ0FBQ0MsTUFBTSxHQUMvQ1Ysb0RBQU0sQ0FBQ1MsYUFBYSxDQUFDLENBQUMsQ0FBQyxHQUN2QnRHLFNBQVM7RUFDZixJQUFJcUcsaUJBQWlCLEVBQUU7SUFDbkJQLHdEQUFVLENBQUNPLGlCQUFpQixDQUFDO0lBQzdCUixvREFBTSxDQUFDUyxhQUFhLEdBQUcsRUFBRTtFQUM3QjtFQUNBVixrRUFBUSxDQUFDLENBQUM7QUFDZCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7OztBQzdCMkM7QUFDQztBQUM3QyxJQUFNYSxjQUFjLEdBQUdBLENBQUEsS0FBTTtFQUN6QjlGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ0UsaUJBQWlCLENBQUMsQ0FBQztFQUM3Q3hGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0ksY0FBYyxDQUFDLENBQUM7RUFDakNQLG9EQUFNLENBQUNTLGFBQWEsQ0FBQ0ksT0FBTyxDQUFDRixzREFBYyxDQUFDO0FBQ2hELENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTjhFO0FBQ25CO0FBQzVELElBQU1yQixJQUFJLE1BQUEvQixNQUFBLENBQU16QyxNQUFNLENBQUNpRyxRQUFRLENBQUNDLFFBQVEsUUFBQXpELE1BQUEsQ0FBS3pDLE1BQU0sQ0FBQ2lHLFFBQVEsQ0FBQ3pCLElBQUksQ0FBRTtBQUNuRTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTTJCLFVBQVUsR0FBSUMsS0FBSyxJQUFLO0VBQ2pDLElBQU1DLE1BQU0sR0FBR0wsd0VBQWEsQ0FBQ0ksS0FBSyxDQUFDRSxJQUFJLENBQUNDLGdCQUFnQixDQUFDLENBQUMsQ0FBQztFQUMzRCxJQUFJLENBQUNGLE1BQU0sRUFBRTtJQUNUO0VBQ0o7RUFDQSxJQUFNRyxNQUFNLEdBQUdILE1BQU0sQ0FBQ0ksSUFBSSxDQUFDQyxvQkFBb0IsQ0FBQyxRQUFRLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUNqRSxJQUFJLEVBQUNILE1BQU0sYUFBTkEsTUFBTSxlQUFOQSxNQUFNLENBQUVJLGFBQWEsR0FBRTtJQUN4QkMsT0FBTyxDQUFDcEYsR0FBRyxDQUFDLDBCQUEwQixFQUFFNEUsTUFBTSxDQUFDUyxFQUFFLEVBQUVULE1BQU0sQ0FBQ0MsSUFBSSxDQUFDO0lBQy9EO0VBQ0o7RUFDQWpGLDZGQUFXLENBQUM7SUFDUnlGLEVBQUUsRUFBRU4sTUFBTSxDQUFDTSxFQUFFO0lBQ2J0QztFQUNKLENBQUMsRUFBRWdDLE1BQU0sQ0FBQ0ksYUFBYSxDQUFDO0FBQzVCLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QmlFO0FBQ3hCO0FBQ2tCO0FBQ0o7QUFDWDtBQUNFO0FBQy9DLElBQU1RLG1CQUFtQixHQUFHQSxDQUFDQyxRQUFRLEVBQUVqQixLQUFLLEtBQUs7RUFDN0M7RUFDQTtFQUNBO0VBQ0EsSUFBSWtCLElBQUksQ0FBQ0MsTUFBTSxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBTSxFQUFFO0lBQzVCLElBQU1DLFVBQVUsR0FBR3BCLEtBQUssQ0FBQ0UsSUFBSSxDQUFDbUIsYUFBYSxDQUFDLENBQUM7SUFDN0MsSUFBTUMsZUFBZSxHQUFHdEIsS0FBSyxDQUFDRSxJQUFJLENBQUNxQixnQkFBZ0IsQ0FBQyxDQUFDO0lBQ3JELElBQU1DLGtCQUFrQixHQUFHRixlQUFlLENBQUN0SCxRQUFRLENBQUMsR0FBRyxDQUFDLEdBQ2xEZ0csS0FBSyxDQUFDRSxJQUFJLENBQUN1QixZQUFZLENBQUMsR0FBRyxDQUFDLEdBQzVCLEVBQUU7SUFDUixJQUFNQyxVQUFVLEdBQUdGLGtCQUFrQixDQUFDckYsSUFBSSxDQUFDLElBQUksQ0FBQztJQUNoRDBFLG9FQUFXLENBQUMsSUFBSWMsS0FBSyxDQUFDLG1DQUFtQyxDQUFDLEVBQUUsWUFBWSxFQUFFO01BQ3RFekUsTUFBTSxFQUFFa0UsVUFBVTtNQUNsQlEsTUFBTSxFQUFFWCxRQUFRO01BQ2hCUztJQUNKLENBQUMsQ0FBQztFQUNOO0FBQ0osQ0FBQztBQUNELElBQU1HLGlCQUFpQixHQUFJQyxJQUFJLElBQUs7RUFDaEMsSUFBSWxCLHdEQUFRLENBQUNrQixJQUFJLENBQUMsRUFDZCxPQUFPLE9BQU87RUFDbEIsT0FBT25CLGdGQUFZLENBQUNvQixNQUFNLENBQUNELElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFQyxNQUFNLENBQUNELElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3pELENBQUM7QUFDTSxJQUFNRSxZQUFZLEdBQUloQyxLQUFLLElBQUs7RUFDbkMsSUFBTUMsTUFBTSxHQUFHTCx3RUFBYSxDQUFDSSxLQUFLLENBQUNFLElBQUksQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0VBQzNELElBQUksQ0FBQ0YsTUFBTSxFQUFFO0lBQ1Q7RUFDSjtFQUNBQSxNQUFNLENBQUNnQyxPQUFPLEdBQUdqQyxLQUFLLENBQUNpQyxPQUFPO0VBQzlCLElBQUlqQyxLQUFLLENBQUNpQyxPQUFPLEVBQUU7SUFDZm5CLDBEQUFXLENBQUNiLE1BQU0sQ0FBQztJQUNuQmUsbUJBQW1CLENBQUNmLE1BQU0sQ0FBQ1MsRUFBRSxFQUFFVixLQUFLLENBQUM7SUFDckNDLE1BQU0sQ0FBQ2lDLGlCQUFpQixDQUFDLEtBQUssQ0FBQztFQUNuQyxDQUFDLE1BQ0k7SUFDRDtBQUNSO0FBQ0E7QUFDQTtJQUNRLElBQUksQ0FBQ2pDLE1BQU0sQ0FBQ2tDLGFBQWEsSUFBSW5DLEtBQUssQ0FBQzhCLElBQUksRUFBRTtNQUNyQzdCLE1BQU0sQ0FBQzZCLElBQUksR0FBR0QsaUJBQWlCLENBQUM3QixLQUFLLENBQUM4QixJQUFJLENBQUM7SUFDL0M7SUFDQTtJQUNBO0lBQ0E7SUFDQTdCLE1BQU0sQ0FBQ21DLFVBQVUsR0FBR3BDLEtBQUssQ0FBQ29DLFVBQVU7SUFDcENuQyxNQUFNLENBQUNvQyxVQUFVLEdBQUdyQyxLQUFLLENBQUNxQyxVQUFVO0lBQ3BDcEMsTUFBTSxDQUFDcUMsa0JBQWtCLEdBQUd0QyxLQUFLLENBQUNzQyxrQkFBa0I7SUFDcEQsS0FBS3ZCLDREQUFZLENBQUNkLE1BQU0sRUFBRUQsS0FBSyxDQUFDLENBQUN1QyxJQUFJLENBQUVDLFVBQVUsSUFBSztNQUNsRHZDLE1BQU0sQ0FBQ2lDLGlCQUFpQixDQUFDTSxVQUFVLENBQUM7SUFDeEMsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxRG1FO0FBQ2tCO0FBQ25CO0FBQzlCO0FBQ087QUFDVTtBQUNNO0FBQ21DO0FBQ3JDO0FBQ2I7QUFDTDtBQUN4QyxJQUFNTyxtQkFBbUIsR0FBRyxLQUFNLENBQUMsQ0FBQztBQUNwQztBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1DLGtCQUFrQixHQUFJL0MsTUFBTSxJQUFLO0VBQ25DO0VBQ0EsSUFBSSxDQUFDeUMsd0RBQVEsQ0FBQ3pDLE1BQU0sQ0FBQzZCLElBQUksQ0FBQyxFQUFFO0lBQ3hCO0VBQ0o7RUFDQSxJQUFNO0lBQUVBLElBQUk7SUFBRXpCO0VBQUssQ0FBQyxHQUFHSixNQUFNO0VBQzdCO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxJQUFNZ0QsbUJBQW1CLEdBQUd2SCxNQUFNLENBQUN3SCxNQUFNLENBQUNULDhFQUFjLENBQUMsQ0FBQ1UsSUFBSSxDQUFDdEgsSUFBQTtJQUFBLElBQUM7TUFBRXVILEtBQUs7TUFBRUM7SUFBTyxDQUFDLEdBQUF4SCxJQUFBO0lBQUEsT0FBS3VILEtBQUssS0FBS3RCLElBQUksQ0FBQ3NCLEtBQUssSUFBSUMsTUFBTSxLQUFLdkIsSUFBSSxDQUFDdUIsTUFBTTtFQUFBLEVBQUM7RUFDckksSUFBSUosbUJBQW1CLEVBQUU7SUFDckI7RUFDSjtFQUNBLElBQU1LLGdCQUFnQixHQUFHLENBQUN4QixJQUFJLENBQUN5QixPQUFPLENBQUMsQ0FBQztFQUN4QyxJQUFJRCxnQkFBZ0IsRUFBRTtJQUNsQixLQUFLVCw0REFBTyxDQUNQVyxPQUFPLENBQUMsTUFBTW5ELElBQUksQ0FBQ29ELFlBQVksQ0FBQyxZQUFZLENBQUMsS0FBSyxNQUFNLENBQUMsQ0FDekRsQixJQUFJLENBQUVtQixRQUFRLElBQUs7TUFDcEIsSUFBTUMsV0FBVyxHQUFHRCxRQUFRLEdBQUc3SyxnR0FBZSxHQUFHLENBQUM7TUFDbEQsS0FBS2dLLDREQUFPLENBQUNlLE1BQU0sQ0FBQyxNQUFNO1FBQ3RCLElBQU1DLFlBQVksR0FBRy9CLElBQUksQ0FBQ3VCLE1BQU0sR0FBR00sV0FBVztRQUM5Q3RELElBQUksQ0FBQ3lELEtBQUssQ0FBQ0MsU0FBUyxNQUFBMUgsTUFBQSxDQUFNd0gsWUFBWSxPQUFJO01BQzlDLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQztFQUNOLENBQUMsTUFDSTtJQUNEO0lBQ0E7SUFDQTtJQUNBLEtBQUtoQiw0REFBTyxDQUFDZSxNQUFNLENBQUMsTUFBTTtNQUN0QnZELElBQUksQ0FBQ3lELEtBQUssQ0FBQ0MsU0FBUyxHQUFHLEVBQUU7SUFDN0IsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0QsSUFBTUMsZ0JBQWdCLEdBQUloRSxLQUFLLElBQUs7RUFDaEMsSUFBTUMsTUFBTSxHQUFHTCx3RUFBYSxDQUFDSSxLQUFLLENBQUNFLElBQUksQ0FBQ0MsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDO0VBQzNELElBQUksQ0FBQ0YsTUFBTSxFQUFFO0lBQ1Q7RUFDSjtFQUNBLEtBQUsrQyxrQkFBa0IsQ0FBQy9DLE1BQU0sQ0FBQztFQUMvQjtFQUNBLEtBQUswQywyR0FBc0MsQ0FBQyxDQUFDLENBQ3hDSixJQUFJLENBQUUwQix5QkFBeUIsSUFBSztJQUNyQztJQUNBO0lBQ0E7SUFDQWhFLE1BQU0sQ0FBQzJDLGFBQWEsR0FBR0Esc0VBQWEsQ0FBQzNDLE1BQU0sRUFBRWdFLHlCQUF5QixDQUFDO0VBQzNFLENBQUMsQ0FBQyxDQUNHQyxLQUFLLENBQUVDLEtBQUssSUFBSztJQUNsQjlJLG1EQUFHLENBQUMsWUFBWSxFQUFFLDhDQUE4QyxFQUFFOEksS0FBSyxDQUFDO0VBQzVFLENBQUMsQ0FBQztFQUNGLElBQU1DLHNCQUFzQixHQUFHckIsbUJBQW1CO0VBQ2xEO0VBQ0EsSUFBTXNCLGlCQUFpQixHQUFHQSxDQUFBLEtBQU07SUFDNUIsSUFBSSxDQUFDaEssUUFBUSxDQUFDaUssTUFBTSxFQUFFO01BQ2xCakssUUFBUSxDQUFDa0ssbUJBQW1CLENBQUMsa0JBQWtCLEVBQUVGLGlCQUFpQixDQUFDO01BQ25FNUUsa0VBQWMsQ0FBQ1EsTUFBTSxDQUFDO0lBQzFCO0VBQ0osQ0FBQztFQUNEdUUsVUFBVSxDQUFDLE1BQU07SUFDYjtJQUNBO0lBQ0EsSUFBSSxDQUFDdkUsTUFBTSxDQUFDMkMsYUFBYSxFQUFFO01BQ3ZCO0lBQ0o7SUFDQTtJQUNBO0lBQ0EsSUFBSXZJLFFBQVEsQ0FBQ2lLLE1BQU0sRUFBRTtNQUNqQmpLLFFBQVEsQ0FBQ29LLGdCQUFnQixDQUFDLGtCQUFrQixFQUFFSixpQkFBaUIsQ0FBQztJQUNwRSxDQUFDLE1BQ0k7TUFDRDVFLGtFQUFjLENBQUNRLE1BQU0sQ0FBQztJQUMxQjtFQUNKLENBQUMsRUFBRW1FLHNCQUFzQixDQUFDO0FBQzlCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1NLHNCQUFzQixHQUFHQSxDQUFBLEtBQU07RUFDakMsSUFBTXZILFdBQVcsR0FBRzJGLHFEQUFVLENBQUMsQ0FBQztFQUNoQyxPQUFROUMsS0FBSyxJQUFLO0lBQ2QsSUFBTUUsSUFBSSxHQUFHRixLQUFLLENBQUNFLElBQUksQ0FBQ3VCLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDL0MvRyw2RUFBVSxDQUFDaUssR0FBRyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLFVBQVUsRUFBRTFFLElBQUksQ0FBQztJQUN2QzdFLG1EQUFHLENBQUMsWUFBWSxFQUFFLGVBQWUsRUFBRTZFLElBQUksQ0FBQztJQUN4QyxJQUFJL0MsV0FBVyxDQUFDMEgsU0FBUyxLQUFLLE9BQU8sRUFBRTtNQUNuQ2IsZ0JBQWdCLENBQUNoRSxLQUFLLENBQUM7SUFDM0I7RUFDSixDQUFDO0FBQ0wsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0c0RDtBQUNMO0FBQ1g7QUFDbUI7QUFDbkI7QUFDYTtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNZ0Ysa0JBQWtCLEdBQUlDLGFBQWEsSUFBSyxTQUFTQyxRQUFRQSxDQUFDQyxVQUFVLEVBQUU7RUFDeEUsT0FBTyxTQUFTQyxnQkFBZ0JBLENBQUNuRixNQUFNLEVBQUU7SUFDckMsSUFBSWtGLFVBQVUsQ0FBQ2hDLElBQUksQ0FBRWtDLFNBQVMsSUFBS3BGLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDaUYsU0FBUyxDQUFDQyxRQUFRLENBQUNGLFNBQVMsQ0FBQyxDQUFDLEVBQUU7TUFDM0UsT0FBT3hDLDREQUFPLENBQUNlLE1BQU0sQ0FBQyxNQUFNO1FBQ3hCcUIsYUFBYSxDQUFDdEYsT0FBTyxDQUFFMEYsU0FBUyxJQUFLO1VBQ2pDcEYsTUFBTSxDQUFDSSxJQUFJLENBQUNpRixTQUFTLENBQUNFLEdBQUcsQ0FBQ0gsU0FBUyxDQUFDO1FBQ3hDLENBQUMsQ0FBQztNQUNOLENBQUMsQ0FBQztJQUNOO0lBQ0EsT0FBT25MLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDNUIsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNc0wsV0FBVyxHQUFHVCxrQkFBa0IsQ0FBQyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFDN0QsSUFBTVUsUUFBUSxHQUFHVixrQkFBa0IsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7QUFDdkQsSUFBTVcsdUJBQXVCLEdBQUdBLENBQUMxRixNQUFNLEVBQUU2RCxLQUFLLEtBQUs7RUFDL0MsSUFBTThCLFFBQVEsR0FBRzNGLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDd0YsYUFBYSxDQUFDLFFBQVEsQ0FBQztFQUNwRCxLQUFLaEQsNERBQU8sQ0FBQ2UsTUFBTSxDQUFDLE1BQU07SUFDdEIsSUFBSWdDLFFBQVEsRUFBRTtNQUNWQSxRQUFRLENBQUM5QixLQUFLLENBQUNnQyxjQUFjLENBQUNoQyxLQUFLLENBQUM7SUFDeEM7RUFDSixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsSUFBTWlDLGFBQWEsR0FBRyxDQUFDLENBQUM7QUFDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBQSxhQUFhLENBQUNwTCx1RUFBTyxDQUFDcUwsS0FBSyxDQUFDQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUloRyxNQUFNLElBQUt5RixRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDekYsTUFBTSxDQUFDLENBQUNzQyxJQUFJLENBQUMsTUFBTW9ELHVCQUF1QixDQUFDMUYsTUFBTSxFQUFFLGdCQUFnQixDQUFDLENBQUM7QUFDako4RixhQUFhLENBQUNwTCx1RUFBTyxDQUFDdUwsR0FBRyxDQUFDRCxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUloRyxNQUFNLElBQUtBLE1BQU0sQ0FBQ2tHLHNCQUFzQixDQUFDLENBQUM7QUFDbkZKLGFBQWEsQ0FBQ3BMLHVFQUFPLENBQUN5TCxRQUFRLENBQUNILFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBSWhHLE1BQU0sSUFBS0EsTUFBTSxDQUFDa0csc0JBQXNCLENBQUMsQ0FBQztBQUN4RkosYUFBYSxDQUFDcEwsdUVBQU8sQ0FBQzBMLFVBQVUsQ0FBQ0osUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFJaEcsTUFBTSxJQUFLQSxNQUFNLENBQUNrRyxzQkFBc0IsQ0FBQyxjQUFjLENBQUM7QUFDeEdKLGFBQWEsQ0FBQ3BMLHVFQUFPLENBQUMyTCxnQkFBZ0IsQ0FBQ0wsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFJaEcsTUFBTSxJQUFLQSxNQUFNLENBQUNrRyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQztBQUNwSEosYUFBYSxDQUFDcEwsdUVBQU8sQ0FBQzRMLHNCQUFzQixDQUFDTixRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUloRyxNQUFNLElBQUtBLE1BQU0sQ0FBQ2tHLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDO0FBQzFISixhQUFhLENBQUNwTCx1RUFBTyxDQUFDNkwsZUFBZSxDQUFDUCxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUloRyxNQUFNLElBQUtBLE1BQU0sQ0FBQ2tHLHNCQUFzQixDQUFDLG9CQUFvQixDQUFDO0FBQ25ISixhQUFhLENBQUNwTCx1RUFBTyxDQUFDOEwsVUFBVSxDQUFDUixRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUloRyxNQUFNLElBQUtBLE1BQU0sQ0FBQ2tHLHNCQUFzQixDQUFDLGFBQWEsQ0FBQztBQUN2R0osYUFBYSxDQUFDcEwsdUVBQU8sQ0FBQytMLHFCQUFxQixDQUFDVCxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUloRyxNQUFNLElBQUs7RUFDbEVBLE1BQU0sQ0FBQzJDLGFBQWEsR0FBRyxLQUFLO0VBQzVCLE9BQU8xSSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0FBQzVCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU13TSxpQkFBaUIsR0FBSTFHLE1BQU0sSUFBSztFQUNsQyxJQUFNMkcsTUFBTSxHQUFHM0csTUFBTSxDQUFDSSxJQUFJLENBQUN3RyxVQUFVO0VBQ3JDLE9BQU9oRSw0REFBTyxDQUFDZSxNQUFNLENBQUMsTUFBTTtJQUN4QjNELE1BQU0sQ0FBQ0ksSUFBSSxDQUFDaUYsU0FBUyxDQUFDRSxHQUFHLENBQUMsbUJBQW1CLENBQUM7SUFDOUM7SUFDQSxJQUFJdkYsTUFBTSxDQUFDUyxFQUFFLENBQUMxRyxRQUFRLENBQUMsZUFBZSxDQUFDLEVBQUU7TUFDckMsSUFBTThNLFdBQVcsR0FBRzdHLE1BQU0sQ0FBQ0ksSUFBSSxDQUFDMEcsT0FBTyxDQUFDLDBCQUEwQixDQUFDO01BQ25FLElBQUlELFdBQVcsRUFBRTtRQUNiQSxXQUFXLENBQUNoRCxLQUFLLENBQUNrRCxPQUFPLEdBQUcsTUFBTTtNQUN0QztJQUNKO0lBQ0EsSUFBSS9HLE1BQU0sQ0FBQ1MsRUFBRSxDQUFDMUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxFQUFFO01BQ3JDLElBQU04TSxZQUFXLEdBQUc3RyxNQUFNLENBQUNJLElBQUksQ0FBQzBHLE9BQU8sQ0FBQyxpQ0FBaUMsQ0FBQztNQUMxRSxJQUFJRCxZQUFXLEVBQUU7UUFDYkEsWUFBVyxDQUFDaEQsS0FBSyxDQUFDa0QsT0FBTyxHQUFHLE1BQU07TUFDdEM7SUFDSjtJQUNBO0lBQ0EsSUFBSUosTUFBTSxDQUFDdEIsU0FBUyxDQUFDQyxRQUFRLENBQUMsK0JBQStCLENBQUMsRUFBRTtNQUM1RHFCLE1BQU0sQ0FBQ3RCLFNBQVMsQ0FBQ0UsR0FBRyxDQUFDLHdCQUF3QixDQUFDO0lBQ2xEO0VBQ0osQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNETyxhQUFhLENBQUNwTCx1RUFBTyxDQUFDc00sU0FBUyxDQUFDaEIsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHVSxpQkFBaUI7QUFDL0RaLGFBQWEsQ0FBQ3BMLHVFQUFPLENBQUN1TSxLQUFLLENBQUNqQixRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUk5TSxFQUFFLElBQUtlLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDMkcsMERBQVcsQ0FBQzNILEVBQUUsQ0FBQyxDQUFDO0FBQ2xGO0FBQ0E7QUFDQTtBQUNBNE0sYUFBYSxDQUFDcEwsdUVBQU8sQ0FBQ3dNLGFBQWEsQ0FBQ2xCLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBR1IsV0FBVyxDQUFDLENBQzFELCtCQUErQixDQUNsQyxDQUFDO0FBQ0YsSUFBTTJCLGVBQWUsR0FBSUMsVUFBVSxJQUFLO0VBQ3BDLElBQU1DLGFBQWEsR0FBR0QsVUFBVSxDQUFDeEIsYUFBYSxLQUFBeEosTUFBQSxDQUFLZ0wsVUFBVSxDQUFDM0csRUFBRSxnQ0FBNkIsQ0FBQztFQUM5RixJQUFJNEcsYUFBYSxFQUFFO0lBQ2YsS0FBS3pFLDREQUFPLENBQUNlLE1BQU0sQ0FBQyxNQUFNO01BQ3RCMEQsYUFBYSxDQUFDaEMsU0FBUyxDQUFDRSxHQUFHLENBQUMsa0JBQWtCLENBQUM7SUFDbkQsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0Q7QUFDQSxJQUFNK0IsaUJBQWlCLEdBQUdBLENBQUNGLFVBQVUsRUFBRTdFLFVBQVUsS0FBSztFQUNsRCxJQUFNZ0YsYUFBYSxHQUFHLENBQ2xCLHVCQUF1QixFQUN2Qiw0QkFBNEIsRUFDNUIsdUJBQXVCLENBQzFCO0VBQ0QsT0FBTzNFLDREQUFPLENBQ1RXLE9BQU8sQ0FBQztJQUFBLElBQUFpRSxxQkFBQTtJQUFBLE9BQU1qRixVQUFVLElBQ3pCLENBQUM2RSxVQUFVLENBQUMvQixTQUFTLENBQUNDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFBa0MscUJBQUEsR0FDaERKLFVBQVUsQ0FBQ0ssYUFBYSxjQUFBRCxxQkFBQSx1QkFBeEJBLHFCQUFBLENBQTBCbkMsU0FBUyxDQUFDQyxRQUFRLENBQUMsbUJBQW1CLENBQUMsS0FDakVpQyxhQUFhLENBQUN4TixRQUFRLENBQUNxTixVQUFVLENBQUMzRyxFQUFFLENBQUM7RUFBQSxFQUFDLENBQ3JDNkIsSUFBSSxDQUFFb0YsWUFBWSxJQUFLO0lBQ3hCLElBQUlBLFlBQVksRUFBRTtNQUNkLE9BQU85RSw0REFBTyxDQUFDZSxNQUFNLENBQUMsTUFBTTtRQUFBLElBQUFnRSxzQkFBQTtRQUN4QixDQUFBQSxzQkFBQSxHQUFBUCxVQUFVLENBQUNLLGFBQWEsY0FBQUUsc0JBQUEsZUFBeEJBLHNCQUFBLENBQTBCdEMsU0FBUyxDQUFDRSxHQUFHLENBQUMsZ0NBQWdDLENBQUM7TUFDN0UsQ0FBQyxDQUFDO0lBQ047RUFDSixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1xQyxTQUFTLEdBQUlqRyxNQUFNLElBQUssSUFBSTFILE9BQU8sQ0FBRUMsT0FBTyxJQUFLO0VBQ25EO0VBQ0E7RUFDQSxJQUFNMk4sTUFBTSxHQUFHbEcsTUFBTSxDQUFDaUUsYUFBYSxDQUFDLGdDQUFnQyxDQUFDO0VBQ3JFMUwsT0FBTyxDQUFDLENBQUMsQ0FBQzJOLE1BQU0sQ0FBQztBQUNyQixDQUFDLENBQUM7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTS9HLFlBQVksR0FBR0EsQ0FBQ2QsTUFBTSxFQUFFOEgsb0JBQW9CLEtBQUs7RUFBQSxJQUFBQyxxQkFBQTtFQUNuRCxJQUFNQyxVQUFVLElBQUFELHFCQUFBLEdBQUdwTyxNQUFNLENBQUNxRSxRQUFRLENBQUNpSyxVQUFVLGNBQUFGLHFCQUFBLGdCQUFBQSxxQkFBQSxHQUExQkEscUJBQUEsQ0FBNEJHLGFBQWEsY0FBQUgscUJBQUEsdUJBQXpDQSxxQkFBQSxDQUEyQ0ksSUFBSSxDQUFFQyxXQUFXLElBQUtBLFdBQVcsQ0FBQ0MsTUFBTSxJQUFJckksTUFBTSxDQUFDUyxFQUFFLENBQUM7RUFDcEgsSUFBTTZILFVBQVUsR0FBRyxDQUFBTixVQUFVLGFBQVZBLFVBQVUsdUJBQVZBLFVBQVUsQ0FBRU8sS0FBSyxNQUFLLFNBQVM7RUFDbEQsSUFBSVQsb0JBQW9CLENBQUNVLFlBQVksS0FBSyxVQUFVLElBQUlGLFVBQVUsRUFBRTtJQUNoRSxJQUFNdEgsUUFBUSxHQUFHaEIsTUFBTSxDQUFDSSxJQUFJLENBQUNLLEVBQUU7SUFDL0JvRSw0RUFBbUIsQ0FBQzdELFFBQVEsRUFBRThHLG9CQUFvQixDQUFDVSxZQUFZLENBQUN4QyxRQUFRLENBQUMsQ0FBQyxDQUFDO0VBQy9FO0VBQ0FtQixlQUFlLENBQUNuSCxNQUFNLENBQUNJLElBQUksQ0FBQztFQUM1QixPQUFPd0gsU0FBUyxDQUFDNUgsTUFBTSxDQUFDSSxJQUFJLENBQUMsQ0FDeEJrQyxJQUFJLENBQUVDLFVBQVUsSUFBSztJQUFBLElBQUFrRyxxQkFBQTtJQUN0QixJQUFNcEcsa0JBQWtCLElBQUFvRyxxQkFBQSxHQUFHWCxvQkFBb0IsQ0FBQ3pGLGtCQUFrQixjQUFBb0cscUJBQUEsY0FBQUEscUJBQUEsR0FBSXpQLFNBQVM7SUFDL0UsSUFBTTBQLGdCQUFnQixHQUFHQSxDQUFBLEtBQU07TUFDM0IsSUFBSTFJLE1BQU0sQ0FBQzZCLElBQUksRUFBRTtRQUNiO0FBQ2hCO0FBQ0E7QUFDQTtRQUNnQjdCLE1BQU0sQ0FBQ2tDLGFBQWEsR0FBRyxLQUFLO1FBQzVCLElBQU15RyxZQUFZLEdBQUc3QyxhQUFhLENBQUM5RixNQUFNLENBQUM2QixJQUFJLENBQUNtRSxRQUFRLENBQUMsQ0FBQyxDQUFDO1FBQzFELE9BQU8vTCxPQUFPLENBQUNDLE9BQU8sQ0FBQ3lPLFlBQVksS0FBSzNQLFNBQVMsR0FDM0MyUCxZQUFZLENBQUMzSSxNQUFNLEVBQUU4SCxvQkFBb0IsQ0FBQyxHQUMxQzlILE1BQU0sQ0FBQ2tHLHNCQUFzQixDQUFDLENBQUMsQ0FBQztNQUMxQztNQUNBLE9BQU9qTSxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFDRCxJQUFNME8sZ0JBQWdCLEdBQUdBLENBQUEsS0FBTXJHLFVBQVUsR0FDbkNLLDREQUFPLENBQUNlLE1BQU0sQ0FBQyxNQUFNO01BQ25CM0QsTUFBTSxDQUFDSSxJQUFJLENBQUNpRixTQUFTLENBQUNFLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztJQUNsRCxDQUFDLENBQUMsR0FDQXRMLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7SUFDdkIsT0FBT3dPLGdCQUFnQixDQUFDLENBQUMsQ0FDcEJwRyxJQUFJLENBQUMsTUFBTXdDLHVFQUFpQixDQUFDOUUsTUFBTSxDQUFDSSxJQUFJLEVBQUVpQyxrQkFBa0IsQ0FBQyxDQUFDLENBQzlEQyxJQUFJLENBQUMsTUFBTWdGLGlCQUFpQixDQUFDdEgsTUFBTSxDQUFDSSxJQUFJLEVBQUVtQyxVQUFVLENBQUMsQ0FBQyxDQUN0REQsSUFBSSxDQUFDc0csZ0JBQWdCLENBQUMsQ0FDdEJ0RyxJQUFJLENBQUMsTUFBTUMsVUFBVSxDQUFDO0VBQy9CLENBQUMsQ0FBQyxDQUNHMEIsS0FBSyxDQUFFNEUsR0FBRyxJQUFLO0lBQ2hCakksb0VBQVcsQ0FBQ2lJLEdBQUcsRUFBRSxZQUFZLENBQUM7SUFDOUIsT0FBTzVPLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLEtBQUssQ0FBQztFQUNqQyxDQUFDLENBQUM7QUFDTixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2pMOEY7QUFDakM7QUFDSztBQUNQO0FBQ0M7QUFDSztBQUNJO0FBQ1A7QUFDRDtBQUNBO0FBQ0g7QUFDYztBQUNBO0FBQ1g7QUFDSztBQUNrQjtBQUNsQjtBQUNPO0FBQ0E7QUFDSTtBQUNLO0FBQ2Q7QUFDa0I7QUFDdkY7QUFDQSxJQUFNcVEsaUJBQWlCLEdBQUcsQ0FDdEJ0Qiw0RUFBZ0IsRUFDaEJjLHlFQUFrQixFQUNsQmIscURBQVksRUFDWkksdURBQWEsRUFDYlUsNkVBQW1CLEVBQ25CRyxnRUFBb0IsRUFDcEJELDhEQUFrQixFQUNsQlgsc0RBQWEsRUFDYmMsNERBQWUsRUFDZkMsc0VBQXVCLEVBQ3ZCRiw2RkFBeUIsRUFDekJQLDREQUFhLEVBQ2JWLHNFQUFnQjtBQUNoQjtBQUNBLE1BQU1TLDRFQUFhLENBQUMsQ0FBQyxDQUFDdEgsSUFBSSxDQUFDcUgsK0RBQWdCLENBQUMsRUFDNUNQLDJFQUFrQixFQUNsQkssd0RBQVMsRUFDVEosK0VBQW9CLEVBQ3BCTiw4RUFBcUIsRUFDckJrQiw4REFBa0IsRUFDbEJULHVFQUF1QixFQUN2QkUsbUZBQTBCLENBQzdCO0FBQ0QsSUFBTWMsdUJBQXVCLEdBQUdBLENBQUEsS0FBTTtFQUNsQyxJQUFJLENBQUMsQ0FBQzdRLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ3lNLFVBQVUsSUFBSSxDQUFDLENBQUM5USxNQUFNLENBQUNxRSxRQUFRLENBQUMwTSxVQUFVLEVBQUU7SUFDOUQsS0FBSzFCLDBFQUFjLENBQUN1QixpQkFBaUIsQ0FBQztFQUMxQyxDQUFDLE1BQ0k7SUFDRDVRLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQzJNLEtBQUssQ0FBQ2xNLElBQUksQ0FBQyxNQUFNdUssMEVBQWMsQ0FBQ3VCLGlCQUFpQixDQUFDLENBQUM7RUFDdkU7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RHNEO0FBQ3FDO0FBQzVGO0FBQ0E7QUFDQTtBQUNBLElBQU1PLHVCQUF1QixHQUFHQSxDQUFBLEtBQU07RUFDbEMsSUFBSUYsZ0VBQWUsQ0FBQ0MsaUdBQXNCLEVBQUUsZ0JBQWdCLENBQUMsRUFBRTtJQUMzRCxPQUFPLGdCQUFnQjtFQUMzQjtFQUNBLElBQUlELGdFQUFlLENBQUNDLGlHQUFzQixFQUFFLGlCQUFpQixDQUFDLEVBQUU7SUFDNUQsT0FBTyxpQkFBaUI7RUFDNUI7RUFDQSxJQUFJRCxnRUFBZSxDQUFDQyxpR0FBc0IsRUFBRSxTQUFTLENBQUMsRUFBRTtJQUNwRCxPQUFPLFNBQVM7RUFDcEI7RUFDQSxPQUFPN1IsU0FBUztBQUNwQixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTStSLHVCQUF1QixHQUFHblAsSUFBQSxJQUF3QjtFQUFBLElBQUFvUCxxQkFBQTtFQUFBLElBQXZCO0lBQUVDLE1BQU07SUFBRW5QO0VBQU8sQ0FBQyxHQUFBRixJQUFBO0VBQy9DLElBQU1zUCxhQUFhLEdBQUdKLHVCQUF1QixDQUFDLENBQUM7RUFDL0MsSUFBTUssY0FBYyxHQUFBcE8sYUFBQSxDQUFBQSxhQUFBO0lBQ2hCcU8sU0FBUyxFQUFFO01BQ1BDLGFBQWEsRUFBRSxtQkFBbUI7TUFDbEM1SyxFQUFFLEVBQUU7SUFDUixDQUFDO0lBQ0R3SztFQUFNLEdBQ0ZuUCxLQUFLLEdBQUc7SUFBRUE7RUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEdBQ3RCb1AsYUFBYSxHQUNYO0lBQ0VJLE1BQU0sRUFBRTtNQUNKQyxJQUFJLEVBQUUsd0JBQXdCO01BQzlCQyxPQUFPLEVBQUVOO0lBQ2I7RUFDSixDQUFDLEdBQ0MsQ0FBQyxDQUFDLENBQ1g7RUFDRCxDQUFBRixxQkFBQSxHQUFBclIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDeU4sS0FBSyxjQUFBVCxxQkFBQSxlQUFyQkEscUJBQUEsQ0FBdUJVLE1BQU0sQ0FBQztJQUFFUDtFQUFlLENBQUMsQ0FBQztBQUNyRCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTVEsbUJBQW1CLEdBQUdBLENBQUM5UCxHQUFHLEVBQUVDLEtBQUs7RUFBQSxJQUFBOFAsZUFBQSxFQUFBQyxPQUFBO0VBQUEsUUFBQUQsZUFBQSxHQUFLLENBQUFDLE9BQUEsR0FBQWxTLE1BQU0sRUFBQ21TLE9BQU8sY0FBQUYsZUFBQSx1QkFBZEEsZUFBQSxDQUFBRyxJQUFBLENBQUFGLE9BQUEsRUFBaUIsV0FBVyxFQUFFLEtBQUssRUFBRWhRLEdBQUcsRUFBRUMsS0FBSyxDQUFDO0FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqRGxCO0FBQ0M7QUFDM0U7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTW9RLFVBQVU7RUFBQSxJQUFBdFEsSUFBQSxHQUFBdVEsaUJBQUEsQ0FBRyxXQUFPWixJQUFJLEVBQUV0TCxJQUFJLEVBQUVtTSxlQUFlLEVBQUs7SUFDdEQsSUFBTUMsa0JBQWtCLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQ3RTLFFBQVEsQ0FBQ3dSLElBQUksQ0FBQztJQUNwRCxNQUFNUyxtRkFBaUIsQ0FBQy9MLElBQUksRUFBRW9NLGtCQUFrQixFQUFFRCxlQUFlLENBQUM7RUFDdEUsQ0FBQztFQUFBLGdCQUhLRixVQUFVQSxDQUFBSSxFQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQTtJQUFBLE9BQUE1USxJQUFBLENBQUE2USxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBR2Y7QUFDRDtBQUNBO0FBQ0E7QUFDQSxJQUFNQyxzQkFBc0IsR0FBR0EsQ0FBQSxLQUFNO0VBQ2pDdlMsUUFBUSxDQUFDb0ssZ0JBQWdCLENBQUMsZ0NBQWdDLEVBQUUsTUFBTTtJQUM5RCxLQUFLeUgsaUVBQWUsQ0FBQ0MsVUFBVSxDQUFDO0VBQ3BDLENBQUMsQ0FBQztFQUNGLE9BQU9ELGlFQUFlLENBQUNDLFVBQVUsQ0FBQztBQUN0QyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEJzRDtBQUNJO0FBQ1k7QUFDRDtBQUN0RSxJQUFNL0MsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTTtFQUMzQnhQLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQzZOLEdBQUcsQ0FBQ3BPLElBQUksQ0FBQyxNQUFNO0lBQzVCLElBQU1RLE1BQU0sR0FBR3RGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUM7SUFDeENBLE1BQU0sQ0FBQ3VGLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFb0ksK0VBQXNCLENBQUM3SyxnRUFBWSxDQUFDLENBQUM7SUFDaEY5QyxNQUFNLENBQUN1RixnQkFBZ0IsQ0FBQyxZQUFZLEVBQUVvSSwrRUFBc0IsQ0FBQzlNLDREQUFVLENBQUMsQ0FBQztJQUN6RWIsTUFBTSxDQUFDdUYsZ0JBQWdCLENBQUMsb0JBQW9CLEVBQUVDLGdGQUFzQixDQUFDLENBQUMsQ0FBQztFQUMzRSxDQUFDLENBQUM7RUFDRixPQUFPeEssT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNabUY7QUFDaEI7QUFDSjtBQUNNO0FBQ2tCO0FBQzdCO0FBQ0s7QUFDaEUsSUFBTWlULG9CQUFvQixHQUFHLENBQ3pCLENBQUMsaUJBQWlCLEVBQUVGLHVEQUFnQixDQUFDLEVBQ3JDLENBQUMsY0FBYyxFQUFFRCxvREFBYSxDQUFDLEVBQy9CLENBQUMsdUJBQXVCLEVBQUVMLHlFQUFzQixDQUFDLEVBQ2pELENBQUMsb0JBQW9CLEVBQUVPLHNFQUFtQixDQUFDLEVBQzNDLENBQUMsNEJBQTRCLEVBQUVKLHlGQUEyQixDQUFDLEVBQzNELENBQUMsa0JBQWtCLEVBQUVDLGlEQUFvQixDQUFDLENBQzdDO0FBQ00sSUFBTTNELGtCQUFrQjtFQUFBLElBQUF4TixJQUFBLEdBQUF1USxpQkFBQSxDQUFHLGFBQVk7SUFDMUMsT0FBT2xTLE9BQU8sQ0FBQ21ULEdBQUcsQ0FBQ0Qsb0JBQW9CLENBQUN4UixHQUFHO01BQUEsSUFBQTBSLEtBQUEsR0FBQWxCLGlCQUFBLENBQUMsV0FBQW5QLEtBQUEsRUFBd0I7UUFBQSxJQUFqQixDQUFDdU8sSUFBSSxFQUFFekMsSUFBSSxDQUFDLEdBQUE5TCxLQUFBO1FBQzNELElBQUk7VUFDQSxNQUFNOEwsSUFBSSxDQUFDLENBQUM7UUFDaEIsQ0FBQyxDQUNELE9BQU81RSxLQUFLLEVBQUU7VUFDVnRELG9FQUFXLENBQUNzRCxLQUFLLEVBQUUsWUFBWSxFQUFFO1lBQUVvSixHQUFHLEVBQUUvQjtVQUFLLENBQUMsQ0FBQztRQUNuRDtNQUNKLENBQUM7TUFBQSxpQkFBQWUsRUFBQTtRQUFBLE9BQUFlLEtBQUEsQ0FBQVosS0FBQSxPQUFBQyxTQUFBO01BQUE7SUFBQSxJQUFDLENBQUM7RUFDUCxDQUFDO0VBQUEsZ0JBVFl0RCxrQkFBa0JBLENBQUE7SUFBQSxPQUFBeE4sSUFBQSxDQUFBNlEsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQVM5QixDOzs7Ozs7Ozs7Ozs7Ozs7O0FDeEJ5RTtBQUMzQjtBQUMvQyxJQUFNYSxhQUFhLEdBQUl4TixLQUFLLElBQUs7RUFDN0IsT0FBTyxRQUFRLElBQUlBLEtBQUs7QUFDNUIsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTXlOLHNCQUFzQixHQUFHQSxDQUFBLEtBQU07RUFDakNwVCxRQUFRLENBQUNvSyxnQkFBZ0IsQ0FBQyx5QkFBeUIsRUFBR3pFLEtBQUssSUFBSztJQUM1RHBHLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQzZOLEdBQUcsQ0FBQ3BPLElBQUksQ0FBQyxNQUFNO01BQzVCLElBQUk4TyxhQUFhLENBQUN4TixLQUFLLENBQUMsRUFBRTtRQUN0QixJQUFNO1VBQUUwTixNQUFNO1VBQUVyQjtRQUFnQixDQUFDLEdBQUlyTSxLQUFLLENBQUUyTixNQUFNO1FBQ2xELElBQUk3TyxvREFBTSxDQUFDOE8sT0FBTyxDQUFDQyxHQUFHLENBQUNILE1BQU0sQ0FBQyxFQUFFO1VBQzVCO1FBQ0o7UUFDQSxJQUFNeE4sSUFBSSxHQUFHN0YsUUFBUSxDQUFDeVQsY0FBYyxDQUFDSixNQUFNLENBQUM7UUFDNUMsSUFBSXhOLElBQUksRUFBRTtVQUNOLEtBQUsrTCxtRkFBaUIsQ0FBQy9MLElBQUksRUFBRSxLQUFLLEVBQUVtTSxlQUFlLENBQUM7UUFDeEQ7TUFDSjtJQUNKLENBQUMsQ0FBQztFQUNOLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxJQUFNL0Msb0JBQW9CLEdBQUdBLENBQUEsS0FBTXBQLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDc1Qsc0JBQXNCLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQ2hCO0FBQ1E7QUFDUztBQUNWO0FBQ21CO0FBQ1o7QUFDSDtBQUNTO0FBQ2hCO0FBQ2U7QUFDbkI7QUFDQTtBQUNKO0FBQ3dCO0FBQ2hCO0FBQ2hFO0FBQ0E7QUFDQTtBQUNBakUsb0RBQWEsQ0FBQyxDQUNWa0Ysc0RBQUksRUFDSk4sK0RBQVMsRUFDVEYsbUVBQW9CLEVBQ3BCQyw2REFBYyxFQUNkRSxnRUFBaUIsRUFDakJFLGlFQUFlLEVBQ2ZDLHdEQUFNLEVBQ05QLDJEQUFTLEVBQ1RGLDJEQUFVLEVBQ1ZDLGdFQUFjLEVBQ2RNLHlEQUFRLEVBQ1JLLHNGQUFtQyxDQUN0QyxFQUFFLENBQUNGLHdEQUFNLEVBQUVHLDBEQUFRLENBQUMsQ0FBQztBQUN0QixJQUFNN0YsSUFBSSxHQUFHQSxDQUFBLEtBQU03TyxPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQ2M7QUFDbEQsSUFBTTJVLGNBQWMsR0FBSWhTLENBQUMsSUFBSztFQUMxQixJQUFJLE9BQU9BLENBQUMsQ0FBQ2lTLElBQUksS0FBSyxRQUFRLElBQzFCalMsQ0FBQyxDQUFDaVMsSUFBSSxLQUFLLElBQUksSUFDZixFQUFFLE1BQU0sSUFBSWpTLENBQUMsQ0FBQ2lTLElBQUksQ0FBQyxJQUNuQixFQUFFLE1BQU0sSUFBSWpTLENBQUMsQ0FBQ2lTLElBQUksQ0FBQyxFQUFFO0lBQ3JCLE9BQU8sS0FBSztFQUNoQjtFQUNBO0VBQ0EsSUFBTUEsSUFBSSxHQUFHalMsQ0FBQyxDQUFDaVMsSUFBSTtFQUNuQixPQUFPQSxJQUFJLENBQUNMLElBQUksS0FBSyxjQUFjLElBQUlLLElBQUksQ0FBQ0MsSUFBSSxDQUFDQyxjQUFjO0FBQ25FLENBQUM7QUFDRCxJQUFNQyxtQkFBbUIsR0FBSWxQLEtBQUssSUFBSztFQUNuQyxJQUFJNk8sMkRBQVcsQ0FBQ2pWLE1BQU0sQ0FBQ3VWLFNBQVMsQ0FBQyxJQUM3Qk4sMkRBQVcsQ0FBQ2pWLE1BQU0sQ0FBQ3VWLFNBQVMsQ0FBQ0MsS0FBSyxDQUFDLElBQ25DLENBQUNOLGNBQWMsQ0FBQzlPLEtBQUssQ0FBQyxFQUFFO0lBQ3hCO0VBQ0o7RUFDQSxJQUFNO0lBQUVnUCxJQUFJO0lBQUVLO0VBQUssQ0FBQyxHQUFHclAsS0FBSyxDQUFDK08sSUFBSTtFQUNqQztBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSSxJQUFNTyxjQUFjLEdBQUc7SUFDbkJDLE1BQU0sRUFBRTtNQUNKN08sRUFBRSxFQUFFc08sSUFBSSxDQUFDUSxNQUFNO01BQ2ZkLElBQUksRUFBRU0sSUFBSSxDQUFDTixJQUFJO01BQ2ZlLFFBQVEsRUFBRTtJQUNkLENBQUM7SUFDREMsUUFBUSxFQUFFO01BQ05DLElBQUksRUFBRVgsSUFBSSxDQUFDWTtJQUNmLENBQUM7SUFDREMsTUFBTSxFQUFFO01BQ0pGLElBQUksRUFBRU4sSUFBSSxDQUFDUyxLQUFLO01BQ2hCQyxJQUFJLEVBQUVWLElBQUksQ0FBQ1csQ0FBQyxJQUFJLEdBQUc7TUFDbkJDLElBQUksRUFBRVosSUFBSSxDQUFDYSxDQUFDLElBQUksR0FBRztNQUNuQkMsZ0JBQWdCLEVBQUVkLElBQUksQ0FBQ2UsUUFBUSxJQUFJLEVBQUU7TUFDckNDLGNBQWMsRUFBRWhCLElBQUksQ0FBQ2lCLFFBQVEsSUFBSSxDQUFDO01BQ2xDQyxRQUFRLEVBQUVsQixJQUFJLENBQUN0VCxLQUFLLElBQUksR0FBRztNQUMzQnlVLElBQUksRUFBRW5CLElBQUksQ0FBQ21CLElBQUksSUFBSTtJQUN2QjtFQUNKLENBQUM7RUFDRDVXLE1BQU0sQ0FBQ3VWLFNBQVMsQ0FBQ0MsS0FBSyxDQUFDLGdCQUFnQixFQUFFRSxjQUFjLENBQUM7RUFDeERqVSxtREFBRyxDQUFDLFlBQVksbURBQUFnQixNQUFBLENBQW1EMlMsSUFBSSxDQUFDUSxNQUFNLENBQUUsQ0FBQztFQUNqRm5VLG1EQUFHLENBQUMsWUFBWSxFQUFFaVUsY0FBYyxDQUFDO0FBQ3JDLENBQUM7QUFDRCxJQUFNN0YsdUJBQXVCLEdBQUdBLENBQUEsS0FBTXZQLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDUCxNQUFNLENBQUM2SyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUV5SyxtQkFBbUIsQ0FBQyxDQUFDO0FBQzlHO0FBQ08sSUFBTXRRLENBQUMsR0FBRztFQUNia1E7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcERvRTtBQUNOO0FBQzlCO0FBQ3VCO0FBQ1c7QUFDRTtBQUNqQjtBQUNpQjtBQUNyRSxJQUFNb0MsWUFBWSxHQUFHQSxDQUFBO0VBQUEsSUFBQXJWLElBQUE7RUFBQSxRQUNyQjtJQUFBLENBQUFBLElBQUEsR0FDQyxDQUFDaVYsd0VBQWtCLENBQUNLLGVBQWUsSUFDaEMsQ0FBQ0osOEVBQWEsQ0FBQyxDQUFDLElBQ2hCblgsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNrVCxRQUFRLENBQUNDLGVBQWUsSUFDL0NQLHdFQUFrQixDQUFDUSxtQkFBbUIsSUFDdEMsQ0FBQ1Isd0VBQWtCLENBQUNqVSxNQUFNLElBQzFCLENBQUNqRCxNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDb1QsV0FBVyxJQUN4QyxDQUFDZCxtRkFBVSxDQUFDLENBQUMsY0FBQTVVLElBQUEsY0FBQUEsSUFBQSxHQUNiO0VBQUs7QUFBQTtBQUNULElBQU0yVixPQUFPLEdBQUdBLENBQUEsS0FBTTtFQUNsQixJQUFJTixZQUFZLENBQUMsQ0FBQyxJQUFJRCwwRUFBbUIsRUFBRTtJQUN2QztJQUNBSiwrREFBUSxDQUFDLENBQUM7SUFDVkcseURBQUUsQ0FBQ1MsVUFBVSxDQUFDLENBQUM7RUFDbkI7RUFDQSxPQUFPdlgsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDO0FBQ0QsSUFBTXVYLFdBQVcsR0FBR2QscURBQUksQ0FBQ1ksT0FBTyxDQUFDO0FBQ2pDO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTXpJLElBQUksR0FBR0EsQ0FBQSxLQUFNNEgseURBQVMsQ0FBQyxDQUFDLENBQ2hDcE8sSUFBSSxDQUFFOUYsWUFBWSxJQUFLO0VBQ3hCLElBQUlpVSw2REFBYSxDQUFDLElBQUksRUFBRWpVLFlBQVksQ0FBQyxFQUFFO0lBQ25DLE9BQU9pVixXQUFXLENBQUMsQ0FBQztFQUN4QjtFQUNBLE1BQU0vUCxLQUFLLENBQUMsbUJBQW1CLENBQUM7QUFDcEMsQ0FBQyxDQUFDLENBQ0d1QyxLQUFLLENBQUVwSCxDQUFDLElBQUs7RUFDZHpCLG1EQUFHLENBQUMsWUFBWSxFQUFFLHlCQUF5QixFQUFFeUIsQ0FBQyxDQUFDO0FBQ25ELENBQUMsQ0FBQztBQUNLLElBQU04QixDQUFDLEdBQUc7RUFDYjRTO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7O0FDM0NvQztBQUNlO0FBQ3BELElBQU1HLDBCQUEwQixHQUFJM1IsS0FBSyxJQUFLO0VBQzFDLElBQU00UixzQkFBc0IsR0FBSTlVLENBQUMsSUFBSyxPQUFPQSxDQUFDLEtBQUssUUFBUSxJQUN2RCxZQUFZLElBQUlBLENBQUMsSUFDakIsYUFBYSxJQUFJQSxDQUFDLElBQ2xCLFlBQVksSUFBSUEsQ0FBQztFQUNyQixJQUFJOFUsc0JBQXNCLENBQUM1UixLQUFLLENBQUMsRUFBRTtJQUMvQixJQUFJQSxLQUFLLENBQUM2UixVQUFVLEVBQUU7TUFDbEJ4VyxtREFBRyxDQUFDLFlBQVksRUFBRSx1REFBdUQsQ0FBQztNQUMxRTJQLGlFQUF1QixDQUFDO1FBQUVFLE1BQU0sRUFBRSxRQUFRO1FBQUVuUCxLQUFLLEVBQUU7TUFBVSxDQUFDLENBQUM7SUFDbkU7SUFDQSxJQUFJaUUsS0FBSyxDQUFDOFIsV0FBVyxFQUFFO01BQ25CelcsbURBQUcsQ0FBQyxZQUFZLEVBQUUsOEVBQThFLENBQUM7TUFDakcyUCxpRUFBdUIsQ0FBQztRQUFFRSxNQUFNLEVBQUUsUUFBUTtRQUFFblAsS0FBSyxFQUFFO01BQWMsQ0FBQyxDQUFDO0lBQ3ZFO0lBQ0EsSUFBSWlFLEtBQUssQ0FBQytSLFVBQVUsRUFBRTtNQUNsQjFXLG1EQUFHLENBQUMsWUFBWSxFQUFFLGtFQUFrRSxDQUFDO0lBQ3pGO0VBQ0osQ0FBQyxNQUNJO0lBQ0RBLG1EQUFHLENBQUMsWUFBWSxzRkFBQWdCLE1BQUEsQ0FBdUUyVixJQUFJLENBQUNDLFNBQVMsQ0FBQ2pTLEtBQUssQ0FBQyxDQUFFLENBQUM7RUFDbkg7QUFDSixDQUFDO0FBQ0QsSUFBTWtTLHlCQUF5QixHQUFJbFMsS0FBSyxJQUFLO0VBQ3pDLElBQU1tUyxxQkFBcUIsR0FBSXJWLENBQUMsSUFBSyxPQUFPQSxDQUFDLEtBQUssUUFBUSxJQUN0RCxhQUFhLElBQUlBLENBQUMsSUFDbEIsV0FBVyxJQUFJQSxDQUFDLElBQ2hCLGlCQUFpQixJQUFJQSxDQUFDO0VBQzFCLElBQUlxVixxQkFBcUIsQ0FBQ25TLEtBQUssQ0FBQyxFQUFFO0lBQzlCM0UsbURBQUcsQ0FBQyxZQUFZLHNEQUFBZ0IsTUFBQSxDQUF1QzJELEtBQUssQ0FBQ29TLFdBQVcsQ0FBRSxDQUFDO0lBQzNFcEgsaUVBQXVCLENBQUM7TUFBRUUsTUFBTSxFQUFFLE1BQU07TUFBRW5QLEtBQUssRUFBRWlFLEtBQUssQ0FBQ29TO0lBQVksQ0FBQyxDQUFDO0VBQ3pFLENBQUMsTUFDSTtJQUNEL1csbURBQUcsQ0FBQyxZQUFZLHFGQUFBZ0IsTUFBQSxDQUFzRTJWLElBQUksQ0FBQ0MsU0FBUyxDQUFDalMsS0FBSyxDQUFDLENBQUUsQ0FBQztFQUNsSDtBQUNKLENBQUM7QUFDRCxJQUFNcVMsNkJBQTZCLEdBQUlyUyxLQUFLLElBQUs7RUFDN0MsSUFBTXNTLHlCQUF5QixHQUFJeFYsQ0FBQyxJQUFLLE9BQU9BLENBQUMsS0FBSyxRQUFRLElBQUksYUFBYSxJQUFJQSxDQUFDLElBQUksaUJBQWlCLElBQUlBLENBQUM7RUFDOUcsSUFBSXdWLHlCQUF5QixDQUFDdFMsS0FBSyxDQUFDLEVBQUU7SUFDbEMzRSxtREFBRyxDQUFDLFlBQVksNENBQUFnQixNQUFBLENBQTZCMkQsS0FBSyxDQUFDb1MsV0FBVyxtQkFBZ0IsQ0FBQztJQUMvRXBILGlFQUF1QixDQUFDO01BQUVFLE1BQU0sRUFBRSxPQUFPO01BQUVuUCxLQUFLLEVBQUVpRSxLQUFLLENBQUNvUztJQUFZLENBQUMsQ0FBQztFQUMxRSxDQUFDLE1BQ0k7SUFDRC9XLG1EQUFHLENBQUMsWUFBWSx5RkFBQWdCLE1BQUEsQ0FBMEUyVixJQUFJLENBQUNDLFNBQVMsQ0FBQ2pTLEtBQUssQ0FBQyxDQUFFLENBQUM7RUFDdEg7QUFDSixDQUFDO0FBQ0QsSUFBTXVTLHVCQUF1QixHQUFJeEcsT0FBTyxJQUFLO0VBQ3pDQSxPQUFPLENBQUMsT0FBTyxFQUFFLGtCQUFrQixFQUFFLFVBQVUvTCxLQUFLLEVBQUU7SUFDbEQyUiwwQkFBMEIsQ0FBQzNSLEtBQUssQ0FBQztFQUNyQyxDQUFDLENBQUM7RUFDRitMLE9BQU8sQ0FBQyxPQUFPLEVBQUUsaUJBQWlCLEVBQUUsVUFBVS9MLEtBQUssRUFBRTtJQUNqRGtTLHlCQUF5QixDQUFDbFMsS0FBSyxDQUFDO0VBQ3BDLENBQUMsQ0FBQztFQUNGK0wsT0FBTyxDQUFDLE9BQU8sRUFBRSxxQkFBcUIsRUFBRSxVQUFVL0wsS0FBSyxFQUFFO0lBQ3JEcVMsNkJBQTZCLENBQUNyUyxLQUFLLENBQUM7RUFDeEMsQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU0ySiwwQkFBMEIsR0FBR0EsQ0FBQSxLQUFNO0VBQ3JDO0VBQ0E7RUFDQS9QLE1BQU0sQ0FBQ21TLE9BQU8sR0FDVm5TLE1BQU0sQ0FBQ21TLE9BQU8sSUFDVixZQUFZO0lBQ1I7SUFDQSxDQUFDQSxPQUFPLENBQUN5RyxDQUFDLEdBQUd6RyxPQUFPLENBQUN5RyxDQUFDLElBQUksRUFBRSxFQUFFOVQsSUFBSSxDQUFDaU8sU0FBUyxDQUFDO0VBQ2pELENBQUM7RUFDVDtFQUNBLEtBQUs0Rix1QkFBdUIsQ0FBQzNZLE1BQU0sQ0FBQ21TLE9BQU8sQ0FBQztFQUM1QyxPQUFPN1IsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMvRWtFO0FBQ1E7QUFDUjtBQUNLO0FBQ1o7QUFDa0I7QUFDakM7QUFDYTtBQUMxRCxJQUFNNlksZ0JBQWdCLEdBQUdBLENBQUN2VyxZQUFZLEVBQUVFLFVBQVUsS0FBS2pCLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDaVgscUVBQWdCLENBQUNuVyxZQUFZLEVBQUVFLFVBQVUsQ0FBQyxDQUFDLENBQUNnRCxPQUFPLENBQUM5RCxJQUFBLElBQWtCO0VBQUEsSUFBakIsQ0FBQ0MsR0FBRyxFQUFFQyxLQUFLLENBQUMsR0FBQUYsSUFBQTtFQUNuSSxJQUFJLENBQUNFLEtBQUssRUFDTjtFQUNKbkMsTUFBTSxDQUFDcUYsU0FBUyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDK1QsWUFBWSxDQUFDblgsR0FBRyxFQUFFQyxLQUFLLENBQUM7QUFDdEQsQ0FBQyxDQUFDO0FBQ0Y7QUFDQTtBQUNBO0FBQ0EsSUFBTW1YLHNCQUFzQixHQUFHQSxDQUFBLEtBQU07RUFDakMsS0FBS1IsaUVBQWMsQ0FBQyxDQUFDLENBQUNuUSxJQUFJLENBQUU0USxXQUFXLElBQUs7SUFDeEMsSUFBSUEsV0FBVyxLQUFLLElBQUksRUFBRTtNQUN0QnZaLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ2dVLHNCQUFzQixDQUFDQyxXQUFXLENBQUM7SUFDakU7RUFDSixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBTUMseUJBQXlCLEdBQUdBLENBQUEsS0FBTTtFQUNwQyxJQUFJLHdCQUF3QixJQUFJQyxTQUFTLEVBQUU7SUFBQSxJQUFBQyxxQkFBQTtJQUN2QyxPQUFBQSxxQkFBQSxHQUFLRCxTQUFTLENBQUNFLHNCQUFzQixjQUFBRCxxQkFBQSx1QkFBaENBLHFCQUFBLENBQWtDRSxRQUFRLENBQUMsQ0FBQyxDQUFDalIsSUFBSSxDQUFFeEcsS0FBSyxJQUFLO01BQzlELElBQU13WCxzQkFBc0IsR0FBR3hYLEtBQUssSUFBSSxPQUFPO01BQy9DbkMsTUFBTSxDQUFDcUYsU0FBUyxDQUNYQyxNQUFNLENBQUMsQ0FBQyxDQUNSK1QsWUFBWSxDQUFDLHdCQUF3QixFQUFFTSxzQkFBc0IsQ0FBQztJQUN2RSxDQUFDLENBQUM7RUFDTjtBQUNKLENBQUM7QUFDRCxJQUFNRSxlQUFlLEdBQUloWCxZQUFZLElBQUs7RUFDdEMsSUFBSUEsWUFBWSxDQUFDaVgsU0FBUyxFQUFFO0lBQ3hCOVosTUFBTSxDQUFDcUYsU0FBUyxDQUFDNk4sR0FBRyxDQUFDcE8sSUFBSSxDQUFDd1Usc0JBQXNCLENBQUM7SUFDakR0WixNQUFNLENBQUNxRixTQUFTLENBQUM2TixHQUFHLENBQUNwTyxJQUFJLENBQUMwVSx5QkFBeUIsQ0FBQztJQUNwRHhaLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQzZOLEdBQUcsQ0FBQ3BPLElBQUksQ0FBQ21VLG1GQUE2QixDQUFDO0VBQzVEO0FBQ0osQ0FBQztBQUNELElBQU1jLGtCQUFrQixHQUFJbFgsWUFBWSxJQUFLaVUsNkRBQWEsQ0FBQyxXQUFXLEVBQUVqVSxZQUFZLENBQUM7QUFDckYsSUFBTW1YLGVBQWUsR0FBSW5YLFlBQVksSUFBSztFQUN0QyxJQUFJQSxZQUFZLENBQUNvWCxLQUFLLEVBQUU7SUFDcEIsT0FBT0Ysa0JBQWtCLENBQUNsWCxZQUFZLENBQUM7RUFDM0M7RUFDQSxPQUFPLElBQUk7QUFDZixDQUFDO0FBQ0QsSUFBTXFYLHVCQUF1QixHQUFJclgsWUFBWSxJQUFLO0VBQzlDLElBQUlBLFlBQVksQ0FBQ3NYLEtBQUssRUFBRTtJQUNwQjtJQUNBbmEsTUFBTSxDQUFDcUYsU0FBUyxDQUFDNk4sR0FBRyxDQUFDcE8sSUFBSSxDQUFDLE1BQU07TUFDNUI5RSxNQUFNLENBQUNxRixTQUFTLENBQUNDLE1BQU0sQ0FBQyxDQUFDLENBQUM4VSxrQkFBa0IsQ0FBQztRQUN6Q0Msc0JBQXNCLEVBQUUsQ0FBQ3hYLFlBQVksQ0FBQ2lYO01BQzFDLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQztFQUNOLENBQUMsTUFDSSxJQUFJalgsWUFBWSxDQUFDeVgsR0FBRyxFQUFFO0lBQ3ZCO0lBQ0F0YSxNQUFNLENBQUNxRixTQUFTLENBQUM2TixHQUFHLENBQUNwTyxJQUFJLENBQUMsTUFBTTtNQUM1QjlFLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQzhVLGtCQUFrQixDQUFDO1FBQ3pDRyxrQkFBa0IsRUFBRSxDQUFDUixrQkFBa0IsQ0FBQ2xYLFlBQVk7TUFDeEQsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ00sSUFBTXNNLElBQUksR0FBR0EsQ0FBQSxLQUFNO0VBQ3RCLElBQU1xTCxnQkFBZ0I7SUFBQSxJQUFBblgsS0FBQSxHQUFBbVAsaUJBQUEsQ0FBRyxhQUFZO01BQ2pDLElBQU0zUCxZQUFZLFNBQVNrVSx5REFBUyxDQUFDLENBQUM7TUFDdENqVyw2RUFBVSxDQUFDaUssR0FBRyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLG9CQUFvQixDQUFDO01BQzNDLElBQU15UCxNQUFNLEdBQUdULGVBQWUsQ0FBQ25YLFlBQVksQ0FBQztNQUM1Q2dYLGVBQWUsQ0FBQ2hYLFlBQVksQ0FBQztNQUM3QnFYLHVCQUF1QixDQUFDclgsWUFBWSxDQUFDO01BQ3JDO01BQ0E7TUFDQSxJQUFJNFgsTUFBTSxFQUFFO1FBQUEsSUFBQUMscUJBQUEsRUFBQUMsc0JBQUE7UUFDUixJQUFNNVgsVUFBVSxTQUFTZ1csaUVBQWMsQ0FBQyxDQUFDO1FBQ3pDL1ksTUFBTSxDQUFDcUYsU0FBUyxDQUFDNk4sR0FBRyxDQUFDcE8sSUFBSSxDQUFDLE1BQU1oRSw2RUFBVSxDQUFDaUssR0FBRyxDQUFDLENBQUMsQ0FBQ0MsSUFBSSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsTUFBTW9PLGdCQUFnQixDQUFDdlcsWUFBWSxFQUFFRSxVQUFVLENBQUM7UUFDM0g7UUFDQTtRQUNBO1FBQ0EsTUFBTSxLQUFLb1csdUVBQXFCLENBQUMsQ0FBQyxDQUFDO1FBQ25DO1FBQ0E7UUFDQTtRQUNBTiwwREFBVSxFQUFBNkIscUJBQUEsSUFBQUMsc0JBQUEsR0FBQzNhLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNxVyxJQUFJLGNBQUFELHNCQUFBLHVCQUFoQ0Esc0JBQUEsQ0FBa0N0VixTQUFTLGNBQUFxVixxQkFBQSxjQUFBQSxxQkFBQSxHQUNsRCxnREFBZ0QsRUFBRTtVQUFFRyxLQUFLLEVBQUU7UUFBTSxDQUFDLENBQUMsQ0FBQ3ZRLEtBQUssQ0FBRUMsS0FBSyxJQUFLO1VBQ3JGLElBQUlrUCxTQUFTLENBQUNxQixTQUFTLENBQUMxYSxRQUFRLENBQUMsWUFBWSxDQUFDLElBQzFDcVosU0FBUyxDQUFDcUIsU0FBUyxDQUFDMWEsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQ3JDcUIsbURBQUcsQ0FBQyxZQUFZLEVBQUUsMENBQTBDLEVBQUU4SSxLQUFLLENBQUM7VUFDeEUsQ0FBQyxNQUNJO1lBQ0QsTUFBTUEsS0FBSztVQUNmO1FBQ0osQ0FBQyxDQUFDO01BQ047SUFDSixDQUFDO0lBQUEsZ0JBN0JLaVEsZ0JBQWdCQSxDQUFBO01BQUEsT0FBQW5YLEtBQUEsQ0FBQXlQLEtBQUEsT0FBQUMsU0FBQTtJQUFBO0VBQUEsR0E2QnJCO0VBQ0QsSUFBSW1FLHdFQUFrQixDQUFDUSxtQkFBbUIsRUFBRTtJQUN4QyxPQUFROEMsZ0JBQWdCLENBQUM7SUFDckI7SUFBQSxDQUNDbFEsS0FBSyxDQUFDNE8sc0RBQVcsQ0FBQztFQUMzQjtFQUNBLE9BQU9BLDBEQUFXLENBQUMsQ0FBQztBQUN4QixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekdvQztBQUNzQjtBQUMzRCxJQUFNN1EsT0FBTyxHQUFJbEcsS0FBSyxJQUFLQSxLQUFLLEtBQUssRUFBRSxJQUNuQ0EsS0FBSyxLQUFLLElBQUksSUFDZCxPQUFPQSxLQUFLLEtBQUssV0FBVyxJQUMzQkUsS0FBSyxDQUFDQyxPQUFPLENBQUNILEtBQUssQ0FBQyxJQUFJQSxLQUFLLENBQUN5RCxNQUFNLEtBQUssQ0FBRSxJQUMzQyxPQUFPekQsS0FBSyxLQUFLLFFBQVEsSUFBSUwsTUFBTSxDQUFDaVosSUFBSSxDQUFDNVksS0FBSyxDQUFDLENBQUN5RCxNQUFNLEtBQUssQ0FBRTtBQUNsRSxJQUFNb1YsV0FBVyxHQUFJQyxPQUFPLElBQUs7RUFDN0IsSUFBSS9ZLEdBQUc7RUFDUCxLQUFLQSxHQUFHLElBQUkrWSxPQUFPLEVBQUU7SUFDakIsSUFBSSxPQUFPQSxPQUFPLENBQUMvWSxHQUFHLENBQUMsS0FBSyxRQUFRLEVBQUU7TUFDbEM4WSxXQUFXLENBQUNDLE9BQU8sQ0FBQy9ZLEdBQUcsQ0FBQyxDQUFDO0lBQzdCO0lBQ0EsSUFBSW1HLE9BQU8sQ0FBQzRTLE9BQU8sQ0FBQy9ZLEdBQUcsQ0FBQyxDQUFDLEVBQUU7TUFDdkIsT0FBTytZLE9BQU8sQ0FBQy9ZLEdBQUcsQ0FBQztJQUN2QjtFQUNKO0VBQ0EsT0FBTytZLE9BQU87QUFDbEIsQ0FBQztBQUNELElBQU1DLGVBQWUsR0FBR2paLElBQUEsSUFBcUI7RUFBQSxJQUFwQjtJQUFFc0MsSUFBSTtJQUFFNFc7RUFBTSxDQUFDLEdBQUFsWixJQUFBO0VBQ3BDLElBQU07SUFBRW1aLGFBQWE7SUFBRTNXLE1BQU07SUFBRTRXLFFBQVE7SUFBRUMsV0FBVztJQUFFQyxPQUFPO0lBQUVDLE1BQU07SUFBRUMsUUFBUTtJQUFFQyxrQkFBa0I7SUFBRUMsTUFBTTtJQUFFQyxPQUFPO0lBQUVDO0VBQVMsQ0FBQyxHQUFHdFgsSUFBSTtFQUN2SSxJQUFNdVgsV0FBVyxHQUFHLENBQUNOLE1BQU0sSUFBSSxPQUFPQSxNQUFNLEtBQUssUUFBUSxHQUFHQSxNQUFNLENBQUNPLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBRyxFQUFFLEVBQUUvWixHQUFHLENBQUVnYSxHQUFHLElBQUtBLEdBQUcsQ0FBQ0MsSUFBSSxDQUFDLENBQUMsQ0FBQztFQUM1RyxJQUFNQyxZQUFZLEdBQUcsQ0FBQ1QsUUFBUSxJQUFJLE9BQU9BLFFBQVEsS0FBSyxRQUFRLEdBQUdBLFFBQVEsQ0FBQ00sS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRS9aLEdBQUcsQ0FBRWdhLEdBQUcsSUFBS0EsR0FBRyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQ25ILElBQU1FLGVBQWUsR0FBR1Qsa0JBQWtCLElBQUksT0FBT0Esa0JBQWtCLEtBQUssUUFBUSxHQUM5RSxJQUFJVSxJQUFJLENBQUNWLGtCQUFrQixDQUFDLENBQUNXLFdBQVcsQ0FBQyxDQUFDLEdBQzFDLEVBQUU7RUFDUixJQUFNQyxXQUFXLEdBQUcsQ0FBQ1QsT0FBTyxJQUFJLE9BQU9BLE9BQU8sS0FBSyxRQUFRLEdBQUdBLE9BQU8sQ0FBQ0UsS0FBSyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRS9aLEdBQUcsQ0FBRWdhLEdBQUcsSUFBS0EsR0FBRyxDQUFDQyxJQUFJLENBQUMsQ0FBQyxDQUFDO0VBQy9HLElBQU1NLFlBQVksR0FBR3ZCLFdBQVcsQ0FBQztJQUM3QndCLE9BQU8sRUFBRTtNQUNMQyxPQUFPLEVBQUVyQixhQUFhO01BQ3RCdFUsRUFBRSxFQUFFckMsTUFBTTtNQUNWaVksS0FBSyxFQUFFckIsUUFBUTtNQUNmdkcsSUFBSSxFQUFFd0csV0FBVztNQUNqQkMsT0FBTztNQUNQb0IsT0FBTyxFQUFFYixXQUFXO01BQ3BCTCxRQUFRLEVBQUVTLFlBQVk7TUFDdEJVLFdBQVcsRUFBRVQsZUFBZTtNQUM1QlIsTUFBTTtNQUNOa0IsSUFBSSxFQUFFUDtJQUNWLENBQUM7SUFDRG5CLElBQUksRUFBRTtNQUNGUyxPQUFPO01BQ1BrQixRQUFRLEVBQUV6VSxPQUFPLENBQUM4UyxJQUFJLENBQUMsR0FBRyxLQUFLLEdBQUcsQ0FBQzlTLE9BQU8sQ0FBQzhTLElBQUksYUFBSkEsSUFBSSx1QkFBSkEsSUFBSSxDQUFFclUsRUFBRTtJQUN2RDtFQUNKLENBQUMsQ0FBQztFQUNGLE9BQU95VixZQUFZO0FBQ3ZCLENBQUM7QUFDRCxJQUFNUSwyQkFBMkIsR0FBSXpZLE1BQU0sSUFBSztFQUM1QyxJQUFJLE9BQU9BLE1BQU0sQ0FBQ3dOLEtBQUssS0FBSyxRQUFRLElBQ2hDLE9BQU94TixNQUFNLENBQUN3TixLQUFLLENBQUNrTCxTQUFTLEtBQUssUUFBUSxJQUMxQzFZLE1BQU0sQ0FBQ3dOLEtBQUssQ0FBQ2tMLFNBQVMsQ0FBQ3BYLE1BQU0sR0FBRyxDQUFDLEVBQUU7SUFDbkMsT0FBTyxDQUFDO01BQUUrTixHQUFHLEVBQUUsT0FBTztNQUFFN00sRUFBRSxFQUFFeEMsTUFBTSxDQUFDd04sS0FBSyxDQUFDa0w7SUFBVSxDQUFDLENBQUM7RUFDekQ7RUFDQSxPQUFPLEVBQUU7QUFDYixDQUFDO0FBQ0QsSUFBTUMsWUFBWSxHQUFHQSxDQUFDQyxVQUFVLEVBQUVDLGVBQWUsS0FBSztFQUNsRCxJQUFJO0lBQ0EsSUFBSSxFQUFDQSxlQUFlLGFBQWZBLGVBQWUsZUFBZkEsZUFBZSxDQUFFQyxLQUFLLEdBQUU7TUFDekIsTUFBTSxJQUFJclYsS0FBSyxDQUFDLDhCQUE4QixDQUFDO0lBQ25EO0lBQ0EsSUFBTXNWLG1CQUFtQixHQUFHTiwyQkFBMkIsQ0FBQ0csVUFBVSxDQUFDO0lBQ25FLElBQUlDLGVBQWUsQ0FBQ0csUUFBUSxJQUFJRCxtQkFBbUIsQ0FBQ3pYLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDNUR1WCxlQUFlLENBQUNHLFFBQVEsQ0FBQ0QsbUJBQW1CLENBQUM7SUFDakQ7SUFDQSxJQUFNcEMsT0FBTyxHQUFHQyxlQUFlLENBQUNnQyxVQUFVLENBQUM7SUFDM0NDLGVBQWUsQ0FBQ0MsS0FBSyxDQUFDLEtBQUssRUFBRTtNQUN6QjdZLElBQUksRUFBRTBXO0lBQ1YsQ0FBQyxDQUFDO0VBQ04sQ0FBQyxDQUNELE9BQU8vTCxHQUFHLEVBQUU7SUFDUmpJLG9FQUFXLENBQUNpSSxHQUFHLEVBQUUsWUFBWSxDQUFDO0VBQ2xDO0FBQ0osQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNcU8seUJBQXlCLEdBQUdBLENBQUEsS0FBTTtFQUNwQzliLG1EQUFHLENBQUMsWUFBWSxFQUFFLHFDQUFxQyxDQUFDO0VBQ3hEO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQSxDQUFDLFVBQVUrYixDQUFDLEVBQUV0YSxDQUFDLEVBQUV1YSxDQUFDLEVBQUVDLENBQUMsRUFBRUMsQ0FBQyxFQUFFO0lBQ3RCLElBQUksQ0FBQ3phLENBQUMsRUFBRTtNQUNGQSxDQUFDLEdBQUdBLENBQUMsSUFBSSxDQUFDLENBQUMsRUFDUmxELE1BQU0sQ0FBQ3VWLFNBQVMsR0FBR3JTLENBQUMsRUFDcEJBLENBQUMsQ0FBQzBWLENBQUMsR0FBRyxFQUFFLEVBQ1IxVixDQUFDLENBQUNvQixNQUFNLEdBQUdxWixDQUFDLElBQUksQ0FBQyxDQUFDLEVBQ2xCemEsQ0FBQyxDQUFDb0IsTUFBTSxDQUFDc1osU0FBUyxHQUFHSCxDQUFDLEVBQ3RCdmEsQ0FBQyxDQUFDb0IsTUFBTSxDQUFDdVosTUFBTSxHQUFHSCxDQUFDLEVBQ25CeGEsQ0FBQyxDQUFDb0IsTUFBTSxDQUFDd1osV0FBVyxHQUFHNWEsQ0FBQyxDQUFDb0IsTUFBTSxDQUFDd1osV0FBVyxJQUFJLFlBQWE7TUFDakUsS0FBSyxJQUFJQyxDQUFDLEdBQUcsQ0FDVCxPQUFPLEVBQ1AsVUFBVSxFQUNWLE9BQU8sRUFDUCxTQUFTLEVBQ1QsT0FBTyxFQUNQLFNBQVMsRUFDVCxVQUFVLEVBQ1YsT0FBTyxFQUNQLElBQUksRUFDSixNQUFNLEVBQ04sTUFBTSxFQUNOLFNBQVMsQ0FDWixFQUFFQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdELENBQUMsQ0FBQ25ZLE1BQU0sRUFBRW9ZLENBQUMsRUFBRSxFQUFFO1FBQ3pCLElBQU1DLENBQUMsR0FBR0YsQ0FBQyxDQUFDQyxDQUFDLENBQUM7UUFDZDtRQUNBOWEsQ0FBQyxDQUFDK2EsQ0FBQyxDQUFDLEdBQUksVUFBVVQsQ0FBQyxFQUFFO1VBQ2pCLE9BQU8sWUFBWTtZQUNmLElBQU1DLENBQUMsR0FBR3BiLEtBQUssQ0FBQzZiLFNBQVMsQ0FBQ0MsS0FBSyxDQUFDL0wsSUFBSSxDQUFDVyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1lBQ2xEO1lBQ0E3UCxDQUFDLENBQUMwVixDQUFDLENBQUM5VCxJQUFJLENBQUM7Y0FBRXNaLFlBQVksRUFBRVosQ0FBQztjQUFFekssU0FBUyxFQUFFMEs7WUFBRSxDQUFDLENBQUM7VUFDL0MsQ0FBQztRQUNMLENBQUMsQ0FBRVEsQ0FBQyxDQUFDO01BQ1Q7SUFDSjtFQUNKLENBQUMsRUFBRXhkLFFBQVEsRUFBRVQsTUFBTSxDQUFDdVYsU0FBUyxFQUFFLHNDQUFzQyxFQUFFLHNDQUFzQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0VBQ2xIO0VBQ0F2VixNQUFNLENBQUNxRixTQUFTLEdBQUdyRixNQUFNLENBQUNxRixTQUFTLElBQUksQ0FBQyxDQUFDO0VBQ3pDO0VBQ0FyRixNQUFNLENBQUNxRixTQUFTLENBQUM2TixHQUFHLEdBQUdsVCxNQUFNLENBQUNxRixTQUFTLENBQUM2TixHQUFHLElBQUksRUFBRTtFQUNqRDtFQUNBbFQsTUFBTSxDQUFDcUYsU0FBUyxDQUFDNk4sR0FBRyxDQUFDcE8sSUFBSSxDQUFDLE1BQU07SUFDNUIsSUFBSTlFLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ3VDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQ2pDLE1BQU0sS0FBSyxDQUFDLEVBQUU7TUFDbEUsSUFBTXlZLENBQUMsR0FBR3JlLE1BQU0sQ0FBQ3NlLFlBQVksQ0FBQ0MsT0FBTyxDQUFDLFFBQVEsQ0FBQztNQUMvQ3ZlLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FDWEMsTUFBTSxDQUFDLENBQUMsQ0FDUitULFlBQVksQ0FBQyxXQUFXLEVBQUVnRixDQUFDLEdBQUdqRyxJQUFJLENBQUNvRyxLQUFLLENBQUNILENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztJQUMxRDtFQUNKLENBQUMsQ0FBQztFQUNGLElBQU1JLGVBQWUsR0FBRztJQUNwQnRELElBQUksRUFBRW5iLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDNlcsSUFBSTtJQUNqQzVXLElBQUksRUFBRXZFLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJO0lBQ2pDdU4sS0FBSyxFQUFFOVIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUN3TjtFQUNsQyxDQUFDO0VBQ0RtTCxZQUFZLENBQUN3QixlQUFlLEVBQUV6ZSxNQUFNLENBQUN1VixTQUFTLENBQUM7QUFDbkQsQ0FBQztBQUNNLElBQU10RixhQUFhLEdBQUdBLENBQUEsS0FBTTtFQUMvQixJQUFJalEsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNrVCxRQUFRLENBQUNqQyxTQUFTLEVBQUU7SUFDM0MsS0FBS2dJLHlCQUF5QixDQUFDLENBQUM7RUFDcEM7RUFDQSxPQUFPamQsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDO0FBQ00sSUFBTXlFLENBQUMsR0FBRztFQUNicUQsT0FBTztFQUNQMlMsV0FBVztFQUNYRSxlQUFlO0VBQ2Y2QiwyQkFBMkI7RUFDM0JFO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEpvRTtBQUNyQjtBQUNmO0FBQ3NCO0FBQ087QUFDSztBQUNFO0FBQ0w7QUFDSztBQUNyRSxJQUFNMkIsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTSxDQUFDekgsOEVBQWEsQ0FBQyxDQUFDLElBQzNDblgsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNrVCxRQUFRLENBQUNxSCxtQkFBbUIsSUFDbkQzSCx3RUFBa0IsQ0FBQ1EsbUJBQW1CLElBQ3RDLENBQUNSLHdFQUFrQixDQUFDalUsTUFBTSxJQUMxQixDQUFDakQsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ29ULFdBQVcsSUFDeEMsQ0FBQ04sMEVBQW1CLElBQ3BCLENBQUNSLG1GQUFVLENBQUMsQ0FBQztBQUNqQixJQUFNaUksbUJBQW1CLEdBQUc3TixnRUFBZSxDQUFDeU4sbUVBQVMsRUFBRSxTQUFTLENBQUM7QUFDakUsSUFBTUssVUFBVTtFQUFBLElBQUE5YyxJQUFBLEdBQUF1USxpQkFBQSxDQUFHLFdBQU8zUCxZQUFZLEVBQUs7SUFDdkMsSUFBSStiLGdCQUFnQixDQUFDLENBQUMsRUFBRTtNQUNwQixJQUFJRSxtQkFBbUIsRUFBRTtRQUNyQixNQUFNLGtuQkFFeUM7TUFDbkQsQ0FBQyxNQUNJO1FBQ0QsTUFBTSxvbEJBRWlDO01BQzNDO01BQ0FILHFFQUFNLENBQUM5RyxVQUFVLENBQUM3WCxNQUFNLEVBQUU2QyxZQUFZLENBQUM7SUFDM0M7RUFDSixDQUFDO0VBQUEsZ0JBZEtrYyxVQUFVQSxDQUFBcE0sRUFBQTtJQUFBLE9BQUExUSxJQUFBLENBQUE2USxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBY2Y7QUFDRCxJQUFNaU0sa0JBQWtCLEdBQUlDLG1CQUFtQixJQUFLO0VBQ2hEeGQsbURBQUcsQ0FBQyxZQUFZLEVBQUUsaUJBQWlCLEVBQUU7SUFDakN3ZDtFQUNKLENBQUMsQ0FBQztFQUNGLElBQUksQ0FBQ0EsbUJBQW1CLEVBQUU7SUFDdEIsTUFBTSxJQUFJbFgsS0FBSyxDQUFDLHVCQUF1QixDQUFDO0VBQzVDO0FBQ0osQ0FBQztBQUNELElBQU1tWCxXQUFXO0VBQUEsSUFBQTdiLEtBQUEsR0FBQW1QLGlCQUFBLENBQUcsYUFBWTtJQUFBLElBQUEyTSxpQkFBQSxFQUFBQyxtQkFBQTtJQUM1QixJQUFJO01BQ0EsSUFBTXZjLFlBQVksU0FBU2tVLHlEQUFTLENBQUMsQ0FBQztNQUN0QyxJQUFJLENBQUNsVSxZQUFZLENBQUN3YyxTQUFTLEVBQUU7UUFDekIsTUFBTSxJQUFJdFgsS0FBSyxDQUFDLG1CQUFtQixDQUFDO01BQ3hDO01BQ0EsUUFBUWxGLFlBQVksQ0FBQ3djLFNBQVM7UUFDMUIsS0FBSyxLQUFLO1VBQ05MLGtCQUFrQixDQUFDLENBQUMsR0FBQUcsaUJBQUEsR0FBQ3RjLFlBQVksQ0FBQ3lYLEdBQUcsY0FBQTZFLGlCQUFBLGVBQWhCQSxpQkFBQSxDQUFrQkcsdUJBQXVCLEVBQUM7VUFDL0Q7UUFDSixLQUFLLE9BQU87VUFDUk4sa0JBQWtCLENBQUMsR0FBQUksbUJBQUEsR0FBQ3ZjLFlBQVksQ0FBQ3NYLEtBQUssY0FBQWlGLG1CQUFBLGVBQWxCQSxtQkFBQSxDQUFvQkcsU0FBUyxFQUFDO1VBQ2xEO1FBQ0osS0FBSyxPQUFPO1VBQ1I7VUFDQTtNQUNSO01BQ0EsT0FBT1IsVUFBVSxDQUFDbGMsWUFBWSxDQUFDO0lBQ25DLENBQUMsQ0FDRCxPQUFPcU0sR0FBRyxFQUFFO01BQ1IsSUFBTTNFLEtBQUssR0FBRzJFLEdBQUc7TUFDakJ6TixtREFBRyxDQUFDLFlBQVksRUFBRSw2QkFBNkIsRUFBRThJLEtBQUssQ0FBQ2lWLE9BQU8sQ0FBQztJQUNuRTtFQUNKLENBQUM7RUFBQSxnQkF2QktOLFdBQVdBLENBQUE7SUFBQSxPQUFBN2IsS0FBQSxDQUFBeVAsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQXVCaEI7QUFDTSxJQUFNME0sZUFBZSxHQUFHekkscURBQUksQ0FBQ2tJLFdBQVcsQ0FBQztBQUNoRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTS9QLElBQUksR0FBR0EsQ0FBQSxLQUFNc1EsZUFBZSxDQUFDLENBQUM7QUFDcEMsSUFBTXphLENBQUMsR0FBRztFQUNia2E7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDekUwRTtBQUNUO0FBQ2Q7QUFDTTtBQUNIO0FBQ1M7QUFDRztBQUNPO0FBQzNCO0FBQ1U7QUFDTjtBQUNFO0FBQ3JELElBQU1hLHFCQUFxQixHQUFJL1gsTUFBTSxJQUFLO0VBQ3RDLElBQU07SUFBRXNUO0VBQVksQ0FBQyxHQUFHdGIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUk7RUFDbkQsSUFBTTtJQUFFcU47RUFBSyxDQUFDLEdBQUc1SixNQUFNLENBQUNnWSxPQUFPO0VBQy9CLElBQUkxRSxXQUFXLEtBQUssU0FBUyxJQUFJMUosSUFBSSxhQUFKQSxJQUFJLGVBQUpBLElBQUksQ0FBRXhSLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtJQUN2RCxPQUFPO01BQ0g2ZixPQUFPLEVBQUUsQ0FBQ2xmLHVFQUFPLENBQUNtZixTQUFTLEVBQUVuWixnRkFBWSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7SUFDdkQsQ0FBQztFQUNMO0VBQ0EsSUFBSXVVLFdBQVcsS0FBSyxVQUFVLElBQUkxSixJQUFJLGFBQUpBLElBQUksZUFBSkEsSUFBSSxDQUFFeFIsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO0lBQ3hELE9BQU87TUFDSCtmLE9BQU8sRUFBRSxDQUFDcGYsdUVBQU8sQ0FBQzJMLGdCQUFnQixFQUFFM0wsdUVBQU8sQ0FBQzRMLHNCQUFzQixDQUFDO01BQ25Fc1QsT0FBTyxFQUFFLENBQUNsZix1RUFBTyxDQUFDMkwsZ0JBQWdCLEVBQUUzTCx1RUFBTyxDQUFDNEwsc0JBQXNCO0lBQ3RFLENBQUM7RUFDTDtFQUNBLElBQUlpRixJQUFJLEtBQUssYUFBYSxJQUFJOE4sZ0ZBQU8sQ0FBQyxDQUFDLEVBQUU7SUFDckMsT0FBTztNQUNIVSxNQUFNLEVBQUUsQ0FBQ3JmLHVFQUFPLENBQUNxTCxLQUFLO0lBQzFCLENBQUM7RUFDTDtFQUNBLE9BQU8sQ0FBQyxDQUFDO0FBQ2IsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTStNLHFCQUFxQjtFQUFBLElBQUFsWCxJQUFBLEdBQUF1USxpQkFBQSxDQUFHLGFBQVk7SUFDdEM7SUFDQTtJQUNBO0lBQ0EsSUFBTTZOLFlBQVksR0FBRyxDQUFDbFEsbUVBQW1CLENBQUMsQ0FBQyxDQUFDO0lBQzVDLE1BQU03UCxPQUFPLENBQUNtVCxHQUFHLENBQUM0TSxZQUFZLENBQUM7SUFDL0I7SUFDQTtJQUNBLE1BQU1aLGlFQUFlLENBQUMsQ0FBQyxDQUFDblYsS0FBSyxDQUFFZ1csTUFBTSxJQUFLN2UsbURBQUcsQ0FBQyxZQUFZLEVBQUUsMEJBQTBCLEVBQUU2ZSxNQUFNLENBQUMsQ0FBQztJQUNoRztJQUNBLElBQUlwSix3RUFBa0IsQ0FBQ2pVLE1BQU0sRUFBRTtNQUMzQixPQUFPM0MsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztJQUM1QjtJQUNBLElBQU1nZ0IsV0FBVyxHQUFHdmdCLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDa2MsaUJBQWlCLElBQ3hEWCxtRkFBb0IsQ0FBQyxDQUFDLEtBQUssUUFBUTtJQUN2QztJQUNBLElBQU03TCxPQUFPLEdBQUcsQ0FDWixHQUFHdlQsUUFBUSxDQUFDZ2dCLGdCQUFnQixDQUFDdmIsb0RBQU0sQ0FBQ3diLGNBQWMsQ0FBQyxDQUN0RCxDQUNJQyxNQUFNLENBQUUzWSxNQUFNLElBQUssQ0FBQzlDLG9EQUFNLENBQUM4TyxPQUFPLENBQUNDLEdBQUcsQ0FBQ2pNLE1BQU0sQ0FBQ2xCLEVBQUUsQ0FBQztJQUNsRDtJQUNBO0lBQ0E7SUFDQTtJQUFBLENBQ0M2WixNQUFNLENBQUUzWSxNQUFNLElBQUssRUFBRXVZLFdBQVcsSUFBSXZZLE1BQU0sQ0FBQ2xCLEVBQUUsS0FBSyx1QkFBdUIsQ0FBQyxDQUFDLENBQzNFOUUsR0FBRyxDQUFFZ0csTUFBTSxJQUFLO01BQ2pCLElBQU15SyxlQUFlLEdBQUdzTixxQkFBcUIsQ0FBQy9YLE1BQU0sQ0FBQztNQUNyRCxPQUFPNFgsbUVBQVksQ0FBQzVYLE1BQU0sRUFBRXlLLGVBQWUsQ0FBQztJQUNoRCxDQUFDLENBQUMsQ0FDR2tPLE1BQU0sQ0FBQ2hCLHlEQUFhLENBQUM7SUFDMUIsS0FBSyxJQUFNdFosTUFBTSxJQUFJMk4sT0FBTyxFQUFFO01BQzFCOU8sb0RBQU0sQ0FBQzhPLE9BQU8sQ0FBQzRNLEdBQUcsQ0FBQ3ZhLE1BQU0sQ0FBQ1MsRUFBRSxFQUFFVCxNQUFNLENBQUM7SUFDekM7SUFDQTJOLE9BQU8sQ0FBQ2pPLE9BQU8sQ0FBQytaLCtEQUFXLENBQUM7SUFDNUIsSUFBSTVhLG9EQUFNLENBQUMyYixjQUFjLENBQUMsQ0FBQyxFQUFFO01BQ3pCL2EseUVBQWMsQ0FBQyxDQUFDO0lBQ3BCLENBQUMsTUFDSTtNQUNEVixnRUFBVSxDQUFDLENBQUM7SUFDaEI7RUFDSixDQUFDO0VBQUEsZ0JBeENLK1QscUJBQXFCQSxDQUFBO0lBQUEsT0FBQWxYLElBQUEsQ0FBQTZRLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0F3QzFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEZEO0FBQzBEO0FBQ1M7QUFDbkI7QUFDMkI7QUFDdEI7QUFDbUI7QUFDYTtBQUMxQjtBQUNNO0FBQ0k7QUFDckUsSUFBTXFPLGVBQWUsR0FBSXpOLEdBQUcsSUFBSztFQUFBLElBQUEwTixXQUFBO0VBQzdCLElBQU1DLE1BQU0sR0FBRzdnQixRQUFRLENBQUNDLGFBQWEsQ0FBQyxRQUFRLENBQUM7RUFDL0MsSUFBSSxPQUFPaVQsR0FBRyxDQUFDNE4sR0FBRyxLQUFLLFdBQVcsRUFBRTtJQUNoQ0QsTUFBTSxDQUFDRSxHQUFHLEdBQUc3TixHQUFHLENBQUM0TixHQUFHO0VBQ3hCO0VBQ0E7RUFDQUQsTUFBTSxDQUFDRyxNQUFNLElBQUFKLFdBQUEsR0FBRzFOLEdBQUcsQ0FBQytOLE1BQU0sY0FBQUwsV0FBQSxjQUFBQSxXQUFBLEdBQUksSUFBSTtFQUNsQyxJQUFJMU4sR0FBRyxDQUFDa0gsS0FBSyxLQUFLLElBQUksRUFBRTtJQUNwQnlHLE1BQU0sQ0FBQzNnQixZQUFZLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQztFQUNwQztFQUNBLElBQUlnVCxHQUFHLENBQUNnTyxLQUFLLEVBQUU7SUFDWGhPLEdBQUcsQ0FBQ2dPLEtBQUssQ0FBQzViLE9BQU8sQ0FBRTZiLElBQUksSUFBSztNQUN4Qk4sTUFBTSxDQUFDM2dCLFlBQVksQ0FBQ2loQixJQUFJLENBQUNoUSxJQUFJLEVBQUVnUSxJQUFJLENBQUN6ZixLQUFLLENBQUM7SUFDOUMsQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPbWYsTUFBTTtBQUNqQixDQUFDO0FBQ0QsSUFBTU8sVUFBVSxHQUFJQyxJQUFJLElBQUs7RUFDekIsSUFBTUMsR0FBRyxHQUFHdGhCLFFBQVEsQ0FBQ3VoQixPQUFPLENBQUMsQ0FBQyxDQUFDO0VBQy9CLElBQU1DLElBQUksR0FBR3hoQixRQUFRLENBQUN5aEIsc0JBQXNCLENBQUMsQ0FBQztFQUM5QyxJQUFJQyxrQkFBa0IsR0FBRyxLQUFLO0VBQzlCTCxJQUFJLENBQUMvYixPQUFPLENBQUU0TixHQUFHLElBQUs7SUFBQSxJQUFBeU8sZUFBQTtJQUNsQixJQUFJek8sR0FBRyxDQUFDME8sTUFBTSxLQUFLLElBQUksRUFDbkI7SUFDSixDQUFBRCxlQUFBLEdBQUF6TyxHQUFHLENBQUMyTyxVQUFVLGNBQUFGLGVBQUEsZUFBZEEsZUFBQSxDQUFBaFEsSUFBQSxDQUFBdUIsR0FBaUIsQ0FBQztJQUNsQjtJQUNBLElBQUlBLEdBQUcsQ0FBQzRPLFFBQVEsS0FBSyxJQUFJLElBQUksT0FBTzVPLEdBQUcsQ0FBQzROLEdBQUcsS0FBSyxXQUFXLEVBQUU7TUFDekQsSUFBSWlCLEtBQUssQ0FBQyxDQUFDLENBQUNoQixHQUFHLEdBQUc3TixHQUFHLENBQUM0TixHQUFHO0lBQzdCLENBQUMsTUFDSSxJQUFJNU4sR0FBRyxDQUFDOE8sYUFBYSxFQUFFO01BQ3hCOU8sR0FBRyxDQUFDOE8sYUFBYSxDQUFDLENBQUM7SUFDdkIsQ0FBQyxNQUNJO01BQ0ROLGtCQUFrQixHQUFHLElBQUk7TUFDekIsSUFBTWIsTUFBTSxHQUFHRixlQUFlLENBQUN6TixHQUFHLENBQUM7TUFDbkNzTyxJQUFJLENBQUNwaEIsV0FBVyxDQUFDeWdCLE1BQU0sQ0FBQztJQUM1QjtJQUNBM04sR0FBRyxDQUFDME8sTUFBTSxHQUFHLElBQUk7RUFDckIsQ0FBQyxDQUFDO0VBQ0Y7RUFDQSxJQUFJRixrQkFBa0IsRUFBRTtJQUNwQixPQUFPbFosNERBQU8sQ0FBQ2UsTUFBTSxDQUFDLE1BQU07TUFDeEIsSUFBSStYLEdBQUcsYUFBSEEsR0FBRyxlQUFIQSxHQUFHLENBQUU5VSxVQUFVLEVBQUU7UUFDakI4VSxHQUFHLENBQUM5VSxVQUFVLENBQUN5VixZQUFZLENBQUNULElBQUksRUFBRUYsR0FBRyxDQUFDO01BQzFDO0lBQ0osQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPemhCLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQztBQUNELElBQU1vaUIsYUFBYTtFQUFBLElBQUExZ0IsSUFBQSxHQUFBdVEsaUJBQUEsQ0FBRyxXQUFPb1EsbUJBQW1CLEVBQUVDLG1CQUFtQixFQUFLO0lBQ3RFLEtBQUtoQixVQUFVLENBQUNnQixtQkFBbUIsQ0FBQztJQUNwQyxJQUFNaGdCLFlBQVksU0FBU2tVLHlEQUFTLENBQUMsQ0FBQztJQUN0QyxJQUFNK0wsNEJBQTRCLEdBQUdGLG1CQUFtQixDQUFDakMsTUFBTSxDQUFFVyxNQUFNLElBQUs7TUFDeEUsSUFBSUEsTUFBTSxDQUFDMVAsSUFBSSxLQUFLdlMsU0FBUyxFQUN6QixPQUFPLEtBQUs7TUFDaEIsT0FBT3lYLDZEQUFhLENBQUN3SyxNQUFNLENBQUMxUCxJQUFJLEVBQUUvTyxZQUFZLENBQUM7SUFDbkQsQ0FBQyxDQUFDO0lBQ0YsSUFBSWlnQiw0QkFBNEIsQ0FBQ2xkLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDekMsS0FBS2ljLFVBQVUsQ0FBQ2lCLDRCQUE0QixDQUFDO0lBQ2pEO0VBQ0osQ0FBQztFQUFBLGdCQVhLSCxhQUFhQSxDQUFBaFEsRUFBQSxFQUFBQyxHQUFBO0lBQUEsT0FBQTNRLElBQUEsQ0FBQTZRLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FXbEI7QUFDRCxJQUFNZ1EsU0FBUyxHQUFHQSxDQUFBLEtBQU07RUFBQSxJQUFBckkscUJBQUEsRUFBQUMsc0JBQUEsRUFBQXFJLHNCQUFBO0VBQ3BCLElBQU1KLG1CQUFtQixHQUFHLENBQ3hCekIsOEVBQVcsQ0FBQztJQUNSOEIsU0FBUyxHQUFBdkkscUJBQUEsR0FBRTFhLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDa1QsUUFBUSxDQUFDMkosV0FBVyxjQUFBekcscUJBQUEsY0FBQUEscUJBQUEsR0FBSTtFQUM5RCxDQUFDLENBQUMsRUFDRm5GLDBFQUFTLENBQUM7SUFDTjBOLFNBQVMsR0FBQXRJLHNCQUFBLEdBQUUzYSxNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ2tULFFBQVEsQ0FBQ2pDLFNBQVMsY0FBQW9GLHNCQUFBLGNBQUFBLHNCQUFBLEdBQUk7RUFDNUQsQ0FBQyxDQUFDLEVBQ0ZvRywwREFBRyxFQUNIRyxvRUFBTSxDQUFDO0lBQUUrQixTQUFTLEdBQUFELHNCQUFBLEdBQUVoakIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNrVCxRQUFRLENBQUMwSixNQUFNLGNBQUE4QixzQkFBQSxjQUFBQSxzQkFBQSxHQUFJO0VBQU0sQ0FBQyxDQUFDLEVBQ3RFN1EscUVBQU8sQ0FDVixDQUFDd08sTUFBTSxDQUFFM2IsQ0FBQyxJQUFLQSxDQUFDLENBQUNpZSxTQUFTLENBQUM7RUFDNUIsSUFBTUosbUJBQW1CLEdBQUc7RUFDeEI7RUFDQTtFQUNBN0IsNkVBQVk7RUFBRTtFQUNkQywwRkFBa0IsQ0FBRTtFQUFBLENBQ3ZCLENBQUNOLE1BQU0sQ0FBRTNiLENBQUMsSUFBS0EsQ0FBQyxDQUFDaWUsU0FBUyxDQUFDO0VBQzVCLE9BQU9OLGFBQWEsQ0FBQ0MsbUJBQW1CLEVBQUVDLG1CQUFtQixDQUFDO0FBQ2xFLENBQUM7QUFDRCxJQUFNMVQsSUFBSTtFQUFBLElBQUE5TCxLQUFBLEdBQUFtUCxpQkFBQSxDQUFHLGFBQVk7SUFDckIsSUFBSTBFLHdFQUFrQixDQUFDZ00sY0FBYyxFQUFFO01BQ25DLEtBQUtILFNBQVMsQ0FBQyxDQUFDO01BQ2hCLE9BQU96aUIsT0FBTyxDQUFDQyxPQUFPLENBQUMsSUFBSSxDQUFDO0lBQ2hDO0lBQ0EsT0FBT0QsT0FBTyxDQUFDQyxPQUFPLENBQUMsS0FBSyxDQUFDO0VBQ2pDLENBQUM7RUFBQSxnQkFOSzRPLElBQUlBLENBQUE7SUFBQSxPQUFBOUwsS0FBQSxDQUFBeVAsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQU1UO0FBQ2U7QUFDVCxJQUFNL04sQ0FBQyxHQUFHO0VBQ2IyZCxhQUFhO0VBQ2JJO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2RzREO0FBQ3lCO0FBQ2pEO0FBQ2dCO0FBQ1c7QUFDWDtBQUNXO0FBQ0o7QUFDQTtBQUNmO0FBQ2tCO0FBQy9ELElBQU1PLGdCQUFnQixHQUFHdmlCLHVFQUFPLENBQUN1TCxHQUFHLENBQUM3QyxNQUFNLEdBQUd4SyxnR0FBZTtBQUM3RCxJQUFNc2tCLHlCQUF5QixHQUFHeGlCLHVFQUFPLENBQUN5TCxRQUFRLENBQUMvQyxNQUFNLEdBQUd4SyxnR0FBZTtBQUMzRSxJQUFNdWtCLFFBQVEsR0FBSUMsTUFBTSxJQUFLO0VBQ3pCLElBQU1uZCxJQUFJLEdBQUc2YyxpRUFBWSxDQUFDLG1CQUFtQixFQUFFO0lBQzNDTyxPQUFPLEVBQUU7RUFDYixDQUFDLENBQUM7RUFDRixJQUFNQyxlQUFlLEdBQUdsakIsUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQ3JEaWpCLGVBQWUsQ0FBQ2xZLFNBQVMsR0FBRyxtQkFBbUI7RUFDL0NrWSxlQUFlLENBQUN6WixLQUFLLENBQUN3TSxRQUFRLEdBQUcsUUFBUTtFQUN6Q2lOLGVBQWUsQ0FBQ3paLEtBQUssQ0FBQzBaLEdBQUcsR0FBRyxHQUFHO0VBQy9CRCxlQUFlLENBQUM5aUIsV0FBVyxDQUFDeUYsSUFBSSxDQUFDO0VBQ2pDLElBQU11ZCxlQUFlLEdBQUdwakIsUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO0VBQ3JEbWpCLGVBQWUsQ0FBQzNaLEtBQUssQ0FBQzRaLFFBQVEsR0FBRyxHQUFHO0VBQ3BDRCxlQUFlLENBQUNoakIsV0FBVyxDQUFDOGlCLGVBQWUsQ0FBQztFQUM1Q2xpQixtREFBRyxDQUFDLFlBQVksRUFBRSxvQ0FBb0MsQ0FBQztFQUN2RCxPQUFPd0gsNERBQU8sQ0FDVGUsTUFBTSxDQUFDLE1BQU07SUFDZHlaLE1BQU0sQ0FBQzVpQixXQUFXLENBQUM4aUIsZUFBZSxDQUFDO0VBQ3ZDLENBQUMsQ0FBQyxDQUNHaGIsSUFBSSxDQUFDLE1BQU0wSiw2RUFBaUIsQ0FBQy9MLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztBQUNuRCxDQUFDO0FBQ0QsSUFBTXlkLGNBQWMsR0FBR0EsQ0FBQ04sTUFBTSxFQUFFM2MsRUFBRSxLQUFLO0VBQ25DLElBQU1SLElBQUksR0FBRzZjLGlFQUFZLENBQUMsbUJBQW1CLEVBQUU7SUFDM0N2UixJQUFJLHVCQUFBblAsTUFBQSxDQUF1QnFFLEVBQUUsQ0FBRTtJQUMvQjRjLE9BQU8sRUFBRTtFQUNiLENBQUMsQ0FBQztFQUNGcGQsSUFBSSxDQUFDNEQsS0FBSyxDQUFDQyxTQUFTLE1BQUExSCxNQUFBLENBQU0xQix1RUFBTyxDQUFDdUwsR0FBRyxDQUFDN0MsTUFBTSxHQUFHeEssZ0dBQWUsT0FBSTtFQUNsRSxJQUFNMGtCLGVBQWUsR0FBR2xqQixRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDckRpakIsZUFBZSxDQUFDbFksU0FBUyxHQUFHLG1CQUFtQjtFQUMvQ2tZLGVBQWUsQ0FBQ3paLEtBQUssQ0FBQ1YsS0FBSyxHQUFHLE9BQU87RUFDckNtYSxlQUFlLENBQUN6WixLQUFLLENBQUM4WixNQUFNLEdBQUcsV0FBVztFQUMxQ0wsZUFBZSxDQUFDOWlCLFdBQVcsQ0FBQ3lGLElBQUksQ0FBQztFQUNqQyxJQUFNMmQsV0FBVyxHQUFHeGpCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLElBQUksQ0FBQztFQUNoRHVqQixXQUFXLENBQUNwakIsV0FBVyxDQUFDOGlCLGVBQWUsQ0FBQztFQUN4Q2xpQixtREFBRyxDQUFDLFlBQVksd0NBQUFnQixNQUFBLENBQXdDcUUsRUFBRSxZQUFTLENBQUM7RUFDcEUsT0FBT21DLDREQUFPLENBQ1RlLE1BQU0sQ0FBQyxNQUFNO0lBQ2R5WixNQUFNLENBQUNTLEtBQUssQ0FBQ0QsV0FBVyxDQUFDO0VBQzdCLENBQUMsQ0FBQyxDQUNHdGIsSUFBSSxDQUFDLE1BQU0wSiw2RUFBaUIsQ0FBQy9MLElBQUksRUFBRSxLQUFLLENBQUMsQ0FBQztBQUNuRCxDQUFDO0FBQ0QsSUFBTTZkLGNBQWMsR0FBR0EsQ0FBQSxLQUFNO0VBQ3pCLElBQU1DLFFBQVEsR0FBR3BrQixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ2tjLGlCQUFpQixHQUNuRCxzQkFBc0IsR0FDdEIseUJBQXlCO0VBQy9CLElBQU02RCxXQUFXLEdBQUc1akIsUUFBUSxDQUFDd0wsYUFBYSxDQUFDbVksUUFBUSxDQUFDO0VBQ3BELElBQUksQ0FBQ0MsV0FBVyxFQUNaLE1BQU0sSUFBSXRjLEtBQUssQ0FBQyw4QkFBOEIsQ0FBQztFQUNuRCxPQUFPc2MsV0FBVztBQUN0QixDQUFDO0FBQ0QsSUFBTUMsaUJBQWlCO0VBQUEsSUFBQXJpQixJQUFBLEdBQUF1USxpQkFBQSxDQUFHLGFBQVk7SUFDbEMsT0FBT3ZKLDREQUFPLENBQUNXLE9BQU8sQ0FBQyxNQUFNO01BQ3pCLElBQU0yYSxjQUFjLEdBQUc5akIsUUFBUSxDQUFDd0wsYUFBYSxDQUFDLHdDQUF3QyxDQUFDO01BQ3ZGLElBQUksQ0FBQ3NZLGNBQWMsRUFDZixNQUFNLElBQUl4YyxLQUFLLENBQUMsNEJBQTRCLENBQUM7TUFDakQsT0FBT3djLGNBQWM7SUFDekIsQ0FBQyxDQUFDO0VBQ04sQ0FBQztFQUFBLGdCQVBLRCxpQkFBaUJBLENBQUE7SUFBQSxPQUFBcmlCLElBQUEsQ0FBQTZRLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FPdEI7QUFDRCxJQUFNeVIsa0JBQWtCLEdBQUlDLGVBQWUsSUFBSztFQUM1QztFQUNBO0VBQ0E7RUFDQSxJQUFNQyxrQkFBa0IsR0FBR3BCLGdCQUFnQixHQUFHQyx5QkFBeUIsR0FBR3ZqQixNQUFNLENBQUMya0IsV0FBVztFQUM1RixPQUFPRixlQUFlLENBQUNobEIsWUFBWSxJQUFJaWxCLGtCQUFrQjtBQUM3RCxDQUFDO0FBQ0QsSUFBTUUscUJBQXFCLEdBQUlMLGNBQWMsSUFBS0EsY0FBYyxDQUFDTSxpQkFBaUIsSUFBSSxDQUFDO0FBQ3ZGLElBQU1DLCtCQUErQixHQUFHQSxDQUFBLEtBQU07RUFDMUMsSUFBTUMsbUJBQW1CLEdBQUd0a0IsUUFBUSxDQUFDZ2dCLGdCQUFnQixDQUFDLDZCQUE2QixDQUFDO0VBQ3BGLE9BQU9zRSxtQkFBbUIsQ0FBQ25mLE1BQU0sR0FBRyxDQUFDLEdBQUcsSUFBSSxHQUFHLEtBQUs7QUFDeEQsQ0FBQztBQUNELElBQU1vZiwrQkFBK0IsR0FBR0EsQ0FBQSxLQUFNO0VBQzFDLElBQU1DLGlCQUFpQixHQUFHN0IsNEVBQWEsQ0FBQ0Msd0VBQVcsQ0FBQyxDQUFDLENBQUM3WixLQUFLLENBQUM7RUFDNUQsSUFBSXliLGlCQUFpQixLQUFLLFFBQVEsRUFBRTtJQUNoQyxPQUFPM2tCLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDNUI7RUFDQSxJQUFNd2tCLG1CQUFtQixHQUFHdGtCLFFBQVEsQ0FBQ2dnQixnQkFBZ0IsQ0FBQyw2QkFBNkIsQ0FBQztFQUNwRixPQUFPeFgsNERBQU8sQ0FBQ2UsTUFBTSxDQUFDLE1BQU0rYSxtQkFBbUIsQ0FBQ2hmLE9BQU8sQ0FBRVUsSUFBSSxJQUFLO0lBQzlEaEYsbURBQUcsQ0FBQyxZQUFZLHVCQUFBZ0IsTUFBQSxDQUF1QmdFLElBQUksQ0FBQ0ssRUFBRSxDQUFFLENBQUM7SUFDakQsSUFBTVQsTUFBTSxHQUFHTCx3RUFBYSxDQUFDUyxJQUFJLENBQUNLLEVBQUUsQ0FBQztJQUNyQyxJQUFJVCxNQUFNLEVBQUU7TUFDUmEsaUVBQVcsQ0FBQ2IsTUFBTSxDQUFDO0lBQ3ZCO0VBQ0osQ0FBQyxDQUFDLENBQUM7QUFDUCxDQUFDO0FBQ0QsSUFBTTZlLHlCQUF5QixHQUFHQSxDQUFBLEtBQU07RUFDcEMsSUFBTVQsZUFBZSxHQUFHTixjQUFjLENBQUMsQ0FBQztFQUN4QyxJQUFJSyxrQkFBa0IsQ0FBQ0MsZUFBZSxDQUFDLEVBQUU7SUFDckMsS0FBS2pCLFFBQVEsQ0FBQ2lCLGVBQWUsQ0FBQztFQUNsQztBQUNKLENBQUM7QUFDRCxJQUFNVSwrQkFBK0I7RUFBQSxJQUFBOWhCLEtBQUEsR0FBQW1QLGlCQUFBLENBQUcsYUFBWTtJQUNoRCxJQUFNK1IsY0FBYyxTQUFTRCxpQkFBaUIsQ0FBQyxDQUFDO0lBQ2hEO0lBQ0E7SUFDQSxJQUFNYyxLQUFLLEdBQUdwbEIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNrYyxpQkFBaUI7SUFDdEQsSUFBTTZFLGtCQUFrQixHQUFHRCxLQUFLLEdBQUcsQ0FBQyxHQUFHLENBQUM7SUFDeEMsSUFBSVIscUJBQXFCLENBQUNMLGNBQWMsQ0FBQyxJQUNyQyxDQUFDTywrQkFBK0IsQ0FBQyxDQUFDLEVBQUU7TUFDcEMsSUFBSVEsT0FBTyxHQUFHLENBQUM7TUFDZixLQUFLLElBQUkzSCxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc0RyxjQUFjLENBQUNNLGlCQUFpQixFQUFFbEgsQ0FBQyxFQUFFLEVBQUU7UUFDdkQsSUFBSTRHLGNBQWMsQ0FBQ2dCLFFBQVEsQ0FBQzVILENBQUMsQ0FBQyxJQUMxQixDQUFDQSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO1FBQUk7UUFDckJBLENBQUMsR0FBRzBILGtCQUFrQixHQUFHZCxjQUFjLENBQUNNLGlCQUFpQixFQUFFO1VBQzNEUyxPQUFPLEVBQUU7VUFDVCxJQUFNRSxZQUFZLEdBQUdqQixjQUFjLENBQUNnQixRQUFRLENBQUM1SCxDQUFDLENBQUM7VUFDL0MsS0FBS29HLGNBQWMsQ0FBQ3lCLFlBQVksRUFBRUYsT0FBTyxDQUFDO1FBQzlDO01BQ0o7SUFDSjtFQUNKLENBQUM7RUFBQSxnQkFuQktILCtCQUErQkEsQ0FBQTtJQUFBLE9BQUE5aEIsS0FBQSxDQUFBeVAsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQW1CcEM7QUFDTSxJQUFNSSwyQkFBMkIsR0FBR0EsQ0FBQSxLQUFNO0VBQzdDLElBQUksQ0FBQytELHdFQUFrQixDQUFDdU8sY0FBYyxFQUFFO0lBQ3BDaGtCLG1EQUFHLENBQUMsWUFBWSxFQUFFLHdEQUF3RCxDQUFDO0lBQzNFLE9BQU9uQixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0VBQzVCO0VBQ0FFLFFBQVEsQ0FBQ29LLGdCQUFnQixDQUFDLGlCQUFpQixFQUFFLE1BQU07SUFDL0MsSUFBTW9hLGlCQUFpQixHQUFHN0IsNEVBQWEsQ0FBQ0Msd0VBQVcsQ0FBQyxDQUFDLENBQUM3WixLQUFLLENBQUM7SUFDNUQsSUFBSXliLGlCQUFpQixLQUFLLFFBQVEsRUFBRTtNQUNoQyxLQUFLRSwrQkFBK0IsQ0FBQyxDQUFDO0lBQzFDLENBQUMsTUFDSTtNQUNELEtBQUtELHlCQUF5QixDQUFDLENBQUM7SUFDcEM7RUFDSixDQUFDLENBQUM7RUFDRjtBQUNKO0FBQ0E7QUFDQTtFQUNJemtCLFFBQVEsQ0FBQ29LLGdCQUFnQixDQUFDLHVCQUF1QixFQUFFLE1BQU07SUFDckQsS0FBS21hLCtCQUErQixDQUFDLENBQUM7RUFDMUMsQ0FBQyxDQUFDO0VBQ0YsT0FBTzFrQixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0FBQzVCLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0kyRTtBQUNaO0FBQ1U7QUFDVjtBQUNKO0FBQ2Y7QUFDa0I7QUFDL0QsSUFBTW9sQixlQUFlLEdBQUcsR0FBRyxDQUFDLENBQUM7QUFDN0IsSUFBTUMsT0FBTyxHQUFHLEVBQUUsQ0FBQyxDQUFDO0FBQ3BCLElBQU1DLHFCQUFxQixHQUFJcEMsTUFBTSxJQUFLO0VBQ3RDLElBQU1uZCxJQUFJLEdBQUc2YyxpRUFBWSxDQUFDLGdCQUFnQixDQUFDO0VBQzNDLElBQU0yQyxTQUFTLEdBQUdKLHdFQUFtQixDQUFDcGYsSUFBSSxFQUFFO0lBQ3hDbUYsU0FBUyxFQUFFO0VBQ2YsQ0FBQyxDQUFDO0VBQ0Y7QUFDSjtBQUNBO0VBQ0lxYSxTQUFTLENBQUM1YixLQUFLLENBQUN3TSxRQUFRLEdBQUcsUUFBUTtFQUNuQ29QLFNBQVMsQ0FBQzViLEtBQUssQ0FBQzBaLEdBQUcsR0FBRyxHQUFHO0VBQ3pCa0MsU0FBUyxDQUFDNWIsS0FBSyxDQUFDNmIsU0FBUyxHQUFHLE1BQU07RUFDbEMsS0FBSzljLDREQUFPLENBQ1BlLE1BQU0sQ0FBQyxNQUFNO0lBQ2R5WixNQUFNLENBQUN2WixLQUFLLENBQUNULE1BQU0sR0FBRyxNQUFNO0lBQzVCZ2EsTUFBTSxDQUFDNWlCLFdBQVcsQ0FBQ2lsQixTQUFTLENBQUM7RUFDakMsQ0FBQyxDQUFDLENBQ0duZCxJQUFJLENBQUMsTUFBTTBKLDRFQUFpQixDQUFDL0wsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ25ELENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU02SSxJQUFJLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUE2VyxxQkFBQTtFQUN0QixJQUFJaG1CLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDa2MsaUJBQWlCLEVBQUU7SUFDMUMsT0FBT2xnQixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0VBQzVCO0VBQ0EsSUFBTTBrQixpQkFBaUIsR0FBRzdCLDRFQUFhLENBQUNDLHdFQUFXLENBQUMsQ0FBQyxDQUFDN1osS0FBSyxDQUFDO0VBQzVELElBQUl5YixpQkFBaUIsS0FBSyxTQUFTLElBQUlBLGlCQUFpQixLQUFLLE1BQU0sRUFBRTtJQUNqRSxPQUFPM2tCLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7RUFDNUI7RUFDQSxJQUFJLENBQUMyVyx3RUFBa0IsQ0FBQytPLHVCQUF1QixFQUFFO0lBQzdDLE9BQU8zbEIsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztFQUM1QjtFQUNBO0FBQ0o7QUFDQTtBQUNBO0VBQ0ksSUFBTWtqQixNQUFNLEdBQUdoakIsUUFBUSxDQUFDd0wsYUFBYSxDQUFDLDRCQUE0QixDQUFDO0VBQ25FLElBQU1pYSxhQUFhLEdBQUdQLGVBQWUsR0FBRzFtQixzRkFBZSxHQUFHMm1CLE9BQU87RUFDakUsSUFBSW5DLE1BQU0sS0FBSyxJQUFJLElBQ2QsQ0FBQXVDLHFCQUFBLEdBQUF2QyxNQUFNLENBQUMzVixhQUFhLGNBQUFrWSxxQkFBQSxlQUFwQkEscUJBQUEsQ0FBc0J2bUIsWUFBWSxJQUMvQmdrQixNQUFNLENBQUMzVixhQUFhLENBQUNyTyxZQUFZLEdBQUd5bUIsYUFBYyxFQUFFO0lBQ3hELE9BQU81bEIsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztFQUM1QjtFQUNBc2xCLHFCQUFxQixDQUFDcEMsTUFBTSxDQUFDO0VBQzdCLE9BQU9uakIsT0FBTyxDQUFDQyxPQUFPLENBQUMsQ0FBQztBQUM1QixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdkQrRDtBQUNVO0FBQzdCO0FBQzdDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTTRPLElBQUksR0FBR0EsQ0FBQSxLQUFNO0VBQ3RCLElBQUkrSCx3RUFBa0IsQ0FBQ2lQLFNBQVMsRUFBRTtJQUM5QixJQUFNQyxjQUFjLEdBQUdwbUIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzhoQixXQUFXLEdBQ3hELGVBQWUsR0FDZixnQ0FBZ0M7SUFDdEMsSUFBTTVDLE1BQU0sR0FBR2hqQixRQUFRLENBQUN3TCxhQUFhLENBQUNtYSxjQUFjLENBQUM7SUFDckQsSUFBTTlmLElBQUksR0FBRzZjLGlFQUFZLENBQUMsb0JBQW9CLENBQUM7SUFDL0MsSUFBTTJDLFNBQVMsR0FBR0osd0VBQW1CLENBQUNwZixJQUFJLEVBQUU7TUFDeENtRixTQUFTLEVBQUU7SUFDZixDQUFDLENBQUM7SUFDRjtJQUNBcWEsU0FBUyxDQUFDNWIsS0FBSyxDQUFDa0QsT0FBTyxHQUFHLE1BQU07SUFDaEMwWSxTQUFTLENBQUM1YixLQUFLLENBQUNvYyxjQUFjLEdBQUcsUUFBUTtJQUN6QztJQUNBLE9BQU9yZCw0REFBTyxDQUFDZSxNQUFNLENBQUMsTUFBTTtNQUN4QixJQUFJeVosTUFBTSxhQUFOQSxNQUFNLGVBQU5BLE1BQU0sQ0FBRXhXLFVBQVUsRUFBRTtRQUNwQndXLE1BQU0sQ0FBQ3hXLFVBQVUsQ0FBQ3lWLFlBQVksQ0FBQ29ELFNBQVMsRUFBRXJDLE1BQU0sQ0FBQztNQUNyRDtJQUNKLENBQUMsQ0FBQztFQUNOO0VBQ0EsT0FBT25qQixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0FBQzVCLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0JvRDtBQUNSO0FBQzJCO0FBQ1Q7QUFDL0QsSUFBTWltQixzQkFBc0IsR0FBR0EsQ0FBQSxLQUFNO0VBQ2pDLElBQU1DLE9BQU8sR0FBR2htQixRQUFRLENBQUNDLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDN0MrbEIsT0FBTyxDQUFDaGIsU0FBUyxHQUFHLHdCQUF3QjtFQUM1QyxJQUFNekQsTUFBTSxHQUFHbWIsaUVBQVksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDaERzRCxPQUFPLENBQUM1bEIsV0FBVyxDQUFDbUgsTUFBTSxDQUFDO0VBQzNCLE9BQU95ZSxPQUFPO0FBQ2xCLENBQUM7QUFDRCxJQUFNQyxrQkFBa0IsR0FBR0EsQ0FBQSxLQUFNO0VBQzdCLElBQU1ELE9BQU8sR0FBR2htQixRQUFRLENBQUN3TCxhQUFhLENBQUMseUJBQXlCLENBQUM7RUFDakUsSUFBSXdhLE9BQU8sRUFBRTtJQUNULElBQU16ZSxNQUFNLEdBQUdtYixpRUFBWSxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNoRHNELE9BQU8sQ0FBQzVsQixXQUFXLENBQUNtSCxNQUFNLENBQUM7RUFDL0I7RUFDQSxPQUFPeWUsT0FBTztBQUNsQixDQUFDO0FBQ0QsSUFBTUUsZUFBZSxHQUFHQSxDQUFBLEtBQU07RUFDMUIsSUFBSSxDQUFDM21CLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDa2MsaUJBQWlCLEVBQUU7SUFDM0MsT0FBT2dHLHNCQUFzQixDQUFDLENBQUM7RUFDbkM7RUFDQSxPQUFPRSxrQkFBa0IsQ0FBQyxDQUFDO0FBQy9CLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU12WCxJQUFJLEdBQUdBLENBQUEsS0FBTTtFQUN0QixJQUFJb1gsb0ZBQXlCLENBQUMsQ0FBQyxFQUFFO0lBQzdCLElBQU1LLG1CQUFtQixHQUFHRCxlQUFlLENBQUMsQ0FBQztJQUM3QyxPQUFPMWQsNERBQU8sQ0FDVGUsTUFBTSxDQUFDLE1BQU07TUFDZDtNQUNBLElBQUl2SixRQUFRLENBQUNHLElBQUksSUFBSWdtQixtQkFBbUIsRUFBRTtRQUN0Q25tQixRQUFRLENBQUNHLElBQUksQ0FBQ0MsV0FBVyxDQUFDK2xCLG1CQUFtQixDQUFDO01BQ2xEO0lBQ0osQ0FBQyxDQUFDLENBQ0dqZSxJQUFJLENBQUMsTUFBTTtNQUNaLElBQUlpZSxtQkFBbUIsRUFBRTtRQUNyQixJQUFNQyxrQkFBa0IsR0FBR0QsbUJBQW1CLENBQUMzYSxhQUFhLENBQUMsd0JBQXdCLENBQUM7UUFDdEYsSUFBSTRhLGtCQUFrQixFQUFFO1VBQ3BCLEtBQUt4VSw0RUFBaUIsQ0FBQ3dVLGtCQUFrQixFQUFFLElBQUksQ0FBQztRQUNwRDtNQUNKO0lBQ0osQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPdm1CLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakQ0RDtBQUN4QjtBQUM4QjtBQUNYO0FBQ2tCO0FBQzFCO0FBQ2dCO0FBQ25CO0FBQzdDO0FBQ0E7QUFDQTtBQUNBLElBQU13bUIsT0FBTyxHQUFHLENBQUM7QUFDakI7QUFDQTtBQUNBO0FBQ0EsSUFBTUMsaUJBQWlCLEdBQUcsR0FBRztBQUM3QixJQUFJQyxVQUFVLEdBQUcsQ0FBQztBQUNsQixJQUFNQyxXQUFXLEdBQUdBLENBQUNDLFFBQVEsRUFBRUMsV0FBVyxLQUFLO0VBQzNDLElBQUlELFFBQVEsRUFBRTtJQUNWLE9BQU9DLFdBQVcsS0FBSyxDQUFDLEdBQUcsZUFBZSxZQUFBM2tCLE1BQUEsQ0FBWTJrQixXQUFXLENBQUU7RUFDdkU7RUFDQSxnQkFBQTNrQixNQUFBLENBQWdCMmtCLFdBQVcsR0FBRyxDQUFDO0FBQ25DLENBQUM7QUFDRCxJQUFNQyxjQUFjLEdBQUlDLElBQUksSUFBSztFQUM3QixJQUFNSCxRQUFRLEdBQUd0SCxtRkFBb0IsQ0FBQyxDQUFDLEtBQUssUUFBUTtFQUNwRCxJQUFNaUcsU0FBUyxHQUFHcmxCLFFBQVEsQ0FBQ0MsYUFBYSxDQUFDLEtBQUssQ0FBQztFQUMvQ29sQixTQUFTLENBQUNyYSxTQUFTLGdDQUFBaEosTUFBQSxDQUFnQzBrQixRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVMsQ0FBRTtFQUNwRixJQUFNNW5CLEVBQUUsR0FBRzRqQixpRUFBWSxDQUFDLFFBQVEsRUFBRTtJQUM5QnZSLElBQUksRUFBRXNWLFdBQVcsQ0FBQ0MsUUFBUSxFQUFFRixVQUFVLENBQUM7SUFDdkN2RCxPQUFPLG9CQUFBamhCLE1BQUEsQ0FBb0Iwa0IsUUFBUSxHQUFHLFVBQVUsR0FBRyxFQUFFO0VBQ3pELENBQUMsQ0FBQztFQUNGckIsU0FBUyxDQUFDamxCLFdBQVcsQ0FBQ3RCLEVBQUUsQ0FBQztFQUN6QixPQUFPMEosNERBQU8sQ0FDVGUsTUFBTSxDQUFDLE1BQU07SUFDZCxJQUFJc2QsSUFBSSxDQUFDcmEsVUFBVSxFQUFFO01BQ2pCO01BQ0FxYSxJQUFJLENBQUNyYSxVQUFVLENBQUN5VixZQUFZLENBQUNvRCxTQUFTLEVBQUV3QixJQUFJLENBQUNDLFdBQVcsQ0FBQztJQUM3RDtFQUNKLENBQUMsQ0FBQyxDQUNHNWUsSUFBSSxjQUFBNkosaUJBQUEsQ0FBQztJQUFBLE9BQVlILDRFQUFpQixDQUFDOVMsRUFBRSxFQUFFLEtBQUssRUFBRTtNQUMvQzRnQixPQUFPLEVBQUUsQ0FDTHBmLHVFQUFPLENBQUMyTCxnQkFBZ0IsRUFDeEIzTCx1RUFBTyxDQUFDNEwsc0JBQXNCLENBQ2pDO01BQ0RzVCxPQUFPLEVBQUUsQ0FDTGxmLHVFQUFPLENBQUMyTCxnQkFBZ0IsRUFDeEIzTCx1RUFBTyxDQUFDNEwsc0JBQXNCO0lBRXRDLENBQUMsQ0FBQztFQUFBLEdBQUM7QUFDUCxDQUFDO0FBQ0QsSUFBTTZhLFNBQVM7RUFBQSxJQUFBbmtCLEtBQUEsR0FBQW1QLGlCQUFBLENBQUcsV0FBT2lWLEtBQUssRUFBSztJQUMvQixJQUFNQyxlQUFlLEdBQUcsRUFBRTtJQUMxQixLQUFLLElBQUkvSixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUc4SixLQUFLLENBQUM3aEIsTUFBTSxJQUFJcWhCLFVBQVUsR0FBR0YsT0FBTyxFQUFFcEosQ0FBQyxJQUFJLENBQUMsRUFBRTtNQUM5RCxJQUFNMkosSUFBSSxHQUFHRyxLQUFLLENBQUM5SixDQUFDLENBQUM7TUFDckIsSUFBSTJKLElBQUksYUFBSkEsSUFBSSxlQUFKQSxJQUFJLENBQUVyYSxVQUFVLEVBQUU7UUFDbEIsSUFBTTBhLE1BQU0sR0FBR04sY0FBYyxDQUFDQyxJQUFJLENBQUM7UUFDbkNJLGVBQWUsQ0FBQzVpQixJQUFJLENBQUM2aUIsTUFBTSxDQUFDO1FBQzVCVixVQUFVLElBQUksQ0FBQztNQUNuQjtJQUNKO0lBQ0EsTUFBTTNtQixPQUFPLENBQUNtVCxHQUFHLENBQUNpVSxlQUFlLENBQUM7RUFDdEMsQ0FBQztFQUFBLGdCQVhLRixTQUFTQSxDQUFBN1UsRUFBQTtJQUFBLE9BQUF0UCxLQUFBLENBQUF5UCxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBV2Q7QUFDRCxJQUFNNlUsU0FBUyxHQUFJQyxLQUFLLElBQUs7RUFDekIsSUFBTUMsT0FBTyxHQUFHO0lBQUVDLElBQUksRUFBRTtFQUFVLENBQUM7RUFDbkMsT0FBT2pCLHNEQUFXLENBQUNjLFNBQVMsQ0FBQ0MsS0FBSyxFQUFFTCxTQUFTLEVBQUVNLE9BQU8sQ0FBQztBQUMzRCxDQUFDO0FBQ0QsSUFBTUUsY0FBYyxHQUFHQSxDQUFDQyxZQUFZLEVBQUVDLGNBQWMsRUFBRUMsWUFBWSxLQUFLN2dCLElBQUksQ0FBQzhnQixHQUFHLENBQUNILFlBQVksQ0FBQ0ksTUFBTSxHQUFHSCxjQUFjLENBQUNHLE1BQU0sQ0FBQyxHQUN4SEYsWUFBWSxHQUFHbkIsaUJBQWlCO0FBQ3BDLElBQU1zQixtQkFBbUIsR0FBR0EsQ0FBQ0MsVUFBVSxFQUFFSixZQUFZLEtBQUs7RUFDdEQ7RUFDQTtFQUNBLElBQUlLLFFBQVE7RUFDWixJQUFNQyxVQUFVLEdBQUluaUIsSUFBSSxJQUFLO0lBQ3pCLElBQUksQ0FBQ2tpQixRQUFRLEVBQUU7TUFDWEEsUUFBUSxHQUFHbGlCLElBQUk7TUFDZixPQUFPLEtBQUs7SUFDaEI7SUFDQSxJQUFJMGhCLGNBQWMsQ0FBQ1EsUUFBUSxFQUFFbGlCLElBQUksRUFBRTZoQixZQUFZLENBQUMsRUFBRTtNQUM5Q0ssUUFBUSxHQUFHbGlCLElBQUk7TUFDZixPQUFPLElBQUk7SUFDZjtJQUNBLE9BQU8sS0FBSztFQUNoQixDQUFDO0VBQ0QsT0FBTztJQUNIb2lCLFlBQVksRUFBRSxtQkFBbUI7SUFDakNDLGlCQUFpQixFQUFFLGlCQUFpQjtJQUNwQ0MsVUFBVSxFQUFFLElBQUk7SUFDaEJDLE9BQU8sRUFBRU4sVUFBVTtJQUNuQk8sMEJBQTBCLEVBQUUsQ0FBQztJQUM3QkMsa0JBQWtCLEVBQUUsQ0FBQztJQUNyQkMscUJBQXFCLEVBQUUsQ0FBQztJQUN4QkMsZ0JBQWdCLEVBQUUsQ0FBQztJQUNuQkMscUJBQXFCLEVBQUUsQ0FBQyxDQUFDO0lBQ3pCdkksTUFBTSxFQUFFOEg7RUFDWixDQUFDO0FBQ0wsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTVUsNEJBQTJCO0VBQUEsSUFBQXpWLEtBQUEsR0FBQWxCLGlCQUFBLENBQUcsV0FBTzRXLFNBQVMsRUFBSztJQUNyRCxJQUFNQyxXQUFXLEdBQUdELFNBQVMsQ0FBQ0Usc0JBQXNCO0lBQ3BELElBQUlELFdBQVcsS0FBSyxJQUFJLEVBQ3BCLE9BQU8sSUFBSTtJQUNmLElBQUlBLFdBQVcsQ0FBQzNkLFNBQVMsQ0FBQ0MsUUFBUSxDQUFDLE9BQU8sQ0FBQyxFQUFFO01BQ3pDLE9BQU8wZCxXQUFXO0lBQ3RCO0lBQ0EsT0FBT0YsNEJBQTJCLENBQUNFLFdBQVcsQ0FBQztFQUNuRCxDQUFDO0VBQUEsZ0JBUktGLDJCQUEyQkEsQ0FBQXZXLEdBQUE7SUFBQSxPQUFBYyxLQUFBLENBQUFaLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FRaEM7QUFDRCxJQUFNd1cscUJBQXFCO0VBQUEsSUFBQUMsS0FBQSxHQUFBaFgsaUJBQUEsQ0FBRyxhQUFZO0lBQ3RDLE9BQU92Siw0REFBTyxDQUFDVyxPQUFPLENBQUMsTUFBTTtNQUFBLElBQUE2ZixVQUFBO01BQ3pCLElBQU1DLFNBQVMsR0FBR2pwQixRQUFRLENBQUNnZ0IsZ0JBQWdCLENBQUMsNEJBQTRCLENBQUM7TUFDekUsUUFBQWdKLFVBQUEsR0FBT0MsU0FBUyxDQUFDQSxTQUFTLENBQUM5akIsTUFBTSxHQUFHLENBQUMsQ0FBQyxjQUFBNmpCLFVBQUEsY0FBQUEsVUFBQSxHQUFJLElBQUk7SUFDbEQsQ0FBQyxDQUFDO0VBQ04sQ0FBQztFQUFBLGdCQUxLRixxQkFBcUJBLENBQUE7SUFBQSxPQUFBQyxLQUFBLENBQUExVyxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBSzFCO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTTRXLHVCQUF1QjtFQUFBLElBQUFDLEtBQUEsR0FBQXBYLGlCQUFBLENBQUcsV0FBT3FYLFlBQVksRUFBSztJQUNwRCxJQUFNVCxTQUFTLEdBQUczb0IsUUFBUSxDQUFDd0wsYUFBYSx3QkFBQXhKLE1BQUEsQ0FBd0JvbkIsWUFBWSxDQUFFLENBQUM7SUFDL0UsSUFBSVQsU0FBUyxLQUFLLElBQUksRUFBRTtNQUNwQixhQUFhRyxxQkFBcUIsQ0FBQyxDQUFDO0lBQ3hDO0lBQ0EsT0FBT0osNEJBQTJCLENBQUNDLFNBQVMsQ0FBQztFQUNqRCxDQUFDO0VBQUEsZ0JBTktPLHVCQUF1QkEsQ0FBQTlXLEdBQUE7SUFBQSxPQUFBK1csS0FBQSxDQUFBOVcsS0FBQSxPQUFBQyxTQUFBO0VBQUE7QUFBQSxHQU01QjtBQUNELElBQU0rVyx1QkFBdUI7RUFBQSxJQUFBQyxLQUFBLEdBQUF2WCxpQkFBQSxDQUFHLGFBQVk7SUFDeEMsSUFBTTJVLFFBQVEsR0FBR3RILG1GQUFvQixDQUFDLENBQUMsS0FBSyxRQUFRO0lBQ3BELElBQU1nSyxZQUFZLGlDQUFBcG5CLE1BQUEsQ0FBaUMwa0IsUUFBUSxHQUFHLFFBQVEsR0FBRyxTQUFTLENBQUU7SUFDcEYsT0FBT2xlLDREQUFPLENBQ1RXLE9BQU8sQ0FBQyxNQUFNO01BQ2YsSUFBTW9nQixRQUFRLEdBQUd2cEIsUUFBUSxDQUFDZ2dCLGdCQUFnQixDQUFDb0osWUFBWSxDQUFDLENBQUNqa0IsTUFBTTtNQUMvRCxJQUFJb2tCLFFBQVEsSUFBSWpELE9BQU8sRUFBRTtRQUNyQixNQUFNLElBQUloZixLQUFLLENBQUMsc0RBQXNELENBQUM7TUFDM0U7TUFDQWtmLFVBQVUsR0FBRytDLFFBQVE7SUFDekIsQ0FBQyxDQUFDLENBQ0dyaEIsSUFBSSxjQUFBNkosaUJBQUEsQ0FBQyxhQUFZO01BQ2xCLElBQU15WCxpQkFBaUIsU0FBVU4sdUJBQXVCLENBQUNFLFlBQVksQ0FBRTtNQUN2RSxJQUFJLENBQUNJLGlCQUFpQixFQUFFO1FBQ3BCLE1BQU0sSUFBSWxpQixLQUFLLENBQUMsOEVBQThFLENBQUM7TUFDbkc7TUFDQSxPQUFPa2lCLGlCQUFpQjtJQUM1QixDQUFDLEVBQUMsQ0FDR3RoQixJQUFJLENBQUVzaEIsaUJBQWlCLElBQUs7TUFDN0IsT0FBT2hoQiw0REFBTyxDQUNUVyxPQUFPLENBQUMsTUFBTW5KLFFBQVEsQ0FBQ3lwQixlQUFlLENBQUNycUIsWUFBWSxDQUFDLENBQ3BEOEksSUFBSSxDQUFFd2YsWUFBWSxJQUFLRyxtQkFBbUIsQ0FBQzJCLGlCQUFpQixFQUFFOUIsWUFBWSxDQUFDLENBQUMsQ0FDNUV4ZixJQUFJLENBQUNpZixTQUFTLENBQUM7SUFDeEIsQ0FBQyxDQUFDLENBQ0d0ZCxLQUFLLENBQUVDLEtBQUssSUFBSztNQUNsQjlJLG1EQUFHLENBQUMsWUFBWSxFQUFFOEksS0FBSyxDQUFDO0lBQzVCLENBQUMsQ0FBQztFQUNOLENBQUM7RUFBQSxnQkEzQkt1Zix1QkFBdUJBLENBQUE7SUFBQSxPQUFBQyxLQUFBLENBQUFqWCxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBMkI1QjtBQUNELElBQU1vWCxjQUFjLEdBQUdBLENBQUEsS0FBTTtFQUN6QjtFQUNBMXBCLFFBQVEsQ0FBQ29LLGdCQUFnQixDQUFDLHlCQUF5QixFQUFFdWYsUUFBUSxDQUFDO0FBQ2xFLENBQUM7QUFDRCxJQUFNQyxhQUFhLEdBQUdBLENBQUEsS0FBTTtFQUN4QjtFQUNBNXBCLFFBQVEsQ0FBQ2tLLG1CQUFtQixDQUFDLHlCQUF5QixFQUFFeWYsUUFBUSxDQUFDO0FBQ3JFLENBQUM7QUFDRCxJQUFNQSxRQUFRLEdBQUdBLENBQUEsS0FBTTtFQUNuQkMsYUFBYSxDQUFDLENBQUM7RUFDZixLQUFLUCx1QkFBdUIsQ0FBQyxDQUFDO0FBQ2xDLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU0zYSxJQUFJLEdBQUdBLENBQUEsS0FBTTtFQUN0QixJQUFJK0gsd0VBQWtCLENBQUNvVCxlQUFlLEVBQUU7SUFDcEMsS0FBS0gsY0FBYyxDQUFDLENBQUM7RUFDekI7RUFDQSxPQUFPN3BCLE9BQU8sQ0FBQ0MsT0FBTyxDQUFDLENBQUM7QUFDNUIsQ0FBQztBQUNNLElBQU15RSxDQUFDLEdBQUc7RUFDYm1rQiwyQkFBMkIsRUFBM0JBLDRCQUEyQjtFQUMzQkkscUJBQXFCO0VBQ3JCckMsV0FBVztFQUNYeUM7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7O0FDMUxEO0FBQ0E7QUFDQTtBQUNPLElBQU0xUyxRQUFRLEdBQUdBLENBQUEsS0FBTTtFQUMxQixDQUFDLFVBQVVHLEVBQUUsRUFBRW1ULENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUUxTSxDQUFDLEVBQUUyTSxDQUFDLEVBQUVyTSxDQUFDLEVBQUU7SUFDN0IsSUFBSWtNLENBQUMsQ0FBQ25ULEVBQUUsQ0FBQyxFQUNMO0lBQ0osU0FBU3dCLENBQUNBLENBQUNvRixDQUFDLEVBQUVOLENBQUMsRUFBRTtNQUNiNk0sQ0FBQyxDQUFDblQsRUFBRSxDQUFDLENBQUN1VCxFQUFFLENBQUM3bEIsSUFBSSxDQUFDLENBQUNrWixDQUFDLEVBQUVOLENBQUMsQ0FBQyxDQUFDO0lBQ3pCO0lBQ0E2TSxDQUFDLENBQUNuVCxFQUFFLENBQUMsR0FBRztNQUNKakksSUFBSUEsQ0FBQSxFQUFHO1FBQ0h5SixDQUFDLENBQUMsR0FBRyxFQUFFN0YsU0FBUyxDQUFDO01BQ3JCLENBQUM7TUFDRDZYLFNBQVNBLENBQUEsRUFBRztRQUNSaFMsQ0FBQyxDQUFDLEdBQUcsRUFBRTdGLFNBQVMsQ0FBQztNQUNyQixDQUFDO01BQ0Q4WCxjQUFjQSxDQUFBLEVBQUcsQ0FBRSxDQUFDO01BQ3BCQyxhQUFhQSxDQUFBLEVBQUc7UUFDWixPQUFPLEVBQUU7TUFDYixDQUFDO01BQ0RILEVBQUUsRUFBRTtJQUNSLENBQUM7SUFDREQsQ0FBQyxHQUFHRixDQUFDLENBQUM5cEIsYUFBYSxDQUFDK3BCLENBQUMsQ0FBQztJQUN0QkMsQ0FBQyxDQUFDN1AsS0FBSyxHQUFHLENBQUMsQ0FBQztJQUNaNlAsQ0FBQyxDQUFDbEosR0FBRyxHQUFHekQsQ0FBQztJQUNUTSxDQUFDLEdBQUdtTSxDQUFDLENBQUM5akIsb0JBQW9CLENBQUMrakIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0lBQ2hDcE0sQ0FBQyxDQUFDcFIsVUFBVSxDQUFDeVYsWUFBWSxDQUFDZ0ksQ0FBQyxFQUFFck0sQ0FBQyxDQUFDO0VBQ25DLENBQUMsRUFBRSxRQUFRLEVBQUVyZSxNQUFNLEVBQUVTLFFBQVEsRUFBRSxRQUFRLEVBQUUsd0NBQXdDLENBQUM7QUFDdEYsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3QjJFO0FBQ1Q7QUFDbEI7QUFDUztBQUNGO0FBQ087QUFDL0QsSUFBTXdxQixZQUFZLEdBQUkxZ0IsS0FBSyxJQUFLO0VBQzVCO0VBQ0E7RUFDQTlJLG1EQUFHLENBQUMsWUFBWSxFQUFFLDBCQUEwQixFQUFFOEksS0FBSyxDQUFDO0FBQ3hELENBQUM7QUFDRCxJQUFNMmdCLHNCQUFzQixHQUFHLEVBQUU7QUFDakMsSUFBTUMsMkJBQTJCLEdBQUdBLENBQUNDLFlBQVksRUFBRUMsVUFBVSxFQUFFQyxTQUFTLEVBQUVDLFNBQVMsRUFBRUMsS0FBSyxFQUFFQyxlQUFlLEtBQUs7RUFBQSxJQUFBQyxxQkFBQSxFQUFBQyxvQkFBQTtFQUM1RyxJQUFNQyxtQkFBbUIsR0FBR0gsZUFBZSxhQUFmQSxlQUFlLGdCQUFBQyxxQkFBQSxHQUFmRCxlQUFlLENBQUU5TSxNQUFNLGNBQUErTSxxQkFBQSx1QkFBdkJBLHFCQUFBLENBQXlCakIsQ0FBQztFQUN0RCxJQUFNb0IsZ0JBQWdCLEdBQUdKLGVBQWUsYUFBZkEsZUFBZSxnQkFBQUUsb0JBQUEsR0FBZkYsZUFBZSxDQUFFSyxHQUFHLGNBQUFILG9CQUFBLHVCQUFwQkEsb0JBQUEsQ0FBc0JsQixDQUFDO0VBQ2hELElBQU1zQixlQUFlLEdBQUdILG1CQUFtQixhQUFuQkEsbUJBQW1CLGNBQW5CQSxtQkFBbUIsR0FBSUMsZ0JBQWdCO0VBQy9EcHFCLG1EQUFHLENBQUMsWUFBWSxLQUFBZ0IsTUFBQSxDQUFLNm9CLFNBQVMsR0FBRyxZQUFZLEdBQUcsYUFBYSw0QkFBeUI7SUFDbEZTLGVBQWU7SUFDZlgsWUFBWTtJQUNaQyxVQUFVO0lBQ1ZFLFNBQVM7SUFDVEM7RUFDSixDQUFDLENBQUM7RUFDRjtFQUNBLElBQUksQ0FBQ0YsU0FBUyxJQUFJLENBQUNTLGVBQWUsRUFDOUI7RUFDSixJQUFNMWxCLE1BQU0sR0FBR0wsb0VBQWEsQ0FBQytsQixlQUFlLENBQUM7RUFDN0MsSUFBSSxDQUFDMWxCLE1BQU0sRUFDUCxNQUFNLElBQUkwQixLQUFLLHNCQUFBdEYsTUFBQSxDQUFzQnNwQixlQUFlLENBQUUsQ0FBQztFQUMzRCxJQUFNQyxVQUFVLEdBQUdsckIsNkVBQVUsQ0FBQ2lLLEdBQUcsQ0FBQyxDQUFDO0VBQ25DaWhCLFVBQVUsQ0FBQ2hoQixJQUFJLElBQUF2SSxNQUFBLENBQUl1b0IsMkVBQW9CLENBQUMza0IsTUFBTSxDQUFDUyxFQUFFLENBQUMsdUJBQW9CLENBQUM7RUFDdkUsS0FBSzVGLDBGQUErQixDQUFDLENBQUM7RUFDdENtRixNQUFNLENBQUNDLElBQUksQ0FBQytTLFlBQVksQ0FBQyxVQUFVLEVBQUU3VyxNQUFNLENBQUM0b0IsWUFBWSxDQUFDLENBQUM7RUFDMUQ7RUFDQSxJQUFJRixzQkFBc0IsQ0FBQzlxQixRQUFRLENBQUMyckIsZUFBZSxDQUFDLEVBQ2hEO0VBQ0o7RUFDQWhCLG1FQUFhLENBQUMxa0IsTUFBTSxDQUFDO0VBQ3JCO0VBQ0E2a0Isc0JBQXNCLENBQUNwbUIsSUFBSSxDQUFDaW5CLGVBQWUsQ0FBQztBQUNoRCxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU01YyxJQUFJO0VBQUEsSUFBQWxOLElBQUEsR0FBQXVRLGlCQUFBLENBQUcsYUFBWTtJQUM1QixJQUFNaE8sSUFBSSxHQUFHLCtCQUErQjtJQUM1QyxJQUFNc0MsRUFBRSxHQUFHLDZCQUE2QjtJQUN4QyxJQUFNbWxCLGVBQWUsUUFBQXhwQixNQUFBLENBQVErQixJQUFJLE9BQUEvQixNQUFBLENBQUlxRSxFQUFFLDhCQUEyQjtJQUNsRSxJQUFJOUcsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNrVCxRQUFRLENBQUMwVSxzQkFBc0IsRUFBRTtNQUFBLElBQUFDLGdCQUFBO01BQ3hELE1BQU10VCwwREFBVSxDQUFDb1QsZUFBZSxFQUFFO1FBQzlCcFIsS0FBSyxFQUFFO01BQ1gsQ0FBQyxDQUFDLENBQUN2USxLQUFLLENBQUMyZ0IsWUFBWSxDQUFDO01BQ3RCLElBQUksR0FBQWtCLGdCQUFBLEdBQUNuc0IsTUFBTSxDQUFDb3NCLFFBQVEsY0FBQUQsZ0JBQUEsZUFBZkEsZ0JBQUEsQ0FBaUJFLFFBQVEsR0FDMUI7TUFDSixJQUFJcnNCLE1BQU0sQ0FBQ2lHLFFBQVEsQ0FBQ3FtQixJQUFJLEtBQUssa0JBQWtCLEVBQUU7UUFDN0N0c0IsTUFBTSxDQUFDb3NCLFFBQVEsQ0FBQ0MsUUFBUSxDQUFDRSxPQUFPLEdBQUcsSUFBSTtNQUMzQztNQUNBdnNCLE1BQU0sQ0FBQ29zQixRQUFRLENBQUNDLFFBQVEsQ0FBQ0csUUFBUSxHQUFHckIsMkJBQTJCO0lBQ25FO0lBQ0E7RUFDSixDQUFDO0VBQUEsZ0JBaEJZaGMsSUFBSUEsQ0FBQTtJQUFBLE9BQUFsTixJQUFBLENBQUE2USxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBZ0JoQjtBQUNNLElBQU0vTixDQUFDLEdBQUc7RUFDYm1LLElBQUk7RUFDSmdjLDJCQUEyQjtFQUMzQkQ7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25FNkI7QUFDOEI7QUFDNEI7QUFDeEYsSUFBTWptQixRQUFRLEdBQUdBLENBQUEsS0FBTTtFQUNuQixJQUFNMG5CLE1BQU0sR0FBR2xzQixRQUFRLENBQUNHLElBQUk7RUFDNUIsSUFBTStXLFdBQVcsR0FBRzNYLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNvVCxXQUFXO0VBQzNELElBQU1pVixhQUFhLEdBQUc1c0IsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ3FYLE9BQU8sQ0FBQ2lSLFdBQVcsQ0FBQyxDQUFDLEtBQUssSUFBSTtFQUNoRixJQUFNQyxhQUFhLEdBQUcsRUFBRTtFQUN4QixJQUFJQyxXQUFXLEdBQUcsQ0FBQztFQUNuQixJQUFJQyxlQUFlLEdBQUcsS0FBSztFQUMzQixJQUFJQyxnQkFBZ0IsR0FBRyxLQUFLO0VBQzVCLElBQU1DLHlCQUF5QixHQUFHQSxDQUFBLEtBQU07SUFDcENqa0IscURBQWMsQ0FBQyxNQUFNO01BQ2pCMGpCLE1BQU0sQ0FBQ2poQixTQUFTLENBQUN5aEIsTUFBTSxDQUFDLHFCQUFxQixFQUFFVCw2RUFBa0IsQ0FBQztRQUFFVSxHQUFHLEVBQUU7TUFBTyxDQUFDLENBQUMsQ0FBQztJQUN2RixDQUFDLENBQUM7RUFDTixDQUFDO0VBQ0QsSUFBTUMsY0FBYyxHQUFHQSxDQUFBLEtBQU07SUFDekIsSUFBSTFWLFdBQVc7SUFDWDtJQUNBOFUsK0VBQW9CLENBQUMsSUFBSSxDQUFDLElBQzFCLENBQUN2VixvRUFBa0IsQ0FBQ2pVLE1BQU0sRUFBRTtNQUM1QmlxQix5QkFBeUIsQ0FBQyxDQUFDO0lBQy9CO0VBQ0osQ0FBQztFQUNELElBQU1JLDhCQUE4QixHQUFJQyxXQUFXLElBQUs7SUFDcERaLE1BQU0sQ0FBQ3ppQixLQUFLLENBQUNzakIsa0JBQWtCLFVBQUEvcUIsTUFBQSxDQUFVOHFCLFdBQVcsT0FBSTtFQUM1RCxDQUFDO0VBQ0QsSUFBTUUsbUJBQW1CLEdBQUdBLENBQUEsS0FBTTtJQUM5QixJQUFJVixXQUFXLEtBQUssQ0FBQyxFQUFFO01BQ25CLElBQU1XLFNBQVMsR0FBR2p0QixRQUFRLENBQUN3TCxhQUFhLENBQUMsYUFBYSxDQUFDO01BQ3ZELElBQUl5aEIsU0FBUyxFQUFFO1FBQ1hYLFdBQVcsR0FBR0MsZUFBZSxHQUN2QlUsU0FBUyxDQUFDL3RCLFNBQVMsR0FBR210QixhQUFhLEdBQ25DWSxTQUFTLENBQUMvdEIsU0FBUyxHQUFHK3RCLFNBQVMsQ0FBQ2p1QixZQUFZO01BQ3REO0lBQ0o7RUFDSixDQUFDO0VBQ0QsSUFBTWt1QixhQUFhLEdBQUlDLE9BQU8sSUFBSztJQUMvQixJQUFNQyxjQUFjLEdBQUdwdEIsUUFBUSxDQUFDd0wsYUFBYSxDQUFDLHNCQUFzQixDQUFDO0lBQ3JFLElBQUk0aEIsY0FBYyxFQUFFO01BQ2hCRCxPQUFPLENBQUMxakIsS0FBSyxDQUFDNGpCLE9BQU8saUJBQUFyckIsTUFBQSxDQUFpQm9yQixjQUFjLENBQUMvdEIsV0FBVywrQ0FBNEM7SUFDaEg7RUFDSixDQUFDO0VBQ0QsSUFBTWl1QixpQkFBaUIsR0FBR0EsQ0FBQSxLQUFNO0lBQzVCLElBQU0vWCxNQUFNLEdBQUd2VixRQUFRLENBQUN3TCxhQUFhLENBQUMsYUFBYSxDQUFDO0lBQ3BELElBQU0raEIsTUFBTSxHQUFHdnRCLFFBQVEsQ0FBQ3dMLGFBQWEsQ0FBQyxXQUFXLENBQUM7SUFDbEQsSUFBTWdpQixXQUFXLEdBQUd4dEIsUUFBUSxDQUFDd0wsYUFBYSxDQUFDLHlCQUF5QixDQUFDO0lBQ3JFLElBQUkrSixNQUFNLElBQUlnWSxNQUFNLElBQUlDLFdBQVcsRUFBRTtNQUNqQyxJQUFNQyxvQkFBb0IsR0FBR3p0QixRQUFRLENBQUN3TCxhQUFhLENBQUMsMEJBQTBCLENBQUM7TUFDL0UsSUFBSWlpQixvQkFBb0IsRUFBRTtRQUN0QkEsb0JBQW9CLENBQUNoa0IsS0FBSyxDQUFDaWtCLFlBQVksR0FBRyxNQUFNO1FBQ2hERCxvQkFBb0IsQ0FBQ2hrQixLQUFLLENBQUNDLFNBQVMsR0FBRyxHQUFHO01BQzlDO01BQ0FzakIsbUJBQW1CLENBQUMsQ0FBQztNQUNyQkUsYUFBYSxDQUFDM1gsTUFBTSxDQUFDO01BQ3JCMlgsYUFBYSxDQUFDSyxNQUFNLENBQUM7TUFDckIsSUFBSWh1QixNQUFNLENBQUNvdUIsV0FBVyxLQUFLLENBQUMsRUFBRTtRQUMxQmQsOEJBQThCLENBQUNQLFdBQVcsQ0FBQztNQUMvQztNQUNBLElBQU1zQixnQkFBZ0IsR0FBR3JZLE1BQU0sQ0FBQ3NZLHFCQUFxQixDQUFDLENBQUM7TUFDdkQsSUFBTUMscUJBQXFCLEdBQUdOLFdBQVcsQ0FBQ0sscUJBQXFCLENBQUMsQ0FBQztNQUNqRSxJQUFNRSxjQUFjLEdBQUdILGdCQUFnQixDQUFDekssR0FBRztNQUMzQyxJQUFNNkssZUFBZSxHQUFHRixxQkFBcUIsQ0FBQ2xHLE1BQU07TUFDcEQsSUFBTXFHLHlCQUF5QixHQUFHSCxxQkFBcUIsQ0FBQzlrQixNQUFNLEdBQzFEcWpCLGFBQWEsR0FDYnVCLGdCQUFnQixDQUFDNWtCLE1BQU07TUFDM0IsSUFBSStrQixjQUFjLElBQUlFLHlCQUF5QixJQUMzQ0QsZUFBZSxHQUFHLENBQUMsRUFBRTtRQUNyQm5CLDhCQUE4QixDQUFDbUIsZUFBZSxDQUFDO01BQ25ELENBQUMsTUFDSSxJQUFJQSxlQUFlLElBQUksQ0FBQyxFQUFFO1FBQzNCbkIsOEJBQThCLENBQUMsQ0FBQyxDQUFDO01BQ3JDO0lBQ0o7RUFDSixDQUFDO0VBQ0QsSUFBTXFCLGtCQUFrQixHQUFHQSxDQUFBLEtBQU07SUFDN0JsQixtQkFBbUIsQ0FBQyxDQUFDO0lBQ3JCLElBQUl6dEIsTUFBTSxDQUFDb3VCLFdBQVcsS0FBSyxDQUFDLEVBQUU7TUFDMUJkLDhCQUE4QixDQUFDUCxXQUFXLENBQUM7SUFDL0MsQ0FBQyxNQUNJLElBQUkvc0IsTUFBTSxDQUFDNHVCLFdBQVcsSUFBSTdCLFdBQVcsRUFBRTtNQUN4Q08sOEJBQThCLENBQUNQLFdBQVcsR0FBRy9zQixNQUFNLENBQUNvdUIsV0FBVyxDQUFDO0lBQ3BFO0lBQ0EsSUFBSXB1QixNQUFNLENBQUNvdUIsV0FBVyxHQUFHckIsV0FBVyxFQUFFO01BQ2xDTyw4QkFBOEIsQ0FBQyxDQUFDLENBQUM7SUFDckM7RUFDSixDQUFDO0VBQ0QsSUFBTXVCLGVBQWUsR0FBR0EsQ0FBQSxLQUFNO0lBQzFCLElBQUk3QixlQUFlLElBQUlyVixXQUFXLEVBQUU7TUFDaENvVyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3ZCO0lBQ0E7SUFDQSxJQUFJZCxnQkFBZ0IsSUFBSXRWLFdBQVcsSUFBSWlWLGFBQWEsRUFBRTtNQUNsRCtCLGtCQUFrQixDQUFDLENBQUM7SUFDeEI7RUFDSixDQUFDO0VBQ0R0QixjQUFjLENBQUMsQ0FBQztFQUNoQnJ0QixNQUFNLENBQUM2SyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUd6RSxLQUFLLElBQUs7SUFDMUM7SUFDQTtJQUNBLElBQUlBLEtBQUssQ0FBQytPLElBQUksS0FBSyxrQkFBa0IsRUFBRTtNQUNuQzhYLGdCQUFnQixHQUFHLElBQUk7TUFDdkI0QixlQUFlLENBQUMsQ0FBQztJQUNyQjtJQUNBO0lBQ0E7SUFDQSxJQUFJem9CLEtBQUssQ0FBQytPLElBQUksS0FBSyxpQkFBaUIsRUFBRTtNQUNsQzZYLGVBQWUsR0FBRyxJQUFJO01BQ3RCNkIsZUFBZSxDQUFDLENBQUM7SUFDckI7RUFDSixDQUFDLEVBQUUsS0FBSyxDQUFDO0FBQ2IsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDL0dEO0FBQ0E7QUFDQTtBQUNBLElBQU1DLGdCQUFnQixHQUFHLGdCQUFnQjtBQUN6QztBQUNBO0FBQ0E7QUFDQSxJQUFNQyxrQkFBa0IsR0FBRyxvQkFBb0I7QUFDL0M7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFNNVgsYUFBYSxHQUFHQSxDQUFBLEtBQU02WCxPQUFPLENBQUN2VixTQUFTLENBQUNxQixTQUFTLENBQUMxYSxRQUFRLENBQUMydUIsa0JBQWtCLENBQUMsSUFDdkZ0VixTQUFTLENBQUNxQixTQUFTLENBQUMxYSxRQUFRLENBQUMwdUIsZ0JBQWdCLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYmY7QUFDZ0I7QUFDN0MsSUFBTUksOEJBQThCO0VBQUEsSUFBQWp0QixJQUFBLEdBQUF1USxpQkFBQSxDQUFHLGFBQVk7SUFDdEQ7SUFDQSxJQUFNO01BQUVoTyxJQUFJO01BQUUycUI7SUFBTyxDQUFDLEdBQUdudkIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUk7SUFDcEQsSUFBTTZxQixRQUFRLEdBQUdELE1BQU0sR0FBRzNxQixJQUFJLEdBQUcsb0NBQW9DO0lBQ3JFLElBQU02cUIsWUFBWSxHQUFHLElBQUlDLEdBQUcsQ0FBQyw2Q0FBNkMsRUFBRUYsUUFBUSxDQUFDO0lBQ3JGLElBQU1HLFFBQVEsU0FBU0MsS0FBSyxDQUFDSCxZQUFZLENBQUNoakIsUUFBUSxDQUFDLENBQUMsQ0FBQztJQUNyRCxJQUFJa2pCLFFBQVEsQ0FBQ0UsRUFBRSxFQUFFO01BQ2IsSUFBTUMsSUFBSSxTQUFTSCxRQUFRLENBQUNHLElBQUksQ0FBQyxDQUFDO01BQ2xDLElBQUksQ0FBQ3J0QixLQUFLLENBQUNDLE9BQU8sQ0FBQ290QixJQUFJLENBQUMsRUFBRTtRQUN0QixNQUFNM25CLEtBQUssQ0FBQyx3REFBd0QsQ0FBQztNQUN6RTtNQUNBO01BQ0EsSUFBTTRuQixnQkFBZ0IsR0FBR0QsSUFBSSxDQUFDRSxNQUFNLENBQUMsQ0FBQ0MsS0FBSyxFQUFFcm5CLFVBQVUsS0FBSyxFQUFFcW5CLEtBQUssWUFBWTluQixLQUFLLENBQUMsSUFBSSxPQUFPUyxVQUFVLEtBQUssUUFBUSxHQUNqSDtRQUFFc25CLFNBQVMsRUFBRSxDQUFDLEdBQUdELEtBQUssQ0FBQ0MsU0FBUyxFQUFFdG5CLFVBQVU7TUFBRSxDQUFDLEdBQy9DVCxLQUFLLENBQUMsc0VBQXNFLENBQUMsRUFBRTtRQUFFK25CLFNBQVMsRUFBRTtNQUFHLENBQUMsQ0FBQztNQUN2RyxJQUFJSCxnQkFBZ0IsWUFBWTVuQixLQUFLLEVBQUU7UUFDbkMsTUFBTTRuQixnQkFBZ0I7TUFDMUI7TUFDQSxPQUFPQSxnQkFBZ0IsQ0FBQ0csU0FBUztJQUNyQztJQUNBO0lBQ0E7SUFDQSxJQUFNdmxCLEtBQUssR0FBR3hDLEtBQUssQ0FBQyw0Q0FBNEMsQ0FBQztJQUNqRWQsZ0VBQVcsQ0FBQ3NELEtBQUssRUFBRSxZQUFZLEVBQUU7TUFDN0J3bEIsTUFBTSxFQUFFdnRCLE1BQU0sQ0FBQytzQixRQUFRLENBQUNRLE1BQU07SUFDbEMsQ0FBQyxDQUFDO0lBQ0YsTUFBTXhsQixLQUFLO0VBQ2YsQ0FBQztFQUFBLGdCQTNCWTJrQiw4QkFBOEJBLENBQUE7SUFBQSxPQUFBanRCLElBQUEsQ0FBQTZRLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0EyQjFDO0FBQ00sSUFBTWhLLHNDQUFzQyxHQUFHa21CLHFEQUFPLENBQUNDLDhCQUE4QixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7OztBQzlCekI7QUFDcEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNbG1CLGFBQWEsR0FBRyxTQUFBQSxDQUFDM0MsTUFBTSxFQUFxQztFQUFBLElBQUEycEIsWUFBQTtFQUFBLElBQW5DM2xCLHlCQUF5QixHQUFBMEksU0FBQSxDQUFBbk4sTUFBQSxRQUFBbU4sU0FBQSxRQUFBMVQsU0FBQSxHQUFBMFQsU0FBQSxNQUFHLEVBQUU7RUFDekQsSUFBTWtkLFVBQVUsSUFBQUQsWUFBQSxHQUFHM3BCLE1BQU0sQ0FBQzZCLElBQUksY0FBQThuQixZQUFBLHVCQUFYQSxZQUFBLENBQWEzakIsUUFBUSxDQUFDLENBQUM7RUFDMUM7RUFDQSxJQUFJaEcsTUFBTSxDQUFDSSxJQUFJLENBQUN1WixPQUFPLENBQUNrUSxPQUFPLEtBQUssT0FBTyxFQUFFO0lBQ3pDLE9BQU8sS0FBSztFQUNoQjtFQUNBO0VBQ0EsSUFBTUMsT0FBTyxHQUFHRixVQUFVLEtBQUssT0FBTztFQUN0QyxJQUFJRSxPQUFPLEVBQ1AsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBTUMsV0FBVyxHQUFHdHVCLE1BQU0sQ0FBQ3dILE1BQU0sQ0FBQ1QsOEVBQWMsQ0FBQyxDQUM1QzdHLEdBQUcsQ0FBRWtHLElBQUksSUFBS0EsSUFBSSxDQUFDbUUsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUM5QmpNLFFBQVEsQ0FBQzZ2QixVQUFVLENBQUM7RUFDekIsSUFBSUcsV0FBVyxFQUNYLE9BQU8sS0FBSztFQUNoQjtFQUNBO0VBQ0EsSUFBTUMsd0JBQXdCLEdBQUdocUIsTUFBTSxDQUFDbUMsVUFBVSxJQUM5QzZCLHlCQUF5QixDQUFDakssUUFBUSxDQUFDaUcsTUFBTSxDQUFDbUMsVUFBVSxDQUFDO0VBQ3pELElBQUk2bkIsd0JBQXdCLEVBQ3hCLE9BQU8sS0FBSztFQUNoQjtFQUNBLElBQUlyd0IsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ29ULFdBQVcsRUFDdkMsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsT0FBTyxJQUFJO0FBQ2YsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDNUNELElBQU16TSxtQkFBbUIsR0FBR0EsQ0FBQ3dELE1BQU0sRUFBRUcsWUFBWSxLQUFLO0VBQ2xELElBQU15aEIsUUFBUSxHQUFHdHdCLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUNnc0IsS0FBSyxHQUM1QyxzQ0FBc0MsR0FDdEMsNkJBQTZCO0VBQ25DLElBQUksQ0FBQzdoQixNQUFNLElBQUksQ0FBQ0csWUFBWSxFQUFFO0lBQzFCO0VBQ0o7RUFDQSxLQUFLMmdCLEtBQUssQ0FBQ2MsUUFBUSxFQUFFO0lBQ2pCRSxNQUFNLEVBQUUsTUFBTTtJQUNkNXZCLElBQUksRUFBRXdYLElBQUksQ0FBQ0MsU0FBUyxDQUFDO01BQ2pCbkMsS0FBSyxFQUFFLDhCQUE4QjtNQUNyQ3VhLFVBQVUsRUFBRSxDQUNSO1FBQUU3ZSxJQUFJLEVBQUUsUUFBUTtRQUFFelAsS0FBSyxFQUFFdU07TUFBTyxDQUFDLEVBQ2pDO1FBQUVrRCxJQUFJLEVBQUUsY0FBYztRQUFFelAsS0FBSyxFQUFFME07TUFBYSxDQUFDLEVBQzdDO1FBQUUrQyxJQUFJLEVBQUUsVUFBVTtRQUFFelAsS0FBSyxFQUFFO01BQVUsQ0FBQyxFQUN0QztRQUNJeVAsSUFBSSxFQUFFLFlBQVk7UUFDbEJ6UCxLQUFLLEVBQUVuQyxNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ3dOLEtBQUssQ0FBQzRlO01BQ3hDLENBQUM7SUFFVCxDQUFDLENBQUM7SUFDRkMsU0FBUyxFQUFFLElBQUk7SUFDZkMsS0FBSyxFQUFFLFVBQVU7SUFDakJDLElBQUksRUFBRTtFQUNWLENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6QnVDO0FBQ3hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU0xaEIsSUFBSSxHQUFJMmhCLFFBQVEsSUFBSztFQUN2QkEsUUFBUSxDQUFDLGlCQUFpQixFQUFFLENBQUNDLEtBQUssRUFBRUMsR0FBRyxFQUFFeHFCLE1BQU0sS0FBSztJQUNoRCxJQUFJQSxNQUFNLEVBQUU7TUFDUixJQUFNd0IsTUFBTSxHQUFHeEIsTUFBTSxDQUFDMkcsT0FBTyxDQUFDLGFBQWEsQ0FBQztNQUM1QyxJQUFJbkYsTUFBTSxZQUFZaXBCLFdBQVcsRUFBRTtRQUMvQixJQUFNNXFCLE1BQU0sR0FBR25CLGdEQUFNLENBQUM4TyxPQUFPLENBQUNqSixHQUFHLENBQUMvQyxNQUFNLENBQUNsQixFQUFFLENBQUM7UUFDNUMsSUFBSVQsTUFBTSxFQUFFO1VBQ1JBLE1BQU0sQ0FBQzJDLGFBQWEsR0FBRyxLQUFLO1FBQ2hDO01BQ0o7SUFDSjtFQUNKLENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQzBDO0FBQ2I7QUFDOUIsSUFBTWtvQixTQUFTLEdBQUdBLENBQUNBLFNBQVMsRUFBRUMsYUFBYSxLQUFLbG9CLHFEQUFjLENBQUMsTUFBTTtFQUNqRSxJQUFJaW9CLFNBQVMsRUFBRTtJQUNYQyxhQUFhLENBQUN6bEIsU0FBUyxDQUFDRSxHQUFHLENBQUMscUJBQXFCLENBQUM7RUFDdEQsQ0FBQyxNQUNJO0lBQ0R1bEIsYUFBYSxDQUFDemxCLFNBQVMsQ0FBQzBsQixNQUFNLENBQUMscUJBQXFCLENBQUM7RUFDekQ7QUFDSixDQUFDLENBQUM7QUFDRixJQUFNamlCLElBQUksR0FBSTJoQixRQUFRLElBQUs7RUFDdkJBLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQ0MsS0FBSyxFQUFFQyxHQUFHLEVBQUV4cUIsTUFBTSxLQUFLO0lBQzNDLElBQUlBLE1BQU0sSUFBSXVxQixLQUFLLEVBQUU7TUFBQSxJQUFBTSxlQUFBLEVBQUFDLGdCQUFBO01BQ2pCLElBQUksQ0FBQ3ZzQix5REFBUyxDQUFDZ3NCLEtBQUssQ0FBQyxFQUFFO1FBQ25CO01BQ0o7TUFDQSxJQUFNL29CLE1BQU0sSUFBQXFwQixlQUFBLEdBQUc3cUIsTUFBTSxDQUFDMkcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxjQUFBa2tCLGVBQUEsY0FBQUEsZUFBQSxHQUFJaHlCLFNBQVM7TUFDekQ7TUFDQSxJQUFNdVMsSUFBSSxHQUFHNUosTUFBTSxhQUFOQSxNQUFNLHVCQUFOQSxNQUFNLENBQUVnWSxPQUFPLENBQUNwTyxJQUFJO01BQ2pDLElBQUksRUFBQ0EsSUFBSSxhQUFKQSxJQUFJLGVBQUpBLElBQUksQ0FBRTJmLFVBQVUsQ0FBQyxlQUFlLENBQUMsS0FBSSxDQUFDdnBCLE1BQU0sRUFBRTtRQUMvQztNQUNKO01BQ0EsSUFBTW1wQixhQUFhLElBQUFHLGdCQUFBLEdBQUc5cUIsTUFBTSxDQUFDMkcsT0FBTyxDQUFDLG9CQUFvQixDQUFDLGNBQUFta0IsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSWp5QixTQUFTO01BQ3ZFLElBQUksQ0FBQzh4QixhQUFhLEVBQUU7UUFDaEI7TUFDSjtNQUNBLE9BQU9ELFNBQVMsQ0FBQ0gsS0FBSyxFQUFFSSxhQUFhLENBQUM7SUFDMUM7RUFDSixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ00sSUFBTW5zQixDQUFDLEdBQUc7RUFBRWtzQjtBQUFVLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzlCOUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU0vaEIsSUFBSSxHQUFJMmhCLFFBQVEsSUFBSztFQUN2QkEsUUFBUSxDQUFDLG9CQUFvQixFQUFFLE1BQU05d0IsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQ2l0QixpQkFBaUIsQ0FBQztBQUN2RixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNQRCxJQUFNcmlCLElBQUksR0FBSTJoQixRQUFRLElBQUs7RUFDdkJBLFFBQVEsQ0FBQyxjQUFjLEVBQUUsTUFBTTl3QixNQUFNLENBQUNpRyxRQUFRLENBQUN3ckIsTUFBTSxHQUFHenhCLE1BQU0sQ0FBQ2lHLFFBQVEsQ0FBQ3lyQixRQUFRLENBQUM7QUFDckYsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGeUM7QUFDMUMsSUFBTUUsWUFBWSxHQUFJYixLQUFLLElBQUtZLHdEQUFRLENBQUNaLEtBQUssQ0FBQyxJQUFJLFVBQVUsSUFBSUEsS0FBSztBQUN0RSxJQUFNdmMsU0FBUyxHQUFHQSxDQUFDdWMsS0FBSyxFQUFFYyxXQUFXLEtBQUs7RUFDdEMsSUFBTWxLLE1BQU0sR0FBRyxFQUFFO0VBQ2pCLEtBQUssSUFBSWhLLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR2tVLFdBQVcsQ0FBQ2pzQixNQUFNLEVBQUUrWCxDQUFDLElBQUksQ0FBQyxFQUFFO0lBQUEsSUFBQW1VLGNBQUE7SUFDNUMsSUFBTUMsU0FBUyxJQUFBRCxjQUFBLEdBQUdELFdBQVcsQ0FBQ2xVLENBQUMsQ0FBQyxjQUFBbVUsY0FBQSx1QkFBZEEsY0FBQSxDQUFnQkMsU0FBUztJQUMzQyxJQUFJQSxTQUFTLFlBQVlDLGdCQUFnQixJQUNyQ0QsU0FBUyxDQUFDRSxPQUFPLENBQUNsQixLQUFLLENBQUMzTSxRQUFRLENBQUMsSUFDakMyTixTQUFTLENBQUNHLFdBQVcsS0FBSyxJQUFJLEVBQUU7TUFDaEN2SyxNQUFNLENBQUM3aUIsSUFBSSxDQUFDaXRCLFNBQVMsQ0FBQ0csV0FBVyxDQUFDO0lBQ3RDO0lBQ0E7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0VBQ0k7RUFDQSxPQUFPdkssTUFBTTtBQUNqQixDQUFDO0FBQ0QsSUFBTXhZLElBQUksR0FBSTJoQixRQUFRLElBQUs7RUFDdkJBLFFBQVEsQ0FBQyxZQUFZLEVBQUdDLEtBQUssSUFBSztJQUM5QixJQUFJYSxZQUFZLENBQUNiLEtBQUssQ0FBQyxFQUFFO01BQ3JCLE9BQU92YyxTQUFTLENBQUN1YyxLQUFLLEVBQUV0d0IsUUFBUSxDQUFDb3hCLFdBQVcsQ0FBQztJQUNqRDtFQUNKLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDTSxJQUFNN3NCLENBQUMsR0FBRztFQUFFd1AsU0FBUztFQUFFb2Q7QUFBYSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMzQnVCO0FBQ2Y7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTU8sU0FBUyxHQUFJcEIsS0FBSyxJQUFLWSx3REFBUSxDQUFDWixLQUFLLENBQUMsSUFBSS9wQix3REFBUSxDQUFDK3BCLEtBQUssQ0FBQ2pkLE1BQU0sQ0FBQyxHQUFHaWQsS0FBSyxDQUFDamQsTUFBTSxHQUFHelUsU0FBUztBQUNqRyxJQUFNMnNCLFVBQVUsR0FBR2xyQiw2RUFBVSxDQUFDaUssR0FBRyxDQUFDLENBQUM7QUFDbkMsSUFBTW9FLElBQUksR0FBSTJoQixRQUFRLElBQUs7RUFDdkJBLFFBQVEsQ0FBQyxpQkFBaUIsRUFBR0MsS0FBSyxJQUFLO0lBQ25DL0UsVUFBVSxDQUFDaGhCLElBQUksQ0FBQyxVQUFVLEVBQUVtbkIsU0FBUyxDQUFDcEIsS0FBSyxDQUFDLENBQUM7SUFDN0MvRSxVQUFVLENBQUNoaEIsSUFBSSxDQUFDLFlBQVksRUFBRW1uQixTQUFTLENBQUNwQixLQUFLLENBQUMsQ0FBQztJQUMvQy9FLFVBQVUsQ0FBQ2hoQixJQUFJLENBQUMsYUFBYSxFQUFFbW5CLFNBQVMsQ0FBQ3BCLEtBQUssQ0FBQyxDQUFDO0VBQ3BELENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM1QnlDO0FBQ2dCO0FBQ0Y7QUFDeEQsSUFBTXFCLG1CQUFtQixHQUFHLENBQUMsY0FBYyxFQUFFLGFBQWEsRUFBRSxPQUFPLENBQUM7QUFDcEUsSUFBTXpkLGVBQWUsR0FBR0EsQ0FBQ29jLEtBQUssRUFBRS9vQixNQUFNLEtBQUs7RUFDdkMsSUFBTTNCLE1BQU0sR0FBR0wsb0VBQWEsQ0FBQ2dDLE1BQU0sQ0FBQ2xCLEVBQUUsQ0FBQztFQUN2QyxJQUFJVCxNQUFNLEVBQUU7SUFDUkEsTUFBTSxDQUFDQyxJQUFJLENBQUMrUyxZQUFZLENBQUMsVUFBVSxFQUFFMFgsS0FBSyxDQUFDO0lBQzNDO0lBQ0EsSUFBSXFCLG1CQUFtQixDQUFDaHlCLFFBQVEsQ0FBQzJ3QixLQUFLLENBQUMsRUFBRTtNQUNyQzFxQixNQUFNLENBQUNDLElBQUksQ0FBQytTLFlBQVksQ0FBQyxlQUFlLEVBQUUsT0FBTyxDQUFDO0lBQ3REO0lBQ0EwUixtRUFBYSxDQUFDMWtCLE1BQU0sQ0FBQztFQUN6QjtBQUNKLENBQUM7QUFDRCxJQUFNOEksSUFBSSxHQUFJMmhCLFFBQVEsSUFBSztFQUN2QkEsUUFBUSxDQUFDLGtCQUFrQixFQUFFLENBQUNDLEtBQUssRUFBRS9yQixDQUFDLEVBQUV3QixNQUFNLEtBQUs7SUFDL0MsSUFBSUEsTUFBTSxJQUFJUSx3REFBUSxDQUFDK3BCLEtBQUssQ0FBQyxFQUFFO01BQUEsSUFBQU0sZUFBQTtNQUMzQixJQUFNcnBCLE1BQU0sSUFBQXFwQixlQUFBLEdBQUc3cUIsTUFBTSxDQUFDMkcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxjQUFBa2tCLGVBQUEsY0FBQUEsZUFBQSxHQUFJaHlCLFNBQVM7TUFDekQsSUFBSSxDQUFDMkksTUFBTSxFQUFFO1FBQ1Q7TUFDSjtNQUNBLE9BQU8yTSxlQUFlLENBQUNvYyxLQUFLLEVBQUUvb0IsTUFBTSxDQUFDO0lBQ3pDO0VBQ0osQ0FBQyxDQUFDO0FBQ04sQ0FBQztBQUNNLElBQU1oRCxDQUFDLEdBQUc7RUFBRTJQO0FBQWdCLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUMxQnlCO0FBQ3hCO0FBQ3NCO0FBQ1E7QUFDWDtBQUNBO0FBQ2Y7QUFDekMsSUFBTW1ZLGFBQWEsR0FBRyxFQUFFO0FBQ3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNeGdCLEdBQUcsR0FBRyxDQUFDdkwsdUVBQU8sQ0FBQ3VMLEdBQUcsQ0FBQzlDLEtBQUssRUFBRXpJLHVFQUFPLENBQUN1TCxHQUFHLENBQUM3QyxNQUFNLENBQUM7QUFDbkQsSUFBTWlELGdCQUFnQixHQUFHLENBQ3JCM0wsdUVBQU8sQ0FBQzJMLGdCQUFnQixDQUFDbEQsS0FBSyxFQUM5QnpJLHVFQUFPLENBQUMyTCxnQkFBZ0IsQ0FBQ2pELE1BQU0sQ0FDbEM7QUFDRCxJQUFNbUQsZUFBZSxHQUFHLENBQ3BCN0wsdUVBQU8sQ0FBQzZMLGVBQWUsQ0FBQ3BELEtBQUssRUFDN0J6SSx1RUFBTyxDQUFDNkwsZUFBZSxDQUFDbkQsTUFBTSxDQUNqQztBQUNELElBQU1aLGNBQWMsR0FBRyxDQUFDeUQsR0FBRyxFQUFFTSxlQUFlLEVBQUVGLGdCQUFnQixDQUFDO0FBQy9ELElBQU02bEIsb0JBQW9CLEdBQUcsQ0FDekIsQ0FDSSxDQUFDRixxRUFBVyxDQUFDbFMsT0FBTyxFQUFFLENBQUMsQ0FBQyxFQUN4QixDQUFDN1QsR0FBRyxFQUFFSSxnQkFBZ0IsQ0FBQyxDQUMxQixFQUNELENBQ0ksQ0FBQzJsQixxRUFBVyxDQUFDalMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUN2QixDQUFDOVQsR0FBRyxFQUFFTSxlQUFlLENBQUMsQ0FDekIsQ0FDSjtBQUNELElBQU00bEIsWUFBWSxHQUFHLENBQ2pCenhCLHVFQUFPLENBQUMweEIsWUFBWSxDQUFDanBCLEtBQUssRUFDMUJ6SSx1RUFBTyxDQUFDMHhCLFlBQVksQ0FBQ2hwQixNQUFNLENBQzlCO0FBQ0QsSUFBTWlwQixpQkFBaUIsR0FBRyxDQUFDRixZQUFZLENBQUM7QUFDeEMsSUFBTUcsd0JBQXdCLEdBQUcsQ0FDN0IsQ0FBQyxDQUFDTixxRUFBVyxDQUFDalMsTUFBTSxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUNvUyxZQUFZLENBQUMsQ0FBQyxDQUM1QztBQUNELElBQU1JLG1CQUFtQixHQUFHLENBQ3hCLENBQUMsQ0FBQ1AscUVBQVcsQ0FBQ2pTLE1BQU0sRUFBRSxDQUFDLENBQUMsRUFBRSxDQUFDOVQsR0FBRyxDQUFDLENBQUMsQ0FDbkM7QUFDRCxJQUFNdW1CLFdBQVcsR0FBSUMsTUFBTSxJQUFLO0VBQzVCLElBQUlBLE1BQU0sS0FBSyxPQUFPLEVBQUU7SUFDcEIsT0FBTztNQUNIQyxLQUFLLEVBQUVscUIsY0FBYztNQUNyQm1xQixZQUFZLEVBQUVUO0lBQ2xCLENBQUM7RUFDTDtFQUNBLElBQUlPLE1BQU0sS0FBSyxPQUFPLEVBQUU7SUFDcEIsT0FBTztNQUNIQyxLQUFLLEVBQUVMLGlCQUFpQjtNQUN4Qk0sWUFBWSxFQUFFTDtJQUNsQixDQUFDO0VBQ0w7RUFDQSxPQUFPO0lBQ0hJLEtBQUssRUFBRSxDQUFDem1CLEdBQUcsQ0FBQztJQUNaMG1CLFlBQVksRUFBRUo7RUFDbEIsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNSyxTQUFTLEdBQUdBLENBQUNsWSxJQUFJLEVBQUVtWSxPQUFPLEtBQUtuWSxJQUFJLENBQUMvWSxHQUFHLENBQUVFLEdBQUcsSUFBSyxDQUFDQSxHQUFHLEVBQUVneEIsT0FBTyxDQUFDaHhCLEdBQUcsQ0FBQyxDQUFDLENBQUM7QUFDM0UsSUFBTWl4QixnQkFBZ0IsR0FBSUwsTUFBTSxJQUFLO0VBQ2pDLElBQU0zTCxRQUFRLEdBQUd0SCwrRUFBb0IsQ0FBQyxDQUFDLEtBQUssUUFBUTtFQUNwRDtFQUNBLFVBQUFwZCxNQUFBLENBQVVxd0IsTUFBTSxFQUFBcndCLE1BQUEsQ0FBRzBrQixRQUFRLEdBQUcsUUFBUSxHQUFHLFNBQVM7QUFDdEQsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTWhZLElBQUksR0FBSTJoQixRQUFRLElBQUs7RUFDdkJBLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQ3NDLGNBQWMsRUFBRXBDLEdBQUcsRUFBRXhxQixNQUFNLEtBQUs7SUFDbER4RyxNQUFNLENBQUNxRixTQUFTLENBQUM2TixHQUFHLENBQUNwTyxJQUFJLENBQUMsTUFBTTtNQUM1QjtBQUNaO0FBQ0E7TUFDWSxJQUFNO1FBQUVndUI7TUFBTyxDQUFDLEdBQUdNLGNBQWM7TUFDakMsSUFBSSxDQUFDTixNQUFNLEVBQUU7UUFDVHJ4QixtREFBRyxDQUFDLFlBQVksRUFBRSxnREFBZ0QsQ0FBQztRQUNuRTtNQUNKO01BQ0EsSUFBSSxDQUFDK0UsTUFBTSxFQUFFO1FBQ1QvRSxtREFBRyxDQUFDLFlBQVksRUFBRSxtREFBbUQsQ0FBQztRQUN0RTtNQUNKO01BQ0E7QUFDWjtBQUNBO01BQ1ksSUFBTTR4QixXQUFXLEdBQUc3c0IsTUFBTSxDQUFDMkcsT0FBTyxDQUFDLFVBQVUsQ0FBQztNQUM5QyxJQUFNMkcsTUFBTSxHQUFHdWYsV0FBVyxhQUFYQSxXQUFXLHVCQUFYQSxXQUFXLENBQUVyVCxPQUFPLENBQUNwTyxJQUFJO01BQ3hDLElBQUksQ0FBQ2tDLE1BQU0sRUFBRTtRQUNUclMsbURBQUcsQ0FBQyxZQUFZLEVBQUUsNkRBQTZELENBQUM7UUFDaEY7TUFDSjtNQUNBLElBQU02eEIsZ0JBQWdCLE1BQUE3d0IsTUFBQSxDQUFNNnZCLGdFQUFjLEVBQUE3dkIsTUFBQSxDQUFHcVIsTUFBTSxDQUFFO01BQ3JEclMsbURBQUcsQ0FBQyxZQUFZLDRCQUFBZ0IsTUFBQSxDQUE0QnF3QixNQUFNLGtCQUFBcndCLE1BQUEsQ0FBZTZ3QixnQkFBZ0IsTUFBRyxDQUFDO01BQ3JGLElBQU1DLGVBQWUsR0FBRy9zQixNQUFNLENBQUMyRyxPQUFPLENBQUMsbUJBQW1CLENBQUM7TUFDM0QsSUFBSSxDQUFDb21CLGVBQWUsRUFBRTtRQUNsQjl4QixtREFBRyxDQUFDLFlBQVksRUFBRSx3RUFBd0UsQ0FBQztRQUMzRjtNQUNKO01BQ0E7QUFDWjtBQUNBO0FBQ0E7QUFDQTtNQUNZLElBQU0reEIsd0JBQXdCLEdBQUd2cUIsd0RBQU8sQ0FBQ2UsTUFBTSxDQUFDLE1BQU07UUFDbER1cEIsZUFBZSxDQUFDcnBCLEtBQUssQ0FBQ3VwQixVQUFVLEdBQUcsUUFBUTtRQUMzQztRQUNBSixXQUFXLENBQUNucEIsS0FBSyxDQUFDd00sUUFBUSxHQUFHLFVBQVU7UUFDdkM7UUFDQTJjLFdBQVcsQ0FBQzNuQixTQUFTLENBQUMwbEIsTUFBTSxDQUFDLG9CQUFvQixDQUFDO1FBQ2xEO1FBQ0FpQyxXQUFXLENBQUMxeUIsWUFBWSxDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUM7UUFDakQsSUFBTTBGLE1BQU0sR0FBR0wsb0VBQWEsQ0FBQ3F0QixXQUFXLENBQUN2c0IsRUFBRSxDQUFDO1FBQzVDLElBQUlULE1BQU0sRUFDTkEsTUFBTSxDQUFDMkMsYUFBYSxHQUFHLEtBQUs7TUFDcEMsQ0FBQyxDQUFDO01BQ0Y7QUFDWjtBQUNBO01BQ1ksSUFBTTBxQiwyQkFBMkIsR0FBR0Ysd0JBQXdCLENBQUM3cUIsSUFBSSxDQUFDLE1BQU07UUFDcEUsSUFBTWdyQixlQUFlLEdBQUdsekIsUUFBUSxDQUFDQyxhQUFhLENBQUMsS0FBSyxDQUFDO1FBQ3JEaXpCLGVBQWUsQ0FBQzdzQixFQUFFLE1BQUFyRSxNQUFBLENBQU02d0IsZ0JBQWdCLGVBQVk7UUFDcERLLGVBQWUsQ0FBQ2pvQixTQUFTLENBQUNFLEdBQUcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDO1FBQ3REK25CLGVBQWUsQ0FBQ2h6QixZQUFZLENBQUMsYUFBYSxFQUFFLE1BQU0sQ0FBQztRQUNuRDtRQUNBZ3pCLGVBQWUsQ0FBQ3pwQixLQUFLLENBQUN3TSxRQUFRLEdBQUcsVUFBVTtRQUMzQztRQUNBaWQsZUFBZSxDQUFDenBCLEtBQUssQ0FBQzBaLEdBQUcsTUFBQW5oQixNQUFBLENBQU1xcUIsYUFBYSxPQUFJO1FBQ2hEO1FBQ0E2RyxlQUFlLENBQUN6cEIsS0FBSyxDQUFDVixLQUFLLEdBQUcsTUFBTTtRQUNwQyxPQUFPUCx3REFBTyxDQUNUZSxNQUFNLENBQUMsTUFBTTtVQUNkcXBCLFdBQVcsQ0FBQ08scUJBQXFCLENBQUMsV0FBVyxFQUFFRCxlQUFlLENBQUM7UUFDbkUsQ0FBQyxDQUFDLENBQ0dockIsSUFBSSxDQUFDLE1BQU1nckIsZUFBZSxDQUFDO01BQ3BDLENBQUMsQ0FBQztNQUNGO0FBQ1o7QUFDQTtNQUNZLEtBQUtELDJCQUEyQixDQUFDL3FCLElBQUksQ0FBRWdyQixlQUFlLElBQUs7UUFDdkQ7QUFDaEI7QUFDQTtRQUNnQixJQUFNRSxXQUFXLEdBQUc3ekIsTUFBTSxDQUFDcUYsU0FBUyxDQUMvQkMsTUFBTSxDQUFDLENBQUMsQ0FDUnd1QixRQUFRLENBQUMsQ0FBQyxDQUNWdGxCLElBQUksQ0FBRWljLENBQUMsSUFBS0EsQ0FBQyxDQUFDbGtCLGdCQUFnQixDQUFDLENBQUMsS0FBSytzQixnQkFBZ0IsQ0FBQztRQUMzRCxJQUFJLENBQUNPLFdBQVcsRUFBRTtVQUNkcHlCLG1EQUFHLENBQUMsWUFBWSxFQUFFLCtEQUErRCxDQUFDO1VBQ2xGO1FBQ0o7UUFDQTtBQUNoQjtBQUNBO1FBQ2dCLElBQU11QixhQUFhLEdBQUdpd0IsU0FBUyxDQUFDanpCLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ3FDLGdCQUFnQixDQUFDLENBQUMsRUFBR3pGLEdBQUcsSUFBS2xDLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQ0MsTUFBTSxDQUFDLENBQUMsQ0FBQ3VDLFlBQVksQ0FBQzNGLEdBQUcsQ0FBQyxDQUFDO1FBQ25JLElBQU02eEIsYUFBYSxHQUFHZCxTQUFTLENBQUNZLFdBQVcsQ0FBQ2xzQixnQkFBZ0IsQ0FBQyxDQUFDLEVBQUd6RixHQUFHLElBQUsyeEIsV0FBVyxDQUFDaHNCLFlBQVksQ0FBQzNGLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZHVCxtREFBRyxDQUFDLFlBQVksRUFBRSxrQ0FBa0MsRUFBRUssTUFBTSxDQUFDa3lCLFdBQVcsQ0FBQyxDQUFDLEdBQUdoeEIsYUFBYSxFQUFFLEdBQUcrd0IsYUFBYSxDQUFDLENBQUMsQ0FBQztRQUMvRztBQUNoQjtBQUNBO1FBQ2dCLElBQU1FLGlCQUFpQixHQUFHLENBQ3RCLEdBQUdqeEIsYUFBYSxFQUNoQixHQUFHK3dCLGFBQWEsRUFDaEIsQ0FBQyxVQUFVLEVBQUUsQ0FBQ1osZ0JBQWdCLENBQUNMLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFDeEMsQ0FBQyxNQUFNLEVBQUUsQ0FBQ2hmLE1BQU0sQ0FBQyxDQUFDLENBQ3JCO1FBQ0Q7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO1FBQ2dCek8sU0FBUyxDQUNKQyxNQUFNLENBQUMsQ0FBQyxDQUNSdUYsZ0JBQWdCLENBQUMsaUJBQWlCLEVBQUUsVUFBVXpFLEtBQUssRUFBRTtVQUN0RCxJQUFNME4sTUFBTSxHQUFHMU4sS0FBSyxDQUFDRSxJQUFJLENBQUNDLGdCQUFnQixDQUFDLENBQUM7VUFDNUMsSUFBSXVOLE1BQU0sS0FBSzZmLGVBQWUsQ0FBQzdzQixFQUFFLEVBQUU7WUFDL0IsSUFBTW9CLElBQUksR0FBRzlCLEtBQUssQ0FBQzhCLElBQUk7WUFDdkIsSUFBSTdGLEtBQUssQ0FBQ0MsT0FBTyxDQUFDNEYsSUFBSSxDQUFDLElBQUlBLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtjQUNoQyxJQUFNZ3NCLFFBQVEsR0FBR2hzQixJQUFJLENBQUMsQ0FBQyxDQUFDO2NBQ3hCekcsbURBQUcsQ0FBQyxZQUFZLDRCQUFBZ0IsTUFBQSxDQUE0Qnl4QixRQUFRLENBQUUsQ0FBQztjQUN2RCxLQUFLanJCLHdEQUFPLENBQUNlLE1BQU0sQ0FBQyxNQUFNO2dCQUN0QixJQUFNbXFCLFVBQVUsTUFBQTF4QixNQUFBLENBQU0sQ0FBQ29kLCtFQUFvQixDQUFDLENBQUMsS0FBSyxRQUFRLEdBQ3BEcVUsUUFBUSxHQUNSbnpCLHVFQUFPLENBQUMyTCxnQkFBZ0IsQ0FDckJqRCxNQUFNLElBQUlxakIsYUFBYSxPQUFJO2dCQUNwQ3JyQixtREFBRyxDQUFDLFlBQVksa0RBQUFnQixNQUFBLENBQWtEMHhCLFVBQVUsQ0FBRSxDQUFDO2dCQUMvRWQsV0FBVyxDQUFDbnBCLEtBQUssQ0FBQ1QsTUFBTSxHQUFHMHFCLFVBQVU7Z0JBQ3JDO0FBQ2hDO0FBQ0E7QUFDQTtnQkFDZ0NSLGVBQWUsQ0FBQ3pwQixLQUFLLENBQUNrRCxPQUFPLEdBQUcsTUFBTTtnQkFDdEN1bUIsZUFBZSxDQUFDenBCLEtBQUssQ0FBQ2txQixhQUFhLEdBQy9CLFFBQVE7Z0JBQ1pULGVBQWUsQ0FBQ3pwQixLQUFLLENBQUNvYyxjQUFjLEdBQ2hDLFFBQVE7Z0JBQ1pxTixlQUFlLENBQUN6cEIsS0FBSyxDQUFDbXFCLFVBQVUsR0FDNUIsUUFBUTtnQkFDWlYsZUFBZSxDQUFDenBCLEtBQUssQ0FBQ1QsTUFBTSxrQkFBQWhILE1BQUEsQ0FBa0JxcUIsYUFBYSxRQUFLO2dCQUNoRTtBQUNoQztBQUNBO0FBQ0E7Z0JBQ2dDdG1CLE1BQU0sQ0FBQzBELEtBQUssQ0FBQ1QsTUFBTSxHQUFHMHFCLFVBQVU7Z0JBQ2hDWixlQUFlLENBQUNycEIsS0FBSyxDQUFDVCxNQUFNLEdBQ3hCMHFCLFVBQVU7Y0FDbEIsQ0FBQyxDQUFDO1lBQ047VUFDSjtRQUNKLENBQUMsQ0FBQztRQUNGO0FBQ2hCO0FBQ0E7UUFDZ0JuMEIsTUFBTSxDQUFDcUYsU0FBUyxDQUFDNk4sR0FBRyxDQUFDcE8sSUFBSSxDQUFDLE1BQU07VUFDNUIsSUFBTTtZQUFFaXVCLEtBQUs7WUFBRUM7VUFBYSxDQUFDLEdBQUdILFdBQVcsQ0FBQ0MsTUFBTSxDQUFDO1VBQ25EO1VBQ0EsSUFBTXdCLFlBQVksR0FBR2p2QixTQUFTLENBQUNrdkIsVUFBVSxDQUFDVixXQUFXLENBQUNwc0IsYUFBYSxDQUFDLENBQUMsRUFBRXNyQixLQUFLLEVBQUVZLGVBQWUsQ0FBQzdzQixFQUFFLENBQUM7VUFDakcsSUFBSXd0QixZQUFZLEVBQUU7WUFDZDtZQUNBQSxZQUFZLENBQUNFLGlCQUFpQixDQUFDeEIsWUFBWSxDQUFDO1lBQzVDc0IsWUFBWSxDQUFDRyxVQUFVLENBQUN6MEIsTUFBTSxDQUFDcUYsU0FBUyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDO1lBQ2xEMnVCLGlCQUFpQixDQUFDbHVCLE9BQU8sQ0FBQzlELElBQUEsSUFBa0I7Y0FBQSxJQUFqQixDQUFDQyxHQUFHLEVBQUVDLEtBQUssQ0FBQyxHQUFBRixJQUFBO2NBQ25DcXlCLFlBQVksQ0FBQ2piLFlBQVksQ0FBQ25YLEdBQUcsRUFBRUMsS0FBSyxDQUFDO1lBQ3pDLENBQUMsQ0FBQztZQUNGVixtREFBRyxDQUFDLFlBQVksRUFBRSx1Q0FBdUMsRUFBRTZ5QixZQUFZLENBQUNJLGVBQWUsQ0FBQyxDQUFDLENBQUM7WUFDMUZqekIsbURBQUcsQ0FBQyxZQUFZLGdDQUFBZ0IsTUFBQSxDQUFnQ2t4QixlQUFlLENBQUM3c0IsRUFBRSxNQUFHLENBQUM7WUFDdEV6QixTQUFTLENBQUMrSCxPQUFPLENBQUN1bUIsZUFBZSxDQUFDN3NCLEVBQUUsQ0FBQztVQUN6QztRQUNKLENBQUMsQ0FBQztNQUNOLENBQUMsQ0FBQztJQUNOLENBQUMsQ0FBQztFQUNOLENBQUMsQ0FBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaFF3QztBQUN6QztBQUNBO0FBQ0EsSUFBSTZ0QixVQUFVLEdBQUcsS0FBSztBQUN0QixJQUFJQyxPQUFPLEdBQUcsQ0FBQyxDQUFDO0FBQ2hCLElBQUlDLGFBQWEsR0FBRyxDQUFDO0FBQ3JCLElBQUlDLFFBQVE7QUFDWixJQUFJQyxnQkFBZ0IsR0FBRyxFQUFFO0FBQ3pCLElBQU1DLEtBQUssR0FBR0EsQ0FBQSxLQUFNO0VBQ2hCTCxVQUFVLEdBQUcsS0FBSztFQUNsQkMsT0FBTyxHQUFHLENBQUMsQ0FBQztFQUNaQyxhQUFhLEdBQUcsQ0FBQztBQUNyQixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0EsSUFBTUksYUFBYSxHQUFJQyxJQUFJLEtBQU07RUFDN0IxckIsS0FBSyxFQUFFMHJCLElBQUksQ0FBQzFyQixLQUFLO0VBQ2pCQyxNQUFNLEVBQUV5ckIsSUFBSSxDQUFDenJCLE1BQU07RUFDbkJtYSxHQUFHLEVBQUVzUixJQUFJLENBQUN0UixHQUFHO0VBQ2J5RSxNQUFNLEVBQUU2TSxJQUFJLENBQUM3TSxNQUFNO0VBQ25COE0sSUFBSSxFQUFFRCxJQUFJLENBQUNDLElBQUk7RUFDZkMsS0FBSyxFQUFFRixJQUFJLENBQUNFO0FBQ2hCLENBQUMsQ0FBQztBQUNGLElBQU1DLGVBQWUsR0FBR0EsQ0FBQ0MsUUFBUSxFQUFFQyxPQUFPLEtBQUs7RUFBQSxJQUFBQyxpQkFBQTtFQUMzQyxDQUFBQSxpQkFBQSxHQUFBWixPQUFPLENBQUNVLFFBQVEsQ0FBQyxjQUFBRSxpQkFBQSxlQUFqQkEsaUJBQUEsQ0FBbUJDLE9BQU8sQ0FBQyxJQUFJLEVBQUVSLGFBQWEsQ0FBQ00sT0FBTyxDQUFDLENBQUM7QUFDNUQsQ0FBQztBQUNELElBQU1HLGFBQWEsR0FBSTV1QixFQUFFLElBQUs7RUFBQSxJQUFBNnVCLFdBQUE7RUFDMUIsSUFBTWx2QixJQUFJLElBQUFrdkIsV0FBQSxHQUFHZixPQUFPLENBQUM5dEIsRUFBRSxDQUFDLGNBQUE2dUIsV0FBQSx1QkFBWEEsV0FBQSxDQUFhbHZCLElBQUk7RUFDOUIsT0FBTyxDQUFDSyxFQUFFLEVBQUVMLElBQUksQ0FBQzZuQixxQkFBcUIsQ0FBQyxDQUFDLENBQUM7QUFDN0MsQ0FBQztBQUNELElBQU1zSCxXQUFXLEdBQUlDLE9BQU8sSUFBSztFQUM3QmQsZ0JBQWdCLEdBQUdjLE9BQU8sQ0FDckJsVixNQUFNLENBQUUzYixDQUFDLElBQUtBLENBQUMsQ0FBQzh3QixpQkFBaUIsR0FBRyxDQUFDLENBQUMsQ0FDdEM5ekIsR0FBRyxDQUFFZ0QsQ0FBQyxJQUFLQSxDQUFDLENBQUMrd0IsTUFBTSxDQUFDanZCLEVBQUUsQ0FBQztBQUNoQyxDQUFDO0FBQ0Q7QUFDQSxJQUFNa3ZCLFFBQVEsR0FBR0EsQ0FBQSxLQUFNO0VBQ25CLElBQUksQ0FBQ3JCLFVBQVUsRUFBRTtJQUNiQSxVQUFVLEdBQUcsSUFBSTtJQUNqQixLQUFLMXJCLHdEQUFPLENBQUNXLE9BQU8sQ0FBQyxNQUFNO01BQ3ZCK3FCLFVBQVUsR0FBRyxLQUFLO01BQ2xCSSxnQkFBZ0IsQ0FBQy95QixHQUFHLENBQUMwekIsYUFBYSxDQUFDLENBQUMzdkIsT0FBTyxDQUFFb1AsSUFBSSxJQUFLO1FBQ2xEa2dCLGVBQWUsQ0FBQ2xnQixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUVBLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztNQUNyQyxDQUFDLENBQUM7SUFDTixDQUFDLENBQUM7RUFDTjtBQUNKLENBQUM7QUFDRCxJQUFNOGdCLGlCQUFpQixHQUFHQSxDQUFDenZCLE1BQU0sRUFBRWl2QixPQUFPLEtBQUs7RUFDM0MsSUFBSVosYUFBYSxLQUFLLENBQUMsRUFBRTtJQUNyQjcwQixNQUFNLENBQUM2SyxnQkFBZ0IsQ0FBQyxRQUFRLEVBQUVtckIsUUFBUSxFQUFFO01BQ3hDRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7SUFDRnBCLFFBQVEsR0FBRyxJQUFJcUIsb0JBQW9CLENBQUNQLFdBQVcsQ0FBQztFQUNwRDtFQUNBaEIsT0FBTyxDQUFDcHVCLE1BQU0sQ0FBQ00sRUFBRSxDQUFDLEdBQUc7SUFDakJMLElBQUksRUFBRUQsTUFBTTtJQUNaNHZCLE9BQU8sRUFBRSxLQUFLO0lBQ2RYO0VBQ0osQ0FBQztFQUNEWixhQUFhLElBQUksQ0FBQztFQUNsQixJQUFJQyxRQUFRLEVBQUU7SUFDVkEsUUFBUSxDQUFDdUIsT0FBTyxDQUFDN3ZCLE1BQU0sQ0FBQztFQUM1QjtFQUNBLEtBQUt5Qyx3REFBTyxDQUNQVyxPQUFPLENBQUMsTUFBTXBELE1BQU0sQ0FBQzhuQixxQkFBcUIsQ0FBQyxDQUFDLENBQUMsQ0FDN0MzbEIsSUFBSSxDQUFFNHNCLE9BQU8sSUFBSztJQUNuQkYsZUFBZSxDQUFDN3VCLE1BQU0sQ0FBQ00sRUFBRSxFQUFFeXVCLE9BQU8sQ0FBQztFQUN2QyxDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsSUFBTWUsb0JBQW9CLEdBQUk5dkIsTUFBTSxJQUFLO0VBQ3JDLElBQUlBLE1BQU0sQ0FBQ00sRUFBRSxJQUFJOHRCLE9BQU8sRUFBRTtJQUN0QixJQUFJRSxRQUFRLEVBQUU7TUFDVkEsUUFBUSxDQUFDeUIsU0FBUyxDQUFDL3ZCLE1BQU0sQ0FBQztJQUM5QjtJQUNBLE9BQU9vdUIsT0FBTyxDQUFDcHVCLE1BQU0sQ0FBQ00sRUFBRSxDQUFDO0lBQ3pCK3RCLGFBQWEsSUFBSSxDQUFDO0VBQ3RCO0VBQ0EsSUFBSUEsYUFBYSxLQUFLLENBQUMsRUFBRTtJQUNyQjcwQixNQUFNLENBQUMySyxtQkFBbUIsQ0FBQyxRQUFRLEVBQUVxckIsUUFBUSxDQUFDO0lBQzlDLElBQUlsQixRQUFRLEVBQUU7TUFDVkEsUUFBUSxDQUFDMEIsVUFBVSxDQUFDLENBQUM7TUFDckIxQixRQUFRLEdBQUcsSUFBSTtJQUNuQjtFQUNKO0FBQ0osQ0FBQztBQUNELElBQU0yQixVQUFVLEdBQUlyZ0IsQ0FBQyxJQUFLLE9BQU9BLENBQUMsS0FBSyxVQUFVO0FBQ2pELElBQU1qSCxJQUFJLEdBQUkyaEIsUUFBUSxJQUFLO0VBQ3ZCQSxRQUFRLENBQUMsUUFBUSxFQUFFLENBQUMyRSxPQUFPLEVBQUVpQixLQUFLLEVBQUVsd0IsTUFBTSxLQUFLO0lBQzNDLElBQUksQ0FBQ0EsTUFBTSxFQUNQO0lBQ0osSUFBSWt3QixLQUFLLElBQUlELFVBQVUsQ0FBQ2hCLE9BQU8sQ0FBQyxFQUFFO01BQzlCUSxpQkFBaUIsQ0FBQ3p2QixNQUFNLEVBQUVpdkIsT0FBTyxDQUFDO0lBQ3RDLENBQUMsTUFDSTtNQUNEYSxvQkFBb0IsQ0FBQzl2QixNQUFNLENBQUM7SUFDaEM7RUFDSixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ00sSUFBTXhCLENBQUMsR0FBRztFQUFFaXhCLGlCQUFpQjtFQUFFSyxvQkFBb0I7RUFBRXRCO0FBQU0sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25HekI7QUFDbUQ7QUFDN0YsSUFBTWpnQixtQ0FBbUMsR0FBSStiLFFBQVEsSUFBSztFQUN0REEsUUFBUSxDQUFDLGdCQUFnQjtJQUFBLElBQUE3dUIsSUFBQSxHQUFBdVEsaUJBQUEsQ0FBRSxXQUFPdWUsS0FBSyxFQUFFQyxHQUFHLEVBQUV4cUIsTUFBTSxFQUFLO01BQ3JELElBQU13QixNQUFNLEdBQUd4QixNQUFNLGFBQU5BLE1BQU0sdUJBQU5BLE1BQU0sQ0FBRTJHLE9BQU8sQ0FBQyxhQUFhLENBQUM7TUFDN0MsSUFBSW5GLE1BQU0sSUFDTjJwQix3REFBUSxDQUFDWixLQUFLLENBQUMsSUFDZixVQUFVLElBQUlBLEtBQUssSUFDbkIsT0FBT0EsS0FBSyxDQUFDOEYsUUFBUSxLQUFLLFFBQVEsRUFBRTtRQUNwQyxLQUFLRixtRkFBd0IsQ0FBQyxDQUFDO1FBQy9CQyw4RUFBbUIsQ0FBQzV1QixNQUFNLENBQUNsQixFQUFFLEVBQUVpcUIsS0FBSyxDQUFDOEYsUUFBUSxDQUFDO01BQ2xEO01BQ0EsT0FBT3YyQixPQUFPLENBQUNDLE9BQU8sQ0FBQyxDQUFDO0lBQzVCLENBQUM7SUFBQSxpQkFBQW9TLEVBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBO01BQUEsT0FBQTVRLElBQUEsQ0FBQTZRLEtBQUEsT0FBQUMsU0FBQTtJQUFBO0VBQUEsSUFBQztBQUNOLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2R1RDtBQUNmO0FBQ3pDLElBQUkrakIsQ0FBQyxHQUFHOTJCLE1BQU07QUFDZCxJQUFJNDBCLE9BQU8sR0FBRyxDQUFDLENBQUM7QUFDaEIsSUFBSUMsYUFBYSxHQUFHLENBQUM7QUFDckIsSUFBSUYsVUFBVSxHQUFHLEtBQUs7QUFDdEIsSUFBTW9DLGdCQUFnQixHQUFHQSxDQUFBLEtBQU05dEIsd0RBQU8sQ0FBQ1csT0FBTyxDQUFDLE1BQU15WixvRUFBVyxDQUFDLENBQUMsQ0FBQztBQUNuRSxJQUFNMlIsS0FBSyxHQUFJZ0MsT0FBTyxJQUFLO0VBQ3ZCRixDQUFDLEdBQUdFLE9BQU8sYUFBUEEsT0FBTyxjQUFQQSxPQUFPLEdBQUloM0IsTUFBTTtFQUNyQjIwQixVQUFVLEdBQUcsS0FBSztFQUNsQkMsT0FBTyxHQUFHLENBQUMsQ0FBQztFQUNaQyxhQUFhLEdBQUcsQ0FBQztBQUNyQixDQUFDO0FBQ0QsSUFBTW9DLHNCQUFzQixHQUFHQSxDQUFDM0IsUUFBUSxFQUFFdGdCLFFBQVEsS0FBSztFQUFBLElBQUF3Z0IsaUJBQUE7RUFDbkQsQ0FBQUEsaUJBQUEsR0FBQVosT0FBTyxDQUFDVSxRQUFRLENBQUMsY0FBQUUsaUJBQUEsZUFBakJBLGlCQUFBLENBQW1CQyxPQUFPLENBQUMsSUFBSSxFQUFFemdCLFFBQVEsQ0FBQztBQUM5QyxDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1raUIsUUFBUSxHQUFHQSxDQUFBLEtBQU07RUFDbkIsSUFBSSxDQUFDdkMsVUFBVSxFQUFFO0lBQ2JBLFVBQVUsR0FBRyxJQUFJO0lBQ2pCLEtBQUtvQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNwdUIsSUFBSSxDQUFFcU0sUUFBUSxJQUFLO01BQ3ZDbFQsTUFBTSxDQUFDaVosSUFBSSxDQUFDNlosT0FBTyxDQUFDLENBQUM3dUIsT0FBTyxDQUFFdXZCLFFBQVEsSUFBSztRQUN2QzJCLHNCQUFzQixDQUFDM0IsUUFBUSxFQUFFdGdCLFFBQVEsQ0FBQztNQUM5QyxDQUFDLENBQUM7TUFDRjJmLFVBQVUsR0FBRyxLQUFLO0lBQ3RCLENBQUMsQ0FBQztFQUNOO0FBQ0osQ0FBQztBQUNELElBQU13QyxpQkFBaUIsR0FBR0EsQ0FBQzN3QixNQUFNLEVBQUVpdkIsT0FBTyxLQUFLO0VBQzNDO0FBQ0o7QUFDQTtFQUNJLElBQUlaLGFBQWEsS0FBSyxDQUFDLEVBQUU7SUFDckJpQyxDQUFDLENBQUNqc0IsZ0JBQWdCLENBQUMsUUFBUSxFQUFFcXNCLFFBQVEsQ0FBQztFQUMxQztFQUNBO0FBQ0o7QUFDQTtBQUNBO0VBQ0l0QyxPQUFPLENBQUNwdUIsTUFBTSxDQUFDTSxFQUFFLENBQUMsR0FBRztJQUNqQkwsSUFBSSxFQUFFRCxNQUFNO0lBQ1ppdkI7RUFDSixDQUFDO0VBQ0RaLGFBQWEsSUFBSSxDQUFDO0VBQ2xCO0FBQ0o7QUFDQTtFQUNJLE9BQU9rQyxnQkFBZ0IsQ0FBQyxDQUFDLENBQUNwdUIsSUFBSSxDQUFFcU0sUUFBUSxJQUFLO0lBQ3pDaWlCLHNCQUFzQixDQUFDendCLE1BQU0sQ0FBQ00sRUFBRSxFQUFFa08sUUFBUSxDQUFDO0VBQy9DLENBQUMsQ0FBQztBQUNOLENBQUM7QUFDRCxJQUFNb2lCLG9CQUFvQixHQUFJNXdCLE1BQU0sSUFBSztFQUNyQyxPQUFPb3VCLE9BQU8sQ0FBQ3B1QixNQUFNLENBQUNNLEVBQUUsQ0FBQztFQUN6Qit0QixhQUFhLElBQUksQ0FBQztFQUNsQixJQUFJQSxhQUFhLEtBQUssQ0FBQyxFQUFFO0lBQ3JCaUMsQ0FBQyxDQUFDbnNCLG1CQUFtQixDQUFDLFFBQVEsRUFBRXVzQixRQUFRLENBQUM7RUFDN0M7QUFDSixDQUFDO0FBQ0QsSUFBTUcsU0FBUyxHQUFHQSxDQUFDNUIsT0FBTyxFQUFFaUIsS0FBSyxFQUFFbHdCLE1BQU0sS0FBSztFQUMxQyxJQUFJLENBQUNBLE1BQU0sRUFBRTtJQUNUO0VBQ0o7RUFDQSxJQUFJLE9BQU9rd0IsS0FBSyxLQUFLLFNBQVMsRUFBRTtJQUM1QjtFQUNKO0VBQ0EsSUFBSUEsS0FBSyxFQUFFO0lBQ1AsS0FBS1MsaUJBQWlCLENBQUMzd0IsTUFBTSxFQUFFaXZCLE9BQU8sQ0FBQztFQUMzQyxDQUFDLE1BQ0k7SUFDRDJCLG9CQUFvQixDQUFDNXdCLE1BQU0sQ0FBQztFQUNoQztBQUNKLENBQUM7QUFDRCxJQUFNMkksSUFBSSxHQUFJMmhCLFFBQVEsSUFBSztFQUN2QkEsUUFBUSxDQUFDLFVBQVUsRUFBRXVHLFNBQVMsQ0FBQztBQUNuQyxDQUFDO0FBQ00sSUFBTXJ5QixDQUFDLEdBQUc7RUFBRW15QixpQkFBaUI7RUFBRUMsb0JBQW9CO0VBQUVwQyxLQUFLO0VBQUVxQztBQUFVLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQy9FOUUsSUFBTUMsZ0JBQWdCLEdBQUlyYyxPQUFPLElBQUssT0FBT0EsT0FBTyxLQUFLLFFBQVEsSUFDN0RBLE9BQU8sS0FBSyxJQUFJLElBQ2hCLFNBQVMsSUFBSUEsT0FBTyxJQUNwQixPQUFPQSxPQUFPLENBQUNzYyxPQUFPLEtBQUssU0FBUztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU10ZSw2QkFBNkIsR0FBR0EsQ0FBQSxLQUFNO0VBQ3hDLElBQU11ZSxjQUFjLEdBQUcvMkIsUUFBUSxDQUFDQyxhQUFhLENBQUMsUUFBUSxDQUFDO0VBQ3ZEODJCLGNBQWMsQ0FBQ3R0QixLQUFLLENBQUNrRCxPQUFPLEdBQUcsTUFBTTtFQUNyQ29xQixjQUFjLENBQUNoVyxHQUFHLE1BQUEvZSxNQUFBLENBQU16QyxNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ216QixxQkFBcUIsc0NBQW1DO0VBQ3ZHejNCLE1BQU0sQ0FBQzZLLGdCQUFnQixDQUFDLFNBQVMsRUFBRTVJLElBQUEsSUFBYztJQUFBLElBQWI7TUFBRWtUO0lBQUssQ0FBQyxHQUFBbFQsSUFBQTtJQUN4QyxJQUFJcTFCLGdCQUFnQixDQUFDbmlCLElBQUksQ0FBQyxFQUFFO01BQ3hCLElBQU07UUFBRXVpQjtNQUFpQixDQUFDLEdBQUd2aUIsSUFBSTtNQUNqQztNQUNBLElBQUl1aUIsZ0JBQWdCLEtBQUtyNEIsU0FBUyxFQUFFO1FBQ2hDVyxNQUFNLENBQUNxRixTQUFTLENBQ1hDLE1BQU0sQ0FBQyxDQUFDLENBQ1IrVCxZQUFZLENBQUMsS0FBSyxFQUFFLENBQUNxZSxnQkFBZ0IsR0FBRyxHQUFHLEdBQUcsR0FBRyxDQUFDLENBQUM7TUFDNUQ7SUFDSjtFQUNKLENBQUMsQ0FBQztFQUNGajNCLFFBQVEsQ0FBQ0csSUFBSSxDQUFDQyxXQUFXLENBQUMyMkIsY0FBYyxDQUFDO0FBQzdDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ3hCaUU7QUFDYjtBQUNpRTtBQUN0SCxJQUFNSyxhQUFhLEdBQUc3M0IsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUN3ekIsS0FBSyxLQUFLLE1BQU0sR0FDdkQsNkNBQTZDLEdBQzdDLHdDQUF3QztBQUM5QyxJQUFNdm1CLGFBQWEsR0FBR0osZ0ZBQXVCLENBQUMsQ0FBQztBQUMvQyxJQUFNNG1CLFdBQVcsSUFBQUMscUJBQUEsR0FBR3ptQixhQUFhLGFBQWJBLGFBQWEsdUJBQWJBLGFBQWEsQ0FBRWdnQixVQUFVLENBQUMsU0FBUyxDQUFDLGNBQUF5RyxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEtBQUs7QUFDakU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU0vVSxTQUFTLEdBQUcwVSwrQ0FBRyxDQUFDTSxjQUFjLENBQUMsQ0FBQyxJQUNsQyxDQUFDTiwrQ0FBRyxDQUFDTywwQkFBMEIsQ0FBQyxDQUFDLElBQ2pDeFksZ0ZBQU8sQ0FBQyxDQUFDLElBQ1RxWSxXQUFXLElBQ1gsQ0FBQ0gseURBQVMsQ0FBQztFQUNQaG1CLElBQUksRUFBRSwyQkFBMkI7RUFDakN1bUIsYUFBYSxFQUFFO0FBQ25CLENBQUMsQ0FBQyxJQUNGLENBQUNuNEIsTUFBTSxDQUFDcUUsUUFBUSxDQUFDQyxNQUFNLENBQUNDLElBQUksQ0FBQzZ6QixpQkFBaUIsSUFDOUMsQ0FBQ3A0QixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDOHpCLHVCQUF1QixJQUNwRCxDQUFDcjRCLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDQyxJQUFJLENBQUMrekIsV0FBVyxJQUN4Q3Q0QixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDZzBCLGVBQWUsS0FBSyxjQUFjLElBQzlELENBQUMsQ0FDRyxPQUFPLEVBQ1AsTUFBTSxFQUNOLFlBQVksRUFDWixNQUFNLEVBQ04seUJBQXlCLEVBQ3pCLGFBQWEsRUFDYixlQUFlLEVBQ2YsV0FBVyxDQUNkLENBQUNuNEIsUUFBUSxDQUFDSixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDZ1gsT0FBTyxDQUFDO0FBQ25EO0FBQ0E7QUFDQTtBQUNBLElBQU11RixVQUFVLEdBQUc7RUFDZm1DLFNBQVM7RUFDVHJSLElBQUksRUFBRSxTQUFTO0VBQ2ZpSixLQUFLLEVBQUUsSUFBSTtFQUNYMEcsR0FBRyxLQUFBOWUsTUFBQSxDQUFLbzFCLGFBQWEscUNBQWtDO0VBQ3ZEdlYsVUFBVSxFQUFFQSxDQUFBLEtBQU07SUFDZDdnQixtREFBRyxDQUFDLFlBQVksRUFBRSwwQ0FBMEMsQ0FBQztJQUM3RDJQLGdGQUF1QixDQUFDO01BQUVFLE1BQU0sRUFBRTtJQUFTLENBQUMsQ0FBQztJQUM3QztJQUNBLElBQUl5bUIsV0FBVyxJQUFJeG1CLGFBQWEsRUFBRTtNQUM5QlMsNEVBQW1CLENBQUMsVUFBVSxFQUFFVCxhQUFhLENBQUM7TUFDOUM5UCxtREFBRyxDQUFDLFlBQVksZ0VBQUFnQixNQUFBLENBQWlEOE8sYUFBYSxDQUFFLENBQUM7SUFDckY7RUFDSjtBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzFERDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sSUFBTXdQLEdBQUcsR0FBRztFQUNma0MsU0FBUyxFQUFFLElBQUk7RUFDZjFCLEdBQUcsRUFBRSx1Q0FBdUM7RUFDNUMzUCxJQUFJLEVBQUU7QUFDVixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7OztBQ1RvRTtBQUNyRTtBQUNBLElBQU04UCxNQUFNLEdBQUdBLENBQUEsS0FBTTtFQUNqQixJQUFNK1csSUFBSSxHQUFHO0lBQ1RDLEdBQUcsRUFBRSxhQUFhO0lBQ2xCbGMsT0FBTyxFQUFFLEdBQUc7SUFDWm1jLE1BQU0sRUFBRTtFQUNaLENBQUM7RUFDRCxJQUFNQyxJQUFJLEdBQUc1NEIsTUFBTSxDQUFDNjRCLEtBQUssQ0FBQ0osSUFBSSxDQUFDO0VBQy9CRyxJQUFJLENBQUM3bUIsTUFBTSxDQUFDLENBQUMsQ0FBQyttQixJQUFJLENBQUMsQ0FBQztBQUN4QixDQUFDO0FBQ00sSUFBTTdYLGtCQUFrQixHQUFHO0VBQzlCZ0MsU0FBUyxFQUFFLENBQUMsQ0FBQ2pqQixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ2tULFFBQVEsQ0FBQ3dKLFlBQVksSUFBSXdYLG1GQUFVLENBQUMsQ0FBQztFQUN6RWpYLEdBQUcsRUFBRSxxQ0FBcUM7RUFDMUNHO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7QUNmb0U7QUFDckU7QUFDQSxJQUFNcVgsVUFBVSxHQUFHO0VBQ2ZDLEtBQUssRUFBRSx1Q0FBdUM7RUFDOUNDLFFBQVEsRUFBRSx1Q0FBdUM7RUFDakRDLGFBQWEsRUFBRSx1Q0FBdUM7RUFDdERDLFlBQVksRUFBRSx1Q0FBdUM7RUFDckRDLE9BQU8sRUFBRSx1Q0FBdUM7RUFDaER0QixLQUFLLEVBQUUsdUNBQXVDO0VBQzlDdUIsU0FBUyxFQUFFLHVDQUF1QztFQUNsRHZiLFdBQVcsRUFBRSx1Q0FBdUM7RUFDcER3YixNQUFNLEVBQUUsdUNBQXVDO0VBQy9DLG9CQUFvQixFQUFFLHVDQUF1QztFQUM3RCxzQkFBc0IsRUFBRSx1Q0FBdUM7RUFDL0RDLE9BQU8sRUFBRSx1Q0FBdUM7RUFDaERDLElBQUksRUFBRSx1Q0FBdUM7RUFDN0NDLEdBQUcsRUFBRSx1Q0FBdUM7RUFDNUNDLFlBQVksRUFBRSx1Q0FBdUM7RUFDckRDLEtBQUssRUFBRSx1Q0FBdUM7RUFDOUNDLEtBQUssRUFBRSx1Q0FBdUM7RUFDOUNDLEtBQUssRUFBRSx1Q0FBdUM7RUFDOUNDLGFBQWEsRUFBRSx1Q0FBdUM7RUFDdERDLEVBQUUsRUFBRSx1Q0FBdUM7RUFDM0MsZ0JBQWdCLEVBQUUsdUNBQXVDO0VBQ3pEQyxFQUFFLEVBQUUsdUNBQXVDO0VBQzNDLFNBQVMsRUFBRSx1Q0FBdUM7RUFDbERDLEVBQUUsRUFBRSx1Q0FBdUM7RUFDM0MsU0FBUyxFQUFFLHVDQUF1QztFQUNsREMsS0FBSyxFQUFFLHVDQUF1QztFQUM5Q0MsUUFBUSxFQUFFLHVDQUF1QztFQUNqREMsT0FBTyxFQUFFLHVDQUF1QztFQUNoRCwrQkFBK0IsRUFBRSx1Q0FBdUM7RUFDeEUsMENBQTBDLEVBQUUsdUNBQXVDO0VBQ25GLDhCQUE4QixFQUFFLHVDQUF1QztFQUN2RSx1QkFBdUIsRUFBRSx1Q0FBdUM7RUFDaEUsb0JBQW9CLEVBQUUsdUNBQXVDO0VBQzdELDBCQUEwQixFQUFFLHVDQUF1QztFQUNuRSxpQkFBaUIsRUFBRSx1Q0FBdUM7RUFDMUQsMEJBQTBCLEVBQUUsdUNBQXVDO0VBQ25FLHVCQUF1QixFQUFFLHVDQUF1QztFQUNoRSx3QkFBd0IsRUFBRSx1Q0FBdUM7RUFDakUsd0JBQXdCLEVBQUUsdUNBQXVDO0VBQ2pFLHFCQUFxQixFQUFFLHVDQUF1QztFQUM5RCxpQkFBaUIsRUFBRSx1Q0FBdUM7RUFDMUQsMEJBQTBCLEVBQUUsdUNBQXVDO0VBQ25FLHFCQUFxQixFQUFFLHVDQUF1QztFQUM5REMsT0FBTyxFQUFFLHVDQUF1QztFQUNoREMsT0FBTyxFQUFFLHVDQUF1QztFQUNoREMsS0FBSyxFQUFFLHVDQUF1QztFQUM5Q0MsUUFBUSxFQUFFLHVDQUF1QztFQUNqREMsVUFBVSxFQUFFLHVDQUF1QztFQUNuREMsTUFBTSxFQUFFLHVDQUF1QztFQUMvQyxjQUFjLEVBQUUsdUNBQXVDO0VBQ3ZELFlBQVksRUFBRTtBQUNsQixDQUFDO0FBQ0QsSUFBTWhaLE1BQU0sR0FBR0EsQ0FBQSxLQUFNO0VBQUEsSUFBQWlaLHFCQUFBO0VBQ2pCLElBQU1DLGVBQWUsR0FBRzU2QixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDZ1gsT0FBTyxDQUFDc1IsV0FBVyxDQUFDLENBQUM7RUFDekUsSUFBTWdPLFlBQVksSUFBQUYscUJBQUEsR0FBSTVCLFVBQVUsQ0FBQzZCLGVBQWUsQ0FBQyxjQUFBRCxxQkFBQSxjQUFBQSxxQkFBQSxHQUM3QzVCLFVBQVUsQ0FBQyxZQUFZLENBQUU7RUFDN0IsSUFBTStCLFVBQVUsR0FBR0YsZUFBZSxJQUFJN0IsVUFBVSxHQUMxQzZCLGVBQWUsR0FDZiwyQkFBMkI7RUFDakMsSUFBTUcsaUJBQWlCLEdBQUc7SUFDdEJDLE1BQU0sRUFBRSxLQUFLO0lBQ2JDLElBQUksRUFBRUosWUFBWTtJQUNsQkssR0FBRyxFQUFFO0VBQ1QsQ0FBQztFQUNELElBQU1DLFlBQVksR0FBR243QixNQUFNLENBQUNvN0IsTUFBTSxDQUFDQyxXQUFXLENBQUNOLGlCQUFpQixDQUFDRSxJQUFJLENBQUM7RUFDdEVFLFlBQVksQ0FBQ0csWUFBWSxDQUFDUCxpQkFBaUIsQ0FBQztFQUM1QyxJQUFNUSxpQkFBaUIsR0FBRztJQUN0QnptQixJQUFJLEVBQUUsUUFBUTtJQUNkMG1CLE9BQU8sRUFBRXg3QixNQUFNLENBQUNxRSxRQUFRLENBQUNDLE1BQU0sQ0FBQ0MsSUFBSSxDQUFDRSxNQUFNO0lBQzNDOFcsT0FBTyxFQUFFdWY7RUFDYixDQUFDO0VBQ0RLLFlBQVksQ0FBQ00sSUFBSSxDQUFDLGFBQWEsRUFBRUYsaUJBQWlCLENBQUM7QUFDdkQsQ0FBQztBQUNNLElBQU12YSxZQUFZLEdBQUc7RUFDeEJpQyxTQUFTLEVBQUUsQ0FBQyxDQUFDampCLE1BQU0sQ0FBQ3FFLFFBQVEsQ0FBQ0MsTUFBTSxDQUFDa1QsUUFBUSxDQUFDd0osWUFBWSxJQUFJd1gsbUZBQVUsQ0FBQyxDQUFDO0VBQ3pFalgsR0FBRyxFQUFFLHNEQUFzRDtFQUMzREc7QUFDSixDQUFDLEM7Ozs7Ozs7Ozs7Ozs7OztBQ2hGRCxJQUFNZ2EscUJBQXFCLEdBQUdBLENBQUNDLGVBQWUsRUFBRWhtQixNQUFNLEtBQUs7RUFDdkQsSUFBSWdtQixlQUFlLEVBQUU7SUFDakI7SUFDQSxJQUFJMzdCLE1BQU0sQ0FBQ3FGLFNBQVMsRUFBRTtNQUNsQnJGLE1BQU0sQ0FBQ3FGLFNBQVMsQ0FBQzZOLEdBQUcsQ0FBQ3BPLElBQUksQ0FBQyxNQUFNO1FBQzVCOUUsTUFBTSxDQUFDcUYsU0FBUyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDK1QsWUFBWSxDQUFDLFFBQVEsRUFBRSxHQUFHLENBQUM7TUFDekQsQ0FBQyxDQUFDO0lBQ047SUFDQXhTLE9BQU8sQ0FBQ3BGLEdBQUcscUJBQUFnQixNQUFBLENBQXFCa1QsTUFBTSxDQUFDaW1CLGFBQWEsQ0FBRSxDQUFDO0VBQzNEO0FBQ0osQ0FBQztBQUNELElBQU1sYSxNQUFNLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUF4UCxPQUFBLEVBQUEycEIscUJBQUE7RUFDakIsQ0FBQUEscUJBQUEsSUFBQTNwQixPQUFBLEdBQUFsUyxNQUFNLEVBQUM4N0IsYUFBYSxjQUFBRCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFwQjNwQixPQUFBLENBQU80cEIsYUFBYSxHQUFLLEVBQUU7RUFDM0I5N0IsTUFBTSxDQUFDODdCLGFBQWEsQ0FBQ2gzQixJQUFJLENBQUM7SUFDdEJvTyxHQUFHLEVBQUUsY0FBYztJQUNuQjZvQixHQUFHLEVBQUU7TUFDRHZQLFFBQVEsRUFBRWtQO0lBQ2Q7RUFDSixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU14YSxNQUFNLEdBQUdqZixJQUFBO0VBQUEsSUFBQztJQUFFZ2hCO0VBQVUsQ0FBQyxHQUFBaGhCLElBQUE7RUFBQSxPQUFNO0lBQ3RDZ2hCLFNBQVM7SUFDVDFCLEdBQUcsRUFBRSwwRUFBMEU7SUFDL0UzUCxJQUFJLEVBQUUsUUFBUTtJQUNkOFA7RUFDSixDQUFDO0FBQUEsQ0FBQztBQUNLLElBQU0xYyxDQUFDLEdBQUc7RUFDYjBjLE1BQU07RUFDTmdhO0FBQ0osQ0FBQyxDOzs7Ozs7Ozs7Ozs7OztBQ2xDRDtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1ubUIsU0FBUyxHQUFHdFQsSUFBQTtFQUFBLElBQUM7SUFBRWdoQjtFQUFVLENBQUMsR0FBQWhoQixJQUFBO0VBQUEsT0FBTTtJQUN6Q2doQixTQUFTO0lBQ1QxQixHQUFHLEVBQUUsaUVBQWlFO0lBQ3RFM1AsSUFBSSxFQUFFO0VBQ1YsQ0FBQztBQUFBLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7QUNSRixJQUFNOFAsTUFBTSxHQUFHQSxDQUFBLEtBQU07RUFBQSxJQUFBc2EscUJBQUEsRUFBQTlwQixPQUFBO0VBQ2pCLENBQUE4cEIscUJBQUEsSUFBQTlwQixPQUFBLEdBQUFsUyxNQUFNLEVBQUNpOEIsc0JBQXNCLGNBQUFELHFCQUFBLGVBQTdCQSxxQkFBQSxDQUFBNXBCLElBQUEsQ0FBQUYsT0FBQSxFQUFnQztJQUM1QmdxQixvQkFBb0IsRUFBRSxTQUFTO0lBQy9CQyxvQkFBb0IsRUFBRW44QixNQUFNLENBQUNvOEIsaUJBQWlCO0lBQzlDQyx1QkFBdUIsRUFBRTtFQUM3QixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQU1sYixXQUFXLEdBQUdsZixJQUFBO0VBQUEsSUFBQztJQUFFZ2hCO0VBQVUsQ0FBQyxHQUFBaGhCLElBQUE7RUFBQSxPQUFNO0lBQzNDZ2hCLFNBQVM7SUFDVDFCLEdBQUcsRUFBRSx1REFBdUQ7SUFDNUQzUCxJQUFJLEVBQUUsYUFBYTtJQUNuQjhQO0VBQ0osQ0FBQztBQUFBLENBQUMsQyIsInNvdXJjZXMiOlsid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9jb25zdGFudHMvYWQtbGFiZWwtaGVpZ2h0LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy9jb25zdGFudHMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL2NvcmUvc3JjL2NvbnN0YW50cy90b3AtYWJvdmUtbmF2LWhlaWdodC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vY29yZS9zcmMvZGV0ZWN0LWFkLWJsb2NrZXIudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL2NvcmUvc3JjL2luZGV4LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9jb3JlL3NyYy90YXJnZXRpbmcveW91dHViZS1pbWEudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9pc0Jvb2xlYW4vaXNCb29sZWFuLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9kaXNwbGF5L2Rpc3BsYXktYWRzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9kaXNwbGF5L2Rpc3BsYXktbGF6eS1hZHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2V2ZW50cy9vbi1zbG90LWxvYWQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2V2ZW50cy9vbi1zbG90LXJlbmRlci50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvZXZlbnRzL29uLXNsb3Qtdmlld2FibGUudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2V2ZW50cy9yZW5kZXItYWR2ZXJ0LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRlZC1hZHZlcnRpc2luZy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvYWRtaXJhbC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvYXJ0aWNsZS1ib2R5LWFkdmVydHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL2RmcC1saXN0ZW5lcnMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL2R5bmFtaWMtYWQtc2xvdHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL2ZpbGwtc2xvdC1saXN0ZW5lci50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvbWVzc2VuZ2VyLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRlZC9vcGluYXJ5LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRlZC9wcmVwYXJlLWE5LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRlZC9wcmVwYXJlLWFkbWlyYWwudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL3ByZXBhcmUtZ29vZ2xldGFnLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRlZC9wcmVwYXJlLXBlcm11dGl2ZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvcHJlcGFyZS1wcmViaWQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGVkL3N0YXRpYy1hZC1zbG90cy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50ZWQvdGhpcmQtcGFydHktdGFncy50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5zZXJ0L2NvbW1lbnRzLWV4cGFuZGVkLWFkdmVydC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5zZXJ0L2ZpeHVyZXMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luc2VydC9oaWdoLW1lcmNoLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbnNlcnQvbW9iaWxlLXN0aWNreS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5zZXJ0L3NwYWNlZmluZGVyL2xpdmVibG9nLWFkdmVydHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9fX3ZlbmRvci9hOS1hcHN0YWcuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9hZC12ZXJpZmljYXRpb24vcHJlcGFyZS1hZC12ZXJpZmljYXRpb24udHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9jcmVhdGl2ZXMvcGFnZS1za2luLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvZGV0ZWN0L2RldGVjdC1nb29nbGUtcHJveHkudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9kZnAvbm9uLXJlZnJlc2hhYmxlLWxpbmUtaXRlbXMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9kZnAvc2hvdWxkLXJlZnJlc2gudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9ndW1ndW0td2lubmluZy1iaWQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvZGlzYWJsZS1yZWZyZXNoLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvbWVzc2VuZ2VyL2Z1bGwtd2lkdGgudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvZ2V0LXBhZ2UtdGFyZ2V0aW5nLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvbWVzc2VuZ2VyL2dldC1wYWdlLXVybC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL21lc3Nlbmdlci9nZXQtc3R5bGVzaGVldC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL21lc3Nlbmdlci9tZWFzdXJlLWFkLWxvYWQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvcGFzc2JhY2stcmVmcmVzaC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL21lc3Nlbmdlci9wYXNzYmFjay50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL21lc3Nlbmdlci9zY3JvbGwudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvdmlkZW8udHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9tZXNzZW5nZXIvdmlld3BvcnQudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi90aGlyZC1wYXJ0eS1jb29raWVzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvdGhpcmQtcGFydHktdGFncy9hZG1pcmFsLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvdGhpcmQtcGFydHktdGFncy9pYXMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi90aGlyZC1wYXJ0eS10YWdzL2ltci13b3JsZHdpZGUtbGVnYWN5LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvdGhpcmQtcGFydHktdGFncy9pbXItd29ybGR3aWRlLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvdGhpcmQtcGFydHktdGFncy9pbml6aW8udHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi90aGlyZC1wYXJ0eS10YWdzL3Blcm11dGl2ZS50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL3RoaXJkLXBhcnR5LXRhZ3MvcmVtYXJrZXRpbmcudHMiXSwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBVbml0OiBwaXhlbHNcbiAqL1xuZXhwb3J0IGNvbnN0IEFEX0xBQkVMX0hFSUdIVCA9IDI0O1xuIiwiZXhwb3J0IHsgQURfTEFCRUxfSEVJR0hUIH0gZnJvbSAnLi9hZC1sYWJlbC1oZWlnaHQnO1xuZXhwb3J0IHsgUFJFQklEX1RJTUVPVVQgfSBmcm9tICcuL3ByZWJpZC10aW1lb3V0JztcbmV4cG9ydCB7IFRPUF9BQk9WRV9OQVZfSEVJR0hUIH0gZnJvbSAnLi90b3AtYWJvdmUtbmF2LWhlaWdodCc7XG4iLCIvKipcbiAqIFVuaXQ6IHBpeGVscy5cbiAqXG4gKiBUaGUgbWFqb3JpdHkgb2YgYWRzIGluIHRoZSB0b3AgYmFubmVyIGFyZSAyNTBweCBoaWdoLiBXZSByYW4gYW4gZXhwZXJpbWVudFxuICogaW4gT2N0b2JlciAyMDIxIHRvIHNldCB0aGUgbWluaW11bSBoZWlnaHQgdG8gMjUwLCBhbmQgbGV0IHNtYWxsZXIgYWRzIGJlXG4gKiBjZW50cmVkIGluIHRoZSBzcGFjZS4gV2UgZGlkIG5vdCBwcm9jZXNzIHdpdGggdGhpcyBvcHRpb24sIGFzIGl0IGhhZCBhXG4gKiBuZWdhdGl2ZSBpbXBhY3Qgb24gdmlld2FiaWxpdHkgYW5kIHJldmVudWUuXG4gKlxuICovXG5leHBvcnQgY29uc3QgVE9QX0FCT1ZFX05BVl9IRUlHSFQgPSA5MDtcbi8qXG5GdXJ0aGVyIE5vdGVzXG49PT09PT09PT09PT09XG5cblRoZXJlIHdhcyBhIHZlcnkgcG9zaXRpdmUgaW1wYWN0IG9uIENMUyAoQ3VtdWxhdGl2ZSBMYXlvdXQgU2hpZnQpLCB3aGljaCBpcyBnb29kXG5mb3IgVVguIEhvd2V2ZXIsIHRoZSBuZWdhdGl2ZSBjb21tZXJjaWFsIGltcGFjdCBtZWFudCB3ZSBrZXB0IGEgaGVpZ2h0IG9mIDkwcHguXG5cbldlIHJhbiBhIDElIHNlcnZlci1zaWRlIGV4cGVyaW1lbnQgdG8gbWVhc3VyZSBDTFMgd2hlbiBkZWRpY2F0aW5nIDI1MHB4IGZvciB0aGVcbnRvcEFib3ZlTmF2LiBUaGUgZXhwZXJpbWVudCBzaG93ZWQgdGhpcyBjaGFuZ2UgaGFzIGEgc2lnbmlmaWNhbnQgcG9zaXRpdmUgaW1wYWN0XG5vbiBDTFMsIGFuZCBtb3ZlcyBhdmVyYWdlIENMUyBmb3IgdGhlIHBhZ2UgZnJvbSAwLjA5IHRvIDAuMDcgKGEgMjYlIGltcHJvdmVtZW50XG5mcm9tIHRoaXMgb25lIGNoYW5nZSkuIFRoZSBvdGhlciB3YXkgd2Ugc2xpY2VkIHRoZSBkYXRhIHdhcyB0byBsb29rIGF0IHRoZVxucGVyY2VudCBvZiBwYWdlcyB0aGF0IEdvb2dsZSBjYXRlZ29yaXNlZCBhcyBoYXZpbmcgJ2dvb2QnLCAnbmVlZHMgaW1wcm92ZW1lbnQnXG5vciAncG9vcicgQ0xTIHNjb3Jlcy4gVGhlIHZpZXdhYmlsaXR5IGZvciB0aGUgcGFnZSBkcm9wcGVkIGJ5IGFib3V0IDElLCBhbmQgZm9yXG50aGF0IHNwZWNpZmljIHNsb3QsIGJ5IDQtNiUuXG5cbldoZW4gdGhlIGV4cGVyaW1lbnQgcmFuLCB0aGUgYnJlYWtkb3duIHdhcyBhcyBmb2xsb3dzOlxuXG4tIDc0JSBvZiBvdXIgcGFnZXMgaGF2ZSBhIOKAnGdvb2TigJ0gQ0xTIHNjb3JlXG4tIDEyJSBoYXZlIGEg4oCccG9vcuKAnSBDTFMgc2NvcmUuXG4tIDcwJSB2aWV3YWJpbGl0eSBmb3IgdG9wLWFib3ZlLW5hdlxuXG5UaGlzIGNoYW5nZSByZXN1bHRlZCBpbjpcblxuLSA4NCUg4oCcZ29vZOKAnVxuLSA0JSDigJxwb29y4oCdXG4tIDY0JSB2aWV3YWJpbGl0eSBmb3IgdG9wLWFib3ZlLW5hdlxuXG5SZWxldmFudCBQdWxsIFJlcXVlc3RzXG4tLS0tLS0tLS0tLS0tLS0tLS0tLS0tXG5cbi0gaHR0cHM6Ly9naXRodWIuY29tL2d1YXJkaWFuL2Zyb250ZW5kL3B1bGwvMjQwOTVcbi0gaHR0cHM6Ly9naXRodWIuY29tL2d1YXJkaWFuL2RvdGNvbS1yZW5kZXJpbmcvcHVsbC8zNDk3XG4tIGh0dHBzOi8vZ2l0aHViLmNvbS9ndWFyZGlhbi9kb3Rjb20tcmVuZGVyaW5nL3B1bGwvMzM0MFxuXG4qL1xuIiwiLyoqXG5EZXRlY3Qgd2hldGhlciBvciBub3QgdGhlIHVzZXIgaGFzIGFuIGFkIGJsb2NraW5nIGV4dGVuc2lvbiBlbmFibGVkLlxuQSBmZXcgYWQgYmxvY2tlcnMgYXJlIG5vdCBkZXRlY3RhYmxlIHdpdGggdGhpcyBhcHByb2FjaCBlLmcuIFNhZmFyaSAvIEFkYmxvY2tcbkNvZGUgaW5zcGlyZWQgYnkganVzdC1kZXRlY3QtYWRibG9jaydzOlxuaHR0cHM6Ly9naXRodWIuY29tL3dtY211cnJheS9qdXN0LWRldGVjdC1hZGJsb2NrL2Jsb2IvbWFzdGVyL3NyYy9oZWxwZXJzLmpzXG4qL1xuLyppc3RhbmJ1bCBpZ25vcmUgZmlsZSAtLSBhZEVsZW1lbnRCbG9ja2VkIGNhbid0IGJlIHRlc3RlZCB3aXRob3V0IHBhdGNoaW5nIGVhY2ggb2YgdGhlIHByb3BlcnRpZXMgb2ZcbkhUTUxFbGVtZW50LnByb3RvdHlwZSB0aGF0IGl0IGFjY2Vzc2VzLCBkZWZlYXRpbmcgdGhlIHB1cnBvc2Ugb2YgdGhlIHRlc3QhICovXG5sZXQgYWRCbG9ja0luVXNlID0gdW5kZWZpbmVkO1xuZnVuY3Rpb24gYWRFbGVtZW50QmxvY2tlZChhZCkge1xuICAgIGlmIChhZC5vZmZzZXRQYXJlbnQgPT09IG51bGwgfHxcbiAgICAgICAgYWQub2Zmc2V0SGVpZ2h0ID09PSAwIHx8XG4gICAgICAgIGFkLm9mZnNldExlZnQgPT09IDAgfHxcbiAgICAgICAgYWQub2Zmc2V0VG9wID09PSAwIHx8XG4gICAgICAgIGFkLm9mZnNldFdpZHRoID09PSAwIHx8XG4gICAgICAgIGFkLmNsaWVudEhlaWdodCA9PT0gMCB8fFxuICAgICAgICBhZC5jbGllbnRXaWR0aCA9PT0gMCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgY29uc3QgYWRTdHlsZXMgPSB3aW5kb3cuZ2V0Q29tcHV0ZWRTdHlsZShhZCk7XG4gICAgaWYgKGFkU3R5bGVzLmdldFByb3BlcnR5VmFsdWUoJ2Rpc3BsYXknKSA9PT0gJ25vbmUnKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICBpZiAoYWRTdHlsZXMuZ2V0UHJvcGVydHlWYWx1ZSgndmlzaWJpbGl0eScpID09PSAnaGlkZGVuJylcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgY29uc3QgbW96QmluZGluZ1Byb3AgPSBhZFN0eWxlcy5nZXRQcm9wZXJ0eVZhbHVlKCctbW96LWJpbmRpbmcnKTtcbiAgICBpZiAobW96QmluZGluZ1Byb3AuaW5jbHVkZXMoJ2Fib3V0OicpKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICByZXR1cm4gZmFsc2U7XG59XG4vKipcbiAqIERldGVybWluZXMgd2hldGhlciBvciBub3QgdGhlIHVzZXIgaGFzIGFuIGFkIGJsb2NraW5nIGV4dGVuc2lvbiBlbmFibGVkLlxuICogTm90ZTogcG9zaXRpdmUgcmVzdWx0cyBjYW4gYmUgY29uc2lkZXJlZCByZWxpYWJsZSB3aGlsZSBuZWdhdGl2ZSBvbmVzIG1heSBub3QgYmUuXG4gKiBAcmV0dXJucyBQcm9taXNlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0FkQmxvY2tJblVzZSgpIHtcbiAgICBpZiAoYWRCbG9ja0luVXNlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShhZEJsb2NrSW5Vc2UpO1xuICAgIH1cbiAgICBpZiAodHlwZW9mIHdpbmRvdy5nZXRDb21wdXRlZFN0eWxlICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIC8vIE9sZCBicm93c2VycyBub3Qgc3VwcG9ydGluZyBnZXRDb21wdXRlZFN0eWxlIG1vc3QgbGlrZWx5IHdvbid0IGhhdmUgYWRCbG9ja2Vyc1xuICAgICAgICBhZEJsb2NrSW5Vc2UgPSBmYWxzZTtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShhZEJsb2NrSW5Vc2UpO1xuICAgIH1cbiAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAgICAgd2luZG93LnJlcXVlc3RBbmltYXRpb25GcmFtZSgoKSA9PiB7XG4gICAgICAgICAgICAvLyBjcmVhdGUgYSBmYWtlIGFkIGVsZW1lbnQgYW5kIGFwcGVuZCBpdCB0byB0aGUgZG9jdW1lbnRcbiAgICAgICAgICAgIGNvbnN0IGFkID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jyk7XG4gICAgICAgICAgICBhZC5zZXRBdHRyaWJ1dGUoJ2NsYXNzJywgJ2FkX3VuaXQgcHViXzMwMHgyNTAgcHViXzMwMHgyNTBtIHB1Yl83Mjh4OTAgdGV4dC1hZCB0ZXh0QWQgdGV4dF9hZCB0ZXh0X2FkcyB0ZXh0LWFkcyB0ZXh0LWFkLWxpbmtzIGFkLXRleHQgYWRTZW5zZSBhZEJsb2NrIGFkQ29udGVudCBhZEJhbm5lcicpO1xuICAgICAgICAgICAgYWQuc2V0QXR0cmlidXRlKCdzdHlsZScsICd3aWR0aDogMXB4ICFpbXBvcnRhbnQ7IGhlaWdodDogMXB4ICFpbXBvcnRhbnQ7IHBvc2l0aW9uOiBhYnNvbHV0ZSAhaW1wb3J0YW50OyBsZWZ0OiAtMTAwMDBweCAhaW1wb3J0YW50OyB0b3A6IC0xMDAwcHggIWltcG9ydGFudDsnKTtcbiAgICAgICAgICAgIGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYWQpO1xuICAgICAgICAgICAgLy8gYXZvaWQgYSBmb3JjZWQgbGF5b3V0XG4gICAgICAgICAgICB3aW5kb3cucmVxdWVzdEFuaW1hdGlvbkZyYW1lKCgpID0+IHtcbiAgICAgICAgICAgICAgICAvLyBpZiB0aGUgYWQgZWxlbWVudCBoYXMgYmVlbiBoaWRkZW4sIGFuIGFkIGJsb2NrZXIgaXMgZW5hYmxlZC5cbiAgICAgICAgICAgICAgICByZXNvbHZlKGFkRWxlbWVudEJsb2NrZWQoYWQpKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9KTtcbn1cbiIsImV4cG9ydCB7IGlzQWRCbG9ja0luVXNlIH0gZnJvbSAnLi9kZXRlY3QtYWQtYmxvY2tlcic7XG5leHBvcnQgeyBFdmVudFRpbWVyIH0gZnJvbSAnLi9ldmVudC10aW1lcic7XG5leHBvcnQgeyBhZFNpemVzIH0gZnJvbSAnLi9hZC1zaXplcyc7XG5leHBvcnQgKiBhcyBjb25zdGFudHMgZnJvbSAnLi9jb25zdGFudHMnO1xuZXhwb3J0IHsgYnlwYXNzQ29tbWVyY2lhbE1ldHJpY3NTYW1wbGluZywgaW5pdENvbW1lcmNpYWxNZXRyaWNzLCB9IGZyb20gJy4vc2VuZC1jb21tZXJjaWFsLW1ldHJpY3MnO1xuZXhwb3J0IHsgYnVpbGRQYWdlVGFyZ2V0aW5nIH0gZnJvbSAnLi90YXJnZXRpbmcvYnVpbGQtcGFnZS10YXJnZXRpbmcnO1xuZXhwb3J0IHsgcG9zdE1lc3NhZ2UgfSBmcm9tICcuL21lc3Nlbmdlci9wb3N0LW1lc3NhZ2UnO1xuZXhwb3J0IHsgYnVpbGRJbWFBZFRhZ1VybCB9IGZyb20gJy4vdGFyZ2V0aW5nL3lvdXR1YmUtaW1hJztcbmV4cG9ydCB7IGdldFBlcm11dGl2ZVBGUFNlZ21lbnRzIH0gZnJvbSAnLi9wZXJtdXRpdmUnO1xuZXhwb3J0IHsgaXNFbGlnaWJsZUZvclRlYWRzIH0gZnJvbSAnLi90YXJnZXRpbmcvdGVhZHMtZWxpZ2liaWxpdHknO1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgYnVpbGRQYWdlVGFyZ2V0aW5nLCBmaWx0ZXJWYWx1ZXMgfSBmcm9tICcuL2J1aWxkLXBhZ2UtdGFyZ2V0aW5nJztcbi8qKlxuICogQHBhcmFtICB7UmVjb3JkPHN0cmluZywgTWF5YmVBcnJheTxzdHJpbmd8bnVtYmVyfGJvb2xlYW4+PlxuICogRm9sbG93cyBodHRwczovL3N1cHBvcnQuZ29vZ2xlLmNvbS9hZG1hbmFnZXIvYW5zd2VyLzEwODA1OTdcbiAqL1xuY29uc3QgZW5jb2RlQ3VzdG9tUGFyYW1zID0gKHBhcmFtcykgPT4ge1xuICAgIGNvbnN0IGVuY29kZWRQYXJhbXMgPSBPYmplY3QuZW50cmllcyhwYXJhbXMpXG4gICAgICAgIC5tYXAoKFtrZXksIHZhbHVlXSkgPT4ge1xuICAgICAgICBjb25zdCBxdWVyeVZhbHVlID0gQXJyYXkuaXNBcnJheSh2YWx1ZSlcbiAgICAgICAgICAgID8gdmFsdWUuam9pbignLCcpXG4gICAgICAgICAgICA6IFN0cmluZyh2YWx1ZSk7XG4gICAgICAgIHJldHVybiBgJHtrZXl9PSR7ZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5VmFsdWUpfWA7XG4gICAgfSlcbiAgICAgICAgLmpvaW4oJyYnKTtcbiAgICByZXR1cm4gZW5jb2RlZFBhcmFtcztcbn07XG5jb25zdCBtZXJnZUN1c3RvbVBhcmFtc1dpdGhUYXJnZXRpbmcgPSAoY3VzdG9tUGFyYW1zLCBjb25zZW50U3RhdGUsIGNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucywgaXNTaWduZWRJbikgPT4ge1xuICAgIGxldCBwYWdlVGFyZ2V0aW5nID0ge307XG4gICAgdHJ5IHtcbiAgICAgICAgcGFnZVRhcmdldGluZyA9IGJ1aWxkUGFnZVRhcmdldGluZyh7XG4gICAgICAgICAgICBhZEZyZWU6IGZhbHNlLFxuICAgICAgICAgICAgY2xpZW50U2lkZVBhcnRpY2lwYXRpb25zLFxuICAgICAgICAgICAgY29uc2VudFN0YXRlOiBjb25zZW50U3RhdGUsXG4gICAgICAgICAgICBpc1NpZ25lZEluOiBpc1NpZ25lZEluLFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgLyoqXG4gICAgICAgICAqIERlZmVuc2l2ZSBlcnJvciBoYW5kbGluZyBpbiBjYXNlIFlvdXR1YmVBdG9tIGlzIHVzZWQgaW4gYW5cbiAgICAgICAgICogZW52aXJvbm1lbnQgd2hlcmUgZ3VhcmRpYW4uY29uZmlnLCBjb29raWVzLCBsb2NhbHN0b3JhZ2UgZXRjXG4gICAgICAgICAqIGFyZSBub3QgYXZhaWxhYmxlXG4gICAgICAgICAqL1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnRXJyb3IgYnVpbGRpbmcgWW91VHViZSBJTUEgY3VzdG9tIHBhcmFtcycsIGUpO1xuICAgICAgICByZXR1cm4gY3VzdG9tUGFyYW1zO1xuICAgIH1cbiAgICBjb25zdCBtZXJnZWRDdXN0b21QYXJhbXMgPSB7XG4gICAgICAgIC4uLmN1c3RvbVBhcmFtcyxcbiAgICAgICAgLi4ucGFnZVRhcmdldGluZyxcbiAgICB9O1xuICAgIHJldHVybiBtZXJnZWRDdXN0b21QYXJhbXM7XG59O1xuY29uc3QgYnVpbGRJbWFBZFRhZ1VybCA9ICh7IGFkVW5pdCwgY2xpZW50U2lkZVBhcnRpY2lwYXRpb25zLCBjb25zZW50U3RhdGUsIGN1c3RvbVBhcmFtcywgaXNTaWduZWRJbiwgfSkgPT4ge1xuICAgIGNvbnN0IG1lcmdlZEN1c3RvbVBhcmFtcyA9IG1lcmdlQ3VzdG9tUGFyYW1zV2l0aFRhcmdldGluZyhjdXN0b21QYXJhbXMsIGNvbnNlbnRTdGF0ZSwgY2xpZW50U2lkZVBhcnRpY2lwYXRpb25zLCBpc1NpZ25lZEluKTtcbiAgICBjb25zdCBxdWVyeVBhcmFtcyA9IHtcbiAgICAgICAgaXU6IGFkVW5pdCxcbiAgICAgICAgdGZjZDogJzAnLFxuICAgICAgICBucGE6ICcwJyxcbiAgICAgICAgc3o6ICc0ODB4MzYwfDQ4MHgzNjF8NDAweDMwMCcsXG4gICAgICAgIGdkZnBfcmVxOiAnMScsXG4gICAgICAgIG91dHB1dDogJ3Zhc3QnLFxuICAgICAgICB1bnZpZXdlZF9wb3NpdGlvbl9zdGFydDogJzEnLFxuICAgICAgICBlbnY6ICd2cCcsXG4gICAgICAgIGltcGw6ICdzJyxcbiAgICAgICAgdmFkX3R5cGU6ICdsaW5lYXInLFxuICAgICAgICB2cG9zOiAncHJlcm9sbCcsXG4gICAgICAgIHBsY210OiAnMScsXG4gICAgICAgIGRlc2NyaXB0aW9uX3VybDogZW5jb2RlVVJJQ29tcG9uZW50KGAke3dpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5ob3N0fS8ke3dpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5wYWdlSWR9YCksXG4gICAgICAgIC8qKlxuICAgICAgICAgKiBjdXN0X3BhcmFtcyBzdHJpbmcgaXMgZW5jb2RlZFxuICAgICAgICAgKiBjdXN0X3BhcmFtcyB2YWx1ZXMgYXJlIGFsc28gZW5jb2RlZCBzbyB0aGV5IHdpbGwgZ2V0IGRvdWJsZSBlbmNvZGVkXG4gICAgICAgICAqIHRoaXMgZW5zdXJlcyBhbnkgdmFsdWVzIHdpdGggc2VwYXJhdG9yIGNoYXJzICg9JiwpIGRvIG5vdCBjb25mbGljdCB3aXRoIHRoZSBtYWluIHN0cmluZ1xuICAgICAgICAgKi9cbiAgICAgICAgY3VzdF9wYXJhbXM6IGVuY29kZVVSSUNvbXBvbmVudChlbmNvZGVDdXN0b21QYXJhbXMoZmlsdGVyVmFsdWVzKG1lcmdlZEN1c3RvbVBhcmFtcykpKSxcbiAgICB9O1xuICAgIGNvbnN0IHF1ZXJ5UGFyYW1zQXJyYXkgPSBbXTtcbiAgICBmb3IgKGNvbnN0IFtrLCB2XSBvZiBPYmplY3QuZW50cmllcyhxdWVyeVBhcmFtcykpIHtcbiAgICAgICAgcXVlcnlQYXJhbXNBcnJheS5wdXNoKGAke2t9PSR7dn1gKTtcbiAgICB9XG4gICAgcmV0dXJuICgnaHR0cHM6Ly9zZWN1cmVwdWJhZHMuZy5kb3VibGVjbGljay5uZXQvZ2FtcGFkL2Fkcz8nICtcbiAgICAgICAgcXVlcnlQYXJhbXNBcnJheS5qb2luKCcmJykpO1xufTtcbmV4cG9ydCB7IGJ1aWxkSW1hQWRUYWdVcmwgfTtcbiIsImNvbnN0IGlzQm9vbGVhbiA9IChfKSA9PiB7XG4gICAgcmV0dXJuIHR5cGVvZiBfID09PSBcImJvb2xlYW5cIjtcbn07XG5leHBvcnQgeyBpc0Jvb2xlYW4gfTtcbiIsImltcG9ydCB7IHBhZ2VTa2luIH0gZnJvbSAnLi4vbGliL2NyZWF0aXZlcy9wYWdlLXNraW4nO1xuaW1wb3J0IHsgZGZwRW52IH0gZnJvbSAnLi4vbGliL2RmcC9kZnAtZW52JztcbmltcG9ydCB7IGxvYWRBZHZlcnQgfSBmcm9tICcuL2xvYWQtYWR2ZXJ0JztcbmNvbnN0IGRpc3BsYXlBZHMgPSAoKSA9PiB7XG4gICAgLypcbiAgICAgKiBXZSBlbmFibGUgU2luZ2xlIFJlcXVlc3QgQXJjaGl0ZWN0dXJlIChTUkEpIGJ5IGludm9raW5nOlxuICAgICAqIGdvb2dsZXRhZy5wdWJhZHMoKS5lbmFibGVTaW5nbGVSZXF1ZXN0KClcbiAgICAgKlxuICAgICAqIFRoaXMgaW5zdHJ1Y3RzIGdvb2dsZXRhZy5wdWJhZHMgdG8gY29tYmluZSByZXF1ZXN0cyBmb3IgYWxsIChmaXhlZCkgYWRzIGludG8gb25lIHJlcXVlc3RcbiAgICAgKiBGcm9tIHRoaXMgb25lIHJlcXVlc3QgR29vZ2xlIEFkIE1hbmFnZXIgd2lsbCB0aGVuIHJ1biBhbGwgYXVjdGlvbnMgZm9yIGV2ZXJ5IHNsb3RcbiAgICAgKlxuICAgICAqIFdlIHRyaWdnZXIgU1JBIGJ5IGNhbGxpbmcgZ29vZ2xldGFnLmRpc3BsYXkoKSBvbiB0aGUgZmlyc3Qgc2xvdFxuICAgICAqIEFsbCBvdGhlciB1bmZldGNoZWQgc2xvdHMgd2lsbCBiZSBpbmNsdWRlZCBpbiB0aGlzIGZpcnN0IHJlcXVlc3RcbiAgICAgKlxuICAgICAqIGh0dHBzOi8vc3VwcG9ydC5nb29nbGUuY29tL2FkbWFuYWdlci9hbnN3ZXIvMTgzMjgyP2hsPWVuXG4gICAgICogaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vcHVibGlzaGVyLXRhZy9yZWZlcmVuY2UjZ29vZ2xldGFnLmRpc3BsYXlcbiAgICAgKlxuICAgICAqL1xuICAgIHdpbmRvdy5nb29nbGV0YWcucHViYWRzKCkuZW5hYmxlU2luZ2xlUmVxdWVzdCgpO1xuICAgIHdpbmRvdy5nb29nbGV0YWcucHViYWRzKCkuY29sbGFwc2VFbXB0eURpdnMoKTtcbiAgICB3aW5kb3cuZ29vZ2xldGFnLmVuYWJsZVNlcnZpY2VzKCk7XG4gICAgY29uc3QgZmlyc3RBZHZlcnRUb0xvYWQgPSBkZnBFbnYuYWR2ZXJ0c1RvTG9hZC5sZW5ndGhcbiAgICAgICAgPyBkZnBFbnYuYWR2ZXJ0c1RvTG9hZFswXVxuICAgICAgICA6IHVuZGVmaW5lZDtcbiAgICBpZiAoZmlyc3RBZHZlcnRUb0xvYWQpIHtcbiAgICAgICAgbG9hZEFkdmVydChmaXJzdEFkdmVydFRvTG9hZCk7XG4gICAgICAgIGRmcEVudi5hZHZlcnRzVG9Mb2FkID0gW107XG4gICAgfVxuICAgIHBhZ2VTa2luKCk7XG59O1xuZXhwb3J0IHsgZGlzcGxheUFkcyB9O1xuIiwiaW1wb3J0IHsgZGZwRW52IH0gZnJvbSAnLi4vbGliL2RmcC9kZnAtZW52JztcbmltcG9ydCB7IGVuYWJsZUxhenlMb2FkIH0gZnJvbSAnLi9sYXp5LWxvYWQnO1xuY29uc3QgZGlzcGxheUxhenlBZHMgPSAoKSA9PiB7XG4gICAgd2luZG93Lmdvb2dsZXRhZy5wdWJhZHMoKS5jb2xsYXBzZUVtcHR5RGl2cygpO1xuICAgIHdpbmRvdy5nb29nbGV0YWcuZW5hYmxlU2VydmljZXMoKTtcbiAgICBkZnBFbnYuYWR2ZXJ0c1RvTG9hZC5mb3JFYWNoKGVuYWJsZUxhenlMb2FkKTtcbn07XG5leHBvcnQgeyBkaXNwbGF5TGF6eUFkcyB9O1xuIiwiaW1wb3J0IHsgcG9zdE1lc3NhZ2UgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL21lc3Nlbmdlci9wb3N0LW1lc3NhZ2UnO1xuaW1wb3J0IHsgZ2V0QWR2ZXJ0QnlJZCB9IGZyb20gJy4uL2xpYi9kZnAvZ2V0LWFkdmVydC1ieS1pZCc7XG5jb25zdCBob3N0ID0gYCR7d2luZG93LmxvY2F0aW9uLnByb3RvY29sfS8vJHt3aW5kb3cubG9jYXRpb24uaG9zdH1gO1xuLyogVGhpcyBpcyBmb3IgbmF0aXZlIGFkcy4gV2Ugc2VuZCB0d28gcGllY2VzIG9mIGluZm9ybWF0aW9uOlxuICAgLSB0aGUgSUQgb2YgdGhlIGlmcmFtZSBpbnRvIHdoaWNoIHRoaXMgYWQgaXMgZW1iZWRkZWQuIFRoaXMgaXMgY3VycmVudGx5XG4gICAgIHRoZSBvbmx5IHdheSB0byBsaW5rIGFuIGluY29taW5nIG1lc3NhZ2UgdG8gdGhlIGlmcmFtZSBpdCBpcyBcImNvbWluZyBmcm9tXCJcbiAgIC0gdGhlIEhPU1Qgb2YgdGhlIHBhcmVudCBmcmFtZS4gQWdhaW4sIGluc2lkZSB0aGUgZW1iZWRkZWQgZG9jdW1lbnQgdGhlcmUgaXNcbiAgICAgbm8gd2F5IHRvIGtub3cgaWYgd2UgYXJlIHJ1bm5pbmcgdGhlIHNpdGUgaW4gcHJvZHVjdGlvbiwgZGV2IG9yIGxvY2FsIG1vZGUuXG4gICAgIEJ1dCwgdGhpcyBpbmZvcm1hdGlvbiBpcyBuZWNlc3NhcnkgaW4gdGhlIHdpbmRvdy5wb3N0TWVzc2FnZSBjYWxsLCBhbmQgc29cbiAgICAgd2UgcmVzb3J0IHRvIHNlbmRpbmcgaXQgYXMgYSB0b2tlbiBvZiB3ZWxjb21lIDopXG4qL1xuZXhwb3J0IGNvbnN0IG9uU2xvdExvYWQgPSAoZXZlbnQpID0+IHtcbiAgICBjb25zdCBhZHZlcnQgPSBnZXRBZHZlcnRCeUlkKGV2ZW50LnNsb3QuZ2V0U2xvdEVsZW1lbnRJZCgpKTtcbiAgICBpZiAoIWFkdmVydCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IGlmcmFtZSA9IGFkdmVydC5ub2RlLmdldEVsZW1lbnRzQnlUYWdOYW1lKCdpZnJhbWUnKS5pdGVtKDApO1xuICAgIGlmICghaWZyYW1lPy5jb250ZW50V2luZG93KSB7XG4gICAgICAgIGNvbnNvbGUubG9nKCdObyBpRnJhbWUgZm91bmQgZm9yIHNsb3QnLCBhZHZlcnQuaWQsIGFkdmVydC5zbG90KTtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBwb3N0TWVzc2FnZSh7XG4gICAgICAgIGlkOiBpZnJhbWUuaWQsXG4gICAgICAgIGhvc3QsXG4gICAgfSwgaWZyYW1lLmNvbnRlbnRXaW5kb3cpO1xufTtcbiIsImltcG9ydCB7IGNyZWF0ZUFkU2l6ZSB9IGZyb20gJ0BndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUvYWQtc2l6ZXMnO1xuaW1wb3J0IHsgaXNTdHJpbmcgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBnZXRBZHZlcnRCeUlkIH0gZnJvbSAnLi4vbGliL2RmcC9nZXQtYWR2ZXJ0LWJ5LWlkJztcbmltcG9ydCB7IHJlcG9ydEVycm9yIH0gZnJvbSAnLi4vbGliL2Vycm9yL3JlcG9ydC1lcnJvcic7XG5pbXBvcnQgeyBlbXB0eUFkdmVydCB9IGZyb20gJy4vZW1wdHktYWR2ZXJ0JztcbmltcG9ydCB7IHJlbmRlckFkdmVydCB9IGZyb20gJy4vcmVuZGVyLWFkdmVydCc7XG5jb25zdCByZXBvcnRFbXB0eVJlc3BvbnNlID0gKGFkU2xvdElkLCBldmVudCkgPT4ge1xuICAgIC8vIFRoaXMgZW1wdHkgc2xvdCBjb3VsZCBiZSBjYXVzZWQgYnkgYSB0YXJnZXRpbmcgcHJvYmxlbSxcbiAgICAvLyBsZXQncyByZXBvcnQgdGhlc2UgYW5kIGRpYWdub3NlIHRoZSBwcm9ibGVtIGluIHNlbnRyeS5cbiAgICAvLyBLZWVwIHRoZSBzYW1wbGUgcmF0ZSBsb3csIG90aGVyd2lzZSB3ZSdsbCBnZXQgcmF0ZS1saW1pdGVkIChyZXBvcnQtZXJyb3Igd2lsbCBhbHNvIHNhbXBsZSBkb3duKVxuICAgIGlmIChNYXRoLnJhbmRvbSgpIDwgMSAvIDEwXzAwMCkge1xuICAgICAgICBjb25zdCBhZFVuaXRQYXRoID0gZXZlbnQuc2xvdC5nZXRBZFVuaXRQYXRoKCk7XG4gICAgICAgIGNvbnN0IGFkVGFyZ2V0aW5nS2V5cyA9IGV2ZW50LnNsb3QuZ2V0VGFyZ2V0aW5nS2V5cygpO1xuICAgICAgICBjb25zdCBhZFRhcmdldGluZ0tWYWx1ZXMgPSBhZFRhcmdldGluZ0tleXMuaW5jbHVkZXMoJ2snKVxuICAgICAgICAgICAgPyBldmVudC5zbG90LmdldFRhcmdldGluZygnaycpXG4gICAgICAgICAgICA6IFtdO1xuICAgICAgICBjb25zdCBhZEtleXdvcmRzID0gYWRUYXJnZXRpbmdLVmFsdWVzLmpvaW4oJywgJyk7XG4gICAgICAgIHJlcG9ydEVycm9yKG5ldyBFcnJvcignZGZwIHJldHVybmVkIGFuIGVtcHR5IGFkIHJlc3BvbnNlJyksICdjb21tZXJjaWFsJywge1xuICAgICAgICAgICAgYWRVbml0OiBhZFVuaXRQYXRoLFxuICAgICAgICAgICAgYWRTbG90OiBhZFNsb3RJZCxcbiAgICAgICAgICAgIGFkS2V5d29yZHMsXG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5jb25zdCBzaXplRXZlbnRUb0FkU2l6ZSA9IChzaXplKSA9PiB7XG4gICAgaWYgKGlzU3RyaW5nKHNpemUpKVxuICAgICAgICByZXR1cm4gJ2ZsdWlkJztcbiAgICByZXR1cm4gY3JlYXRlQWRTaXplKE51bWJlcihzaXplWzBdKSwgTnVtYmVyKHNpemVbMV0pKTtcbn07XG5leHBvcnQgY29uc3Qgb25TbG90UmVuZGVyID0gKGV2ZW50KSA9PiB7XG4gICAgY29uc3QgYWR2ZXJ0ID0gZ2V0QWR2ZXJ0QnlJZChldmVudC5zbG90LmdldFNsb3RFbGVtZW50SWQoKSk7XG4gICAgaWYgKCFhZHZlcnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBhZHZlcnQuaXNFbXB0eSA9IGV2ZW50LmlzRW1wdHk7XG4gICAgaWYgKGV2ZW50LmlzRW1wdHkpIHtcbiAgICAgICAgZW1wdHlBZHZlcnQoYWR2ZXJ0KTtcbiAgICAgICAgcmVwb3J0RW1wdHlSZXNwb25zZShhZHZlcnQuaWQsIGV2ZW50KTtcbiAgICAgICAgYWR2ZXJ0LmZpbmlzaGVkUmVuZGVyaW5nKGZhbHNlKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBpZiBhZHZlcnQuaGFzUHJlYmlkU2l6ZSBpcyBmYWxzZSB3ZSB1c2Ugc2l6ZVxuICAgICAgICAgKiBmcm9tIHRoZSBHQU0gZXZlbnQgd2hlbiBhZGp1c3RpbmcgdGhlIHNsb3Qgc2l6ZS5cbiAgICAgICAgICogKi9cbiAgICAgICAgaWYgKCFhZHZlcnQuaGFzUHJlYmlkU2l6ZSAmJiBldmVudC5zaXplKSB7XG4gICAgICAgICAgICBhZHZlcnQuc2l6ZSA9IHNpemVFdmVudFRvQWRTaXplKGV2ZW50LnNpemUpO1xuICAgICAgICB9XG4gICAgICAgIC8vIEFzc29jaWF0ZSB0aGUgbGluZSBpdGVtIGlkIHdpdGggdGhlIGFkdmVydFxuICAgICAgICAvLyBXZSdsbCBuZWVkIGl0IGxhdGVyIHdoZW4gdGhlIHNsb3QgYmVjb21lcyB2aWV3YWJsZVxuICAgICAgICAvLyBpbiBvcmRlciB0byBkZXRlcm1pbmUgd2hldGhlciB3ZSBjYW4gcmVmcmVzaCB0aGUgc2xvdFxuICAgICAgICBhZHZlcnQubGluZUl0ZW1JZCA9IGV2ZW50LmxpbmVJdGVtSWQ7XG4gICAgICAgIGFkdmVydC5jcmVhdGl2ZUlkID0gZXZlbnQuY3JlYXRpdmVJZDtcbiAgICAgICAgYWR2ZXJ0LmNyZWF0aXZlVGVtcGxhdGVJZCA9IGV2ZW50LmNyZWF0aXZlVGVtcGxhdGVJZDtcbiAgICAgICAgdm9pZCByZW5kZXJBZHZlcnQoYWR2ZXJ0LCBldmVudCkudGhlbigoaXNSZW5kZXJlZCkgPT4ge1xuICAgICAgICAgICAgYWR2ZXJ0LmZpbmlzaGVkUmVuZGVyaW5nKGlzUmVuZGVyZWQpO1xuICAgICAgICB9KTtcbiAgICB9XG59O1xuIiwiaW1wb3J0IHsgb3V0c3RyZWFtU2l6ZXMgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2FkLXNpemVzJztcbmltcG9ydCB7IEFEX0xBQkVMX0hFSUdIVCB9IGZyb20gJ0BndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUvY29uc3RhbnRzL2FkLWxhYmVsLWhlaWdodCc7XG5pbXBvcnQgeyBFdmVudFRpbWVyIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9ldmVudC10aW1lcic7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBpc0FkU2l6ZSB9IGZyb20gJy4uL2RlZmluZS9BZHZlcnQnO1xuaW1wb3J0IHsgZW5hYmxlTGF6eUxvYWQgfSBmcm9tICcuLi9kaXNwbGF5L2xhenktbG9hZCc7XG5pbXBvcnQgeyBnZXRBZHZlcnRCeUlkIH0gZnJvbSAnLi4vbGliL2RmcC9nZXQtYWR2ZXJ0LWJ5LWlkJztcbmltcG9ydCB7IG1lbW9pemVkRmV0Y2hOb25SZWZyZXNoYWJsZUxpbmVJdGVtSWRzIH0gZnJvbSAnLi4vbGliL2RmcC9ub24tcmVmcmVzaGFibGUtbGluZS1pdGVtcyc7XG5pbXBvcnQgeyBzaG91bGRSZWZyZXNoIH0gZnJvbSAnLi4vbGliL2RmcC9zaG91bGQtcmVmcmVzaCc7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi9saWIvZmFzdGRvbS1wcm9taXNlJztcbmltcG9ydCB7IGdldFVybFZhcnMgfSBmcm9tICcuLi9saWIvdXJsJztcbmNvbnN0IEFEVkVSVF9SRUZSRVNIX1JBVEUgPSAzMF8wMDA7IC8vIDMwIHNlY29uZHMuIFRoZSBtaW5pbXVtIHRpbWUgYWxsb3dlZCBieSBHb29nbGUuXG4vKipcbiAqIFByZXZlbnQgQ0xTIHdoZW4gYW4gYWR2ZXJ0IGlzIHJlZnJlc2hlZCwgYnkgc2V0dGluZyB0aGVcbiAqIG1pbi1oZWlnaHQgb2YgdGhlIGFkIHNsb3QgdG8gdGhlIGhlaWdodCBvZiB0aGUgYWQuXG4gKi9cbmNvbnN0IHNldEFkU2xvdE1pbkhlaWdodCA9IChhZHZlcnQpID0+IHtcbiAgICAvLyBXZSBuZWVkIHRvIGtub3cgdGhlIGhlaWdodCBvZiB0aGUgYWQgdG8gc2V0IHRoZSBtaW4taGVpZ2h0XG4gICAgaWYgKCFpc0FkU2l6ZShhZHZlcnQuc2l6ZSkpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICBjb25zdCB7IHNpemUsIG5vZGUgfSA9IGFkdmVydDtcbiAgICAvLyBXaGVuIGEgcGFzc2JhY2sgb2NjdXJzLCBhIG5ldyBhZCBzbG90IGlzIGNyZWF0ZWQgd2l0aGluIHRoZSBvcmlnaW5hbCBhZCBzbG90LlxuICAgIC8vIFdlIGRvbid0IHdhbnQgdG8gc2V0IGEgbWluLWhlaWdodCBvbiB0aGUgcGFyZW50IGFkIHNsb3QsIGFzIHRoZSBjaGlsZCBhZCBzbG90XG4gICAgLy8gbWF5IGxvYWQgYW4gYWQgc2l6ZSB0aGF0IHdlIGFyZSBub3QgYXdhcmUgb2YgYXQgdGhpcyBwb2ludC4gSXQgbWF5IGJlIHNob3J0ZXIsXG4gICAgLy8gd2hpY2ggd291bGQgbWFrZSB0aGUgbWluLWhlaWdodCB3ZSBzZXQgaGVyZSB0b28gaGlnaC5cbiAgICAvLyBUaGVyZWZvcmUgaXQgaXMgc2FmZXIgdG8gZXhjbHVkZSBhZCBzbG90cyB3aGVyZSBhIHBhc3NiYWNrIG1heSBvY2N1ci5cbiAgICBjb25zdCBjYW5TbG90QmVQYXNzZWRCYWNrID0gT2JqZWN0LnZhbHVlcyhvdXRzdHJlYW1TaXplcykuc29tZSgoeyB3aWR0aCwgaGVpZ2h0IH0pID0+IHdpZHRoID09PSBzaXplLndpZHRoICYmIGhlaWdodCA9PT0gc2l6ZS5oZWlnaHQpO1xuICAgIGlmIChjYW5TbG90QmVQYXNzZWRCYWNrKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgY29uc3QgaXNTdGFuZGFyZEFkU2l6ZSA9ICFzaXplLmlzUHJveHkoKTtcbiAgICBpZiAoaXNTdGFuZGFyZEFkU2l6ZSkge1xuICAgICAgICB2b2lkIGZhc3Rkb21cbiAgICAgICAgICAgIC5tZWFzdXJlKCgpID0+IG5vZGUuZ2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsJykgPT09ICd0cnVlJylcbiAgICAgICAgICAgIC50aGVuKChoYXNMYWJlbCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbGFiZWxIZWlnaHQgPSBoYXNMYWJlbCA/IEFEX0xBQkVMX0hFSUdIVCA6IDA7XG4gICAgICAgICAgICB2b2lkIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBhZFNsb3RIZWlnaHQgPSBzaXplLmhlaWdodCArIGxhYmVsSGVpZ2h0O1xuICAgICAgICAgICAgICAgIG5vZGUuc3R5bGUubWluSGVpZ2h0ID0gYCR7YWRTbG90SGVpZ2h0fXB4YDtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIC8vIEZvciB0aGUgc2l0dWF0aW9uIHdoZW4gd2UgbG9hZCBhIG5vbi1zdGFuZGFyZCBzaXplIGFkLCBlLmcuIGZsdWlkIGFkLCBhZnRlclxuICAgICAgICAvLyBwcmV2aW91c2x5IGxvYWRpbmcgYSBzdGFuZGFyZCBzaXplIGFkLiBFbnN1cmUgdGhhdCB0aGUgcHJldmlvdXNseSBhZGRlZCBtaW4taGVpZ2h0IGlzXG4gICAgICAgIC8vIHJlbW92ZWQsIHNvIHRoYXQgYSBzbWFsbGVyIGZsdWlkIGFkIGRvZXMgbm90IGhhdmUgYSBtaW4taGVpZ2h0IGxhcmdlciB0aGFuIGl0IGlzLlxuICAgICAgICB2b2lkIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgIG5vZGUuc3R5bGUubWluSGVpZ2h0ID0gJyc7XG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5jb25zdCBzZXRTbG90QWRSZWZyZXNoID0gKGV2ZW50KSA9PiB7XG4gICAgY29uc3QgYWR2ZXJ0ID0gZ2V0QWR2ZXJ0QnlJZChldmVudC5zbG90LmdldFNsb3RFbGVtZW50SWQoKSk7XG4gICAgaWYgKCFhZHZlcnQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2b2lkIHNldEFkU2xvdE1pbkhlaWdodChhZHZlcnQpO1xuICAgIC8vIENhbGwgdGhlIG1lbW9pemVkIGZ1bmN0aW9uIHNvIHdlIG9ubHkgcmV0cmlldmUgdGhlIHZhbHVlIGZyb20gdGhlIEFQSSBvbmNlXG4gICAgdm9pZCBtZW1vaXplZEZldGNoTm9uUmVmcmVzaGFibGVMaW5lSXRlbUlkcygpXG4gICAgICAgIC50aGVuKChub25SZWZyZXNoYWJsZUxpbmVJdGVtSWRzKSA9PiB7XG4gICAgICAgIC8vIERldGVybWluZSB3aGV0aGVyIGFkIHNob3VsZCByZWZyZXNoXG4gICAgICAgIC8vIFRoaXMgdmFsdWUgd2lsbCB0aGVuIGJlIGNoZWNrZWQgd2hlbiB0aGUgdGltZXIgaGFzIGVsYXBzZWQgYW5kXG4gICAgICAgIC8vIHdlIHdhbnQgdG8ga25vdyB3aGV0aGVyIHRvIHJlZnJlc2hcbiAgICAgICAgYWR2ZXJ0LnNob3VsZFJlZnJlc2ggPSBzaG91bGRSZWZyZXNoKGFkdmVydCwgbm9uUmVmcmVzaGFibGVMaW5lSXRlbUlkcyk7XG4gICAgfSlcbiAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAn4pqg77iPIEVycm9yIGZldGNoaW5nIG5vbi1yZWZyZXNoYWJsZSBsaW5lIGl0ZW1zJywgZXJyb3IpO1xuICAgIH0pO1xuICAgIGNvbnN0IHZpZXdhYmlsaXR5VGhyZXNob2xkTXMgPSBBRFZFUlRfUkVGUkVTSF9SQVRFO1xuICAgIC8vIEV2ZW50IGxpc3RlbmVyIHRoYXQgd2lsbCBsb2FkIGFuIGFkdmVydCBvbmNlIGEgZG9jdW1lbnQgYmVjb21lcyB2aXNpYmxlXG4gICAgY29uc3Qgb25Eb2N1bWVudFZpc2libGUgPSAoKSA9PiB7XG4gICAgICAgIGlmICghZG9jdW1lbnQuaGlkZGVuKSB7XG4gICAgICAgICAgICBkb2N1bWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCd2aXNpYmlsaXR5Y2hhbmdlJywgb25Eb2N1bWVudFZpc2libGUpO1xuICAgICAgICAgICAgZW5hYmxlTGF6eUxvYWQoYWR2ZXJ0KTtcbiAgICAgICAgfVxuICAgIH07XG4gICAgc2V0VGltZW91dCgoKSA9PiB7XG4gICAgICAgIC8vIER1cmluZyB0aGUgZWxhcHNlZCB0aW1lLCBhICdkaXNhYmxlLXJlZnJlc2gnIG1lc3NhZ2UgbWF5IGhhdmUgYmVlbiBwb3N0ZWQuXG4gICAgICAgIC8vIENoZWNrIHRoZSBmbGFnIGFnYWluLlxuICAgICAgICBpZiAoIWFkdmVydC5zaG91bGRSZWZyZXNoKSB7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgLy8gSWYgdGhlIGRvY3VtZW50IGlzIGhpZGRlbiBkb24ndCByZWZyZXNoIGltbWVkaWF0ZWx5XG4gICAgICAgIC8vIEluc3RlYWQgYWRkIGFuIGV2ZW50IGxpc3RlbmVyIHRvIHJlZnJlc2ggd2hlbiBkb2N1bWVudCBiZWNvbWVzIHZpc2libGUgYWdhaW5cbiAgICAgICAgaWYgKGRvY3VtZW50LmhpZGRlbikge1xuICAgICAgICAgICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcigndmlzaWJpbGl0eWNoYW5nZScsIG9uRG9jdW1lbnRWaXNpYmxlKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGVuYWJsZUxhenlMb2FkKGFkdmVydCk7XG4gICAgICAgIH1cbiAgICB9LCB2aWV3YWJpbGl0eVRocmVzaG9sZE1zKTtcbn07XG4vKlxuICBSZXR1cm5zIGEgZnVuY3Rpb24gdG8gYmUgdXNlZCBhcyBhIGNhbGxiYWNrIGZvciBHVFAgJ2ltcHJlc3Npb25WaWV3YWJsZScgZXZlbnRcbiAgVXNlcyBVUkwgcGFyYW1ldGVycy5cbiAqL1xuY29uc3Qgb25TbG90Vmlld2FibGVGdW5jdGlvbiA9ICgpID0+IHtcbiAgICBjb25zdCBxdWVyeVBhcmFtcyA9IGdldFVybFZhcnMoKTtcbiAgICByZXR1cm4gKGV2ZW50KSA9PiB7XG4gICAgICAgIGNvbnN0IHNsb3QgPSBldmVudC5zbG90LmdldFRhcmdldGluZygnc2xvdCcpWzBdO1xuICAgICAgICBFdmVudFRpbWVyLmdldCgpLm1hcmsoJ3ZpZXdhYmxlJywgc2xvdCk7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsICdTbG90IHZpZXdhYmxlJywgc2xvdCk7XG4gICAgICAgIGlmIChxdWVyeVBhcmFtcy5hZHJlZnJlc2ggIT09ICdmYWxzZScpIHtcbiAgICAgICAgICAgIHNldFNsb3RBZFJlZnJlc2goZXZlbnQpO1xuICAgICAgICB9XG4gICAgfTtcbn07XG5leHBvcnQgeyBvblNsb3RWaWV3YWJsZUZ1bmN0aW9uIH07XG4iLCJpbXBvcnQgeyBhZFNpemVzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyByZXBvcnRFcnJvciB9IGZyb20gJy4uL2xpYi9lcnJvci9yZXBvcnQtZXJyb3InO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vbGliL2Zhc3Rkb20tcHJvbWlzZSc7XG5pbXBvcnQgeyBsb2dHdW1HdW1XaW5uaW5nQmlkIH0gZnJvbSAnLi4vbGliL2d1bWd1bS13aW5uaW5nLWJpZCc7XG5pbXBvcnQgeyBlbXB0eUFkdmVydCB9IGZyb20gJy4vZW1wdHktYWR2ZXJ0JztcbmltcG9ydCB7IHJlbmRlckFkdmVydExhYmVsIH0gZnJvbSAnLi9yZW5kZXItYWR2ZXJ0LWxhYmVsJztcbi8qKlxuICogQURWRVJUIFJFTkRFUklOR1xuICogLS0tLS0tLS0tLS0tLS0tLVxuICpcbiAqIE1vc3QgYWR2ZXJ0cyBjb21lIGJhY2sgZnJvbSBERlAgcmVhZHkgdG8gZGlzcGxheSBhcy1pcy4gQnV0IHNvbWV0aW1lcyB3ZSBuZWVkIG1vcmU6IGVtYmVkZGVkIGNvbXBvbmVudHMgdGhhdCBjYW4gc2hhcmVcbiAqIEd1YXJkaWFuIHN0eWxlcywgZm9yIGV4YW1wbGUsIG9yIGJlaGF2aW91cnMgbGlrZSBzdGlja3ktc2Nyb2xsaW5nLiBUaGlzIG1vZHVsZSBoZWxwcyAnZmluaXNoJyByZW5kZXJpbmcgYW55IGFkdmVydCwgYW5kXG4gKiBkZWNvcmF0ZXMgdGhlbSB3aXRoIHRoZXNlIGJlaGF2aW91cnMuXG4gKlxuICovXG4vKipcbiAqIFR5cGVzIG9mIGV2ZW50cyB0aGF0IGFyZSByZXR1cm5lZCB3aGVuIGV4ZWN1dGluZyBhIHNpemUgY2hhbmdlIGNhbGxiYWNrXG4gKi9cbmNvbnN0IGFkZENsYXNzSWZIYXNDbGFzcyA9IChuZXdDbGFzc05hbWVzKSA9PiBmdW5jdGlvbiBoYXNDbGFzcyhjbGFzc05hbWVzKSB7XG4gICAgcmV0dXJuIGZ1bmN0aW9uIG9uQWR2ZXJ0UmVuZGVyZWQoYWR2ZXJ0KSB7XG4gICAgICAgIGlmIChjbGFzc05hbWVzLnNvbWUoKGNsYXNzTmFtZSkgPT4gYWR2ZXJ0Lm5vZGUuY2xhc3NMaXN0LmNvbnRhaW5zKGNsYXNzTmFtZSkpKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICAgICAgICAgIG5ld0NsYXNzTmFtZXMuZm9yRWFjaCgoY2xhc3NOYW1lKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGFkdmVydC5ub2RlLmNsYXNzTGlzdC5hZGQoY2xhc3NOYW1lKTtcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9O1xufTtcbmNvbnN0IGFkZEZsdWlkMjUwID0gYWRkQ2xhc3NJZkhhc0NsYXNzKFsnYWQtc2xvdC0tZmx1aWQyNTAnXSk7XG5jb25zdCBhZGRGbHVpZCA9IGFkZENsYXNzSWZIYXNDbGFzcyhbJ2FkLXNsb3QtLWZsdWlkJ10pO1xuY29uc3QgcmVtb3ZlU3R5bGVGcm9tQWRJZnJhbWUgPSAoYWR2ZXJ0LCBzdHlsZSkgPT4ge1xuICAgIGNvbnN0IGFkSWZyYW1lID0gYWR2ZXJ0Lm5vZGUucXVlcnlTZWxlY3RvcignaWZyYW1lJyk7XG4gICAgdm9pZCBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgIGlmIChhZElmcmFtZSkge1xuICAgICAgICAgICAgYWRJZnJhbWUuc3R5bGUucmVtb3ZlUHJvcGVydHkoc3R5bGUpO1xuICAgICAgICB9XG4gICAgfSk7XG59O1xuY29uc3Qgc2l6ZUNhbGxiYWNrcyA9IHt9O1xuLyoqXG4gKiBERlAgZmx1aWQgYWRzIHNob3VsZCB1c2UgZXhpc3RpbmcgZmx1aWQtMjUwIHN0eWxlcyBpbiB0aGUgdG9wIGJhbm5lciBwb3NpdGlvblxuICogVGhlIHZlcnRpY2FsLWFsaWduIHByb3BlcnR5IGZvdW5kIG9uIERGUCBpZnJhbWVzIGFmZmVjdHMgdGhlIHNtb290aG5lc3Mgb2ZcbiAqIENTUyB0cmFuc2l0aW9ucyB3aGVuIGV4cGFuZGluZy9jb2xsYXBzaW5nIHZhcmlvdXMgbmF0aXZlIHN0eWxlIGZvcm1hdHMuXG4gKi9cbnNpemVDYWxsYmFja3NbYWRTaXplcy5mbHVpZC50b1N0cmluZygpXSA9IChhZHZlcnQpID0+IGFkZEZsdWlkKFsnYWQtc2xvdCddKShhZHZlcnQpLnRoZW4oKCkgPT4gcmVtb3ZlU3R5bGVGcm9tQWRJZnJhbWUoYWR2ZXJ0LCAndmVydGljYWwtYWxpZ24nKSk7XG5zaXplQ2FsbGJhY2tzW2FkU2l6ZXMubXB1LnRvU3RyaW5nKCldID0gKGFkdmVydCkgPT4gYWR2ZXJ0LnVwZGF0ZUV4dHJhU2xvdENsYXNzZXMoKTtcbnNpemVDYWxsYmFja3NbYWRTaXplcy5oYWxmUGFnZS50b1N0cmluZygpXSA9IChhZHZlcnQpID0+IGFkdmVydC51cGRhdGVFeHRyYVNsb3RDbGFzc2VzKCk7XG5zaXplQ2FsbGJhY2tzW2FkU2l6ZXMuc2t5c2NyYXBlci50b1N0cmluZygpXSA9IChhZHZlcnQpID0+IGFkdmVydC51cGRhdGVFeHRyYVNsb3RDbGFzc2VzKCdhZC1zbG90LS1za3knKTtcbnNpemVDYWxsYmFja3NbYWRTaXplcy5vdXRzdHJlYW1EZXNrdG9wLnRvU3RyaW5nKCldID0gKGFkdmVydCkgPT4gYWR2ZXJ0LnVwZGF0ZUV4dHJhU2xvdENsYXNzZXMoJ2FkLXNsb3QtLW91dHN0cmVhbScpO1xuc2l6ZUNhbGxiYWNrc1thZFNpemVzLm91dHN0cmVhbUdvb2dsZURlc2t0b3AudG9TdHJpbmcoKV0gPSAoYWR2ZXJ0KSA9PiBhZHZlcnQudXBkYXRlRXh0cmFTbG90Q2xhc3NlcygnYWQtc2xvdC0tb3V0c3RyZWFtJyk7XG5zaXplQ2FsbGJhY2tzW2FkU2l6ZXMub3V0c3RyZWFtTW9iaWxlLnRvU3RyaW5nKCldID0gKGFkdmVydCkgPT4gYWR2ZXJ0LnVwZGF0ZUV4dHJhU2xvdENsYXNzZXMoJ2FkLXNsb3QtLW91dHN0cmVhbScpO1xuc2l6ZUNhbGxiYWNrc1thZFNpemVzLmdvb2dsZUNhcmQudG9TdHJpbmcoKV0gPSAoYWR2ZXJ0KSA9PiBhZHZlcnQudXBkYXRlRXh0cmFTbG90Q2xhc3NlcygnYWQtc2xvdC0tZ2MnKTtcbnNpemVDYWxsYmFja3NbYWRTaXplcy5wdWJtYXRpY0ludGVyc2Nyb2xsZXIudG9TdHJpbmcoKV0gPSAoYWR2ZXJ0KSA9PiB7XG4gICAgYWR2ZXJ0LnNob3VsZFJlZnJlc2ggPSBmYWxzZTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuLyoqXG4gKiBPdXQgb2YgcGFnZSBhZHZlcnRzIC0gY3JlYXRpdmVzIHRoYXQgYXJlbid0IGRpcmVjdGx5IHNob3duIG9uIHRoZSBwYWdlIC0gbmVlZCB0byBiZSBoaWRkZW4sXG4gKiBhbmQgdGhlaXIgY29udGFpbmVycyBjbG9zZWQgdXAuXG4gKi9cbmNvbnN0IG91dE9mUGFnZUNhbGxiYWNrID0gKGFkdmVydCkgPT4ge1xuICAgIGNvbnN0IHBhcmVudCA9IGFkdmVydC5ub2RlLnBhcmVudE5vZGU7XG4gICAgcmV0dXJuIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgYWR2ZXJ0Lm5vZGUuY2xhc3NMaXN0LmFkZCgnYWQtc2xvdC0tY29sbGFwc2UnKTtcbiAgICAgICAgLy8gdG9wLWFib3ZlLW5hdiBhbmQgZnJvbnRzLWJhbm5lciBoYXZlIGFuIGV4dHJhIGNvbnRhaW5lclxuICAgICAgICBpZiAoYWR2ZXJ0LmlkLmluY2x1ZGVzKCd0b3AtYWJvdmUtbmF2JykpIHtcbiAgICAgICAgICAgIGNvbnN0IGFkQ29udGFpbmVyID0gYWR2ZXJ0Lm5vZGUuY2xvc2VzdCgnLnRvcC1iYW5uZXItYWQtY29udGFpbmVyJyk7XG4gICAgICAgICAgICBpZiAoYWRDb250YWluZXIpIHtcbiAgICAgICAgICAgICAgICBhZENvbnRhaW5lci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGlmIChhZHZlcnQuaWQuaW5jbHVkZXMoJ2Zyb250cy1iYW5uZXInKSkge1xuICAgICAgICAgICAgY29uc3QgYWRDb250YWluZXIgPSBhZHZlcnQubm9kZS5jbG9zZXN0KCcudG9wLWZyb250cy1iYW5uZXItYWQtY29udGFpbmVyJyk7XG4gICAgICAgICAgICBpZiAoYWRDb250YWluZXIpIHtcbiAgICAgICAgICAgICAgICBhZENvbnRhaW5lci5zdHlsZS5kaXNwbGF5ID0gJ25vbmUnO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIC8vIGlmIGluIGEgc2xpY2UsIGFkZCB0aGUgJ25vIG1wdScgY2xhc3NcbiAgICAgICAgaWYgKHBhcmVudC5jbGFzc0xpc3QuY29udGFpbnMoJ2ZjLXNsaWNlX19pdGVtLS1tcHUtY2FuZGlkYXRlJykpIHtcbiAgICAgICAgICAgIHBhcmVudC5jbGFzc0xpc3QuYWRkKCdmYy1zbGljZV9faXRlbS0tbm8tbXB1Jyk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5zaXplQ2FsbGJhY2tzW2FkU2l6ZXMub3V0T2ZQYWdlLnRvU3RyaW5nKCldID0gb3V0T2ZQYWdlQ2FsbGJhY2s7XG5zaXplQ2FsbGJhY2tzW2FkU2l6ZXMuZW1wdHkudG9TdHJpbmcoKV0gPSAoYWQpID0+IFByb21pc2UucmVzb2x2ZShlbXB0eUFkdmVydChhZCkpO1xuLyoqXG4gKiBDb21tZXJjaWFsIGNvbXBvbmVudHMgd2l0aCBtZXJjaCBzaXppbmcgZ2V0IGZsdWlkLTI1MCBzdHlsaW5nXG4gKi9cbnNpemVDYWxsYmFja3NbYWRTaXplcy5tZXJjaGFuZGlzaW5nLnRvU3RyaW5nKCldID0gYWRkRmx1aWQyNTAoW1xuICAgICdhZC1zbG90LS1jb21tZXJjaWFsLWNvbXBvbmVudCcsXG5dKTtcbmNvbnN0IGFkZENvbnRlbnRDbGFzcyA9IChhZFNsb3ROb2RlKSA9PiB7XG4gICAgY29uc3QgYWRTbG90Q29udGVudCA9IGFkU2xvdE5vZGUucXVlcnlTZWxlY3RvcihgIyR7YWRTbG90Tm9kZS5pZH0gPiBkaXY6bm90KC5hZC1zbG90X19sYWJlbClgKTtcbiAgICBpZiAoYWRTbG90Q29udGVudCkge1xuICAgICAgICB2b2lkIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgIGFkU2xvdENvbnRlbnQuY2xhc3NMaXN0LmFkZCgnYWQtc2xvdF9fY29udGVudCcpO1xuICAgICAgICB9KTtcbiAgICB9XG59O1xuLyogQ2VudHJlIGNlcnRhaW4gc2xvdHMgaW4gdGhlaXIgY29udGFpbmVycywgdGhpcyBjbGFzcyBpcyBhZGRlZCBkeW5hbWljYWxseSB0byBhdm9pZCByZW5kZXJpbmcgcXVpcmtzIHdpdGggdGhlIGFkIGxhYmVsIGFuZCB2YXJpYWJsZSB3aWR0aCBhZHMuICovXG5jb25zdCBhZGRDb250YWluZXJDbGFzcyA9IChhZFNsb3ROb2RlLCBpc1JlbmRlcmVkKSA9PiB7XG4gICAgY29uc3QgY2VudHJlQWRTbG90cyA9IFtcbiAgICAgICAgJ2RmcC1hZC0tdG9wLWFib3ZlLW5hdicsXG4gICAgICAgICdkZnAtYWQtLW1lcmNoYW5kaXNpbmctaGlnaCcsXG4gICAgICAgICdkZnAtYWQtLW1lcmNoYW5kaXNpbmcnLFxuICAgIF07XG4gICAgcmV0dXJuIGZhc3Rkb21cbiAgICAgICAgLm1lYXN1cmUoKCkgPT4gaXNSZW5kZXJlZCAmJlxuICAgICAgICAhYWRTbG90Tm9kZS5jbGFzc0xpc3QuY29udGFpbnMoJ2FkLXNsb3QtLWZsdWlkJykgJiZcbiAgICAgICAgYWRTbG90Tm9kZS5wYXJlbnRFbGVtZW50Py5jbGFzc0xpc3QuY29udGFpbnMoJ2FkLXNsb3QtY29udGFpbmVyJykgJiZcbiAgICAgICAgY2VudHJlQWRTbG90cy5pbmNsdWRlcyhhZFNsb3ROb2RlLmlkKSlcbiAgICAgICAgLnRoZW4oKHNob3VsZENlbnRyZSkgPT4ge1xuICAgICAgICBpZiAoc2hvdWxkQ2VudHJlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICAgICAgICAgIGFkU2xvdE5vZGUucGFyZW50RWxlbWVudD8uY2xhc3NMaXN0LmFkZCgnYWQtc2xvdC1jb250YWluZXItLWNlbnRyZS1zbG90Jyk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbi8qKlxuICogQ2hlY2sgaWYgdGhlIGFkIHNsb3QgaGFzIGEgY29ycmVzcG9uZGluZyBpZnJhbWUgdG8gaW5kaWN0ZSB0aGUgYWQgaGFzIHJlbmRlcmVkLlxuICogQHBhcmFtIGFkU2xvdFxuICogQHJldHVybnNcbiAqL1xuY29uc3QgaGFzSWZyYW1lID0gKGFkU2xvdCkgPT4gbmV3IFByb21pc2UoKHJlc29sdmUpID0+IHtcbiAgICAvLyBERlAgd2lsbCBzb21ldGltZXMgcmV0dXJuIGVtcHR5IGlmcmFtZXMsIGRlbm90ZWQgd2l0aCBhICdfX2hpZGRlbl9fJyBwYXJhbWV0ZXIgZW1iZWRkZWQgaW4gaXRzIElELlxuICAgIC8vIFdlIG5lZWQgdG8gYmUgc3VyZSBvbmx5IHRvIHNlbGVjdCB0aGUgYWQgY29udGVudCBmcmFtZS5cbiAgICBjb25zdCBpRnJhbWUgPSBhZFNsb3QucXVlcnlTZWxlY3RvcignaWZyYW1lOm5vdChbaWQqPVwiX19oaWRkZW5fX1wiXSknKTtcbiAgICByZXNvbHZlKCEhaUZyYW1lKTtcbn0pO1xuLyoqXG4gKiBAcGFyYW0gYWR2ZXJ0IC0gYXMgZGVmaW5lZCBpbiBsaWIvZGZwL0FkdmVydFxuICogQHBhcmFtIHNsb3RSZW5kZXJFbmRlZEV2ZW50IC0gR1BUIHNsb3RSZW5kZXJFbmRlZEV2ZW50XG4gKiBAcmV0dXJucyB7UHJvbWlzZX0gLSByZXNvbHZlcyBvbmNlIGFsbCBuZWNlc3NhcnkgcmVuZGVyaW5nIGlzIHF1ZXVlZCB1cFxuICovXG5jb25zdCByZW5kZXJBZHZlcnQgPSAoYWR2ZXJ0LCBzbG90UmVuZGVyRW5kZWRFdmVudCkgPT4ge1xuICAgIGNvbnN0IG1hdGNoaW5nQWQgPSB3aW5kb3cuZ3VhcmRpYW4uY29tbWVyY2lhbD8uYTlXaW5uaW5nQmlkcz8uZmluZCgoYmlkUmVzcG9uc2UpID0+IGJpZFJlc3BvbnNlLnNsb3RJRCA9PSBhZHZlcnQuaWQpO1xuICAgIGNvbnN0IGlzQTlHdW1HdW0gPSBtYXRjaGluZ0FkPy5hbXpucCA9PT0gJzFsc3hqYjQnO1xuICAgIGlmIChzbG90UmVuZGVyRW5kZWRFdmVudC5hZHZlcnRpc2VySWQgPT09IDQ3NTE1MjU0MTEgJiYgaXNBOUd1bUd1bSkge1xuICAgICAgICBjb25zdCBhZFNsb3RJZCA9IGFkdmVydC5ub2RlLmlkO1xuICAgICAgICBsb2dHdW1HdW1XaW5uaW5nQmlkKGFkU2xvdElkLCBzbG90UmVuZGVyRW5kZWRFdmVudC5hZHZlcnRpc2VySWQudG9TdHJpbmcoKSk7XG4gICAgfVxuICAgIGFkZENvbnRlbnRDbGFzcyhhZHZlcnQubm9kZSk7XG4gICAgcmV0dXJuIGhhc0lmcmFtZShhZHZlcnQubm9kZSlcbiAgICAgICAgLnRoZW4oKGlzUmVuZGVyZWQpID0+IHtcbiAgICAgICAgY29uc3QgY3JlYXRpdmVUZW1wbGF0ZUlkID0gc2xvdFJlbmRlckVuZGVkRXZlbnQuY3JlYXRpdmVUZW1wbGF0ZUlkID8/IHVuZGVmaW5lZDtcbiAgICAgICAgY29uc3QgY2FsbFNpemVDYWxsYmFjayA9ICgpID0+IHtcbiAgICAgICAgICAgIGlmIChhZHZlcnQuc2l6ZSkge1xuICAgICAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICAgICAqIFdlIHJlc2V0IGhhc1ByZWJpZFNpemUgdG8gdGhlIGRlZmF1bHQgdmFsdWUgb2YgZmFsc2UgZm9yXG4gICAgICAgICAgICAgICAgICogc3Vic2VxdWVudCBhZCByZWZyZXNoZXMgYXMgdGhleSBtYXkgbm90IGJlIHByZWJpZCBhZHMuXG4gICAgICAgICAgICAgICAgICogKi9cbiAgICAgICAgICAgICAgICBhZHZlcnQuaGFzUHJlYmlkU2l6ZSA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIGNvbnN0IHNpemVDYWxsYmFjayA9IHNpemVDYWxsYmFja3NbYWR2ZXJ0LnNpemUudG9TdHJpbmcoKV07XG4gICAgICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZShzaXplQ2FsbGJhY2sgIT09IHVuZGVmaW5lZFxuICAgICAgICAgICAgICAgICAgICA/IHNpemVDYWxsYmFjayhhZHZlcnQsIHNsb3RSZW5kZXJFbmRlZEV2ZW50KVxuICAgICAgICAgICAgICAgICAgICA6IGFkdmVydC51cGRhdGVFeHRyYVNsb3RDbGFzc2VzKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBhZGRSZW5kZXJlZENsYXNzID0gKCkgPT4gaXNSZW5kZXJlZFxuICAgICAgICAgICAgPyBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgICAgICAgICAgYWR2ZXJ0Lm5vZGUuY2xhc3NMaXN0LmFkZCgnYWQtc2xvdC0tcmVuZGVyZWQnKTtcbiAgICAgICAgICAgIH0pXG4gICAgICAgICAgICA6IFByb21pc2UucmVzb2x2ZSgpO1xuICAgICAgICByZXR1cm4gY2FsbFNpemVDYWxsYmFjaygpXG4gICAgICAgICAgICAudGhlbigoKSA9PiByZW5kZXJBZHZlcnRMYWJlbChhZHZlcnQubm9kZSwgY3JlYXRpdmVUZW1wbGF0ZUlkKSlcbiAgICAgICAgICAgIC50aGVuKCgpID0+IGFkZENvbnRhaW5lckNsYXNzKGFkdmVydC5ub2RlLCBpc1JlbmRlcmVkKSlcbiAgICAgICAgICAgIC50aGVuKGFkZFJlbmRlcmVkQ2xhc3MpXG4gICAgICAgICAgICAudGhlbigoKSA9PiBpc1JlbmRlcmVkKTtcbiAgICB9KVxuICAgICAgICAuY2F0Y2goKGVycikgPT4ge1xuICAgICAgICByZXBvcnRFcnJvcihlcnIsICdjb21tZXJjaWFsJyk7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoZmFsc2UpO1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IHJlbmRlckFkdmVydCB9O1xuIiwiaW1wb3J0IHsgaW5pdCBhcyBwcmVwYXJlQWRWZXJpZmljYXRpb24gfSBmcm9tICcuLi9saWIvYWQtdmVyaWZpY2F0aW9uL3ByZXBhcmUtYWQtdmVyaWZpY2F0aW9uJztcbmltcG9ydCB7IGJvb3RDb21tZXJjaWFsIH0gZnJvbSAnLi4vbGliL2NvbW1lcmNpYWwtYm9vdC11dGlscyc7XG5pbXBvcnQgeyBhZEZyZWVTbG90UmVtb3ZlIH0gZnJvbSAnLi9jb25zZW50ZWQvYWQtZnJlZS1zbG90LXJlbW92ZSc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRDb21zY29yZSB9IGZyb20gJy4vY29uc2VudGVkL2NvbXNjb3JlJztcbmltcG9ydCB7IGluaXREZnBMaXN0ZW5lcnMgfSBmcm9tICcuL2NvbnNlbnRlZC9kZnAtbGlzdGVuZXJzJztcbmltcG9ydCB7IGluaXREeW5hbWljQWRTbG90cyB9IGZyb20gJy4vY29uc2VudGVkL2R5bmFtaWMtYWQtc2xvdHMnO1xuaW1wb3J0IHsgaW5pdEZpbGxTbG90TGlzdGVuZXIgfSBmcm9tICcuL2NvbnNlbnRlZC9maWxsLXNsb3QtbGlzdGVuZXInO1xuaW1wb3J0IHsgaW5pdCBhcyBpbml0SXBzb3NNb3JpIH0gZnJvbSAnLi9jb25zZW50ZWQvaXBzb3MtbW9yaSc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRNZXNzZW5nZXIgfSBmcm9tICcuL2NvbnNlbnRlZC9tZXNzZW5nZXInO1xuaW1wb3J0IHsgaW5pdE9waW5hcnlQb2xsTGlzdGVuZXIgfSBmcm9tICcuL2NvbnNlbnRlZC9vcGluYXJ5JztcbmltcG9ydCB7IGluaXQgYXMgcHJlcGFyZUE5IH0gZnJvbSAnLi9jb25zZW50ZWQvcHJlcGFyZS1hOSc7XG5pbXBvcnQgeyBpbml0QWRtaXJhbEFkYmxvY2tSZWNvdmVyeSB9IGZyb20gJy4vY29uc2VudGVkL3ByZXBhcmUtYWRtaXJhbCc7XG5pbXBvcnQgeyBpbml0IGFzIHByZXBhcmVHb29nbGV0YWcgfSBmcm9tICcuL2NvbnNlbnRlZC9wcmVwYXJlLWdvb2dsZXRhZyc7XG5pbXBvcnQgeyBpbml0UGVybXV0aXZlIH0gZnJvbSAnLi9jb25zZW50ZWQvcHJlcGFyZS1wZXJtdXRpdmUnO1xuaW1wb3J0IHsgaW5pdCBhcyBwcmVwYXJlUHJlYmlkIH0gZnJvbSAnLi9jb25zZW50ZWQvcHJlcGFyZS1wcmViaWQnO1xuaW1wb3J0IHsgcmVtb3ZlRGlzYWJsZWRTbG90cyBhcyBjbG9zZURpc2FibGVkU2xvdHMgfSBmcm9tICcuL2NvbnNlbnRlZC9yZW1vdmUtc2xvdHMnO1xuaW1wb3J0IHsgaW5pdFRlYWRzQ29va2llbGVzcyB9IGZyb20gJy4vY29uc2VudGVkL3RlYWRzLWNvb2tpZWxlc3MnO1xuaW1wb3J0IHsgaW5pdCBhcyBpbml0VGhpcmRQYXJ0eVRhZ3MgfSBmcm9tICcuL2NvbnNlbnRlZC90aGlyZC1wYXJ0eS10YWdzJztcbmltcG9ydCB7IGluaXQgYXMgaW5pdFRyYWNrR3BjU2lnbmFsIH0gZnJvbSAnLi9jb25zZW50ZWQvdHJhY2stZ3BjLXNpZ25hbCc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRUcmFja1Njcm9sbERlcHRoIH0gZnJvbSAnLi9jb25zZW50ZWQvdHJhY2stc2Nyb2xsLWRlcHRoJztcbmltcG9ydCB7IHJlbG9hZFBhZ2VPbkNvbnNlbnRDaGFuZ2UgfSBmcm9tICcuL3NoYXJlZC9yZWxvYWQtcGFnZS1vbi1jb25zZW50LWNoYW5nZSc7XG5pbXBvcnQgeyBpbml0IGFzIHNldEFkVGVzdENvb2tpZSB9IGZyb20gJy4vc2hhcmVkL3NldC1hZHRlc3QtY29va2llJztcbmltcG9ydCB7IGluaXQgYXMgc2V0QWRUZXN0SW5MYWJlbHNDb29raWUgfSBmcm9tICcuL3NoYXJlZC9zZXQtYWR0ZXN0LWluLWxhYmVscy1jb29raWUnO1xuLy8gYWxsIG1vZHVsZXMgbmVlZGVkIGZvciBjb21tZXJjaWFsIGNvZGUgYW5kIGFkcyB0byBydW5cbmNvbnN0IGNvbW1lcmNpYWxNb2R1bGVzID0gW1xuICAgIGFkRnJlZVNsb3RSZW1vdmUsXG4gICAgY2xvc2VEaXNhYmxlZFNsb3RzLFxuICAgIGluaXRDb21zY29yZSxcbiAgICBpbml0SXBzb3NNb3JpLFxuICAgIGluaXRUZWFkc0Nvb2tpZWxlc3MsXG4gICAgaW5pdFRyYWNrU2Nyb2xsRGVwdGgsXG4gICAgaW5pdFRyYWNrR3BjU2lnbmFsLFxuICAgIGluaXRNZXNzZW5nZXIsXG4gICAgc2V0QWRUZXN0Q29va2llLFxuICAgIHNldEFkVGVzdEluTGFiZWxzQ29va2llLFxuICAgIHJlbG9hZFBhZ2VPbkNvbnNlbnRDaGFuZ2UsXG4gICAgcHJlcGFyZVByZWJpZCxcbiAgICBpbml0RGZwTGlzdGVuZXJzLFxuICAgIC8vIFBlcm11dGl2ZSBpbml0IGNvZGUgbXVzdCBydW4gYmVmb3JlIGdvb2dsZXRhZy5lbmFibGVTZXJ2aWNlcygpIGlzIGNhbGxlZFxuICAgICgpID0+IGluaXRQZXJtdXRpdmUoKS50aGVuKHByZXBhcmVHb29nbGV0YWcpLFxuICAgIGluaXREeW5hbWljQWRTbG90cyxcbiAgICBwcmVwYXJlQTksXG4gICAgaW5pdEZpbGxTbG90TGlzdGVuZXIsXG4gICAgcHJlcGFyZUFkVmVyaWZpY2F0aW9uLFxuICAgIGluaXRUaGlyZFBhcnR5VGFncyxcbiAgICBpbml0T3BpbmFyeVBvbGxMaXN0ZW5lcixcbiAgICBpbml0QWRtaXJhbEFkYmxvY2tSZWNvdmVyeSxcbl07XG5jb25zdCBib290Q29tbWVyY2lhbFdoZW5SZWFkeSA9ICgpID0+IHtcbiAgICBpZiAoISF3aW5kb3cuZ3VhcmRpYW4ubXVzdGFyZEN1dCB8fCAhIXdpbmRvdy5ndWFyZGlhbi5wb2x5ZmlsbGVkKSB7XG4gICAgICAgIHZvaWQgYm9vdENvbW1lcmNpYWwoY29tbWVyY2lhbE1vZHVsZXMpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgd2luZG93Lmd1YXJkaWFuLnF1ZXVlLnB1c2goKCkgPT4gYm9vdENvbW1lcmNpYWwoY29tbWVyY2lhbE1vZHVsZXMpKTtcbiAgICB9XG59O1xuZXhwb3J0IHsgYm9vdENvbW1lcmNpYWxXaGVuUmVhZHkgfTtcbiIsImltcG9ydCB7IGlzVXNlckluVmFyaWFudCB9IGZyb20gJy4uLy4uL2V4cGVyaW1lbnRzL2FiJztcbmltcG9ydCB7IGFkbWlyYWxBZGJsb2NrUmVjb3ZlcnkgfSBmcm9tICcuLi8uLi9leHBlcmltZW50cy90ZXN0cy9hZG1pcmFsLWFkYmxvY2tlci1yZWNvdmVyeSc7XG4vKipcbiAqIEZldGNoZXMgQUIgdGVzdCB2YXJpYW50IG5hbWUgZm9yIEFkbWlyYWwsIGFzIHRoZXJlIGFyZSB0d28gdmFyaWFudHNcbiAqL1xuY29uc3QgZ2V0QWRtaXJhbEFiVGVzdFZhcmlhbnQgPSAoKSA9PiB7XG4gICAgaWYgKGlzVXNlckluVmFyaWFudChhZG1pcmFsQWRibG9ja1JlY292ZXJ5LCAndmFyaWFudC1kZXRlY3QnKSkge1xuICAgICAgICByZXR1cm4gJ3ZhcmlhbnQtZGV0ZWN0JztcbiAgICB9XG4gICAgaWYgKGlzVXNlckluVmFyaWFudChhZG1pcmFsQWRibG9ja1JlY292ZXJ5LCAndmFyaWFudC1yZWNvdmVyJykpIHtcbiAgICAgICAgcmV0dXJuICd2YXJpYW50LXJlY292ZXInO1xuICAgIH1cbiAgICBpZiAoaXNVc2VySW5WYXJpYW50KGFkbWlyYWxBZGJsb2NrUmVjb3ZlcnksICdjb250cm9sJykpIHtcbiAgICAgICAgcmV0dXJuICdjb250cm9sJztcbiAgICB9XG4gICAgcmV0dXJuIHVuZGVmaW5lZDtcbn07XG4vKipcbiAqIFNlbmRzIGNvbXBvbmVudCBldmVudHMgdG8gT3BoYW4gd2l0aCB0aGUgY29tcG9uZW50VHlwZSBvZiBgQURfQkxPQ0tfUkVDT1ZFUllgXG4gKiBhcyB3ZWxsIGFzIHNlbmRpbmcgdGhlIEFCIHRlc3QgcGFydGljaXBhdGlvblxuICpcbiAqIEBwYXJhbSBvdmVycmlkZXMgYWxsb3dzIG92ZXJyaWRpbmcgLyBzZXR0aW5nIHZhbHVlcyBmb3IgYGFjdGlvbmAgYW5kIGB2YWx1ZWBcbiAqL1xuY29uc3QgcmVjb3JkQWRtaXJhbE9waGFuRXZlbnQgPSAoeyBhY3Rpb24sIHZhbHVlLCB9KSA9PiB7XG4gICAgY29uc3QgYWJUZXN0VmFyaWFudCA9IGdldEFkbWlyYWxBYlRlc3RWYXJpYW50KCk7XG4gICAgY29uc3QgY29tcG9uZW50RXZlbnQgPSB7XG4gICAgICAgIGNvbXBvbmVudDoge1xuICAgICAgICAgICAgY29tcG9uZW50VHlwZTogJ0FEX0JMT0NLX1JFQ09WRVJZJyxcbiAgICAgICAgICAgIGlkOiAnYWRtaXJhbC1hZGJsb2NrLXJlY292ZXJ5JyxcbiAgICAgICAgfSxcbiAgICAgICAgYWN0aW9uLFxuICAgICAgICAuLi4odmFsdWUgPyB7IHZhbHVlIH0gOiB7fSksXG4gICAgICAgIC4uLihhYlRlc3RWYXJpYW50XG4gICAgICAgICAgICA/IHtcbiAgICAgICAgICAgICAgICBhYlRlc3Q6IHtcbiAgICAgICAgICAgICAgICAgICAgbmFtZTogJ0FkbWlyYWxBZGJsb2NrUmVjb3ZlcnknLFxuICAgICAgICAgICAgICAgICAgICB2YXJpYW50OiBhYlRlc3RWYXJpYW50LFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICB9XG4gICAgICAgICAgICA6IHt9KSxcbiAgICB9O1xuICAgIHdpbmRvdy5ndWFyZGlhbi5vcGhhbj8ucmVjb3JkKHsgY29tcG9uZW50RXZlbnQgfSk7XG59O1xuLyoqXG4gKiBTZXRzIHRhcmdldGluZyBvbiB0aGUgQWRtaXJhbCBvYmplY3RcbiAqXG4gKiBAcGFyYW0ga2V5IHRhcmdldGluZyBrZXkgc2VudCB0byBBZG1pcmFsXG4gKiBAcGFyYW0gdmFsdWUgdGFyZ2V0aW5nIHZhbHVlIHNlbnQgdG8gQWRtaXJhbFxuICovXG5jb25zdCBzZXRBZG1pcmFsVGFyZ2V0aW5nID0gKGtleSwgdmFsdWUpID0+IHdpbmRvdy5hZG1pcmFsPy4oJ3RhcmdldGluZycsICdzZXQnLCBrZXksIHZhbHVlKTtcbmV4cG9ydCB7IGdldEFkbWlyYWxBYlRlc3RWYXJpYW50LCByZWNvcmRBZG1pcmFsT3BoYW5FdmVudCwgc2V0QWRtaXJhbFRhcmdldGluZywgfTtcbiIsImltcG9ydCB7IGZpbGxEeW5hbWljQWRTbG90IH0gZnJvbSAnLi4vLi4vaW5zZXJ0L2ZpbGwtZHluYW1pYy1hZHZlcnQtc2xvdCc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRTcGFjZWZpbmRlciB9IGZyb20gJy4uLy4uL2luc2VydC9zcGFjZWZpbmRlci9hcnRpY2xlJztcbi8qKlxuICogRmlsbCBhbiBhZCBzbG90IHdpdGggYSBnb29nbGV0YWcgYWR2ZXJ0XG4gKiBAcGFyYW0gbmFtZSBUaGUgbmFtZSBvZiB0aGUgYWQgc2xvdFxuICogQHBhcmFtIHNsb3QgVGhlIHNsb3QgZWxlbWVudFxuICogQHBhcmFtIGFkZGl0aW9uYWxTaXplcyBBZGRpdGlvbmFsIHNpemVzIHRvIGJlIGFkZGVkIHRvIHRoZSBzbG90XG4gKi9cbmNvbnN0IGZpbGxBZFNsb3QgPSBhc3luYyAobmFtZSwgc2xvdCwgYWRkaXRpb25hbFNpemVzKSA9PiB7XG4gICAgY29uc3Qgc2hvdWxkRm9yY2VEaXNwbGF5ID0gWydjYXJyb3QnXS5pbmNsdWRlcyhuYW1lKTtcbiAgICBhd2FpdCBmaWxsRHluYW1pY0FkU2xvdChzbG90LCBzaG91bGRGb3JjZURpc3BsYXksIGFkZGl0aW9uYWxTaXplcyk7XG59O1xuLyoqXG4gKiBJbml0aWFsaXNlIGFydGljbGUgYm9keSBhZCBzbG90c1xuICovXG5jb25zdCBpbml0QXJ0aWNsZUJvZHlBZHZlcnRzID0gKCkgPT4ge1xuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2FydGljbGU6c2lnbi1pbi1nYXRlLWRpc21pc3NlZCcsICgpID0+IHtcbiAgICAgICAgdm9pZCBpbml0U3BhY2VmaW5kZXIoZmlsbEFkU2xvdCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIGluaXRTcGFjZWZpbmRlcihmaWxsQWRTbG90KTtcbn07XG5leHBvcnQgeyBpbml0QXJ0aWNsZUJvZHlBZHZlcnRzIH07XG4iLCJpbXBvcnQgeyBvblNsb3RMb2FkIH0gZnJvbSAnLi4vLi4vZXZlbnRzL29uLXNsb3QtbG9hZCc7XG5pbXBvcnQgeyBvblNsb3RSZW5kZXIgfSBmcm9tICcuLi8uLi9ldmVudHMvb24tc2xvdC1yZW5kZXInO1xuaW1wb3J0IHsgb25TbG90Vmlld2FibGVGdW5jdGlvbiB9IGZyb20gJy4uLy4uL2V2ZW50cy9vbi1zbG90LXZpZXdhYmxlJztcbmltcG9ydCB7IHdyYXBXaXRoRXJyb3JSZXBvcnRpbmcgfSBmcm9tICcuLi8uLi9saWIvZXJyb3IvcmVwb3J0LWVycm9yJztcbmNvbnN0IGluaXREZnBMaXN0ZW5lcnMgPSAoKSA9PiB7XG4gICAgd2luZG93Lmdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICAgIGNvbnN0IHB1YmFkcyA9IHdpbmRvdy5nb29nbGV0YWcucHViYWRzKCk7XG4gICAgICAgIHB1YmFkcy5hZGRFdmVudExpc3RlbmVyKCdzbG90UmVuZGVyRW5kZWQnLCB3cmFwV2l0aEVycm9yUmVwb3J0aW5nKG9uU2xvdFJlbmRlcikpO1xuICAgICAgICBwdWJhZHMuYWRkRXZlbnRMaXN0ZW5lcignc2xvdE9ubG9hZCcsIHdyYXBXaXRoRXJyb3JSZXBvcnRpbmcob25TbG90TG9hZCkpO1xuICAgICAgICBwdWJhZHMuYWRkRXZlbnRMaXN0ZW5lcignaW1wcmVzc2lvblZpZXdhYmxlJywgb25TbG90Vmlld2FibGVGdW5jdGlvbigpKTtcbiAgICB9KTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuZXhwb3J0IHsgaW5pdERmcExpc3RlbmVycyB9O1xuIiwiaW1wb3J0IHsgaW5pdENvbW1lbnRzRXhwYW5kZWRBZHZlcnRzIH0gZnJvbSAnLi4vLi4vaW5zZXJ0L2NvbW1lbnRzLWV4cGFuZGVkLWFkdmVydCc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRGb290YmFsbFJpZ2h0QWRzIH0gZnJvbSAnLi4vLi4vaW5zZXJ0L2ZpeHVyZXMnO1xuaW1wb3J0IHsgaW5pdCBhcyBpbml0SGlnaE1lcmNoIH0gZnJvbSAnLi4vLi4vaW5zZXJ0L2hpZ2gtbWVyY2gnO1xuaW1wb3J0IHsgaW5pdCBhcyBpbml0TW9iaWxlU3RpY2t5IH0gZnJvbSAnLi4vLi4vaW5zZXJ0L21vYmlsZS1zdGlja3knO1xuaW1wb3J0IHsgaW5pdCBhcyBpbml0TGl2ZWJsb2dBZHZlcnRzIH0gZnJvbSAnLi4vLi4vaW5zZXJ0L3NwYWNlZmluZGVyL2xpdmVibG9nLWFkdmVydHMnO1xuaW1wb3J0IHsgcmVwb3J0RXJyb3IgfSBmcm9tICcuLi8uLi9saWIvZXJyb3IvcmVwb3J0LWVycm9yJztcbmltcG9ydCB7IGluaXRBcnRpY2xlQm9keUFkdmVydHMgfSBmcm9tICcuL2FydGljbGUtYm9keS1hZHZlcnRzJztcbmNvbnN0IGR5bmFtaWNBZFNsb3RNb2R1bGVzID0gW1xuICAgIFsnY20tbW9iaWxlU3RpY2t5JywgaW5pdE1vYmlsZVN0aWNreV0sXG4gICAgWydjbS1oaWdoTWVyY2gnLCBpbml0SGlnaE1lcmNoXSxcbiAgICBbJ2NtLWFydGljbGVCb2R5QWR2ZXJ0cycsIGluaXRBcnRpY2xlQm9keUFkdmVydHNdLFxuICAgIFsnY20tbGl2ZWJsb2dBZHZlcnRzJywgaW5pdExpdmVibG9nQWR2ZXJ0c10sXG4gICAgWydjbS1jb21tZW50c0V4cGFuZGVkQWR2ZXJ0cycsIGluaXRDb21tZW50c0V4cGFuZGVkQWR2ZXJ0c10sXG4gICAgWydjbS1mb290YmFsbFJpZ2h0JywgaW5pdEZvb3RiYWxsUmlnaHRBZHNdLFxuXTtcbmV4cG9ydCBjb25zdCBpbml0RHluYW1pY0FkU2xvdHMgPSBhc3luYyAoKSA9PiB7XG4gICAgcmV0dXJuIFByb21pc2UuYWxsKGR5bmFtaWNBZFNsb3RNb2R1bGVzLm1hcChhc3luYyAoW25hbWUsIGluaXRdKSA9PiB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBhd2FpdCBpbml0KCk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgICAgICByZXBvcnRFcnJvcihlcnJvciwgJ2NvbW1lcmNpYWwnLCB7IHRhZzogbmFtZSB9KTtcbiAgICAgICAgfVxuICAgIH0pKTtcbn07XG4iLCJpbXBvcnQgeyBmaWxsRHluYW1pY0FkU2xvdCB9IGZyb20gJy4uLy4uL2luc2VydC9maWxsLWR5bmFtaWMtYWR2ZXJ0LXNsb3QnO1xuaW1wb3J0IHsgZGZwRW52IH0gZnJvbSAnLi4vLi4vbGliL2RmcC9kZnAtZW52JztcbmNvbnN0IGlzQ3VzdG9tRXZlbnQgPSAoZXZlbnQpID0+IHtcbiAgICByZXR1cm4gJ2RldGFpbCcgaW4gZXZlbnQ7XG59O1xuLyoqXG4gKiBMaXN0ZW4gZm9yIGV2ZW50cyB0byBmaWxsIGFuIGFkZGl0aW9uYWwgc2xvdFxuICpcbiAqIFRoaXMgaXMgZm9yIHNsb3RzIHRoYXQgYXJlIG5vdCBmaXhlZCAoYWthIFNTUikgb3IgZHluYW1pYyAoYWthIGluamVjdGVkIGZyb21cbiAqIHRoaXMgYnVuZGxlLCBlLmcuIHZpYSBzcGFjZWZpbmRlcikuIFRoZXkgYXJlIHBsYWNlZCBvbiB0aGUgcGFnZSBieSBhXG4gKiBub24tc3RhbmRhcmQgcm91dGUsIGZvciBleGFtcGxlIGluIGEgdGhyYXNoZXIgb3Igc29tZSBvdGhlciBhc3luYyBwcm9jZXNzXG4gKiB0aGF0IGFkZHMgdGhlIHNsb3QgYXQgYW4gdW5rbm93biB0aW1lIGJ1dCBzdGlsbCBleHBlY3RzIHRoZSBjb21tZXJjaWFsXG4gKiBydW50aW1lIHRvIGZ1bGZpbGwgdGhlIHNsb3QuXG4gKlxuICogVGhlIGV4dHJhIGxvZ2ljIGluIGFkZGl0aW9uIHRvIGR5bmFtaWMgc2xvdHMgY292ZXJzIHdoZW46XG4gKiAtIHRoZSBjb21tZXJjaWFsIHJ1bnRpbWUgbG9hZHMgYmVmb3JlIHRoZSBzbG90IHNvIHdlIHdhaXQgZm9yIGEgY3VzdG9tIGV2ZW50XG4gKiAtIHRoZSBjb21tZXJjaWFsIHJ1bnRpbWUgbG9hZHMgYWZ0ZXIgdGhlIHNsb3Qgc28gd2UgZmlsbCB0aGUgc2xvdCBpbW1lZGlhdGVseVxuICpcbiAqIFRoZXNlIGV2ZW50cyB3aWxsIG5vdCBiZSByZWNlaXZlZCBmcm9tIGEgcmVzdHJpY3RlZCBpZnJhbWUgc3VjaCwgc3VjaCBhcyBhXG4gKiBjcm9zcy1vcmlnaW4gb3Igc2FmZWZyYW1lIGlmcmFtZS5cbiAqL1xuY29uc3QgY3JlYXRlU2xvdEZpbGxMaXN0ZW5lciA9ICgpID0+IHtcbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdndS5jb21tZXJjaWFsLnNsb3QuZmlsbCcsIChldmVudCkgPT4ge1xuICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLmNtZC5wdXNoKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChpc0N1c3RvbUV2ZW50KGV2ZW50KSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgc2xvdElkLCBhZGRpdGlvbmFsU2l6ZXMgfSA9IChldmVudCkuZGV0YWlsO1xuICAgICAgICAgICAgICAgIGlmIChkZnBFbnYuYWR2ZXJ0cy5oYXMoc2xvdElkKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGNvbnN0IHNsb3QgPSBkb2N1bWVudC5nZXRFbGVtZW50QnlJZChzbG90SWQpO1xuICAgICAgICAgICAgICAgIGlmIChzbG90KSB7XG4gICAgICAgICAgICAgICAgICAgIHZvaWQgZmlsbER5bmFtaWNBZFNsb3Qoc2xvdCwgZmFsc2UsIGFkZGl0aW9uYWxTaXplcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9KTtcbn07XG5jb25zdCBpbml0RmlsbFNsb3RMaXN0ZW5lciA9ICgpID0+IFByb21pc2UucmVzb2x2ZShjcmVhdGVTbG90RmlsbExpc3RlbmVyKCkpO1xuZXhwb3J0IHsgaW5pdEZpbGxTbG90TGlzdGVuZXIgfTtcbiIsImltcG9ydCB7IGluaXQgYXMgaW5pdE1lc3NlbmdlciB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXInO1xuaW1wb3J0IHsgaW5pdCBhcyBiYWNrZ3JvdW5kIH0gZnJvbSAnLi4vLi4vbGliL21lc3Nlbmdlci9iYWNrZ3JvdW5kJztcbmltcG9ydCB7IGluaXQgYXMgZGlzYWJsZVJlZnJlc2ggfSBmcm9tICcuLi8uLi9saWIvbWVzc2VuZ2VyL2Rpc2FibGUtcmVmcmVzaCc7XG5pbXBvcnQgeyBpbml0IGFzIGZ1bGx3aWR0aCB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvZnVsbC13aWR0aCc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRHZXRQYWdlVGFyZ2V0aW5nIH0gZnJvbSAnLi4vLi4vbGliL21lc3Nlbmdlci9nZXQtcGFnZS10YXJnZXRpbmcnO1xuaW1wb3J0IHsgaW5pdCBhcyBpbml0R2V0UGFnZVVybCB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvZ2V0LXBhZ2UtdXJsJztcbmltcG9ydCB7IGluaXQgYXMgZ2V0U3R5bGVzIH0gZnJvbSAnLi4vLi4vbGliL21lc3Nlbmdlci9nZXQtc3R5bGVzaGVldCc7XG5pbXBvcnQgeyBpbml0IGFzIGluaXRNZWFzdXJlQWRMb2FkIH0gZnJvbSAnLi4vLi4vbGliL21lc3Nlbmdlci9tZWFzdXJlLWFkLWxvYWQnO1xuaW1wb3J0IHsgaW5pdCBhcyBwYXNzYmFjayB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvcGFzc2JhY2snO1xuaW1wb3J0IHsgaW5pdCBhcyBwYXNzYmFja1JlZnJlc2ggfSBmcm9tICcuLi8uLi9saWIvbWVzc2VuZ2VyL3Bhc3NiYWNrLXJlZnJlc2gnO1xuaW1wb3J0IHsgaW5pdCBhcyByZXNpemUgfSBmcm9tICcuLi8uLi9saWIvbWVzc2VuZ2VyL3Jlc2l6ZSc7XG5pbXBvcnQgeyBpbml0IGFzIHNjcm9sbCB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvc2Nyb2xsJztcbmltcG9ydCB7IGluaXQgYXMgdHlwZSB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvdHlwZSc7XG5pbXBvcnQgeyBpbml0TWVzc2VuZ2VyVmlkZW9Qcm9ncmVzc1JlcG9ydGluZyB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvdmlkZW8nO1xuaW1wb3J0IHsgaW5pdCBhcyB2aWV3cG9ydCB9IGZyb20gJy4uLy4uL2xpYi9tZXNzZW5nZXIvdmlld3BvcnQnO1xuLyoqXG4gKiBNZXNzZW5nZXIgZ2V0cyB0byBza2lwIHRoZSBwcm9taXNlIGNoYWluIGFuZCBydW4gaW1tZWRpYXRlbHkuXG4gKi9cbmluaXRNZXNzZW5nZXIoW1xuICAgIHR5cGUsXG4gICAgZ2V0U3R5bGVzLFxuICAgIGluaXRHZXRQYWdlVGFyZ2V0aW5nLFxuICAgIGluaXRHZXRQYWdlVXJsLFxuICAgIGluaXRNZWFzdXJlQWRMb2FkLFxuICAgIHBhc3NiYWNrUmVmcmVzaCxcbiAgICByZXNpemUsXG4gICAgZnVsbHdpZHRoLFxuICAgIGJhY2tncm91bmQsXG4gICAgZGlzYWJsZVJlZnJlc2gsXG4gICAgcGFzc2JhY2ssXG4gICAgaW5pdE1lc3NlbmdlclZpZGVvUHJvZ3Jlc3NSZXBvcnRpbmcsXG5dLCBbc2Nyb2xsLCB2aWV3cG9ydF0pO1xuY29uc3QgaW5pdCA9ICgpID0+IFByb21pc2UucmVzb2x2ZSgpO1xuZXhwb3J0IHsgaW5pdCB9O1xuIiwiaW1wb3J0IHsgaXNVbmRlZmluZWQsIGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmNvbnN0IGlzT3BpbmFyeUV2ZW50ID0gKGUpID0+IHtcbiAgICBpZiAodHlwZW9mIGUuZGF0YSAhPT0gJ29iamVjdCcgfHxcbiAgICAgICAgZS5kYXRhID09PSBudWxsIHx8XG4gICAgICAgICEoJ3R5cGUnIGluIGUuZGF0YSkgfHxcbiAgICAgICAgISgncG9sbCcgaW4gZS5kYXRhKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIC8vIFR5cGUgYXNzZXJ0aW9uIHRvIGxldCBUeXBlU2NyaXB0IGtub3cgdGhlIHN0cnVjdHVyZVxuICAgIGNvbnN0IGRhdGEgPSBlLmRhdGE7XG4gICAgcmV0dXJuIGRhdGEudHlwZSA9PT0gJ29waW5hcnkudm90ZScgJiYgZGF0YS5wb2xsLmRtcEludGVncmF0aW9uO1xufTtcbmNvbnN0IG9waW5hcnlQb2xsTGlzdGVuZXIgPSAoZXZlbnQpID0+IHtcbiAgICBpZiAoaXNVbmRlZmluZWQod2luZG93LnBlcm11dGl2ZSkgfHxcbiAgICAgICAgaXNVbmRlZmluZWQod2luZG93LnBlcm11dGl2ZS50cmFjaykgfHxcbiAgICAgICAgIWlzT3BpbmFyeUV2ZW50KGV2ZW50KSkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGNvbnN0IHsgcG9sbCwgdm90ZSB9ID0gZXZlbnQuZGF0YTtcbiAgICAvKipcbiAgICAgKiBJTVBPUlRBTlQ6IERvIG5vdCBjaGFuZ2UgdGhlIHNoYXBlIG9mIHRoaXMgZGF0YSBiZWZvcmUgY2hlY2tpbmcgd2l0aCBQZXJtdXRpdmUhXG4gICAgICogVGhpcyBpcyBhIFBlcm11dGl2ZSBjdXN0b20gZXZlbnQgYW5kIGlzIGRvY3VtZW50ZWQgYW5kIHNwZWNpZmllZCBtYW51YWxseSBpbiBhIHNjaGVtYVxuICAgICAqIEBzZWUgaHR0cHM6Ly9zdXBwb3J0LnBlcm11dGl2ZS5jb20vaGMvZW4tdXMvYXJ0aWNsZXMvMTAyMTEzMzUyNTM2NjAtU2NoZW1hLVVwZGF0ZXMtZm9yLXRoZS1QYWdldmlldy1FdmVudC1DdXN0b20tRXZlbnRzXG4gICAgICogZm9yIG1vcmUgaW5mb3JtYXRpb25cbiAgICAgKi9cbiAgICBjb25zdCBzdXJ2ZXlSZXNwb25zZSA9IHtcbiAgICAgICAgc3VydmV5OiB7XG4gICAgICAgICAgICBpZDogcG9sbC5wb2xsSWQsXG4gICAgICAgICAgICB0eXBlOiBwb2xsLnR5cGUsXG4gICAgICAgICAgICBzb2x1dGlvbjogJ09waW5hcnknLFxuICAgICAgICB9LFxuICAgICAgICBxdWVzdGlvbjoge1xuICAgICAgICAgICAgdGV4dDogcG9sbC5oZWFkZXIsXG4gICAgICAgIH0sXG4gICAgICAgIGFuc3dlcjoge1xuICAgICAgICAgICAgdGV4dDogdm90ZS5sYWJlbCxcbiAgICAgICAgICAgIHBvc1g6IHZvdGUueCB8fCAwLjAsXG4gICAgICAgICAgICBwb3NZOiB2b3RlLnkgfHwgMC4wLFxuICAgICAgICAgICAgb3B0aW9uSWRlbnRpZmllcjogdm90ZS5vcHRpb25JRCB8fCAnJyxcbiAgICAgICAgICAgIG9wdGlvblBvc2l0aW9uOiB2b3RlLnBvc2l0aW9uIHx8IDAsXG4gICAgICAgICAgICByYXdWYWx1ZTogdm90ZS52YWx1ZSB8fCAwLjAsXG4gICAgICAgICAgICB1bml0OiB2b3RlLnVuaXQgfHwgJycsXG4gICAgICAgIH0sXG4gICAgfTtcbiAgICB3aW5kb3cucGVybXV0aXZlLnRyYWNrKCdTdXJ2ZXlSZXNwb25zZScsIHN1cnZleVJlc3BvbnNlKTtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCBgU2VudCBzdXJ2ZXkgcmVzcG9uc2UgdG8gUGVybXV0aXZlIGZvciBwb2xsIElEICR7cG9sbC5wb2xsSWR9YCk7XG4gICAgbG9nKCdjb21tZXJjaWFsJywgc3VydmV5UmVzcG9uc2UpO1xufTtcbmNvbnN0IGluaXRPcGluYXJ5UG9sbExpc3RlbmVyID0gKCkgPT4gUHJvbWlzZS5yZXNvbHZlKHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgb3BpbmFyeVBvbGxMaXN0ZW5lcikpO1xuLy8gRXhwb3J0cyBmb3IgdGVzdGluZyBvbmx5XG5leHBvcnQgY29uc3QgXyA9IHtcbiAgICBpc09waW5hcnlFdmVudCxcbn07XG5leHBvcnQgeyBpbml0T3BpbmFyeVBvbGxMaXN0ZW5lciB9O1xuIiwiaW1wb3J0IHsgaXNJbkNhbmFkYSB9IGZyb20gJ0BndWFyZGlhbi9jb21tZXJjaWFsLWNvcmUvZ2VvL2dlby11dGlscyc7XG5pbXBvcnQgeyBnZXRDb25zZW50Rm9yLCBsb2csIG9uQ29uc2VudCB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IG9uY2UgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgYTlBcHN0YWcgfSBmcm9tICcuLi8uLi9saWIvX192ZW5kb3IvYTktYXBzdGFnJztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uLy4uL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCB7IGlzR29vZ2xlUHJveHkgfSBmcm9tICcuLi8uLi9saWIvZGV0ZWN0L2RldGVjdC1nb29nbGUtcHJveHknO1xuaW1wb3J0IHsgYTkgfSBmcm9tICcuLi8uLi9saWIvaGVhZGVyLWJpZGRpbmcvYTkvYTknO1xuaW1wb3J0IHsgc2hvdWxkSW5jbHVkZU9ubHlBOSB9IGZyb20gJy4uLy4uL2xpYi9oZWFkZXItYmlkZGluZy91dGlscyc7XG5jb25zdCBzaG91bGRMb2FkQTkgPSAoKSA9PiBcbi8vIFRoZXJlIGFyZSB0d28gYXJ0aWNsZXMgdGhhdCBJbmZvU2VjIHdvdWxkIGxpa2UgdG8gYXZvaWQgbG9hZGluZyBzY3JpcHRzIG9uXG4oIWNvbW1lcmNpYWxGZWF0dXJlcy5pc1NlY3VyZUNvbnRhY3QgJiZcbiAgICAhaXNHb29nbGVQcm94eSgpICYmXG4gICAgd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlcy5hOUhlYWRlckJpZGRpbmcgJiZcbiAgICBjb21tZXJjaWFsRmVhdHVyZXMuc2hvdWxkTG9hZEdvb2dsZXRhZyAmJlxuICAgICFjb21tZXJjaWFsRmVhdHVyZXMuYWRGcmVlICYmXG4gICAgIXdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5oYXNQYWdlU2tpbiAmJlxuICAgICFpc0luQ2FuYWRhKCkpID8/XG4gICAgZmFsc2U7XG5jb25zdCBzZXR1cEE5ID0gKCkgPT4ge1xuICAgIGlmIChzaG91bGRMb2FkQTkoKSB8fCBzaG91bGRJbmNsdWRlT25seUE5KSB7XG4gICAgICAgIC8vIExvYWQgYTkgdGhpcmQgcGFydHkgc3R1YlxuICAgICAgICBhOUFwc3RhZygpO1xuICAgICAgICBhOS5pbml0aWFsaXNlKCk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbn07XG5jb25zdCBzZXR1cEE5T25jZSA9IG9uY2Uoc2V0dXBBOSk7XG4vKipcbiAqIEluaXRpYWxpc2UgQTksIEFtYXpvbiBoZWFkZXIgYmlkZGluZyBsaWJyYXJ5XG4gKiBodHRwczovL2Ftcy5hbWF6b24uY29tL3dlYnB1Ymxpc2hlci91YW0vZG9jcy93ZWItaW50ZWdyYXRpb24tZG9jdW1lbnRhdGlvbi9pbnRlZ3JhdGlvbi1ndWlkZS9qYXZhc2NyaXB0LWd1aWRlL2Rpc3BsYXkuaHRtbFxuICovXG5leHBvcnQgY29uc3QgaW5pdCA9ICgpID0+IG9uQ29uc2VudCgpXG4gICAgLnRoZW4oKGNvbnNlbnRTdGF0ZSkgPT4ge1xuICAgIGlmIChnZXRDb25zZW50Rm9yKCdhOScsIGNvbnNlbnRTdGF0ZSkpIHtcbiAgICAgICAgcmV0dXJuIHNldHVwQTlPbmNlKCk7XG4gICAgfVxuICAgIHRocm93IEVycm9yKCdObyBjb25zZW50IGZvciBhOScpO1xufSlcbiAgICAuY2F0Y2goKGUpID0+IHtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCAn4pqg77iPIEZhaWxlZCB0byBleGVjdXRlIGE5JywgZSk7XG59KTtcbmV4cG9ydCBjb25zdCBfID0ge1xuICAgIHNldHVwQTksXG59O1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgcmVjb3JkQWRtaXJhbE9waGFuRXZlbnQgfSBmcm9tICcuL2FkbWlyYWwnO1xuY29uc3QgaGFuZGxlTWVhc3VyZURldGVjdGVkRXZlbnQgPSAoZXZlbnQpID0+IHtcbiAgICBjb25zdCBpc01lYXN1cmVEZXRlY3RlZEV2ZW50ID0gKGUpID0+IHR5cGVvZiBlID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAnYWRibG9ja2luZycgaW4gZSAmJlxuICAgICAgICAnd2hpdGVsaXN0ZWQnIGluIGUgJiZcbiAgICAgICAgJ3N1YnNjcmliZWQnIGluIGU7XG4gICAgaWYgKGlzTWVhc3VyZURldGVjdGVkRXZlbnQoZXZlbnQpKSB7XG4gICAgICAgIGlmIChldmVudC5hZGJsb2NraW5nKSB7XG4gICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAn8J+boe+4jyBBZG1pcmFsIC0gdXNlciBoYXMgYW4gYWRibG9ja2VyIGFuZCBpdCBpcyBlbmFibGVkJyk7XG4gICAgICAgICAgICByZWNvcmRBZG1pcmFsT3BoYW5FdmVudCh7IGFjdGlvbjogJ0RFVEVDVCcsIHZhbHVlOiAnYmxvY2tlZCcgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2ZW50LndoaXRlbGlzdGVkKSB7XG4gICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAn8J+boe+4jyBBZG1pcmFsIC0gdXNlciBoYXMgc2VlbiBFbmdhZ2UgYW5kIHN1YnNlcXVlbnRseSBkaXNhYmxlZCB0aGVpciBhZGJsb2NrZXInKTtcbiAgICAgICAgICAgIHJlY29yZEFkbWlyYWxPcGhhbkV2ZW50KHsgYWN0aW9uOiAnREVURUNUJywgdmFsdWU6ICd3aGl0ZWxpc3RlZCcgfSk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGV2ZW50LnN1YnNjcmliZWQpIHtcbiAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsICfwn5uh77iPIEFkbWlyYWwgLSB1c2VyIGhhcyBhbiBhY3RpdmUgc3Vic2NyaXB0aW9uIHRvIGEgdHJhbnNhY3QgcGxhbicpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBg8J+boe+4jyBBZG1pcmFsIC0gRXZlbnQgaXMgbm90IG9mIGV4cGVjdGVkIGZvcm1hdCBvZiBtZWFzdXJlLmRldGVjdGVkICR7SlNPTi5zdHJpbmdpZnkoZXZlbnQpfWApO1xuICAgIH1cbn07XG5jb25zdCBoYW5kbGVDYW5kaWRhdGVTaG93bkV2ZW50ID0gKGV2ZW50KSA9PiB7XG4gICAgY29uc3QgaXNDYW5kaWRhdGVTaG93bkV2ZW50ID0gKGUpID0+IHR5cGVvZiBlID09PSAnb2JqZWN0JyAmJlxuICAgICAgICAnY2FuZGlkYXRlSUQnIGluIGUgJiZcbiAgICAgICAgJ3ZhcmlhbnRJRCcgaW4gZSAmJlxuICAgICAgICAnY2FuZGlkYXRlR3JvdXBzJyBpbiBlO1xuICAgIGlmIChpc0NhbmRpZGF0ZVNob3duRXZlbnQoZXZlbnQpKSB7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGDwn5uh77iPIEFkbWlyYWwgLSBMYXVuY2hpbmcgY2FuZGlkYXRlICR7ZXZlbnQuY2FuZGlkYXRlSUR9YCk7XG4gICAgICAgIHJlY29yZEFkbWlyYWxPcGhhbkV2ZW50KHsgYWN0aW9uOiAnVklFVycsIHZhbHVlOiBldmVudC5jYW5kaWRhdGVJRCB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGDwn5uh77iPIEFkbWlyYWwgLSBFdmVudCBpcyBub3Qgb2YgZXhwZWN0ZWQgZm9ybWF0IG9mIGNhbmRpZGF0ZS5zaG93biAke0pTT04uc3RyaW5naWZ5KGV2ZW50KX1gKTtcbiAgICB9XG59O1xuY29uc3QgaGFuZGxlQ2FuZGlkYXRlRGlzbWlzc2VkRXZlbnQgPSAoZXZlbnQpID0+IHtcbiAgICBjb25zdCBpc0NhbmRpZGF0ZURpc21pc3NlZEV2ZW50ID0gKGUpID0+IHR5cGVvZiBlID09PSAnb2JqZWN0JyAmJiAnY2FuZGlkYXRlSUQnIGluIGUgJiYgJ2NhbmRpZGF0ZUdyb3VwcycgaW4gZTtcbiAgICBpZiAoaXNDYW5kaWRhdGVEaXNtaXNzZWRFdmVudChldmVudCkpIHtcbiAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYPCfm6HvuI8gQWRtaXJhbCAtIENhbmRpZGF0ZSAke2V2ZW50LmNhbmRpZGF0ZUlEfSB3YXMgZGlzbWlzc2VkYCk7XG4gICAgICAgIHJlY29yZEFkbWlyYWxPcGhhbkV2ZW50KHsgYWN0aW9uOiAnQ0xPU0UnLCB2YWx1ZTogZXZlbnQuY2FuZGlkYXRlSUQgfSk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBg8J+boe+4jyBBZG1pcmFsIC0gRXZlbnQgaXMgbm90IG9mIGV4cGVjdGVkIGZvcm1hdCBvZiBjYW5kaWRhdGUuZGlzbWlzc2VkICR7SlNPTi5zdHJpbmdpZnkoZXZlbnQpfWApO1xuICAgIH1cbn07XG5jb25zdCBzZXRVcEFkbWlyYWxFdmVudExvZ2dlciA9IChhZG1pcmFsKSA9PiB7XG4gICAgYWRtaXJhbCgnYWZ0ZXInLCAnbWVhc3VyZS5kZXRlY3RlZCcsIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICBoYW5kbGVNZWFzdXJlRGV0ZWN0ZWRFdmVudChldmVudCk7XG4gICAgfSk7XG4gICAgYWRtaXJhbCgnYWZ0ZXInLCAnY2FuZGlkYXRlLnNob3duJywgZnVuY3Rpb24gKGV2ZW50KSB7XG4gICAgICAgIGhhbmRsZUNhbmRpZGF0ZVNob3duRXZlbnQoZXZlbnQpO1xuICAgIH0pO1xuICAgIGFkbWlyYWwoJ2FmdGVyJywgJ2NhbmRpZGF0ZS5kaXNtaXNzZWQnLCBmdW5jdGlvbiAoZXZlbnQpIHtcbiAgICAgICAgaGFuZGxlQ2FuZGlkYXRlRGlzbWlzc2VkRXZlbnQoZXZlbnQpO1xuICAgIH0pO1xufTtcbi8qKlxuICogQWRtaXJhbCBBZGJsb2NrIFJlY292ZXJ5IEluaXRcbiAqXG4gKiBUaGUgc2NyaXB0IGlzIGxvYWRlZCBjb25kaXRpb25hbGx5IGFzIGEgdGhpcmQtcGFydHktdGFnXG4gKiBAc2VlIC9idW5kbGUvc3JjL2luaXQvY29uc2VudGVkL3RoaXJkLXBhcnR5LXRhZ3MudHNcbiAqXG4gKiBUaGlzIGZ1bmN0aW9uIGVuc3VyZXMgYWRtaXJhbCBpcyBhdmFpbGFibGUgb24gdGhlIHdpbmRvdyBvYmplY3RcbiAqIGFuZCBzZXRzIHVwIEFkbWlyYWwgZXZlbnQgbG9nZ2luZ1xuICovXG5jb25zdCBpbml0QWRtaXJhbEFkYmxvY2tSZWNvdmVyeSA9ICgpID0+IHtcbiAgICAvLyBTZXQgdXAgd2luZG93LmFkbWlyYWxcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSAtLSBUaGlzIGlzIGEgc3R1YiBwcm92aWRlZCBieSBBZG1pcmFsICovXG4gICAgd2luZG93LmFkbWlyYWwgPVxuICAgICAgICB3aW5kb3cuYWRtaXJhbCB8fFxuICAgICAgICAgICAgZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3JcbiAgICAgICAgICAgICAgICAoYWRtaXJhbC5xID0gYWRtaXJhbC5xIHx8IFtdKS5wdXNoKGFyZ3VtZW50cyk7XG4gICAgICAgICAgICB9O1xuICAgIC8qIGVzbGludC1lbmFibGUgKi9cbiAgICB2b2lkIHNldFVwQWRtaXJhbEV2ZW50TG9nZ2VyKHdpbmRvdy5hZG1pcmFsKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuZXhwb3J0IHsgaW5pdEFkbWlyYWxBZGJsb2NrUmVjb3ZlcnkgfTtcbiIsImltcG9ydCB7IEV2ZW50VGltZXIgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2V2ZW50LXRpbWVyJztcbmltcG9ydCB7IGdldENvbnNlbnRGb3IsIGxvYWRTY3JpcHQsIGxvZywgb25Db25zZW50IH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgY29tbWVyY2lhbEZlYXR1cmVzIH0gZnJvbSAnLi4vLi4vbGliL2NvbW1lcmNpYWwtZmVhdHVyZXMnO1xuaW1wb3J0IHsgZ2V0R29vZ2xlVGFnSWQsIGlzVXNlckxvZ2dlZEluIH0gZnJvbSAnLi4vLi4vbGliL2lkZW50aXR5L2FwaSc7XG5pbXBvcnQgeyBnZXRQYWdlVGFyZ2V0aW5nIH0gZnJvbSAnLi4vLi4vbGliL3BhZ2UtdGFyZ2V0aW5nJztcbmltcG9ydCB7IGNoZWNrVGhpcmRQYXJ0eUNvb2tpZXNFbmFibGVkIH0gZnJvbSAnLi4vLi4vbGliL3RoaXJkLXBhcnR5LWNvb2tpZXMnO1xuaW1wb3J0IHsgcmVtb3ZlU2xvdHMgfSBmcm9tICcuL3JlbW92ZS1zbG90cyc7XG5pbXBvcnQgeyBmaWxsU3RhdGljQWR2ZXJ0U2xvdHMgfSBmcm9tICcuL3N0YXRpYy1hZC1zbG90cyc7XG5jb25zdCBzZXRQYWdlVGFyZ2V0aW5nID0gKGNvbnNlbnRTdGF0ZSwgaXNTaWduZWRJbikgPT4gT2JqZWN0LmVudHJpZXMoZ2V0UGFnZVRhcmdldGluZyhjb25zZW50U3RhdGUsIGlzU2lnbmVkSW4pKS5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICBpZiAoIXZhbHVlKVxuICAgICAgICByZXR1cm47XG4gICAgd2luZG93Lmdvb2dsZXRhZy5wdWJhZHMoKS5zZXRUYXJnZXRpbmcoa2V5LCB2YWx1ZSk7XG59KTtcbi8qKlxuICogQWxzbyBrbm93biBhcyBQUElEXG4gKi9cbmNvbnN0IHNldFB1Ymxpc2hlclByb3ZpZGVkSWQgPSAoKSA9PiB7XG4gICAgdm9pZCBnZXRHb29nbGVUYWdJZCgpLnRoZW4oKGdvb2dsZVRhZ0lkKSA9PiB7XG4gICAgICAgIGlmIChnb29nbGVUYWdJZCAhPT0gbnVsbCkge1xuICAgICAgICAgICAgd2luZG93Lmdvb2dsZXRhZy5wdWJhZHMoKS5zZXRQdWJsaXNoZXJQcm92aWRlZElkKGdvb2dsZVRhZ0lkKTtcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbi8qKlxuICogXHRUcmFjayB1c2FnZSBvZiBjb29raWVEZXByZWNhdGlvbkxhYmVsXG4gKi9cbmNvbnN0IHNldENvb2tpZURlcHJlY2F0aW9uTGFiZWwgPSAoKSA9PiB7XG4gICAgaWYgKCdjb29raWVEZXByZWNhdGlvbkxhYmVsJyBpbiBuYXZpZ2F0b3IpIHtcbiAgICAgICAgdm9pZCBuYXZpZ2F0b3IuY29va2llRGVwcmVjYXRpb25MYWJlbD8uZ2V0VmFsdWUoKS50aGVuKCh2YWx1ZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY29va2llRGVwcmVjYXRpb25MYWJlbCA9IHZhbHVlIHx8ICdlbXB0eSc7XG4gICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnXG4gICAgICAgICAgICAgICAgLnB1YmFkcygpXG4gICAgICAgICAgICAgICAgLnNldFRhcmdldGluZygnY29va2llRGVwcmVjYXRpb25MYWJlbCcsIGNvb2tpZURlcHJlY2F0aW9uTGFiZWwpO1xuICAgICAgICB9KTtcbiAgICB9XG59O1xuY29uc3QgZW5hYmxlVGFyZ2V0aW5nID0gKGNvbnNlbnRTdGF0ZSkgPT4ge1xuICAgIGlmIChjb25zZW50U3RhdGUuY2FuVGFyZ2V0KSB7XG4gICAgICAgIHdpbmRvdy5nb29nbGV0YWcuY21kLnB1c2goc2V0UHVibGlzaGVyUHJvdmlkZWRJZCk7XG4gICAgICAgIHdpbmRvdy5nb29nbGV0YWcuY21kLnB1c2goc2V0Q29va2llRGVwcmVjYXRpb25MYWJlbCk7XG4gICAgICAgIHdpbmRvdy5nb29nbGV0YWcuY21kLnB1c2goY2hlY2tUaGlyZFBhcnR5Q29va2llc0VuYWJsZWQpO1xuICAgIH1cbn07XG5jb25zdCBpc0dvb2dsZVRhZ0FsbG93ZWQgPSAoY29uc2VudFN0YXRlKSA9PiBnZXRDb25zZW50Rm9yKCdnb29nbGV0YWcnLCBjb25zZW50U3RhdGUpO1xuY29uc3QgY2FuUnVuR29vZ2xldGFnID0gKGNvbnNlbnRTdGF0ZSkgPT4ge1xuICAgIGlmIChjb25zZW50U3RhdGUudGNmdjIpIHtcbiAgICAgICAgcmV0dXJuIGlzR29vZ2xlVGFnQWxsb3dlZChjb25zZW50U3RhdGUpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5jb25zdCBoYW5kbGVMb2NhbGVQZXJtaXNzaW9ucyA9IChjb25zZW50U3RhdGUpID0+IHtcbiAgICBpZiAoY29uc2VudFN0YXRlLnVzbmF0KSB7XG4gICAgICAgIC8vIFVTIG1vZGUtIFVTTkFUIGlzIGEgZ2VuZXJhbC1wdXJwb3NlIGNvbnNlbnQgc3RyaW5nIGZvciB2YXJpb3VzIHN0YXRlIGxhd3NcbiAgICAgICAgd2luZG93Lmdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLnB1YmFkcygpLnNldFByaXZhY3lTZXR0aW5ncyh7XG4gICAgICAgICAgICAgICAgcmVzdHJpY3REYXRhUHJvY2Vzc2luZzogIWNvbnNlbnRTdGF0ZS5jYW5UYXJnZXQsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKGNvbnNlbnRTdGF0ZS5hdXMpIHtcbiAgICAgICAgLy8gQVVTIG1vZGVcbiAgICAgICAgd2luZG93Lmdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLnB1YmFkcygpLnNldFByaXZhY3lTZXR0aW5ncyh7XG4gICAgICAgICAgICAgICAgbm9uUGVyc29uYWxpemVkQWRzOiAhaXNHb29nbGVUYWdBbGxvd2VkKGNvbnNlbnRTdGF0ZSksXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfSk7XG4gICAgfVxufTtcbmV4cG9ydCBjb25zdCBpbml0ID0gKCkgPT4ge1xuICAgIGNvbnN0IHNldHVwQWR2ZXJ0aXNpbmcgPSBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGNvbnNlbnRTdGF0ZSA9IGF3YWl0IG9uQ29uc2VudCgpO1xuICAgICAgICBFdmVudFRpbWVyLmdldCgpLm1hcmsoJ2dvb2dsZXRhZ0luaXRTdGFydCcpO1xuICAgICAgICBjb25zdCBjYW5SdW4gPSBjYW5SdW5Hb29nbGV0YWcoY29uc2VudFN0YXRlKTtcbiAgICAgICAgZW5hYmxlVGFyZ2V0aW5nKGNvbnNlbnRTdGF0ZSk7XG4gICAgICAgIGhhbmRsZUxvY2FsZVBlcm1pc3Npb25zKGNvbnNlbnRTdGF0ZSk7XG4gICAgICAgIC8vIFByZWJpZCB3aWxsIGFscmVhZHkgYmUgbG9hZGVkLCBhbmQgd2luZG93Lmdvb2dsZXRhZyBpcyBzdHViYmVkIGluIGBjb21tZXJjaWFsLmpzYC5cbiAgICAgICAgLy8gSnVzdCBsb2FkIGdvb2dsZXRhZyAtIGl0J3MgYWxyZWFkeSBhZGRlZCB0byB0aGUgd2luZG93IGJ5IFByZWJpZC5cbiAgICAgICAgaWYgKGNhblJ1bikge1xuICAgICAgICAgICAgY29uc3QgaXNTaWduZWRJbiA9IGF3YWl0IGlzVXNlckxvZ2dlZEluKCk7XG4gICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLmNtZC5wdXNoKCgpID0+IEV2ZW50VGltZXIuZ2V0KCkubWFyaygnZ29vZ2xldGFnSW5pdEVuZCcpLCAoKSA9PiBzZXRQYWdlVGFyZ2V0aW5nKGNvbnNlbnRTdGF0ZSwgaXNTaWduZWRJbiksIFxuICAgICAgICAgICAgLy8gTm90ZTogdGhpcyBmdW5jdGlvbiBpc24ndCBzeW5jaHJvbm91cyBsaWtlIG1vc3QgYnVmZmVyZWQgY21kcywgaXQncyBhIHByb21pc2UuIEl0J3MgcHV0IGluIGhlcmUgdG8gZW5zdXJlXG4gICAgICAgICAgICAvLyBpdCBzdHJpY3RseSBmb2xsb3dzIHByZWNlZGluZyBwcmVwYXJlLWdvb2dsZXRhZyB3b3JrIChhbmQgdGhlIG1vZHVsZSBpdHNlbGYgZW5zdXJlcyBkZXBlbmRlbmNpZXMgYXJlXG4gICAgICAgICAgICAvLyBmdWxmaWxsZWQpLCBidXQgZG9uJ3QgYXNzdW1lIHRoaXMgZnVuY3Rpb24gaXMgY29tcGxldGUgd2hlbiBxdWV1ZWluZyBzdWJzZXF1ZW50IHdvcmsgdXNpbmcgY21kLnB1c2hcbiAgICAgICAgICAgICgpID0+IHZvaWQgZmlsbFN0YXRpY0FkdmVydFNsb3RzKCkpO1xuICAgICAgICAgICAgLy8gVGhlIER1Y2tEdWNrR28gYnJvd3NlciBibG9ja3MgYWRzIGZyb20gbG9hZGluZyBieSBkZWZhdWx0LCBzbyBpdCBjYXVzZXMgYSBsb3Qgb2Ygbm9pc2UgaW4gU2VudHJ5LlxuICAgICAgICAgICAgLy8gV2UgZmlsdGVyIHRoZXNlIGVycm9ycyBvdXQgaGVyZSAtIER1Y2tEdWNrR28gaXMgaW4gdGhlIHVzZXIgYWdlbnQgc3RyaW5nIGlmIHNvbWVvbmUgaXMgdXNpbmcgdGhlXG4gICAgICAgICAgICAvLyBkZXNrdG9wIGJyb3dzZXIsIGFuZCBEZGcgaXMgcHJlc2VudCBmb3IgdGhvc2UgdXNpbmcgdGhlIG1vYmlsZSBicm93c2VyLCBzbyB3ZSBmaWx0ZXIgb3V0IGJvdGguXG4gICAgICAgICAgICBsb2FkU2NyaXB0KHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5saWJzPy5nb29nbGV0YWcgPz9cbiAgICAgICAgICAgICAgICAnLy9zZWN1cmVwdWJhZHMuZy5kb3VibGVjbGljay5uZXQvdGFnL2pzL2dwdC5qcycsIHsgYXN5bmM6IGZhbHNlIH0pLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChuYXZpZ2F0b3IudXNlckFnZW50LmluY2x1ZGVzKCdEdWNrRHVja0dvJykgfHxcbiAgICAgICAgICAgICAgICAgICAgbmF2aWdhdG9yLnVzZXJBZ2VudC5pbmNsdWRlcygnRGRnJykpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ/CfpoYgQ2F1Z2h0IGxvYWRTY3JpcHQgZXJyb3Igb24gRHVja0R1Y2tHbycsIGVycm9yKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBpZiAoY29tbWVyY2lhbEZlYXR1cmVzLnNob3VsZExvYWRHb29nbGV0YWcpIHtcbiAgICAgICAgcmV0dXJuIChzZXR1cEFkdmVydGlzaW5nKClcbiAgICAgICAgICAgIC8vIG9uIGVycm9yLCByZW1vdmUgYWxsIHNsb3RzXG4gICAgICAgICAgICAuY2F0Y2gocmVtb3ZlU2xvdHMpKTtcbiAgICB9XG4gICAgcmV0dXJuIHJlbW92ZVNsb3RzKCk7XG59O1xuIiwiaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgcmVwb3J0RXJyb3IgfSBmcm9tICcuLi8uLi9saWIvZXJyb3IvcmVwb3J0LWVycm9yJztcbmNvbnN0IGlzRW1wdHkgPSAodmFsdWUpID0+IHZhbHVlID09PSAnJyB8fFxuICAgIHZhbHVlID09PSBudWxsIHx8XG4gICAgdHlwZW9mIHZhbHVlID09PSAndW5kZWZpbmVkJyB8fFxuICAgIChBcnJheS5pc0FycmF5KHZhbHVlKSAmJiB2YWx1ZS5sZW5ndGggPT09IDApIHx8XG4gICAgKHR5cGVvZiB2YWx1ZSA9PT0gJ29iamVjdCcgJiYgT2JqZWN0LmtleXModmFsdWUpLmxlbmd0aCA9PT0gMCk7XG5jb25zdCByZW1vdmVFbXB0eSA9IChwYXlsb2FkKSA9PiB7XG4gICAgbGV0IGtleTtcbiAgICBmb3IgKGtleSBpbiBwYXlsb2FkKSB7XG4gICAgICAgIGlmICh0eXBlb2YgcGF5bG9hZFtrZXldID09PSAnb2JqZWN0Jykge1xuICAgICAgICAgICAgcmVtb3ZlRW1wdHkocGF5bG9hZFtrZXldKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNFbXB0eShwYXlsb2FkW2tleV0pKSB7XG4gICAgICAgICAgICBkZWxldGUgcGF5bG9hZFtrZXldO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBwYXlsb2FkO1xufTtcbmNvbnN0IGdlbmVyYXRlUGF5bG9hZCA9ICh7IHBhZ2UsIHVzZXIsIH0pID0+IHtcbiAgICBjb25zdCB7IGlzUGFpZENvbnRlbnQsIHBhZ2VJZCwgaGVhZGxpbmUsIGNvbnRlbnRUeXBlLCBzZWN0aW9uLCBhdXRob3IsIGtleXdvcmRzLCB3ZWJQdWJsaWNhdGlvbkRhdGUsIHNlcmllcywgZWRpdGlvbiwgdG9uZUlkcywgfSA9IHBhZ2U7XG4gICAgY29uc3Qgc2FmZUF1dGhvcnMgPSAoYXV0aG9yICYmIHR5cGVvZiBhdXRob3IgPT09ICdzdHJpbmcnID8gYXV0aG9yLnNwbGl0KCcsJykgOiBbXSkubWFwKChzdHIpID0+IHN0ci50cmltKCkpO1xuICAgIGNvbnN0IHNhZmVLZXl3b3JkcyA9IChrZXl3b3JkcyAmJiB0eXBlb2Yga2V5d29yZHMgPT09ICdzdHJpbmcnID8ga2V5d29yZHMuc3BsaXQoJywnKSA6IFtdKS5tYXAoKHN0cikgPT4gc3RyLnRyaW0oKSk7XG4gICAgY29uc3Qgc2FmZVB1Ymxpc2hlZEF0ID0gd2ViUHVibGljYXRpb25EYXRlICYmIHR5cGVvZiB3ZWJQdWJsaWNhdGlvbkRhdGUgPT09ICdudW1iZXInXG4gICAgICAgID8gbmV3IERhdGUod2ViUHVibGljYXRpb25EYXRlKS50b0lTT1N0cmluZygpXG4gICAgICAgIDogJyc7XG4gICAgY29uc3Qgc2FmZVRvbmVJZHMgPSAodG9uZUlkcyAmJiB0eXBlb2YgdG9uZUlkcyA9PT0gJ3N0cmluZycgPyB0b25lSWRzLnNwbGl0KCcsJykgOiBbXSkubWFwKChzdHIpID0+IHN0ci50cmltKCkpO1xuICAgIGNvbnN0IGNsZWFuUGF5bG9hZCA9IHJlbW92ZUVtcHR5KHtcbiAgICAgICAgY29udGVudDoge1xuICAgICAgICAgICAgcHJlbWl1bTogaXNQYWlkQ29udGVudCxcbiAgICAgICAgICAgIGlkOiBwYWdlSWQsXG4gICAgICAgICAgICB0aXRsZTogaGVhZGxpbmUsXG4gICAgICAgICAgICB0eXBlOiBjb250ZW50VHlwZSxcbiAgICAgICAgICAgIHNlY3Rpb24sXG4gICAgICAgICAgICBhdXRob3JzOiBzYWZlQXV0aG9ycyxcbiAgICAgICAgICAgIGtleXdvcmRzOiBzYWZlS2V5d29yZHMsXG4gICAgICAgICAgICBwdWJsaXNoZWRBdDogc2FmZVB1Ymxpc2hlZEF0LFxuICAgICAgICAgICAgc2VyaWVzLFxuICAgICAgICAgICAgdG9uZTogc2FmZVRvbmVJZHMsXG4gICAgICAgIH0sXG4gICAgICAgIHVzZXI6IHtcbiAgICAgICAgICAgIGVkaXRpb24sXG4gICAgICAgICAgICBpZGVudGl0eTogaXNFbXB0eSh1c2VyKSA/IGZhbHNlIDogIWlzRW1wdHkodXNlcj8uaWQpLFxuICAgICAgICB9LFxuICAgIH0pO1xuICAgIHJldHVybiBjbGVhblBheWxvYWQ7XG59O1xuY29uc3QgZ2VuZXJhdGVQZXJtdXRpdmVJZGVudGl0aWVzID0gKGNvbmZpZykgPT4ge1xuICAgIGlmICh0eXBlb2YgY29uZmlnLm9waGFuID09PSAnb2JqZWN0JyAmJlxuICAgICAgICB0eXBlb2YgY29uZmlnLm9waGFuLmJyb3dzZXJJZCA9PT0gJ3N0cmluZycgJiZcbiAgICAgICAgY29uZmlnLm9waGFuLmJyb3dzZXJJZC5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiBbeyB0YWc6ICdvcGhhbicsIGlkOiBjb25maWcub3BoYW4uYnJvd3NlcklkIH1dO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59O1xuY29uc3QgcnVuUGVybXV0aXZlID0gKHBhZ2VDb25maWcsIHBlcm11dGl2ZUdsb2JhbCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGlmICghcGVybXV0aXZlR2xvYmFsPy5hZGRvbikge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdHbG9iYWwgUGVybXV0aXZlIHNldHVwIGVycm9yJyk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgcGVybXV0aXZlSWRlbnRpdGllcyA9IGdlbmVyYXRlUGVybXV0aXZlSWRlbnRpdGllcyhwYWdlQ29uZmlnKTtcbiAgICAgICAgaWYgKHBlcm11dGl2ZUdsb2JhbC5pZGVudGlmeSAmJiBwZXJtdXRpdmVJZGVudGl0aWVzLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIHBlcm11dGl2ZUdsb2JhbC5pZGVudGlmeShwZXJtdXRpdmVJZGVudGl0aWVzKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBwYXlsb2FkID0gZ2VuZXJhdGVQYXlsb2FkKHBhZ2VDb25maWcpO1xuICAgICAgICBwZXJtdXRpdmVHbG9iYWwuYWRkb24oJ3dlYicsIHtcbiAgICAgICAgICAgIHBhZ2U6IHBheWxvYWQsXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIHJlcG9ydEVycm9yKGVyciwgJ2NvbW1lcmNpYWwnKTtcbiAgICB9XG59O1xuLyoqXG4gKiBJbml0aWFsaXNlIFBlcm11dGl2ZSB1c2VyIHNlZ21lbnRhdGlvbiAtIHJlYWRzIGRhdGEgc3RvcmVkIGJ5IHRoaXJkLXBhcnR5LXRhZ3MgcGVybXV0aXZlIHNjcmlwdCBmb3IgYWQgdGFyZ2V0aW5nXG4gKiBodHRwczovL3Blcm11dGl2ZS5jb20vYXVkaWVuY2UtcGxhdGZvcm0vcHVibGlzaGVycy9cbiAqIEByZXR1cm5zIFByb21pc2VcbiAqL1xuY29uc3QgaW5pdFBlcm11dGl2ZVNlZ21lbnRhdGlvbiA9ICgpID0+IHtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCAnSW5pdGlhbGlzaW5nIFBlcm11dGl2ZSBzZWdtZW50YXRpb24nKTtcbiAgICAvKiBlc2xpbnQtZGlzYWJsZSAtLSBwZXJtdXRpdmUgY29kZSAqL1xuICAgIC8vIEZyb20gaGVyZSB1bnRpbCB3ZSByZS1lbmFibGUgZXNsaW50IGlzIHRoZSBQZXJtdXRpdmUgY29kZVxuICAgIC8vIHRoYXQgd2UgcmVjZWl2ZWQgZnJvbSB0aGVtLlxuICAgIC8vIFBsZWFzZSBkbyBub3QgY2hhbmdlIHVubGVzcyB5b3UndmUgY29uc3VsdGVkIHdpdGggUGVybXV0aXZlXG4gICAgLy8gYW5kIGNvbmZpcm1lZCB0aGUgY2hhbmdlIGlzIHNhZmUuXG4gICAgKGZ1bmN0aW9uIChuLCBlLCBvLCByLCBpKSB7XG4gICAgICAgIGlmICghZSkge1xuICAgICAgICAgICAgKChlID0gZSB8fCB7fSksXG4gICAgICAgICAgICAgICAgKHdpbmRvdy5wZXJtdXRpdmUgPSBlKSxcbiAgICAgICAgICAgICAgICAoZS5xID0gW10pLFxuICAgICAgICAgICAgICAgIChlLmNvbmZpZyA9IGkgfHwge30pLFxuICAgICAgICAgICAgICAgIChlLmNvbmZpZy5wcm9qZWN0SWQgPSBvKSxcbiAgICAgICAgICAgICAgICAoZS5jb25maWcuYXBpS2V5ID0gciksXG4gICAgICAgICAgICAgICAgKGUuY29uZmlnLmVudmlyb25tZW50ID0gZS5jb25maWcuZW52aXJvbm1lbnQgfHwgJ3Byb2R1Y3Rpb24nKSk7XG4gICAgICAgICAgICBmb3IgKGxldCB0ID0gW1xuICAgICAgICAgICAgICAgICdhZGRvbicsXG4gICAgICAgICAgICAgICAgJ2lkZW50aWZ5JyxcbiAgICAgICAgICAgICAgICAndHJhY2snLFxuICAgICAgICAgICAgICAgICd0cmlnZ2VyJyxcbiAgICAgICAgICAgICAgICAncXVlcnknLFxuICAgICAgICAgICAgICAgICdzZWdtZW50JyxcbiAgICAgICAgICAgICAgICAnc2VnbWVudHMnLFxuICAgICAgICAgICAgICAgICdyZWFkeScsXG4gICAgICAgICAgICAgICAgJ29uJyxcbiAgICAgICAgICAgICAgICAnb25jZScsXG4gICAgICAgICAgICAgICAgJ3VzZXInLFxuICAgICAgICAgICAgICAgICdjb25zZW50JyxcbiAgICAgICAgICAgIF0sIGMgPSAwOyBjIDwgdC5sZW5ndGg7IGMrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IGYgPSB0W2NdO1xuICAgICAgICAgICAgICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgLS0gYmVzdCBub3QgdG8gY2hhbmdlIHRoaXMgY29kZSBmcm9tIHBlcm11dGl2ZVxuICAgICAgICAgICAgICAgIGVbZl0gPSAoZnVuY3Rpb24gKG4pIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IG8gPSBBcnJheS5wcm90b3R5cGUuc2xpY2UuY2FsbChhcmd1bWVudHMsIDApO1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtLSBiZXN0IG5vdCB0byBjaGFuZ2UgdGhpcyBjb2RlIGZyb20gcGVybXV0aXZlXG4gICAgICAgICAgICAgICAgICAgICAgICBlLnEucHVzaCh7IGZ1bmN0aW9uTmFtZTogbiwgYXJndW1lbnRzOiBvIH0pO1xuICAgICAgICAgICAgICAgICAgICB9O1xuICAgICAgICAgICAgICAgIH0pKGYpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSkoZG9jdW1lbnQsIHdpbmRvdy5wZXJtdXRpdmUsICdkNjY5MWExNy02ZmRiLTRkMjYtODVkNi1iM2RkMjdmNTVmMDgnLCAnMzU5YmEyNzUtNWVkZC00NzU2LTg0ZjgtMjFhMjQzNjljZTBiJywge30pO1xuICAgIC8vIFRoaXMgaXMgb3VyIGNvZGUsIGJ1dCBub3QgcmUtZW5hYmxpbmcgRVNMaW50IGJlY2F1c2Ugd2UnZCBoYXZlIHRvIGRpc2FibGUgaXQgZm9yIGJvdGggZm9sbG93aW5nIGxpbmVzIGFueXdheVxuICAgIHdpbmRvdy5nb29nbGV0YWcgPSB3aW5kb3cuZ29vZ2xldGFnIHx8IHt9O1xuICAgIC8vIEB0cy1leHBlY3QtZXJyb3IgLS0gdGhpcyBpcyBhIHN0dWJcbiAgICB3aW5kb3cuZ29vZ2xldGFnLmNtZCA9IHdpbmRvdy5nb29nbGV0YWcuY21kIHx8IFtdO1xuICAgIC8qIGVzbGludC1lbmFibGUgKi9cbiAgICB3aW5kb3cuZ29vZ2xldGFnLmNtZC5wdXNoKCgpID0+IHtcbiAgICAgICAgaWYgKHdpbmRvdy5nb29nbGV0YWcucHViYWRzKCkuZ2V0VGFyZ2V0aW5nKCdwZXJtdXRpdmUnKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgICAgIGNvbnN0IGcgPSB3aW5kb3cubG9jYWxTdG9yYWdlLmdldEl0ZW0oJ19wZGZwcycpO1xuICAgICAgICAgICAgd2luZG93Lmdvb2dsZXRhZ1xuICAgICAgICAgICAgICAgIC5wdWJhZHMoKVxuICAgICAgICAgICAgICAgIC5zZXRUYXJnZXRpbmcoJ3Blcm11dGl2ZScsIGcgPyBKU09OLnBhcnNlKGcpIDogW10pO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgY29uc3QgcGVybXV0aXZlQ29uZmlnID0ge1xuICAgICAgICB1c2VyOiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnVzZXIsXG4gICAgICAgIHBhZ2U6IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZSxcbiAgICAgICAgb3BoYW46IHdpbmRvdy5ndWFyZGlhbi5jb25maWcub3BoYW4sXG4gICAgfTtcbiAgICBydW5QZXJtdXRpdmUocGVybXV0aXZlQ29uZmlnLCB3aW5kb3cucGVybXV0aXZlKTtcbn07XG5leHBvcnQgY29uc3QgaW5pdFBlcm11dGl2ZSA9ICgpID0+IHtcbiAgICBpZiAod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlcy5wZXJtdXRpdmUpIHtcbiAgICAgICAgdm9pZCBpbml0UGVybXV0aXZlU2VnbWVudGF0aW9uKCk7XG4gICAgfVxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbn07XG5leHBvcnQgY29uc3QgXyA9IHtcbiAgICBpc0VtcHR5LFxuICAgIHJlbW92ZUVtcHR5LFxuICAgIGdlbmVyYXRlUGF5bG9hZCxcbiAgICBnZW5lcmF0ZVBlcm11dGl2ZUlkZW50aXRpZXMsXG4gICAgcnVuUGVybXV0aXZlLFxufTtcbiIsImltcG9ydCB7IGlzSW5DYW5hZGEgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2dlby9nZW8tdXRpbHMnO1xuaW1wb3J0IHsgbG9nLCBvbkNvbnNlbnQgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBvbmNlIH0gZnJvbSAnbG9kYXNoLWVzJztcbmltcG9ydCB7IGlzVXNlckluVmFyaWFudCB9IGZyb20gJy4uLy4uL2V4cGVyaW1lbnRzL2FiJztcbmltcG9ydCB7IHByZWJpZDk0NiB9IGZyb20gJy4uLy4uL2V4cGVyaW1lbnRzL3Rlc3RzL3ByZWJpZDk0Nic7XG5pbXBvcnQgeyBjb21tZXJjaWFsRmVhdHVyZXMgfSBmcm9tICcuLi8uLi9saWIvY29tbWVyY2lhbC1mZWF0dXJlcyc7XG5pbXBvcnQgeyBpc0dvb2dsZVByb3h5IH0gZnJvbSAnLi4vLi4vbGliL2RldGVjdC9kZXRlY3QtZ29vZ2xlLXByb3h5JztcbmltcG9ydCB7IHByZWJpZCB9IGZyb20gJy4uLy4uL2xpYi9oZWFkZXItYmlkZGluZy9wcmViaWQvcHJlYmlkJztcbmltcG9ydCB7IHNob3VsZEluY2x1ZGVPbmx5QTkgfSBmcm9tICcuLi8uLi9saWIvaGVhZGVyLWJpZGRpbmcvdXRpbHMnO1xuY29uc3Qgc2hvdWxkTG9hZFByZWJpZCA9ICgpID0+ICFpc0dvb2dsZVByb3h5KCkgJiZcbiAgICB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLnByZWJpZEhlYWRlckJpZGRpbmcgJiZcbiAgICBjb21tZXJjaWFsRmVhdHVyZXMuc2hvdWxkTG9hZEdvb2dsZXRhZyAmJlxuICAgICFjb21tZXJjaWFsRmVhdHVyZXMuYWRGcmVlICYmXG4gICAgIXdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5oYXNQYWdlU2tpbiAmJlxuICAgICFzaG91bGRJbmNsdWRlT25seUE5ICYmXG4gICAgIWlzSW5DYW5hZGEoKTtcbmNvbnN0IHNob3VsZExvYWRQcmViaWQ5NDYgPSBpc1VzZXJJblZhcmlhbnQocHJlYmlkOTQ2LCAndmFyaWFudCcpO1xuY29uc3QgbG9hZFByZWJpZCA9IGFzeW5jIChjb25zZW50U3RhdGUpID0+IHtcbiAgICBpZiAoc2hvdWxkTG9hZFByZWJpZCgpKSB7XG4gICAgICAgIGlmIChzaG91bGRMb2FkUHJlYmlkOTQ2KSB7XG4gICAgICAgICAgICBhd2FpdCBpbXBvcnQoXG4gICAgICAgICAgICAvKiB3ZWJwYWNrQ2h1bmtOYW1lOiBcIlByZWJpZEA5LjQ2LjAuanNcIiAqL1xuICAgICAgICAgICAgYC4uLy4uL2xpYi9oZWFkZXItYmlkZGluZy9wcmViaWQvcGJqcy12OS40Ni4wYCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBhd2FpdCBpbXBvcnQoXG4gICAgICAgICAgICAvKiB3ZWJwYWNrQ2h1bmtOYW1lOiBcIlByZWJpZC5qc1wiICovXG4gICAgICAgICAgICBgLi4vLi4vbGliL2hlYWRlci1iaWRkaW5nL3ByZWJpZC9wYmpzYCk7XG4gICAgICAgIH1cbiAgICAgICAgcHJlYmlkLmluaXRpYWxpc2Uod2luZG93LCBjb25zZW50U3RhdGUpO1xuICAgIH1cbn07XG5jb25zdCB0aHJvd0lmVW5jb25zZW50ZWQgPSAoaGFzQ29uc2VudEZvclByZWJpZCkgPT4ge1xuICAgIGxvZygnY29tbWVyY2lhbCcsICdQcmViaWQgY29uc2VudDonLCB7XG4gICAgICAgIGhhc0NvbnNlbnRGb3JQcmViaWQsXG4gICAgfSk7XG4gICAgaWYgKCFoYXNDb25zZW50Rm9yUHJlYmlkKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gY29uc2VudCBmb3IgcHJlYmlkJyk7XG4gICAgfVxufTtcbmNvbnN0IHNldHVwUHJlYmlkID0gYXN5bmMgKCkgPT4ge1xuICAgIHRyeSB7XG4gICAgICAgIGNvbnN0IGNvbnNlbnRTdGF0ZSA9IGF3YWl0IG9uQ29uc2VudCgpO1xuICAgICAgICBpZiAoIWNvbnNlbnRTdGF0ZS5mcmFtZXdvcmspIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignVW5rbm93biBmcmFtZXdvcmsnKTtcbiAgICAgICAgfVxuICAgICAgICBzd2l0Y2ggKGNvbnNlbnRTdGF0ZS5mcmFtZXdvcmspIHtcbiAgICAgICAgICAgIGNhc2UgJ2F1cyc6XG4gICAgICAgICAgICAgICAgdGhyb3dJZlVuY29uc2VudGVkKCEhY29uc2VudFN0YXRlLmF1cz8ucGVyc29uYWxpc2VkQWR2ZXJ0aXNpbmcpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndXNuYXQnOlxuICAgICAgICAgICAgICAgIHRocm93SWZVbmNvbnNlbnRlZCghY29uc2VudFN0YXRlLnVzbmF0Py5kb05vdFNlbGwpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAndGNmdjInOlxuICAgICAgICAgICAgICAgIC8vIFdlIGRvIHBlci12ZW5kb3IgY2hlY2tzIGZvciB0aGlzIGZyYW1ld29yaywgbm8gcmVxdWlyZW1lbnQgZm9yIGEgdG9wLWxldmVsIGNoZWNrIGZvciBQcmViaWRcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbG9hZFByZWJpZChjb25zZW50U3RhdGUpO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnN0IGVycm9yID0gZXJyO1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAn4pqg77iPIEZhaWxlZCB0byBleGVjdXRlIHByZWJpZCcsIGVycm9yLm1lc3NhZ2UpO1xuICAgIH1cbn07XG5leHBvcnQgY29uc3Qgc2V0dXBQcmViaWRPbmNlID0gb25jZShzZXR1cFByZWJpZCk7XG4vKipcbiAqIEluaXRpYWxpc2UgcHJlYmlkIC0gaGVhZGVyIGJpZGRpbmcgZm9yIGRpc3BsYXkgYW5kIHZpZGVvIGFkc1xuICogaHR0cHM6Ly9kb2NzLnByZWJpZC5vcmcvb3ZlcnZpZXcvaW50cm8uaHRtbFxuICogQHJldHVybnMgUHJvbWlzZVxuICovXG5leHBvcnQgY29uc3QgaW5pdCA9ICgpID0+IHNldHVwUHJlYmlkT25jZSgpO1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgc2V0dXBQcmViaWQsXG59O1xuIiwiaW1wb3J0IHsgYWRTaXplcywgY3JlYXRlQWRTaXplIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBpc0luVXNhIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9nZW8vZ2VvLXV0aWxzJztcbmltcG9ydCB7IGlzTm9uTnVsbGFibGUsIGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGNyZWF0ZUFkdmVydCB9IGZyb20gJy4uLy4uL2RlZmluZS9jcmVhdGUtYWR2ZXJ0JztcbmltcG9ydCB7IGRpc3BsYXlBZHMgfSBmcm9tICcuLi8uLi9kaXNwbGF5L2Rpc3BsYXktYWRzJztcbmltcG9ydCB7IGRpc3BsYXlMYXp5QWRzIH0gZnJvbSAnLi4vLi4vZGlzcGxheS9kaXNwbGF5LWxhenktYWRzJztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uLy4uL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCB7IGdldEN1cnJlbnRCcmVha3BvaW50IH0gZnJvbSAnLi4vLi4vbGliL2RldGVjdC9kZXRlY3QtYnJlYWtwb2ludCc7XG5pbXBvcnQgeyBkZnBFbnYgfSBmcm9tICcuLi8uLi9saWIvZGZwL2RmcC1lbnYnO1xuaW1wb3J0IHsgcXVldWVBZHZlcnQgfSBmcm9tICcuLi8uLi9saWIvZGZwL3F1ZXVlLWFkdmVydCc7XG5pbXBvcnQgeyBzZXR1cFByZWJpZE9uY2UgfSBmcm9tICcuL3ByZXBhcmUtcHJlYmlkJztcbmltcG9ydCB7IHJlbW92ZURpc2FibGVkU2xvdHMgfSBmcm9tICcuL3JlbW92ZS1zbG90cyc7XG5jb25zdCBkZWNpZGVBZGRpdGlvbmFsU2l6ZXMgPSAoYWRTbG90KSA9PiB7XG4gICAgY29uc3QgeyBjb250ZW50VHlwZSB9ID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlO1xuICAgIGNvbnN0IHsgbmFtZSB9ID0gYWRTbG90LmRhdGFzZXQ7XG4gICAgaWYgKGNvbnRlbnRUeXBlID09PSAnR2FsbGVyeScgJiYgbmFtZT8uaW5jbHVkZXMoJ2lubGluZScpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBkZXNrdG9wOiBbYWRTaXplcy5iaWxsYm9hcmQsIGNyZWF0ZUFkU2l6ZSg5MDAsIDI1MCldLFxuICAgICAgICB9O1xuICAgIH1cbiAgICBpZiAoY29udGVudFR5cGUgPT09ICdMaXZlQmxvZycgJiYgbmFtZT8uaW5jbHVkZXMoJ2lubGluZScpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBwaGFibGV0OiBbYWRTaXplcy5vdXRzdHJlYW1EZXNrdG9wLCBhZFNpemVzLm91dHN0cmVhbUdvb2dsZURlc2t0b3BdLFxuICAgICAgICAgICAgZGVza3RvcDogW2FkU2l6ZXMub3V0c3RyZWFtRGVza3RvcCwgYWRTaXplcy5vdXRzdHJlYW1Hb29nbGVEZXNrdG9wXSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKG5hbWUgPT09ICdhcnRpY2xlLWVuZCcgJiYgaXNJblVzYSgpKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBtb2JpbGU6IFthZFNpemVzLmZsdWlkXSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgcmV0dXJuIHt9O1xufTtcbi8qKlxuICogU3RhdGljIGFkIHNsb3RzIHRoYXQgd2VyZSByZW5kZXJlZCBvbiB0aGUgcGFnZSBieSB0aGUgc2VydmVyIGFyZSBjb2xsZWN0ZWQgaGVyZS5cbiAqXG4gKiBGb3IgZHluYW1pYyBhZCBzbG90cyB0aGF0IGFyZSBjcmVhdGVkIGF0IHJ1bnRpbWUsIHNlZTpcbiAqICAtIGFydGljbGUtYm9keS1hZHZlcnRzXG4gKiAgLSBoaWdoLW1lcmNoXG4gKi9cbmNvbnN0IGZpbGxTdGF0aWNBZHZlcnRTbG90cyA9IGFzeW5jICgpID0+IHtcbiAgICAvLyBUaGlzIG1vZHVsZSBoYXMgdGhlIGZvbGxvd2luZyBzdHJpY3QgZGVwZW5kZW5jaWVzLiBUaGVzZSBkZXBlbmRlbmNpZXMgbXVzdCBiZVxuICAgIC8vIGZ1bGZpbGxlZCBiZWZvcmUgdGhpcyBmdW5jdGlvbiBjYW4gZXhlY3V0ZSByZWxpYWJseS4gVGhlIGJvb3RzdHJhcFxuICAgIC8vIGluaXRpYXRlcyB0aGVzZSBkZXBlbmRlbmNpZXMsIHRvIHNwZWVkIHVwIHRoZSBpbml0IHByb2Nlc3MuIEJvb3RzdHJhcCBhbHNvIGNhcHR1cmVzIHRoZSBtb2R1bGUgcGVyZm9ybWFuY2UuXG4gICAgY29uc3QgZGVwZW5kZW5jaWVzID0gW3JlbW92ZURpc2FibGVkU2xvdHMoKV07XG4gICAgYXdhaXQgUHJvbWlzZS5hbGwoZGVwZW5kZW5jaWVzKTtcbiAgICAvLyBQcmViaWQgbWlnaHQgbm90IGxvYWQgaWYgaXQgZG9lcyBub3QgaGF2ZSBjb25zZW50XG4gICAgLy8gVE9ETzogdXNlIFByb21pc2UuYWxsU2V0dGxlZCwgb25jZSB3ZSBoYXZlIE5vZGUgMTJcbiAgICBhd2FpdCBzZXR1cFByZWJpZE9uY2UoKS5jYXRjaCgocmVhc29uKSA9PiBsb2coJ2NvbW1lcmNpYWwnLCAnY291bGQgbm90IGxvYWQgUHJlYmlkLmpzJywgcmVhc29uKSk7XG4gICAgLy8gUXVpdCBpZiBhZC1mcmVlXG4gICAgaWYgKGNvbW1lcmNpYWxGZWF0dXJlcy5hZEZyZWUpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBjb25zdCBpc0RDUk1vYmlsZSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcuaXNEb3Rjb21SZW5kZXJpbmcgJiZcbiAgICAgICAgZ2V0Q3VycmVudEJyZWFrcG9pbnQoKSA9PT0gJ21vYmlsZSc7XG4gICAgLy8gR2V0IGFsbCBhZCBzbG90c1xuICAgIGNvbnN0IGFkdmVydHMgPSBbXG4gICAgICAgIC4uLmRvY3VtZW50LnF1ZXJ5U2VsZWN0b3JBbGwoZGZwRW52LmFkU2xvdFNlbGVjdG9yKSxcbiAgICBdXG4gICAgICAgIC5maWx0ZXIoKGFkU2xvdCkgPT4gIWRmcEVudi5hZHZlcnRzLmhhcyhhZFNsb3QuaWQpKVxuICAgICAgICAvLyBUT0RPOiBmaW5kIGNsZWFuZXIgd29ya2Fyb3VuZFxuICAgICAgICAvLyB3ZSBuZWVkIHRvIG5vdCBpbml0IHRvcC1hYm92ZS1uYXYgb24gbW9iaWxlIHZpZXcgaW4gRENSXG4gICAgICAgIC8vIGFzIHRoZSBET00gZWxlbWVudCBuZWVkcyB0byBiZSByZW1vdmVkIGFuZCByZXBsYWNlZCB0byBiZSBpbmxpbmVcbiAgICAgICAgLy8gcmVmZXIgdG86IDM1NjJkYzA3LTc4ZTktNDUwNy1iOTIyLTc4Yjk3OWQ0YzVjYlxuICAgICAgICAuZmlsdGVyKChhZFNsb3QpID0+ICEoaXNEQ1JNb2JpbGUgJiYgYWRTbG90LmlkID09PSAnZGZwLWFkLS10b3AtYWJvdmUtbmF2JykpXG4gICAgICAgIC5tYXAoKGFkU2xvdCkgPT4ge1xuICAgICAgICBjb25zdCBhZGRpdGlvbmFsU2l6ZXMgPSBkZWNpZGVBZGRpdGlvbmFsU2l6ZXMoYWRTbG90KTtcbiAgICAgICAgcmV0dXJuIGNyZWF0ZUFkdmVydChhZFNsb3QsIGFkZGl0aW9uYWxTaXplcyk7XG4gICAgfSlcbiAgICAgICAgLmZpbHRlcihpc05vbk51bGxhYmxlKTtcbiAgICBmb3IgKGNvbnN0IGFkdmVydCBvZiBhZHZlcnRzKSB7XG4gICAgICAgIGRmcEVudi5hZHZlcnRzLnNldChhZHZlcnQuaWQsIGFkdmVydCk7XG4gICAgfVxuICAgIGFkdmVydHMuZm9yRWFjaChxdWV1ZUFkdmVydCk7XG4gICAgaWYgKGRmcEVudi5zaG91bGRMYXp5TG9hZCgpKSB7XG4gICAgICAgIGRpc3BsYXlMYXp5QWRzKCk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBkaXNwbGF5QWRzKCk7XG4gICAgfVxufTtcbmV4cG9ydCB7IGZpbGxTdGF0aWNBZHZlcnRTbG90cyB9O1xuIiwiLyogQSByZWdpb25hbGlzZWQgY29udGFpbmVyIGZvciBhbGwgdGhlIGNvbW1lcmNpYWwgdGFncy4gKi9cbmltcG9ydCB7IGdldENvbnNlbnRGb3IsIG9uQ29uc2VudCB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uLy4uL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uLy4uL2xpYi9mYXN0ZG9tLXByb21pc2UnO1xuaW1wb3J0IHsgYWRtaXJhbFRhZyBhcyBhZG1pcmFsIH0gZnJvbSAnLi4vLi4vbGliL3RoaXJkLXBhcnR5LXRhZ3MvYWRtaXJhbCc7XG5pbXBvcnQgeyBpYXMgfSBmcm9tICcuLi8uLi9saWIvdGhpcmQtcGFydHktdGFncy9pYXMnO1xuaW1wb3J0IHsgaW1yV29ybGR3aWRlIH0gZnJvbSAnLi4vLi4vbGliL3RoaXJkLXBhcnR5LXRhZ3MvaW1yLXdvcmxkd2lkZSc7XG5pbXBvcnQgeyBpbXJXb3JsZHdpZGVMZWdhY3kgfSBmcm9tICcuLi8uLi9saWIvdGhpcmQtcGFydHktdGFncy9pbXItd29ybGR3aWRlLWxlZ2FjeSc7XG5pbXBvcnQgeyBpbml6aW8gfSBmcm9tICcuLi8uLi9saWIvdGhpcmQtcGFydHktdGFncy9pbml6aW8nO1xuaW1wb3J0IHsgcGVybXV0aXZlIH0gZnJvbSAnLi4vLi4vbGliL3RoaXJkLXBhcnR5LXRhZ3MvcGVybXV0aXZlJztcbmltcG9ydCB7IHJlbWFya2V0aW5nIH0gZnJvbSAnLi4vLi4vbGliL3RoaXJkLXBhcnR5LXRhZ3MvcmVtYXJrZXRpbmcnO1xuY29uc3QgY3JlYXRlVGFnU2NyaXB0ID0gKHRhZykgPT4ge1xuICAgIGNvbnN0IHNjcmlwdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NjcmlwdCcpO1xuICAgIGlmICh0eXBlb2YgdGFnLnVybCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgc2NyaXB0LnNyYyA9IHRhZy51cmw7XG4gICAgfVxuICAgIC8vIHNjcmlwdC5vbmxvYWQgY2Fubm90IGJlIHVuZGVmaW5lZFxuICAgIHNjcmlwdC5vbmxvYWQgPSB0YWcub25Mb2FkID8/IG51bGw7XG4gICAgaWYgKHRhZy5hc3luYyA9PT0gdHJ1ZSkge1xuICAgICAgICBzY3JpcHQuc2V0QXR0cmlidXRlKCdhc3luYycsICcnKTtcbiAgICB9XG4gICAgaWYgKHRhZy5hdHRycykge1xuICAgICAgICB0YWcuYXR0cnMuZm9yRWFjaCgoYXR0cikgPT4ge1xuICAgICAgICAgICAgc2NyaXB0LnNldEF0dHJpYnV0ZShhdHRyLm5hbWUsIGF0dHIudmFsdWUpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHNjcmlwdDtcbn07XG5jb25zdCBhZGRTY3JpcHRzID0gKHRhZ3MpID0+IHtcbiAgICBjb25zdCByZWYgPSBkb2N1bWVudC5zY3JpcHRzWzBdO1xuICAgIGNvbnN0IGZyYWcgPSBkb2N1bWVudC5jcmVhdGVEb2N1bWVudEZyYWdtZW50KCk7XG4gICAgbGV0IGhhc1NjcmlwdHNUb0luc2VydCA9IGZhbHNlO1xuICAgIHRhZ3MuZm9yRWFjaCgodGFnKSA9PiB7XG4gICAgICAgIGlmICh0YWcubG9hZGVkID09PSB0cnVlKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB0YWcuYmVmb3JlTG9hZD8uKCk7XG4gICAgICAgIC8vIFRhZyBpcyBlaXRoZXIgYW4gaW1hZ2UsIGEgc25pcHBldCBvciBhIHNjcmlwdC5cbiAgICAgICAgaWYgKHRhZy51c2VJbWFnZSA9PT0gdHJ1ZSAmJiB0eXBlb2YgdGFnLnVybCAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgIG5ldyBJbWFnZSgpLnNyYyA9IHRhZy51cmw7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAodGFnLmluc2VydFNuaXBwZXQpIHtcbiAgICAgICAgICAgIHRhZy5pbnNlcnRTbmlwcGV0KCk7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICBoYXNTY3JpcHRzVG9JbnNlcnQgPSB0cnVlO1xuICAgICAgICAgICAgY29uc3Qgc2NyaXB0ID0gY3JlYXRlVGFnU2NyaXB0KHRhZyk7XG4gICAgICAgICAgICBmcmFnLmFwcGVuZENoaWxkKHNjcmlwdCk7XG4gICAgICAgIH1cbiAgICAgICAgdGFnLmxvYWRlZCA9IHRydWU7XG4gICAgfSk7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bm5lY2Vzc2FyeS1jb25kaXRpb24gLS0gZmFsc2UgcG9zaXRpdmVcbiAgICBpZiAoaGFzU2NyaXB0c1RvSW5zZXJ0KSB7XG4gICAgICAgIHJldHVybiBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgICAgICBpZiAocmVmPy5wYXJlbnROb2RlKSB7XG4gICAgICAgICAgICAgICAgcmVmLnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGZyYWcsIHJlZik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuY29uc3QgaW5zZXJ0U2NyaXB0cyA9IGFzeW5jIChhZHZlcnRpc2luZ1NlcnZpY2VzLCBwZXJmb3JtYW5jZVNlcnZpY2VzKSA9PiB7XG4gICAgdm9pZCBhZGRTY3JpcHRzKHBlcmZvcm1hbmNlU2VydmljZXMpO1xuICAgIGNvbnN0IGNvbnNlbnRTdGF0ZSA9IGF3YWl0IG9uQ29uc2VudCgpO1xuICAgIGNvbnN0IGNvbnNlbnRlZEFkdmVydGlzaW5nU2VydmljZXMgPSBhZHZlcnRpc2luZ1NlcnZpY2VzLmZpbHRlcigoc2NyaXB0KSA9PiB7XG4gICAgICAgIGlmIChzY3JpcHQubmFtZSA9PT0gdW5kZWZpbmVkKVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICByZXR1cm4gZ2V0Q29uc2VudEZvcihzY3JpcHQubmFtZSwgY29uc2VudFN0YXRlKTtcbiAgICB9KTtcbiAgICBpZiAoY29uc2VudGVkQWR2ZXJ0aXNpbmdTZXJ2aWNlcy5sZW5ndGggPiAwKSB7XG4gICAgICAgIHZvaWQgYWRkU2NyaXB0cyhjb25zZW50ZWRBZHZlcnRpc2luZ1NlcnZpY2VzKTtcbiAgICB9XG59O1xuY29uc3QgbG9hZE90aGVyID0gKCkgPT4ge1xuICAgIGNvbnN0IGFkdmVydGlzaW5nU2VydmljZXMgPSBbXG4gICAgICAgIHJlbWFya2V0aW5nKHtcbiAgICAgICAgICAgIHNob3VsZFJ1bjogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5zd2l0Y2hlcy5yZW1hcmtldGluZyA/PyBmYWxzZSxcbiAgICAgICAgfSksXG4gICAgICAgIHBlcm11dGl2ZSh7XG4gICAgICAgICAgICBzaG91bGRSdW46IHdpbmRvdy5ndWFyZGlhbi5jb25maWcuc3dpdGNoZXMucGVybXV0aXZlID8/IGZhbHNlLFxuICAgICAgICB9KSxcbiAgICAgICAgaWFzLFxuICAgICAgICBpbml6aW8oeyBzaG91bGRSdW46IHdpbmRvdy5ndWFyZGlhbi5jb25maWcuc3dpdGNoZXMuaW5pemlvID8/IGZhbHNlIH0pLFxuICAgICAgICBhZG1pcmFsLFxuICAgIF0uZmlsdGVyKChfKSA9PiBfLnNob3VsZFJ1bik7XG4gICAgY29uc3QgcGVyZm9ybWFuY2VTZXJ2aWNlcyA9IFtcbiAgICAgICAgLy8gYS5rLmEgTmllbHNlbiBPbmxpbmUgLSBwcm92aWRlcyBtZWFzdXJlbWVudCBhbmQgYW5hbHlzaXMgb2Ygb25saW5lIGF1ZGllbmNlcyxcbiAgICAgICAgLy8gYWR2ZXJ0aXNpbmcsIHZpZGVvLCBjb25zdW1lci1nZW5lcmF0ZWQgbWVkaWEsIHdvcmQgb2YgbW91dGgsIGNvbW1lcmNlIGFuZCBjb25zdW1lciBiZWhhdmlvci5cbiAgICAgICAgaW1yV29ybGR3aWRlLCAvLyBvbmx5IGluIEFVICYgTlpcbiAgICAgICAgaW1yV29ybGR3aWRlTGVnYWN5LCAvLyBvbmx5IGluIEFVICYgTlpcbiAgICBdLmZpbHRlcigoXykgPT4gXy5zaG91bGRSdW4pO1xuICAgIHJldHVybiBpbnNlcnRTY3JpcHRzKGFkdmVydGlzaW5nU2VydmljZXMsIHBlcmZvcm1hbmNlU2VydmljZXMpO1xufTtcbmNvbnN0IGluaXQgPSBhc3luYyAoKSA9PiB7XG4gICAgaWYgKGNvbW1lcmNpYWxGZWF0dXJlcy50aGlyZFBhcnR5VGFncykge1xuICAgICAgICB2b2lkIGxvYWRPdGhlcigpO1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKHRydWUpO1xuICAgIH1cbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKGZhbHNlKTtcbn07XG5leHBvcnQgeyBpbml0IH07XG5leHBvcnQgY29uc3QgXyA9IHtcbiAgICBpbnNlcnRTY3JpcHRzLFxuICAgIGxvYWRPdGhlcixcbn07XG4iLCJpbXBvcnQgeyBhZFNpemVzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBBRF9MQUJFTF9IRUlHSFQgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2NvbnN0YW50cy9hZC1sYWJlbC1oZWlnaHQnO1xuaW1wb3J0IHsgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgZW1wdHlBZHZlcnQgfSBmcm9tICcuLi9ldmVudHMvZW1wdHktYWR2ZXJ0JztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCB7IGNyZWF0ZUFkU2xvdCB9IGZyb20gJy4uL2xpYi9jcmVhdGUtYWQtc2xvdCc7XG5pbXBvcnQgeyBnZXRCcmVha3BvaW50IH0gZnJvbSAnLi4vbGliL2RldGVjdC9kZXRlY3QtYnJlYWtwb2ludCc7XG5pbXBvcnQgeyBnZXRWaWV3cG9ydCB9IGZyb20gJy4uL2xpYi9kZXRlY3QvZGV0ZWN0LXZpZXdwb3J0JztcbmltcG9ydCB7IGdldEFkdmVydEJ5SWQgfSBmcm9tICcuLi9saWIvZGZwL2dldC1hZHZlcnQtYnktaWQnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vbGliL2Zhc3Rkb20tcHJvbWlzZSc7XG5pbXBvcnQgeyBmaWxsRHluYW1pY0FkU2xvdCB9IGZyb20gJy4vZmlsbC1keW5hbWljLWFkdmVydC1zbG90JztcbmNvbnN0IHRhbGxlc3RDb21tZW50QWQgPSBhZFNpemVzLm1wdS5oZWlnaHQgKyBBRF9MQUJFTF9IRUlHSFQ7XG5jb25zdCB0YWxsZXN0Q29tbWVudHNFeHBhbmRlZEFkID0gYWRTaXplcy5oYWxmUGFnZS5oZWlnaHQgKyBBRF9MQUJFTF9IRUlHSFQ7XG5jb25zdCBpbnNlcnRBZCA9IChhbmNob3IpID0+IHtcbiAgICBjb25zdCBzbG90ID0gY3JlYXRlQWRTbG90KCdjb21tZW50cy1leHBhbmRlZCcsIHtcbiAgICAgICAgY2xhc3NlczogJ2NvbW1lbnRzLWV4cGFuZGVkJyxcbiAgICB9KTtcbiAgICBjb25zdCBhZFNsb3RDb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBhZFNsb3RDb250YWluZXIuY2xhc3NOYW1lID0gJ2FkLXNsb3QtY29udGFpbmVyJztcbiAgICBhZFNsb3RDb250YWluZXIuc3R5bGUucG9zaXRpb24gPSAnc3RpY2t5JztcbiAgICBhZFNsb3RDb250YWluZXIuc3R5bGUudG9wID0gJzAnO1xuICAgIGFkU2xvdENvbnRhaW5lci5hcHBlbmRDaGlsZChzbG90KTtcbiAgICBjb25zdCBzdGlja3lDb250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBzdGlja3lDb250YWluZXIuc3R5bGUuZmxleEdyb3cgPSAnMSc7XG4gICAgc3RpY2t5Q29udGFpbmVyLmFwcGVuZENoaWxkKGFkU2xvdENvbnRhaW5lcik7XG4gICAgbG9nKCdjb21tZXJjaWFsJywgJ0luc2VydGluZyBjb21tZW50cy1leHBhbmRlZCBhZHZlcnQnKTtcbiAgICByZXR1cm4gZmFzdGRvbVxuICAgICAgICAubXV0YXRlKCgpID0+IHtcbiAgICAgICAgYW5jaG9yLmFwcGVuZENoaWxkKGFkU2xvdENvbnRhaW5lcik7XG4gICAgfSlcbiAgICAgICAgLnRoZW4oKCkgPT4gZmlsbER5bmFtaWNBZFNsb3Qoc2xvdCwgZmFsc2UpKTtcbn07XG5jb25zdCBpbnNlcnRBZE1vYmlsZSA9IChhbmNob3IsIGlkKSA9PiB7XG4gICAgY29uc3Qgc2xvdCA9IGNyZWF0ZUFkU2xvdCgnY29tbWVudHMtZXhwYW5kZWQnLCB7XG4gICAgICAgIG5hbWU6IGBjb21tZW50cy1leHBhbmRlZC0ke2lkfWAsXG4gICAgICAgIGNsYXNzZXM6ICdjb21tZW50cy1leHBhbmRlZCcsXG4gICAgfSk7XG4gICAgc2xvdC5zdHlsZS5taW5IZWlnaHQgPSBgJHthZFNpemVzLm1wdS5oZWlnaHQgKyBBRF9MQUJFTF9IRUlHSFR9cHhgO1xuICAgIGNvbnN0IGFkU2xvdENvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGFkU2xvdENvbnRhaW5lci5jbGFzc05hbWUgPSAnYWQtc2xvdC1jb250YWluZXInO1xuICAgIGFkU2xvdENvbnRhaW5lci5zdHlsZS53aWR0aCA9ICczMDBweCc7XG4gICAgYWRTbG90Q29udGFpbmVyLnN0eWxlLm1hcmdpbiA9ICcyMHB4IGF1dG8nO1xuICAgIGFkU2xvdENvbnRhaW5lci5hcHBlbmRDaGlsZChzbG90KTtcbiAgICBjb25zdCBsaXN0RWxlbWVudCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xpJyk7XG4gICAgbGlzdEVsZW1lbnQuYXBwZW5kQ2hpbGQoYWRTbG90Q29udGFpbmVyKTtcbiAgICBsb2coJ2NvbW1lcmNpYWwnLCBgSW5zZXJ0aW5nIG1vYmlsZSBjb21tZW50cy1leHBhbmRlZC0ke2lkfSBhZHZlcnRgKTtcbiAgICByZXR1cm4gZmFzdGRvbVxuICAgICAgICAubXV0YXRlKCgpID0+IHtcbiAgICAgICAgYW5jaG9yLmFmdGVyKGxpc3RFbGVtZW50KTtcbiAgICB9KVxuICAgICAgICAudGhlbigoKSA9PiBmaWxsRHluYW1pY0FkU2xvdChzbG90LCBmYWxzZSkpO1xufTtcbmNvbnN0IGdldFJpZ2h0Q29sdW1uID0gKCkgPT4ge1xuICAgIGNvbnN0IHNlbGVjdG9yID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5pc0RvdGNvbVJlbmRlcmluZ1xuICAgICAgICA/ICcuY29tbWVudHNSaWdodENvbHVtbidcbiAgICAgICAgOiAnLmpzLWRpc2N1c3Npb25fX2FkLXNsb3QnO1xuICAgIGNvbnN0IHJpZ2h0Q29sdW1uID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcihzZWxlY3Rvcik7XG4gICAgaWYgKCFyaWdodENvbHVtbilcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdDb3VsZCBub3QgZmluZCByaWdodCBjb2x1bW4uJyk7XG4gICAgcmV0dXJuIHJpZ2h0Q29sdW1uO1xufTtcbmNvbnN0IGdldENvbW1lbnRzQ29sdW1uID0gYXN5bmMgKCkgPT4ge1xuICAgIHJldHVybiBmYXN0ZG9tLm1lYXN1cmUoKCkgPT4ge1xuICAgICAgICBjb25zdCBjb21tZW50c0NvbHVtbiA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJ1tkYXRhLWNvbW1lcmNpYWwtaWQ9XCJjb21tZW50cy1jb2x1bW5cIl0nKTtcbiAgICAgICAgaWYgKCFjb21tZW50c0NvbHVtbilcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ29tbWVudHMgYXJlIG5vdCBleHBhbmRlZC4nKTtcbiAgICAgICAgcmV0dXJuIGNvbW1lbnRzQ29sdW1uO1xuICAgIH0pO1xufTtcbmNvbnN0IGlzRW5vdWdoU3BhY2VGb3JBZCA9IChyaWdodENvbHVtbk5vZGUpID0+IHtcbiAgICAvLyBPbmx5IGluc2VydCBhIHNlY29uZCBhZHZlcnQgaW50byB0aGUgcmlnaHQtaGFuZCBjb2x1bW4gaWYgdGhlcmUgaXMgZW5vdWdoIHNwYWNlLlxuICAgIC8vIFRoZXJlIGlzIGVub3VnaCBzcGFjZSBpZiB0aGUgcmlnaHQtaGFuZCBjb2x1bW4gaXMgbGFyZ2VyIHRoYW46XG4gICAgLy8gKHRoZSBsYXJnZXN0IHBvc3NpYmxlIGhlaWdodHMgb2YgYm90aCBhZHZlcnRzKSArICh0aGUgZ2FwIGJldHdlZW4gdGhlIHR3byBhZHZlcnRzKVxuICAgIGNvbnN0IG1pbkhlaWdodFRvUGxhY2VBZCA9IHRhbGxlc3RDb21tZW50QWQgKyB0YWxsZXN0Q29tbWVudHNFeHBhbmRlZEFkICsgd2luZG93LmlubmVySGVpZ2h0O1xuICAgIHJldHVybiByaWdodENvbHVtbk5vZGUub2Zmc2V0SGVpZ2h0ID49IG1pbkhlaWdodFRvUGxhY2VBZDtcbn07XG5jb25zdCBpc0Vub3VnaENvbW1lbnRzRm9yQWQgPSAoY29tbWVudHNDb2x1bW4pID0+IGNvbW1lbnRzQ29sdW1uLmNoaWxkRWxlbWVudENvdW50ID49IDU7XG5jb25zdCBjb21tZW50c0V4cGFuZGVkQWRzQWxyZWFkeUV4aXN0ID0gKCkgPT4ge1xuICAgIGNvbnN0IGNvbW1lbnRzRXhwYW5kZWRBZHMgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuYWQtc2xvdC0tY29tbWVudHMtZXhwYW5kZWQnKTtcbiAgICByZXR1cm4gY29tbWVudHNFeHBhbmRlZEFkcy5sZW5ndGggPiAwID8gdHJ1ZSA6IGZhbHNlO1xufTtcbmNvbnN0IHJlbW92ZU1vYmlsZUNvbW1lbnRzRXhwYW5kZWRBZHMgPSAoKSA9PiB7XG4gICAgY29uc3QgY3VycmVudEJyZWFrcG9pbnQgPSBnZXRCcmVha3BvaW50KGdldFZpZXdwb3J0KCkud2lkdGgpO1xuICAgIGlmIChjdXJyZW50QnJlYWtwb2ludCAhPT0gJ21vYmlsZScpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBjb25zdCBjb21tZW50c0V4cGFuZGVkQWRzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmFkLXNsb3QtLWNvbW1lbnRzLWV4cGFuZGVkJyk7XG4gICAgcmV0dXJuIGZhc3Rkb20ubXV0YXRlKCgpID0+IGNvbW1lbnRzRXhwYW5kZWRBZHMuZm9yRWFjaCgobm9kZSkgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBgUmVtb3ZpbmcgYWQgc2xvdDogJHtub2RlLmlkfWApO1xuICAgICAgICBjb25zdCBhZHZlcnQgPSBnZXRBZHZlcnRCeUlkKG5vZGUuaWQpO1xuICAgICAgICBpZiAoYWR2ZXJ0KSB7XG4gICAgICAgICAgICBlbXB0eUFkdmVydChhZHZlcnQpO1xuICAgICAgICB9XG4gICAgfSkpO1xufTtcbmNvbnN0IGhhbmRsZUNvbW1lbnRzTG9hZGVkRXZlbnQgPSAoKSA9PiB7XG4gICAgY29uc3QgcmlnaHRDb2x1bW5Ob2RlID0gZ2V0UmlnaHRDb2x1bW4oKTtcbiAgICBpZiAoaXNFbm91Z2hTcGFjZUZvckFkKHJpZ2h0Q29sdW1uTm9kZSkpIHtcbiAgICAgICAgdm9pZCBpbnNlcnRBZChyaWdodENvbHVtbk5vZGUpO1xuICAgIH1cbn07XG5jb25zdCBoYW5kbGVDb21tZW50c0xvYWRlZE1vYmlsZUV2ZW50ID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGNvbW1lbnRzQ29sdW1uID0gYXdhaXQgZ2V0Q29tbWVudHNDb2x1bW4oKTtcbiAgICAvLyBPbiBmcm9udGVuZC1yZW5kZXJlZCBwYWdlcywgdGhlcmUgaXMgYSBtZXJjaGFuZGlzaW5nLWhpZ2ggYWQgYmVsb3cgdGhlIGNvbW1lbnRzIGFkLlxuICAgIC8vIFdlIHdhbnQgYSBzdWZmaWNpZW50IGFtb3VudCBvZiBjb250ZW50IGJldHdlZW4gdGhlc2UgdHdvIGFkcy5cbiAgICBjb25zdCBpc0RjciA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcuaXNEb3Rjb21SZW5kZXJpbmc7XG4gICAgY29uc3QgbWluQ29tbWVudHNCZWxvd0FkID0gaXNEY3IgPyAxIDogMztcbiAgICBpZiAoaXNFbm91Z2hDb21tZW50c0ZvckFkKGNvbW1lbnRzQ29sdW1uKSAmJlxuICAgICAgICAhY29tbWVudHNFeHBhbmRlZEFkc0FscmVhZHlFeGlzdCgpKSB7XG4gICAgICAgIGxldCBjb3VudGVyID0gMDtcbiAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCBjb21tZW50c0NvbHVtbi5jaGlsZEVsZW1lbnRDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoY29tbWVudHNDb2x1bW4uY2hpbGRyZW5baV0gJiZcbiAgICAgICAgICAgICAgICAoaSAtIDMpICUgNSA9PT0gMCAmJiAvLyBUaGUgZm91cnRoIGNvbW1lbnQgYW5kIHRoZW4gZXZlcnkgZmlmdGggY29tbWVudFxuICAgICAgICAgICAgICAgIGkgKyBtaW5Db21tZW50c0JlbG93QWQgPCBjb21tZW50c0NvbHVtbi5jaGlsZEVsZW1lbnRDb3VudCkge1xuICAgICAgICAgICAgICAgIGNvdW50ZXIrKztcbiAgICAgICAgICAgICAgICBjb25zdCBjaGlsZEVsZW1lbnQgPSBjb21tZW50c0NvbHVtbi5jaGlsZHJlbltpXTtcbiAgICAgICAgICAgICAgICB2b2lkIGluc2VydEFkTW9iaWxlKGNoaWxkRWxlbWVudCwgY291bnRlcik7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG59O1xuZXhwb3J0IGNvbnN0IGluaXRDb21tZW50c0V4cGFuZGVkQWR2ZXJ0cyA9ICgpID0+IHtcbiAgICBpZiAoIWNvbW1lcmNpYWxGZWF0dXJlcy5jb21tZW50QWR2ZXJ0cykge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnQWR2ZXJ0cyBpbiBjb21tZW50cyBhcmUgZGlzYWJsZWQgaW4gY29tbWVyY2lhbEZlYXR1cmVzJyk7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgZG9jdW1lbnQuYWRkRXZlbnRMaXN0ZW5lcignY29tbWVudHMtbG9hZGVkJywgKCkgPT4ge1xuICAgICAgICBjb25zdCBjdXJyZW50QnJlYWtwb2ludCA9IGdldEJyZWFrcG9pbnQoZ2V0Vmlld3BvcnQoKS53aWR0aCk7XG4gICAgICAgIGlmIChjdXJyZW50QnJlYWtwb2ludCA9PT0gJ21vYmlsZScpIHtcbiAgICAgICAgICAgIHZvaWQgaGFuZGxlQ29tbWVudHNMb2FkZWRNb2JpbGVFdmVudCgpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgdm9pZCBoYW5kbGVDb21tZW50c0xvYWRlZEV2ZW50KCk7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICAvKipcbiAgICAgKiBJZiB0aGUgcGFnZSBvZiBjb21tZW50cyBpcyBjaGFuZ2VkLCBvciB0aGUgb3JkZXJpbmcgaXMgdXBkYXRlZCwgZXRjLFxuICAgICAqIHdlIG5lZWQgdG8gcmVtb3ZlIHRoZSBleGlzdGluZyBzbG90cyBhbmQgY3JlYXRlIG5ldyBzbG90cy5cbiAgICAgKi9cbiAgICBkb2N1bWVudC5hZGRFdmVudExpc3RlbmVyKCdjb21tZW50cy1zdGF0ZS1jaGFuZ2UnLCAoKSA9PiB7XG4gICAgICAgIHZvaWQgcmVtb3ZlTW9iaWxlQ29tbWVudHNFeHBhbmRlZEFkcygpO1xuICAgIH0pO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbn07XG4iLCJpbXBvcnQgeyBBRF9MQUJFTF9IRUlHSFQgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2NvbnN0YW50cy9pbmRleCc7XG5pbXBvcnQgeyBjb21tZXJjaWFsRmVhdHVyZXMgfSBmcm9tICcuLi9saWIvY29tbWVyY2lhbC1mZWF0dXJlcyc7XG5pbXBvcnQgeyBjcmVhdGVBZFNsb3QsIHdyYXBTbG90SW5Db250YWluZXIgfSBmcm9tICcuLi9saWIvY3JlYXRlLWFkLXNsb3QnO1xuaW1wb3J0IHsgZ2V0QnJlYWtwb2ludCB9IGZyb20gJy4uL2xpYi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuaW1wb3J0IHsgZ2V0Vmlld3BvcnQgfSBmcm9tICcuLi9saWIvZGV0ZWN0L2RldGVjdC12aWV3cG9ydCc7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi9saWIvZmFzdGRvbS1wcm9taXNlJztcbmltcG9ydCB7IGZpbGxEeW5hbWljQWRTbG90IH0gZnJvbSAnLi9maWxsLWR5bmFtaWMtYWR2ZXJ0LXNsb3QnO1xuY29uc3QgTEFSR0VTVF9BRF9TSVpFID0gNjAwOyAvLyBweCwgZG91YmxlIG1wdVxuY29uc3QgU1BBQ0lORyA9IDEwOyAvLyBweCwgYWJvdmUgYWRcbmNvbnN0IGluc2VydEZvb3RiYWxsUmlnaHRBZCA9IChhbmNob3IpID0+IHtcbiAgICBjb25zdCBzbG90ID0gY3JlYXRlQWRTbG90KCdmb290YmFsbC1yaWdodCcpO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IHdyYXBTbG90SW5Db250YWluZXIoc2xvdCwge1xuICAgICAgICBjbGFzc05hbWU6ICdhZC1zbG90LWNvbnRhaW5lciBmb290YmFsbC1yaWdodC1hZC1jb250YWluZXInLFxuICAgIH0pO1xuICAgIC8qKlxuICAgICAqIFRPRE86IE1vdmUgdGhlc2UgdG8gYSBjbGFzcyBpbiBmcm9udGVuZFxuICAgICAqL1xuICAgIGNvbnRhaW5lci5zdHlsZS5wb3NpdGlvbiA9ICdzdGlja3knO1xuICAgIGNvbnRhaW5lci5zdHlsZS50b3AgPSAnMCc7XG4gICAgY29udGFpbmVyLnN0eWxlLm1hcmdpblRvcCA9ICcxMHB4JztcbiAgICB2b2lkIGZhc3Rkb21cbiAgICAgICAgLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgIGFuY2hvci5zdHlsZS5oZWlnaHQgPSAnMTAwJSc7XG4gICAgICAgIGFuY2hvci5hcHBlbmRDaGlsZChjb250YWluZXIpO1xuICAgIH0pXG4gICAgICAgIC50aGVuKCgpID0+IGZpbGxEeW5hbWljQWRTbG90KHNsb3QsIGZhbHNlKSk7XG59O1xuLyoqXG4gKiBJbnNlcnRzIGFuIGFkdmVydCBvbiBjZXJ0YWluIGZvb3RiYWxsIGZpeHR1cmVzL3Jlc3VsdHMvdGFibGVzXG4gKiBwYWdlcyBpbiB0aGUgcmlnaHQgY29sdW1uLlxuICovXG5leHBvcnQgY29uc3QgaW5pdCA9ICgpID0+IHtcbiAgICBpZiAod2luZG93Lmd1YXJkaWFuLmNvbmZpZy5pc0RvdGNvbVJlbmRlcmluZykge1xuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG4gICAgfVxuICAgIGNvbnN0IGN1cnJlbnRCcmVha3BvaW50ID0gZ2V0QnJlYWtwb2ludChnZXRWaWV3cG9ydCgpLndpZHRoKTtcbiAgICBpZiAoY3VycmVudEJyZWFrcG9pbnQgIT09ICdkZXNrdG9wJyAmJiBjdXJyZW50QnJlYWtwb2ludCAhPT0gJ3dpZGUnKSB7XG4gICAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbiAgICB9XG4gICAgaWYgKCFjb21tZXJjaWFsRmVhdHVyZXMuZm9vdGJhbGxGaXh0dXJlc0FkdmVydHMpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBPbiBGb290YmFsbCBwYWdlcywgdGhpcyByaWdodC1oYW5kIGNvbHVtbiBleGlzdHMgaW4gdGhlIERPTSBidXQgZG9lcyBub3RcbiAgICAgKiBhcHBlYXIgdG8gYmUgdXNlZC4gQ2FuIHdlIHVzZSBpdCBmb3IgYW4gYWR2ZXJ0P1xuICAgICAqL1xuICAgIGNvbnN0IGFuY2hvciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5jb250ZW50X19zZWNvbmRhcnktY29sdW1uJyk7XG4gICAgY29uc3QgbWluU3BhY2VGb3JBZCA9IExBUkdFU1RfQURfU0laRSArIEFEX0xBQkVMX0hFSUdIVCArIFNQQUNJTkc7XG4gICAgaWYgKGFuY2hvciA9PT0gbnVsbCB8fFxuICAgICAgICAoYW5jaG9yLnBhcmVudEVsZW1lbnQ/Lm9mZnNldEhlaWdodCAmJlxuICAgICAgICAgICAgYW5jaG9yLnBhcmVudEVsZW1lbnQub2Zmc2V0SGVpZ2h0IDwgbWluU3BhY2VGb3JBZCkpIHtcbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH1cbiAgICBpbnNlcnRGb290YmFsbFJpZ2h0QWQoYW5jaG9yKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuIiwiaW1wb3J0IHsgY29tbWVyY2lhbEZlYXR1cmVzIH0gZnJvbSAnLi4vbGliL2NvbW1lcmNpYWwtZmVhdHVyZXMnO1xuaW1wb3J0IHsgY3JlYXRlQWRTbG90LCB3cmFwU2xvdEluQ29udGFpbmVyIH0gZnJvbSAnLi4vbGliL2NyZWF0ZS1hZC1zbG90JztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJy4uL2xpYi9mYXN0ZG9tLXByb21pc2UnO1xuLyoqXG4gKiBJbml0aWFsaXNlIG1lcmNoYW5kaXNpbmctaGlnaCBhZCBzbG90IG9uIEZyb250ZW5kIHJlbmRlcmVkIGNvbnRlbnRcbiAqXG4gKiBPbiBEQ1IsIHRoZXNlIGFkIHNsb3RzIGFyZSBzZXJ2ZXIgc2lkZSByZW5kZXJlZFxuICpcbiAqIFJldmlzaXQgd2hldGhlciB0aGlzIGNvZGUgaXMgbmVlZGVkIG9uY2UgZ2FsbGVyaWVzIGhhdmUgYmVlbiBtaWdyYXRlZCB0byBEQ1JcbiAqL1xuZXhwb3J0IGNvbnN0IGluaXQgPSAoKSA9PiB7XG4gICAgaWYgKGNvbW1lcmNpYWxGZWF0dXJlcy5oaWdoTWVyY2gpIHtcbiAgICAgICAgY29uc3QgYW5jaG9yU2VsZWN0b3IgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuY29tbWVudGFibGVcbiAgICAgICAgICAgID8gJyNjb21tZW50cyArIConXG4gICAgICAgICAgICA6ICcuY29udGVudC1mb290ZXIgPiA6Zmlyc3QtY2hpbGQnO1xuICAgICAgICBjb25zdCBhbmNob3IgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKGFuY2hvclNlbGVjdG9yKTtcbiAgICAgICAgY29uc3Qgc2xvdCA9IGNyZWF0ZUFkU2xvdCgnbWVyY2hhbmRpc2luZy1oaWdoJyk7XG4gICAgICAgIGNvbnN0IGNvbnRhaW5lciA9IHdyYXBTbG90SW5Db250YWluZXIoc2xvdCwge1xuICAgICAgICAgICAgY2xhc3NOYW1lOiAnZmMtY29udGFpbmVyIGZjLWNvbnRhaW5lci0tY29tbWVyY2lhbCcsXG4gICAgICAgIH0pO1xuICAgICAgICAvLyBSZW1vdmUgdGhpcyBvbmNlIG5ldyBgYWQtc2xvdC1jb250YWluZXItLWNlbnRyZS1zbG90YCBjbGFzcyBpcyBpbiBwbGFjZVxuICAgICAgICBjb250YWluZXIuc3R5bGUuZGlzcGxheSA9ICdmbGV4JztcbiAgICAgICAgY29udGFpbmVyLnN0eWxlLmp1c3RpZnlDb250ZW50ID0gJ2NlbnRlcic7XG4gICAgICAgIC8vIFxcUmVtb3ZlIHRoaXNcbiAgICAgICAgcmV0dXJuIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChhbmNob3I/LnBhcmVudE5vZGUpIHtcbiAgICAgICAgICAgICAgICBhbmNob3IucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoY29udGFpbmVyLCBhbmNob3IpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xufTtcbiIsImltcG9ydCB7IGNyZWF0ZUFkU2xvdCB9IGZyb20gJy4uL2xpYi9jcmVhdGUtYWQtc2xvdCc7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi9saWIvZmFzdGRvbS1wcm9taXNlJztcbmltcG9ydCB7IHNob3VsZEluY2x1ZGVNb2JpbGVTdGlja3kgfSBmcm9tICcuLi9saWIvaGVhZGVyLWJpZGRpbmcvdXRpbHMnO1xuaW1wb3J0IHsgZmlsbER5bmFtaWNBZFNsb3QgfSBmcm9tICcuL2ZpbGwtZHluYW1pYy1hZHZlcnQtc2xvdCc7XG5jb25zdCBjcmVhdGVBZFdyYXBwZXJDbGFzc2ljID0gKCkgPT4ge1xuICAgIGNvbnN0IHdyYXBwZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICB3cmFwcGVyLmNsYXNzTmFtZSA9ICdtb2JpbGVzdGlja3ktY29udGFpbmVyJztcbiAgICBjb25zdCBhZFNsb3QgPSBjcmVhdGVBZFNsb3QoJ21vYmlsZS1zdGlja3knLCB7fSk7XG4gICAgd3JhcHBlci5hcHBlbmRDaGlsZChhZFNsb3QpO1xuICAgIHJldHVybiB3cmFwcGVyO1xufTtcbmNvbnN0IGNyZWF0ZUFkV3JhcHBlckRDUiA9ICgpID0+IHtcbiAgICBjb25zdCB3cmFwcGVyID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLm1vYmlsZXN0aWNreS1jb250YWluZXInKTtcbiAgICBpZiAod3JhcHBlcikge1xuICAgICAgICBjb25zdCBhZFNsb3QgPSBjcmVhdGVBZFNsb3QoJ21vYmlsZS1zdGlja3knLCB7fSk7XG4gICAgICAgIHdyYXBwZXIuYXBwZW5kQ2hpbGQoYWRTbG90KTtcbiAgICB9XG4gICAgcmV0dXJuIHdyYXBwZXI7XG59O1xuY29uc3QgY3JlYXRlQWRXcmFwcGVyID0gKCkgPT4ge1xuICAgIGlmICghd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5pc0RvdGNvbVJlbmRlcmluZykge1xuICAgICAgICByZXR1cm4gY3JlYXRlQWRXcmFwcGVyQ2xhc3NpYygpO1xuICAgIH1cbiAgICByZXR1cm4gY3JlYXRlQWRXcmFwcGVyRENSKCk7XG59O1xuLyoqXG4gKiBJbml0aWFsaXNlIG1vYmlsZSBzdGlja3kgYWQgc2xvdFxuICogQHJldHVybnMgUHJvbWlzZVxuICovXG5leHBvcnQgY29uc3QgaW5pdCA9ICgpID0+IHtcbiAgICBpZiAoc2hvdWxkSW5jbHVkZU1vYmlsZVN0aWNreSgpKSB7XG4gICAgICAgIGNvbnN0IG1vYmlsZVN0aWNreVdyYXBwZXIgPSBjcmVhdGVBZFdyYXBwZXIoKTtcbiAgICAgICAgcmV0dXJuIGZhc3Rkb21cbiAgICAgICAgICAgIC5tdXRhdGUoKCkgPT4ge1xuICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bm5lY2Vzc2FyeS1jb25kaXRpb24gLS0gSXMgYm9keSByZWFsbHkgYWx3YXlzIGRlZmluZWQ/XG4gICAgICAgICAgICBpZiAoZG9jdW1lbnQuYm9keSAmJiBtb2JpbGVTdGlja3lXcmFwcGVyKSB7XG4gICAgICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChtb2JpbGVTdGlja3lXcmFwcGVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSlcbiAgICAgICAgICAgIC50aGVuKCgpID0+IHtcbiAgICAgICAgICAgIGlmIChtb2JpbGVTdGlja3lXcmFwcGVyKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgbW9iaWxlU3RpY2t5QWRTbG90ID0gbW9iaWxlU3RpY2t5V3JhcHBlci5xdWVyeVNlbGVjdG9yKCcjZGZwLWFkLS1tb2JpbGUtc3RpY2t5Jyk7XG4gICAgICAgICAgICAgICAgaWYgKG1vYmlsZVN0aWNreUFkU2xvdCkge1xuICAgICAgICAgICAgICAgICAgICB2b2lkIGZpbGxEeW5hbWljQWRTbG90KG1vYmlsZVN0aWNreUFkU2xvdCwgdHJ1ZSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xufTtcbiIsImltcG9ydCB7IGFkU2l6ZXMgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2FkLXNpemVzJztcbmltcG9ydCB7IGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uLy4uL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCB7IGNyZWF0ZUFkU2xvdCB9IGZyb20gJy4uLy4uL2xpYi9jcmVhdGUtYWQtc2xvdCc7XG5pbXBvcnQgeyBnZXRDdXJyZW50QnJlYWtwb2ludCB9IGZyb20gJy4uLy4uL2xpYi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vLi4vbGliL2Zhc3Rkb20tcHJvbWlzZSc7XG5pbXBvcnQgeyBmaWxsRHluYW1pY0FkU2xvdCB9IGZyb20gJy4uL2ZpbGwtZHluYW1pYy1hZHZlcnQtc2xvdCc7XG5pbXBvcnQgeyBzcGFjZUZpbGxlciB9IGZyb20gJy4vc3BhY2UtZmlsbGVyJztcbi8qKlxuICogTWF4aW11bSBudW1iZXIgb2YgaW5saW5lIGFkcyB0byBkaXNwbGF5IG9uIHRoZSBwYWdlXG4gKi9cbmNvbnN0IE1BWF9BRFMgPSA4O1xuLyoqXG4gKiBNdWx0aXBsaWVyIG9mIHNjcmVlbiBoZWlnaHQgdGhhdCBkZXRlcm1pbmVzIHRoZSBtaW5pbXVtIGRpc3RhbmNlIGJldHdlZW4gYW55IHR3byBhZHNcbiAqL1xuY29uc3QgQURfR0FQX01VTFRJUExJRVIgPSAxLjU7XG5sZXQgQURfQ09VTlRFUiA9IDA7XG5jb25zdCBnZXRTbG90TmFtZSA9IChpc01vYmlsZSwgc2xvdENvdW50ZXIpID0+IHtcbiAgICBpZiAoaXNNb2JpbGUpIHtcbiAgICAgICAgcmV0dXJuIHNsb3RDb3VudGVyID09PSAwID8gJ3RvcC1hYm92ZS1uYXYnIDogYGlubGluZSR7c2xvdENvdW50ZXJ9YDtcbiAgICB9XG4gICAgcmV0dXJuIGBpbmxpbmUke3Nsb3RDb3VudGVyICsgMX1gO1xufTtcbmNvbnN0IGluc2VydEFkQXRQYXJhID0gKHBhcmEpID0+IHtcbiAgICBjb25zdCBpc01vYmlsZSA9IGdldEN1cnJlbnRCcmVha3BvaW50KCkgPT09ICdtb2JpbGUnO1xuICAgIGNvbnN0IGNvbnRhaW5lciA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpO1xuICAgIGNvbnRhaW5lci5jbGFzc05hbWUgPSBgYWQtc2xvdC1jb250YWluZXIgYWQtc2xvdC0ke2lzTW9iaWxlID8gJ21vYmlsZScgOiAnZGVza3RvcCd9YDtcbiAgICBjb25zdCBhZCA9IGNyZWF0ZUFkU2xvdCgnaW5saW5lJywge1xuICAgICAgICBuYW1lOiBnZXRTbG90TmFtZShpc01vYmlsZSwgQURfQ09VTlRFUiksXG4gICAgICAgIGNsYXNzZXM6IGBsaXZlYmxvZy1pbmxpbmUke2lzTW9iaWxlID8gJy0tbW9iaWxlJyA6ICcnfWAsXG4gICAgfSk7XG4gICAgY29udGFpbmVyLmFwcGVuZENoaWxkKGFkKTtcbiAgICByZXR1cm4gZmFzdGRvbVxuICAgICAgICAubXV0YXRlKCgpID0+IHtcbiAgICAgICAgaWYgKHBhcmEucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgLyogYWRzIGFyZSBpbnNlcnRlZCBhZnRlciB0aGUgYmxvY2sgb24gbGl2ZWJsb2dzICovXG4gICAgICAgICAgICBwYXJhLnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGNvbnRhaW5lciwgcGFyYS5uZXh0U2libGluZyk7XG4gICAgICAgIH1cbiAgICB9KVxuICAgICAgICAudGhlbihhc3luYyAoKSA9PiBmaWxsRHluYW1pY0FkU2xvdChhZCwgZmFsc2UsIHtcbiAgICAgICAgcGhhYmxldDogW1xuICAgICAgICAgICAgYWRTaXplcy5vdXRzdHJlYW1EZXNrdG9wLFxuICAgICAgICAgICAgYWRTaXplcy5vdXRzdHJlYW1Hb29nbGVEZXNrdG9wLFxuICAgICAgICBdLFxuICAgICAgICBkZXNrdG9wOiBbXG4gICAgICAgICAgICBhZFNpemVzLm91dHN0cmVhbURlc2t0b3AsXG4gICAgICAgICAgICBhZFNpemVzLm91dHN0cmVhbUdvb2dsZURlc2t0b3AsXG4gICAgICAgIF0sXG4gICAgfSkpO1xufTtcbmNvbnN0IGluc2VydEFkcyA9IGFzeW5jIChwYXJhcykgPT4ge1xuICAgIGNvbnN0IGZhc3Rkb21Qcm9taXNlcyA9IFtdO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcGFyYXMubGVuZ3RoICYmIEFEX0NPVU5URVIgPCBNQVhfQURTOyBpICs9IDEpIHtcbiAgICAgICAgY29uc3QgcGFyYSA9IHBhcmFzW2ldO1xuICAgICAgICBpZiAocGFyYT8ucGFyZW50Tm9kZSkge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gaW5zZXJ0QWRBdFBhcmEocGFyYSk7XG4gICAgICAgICAgICBmYXN0ZG9tUHJvbWlzZXMucHVzaChyZXN1bHQpO1xuICAgICAgICAgICAgQURfQ09VTlRFUiArPSAxO1xuICAgICAgICB9XG4gICAgfVxuICAgIGF3YWl0IFByb21pc2UuYWxsKGZhc3Rkb21Qcm9taXNlcyk7XG59O1xuY29uc3QgZmlsbFNwYWNlID0gKHJ1bGVzKSA9PiB7XG4gICAgY29uc3Qgb3B0aW9ucyA9IHsgcGFzczogJ2lubGluZTEnIH07XG4gICAgcmV0dXJuIHNwYWNlRmlsbGVyLmZpbGxTcGFjZShydWxlcywgaW5zZXJ0QWRzLCBvcHRpb25zKTtcbn07XG5jb25zdCBzaG91bGRJbnNlcnRBZCA9IChibG9ja0Fib3ZlQWQsIGNhbmRpZGF0ZUJsb2NrLCB3aW5kb3dIZWlnaHQpID0+IE1hdGguYWJzKGJsb2NrQWJvdmVBZC5ib3R0b20gLSBjYW5kaWRhdGVCbG9jay5ib3R0b20pID5cbiAgICB3aW5kb3dIZWlnaHQgKiBBRF9HQVBfTVVMVElQTElFUjtcbmNvbnN0IGdldFNwYWNlRmlsbGVyUnVsZXMgPSAoc3RhcnRCbG9jaywgd2luZG93SGVpZ2h0KSA9PiB7XG4gICAgLy8gVGhpcyBpcyBhbHdheXMgdGhlIGNvbnRlbnQgYmxvY2sgYWJvdmUgdGhlIGhpZ2hlc3QgaW5saW5lIGFkIHNsb3Qgb24gdGhlIHBhZ2UuXG4gICAgLy8gV2hlbiBhIG5ldyBhZCBzbG90IGlzIGluc2VydGVkLCB0aGlzIHdpbGwgYmVjb21lIHRoZSBmaXJzdCBjb250ZW50IGJsb2NrIGFib3ZlIGl0LlxuICAgIGxldCBwcmV2U2xvdDtcbiAgICBjb25zdCBmaWx0ZXJTbG90ID0gKHNsb3QpID0+IHtcbiAgICAgICAgaWYgKCFwcmV2U2xvdCkge1xuICAgICAgICAgICAgcHJldlNsb3QgPSBzbG90O1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChzaG91bGRJbnNlcnRBZChwcmV2U2xvdCwgc2xvdCwgd2luZG93SGVpZ2h0KSkge1xuICAgICAgICAgICAgcHJldlNsb3QgPSBzbG90O1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH07XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYm9keVNlbGVjdG9yOiAnLmpzLWxpdmVibG9nLWJvZHknLFxuICAgICAgICBjYW5kaWRhdGVTZWxlY3RvcjogJzpzY29wZSA+IC5ibG9jaycsXG4gICAgICAgIGZyb21Cb3R0b206IHRydWUsXG4gICAgICAgIHN0YXJ0QXQ6IHN0YXJ0QmxvY2ssXG4gICAgICAgIGFic29sdXRlTWluRGlzdGFuY2VGcm9tVG9wOiAwLFxuICAgICAgICBtaW5EaXN0YW5jZUZyb21Ub3A6IDAsXG4gICAgICAgIG1pbkRpc3RhbmNlRnJvbUJvdHRvbTogMCxcbiAgICAgICAgY2xlYXJDb250ZW50TWV0YTogMCxcbiAgICAgICAgb3Bwb25lbnRTZWxlY3RvclJ1bGVzOiB7fSxcbiAgICAgICAgZmlsdGVyOiBmaWx0ZXJTbG90LFxuICAgIH07XG59O1xuLyoqXG4gKiBSZWN1cnNpdmVseSBsb29rcyBhdCB0aGUgbmV4dCBoaWdoZXN0IGVsZW1lbnRcbiAqIGluIHRoZSBwYWdlIHVudGlsIHdlIGZpbmQgYSBjb250ZW50IGJsb2NrLlxuICpcbiAqIFdlIGNhbm5vdCBiZSBzdXJlIHRoYXQgdGhlIGVsZW1lbnQgYWJvdmUgdGhlIGFkIHNsb3QgaXMgYSBjb250ZW50XG4gKiBibG9jaywgYXMgdGhlcmUgbWF5IGJlIG90aGVyIHR5cGVzIG9mIGVsZW1lbnRzIGluc2VydGVkIGludG8gdGhlIHBhZ2UuXG4gKi9cbmNvbnN0IGdldEZpcnN0Q29udGVudEJsb2NrQWJvdmVBZCA9IGFzeW5jICh0b3BBZHZlcnQpID0+IHtcbiAgICBjb25zdCBwcmV2RWxlbWVudCA9IHRvcEFkdmVydC5wcmV2aW91c0VsZW1lbnRTaWJsaW5nO1xuICAgIGlmIChwcmV2RWxlbWVudCA9PT0gbnVsbClcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgaWYgKHByZXZFbGVtZW50LmNsYXNzTGlzdC5jb250YWlucygnYmxvY2snKSkge1xuICAgICAgICByZXR1cm4gcHJldkVsZW1lbnQ7XG4gICAgfVxuICAgIHJldHVybiBnZXRGaXJzdENvbnRlbnRCbG9ja0Fib3ZlQWQocHJldkVsZW1lbnQpO1xufTtcbmNvbnN0IGdldExvd2VzdENvbnRlbnRCbG9jayA9IGFzeW5jICgpID0+IHtcbiAgICByZXR1cm4gZmFzdGRvbS5tZWFzdXJlKCgpID0+IHtcbiAgICAgICAgY29uc3QgYWxsQmxvY2tzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbCgnLmpzLWxpdmVibG9nLWJvZHkgPiAuYmxvY2snKTtcbiAgICAgICAgcmV0dXJuIGFsbEJsb2Nrc1thbGxCbG9ja3MubGVuZ3RoIC0gMV0gPz8gbnVsbDtcbiAgICB9KTtcbn07XG4vKipcbiAqIEZpbmRzIHRoZSBjb250ZW50IGJsb2NrIHRvIHN0YXJ0IHdpdGggd2hlbiB1c2luZyBTcGFjZWZpbmRlci5cbiAqXG4gKiBTcGFjZWZpbmRlciB3aWxsIGl0ZXJhdGUgdGhyb3VnaCBibG9ja3MgbG9va2luZyBmb3Igc3BhY2VzIHRvXG4gKiBpbnNlcnQgYWRzLCBzbyB3ZSBuZWVkIHRvIHRlbGwgaXQgd2hlcmUgdG8gc3RhcnQuXG4gKi9cbmNvbnN0IGdldFN0YXJ0aW5nQ29udGVudEJsb2NrID0gYXN5bmMgKHNsb3RTZWxlY3RvcikgPT4ge1xuICAgIGNvbnN0IHRvcEFkdmVydCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoYC5qcy1saXZlYmxvZy1ib2R5ID4gJHtzbG90U2VsZWN0b3J9YCk7XG4gICAgaWYgKHRvcEFkdmVydCA9PT0gbnVsbCkge1xuICAgICAgICByZXR1cm4gYXdhaXQgZ2V0TG93ZXN0Q29udGVudEJsb2NrKCk7XG4gICAgfVxuICAgIHJldHVybiBnZXRGaXJzdENvbnRlbnRCbG9ja0Fib3ZlQWQodG9wQWR2ZXJ0KTtcbn07XG5jb25zdCBsb29rRm9yU3BhY2VzRm9yQWRTbG90cyA9IGFzeW5jICgpID0+IHtcbiAgICBjb25zdCBpc01vYmlsZSA9IGdldEN1cnJlbnRCcmVha3BvaW50KCkgPT09ICdtb2JpbGUnO1xuICAgIGNvbnN0IHNsb3RTZWxlY3RvciA9IGAuYWQtc2xvdC1jb250YWluZXIuYWQtc2xvdC0ke2lzTW9iaWxlID8gJ21vYmlsZScgOiAnZGVza3RvcCd9YDtcbiAgICByZXR1cm4gZmFzdGRvbVxuICAgICAgICAubWVhc3VyZSgoKSA9PiB7XG4gICAgICAgIGNvbnN0IG51bVNsb3RzID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvckFsbChzbG90U2VsZWN0b3IpLmxlbmd0aDtcbiAgICAgICAgaWYgKG51bVNsb3RzID49IE1BWF9BRFMpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcignQ2Fubm90IGluc2VydCBhbnkgbW9yZSBpbmxpbmUgYWRzLiBBdCBhZCBzbG90IGxpbWl0LicpO1xuICAgICAgICB9XG4gICAgICAgIEFEX0NPVU5URVIgPSBudW1TbG90cztcbiAgICB9KVxuICAgICAgICAudGhlbihhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHN0YXJ0Q29udGVudEJsb2NrID0gKGF3YWl0IGdldFN0YXJ0aW5nQ29udGVudEJsb2NrKHNsb3RTZWxlY3RvcikpO1xuICAgICAgICBpZiAoIXN0YXJ0Q29udGVudEJsb2NrKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0Nhbm5vdCBpbnNlcnQgbmV3IGlubGluZSBhZHMuIENhbm5vdCBmaW5kIGEgY29udGVudCBibG9jayB0byBzdGFydCBzZWFyY2hpbmcnKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhcnRDb250ZW50QmxvY2s7XG4gICAgfSlcbiAgICAgICAgLnRoZW4oKHN0YXJ0Q29udGVudEJsb2NrKSA9PiB7XG4gICAgICAgIHJldHVybiBmYXN0ZG9tXG4gICAgICAgICAgICAubWVhc3VyZSgoKSA9PiBkb2N1bWVudC5kb2N1bWVudEVsZW1lbnQuY2xpZW50SGVpZ2h0KVxuICAgICAgICAgICAgLnRoZW4oKHdpbmRvd0hlaWdodCkgPT4gZ2V0U3BhY2VGaWxsZXJSdWxlcyhzdGFydENvbnRlbnRCbG9jaywgd2luZG93SGVpZ2h0KSlcbiAgICAgICAgICAgIC50aGVuKGZpbGxTcGFjZSk7XG4gICAgfSlcbiAgICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBlcnJvcik7XG4gICAgfSk7XG59O1xuY29uc3Qgc3RhcnRMaXN0ZW5pbmcgPSAoKSA9PiB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lIC0tIGNpcmN1bGFyIHJlZmVyZW5jZVxuICAgIGRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoJ2xpdmVibG9nOmJsb2Nrcy11cGRhdGVkJywgb25VcGRhdGUpO1xufTtcbmNvbnN0IHN0b3BMaXN0ZW5pbmcgPSAoKSA9PiB7XG4gICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLXVzZS1iZWZvcmUtZGVmaW5lIC0tIGNpcmN1bGFyIHJlZmVyZW5jZVxuICAgIGRvY3VtZW50LnJlbW92ZUV2ZW50TGlzdGVuZXIoJ2xpdmVibG9nOmJsb2Nrcy11cGRhdGVkJywgb25VcGRhdGUpO1xufTtcbmNvbnN0IG9uVXBkYXRlID0gKCkgPT4ge1xuICAgIHN0b3BMaXN0ZW5pbmcoKTtcbiAgICB2b2lkIGxvb2tGb3JTcGFjZXNGb3JBZFNsb3RzKCk7XG59O1xuLyoqXG4gKiBJbnNlcnRzIGlubGluZSBhZCBzbG90cyBiZXR3ZWVuIG5ldyBjb250ZW50XG4gKiBibG9ja3Mgd2hlbiB0aGV5IGFyZSBwdXNoZWQgdG8gdGhlIHBhZ2UuXG4gKi9cbmV4cG9ydCBjb25zdCBpbml0ID0gKCkgPT4ge1xuICAgIGlmIChjb21tZXJjaWFsRmVhdHVyZXMubGl2ZWJsb2dBZHZlcnRzKSB7XG4gICAgICAgIHZvaWQgc3RhcnRMaXN0ZW5pbmcoKTtcbiAgICB9XG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xufTtcbmV4cG9ydCBjb25zdCBfID0ge1xuICAgIGdldEZpcnN0Q29udGVudEJsb2NrQWJvdmVBZCxcbiAgICBnZXRMb3dlc3RDb250ZW50QmxvY2ssXG4gICAgZ2V0U2xvdE5hbWUsXG4gICAgZ2V0U3RhcnRpbmdDb250ZW50QmxvY2ssXG59O1xuIiwiLyoqXG4gKiBMb2FkIEFtYXpvbiBBOSBsaWJyYXJ5IGFzIHtAbGluayBodHRwczovL2Ftcy5hbWF6b24uY29tL3dlYnB1Ymxpc2hlci91YW0vZG9jcy93ZWItaW50ZWdyYXRpb24tZG9jdW1lbnRhdGlvbi9pbnRlZ3JhdGlvbi1ndWlkZS9qYXZhc2NyaXB0LWd1aWRlL2Rpc3BsYXkuaHRtbCBkZXNjcmliZWQgaGVyZX1cbiAqL1xuZXhwb3J0IGNvbnN0IGE5QXBzdGFnID0gKCkgPT4ge1xuICAgIChmdW5jdGlvbiAoYTksIGEsIHAsIHMsIHQsIEEsIGcpIHtcbiAgICAgICAgaWYgKGFbYTldKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBmdW5jdGlvbiBxKGMsIHIpIHtcbiAgICAgICAgICAgIGFbYTldLl9RLnB1c2goW2MsIHJdKTtcbiAgICAgICAgfVxuICAgICAgICBhW2E5XSA9IHtcbiAgICAgICAgICAgIGluaXQoKSB7XG4gICAgICAgICAgICAgICAgcSgnaScsIGFyZ3VtZW50cyk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgZmV0Y2hCaWRzKCkge1xuICAgICAgICAgICAgICAgIHEoJ2YnLCBhcmd1bWVudHMpO1xuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIHNldERpc3BsYXlCaWRzKCkgeyB9LFxuICAgICAgICAgICAgdGFyZ2V0aW5nS2V5cygpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gW107XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgX1E6IFtdLFxuICAgICAgICB9O1xuICAgICAgICBBID0gcC5jcmVhdGVFbGVtZW50KHMpO1xuICAgICAgICBBLmFzeW5jID0gITA7XG4gICAgICAgIEEuc3JjID0gdDtcbiAgICAgICAgZyA9IHAuZ2V0RWxlbWVudHNCeVRhZ05hbWUocylbMF07XG4gICAgICAgIGcucGFyZW50Tm9kZS5pbnNlcnRCZWZvcmUoQSwgZyk7XG4gICAgfSkoJ2Fwc3RhZycsIHdpbmRvdywgZG9jdW1lbnQsICdzY3JpcHQnLCAnLy9jLmFtYXpvbi1hZHN5c3RlbS5jb20vYWF4Mi9hcHN0YWcuanMnKTtcbn07XG4iLCJpbXBvcnQgeyBieXBhc3NDb21tZXJjaWFsTWV0cmljc1NhbXBsaW5nIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZSc7XG5pbXBvcnQgeyBFdmVudFRpbWVyIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9ldmVudC10aW1lcic7XG5pbXBvcnQgeyBsb2FkU2NyaXB0LCBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyByZWZyZXNoQWR2ZXJ0IH0gZnJvbSAnLi4vLi4vZGlzcGxheS9sb2FkLWFkdmVydCc7XG5pbXBvcnQgeyBnZXRBZHZlcnRCeUlkIH0gZnJvbSAnLi4vZGZwL2dldC1hZHZlcnQtYnktaWQnO1xuaW1wb3J0IHsgc3RyaXBEZnBBZFByZWZpeEZyb20gfSBmcm9tICcuLi9oZWFkZXItYmlkZGluZy91dGlscyc7XG5jb25zdCBlcnJvckhhbmRsZXIgPSAoZXJyb3IpID0+IHtcbiAgICAvLyBMb29rcyBsaWtlIHNvbWUgcGx1Z2lucyBibG9jayBhZC12ZXJpZmljYXRpb25cbiAgICAvLyBBdm9pZCBiYXJyYWdpbmcgU2VudHJ5IHdpdGggZXJyb3JzIGZyb20gdGhlc2UgcGFnZXZpZXdzXG4gICAgbG9nKCdjb21tZXJjaWFsJywgJ0ZhaWxlZCB0byBsb2FkIENvbmZpYW50OicsIGVycm9yKTtcbn07XG5jb25zdCBjb25maWFudFJlZnJlc2hlZFNsb3RzID0gW107XG5jb25zdCBtYXliZVJlZnJlc2hCbG9ja2VkU2xvdE9uY2UgPSAoYmxvY2tpbmdUeXBlLCBibG9ja2luZ0lkLCBpc0Jsb2NrZWQsIHdyYXBwZXJJZCwgdGFnSWQsIGltcHJlc3Npb25zRGF0YSkgPT4ge1xuICAgIGNvbnN0IHByZWJpZFNsb3RFbGVtZW50SWQgPSBpbXByZXNzaW9uc0RhdGE/LnByZWJpZD8ucztcbiAgICBjb25zdCBkZnBTbG90RWxlbWVudElkID0gaW1wcmVzc2lvbnNEYXRhPy5kZnA/LnM7XG4gICAgY29uc3QgYmxvY2tlZFNsb3RQYXRoID0gcHJlYmlkU2xvdEVsZW1lbnRJZCA/PyBkZnBTbG90RWxlbWVudElkO1xuICAgIGxvZygnY29tbWVyY2lhbCcsIGAke2lzQmxvY2tlZCA/ICfwn5qrIEJsb2NrZWQnIDogJ/CfmqggU2NyZWVuZWQnfSBiYWQgYWQgd2l0aCBDb25maWFudGAsIHtcbiAgICAgICAgYmxvY2tlZFNsb3RQYXRoLFxuICAgICAgICBibG9ja2luZ1R5cGUsXG4gICAgICAgIGJsb2NraW5nSWQsXG4gICAgICAgIHdyYXBwZXJJZCxcbiAgICAgICAgdGFnSWQsXG4gICAgfSk7XG4gICAgLy8gZG9u4oCZdCBydW4gdGhlIGxvZ2ljIGlmIHRoZSBhZCBpcyBvbmx5IHNjcmVlbmVkXG4gICAgaWYgKCFpc0Jsb2NrZWQgfHwgIWJsb2NrZWRTbG90UGF0aClcbiAgICAgICAgcmV0dXJuO1xuICAgIGNvbnN0IGFkdmVydCA9IGdldEFkdmVydEJ5SWQoYmxvY2tlZFNsb3RQYXRoKTtcbiAgICBpZiAoIWFkdmVydClcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBObyBzbG90IGZvdW5kIGZvciAke2Jsb2NrZWRTbG90UGF0aH1gKTtcbiAgICBjb25zdCBldmVudFRpbWVyID0gRXZlbnRUaW1lci5nZXQoKTtcbiAgICBldmVudFRpbWVyLm1hcmsoYCR7c3RyaXBEZnBBZFByZWZpeEZyb20oYWR2ZXJ0LmlkKX0tYmxvY2tlZEJ5Q29uZmlhbnRgKTtcbiAgICB2b2lkIGJ5cGFzc0NvbW1lcmNpYWxNZXRyaWNzU2FtcGxpbmcoKTtcbiAgICBhZHZlcnQuc2xvdC5zZXRUYXJnZXRpbmcoJ2NvbmZpYW50JywgU3RyaW5nKGJsb2NraW5nVHlwZSkpO1xuICAgIC8vIGlmIHRoZSBzbG90IGhhcyBhbHJlYWR5IGJlZW4gcmVmcmVzaGVkLCBkb27igJl0IGRvIGFueXRoaW5nXG4gICAgaWYgKGNvbmZpYW50UmVmcmVzaGVkU2xvdHMuaW5jbHVkZXMoYmxvY2tlZFNsb3RQYXRoKSlcbiAgICAgICAgcmV0dXJuO1xuICAgIC8vIHJlZnJlc2ggdGhlIGJsb2NrZWQgc2xvdCB0byBnZXQgbmV3IGFkXG4gICAgcmVmcmVzaEFkdmVydChhZHZlcnQpO1xuICAgIC8vIG1hcmsgaXQgYXMgcmVmcmVzaGVkIHNvIGl0IHdvbuKAmXQgcmVmcmVzaCBtdWx0aXBsZSB0aW1lXG4gICAgY29uZmlhbnRSZWZyZXNoZWRTbG90cy5wdXNoKGJsb2NrZWRTbG90UGF0aCk7XG59O1xuLyoqXG4gKiBJbml0aWFsaXNlIENvbmZpYW50IC0gYmxvY2sgYmFkIGFkc1xuICogaHR0cHM6Ly93d3cuY29uZmlhbnQuY29tL3NvbHV0aW9ucy9xdWFsaXR5XG4gKiBAcmV0dXJucyBQcm9taXNlXG4gKi9cbmV4cG9ydCBjb25zdCBpbml0ID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGhvc3QgPSAnY2RuLmNvbmZpYW50LWludGVncmF0aW9ucy5uZXQnO1xuICAgIGNvbnN0IGlkID0gJzdvRGdpVHNxODhVUzRyckJHMF9OeHBhZmtyZyc7XG4gICAgY29uc3QgcmVtb3RlU2NyaXB0VXJsID0gYC8vJHtob3N0fS8ke2lkfS9ncHRfYW5kX3ByZWJpZC9jb25maWcuanNgO1xuICAgIGlmICh3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLmNvbmZpYW50QWRWZXJpZmljYXRpb24pIHtcbiAgICAgICAgYXdhaXQgbG9hZFNjcmlwdChyZW1vdGVTY3JpcHRVcmwsIHtcbiAgICAgICAgICAgIGFzeW5jOiB0cnVlLFxuICAgICAgICB9KS5jYXRjaChlcnJvckhhbmRsZXIpO1xuICAgICAgICBpZiAoIXdpbmRvdy5jb25maWFudD8uc2V0dGluZ3MpXG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIGlmICh3aW5kb3cubG9jYXRpb24uaGFzaCA9PT0gJyNjb25maWFudERldk1vZGUnKSB7XG4gICAgICAgICAgICB3aW5kb3cuY29uZmlhbnQuc2V0dGluZ3MuZGV2TW9kZSA9IHRydWU7XG4gICAgICAgIH1cbiAgICAgICAgd2luZG93LmNvbmZpYW50LnNldHRpbmdzLmNhbGxiYWNrID0gbWF5YmVSZWZyZXNoQmxvY2tlZFNsb3RPbmNlO1xuICAgIH1cbiAgICByZXR1cm47XG59O1xuZXhwb3J0IGNvbnN0IF8gPSB7XG4gICAgaW5pdCxcbiAgICBtYXliZVJlZnJlc2hCbG9ja2VkU2xvdE9uY2UsXG4gICAgY29uZmlhbnRSZWZyZXNoZWRTbG90cyxcbn07XG4iLCJpbXBvcnQgZmFzdGRvbSBmcm9tICdmYXN0ZG9tJztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uL2NvbW1lcmNpYWwtZmVhdHVyZXMnO1xuaW1wb3J0IHsgaGFzQ3Jvc3NlZEJyZWFrcG9pbnQsIG1hdGNoZXNCcmVha3BvaW50cywgfSBmcm9tICcuLi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuY29uc3QgcGFnZVNraW4gPSAoKSA9PiB7XG4gICAgY29uc3QgYm9keUVsID0gZG9jdW1lbnQuYm9keTtcbiAgICBjb25zdCBoYXNQYWdlU2tpbiA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5oYXNQYWdlU2tpbjtcbiAgICBjb25zdCBpc0luQVVFZGl0aW9uID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLmVkaXRpb24udG9Mb3dlckNhc2UoKSA9PT0gJ2F1JztcbiAgICBjb25zdCBhZExhYmVsSGVpZ2h0ID0gMjQ7XG4gICAgbGV0IHRvcFBvc2l0aW9uID0gMDtcbiAgICBsZXQgdHJ1c2tpblJlbmRlcmVkID0gZmFsc2U7XG4gICAgbGV0IHBhZ2Vza2luUmVuZGVyZWQgPSBmYWxzZTtcbiAgICBjb25zdCB0b2dnbGVQYWdlU2tpbkFjdGl2ZUNsYXNzID0gKCkgPT4ge1xuICAgICAgICBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgICAgICAgICBib2R5RWwuY2xhc3NMaXN0LnRvZ2dsZSgnaGFzLWFjdGl2ZS1wYWdlc2tpbicsIG1hdGNoZXNCcmVha3BvaW50cyh7IG1pbjogJ3dpZGUnIH0pKTtcbiAgICAgICAgfSk7XG4gICAgfTtcbiAgICBjb25zdCB0b2dnbGVQYWdlU2tpbiA9ICgpID0+IHtcbiAgICAgICAgaWYgKGhhc1BhZ2VTa2luICYmXG4gICAgICAgICAgICAvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgQHR5cGVzY3JpcHQtZXNsaW50L25vLXVubmVjZXNzYXJ5LWNvbmRpdGlvbiAtLSBuZWVkcyB0byBiZSBpbnZlc3RpZ2F0ZWRcbiAgICAgICAgICAgIGhhc0Nyb3NzZWRCcmVha3BvaW50KHRydWUpICYmXG4gICAgICAgICAgICAhY29tbWVyY2lhbEZlYXR1cmVzLmFkRnJlZSkge1xuICAgICAgICAgICAgdG9nZ2xlUGFnZVNraW5BY3RpdmVDbGFzcygpO1xuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBtb3ZlQmFja2dyb3VuZFZlcnRpY2FsUG9zaXRpb24gPSAodmVydGljYWxQb3MpID0+IHtcbiAgICAgICAgYm9keUVsLnN0eWxlLmJhY2tncm91bmRQb3NpdGlvbiA9IGA1MCUgJHt2ZXJ0aWNhbFBvc31weGA7XG4gICAgfTtcbiAgICBjb25zdCBpbml0VG9wUG9zaXRpb25PbmNlID0gKCkgPT4ge1xuICAgICAgICBpZiAodG9wUG9zaXRpb24gPT09IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG5hdkhlYWRlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5uZXctaGVhZGVyJyk7XG4gICAgICAgICAgICBpZiAobmF2SGVhZGVyKSB7XG4gICAgICAgICAgICAgICAgdG9wUG9zaXRpb24gPSB0cnVza2luUmVuZGVyZWRcbiAgICAgICAgICAgICAgICAgICAgPyBuYXZIZWFkZXIub2Zmc2V0VG9wICsgYWRMYWJlbEhlaWdodFxuICAgICAgICAgICAgICAgICAgICA6IG5hdkhlYWRlci5vZmZzZXRUb3AgKyBuYXZIZWFkZXIub2Zmc2V0SGVpZ2h0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCBzaHJpbmtFbGVtZW50ID0gKGVsZW1lbnQpID0+IHtcbiAgICAgICAgY29uc3QgZnJvbnRDb250YWluZXIgPSBkb2N1bWVudC5xdWVyeVNlbGVjdG9yKCcuZmMtY29udGFpbmVyX19pbm5lcicpO1xuICAgICAgICBpZiAoZnJvbnRDb250YWluZXIpIHtcbiAgICAgICAgICAgIGVsZW1lbnQuc3R5bGUuY3NzVGV4dCA9IGBtYXgtd2lkdGg6ICR7ZnJvbnRDb250YWluZXIuY2xpZW50V2lkdGh9cHg7IG1hcmdpbi1yaWdodDogYXV0bzsgbWFyZ2luLWxlZnQ6IGF1dG87YDtcbiAgICAgICAgfVxuICAgIH07XG4gICAgY29uc3QgcmVwb3NpdGlvblRydXNraW4gPSAoKSA9PiB7XG4gICAgICAgIGNvbnN0IGhlYWRlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5uZXctaGVhZGVyJyk7XG4gICAgICAgIGNvbnN0IGZvb3RlciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5sLWZvb3RlcicpO1xuICAgICAgICBjb25zdCB0b3BCYW5uZXJBZCA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy5hZC1zbG90LS10b3AtYmFubmVyLWFkJyk7XG4gICAgICAgIGlmIChoZWFkZXIgJiYgZm9vdGVyICYmIHRvcEJhbm5lckFkKSB7XG4gICAgICAgICAgICBjb25zdCB0b3BCYW5uZXJBZENvbnRhaW5lciA9IGRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJy50b3AtYmFubmVyLWFkLWNvbnRhaW5lcicpO1xuICAgICAgICAgICAgaWYgKHRvcEJhbm5lckFkQ29udGFpbmVyKSB7XG4gICAgICAgICAgICAgICAgdG9wQmFubmVyQWRDb250YWluZXIuc3R5bGUuYm9yZGVyQm90dG9tID0gJ25vbmUnO1xuICAgICAgICAgICAgICAgIHRvcEJhbm5lckFkQ29udGFpbmVyLnN0eWxlLm1pbkhlaWdodCA9ICcwJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGluaXRUb3BQb3NpdGlvbk9uY2UoKTtcbiAgICAgICAgICAgIHNocmlua0VsZW1lbnQoaGVhZGVyKTtcbiAgICAgICAgICAgIHNocmlua0VsZW1lbnQoZm9vdGVyKTtcbiAgICAgICAgICAgIGlmICh3aW5kb3cucGFnZVlPZmZzZXQgPT09IDApIHtcbiAgICAgICAgICAgICAgICBtb3ZlQmFja2dyb3VuZFZlcnRpY2FsUG9zaXRpb24odG9wUG9zaXRpb24pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3QgaGVhZGVyQm91bmRhcmllcyA9IGhlYWRlci5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKTtcbiAgICAgICAgICAgIGNvbnN0IHRvcEJhbm5lckFkQm91bmRhcmllcyA9IHRvcEJhbm5lckFkLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpO1xuICAgICAgICAgICAgY29uc3QgaGVhZGVyUG9zaXRpb24gPSBoZWFkZXJCb3VuZGFyaWVzLnRvcDtcbiAgICAgICAgICAgIGNvbnN0IHRvcEJhbm5lckJvdHRvbSA9IHRvcEJhbm5lckFkQm91bmRhcmllcy5ib3R0b207XG4gICAgICAgICAgICBjb25zdCBmYWJyaWNTY3JvbGxTdGFydFBvc2l0aW9uID0gdG9wQmFubmVyQWRCb3VuZGFyaWVzLmhlaWdodCArXG4gICAgICAgICAgICAgICAgYWRMYWJlbEhlaWdodCAtXG4gICAgICAgICAgICAgICAgaGVhZGVyQm91bmRhcmllcy5oZWlnaHQ7XG4gICAgICAgICAgICBpZiAoaGVhZGVyUG9zaXRpb24gPD0gZmFicmljU2Nyb2xsU3RhcnRQb3NpdGlvbiAmJlxuICAgICAgICAgICAgICAgIHRvcEJhbm5lckJvdHRvbSA+IDApIHtcbiAgICAgICAgICAgICAgICBtb3ZlQmFja2dyb3VuZFZlcnRpY2FsUG9zaXRpb24odG9wQmFubmVyQm90dG9tKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKHRvcEJhbm5lckJvdHRvbSA8PSAwKSB7XG4gICAgICAgICAgICAgICAgbW92ZUJhY2tncm91bmRWZXJ0aWNhbFBvc2l0aW9uKDApO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfTtcbiAgICBjb25zdCByZXBvc2l0aW9uUGFnZVNraW4gPSAoKSA9PiB7XG4gICAgICAgIGluaXRUb3BQb3NpdGlvbk9uY2UoKTtcbiAgICAgICAgaWYgKHdpbmRvdy5wYWdlWU9mZnNldCA9PT0gMCkge1xuICAgICAgICAgICAgbW92ZUJhY2tncm91bmRWZXJ0aWNhbFBvc2l0aW9uKHRvcFBvc2l0aW9uKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIGlmICh3aW5kb3cucGFnZVhPZmZzZXQgPD0gdG9wUG9zaXRpb24pIHtcbiAgICAgICAgICAgIG1vdmVCYWNrZ3JvdW5kVmVydGljYWxQb3NpdGlvbih0b3BQb3NpdGlvbiAtIHdpbmRvdy5wYWdlWU9mZnNldCk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHdpbmRvdy5wYWdlWU9mZnNldCA+IHRvcFBvc2l0aW9uKSB7XG4gICAgICAgICAgICBtb3ZlQmFja2dyb3VuZFZlcnRpY2FsUG9zaXRpb24oMCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHJlcG9zaXRpb25Ta2lucyA9ICgpID0+IHtcbiAgICAgICAgaWYgKHRydXNraW5SZW5kZXJlZCAmJiBoYXNQYWdlU2tpbikge1xuICAgICAgICAgICAgcmVwb3NpdGlvblRydXNraW4oKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUaGlzIGlzIHRvIHJlcG9zaXRpb24gdGhlIFBhZ2UgU2tpbiB0byBzdGFydCB3aGVyZSB0aGUgbmF2aWdhdGlvbiBoZWFkZXIgZW5kcy5cbiAgICAgICAgaWYgKHBhZ2Vza2luUmVuZGVyZWQgJiYgaGFzUGFnZVNraW4gJiYgaXNJbkFVRWRpdGlvbikge1xuICAgICAgICAgICAgcmVwb3NpdGlvblBhZ2VTa2luKCk7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIHRvZ2dsZVBhZ2VTa2luKCk7XG4gICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCAoZXZlbnQpID0+IHtcbiAgICAgICAgLy8gVGhpcyBldmVudCBpcyB0cmlnZ2VyZWQgYnkgdGhlIGNvbW1lcmNpYWwgdGVtcGxhdGU6ICdTa2luIGZvciBmcm9udCBwYWdlcydcbiAgICAgICAgLy8gQWxzbyBmb3VuZCBpbjogY29tbWVyY2lhbC10ZW1wbGF0ZXMvc3JjL3BhZ2Utc2tpbi93ZWIvaW5kZXguaHRtbFxuICAgICAgICBpZiAoZXZlbnQuZGF0YSA9PT0gJ3BhZ2Vza2luUmVuZGVyZWQnKSB7XG4gICAgICAgICAgICBwYWdlc2tpblJlbmRlcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlcG9zaXRpb25Ta2lucygpO1xuICAgICAgICB9XG4gICAgICAgIC8vIFRoaXMgZXZlbnQgaXMgdHJpZ2dlcmVkIGJ5IHRoZSBjb21tZXJjaWFsIHRlbXBsYXRlOiAnVHJ1c2tpbiBUZW1wbGF0ZScgdG8gaW5kaWNhdGUgdGhlIHBhZ2Ugc2tpbiBpcyBhbHNvIGEgVHJ1c2tpblxuICAgICAgICAvLyBBbHNvIGZvdW5kIGluOiBjb21tZXJjaWFsLXRlbXBsYXRlcy9zcmMvdHJ1c2tpbi1wYWdlLXNraW4vd2ViL2luZGV4LmpzXG4gICAgICAgIGlmIChldmVudC5kYXRhID09PSAndHJ1c2tpblJlbmRlcmVkJykge1xuICAgICAgICAgICAgdHJ1c2tpblJlbmRlcmVkID0gdHJ1ZTtcbiAgICAgICAgICAgIHJlcG9zaXRpb25Ta2lucygpO1xuICAgICAgICB9XG4gICAgfSwgZmFsc2UpO1xufTtcbmV4cG9ydCB7IHBhZ2VTa2luIH07XG4iLCIvKipcbiAqIGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3NlYXJjaC9kb2NzL2FkdmFuY2VkL21vYmlsZS93ZWItbGlnaHRcbiAqL1xuY29uc3QgR09PR0xFX1dFQl9MSUdIVCA9ICdnb29nbGV3ZWJsaWdodCc7XG4vKipcbiAqIFRoaXMgb25lIGlzIHVuZG9jdW1lbnRlZCwgbm90IHN1cmUgaXQgYWN0dWFsbHkgZXhpc3RzLlxuICovXG5jb25zdCBHT09HTEVfV0VCX1BSRVZJRVcgPSAnR29vZ2xlIFdlYiBQcmV2aWV3Jztcbi8qKlxuICogUmVhZCBtb3JlIGFib3V0IEdvb2dsZSBDcmF3bGVyIGhlcmU6IGh0dHBzOi8vZGV2ZWxvcGVycy5nb29nbGUuY29tL3NlYXJjaC9kb2NzL2FkdmFuY2VkL2NyYXdsaW5nL292ZXJ2aWV3LWdvb2dsZS1jcmF3bGVyc1xuICogQHJldHVybnMgd2hldGhlciB0aGlzIGlzIGEgR29vZ2xlIFByb3h5XG4gKi9cbmV4cG9ydCBjb25zdCBpc0dvb2dsZVByb3h5ID0gKCkgPT4gQm9vbGVhbihuYXZpZ2F0b3IudXNlckFnZW50LmluY2x1ZGVzKEdPT0dMRV9XRUJfUFJFVklFVykgfHxcbiAgICBuYXZpZ2F0b3IudXNlckFnZW50LmluY2x1ZGVzKEdPT0dMRV9XRUJfTElHSFQpKTtcbiIsImltcG9ydCB7IG1lbW9pemUgfSBmcm9tICdsb2Rhc2gtZXMnO1xuaW1wb3J0IHsgcmVwb3J0RXJyb3IgfSBmcm9tICcuLi9lcnJvci9yZXBvcnQtZXJyb3InO1xuZXhwb3J0IGNvbnN0IGZldGNoTm9uUmVmcmVzaGFibGVMaW5lSXRlbUlkcyA9IGFzeW5jICgpID0+IHtcbiAgICAvLyBXaGVuIHRoZSBlbnYgaXMgQ09ERSBvciBsb2NhbCwgdXNlIHRoZSBDT0RFIGVudidzIG5vbi1yZWZyZXNoYWJsZSBsaW5lIGl0ZW1zIGZpbGVcbiAgICBjb25zdCB7IGhvc3QsIGlzUHJvZCB9ID0gd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlO1xuICAgIGNvbnN0IGZpbGVIb3N0ID0gaXNQcm9kID8gaG9zdCA6ICdodHRwczovL20uY29kZS5kZXYtdGhlZ3VhcmRpYW4uY29tJztcbiAgICBjb25zdCBmaWxlTG9jYXRpb24gPSBuZXcgVVJMKCcvY29tbWVyY2lhbC9ub24tcmVmcmVzaGFibGUtbGluZS1pdGVtcy5qc29uJywgZmlsZUhvc3QpO1xuICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgZmV0Y2goZmlsZUxvY2F0aW9uLnRvU3RyaW5nKCkpO1xuICAgIGlmIChyZXNwb25zZS5vaykge1xuICAgICAgICBjb25zdCBqc29uID0gYXdhaXQgcmVzcG9uc2UuanNvbigpO1xuICAgICAgICBpZiAoIUFycmF5LmlzQXJyYXkoanNvbikpIHtcbiAgICAgICAgICAgIHRocm93IEVycm9yKCdGYWlsZWQgdG8gcGFyc2Ugbm9uLXJlZnJlc2hhYmxlIGxpbmUgaXRlbXMgYXMgYW4gYXJyYXknKTtcbiAgICAgICAgfVxuICAgICAgICAvLyBUaHJvdyBhbiBlcnJvciBpZiBhbnkgb2YgdGhlIGVsZW1lbnRzIGluIHRoZSBhcnJheSBhcmUgbm90IG51bWJlcnNcbiAgICAgICAgY29uc3QgbGluZUl0ZW1zT3JFcnJvciA9IGpzb24ucmVkdWNlKChhY2N1bSwgbGluZUl0ZW1JZCkgPT4gIShhY2N1bSBpbnN0YW5jZW9mIEVycm9yKSAmJiB0eXBlb2YgbGluZUl0ZW1JZCA9PT0gJ251bWJlcidcbiAgICAgICAgICAgID8geyBsaW5lSXRlbXM6IFsuLi5hY2N1bS5saW5lSXRlbXMsIGxpbmVJdGVtSWRdIH1cbiAgICAgICAgICAgIDogRXJyb3IoJ0ZhaWxlZCB0byBwYXJzZSBlbGVtZW50IGluIG5vbi1yZWZyZXNoYWJsZSBsaW5lIGl0ZW0gYXJyYXkgYXMgbnVtYmVyJyksIHsgbGluZUl0ZW1zOiBbXSB9KTtcbiAgICAgICAgaWYgKGxpbmVJdGVtc09yRXJyb3IgaW5zdGFuY2VvZiBFcnJvcikge1xuICAgICAgICAgICAgdGhyb3cgbGluZUl0ZW1zT3JFcnJvcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbGluZUl0ZW1zT3JFcnJvci5saW5lSXRlbXM7XG4gICAgfVxuICAgIC8vIFJlcG9ydCBhbiBlcnJvciB0byBTZW50cnkgaWYgd2UgZG9uJ3QgZ2V0IGFuIG9rIHJlc3BvbnNlXG4gICAgLy8gTm90ZSB0aGF0IGluIG90aGVyIGNhc2VzIChKU09OIHBhcnNpbmcgZmFpbHVyZSkgd2UgdGhyb3cgYnV0IGRvbid0IHJlcG9ydCB0aGUgZXJyb3JcbiAgICBjb25zdCBlcnJvciA9IEVycm9yKCdGYWlsZWQgdG8gZmV0Y2ggbm9uLXJlZnJlc2hhYmxlIGxpbmUgaXRlbXMnKTtcbiAgICByZXBvcnRFcnJvcihlcnJvciwgJ2NvbW1lcmNpYWwnLCB7XG4gICAgICAgIHN0YXR1czogU3RyaW5nKHJlc3BvbnNlLnN0YXR1cyksXG4gICAgfSk7XG4gICAgdGhyb3cgZXJyb3I7XG59O1xuZXhwb3J0IGNvbnN0IG1lbW9pemVkRmV0Y2hOb25SZWZyZXNoYWJsZUxpbmVJdGVtSWRzID0gbWVtb2l6ZShmZXRjaE5vblJlZnJlc2hhYmxlTGluZUl0ZW1JZHMpO1xuIiwiaW1wb3J0IHsgb3V0c3RyZWFtU2l6ZXMgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2FkLXNpemVzJztcbi8qKlxuICogRGV0ZXJtaW5lIHdoZXRoZXIgYW4gYWR2ZXJ0IHNob3VsZCByZWZyZXNoLCB0YWtpbmcgaW50byBhY2NvdW50XG4gKiBpdHMgc2l6ZSwgd2hldGhlciB0aGVyZSdzIGEgcGFnZXNraW4gb3Igd2hldGhlciB0aGUgYWR2ZXJ0J3NcbiAqIGxpbmUgaXRlbSBpcyBtYXJrZWQgYXMgbm9uLXJlZnJlc2hhYmxlXG4gKlxuICogIC0gRmx1aWQgYWRzIHNob3VsZCBub3QgcmVmcmVzaFxuICogIC0gT3V0c3RyZWFtIGFkcyBzaG91bGQgbm90IHJlZnJlc2hcbiAqICAtIFBhZ2Vza2lucyBzaG91bGQgbm90IHJlZnJlc2hcbiAqICAtIEFkcyB0aGF0IGhhdmUgbGluZSBpdGVtcyBtYXJrZWQgYXMgbm9uLXJlZnJlc2hhYmxlIHNob3VsZCBub3QgYmVcbiAqIFx0ICByZWZyZXNoZWQuIFRoaXMgaW5mb3JtYXRpb24gaXMgcmV0cmlldmVkIHZpYSB0aGUgbm9uIHJlZnJlc2hhYmxlXG4gKiBcdCAgbGluZSBpdGVtIEFQSSBlbmRwb2ludFxuICpcbiAqIEBwYXJhbSBhZHZlcnQgVGhlIGNhbmRpZGF0ZSBhZHZlcnQgdG8gY2hlY2tcbiAqIEBwYXJhbSBub25SZWZyZXNoYWJsZUxpbmVJdGVtSWRzIFRoZSBhcnJheSBvZiBsaW5lIGl0ZW0gaWRzIGZvciB3aGljaFxuICogYWR2ZXJ0cyBzaG91bGQgbm90IHJlZnJlc2hcbiAqL1xuY29uc3Qgc2hvdWxkUmVmcmVzaCA9IChhZHZlcnQsIG5vblJlZnJlc2hhYmxlTGluZUl0ZW1JZHMgPSBbXSkgPT4ge1xuICAgIGNvbnN0IHNpemVTdHJpbmcgPSBhZHZlcnQuc2l6ZT8udG9TdHJpbmcoKTtcbiAgICAvLyBEbyBub3QgcmVmcmVzaCBhZHMgaW4gc2xvdHMgbGFiZWxsZWQgZGF0YS1yZWZyZXNoPVwiZmFsc2VcIlxuICAgIGlmIChhZHZlcnQubm9kZS5kYXRhc2V0LnJlZnJlc2ggPT09ICdmYWxzZScpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICAvLyBGbHVpZCBhZHZlcnRzIHNob3VsZCBub3QgcmVmcmVzaFxuICAgIGNvbnN0IGlzRmx1aWQgPSBzaXplU3RyaW5nID09PSAnZmx1aWQnO1xuICAgIGlmIChpc0ZsdWlkKVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgLy8gT3V0c3RyZWFtIGFkdmVydHMgc2hvdWxkIG5vdCByZWZyZXNoXG4gICAgY29uc3QgaXNPdXRzdHJlYW0gPSBPYmplY3QudmFsdWVzKG91dHN0cmVhbVNpemVzKVxuICAgICAgICAubWFwKChzaXplKSA9PiBzaXplLnRvU3RyaW5nKCkpXG4gICAgICAgIC5pbmNsdWRlcyhzaXplU3RyaW5nKTtcbiAgICBpZiAoaXNPdXRzdHJlYW0pXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAvLyBJZiB0aGUgYWR2ZXJ0IGhhcyBhIGxpbmUgaXRlbSBpZCBpbmNsdWRlZCBpbiB0aGUgYXJyYXkgb2Ygbm9uIHJlZnJlc2hhYmxlXG4gICAgLy8gbGluZSBpdGVtIGlkcyB0aGVuIGl0IHNob3VsZCBub3QgcmVmcmVzaFxuICAgIGNvbnN0IGlzTm9uUmVmcmVzaGFibGVMaW5lSXRlbSA9IGFkdmVydC5saW5lSXRlbUlkICYmXG4gICAgICAgIG5vblJlZnJlc2hhYmxlTGluZUl0ZW1JZHMuaW5jbHVkZXMoYWR2ZXJ0LmxpbmVJdGVtSWQpO1xuICAgIGlmIChpc05vblJlZnJlc2hhYmxlTGluZUl0ZW0pXG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAvLyBJZiB3ZSBoYXZlIGEgcGFnZXNraW4gdGhlbiBkb24ndCByZWZyZXNoXG4gICAgaWYgKHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5oYXNQYWdlU2tpbilcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIC8vIElmIG5vbmUgb2YgdGhlIG90aGVyIGNvbmRpdGlvbnMgYXJlIG1ldCB0aGVuIHRoZSBhZHZlcnQgc2hvdWxkIHJlZnJlc2hcbiAgICByZXR1cm4gdHJ1ZTtcbn07XG5leHBvcnQgeyBzaG91bGRSZWZyZXNoIH07XG4iLCJjb25zdCBsb2dHdW1HdW1XaW5uaW5nQmlkID0gKHNsb3RJRCwgYWR2ZXJ0aXNlcklkKSA9PiB7XG4gICAgY29uc3QgZW5kcG9pbnQgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNEZXZcbiAgICAgICAgPyAnLy9sb2dzLmNvZGUuZGV2LWd1YXJkaWFuYXBpcy5jb20vbG9nJ1xuICAgICAgICA6ICcvL2xvZ3MuZ3VhcmRpYW5hcGlzLmNvbS9sb2cnO1xuICAgIGlmICghc2xvdElEIHx8ICFhZHZlcnRpc2VySWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICB2b2lkIGZldGNoKGVuZHBvaW50LCB7XG4gICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICBib2R5OiBKU09OLnN0cmluZ2lmeSh7XG4gICAgICAgICAgICBsYWJlbDogJ2NvbW1lcmNpYWwuZ3VtZ3VtLndpbm5pbmdCaWQnLFxuICAgICAgICAgICAgcHJvcGVydGllczogW1xuICAgICAgICAgICAgICAgIHsgbmFtZTogJ3Nsb3RJRCcsIHZhbHVlOiBzbG90SUQgfSxcbiAgICAgICAgICAgICAgICB7IG5hbWU6ICdhZHZlcnRpc2VySWQnLCB2YWx1ZTogYWR2ZXJ0aXNlcklkIH0sXG4gICAgICAgICAgICAgICAgeyBuYW1lOiAnZ3VtZ3VtSWQnLCB2YWx1ZTogJzFsc3hqYjQnIH0sXG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICBuYW1lOiAncGFnZXZpZXdJZCcsXG4gICAgICAgICAgICAgICAgICAgIHZhbHVlOiB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLm9waGFuLnBhZ2VWaWV3SWQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIF0sXG4gICAgICAgIH0pLFxuICAgICAgICBrZWVwYWxpdmU6IHRydWUsXG4gICAgICAgIGNhY2hlOiAnbm8tc3RvcmUnLFxuICAgICAgICBtb2RlOiAnbm8tY29ycycsXG4gICAgfSk7XG59O1xuZXhwb3J0IHsgbG9nR3VtR3VtV2lubmluZ0JpZCB9O1xuIiwiaW1wb3J0IHsgZGZwRW52IH0gZnJvbSAnLi4vZGZwL2RmcC1lbnYnO1xuLy8gVGhpcyBtZXNzYWdlIGlzIGludGVuZGVkIHRvIGJlIHVzZWQgd2l0aCBhIERGUCBjcmVhdGl2ZSB3cmFwcGVyLlxuLy8gRm9yIHJlZmVyZW5jZSwgdGhlIHdyYXBwZXIgd2lsbCBwb3N0IGEgbWVzc2FnZSwgd2l0aCBhbiBpRnJhbWVJZCwgbGlrZSBzbzpcbi8qXG48c2NyaXB0Plxuc2VsZi5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgZnVuY3Rpb24gb25NZXNzYWdlKGV2dCkge1xuICAgIHZhciBqc29uO1xuICAgIHRyeSB7XG4gICAgICAgIGpzb24gPSBKU09OLnBhcnNlKGV2dC5kYXRhKTtcbiAgICB9IGNhdGNoKF8pIHsgcmV0dXJuOyB9XG5cbiAgICB2YXIga2V5cyA9IE9iamVjdC5rZXlzKGpzb24pO1xuICAgIGlmKCBrZXlzLmxlbmd0aCA8IDIgfHwgIWtleXMuaW5jbHVkZXMoJ2lkJykgfHwgIWtleXMuaW5jbHVkZXMoJ2hvc3QnKSApIHJldHVybjtcblxuICAgIHdpbmRvdy5wYXJlbnQucG9zdE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkoe1xuICAgICAgICB0eXBlOiAnZGlzYWJsZS1yZWZyZXNoJyxcbiAgICAgICAgdmFsdWU6IHt9LFxuICAgICAgICBpZnJhbWVJZDoganNvbi5pZCxcbiAgICAgICAgaWQ6ICdhYWFhMDAwMC1iYjExLWNjMjItZGQzMy1lZWVlZWU0NDQ0NDQnXG4gICAgfSksICcqJyk7XG5cbiAgICBzZWxmLnJlbW92ZUV2ZW50TGlzdGVuZXIoJ21lc3NhZ2UnLCBvbk1lc3NhZ2UpO1xufSk7XG48L3NjcmlwdD5cbiovXG5jb25zdCBpbml0ID0gKHJlZ2lzdGVyKSA9PiB7XG4gICAgcmVnaXN0ZXIoJ2Rpc2FibGUtcmVmcmVzaCcsIChzcGVjcywgcmV0LCBpZnJhbWUpID0+IHtcbiAgICAgICAgaWYgKGlmcmFtZSkge1xuICAgICAgICAgICAgY29uc3QgYWRTbG90ID0gaWZyYW1lLmNsb3Nlc3QoJy5qcy1hZC1zbG90Jyk7XG4gICAgICAgICAgICBpZiAoYWRTbG90IGluc3RhbmNlb2YgSFRNTEVsZW1lbnQpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBhZHZlcnQgPSBkZnBFbnYuYWR2ZXJ0cy5nZXQoYWRTbG90LmlkKTtcbiAgICAgICAgICAgICAgICBpZiAoYWR2ZXJ0KSB7XG4gICAgICAgICAgICAgICAgICAgIGFkdmVydC5zaG91bGRSZWZyZXNoID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSk7XG59O1xuZXhwb3J0IHsgaW5pdCB9O1xuIiwiaW1wb3J0IHsgaXNCb29sZWFuIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnZmFzdGRvbSc7XG5jb25zdCBmdWxsV2lkdGggPSAoZnVsbFdpZHRoLCBzbG90Q29udGFpbmVyKSA9PiBmYXN0ZG9tLm11dGF0ZSgoKSA9PiB7XG4gICAgaWYgKGZ1bGxXaWR0aCkge1xuICAgICAgICBzbG90Q29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ2FkLXNsb3QtLWZ1bGwtd2lkdGgnKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHNsb3RDb250YWluZXIuY2xhc3NMaXN0LnJlbW92ZSgnYWQtc2xvdC0tZnVsbC13aWR0aCcpO1xuICAgIH1cbn0pO1xuY29uc3QgaW5pdCA9IChyZWdpc3RlcikgPT4ge1xuICAgIHJlZ2lzdGVyKCdmdWxsLXdpZHRoJywgKHNwZWNzLCByZXQsIGlmcmFtZSkgPT4ge1xuICAgICAgICBpZiAoaWZyYW1lICYmIHNwZWNzKSB7XG4gICAgICAgICAgICBpZiAoIWlzQm9vbGVhbihzcGVjcykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBhZFNsb3QgPSBpZnJhbWUuY2xvc2VzdCgnLmpzLWFkLXNsb3QnKSA/PyB1bmRlZmluZWQ7XG4gICAgICAgICAgICAvLyBvbmx5IGFsbG93IGZvciBiYW5uZXIgYWRzXG4gICAgICAgICAgICBjb25zdCBuYW1lID0gYWRTbG90Py5kYXRhc2V0Lm5hbWU7XG4gICAgICAgICAgICBpZiAoIW5hbWU/LnN0YXJ0c1dpdGgoJ2Zyb250cy1iYW5uZXInKSB8fCAhYWRTbG90KSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgc2xvdENvbnRhaW5lciA9IGlmcmFtZS5jbG9zZXN0KCcuYWQtc2xvdC1jb250YWluZXInKSA/PyB1bmRlZmluZWQ7XG4gICAgICAgICAgICBpZiAoIXNsb3RDb250YWluZXIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZnVsbFdpZHRoKHNwZWNzLCBzbG90Q29udGFpbmVyKTtcbiAgICAgICAgfVxuICAgIH0pO1xufTtcbmV4cG9ydCBjb25zdCBfID0geyBmdWxsV2lkdGggfTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsIi8qKlxuICogUmVnaXN0ZXIgYSBsaXN0ZW5lciBmb3IgaWZyYW1lcyB0byByZXF1ZXN0IHNoYXJlZCBhZCB0YXJnZXRpbmdcbiAqXG4gKiBBbGxvd3MgZm9yIGFkcyB0byBiZSBzZXJ2ZWQgaW50byBTYWZlRnJhbWUgd2hpbHN0IHJldGFpbmluZyB0aGUgYWJpbGl0eSB0byBkZWZpbmUgYSBwYXNzYmFja1xuICovXG5jb25zdCBpbml0ID0gKHJlZ2lzdGVyKSA9PiB7XG4gICAgcmVnaXN0ZXIoJ2dldC1wYWdlLXRhcmdldGluZycsICgpID0+IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5zaGFyZWRBZFRhcmdldGluZyk7XG59O1xuZXhwb3J0IHsgaW5pdCB9O1xuIiwiY29uc3QgaW5pdCA9IChyZWdpc3RlcikgPT4ge1xuICAgIHJlZ2lzdGVyKCdnZXQtcGFnZS11cmwnLCAoKSA9PiB3aW5kb3cubG9jYXRpb24ub3JpZ2luICsgd2luZG93LmxvY2F0aW9uLnBhdGhuYW1lKTtcbn07XG5leHBvcnQgeyBpbml0IH07XG4iLCJpbXBvcnQgeyBpc09iamVjdCB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmNvbnN0IGlzU3R5bGVTcGVjcyA9IChzcGVjcykgPT4gaXNPYmplY3Qoc3BlY3MpICYmICdzZWxlY3RvcicgaW4gc3BlY3M7XG5jb25zdCBnZXRTdHlsZXMgPSAoc3BlY3MsIHN0eWxlU2hlZXRzKSA9PiB7XG4gICAgY29uc3QgcmVzdWx0ID0gW107XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHlsZVNoZWV0cy5sZW5ndGg7IGkgKz0gMSkge1xuICAgICAgICBjb25zdCBvd25lck5vZGUgPSBzdHlsZVNoZWV0c1tpXT8ub3duZXJOb2RlO1xuICAgICAgICBpZiAob3duZXJOb2RlIGluc3RhbmNlb2YgSFRNTFN0eWxlRWxlbWVudCAmJlxuICAgICAgICAgICAgb3duZXJOb2RlLm1hdGNoZXMoc3BlY3Muc2VsZWN0b3IpICYmXG4gICAgICAgICAgICBvd25lck5vZGUudGV4dENvbnRlbnQgIT09IG51bGwpIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKG93bmVyTm9kZS50ZXh0Q29udGVudCk7XG4gICAgICAgIH1cbiAgICAgICAgLypcbiAgICAgICAgICAgIFRoZXJlIGNvdWxkIGJlIGxpbmsgZWxlbWVudHMgaGVyZSB0b28sIGJ1dCB3ZSBkb24ndCBjYXJlIGFib3V0IHRoZW0gYXMgd2UgY2Fubm90IGFjY2VzcyB0aGUgQ1NTXG4gICAgICAgICAgICB0ZXh0IGNvbnRlbnQgaW4gdGhlbSBhbnl3YXkuXG4gICAgICAgICAgICBUaGlzIGlzIGR1ZSB0byB0aGUgZmFjdCB0aGF0IHRoZXkgYXJlIG9uIHNlcGFyYXRlIGRvbWFpbnMgbGlrZSBgYXNzZXRzLmd1aW0uY28udWtgLCBhY2Nlc3NpbmcgdGhlIHRleHRcbiAgICAgICAgICAgIGZyb20gdGhlbSByZXN1bHRzIGluIGEgQ09SUyBlcnJvci5cbiAgICAgICAgICovXG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59O1xuY29uc3QgaW5pdCA9IChyZWdpc3RlcikgPT4ge1xuICAgIHJlZ2lzdGVyKCdnZXQtc3R5bGVzJywgKHNwZWNzKSA9PiB7XG4gICAgICAgIGlmIChpc1N0eWxlU3BlY3Moc3BlY3MpKSB7XG4gICAgICAgICAgICByZXR1cm4gZ2V0U3R5bGVzKHNwZWNzLCBkb2N1bWVudC5zdHlsZVNoZWV0cyk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5leHBvcnQgY29uc3QgXyA9IHsgZ2V0U3R5bGVzLCBpc1N0eWxlU3BlY3MgfTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsImltcG9ydCB7IEV2ZW50VGltZXIgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2V2ZW50LXRpbWVyJztcbmltcG9ydCB7IGlzT2JqZWN0LCBpc1N0cmluZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbi8vIFRoaXMgbWVzc2FnZSBpcyBpbnRlbmRlZCB0byBiZSB1c2VkIHdpdGggYSBHQU0gY3JlYXRpdmUgd3JhcHBlci5cbi8vIEZvciByZWZlcmVuY2UsIHRoZSB3cmFwcGVyIHdpbGwgcG9zdCBhIG1lc3NhZ2UsIGxpa2Ugc286XG4vKlxuKiA8c2NyaXB0ICBpZD0nYWQtbG9hZC0lJUNBQ0hFQlVTVEVSJSUnPlxuLy9zZW5kIHBvc3RNZXNzYWdlIHRvIGNvbW1lcmNpYWwgYnVuZGxlXG5jb25zdCBtZXRhRGF0YSA9IHtcbiAgICBzbG90SWQ6ICclJVBBVFRFUk46c2xvdCUlJ1xufTtcbnRvcC53aW5kb3cucG9zdE1lc3NhZ2UoSlNPTi5zdHJpbmdpZnkoXG4gICAge1xuICAgICAgICBpZDogJ2JmNzI0ODY2LTcyM2MtNmIwYS1lNWQ3LWFkNjE1MzVmOThiNycsXG4gICAgICAgIHNsb3RJZDogJyUlUEFUVEVSTjpzbG90JSUnLFxuICAgICAgICB0eXBlOiAnbWVhc3VyZS1hZC1sb2FkJyxcbiAgICAgICAgdmFsdWU6IG1ldGFEYXRhXG4gICAgfVxuKSwgJyonKTtcbjwvc2NyaXB0PlxuKiAqL1xuY29uc3QgZ2V0U2xvdElkID0gKHNwZWNzKSA9PiBpc09iamVjdChzcGVjcykgJiYgaXNTdHJpbmcoc3BlY3Muc2xvdElkKSA/IHNwZWNzLnNsb3RJZCA6IHVuZGVmaW5lZDtcbmNvbnN0IGV2ZW50VGltZXIgPSBFdmVudFRpbWVyLmdldCgpO1xuY29uc3QgaW5pdCA9IChyZWdpc3RlcikgPT4ge1xuICAgIHJlZ2lzdGVyKCdtZWFzdXJlLWFkLWxvYWQnLCAoc3BlY3MpID0+IHtcbiAgICAgICAgZXZlbnRUaW1lci5tYXJrKCdhZE9uUGFnZScsIGdldFNsb3RJZChzcGVjcykpO1xuICAgICAgICBldmVudFRpbWVyLm1hcmsoJ2ZldGNoQWRFbmQnLCBnZXRTbG90SWQoc3BlY3MpKTtcbiAgICAgICAgZXZlbnRUaW1lci5tYXJrKCdhZFJlbmRlckVuZCcsIGdldFNsb3RJZChzcGVjcykpO1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsImltcG9ydCB7IGlzU3RyaW5nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgcmVmcmVzaEFkdmVydCB9IGZyb20gJy4uLy4uL2Rpc3BsYXkvbG9hZC1hZHZlcnQnO1xuaW1wb3J0IHsgZ2V0QWR2ZXJ0QnlJZCB9IGZyb20gJy4uL2RmcC9nZXQtYWR2ZXJ0LWJ5LWlkJztcbmNvbnN0IGluZWxpZ2libGVQYXNzYmFja3MgPSBbJ3RlYWRzZGVza3RvcCcsICd0ZWFkc21vYmlsZScsICd0ZWFkcyddO1xuY29uc3QgcGFzc2JhY2tSZWZyZXNoID0gKHNwZWNzLCBhZFNsb3QpID0+IHtcbiAgICBjb25zdCBhZHZlcnQgPSBnZXRBZHZlcnRCeUlkKGFkU2xvdC5pZCk7XG4gICAgaWYgKGFkdmVydCkge1xuICAgICAgICBhZHZlcnQuc2xvdC5zZXRUYXJnZXRpbmcoJ3Bhc3NiYWNrJywgc3BlY3MpO1xuICAgICAgICAvLyBwYXNzYmFja3Mgd2l0aCB0aGVzZSB2YWx1ZXMgYXJlIG5vdCBlbGlnaWJsZSBmb3IgdGVhZHNcbiAgICAgICAgaWYgKGluZWxpZ2libGVQYXNzYmFja3MuaW5jbHVkZXMoc3BlY3MpKSB7XG4gICAgICAgICAgICBhZHZlcnQuc2xvdC5zZXRUYXJnZXRpbmcoJ3RlYWRzRWxpZ2libGUnLCAnZmFsc2UnKTtcbiAgICAgICAgfVxuICAgICAgICByZWZyZXNoQWR2ZXJ0KGFkdmVydCk7XG4gICAgfVxufTtcbmNvbnN0IGluaXQgPSAocmVnaXN0ZXIpID0+IHtcbiAgICByZWdpc3RlcigncGFzc2JhY2stcmVmcmVzaCcsIChzcGVjcywgXywgaWZyYW1lKSA9PiB7XG4gICAgICAgIGlmIChpZnJhbWUgJiYgaXNTdHJpbmcoc3BlY3MpKSB7XG4gICAgICAgICAgICBjb25zdCBhZFNsb3QgPSBpZnJhbWUuY2xvc2VzdCgnLmpzLWFkLXNsb3QnKSA/PyB1bmRlZmluZWQ7XG4gICAgICAgICAgICBpZiAoIWFkU2xvdCkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBwYXNzYmFja1JlZnJlc2goc3BlY3MsIGFkU2xvdCk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5leHBvcnQgY29uc3QgXyA9IHsgcGFzc2JhY2tSZWZyZXNoIH07XG5leHBvcnQgeyBpbml0IH07XG4iLCJpbXBvcnQgeyBhZFNpemVzIH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9hZC1zaXplcyc7XG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBicmVha3BvaW50cyB9IGZyb20gJ0BndWFyZGlhbi9zb3VyY2UvZm91bmRhdGlvbnMnO1xuaW1wb3J0IHsgZ2V0Q3VycmVudEJyZWFrcG9pbnQgfSBmcm9tICcuLi9kZXRlY3QvZGV0ZWN0LWJyZWFrcG9pbnQnO1xuaW1wb3J0IHsgYWRTbG90SWRQcmVmaXggfSBmcm9tICcuLi9kZnAvZGZwLWVudi1nbG9iYWxzJztcbmltcG9ydCB7IGdldEFkdmVydEJ5SWQgfSBmcm9tICcuLi9kZnAvZ2V0LWFkdmVydC1ieS1pZCc7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi9mYXN0ZG9tLXByb21pc2UnO1xuY29uc3QgYWRMYWJlbEhlaWdodCA9IDI0O1xuLyoqXG4gKiBQYXNzYmFjayBzaXplIG1hcHBpbmdzXG4gKiBodHRwczovL2RldmVsb3BlcnMuZ29vZ2xlLmNvbS9wdWJsaXNoZXItdGFnL2d1aWRlcy9hZC1zaXplcyNyZXNwb25zaXZlX2Fkc1xuICpcbiAqIHZpZXdwb3J0IGhlaWdodCBpcyBzZXQgdG8gMCB0byBkZW5vdGUgYW55IHNpemUgZnJvbSAwXG4gKlxuICogW1xuICogICBbXG4gKiAgICAgWyB2aWV3cG9ydDEtd2lkdGgsIHZpZXdwb3J0MS1oZWlnaHRdLFxuICogICAgIFsgW3Nsb3QxLXdpZHRoLCBzbG90MS1oZWlnaHRdLCBbc2xvdDItd2lkdGgsIHNsb3QyLWhlaWdodF0sIC4uLiBdXG4gKiAgIF1cbiAqIF1cbiAqXG4gKi9cbmNvbnN0IG1wdSA9IFthZFNpemVzLm1wdS53aWR0aCwgYWRTaXplcy5tcHUuaGVpZ2h0XTtcbmNvbnN0IG91dHN0cmVhbURlc2t0b3AgPSBbXG4gICAgYWRTaXplcy5vdXRzdHJlYW1EZXNrdG9wLndpZHRoLFxuICAgIGFkU2l6ZXMub3V0c3RyZWFtRGVza3RvcC5oZWlnaHQsXG5dO1xuY29uc3Qgb3V0c3RyZWFtTW9iaWxlID0gW1xuICAgIGFkU2l6ZXMub3V0c3RyZWFtTW9iaWxlLndpZHRoLFxuICAgIGFkU2l6ZXMub3V0c3RyZWFtTW9iaWxlLmhlaWdodCxcbl07XG5jb25zdCBvdXRzdHJlYW1TaXplcyA9IFttcHUsIG91dHN0cmVhbU1vYmlsZSwgb3V0c3RyZWFtRGVza3RvcF07XG5jb25zdCBvdXN0cmVhbVNpemVNYXBwaW5ncyA9IFtcbiAgICBbXG4gICAgICAgIFticmVha3BvaW50cy5waGFibGV0LCAwXSxcbiAgICAgICAgW21wdSwgb3V0c3RyZWFtRGVza3RvcF0sXG4gICAgXSxcbiAgICBbXG4gICAgICAgIFticmVha3BvaW50cy5tb2JpbGUsIDBdLFxuICAgICAgICBbbXB1LCBvdXRzdHJlYW1Nb2JpbGVdLFxuICAgIF0sXG5dO1xuY29uc3QgbW9iaWxlU3RpY2t5ID0gW1xuICAgIGFkU2l6ZXMubW9iaWxlc3RpY2t5LndpZHRoLFxuICAgIGFkU2l6ZXMubW9iaWxlc3RpY2t5LmhlaWdodCxcbl07XG5jb25zdCBtb2JpbGVTdGlja3lTaXplcyA9IFttb2JpbGVTdGlja3ldO1xuY29uc3QgbW9iaWxlU3RpY2t5U2l6ZU1hcHBpbmdzID0gW1xuICAgIFtbYnJlYWtwb2ludHMubW9iaWxlLCAwXSwgW21vYmlsZVN0aWNreV1dLFxuXTtcbmNvbnN0IGRlZmF1bHRTaXplTWFwcGluZ3MgPSBbXG4gICAgW1ticmVha3BvaW50cy5tb2JpbGUsIDBdLCBbbXB1XV0sXG5dO1xuY29uc3QgZGVjaWRlU2l6ZXMgPSAoc291cmNlKSA9PiB7XG4gICAgaWYgKHNvdXJjZSA9PT0gJ3RlYWRzJykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2l6ZXM6IG91dHN0cmVhbVNpemVzLFxuICAgICAgICAgICAgc2l6ZU1hcHBpbmdzOiBvdXN0cmVhbVNpemVNYXBwaW5ncyxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgaWYgKHNvdXJjZSA9PT0gJ29ndXJ5Jykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgc2l6ZXM6IG1vYmlsZVN0aWNreVNpemVzLFxuICAgICAgICAgICAgc2l6ZU1hcHBpbmdzOiBtb2JpbGVTdGlja3lTaXplTWFwcGluZ3MsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHJldHVybiB7XG4gICAgICAgIHNpemVzOiBbbXB1XSxcbiAgICAgICAgc2l6ZU1hcHBpbmdzOiBkZWZhdWx0U2l6ZU1hcHBpbmdzLFxuICAgIH07XG59O1xuY29uc3QgbWFwVmFsdWVzID0gKGtleXMsIHZhbHVlRm4pID0+IGtleXMubWFwKChrZXkpID0+IFtrZXksIHZhbHVlRm4oa2V5KV0pO1xuY29uc3QgZ2V0UGFzc2JhY2tWYWx1ZSA9IChzb3VyY2UpID0+IHtcbiAgICBjb25zdCBpc01vYmlsZSA9IGdldEN1cnJlbnRCcmVha3BvaW50KCkgPT09ICdtb2JpbGUnO1xuICAgIC8vIGUuZy4gJ3RlYWRzZGVza3RvcCcgb3IgJ3RlYWRzbW9iaWxlJztcbiAgICByZXR1cm4gYCR7c291cmNlfSR7aXNNb2JpbGUgPyAnbW9iaWxlJyA6ICdkZXNrdG9wJ31gO1xufTtcbi8qKlxuICogQSBsaXN0ZW5lciBmb3IgJ3Bhc3NiYWNrJyBtZXNzYWdlcyBmcm9tIGFkIHNsb3QgaUZyYW1lc1xuICogQWQgcHJvdmlkZXJzIHdpbGwgcG9zdE1lc3NhZ2UgYSAncGFzc2JhY2snIG1lc3NhZ2UgdG8gdGVsbCB1cyB0aGV5IGhhdmUgbm90IGZpbGxlZCB0aGlzIHNsb3RcbiAqIEluIHdoaWNoIGNhc2Ugd2UgY3JlYXRlIGEgJ3Bhc3NiYWNrJyBzbG90IHRvIGZ1bGZpbCB0aGUgc2xvdCB3aXRoIGFub3RoZXIgYWRcbiAqXG4gKiBNb3JlIGRldGFpbHM6XG4gKiBodHRwczovL2dpdGh1Yi5jb20vZ3VhcmRpYW4vZnJvbnRlbmQvcHVsbC8yNDcyNFxuICogaHR0cHM6Ly9naXRodWIuY29tL2d1YXJkaWFuL2Zyb250ZW5kL3B1bGwvMjQ5MDNcbiAqIGh0dHBzOi8vZ2l0aHViLmNvbS9ndWFyZGlhbi9mcm9udGVuZC9wdWxsLzI1MDA4XG4gKi9cbmNvbnN0IGluaXQgPSAocmVnaXN0ZXIpID0+IHtcbiAgICByZWdpc3RlcigncGFzc2JhY2snLCAobWVzc2FnZVBheWxvYWQsIHJldCwgaWZyYW1lKSA9PiB7XG4gICAgICAgIHdpbmRvdy5nb29nbGV0YWcuY21kLnB1c2goKCkgPT4ge1xuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBHZXQgdGhlIHBhc3NiYWNrIHNvdXJjZSBmcm9tIHRoZSBpbmNvbWluZyBtZXNzYWdlXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIGNvbnN0IHsgc291cmNlIH0gPSBtZXNzYWdlUGF5bG9hZDtcbiAgICAgICAgICAgIGlmICghc291cmNlKSB7XG4gICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ1Bhc3NiYWNrOiBwb3N0TWVzc2FnZSBkb2VzIG5vdCBoYXZlIHNvdXJjZSBzZXQnKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoIWlmcmFtZSkge1xuICAgICAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsICdQYXNzYmFjazogaWZyYW1lIGhhcyBub3QgYmVlbiBwYXNzZWQgYnkgbWVzc2VuZ2VyJyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBEZXRlcm1pbmUgdGhlIHNsb3QgZnJvbSB0aGUgY2FsbGluZyBpRnJhbWUgYXMgcHJvdmlkZWQgYnkgbWVzc2VuZ2VyXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIGNvbnN0IHNsb3RFbGVtZW50ID0gaWZyYW1lLmNsb3Nlc3QoJy5hZC1zbG90Jyk7XG4gICAgICAgICAgICBjb25zdCBzbG90SWQgPSBzbG90RWxlbWVudD8uZGF0YXNldC5uYW1lO1xuICAgICAgICAgICAgaWYgKCFzbG90SWQpIHtcbiAgICAgICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnUGFzc2JhY2s6IGNhbm5vdCBkZXRlcm1pbmUgdGhlIHNsb3QgZnJvbSB0aGUgY2FsbGluZyBpRnJhbWUnKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBzbG90SWRXaXRoUHJlZml4ID0gYCR7YWRTbG90SWRQcmVmaXh9JHtzbG90SWR9YDtcbiAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGBQYXNzYmFjazogZnJvbSBzb3VyY2UgJyR7c291cmNlfScgZm9yIHNsb3QgJyR7c2xvdElkV2l0aFByZWZpeH0nYCk7XG4gICAgICAgICAgICBjb25zdCBpRnJhbWVDb250YWluZXIgPSBpZnJhbWUuY2xvc2VzdCgnLmFkLXNsb3RfX2NvbnRlbnQnKTtcbiAgICAgICAgICAgIGlmICghaUZyYW1lQ29udGFpbmVyKSB7XG4gICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ1Bhc3NiYWNrOiBjYW5ub3QgZGV0ZXJtaW5lIHRoZSBpRnJhbWVDb250YWluZXIgZnJvbSB0aGUgY2FsbGluZyBpRnJhbWUnKTtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIEtlZXAgdGhlIGluaXRpYWwgb3V0c3RyZWFtIGlGcmFtZSBzbyB0aGV5IGNhbiBkZXRlY3QgcGFzc2JhY2tzLlxuICAgICAgICAgICAgICogTWFpbnRhaW4gdGhlIGlGcmFtZSBpbml0aWFsIHNpemUgYnkgc2V0dGluZyB2aXNpYmlsaXR5IGhpZGRlbiB0byBwcmV2ZW50IENMUy5cbiAgICAgICAgICAgICAqIEluIGEgZnVsbCB3aWR0aCBjb2x1bW4gd2UgdGhlbiBqdXN0IG5lZWQgdG8gcmVzaXplIHRoZSBoZWlnaHQuXG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIGNvbnN0IHVwZGF0ZUluaXRpYWxTbG90UHJvbWlzZSA9IGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgICAgICBpRnJhbWVDb250YWluZXIuc3R5bGUudmlzaWJpbGl0eSA9ICdoaWRkZW4nO1xuICAgICAgICAgICAgICAgIC8vIEFsbG93cyBwYXNzYmFjayBzbG90IHRvIHBvc2l0aW9uIGFic29sdXRlbHkgb3ZlciB0aGUgcGFyZW50IHNsb3RcbiAgICAgICAgICAgICAgICBzbG90RWxlbWVudC5zdHlsZS5wb3NpdGlvbiA9ICdyZWxhdGl2ZSc7XG4gICAgICAgICAgICAgICAgLy8gUmVtb3ZlIGFueSBvdXRzdHJlYW0gc3R5bGluZyBmb3IgdGhlIHBhcmVudCBzbG90XG4gICAgICAgICAgICAgICAgc2xvdEVsZW1lbnQuY2xhc3NMaXN0LnJlbW92ZSgnYWQtc2xvdC0tb3V0c3RyZWFtJyk7XG4gICAgICAgICAgICAgICAgLy8gUHJldmVudCByZWZyZXNoaW5nIG9mIHRoZSBwYXJlbnQgc2xvdFxuICAgICAgICAgICAgICAgIHNsb3RFbGVtZW50LnNldEF0dHJpYnV0ZSgnZGF0YS1yZWZyZXNoJywgJ2ZhbHNlJyk7XG4gICAgICAgICAgICAgICAgY29uc3QgYWR2ZXJ0ID0gZ2V0QWR2ZXJ0QnlJZChzbG90RWxlbWVudC5pZCk7XG4gICAgICAgICAgICAgICAgaWYgKGFkdmVydClcbiAgICAgICAgICAgICAgICAgICAgYWR2ZXJ0LnNob3VsZFJlZnJlc2ggPSBmYWxzZTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgKiBDcmVhdGUgYSBuZXcgcGFzc2JhY2sgYWQgc2xvdCBlbGVtZW50XG4gICAgICAgICAgICAgKi9cbiAgICAgICAgICAgIGNvbnN0IGNyZWF0ZU5ld1Nsb3RFbGVtZW50UHJvbWlzZSA9IHVwZGF0ZUluaXRpYWxTbG90UHJvbWlzZS50aGVuKCgpID0+IHtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXNzYmFja0VsZW1lbnQgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICAgICAgICAgICAgICBwYXNzYmFja0VsZW1lbnQuaWQgPSBgJHtzbG90SWRXaXRoUHJlZml4fS0tcGFzc2JhY2tgO1xuICAgICAgICAgICAgICAgIHBhc3NiYWNrRWxlbWVudC5jbGFzc0xpc3QuYWRkKCdhZC1zbG90JywgJ2pzLWFkLXNsb3QnKTtcbiAgICAgICAgICAgICAgICBwYXNzYmFja0VsZW1lbnQuc2V0QXR0cmlidXRlKCdhcmlhLWhpZGRlbicsICd0cnVlJyk7XG4gICAgICAgICAgICAgICAgLy8gcG9zaXRpb24gYWJzb2x1dGUgdG8gcG9zaXRpb24gb3ZlciB0aGUgY29udGFpbmVyIHNsb3RcbiAgICAgICAgICAgICAgICBwYXNzYmFja0VsZW1lbnQuc3R5bGUucG9zaXRpb24gPSAnYWJzb2x1dGUnO1xuICAgICAgICAgICAgICAgIC8vIGFjY291bnQgZm9yIHRoZSBhZCBsYWJlbFxuICAgICAgICAgICAgICAgIHBhc3NiYWNrRWxlbWVudC5zdHlsZS50b3AgPSBgJHthZExhYmVsSGVpZ2h0fXB4YDtcbiAgICAgICAgICAgICAgICAvLyB0YWtlIHRoZSBmdWxsIHdpZHRoIHNvIGl0IHdpbGwgY2VudGVyIGhvcml6b250YWxseVxuICAgICAgICAgICAgICAgIHBhc3NiYWNrRWxlbWVudC5zdHlsZS53aWR0aCA9ICcxMDAlJztcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFzdGRvbVxuICAgICAgICAgICAgICAgICAgICAubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgc2xvdEVsZW1lbnQuaW5zZXJ0QWRqYWNlbnRFbGVtZW50KCdiZWZvcmVlbmQnLCBwYXNzYmFja0VsZW1lbnQpO1xuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgICAgIC50aGVuKCgpID0+IHBhc3NiYWNrRWxlbWVudCk7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIC8qKlxuICAgICAgICAgICAgICogQ3JlYXRlIGFuZCBkaXNwbGF5IHRoZSBuZXcgcGFzc2JhY2sgc2xvdFxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICB2b2lkIGNyZWF0ZU5ld1Nsb3RFbGVtZW50UHJvbWlzZS50aGVuKChwYXNzYmFja0VsZW1lbnQpID0+IHtcbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBGaW5kIHRoZSBpbml0aWFsIHNsb3Qgb2JqZWN0IGZyb20gZ29vZ2xldGFnXG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgY29uc3QgaW5pdGlhbFNsb3QgPSB3aW5kb3cuZ29vZ2xldGFnXG4gICAgICAgICAgICAgICAgICAgIC5wdWJhZHMoKVxuICAgICAgICAgICAgICAgICAgICAuZ2V0U2xvdHMoKVxuICAgICAgICAgICAgICAgICAgICAuZmluZCgocykgPT4gcy5nZXRTbG90RWxlbWVudElkKCkgPT09IHNsb3RJZFdpdGhQcmVmaXgpO1xuICAgICAgICAgICAgICAgIGlmICghaW5pdGlhbFNsb3QpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ1Bhc3NiYWNrOiBjYW5ub3QgZGV0ZXJtaW5lIHRoZSBnb29nbGV0YWcgc2xvdCBmcm9tIHRoZSBzbG90SWQnKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBDb3B5IHRoZSB0YXJnZXRpbmcgZnJvbSB0aGUgaW5pdGlhbCBzbG90XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgY29uc3QgcGFnZVRhcmdldGluZyA9IG1hcFZhbHVlcyh3aW5kb3cuZ29vZ2xldGFnLnB1YmFkcygpLmdldFRhcmdldGluZ0tleXMoKSwgKGtleSkgPT4gd2luZG93Lmdvb2dsZXRhZy5wdWJhZHMoKS5nZXRUYXJnZXRpbmcoa2V5KSk7XG4gICAgICAgICAgICAgICAgY29uc3Qgc2xvdFRhcmdldGluZyA9IG1hcFZhbHVlcyhpbml0aWFsU2xvdC5nZXRUYXJnZXRpbmdLZXlzKCksIChrZXkpID0+IGluaXRpYWxTbG90LmdldFRhcmdldGluZyhrZXkpKTtcbiAgICAgICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnUGFzc2JhY2s6IGluaXRpYWwgc2xvdCB0YXJnZXRpbmcnLCBPYmplY3QuZnJvbUVudHJpZXMoWy4uLnBhZ2VUYXJnZXRpbmcsIC4uLnNsb3RUYXJnZXRpbmddKSk7XG4gICAgICAgICAgICAgICAgLyoqXG4gICAgICAgICAgICAgICAgICogQ3JlYXRlIHRoZSB0YXJnZXRpbmcgZm9yIHRoZSBuZXcgcGFzc2JhY2sgc2xvdFxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGNvbnN0IHBhc3NiYWNrVGFyZ2V0aW5nID0gW1xuICAgICAgICAgICAgICAgICAgICAuLi5wYWdlVGFyZ2V0aW5nLFxuICAgICAgICAgICAgICAgICAgICAuLi5zbG90VGFyZ2V0aW5nLFxuICAgICAgICAgICAgICAgICAgICBbJ3Bhc3NiYWNrJywgW2dldFBhc3NiYWNrVmFsdWUoc291cmNlKV1dLFxuICAgICAgICAgICAgICAgICAgICBbJ3Nsb3QnLCBbc2xvdElkXV0sXG4gICAgICAgICAgICAgICAgXTtcbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBSZWdpc3RlciBhIGxpc3RlbmVyIHRvIGFkanVzdCB0aGUgY29udGFpbmVyIGhlaWdodCBvbmNlIHRoZVxuICAgICAgICAgICAgICAgICAqIHBhc3NiYWNrIGhhcyBsb2FkZWQuIFdlIG5lZWQgdG8gZG8gdGhpcyBiZWNhdXNlIHRoZSBwYXNzYmFja1xuICAgICAgICAgICAgICAgICAqIGFkIGlzIGFic29sdXRlbHkgcG9zaXRpb25lZCBpbiBvcmRlciB0byBub3QgY2F1c2UgbGF5b3V0IHNoaWZ0LlxuICAgICAgICAgICAgICAgICAqIFNvIGl0IGlzIHRha2VuIG91dCBvZiBub3JtYWwgZG9jdW1lbnQgZmxvdyBhbmQgdGhlIHBhcmVudCBjb250YWluZXJcbiAgICAgICAgICAgICAgICAgKiBkb2VzIG5vdCB0YWtlIHRoZSBoZWlnaHQgb2YgdGhlIGNoaWxkIGFkIGVsZW1lbnQgYXMgbm9ybWFsLlxuICAgICAgICAgICAgICAgICAqIFdlIHNldCB0aGUgY29udGFpbmVyIGhlaWdodCBieSBhZGRpbmcgYSBsaXN0ZW5lciB0byB0aGUgZ29vZ2xldGFnXG4gICAgICAgICAgICAgICAgICogc2xvdFJlbmRlckVuZGVkIGV2ZW50IHdoaWNoIHByb3ZpZGVzIHRoZSBzaXplIG9mIHRoZSBsb2FkZWQgYWQuXG4gICAgICAgICAgICAgICAgICogaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vcHVibGlzaGVyLXRhZy9yZWZlcmVuY2UjZ29vZ2xldGFnLmV2ZW50cy5zbG90cmVuZGVyZW5kZWRldmVudFxuICAgICAgICAgICAgICAgICAqL1xuICAgICAgICAgICAgICAgIGdvb2dsZXRhZ1xuICAgICAgICAgICAgICAgICAgICAucHViYWRzKClcbiAgICAgICAgICAgICAgICAgICAgLmFkZEV2ZW50TGlzdGVuZXIoJ3Nsb3RSZW5kZXJFbmRlZCcsIGZ1bmN0aW9uIChldmVudCkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBzbG90SWQgPSBldmVudC5zbG90LmdldFNsb3RFbGVtZW50SWQoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHNsb3RJZCA9PT0gcGFzc2JhY2tFbGVtZW50LmlkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBzaXplID0gZXZlbnQuc2l6ZTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KHNpemUpICYmIHNpemVbMV0pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb25zdCBhZEhlaWdodCA9IHNpemVbMV07XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgYFBhc3NiYWNrOiBhZCBoZWlnaHQgaXMgJHthZEhlaWdodH1gKTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB2b2lkIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgY29uc3Qgc2xvdEhlaWdodCA9IGAkeyhnZXRDdXJyZW50QnJlYWtwb2ludCgpID09PSAnbW9iaWxlJ1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgPyBhZEhlaWdodFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgOiBhZFNpemVzLm91dHN0cmVhbURlc2t0b3BcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAuaGVpZ2h0KSArIGFkTGFiZWxIZWlnaHR9cHhgO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBgUGFzc2JhY2s6IHNldHRpbmcgaGVpZ2h0IG9mIHBhc3NiYWNrIHNsb3QgdG8gJHtzbG90SGVpZ2h0fWApO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBzbG90RWxlbWVudC5zdHlsZS5oZWlnaHQgPSBzbG90SGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICogVGhlIGNlbnRyZSBzdHlsaW5nIGlzIGFkZGVkIGluIGhlcmUgaW5zdGVhZCBvZiB3aGVyZSB0aGUgZWxlbWVudCBpcyBjcmVhdGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqIGJlY2F1c2UgZ29vZ2xldGFnIHJlbW92ZXMgdGhlIGRpc3BsYXkgc3R5bGUgb24gdGhlIHBhc3NiYWNrRWxlbWVudFxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgKi9cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgcGFzc2JhY2tFbGVtZW50LnN0eWxlLmRpc3BsYXkgPSAnZmxleCc7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhc3NiYWNrRWxlbWVudC5zdHlsZS5mbGV4RGlyZWN0aW9uID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjb2x1bW4nO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXNzYmFja0VsZW1lbnQuc3R5bGUuanVzdGlmeUNvbnRlbnQgPVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgJ2NlbnRlcic7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHBhc3NiYWNrRWxlbWVudC5zdHlsZS5hbGlnbkl0ZW1zID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICdjZW50ZXInO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXNzYmFja0VsZW1lbnQuc3R5bGUuaGVpZ2h0ID0gYGNhbGMoMTAwJSAtICR7YWRMYWJlbEhlaWdodH1weClgO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICogQWxzbyByZXNpemUgdGhlIGluaXRpYWwgb3V0c3RyZWFtIGlmcmFtZSBzbyBpdCBkb2Vzbid0IGJsb2NrIHRleHQgc2VsZWN0aW9uXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAqIGRpcmVjdGx5IHVuZGVyIHRoZSBuZXcgYWRcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGlmcmFtZS5zdHlsZS5oZWlnaHQgPSBzbG90SGVpZ2h0O1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICBpRnJhbWVDb250YWluZXIuc3R5bGUuaGVpZ2h0ID1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIHNsb3RIZWlnaHQ7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAgICAgKiBEZWZpbmUgYW5kIGRpc3BsYXkgdGhlIG5ldyBwYXNzYmFjayBzbG90XG4gICAgICAgICAgICAgICAgICovXG4gICAgICAgICAgICAgICAgd2luZG93Lmdvb2dsZXRhZy5jbWQucHVzaCgoKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IHsgc2l6ZXMsIHNpemVNYXBwaW5ncyB9ID0gZGVjaWRlU2l6ZXMoc291cmNlKTtcbiAgICAgICAgICAgICAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vcHVibGlzaGVyLXRhZy9yZWZlcmVuY2UjZ29vZ2xldGFnLmRlZmluZVNsb3RcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgcGFzc2JhY2tTbG90ID0gZ29vZ2xldGFnLmRlZmluZVNsb3QoaW5pdGlhbFNsb3QuZ2V0QWRVbml0UGF0aCgpLCBzaXplcywgcGFzc2JhY2tFbGVtZW50LmlkKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKHBhc3NiYWNrU2xvdCkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXJzLmdvb2dsZS5jb20vcHVibGlzaGVyLXRhZy9ndWlkZXMvYWQtc2l6ZXMjcmVzcG9uc2l2ZV9hZHNcbiAgICAgICAgICAgICAgICAgICAgICAgIHBhc3NiYWNrU2xvdC5kZWZpbmVTaXplTWFwcGluZyhzaXplTWFwcGluZ3MpO1xuICAgICAgICAgICAgICAgICAgICAgICAgcGFzc2JhY2tTbG90LmFkZFNlcnZpY2Uod2luZG93Lmdvb2dsZXRhZy5wdWJhZHMoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBwYXNzYmFja1RhcmdldGluZy5mb3JFYWNoKChba2V5LCB2YWx1ZV0pID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBwYXNzYmFja1Nsb3Quc2V0VGFyZ2V0aW5nKGtleSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnUGFzc2JhY2s6IHBhc3NiYWNrIHNsb3QgdGFyZ2V0aW5nIG1hcCcsIHBhc3NiYWNrU2xvdC5nZXRUYXJnZXRpbmdNYXAoKSk7XG4gICAgICAgICAgICAgICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBgUGFzc2JhY2s6IGRpc3BsYXlpbmcgc2xvdCAnJHtwYXNzYmFja0VsZW1lbnQuaWR9J2ApO1xuICAgICAgICAgICAgICAgICAgICAgICAgZ29vZ2xldGFnLmRpc3BsYXkocGFzc2JhY2tFbGVtZW50LmlkKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsImltcG9ydCBmYXN0ZG9tIGZyb20gJy4uL2Zhc3Rkb20tcHJvbWlzZSc7XG4vLyBBbiBpbnRlcnNlY3Rpb24gb2JzZXJ2ZXIgd2lsbCBhbGxvdyB1cyB0byBlZmZpY2llbnRseSBzZW5kIHNsb3Rcbi8vIGNvb3JkaW5hdGVzIGZvciBvbmx5IHRob3NlIHRoYXQgYXJlIGluIHRoZSB2aWV3cG9ydC5cbmxldCB0YXNrUXVldWVkID0gZmFsc2U7XG5sZXQgaWZyYW1lcyA9IHt9O1xubGV0IGlmcmFtZUNvdW50ZXIgPSAwO1xubGV0IG9ic2VydmVyO1xubGV0IHZpc2libGVJZnJhbWVJZHMgPSBbXTtcbmNvbnN0IHJlc2V0ID0gKCkgPT4ge1xuICAgIHRhc2tRdWV1ZWQgPSBmYWxzZTtcbiAgICBpZnJhbWVzID0ge307XG4gICAgaWZyYW1lQ291bnRlciA9IDA7XG59O1xuLy8gSW5zdGFuY2VzIG9mIGNsYXNzZXMgYm91bmQgdG8gdGhlIGN1cnJlbnQgdmlldyBhcmUgbm90IHNlcmlhbGlzZWQgY29ycmVjdGx5XG4vLyBieSBKU09OLnN0cmluZ2lmeS4gVGhhdCdzIG9rLCB3ZSBkb24ndCBjYXJlIGlmIGl0J3MgYSBET01SZWN0IG9yIHNvbWUgb3RoZXJcbi8vIG9iamVjdCwgYXMgbG9uZyBhcyB0aGUgY2FsbGluZyB2aWV3IHJlY2VpdmVzIHRoZSBmcmFtZSBjb29yZGluYXRlcy5cbmNvbnN0IGRvbVJlY3RUb1JlY3QgPSAocmVjdCkgPT4gKHtcbiAgICB3aWR0aDogcmVjdC53aWR0aCxcbiAgICBoZWlnaHQ6IHJlY3QuaGVpZ2h0LFxuICAgIHRvcDogcmVjdC50b3AsXG4gICAgYm90dG9tOiByZWN0LmJvdHRvbSxcbiAgICBsZWZ0OiByZWN0LmxlZnQsXG4gICAgcmlnaHQ6IHJlY3QucmlnaHQsXG59KTtcbmNvbnN0IHNlbmRDb29yZGluYXRlcyA9IChpZnJhbWVJZCwgZG9tUmVjdCkgPT4ge1xuICAgIGlmcmFtZXNbaWZyYW1lSWRdPy5yZXNwb25kKG51bGwsIGRvbVJlY3RUb1JlY3QoZG9tUmVjdCkpO1xufTtcbmNvbnN0IGdldERpbWVuc2lvbnMgPSAoaWQpID0+IHtcbiAgICBjb25zdCBub2RlID0gaWZyYW1lc1tpZF0/Lm5vZGU7XG4gICAgcmV0dXJuIFtpZCwgbm9kZS5nZXRCb3VuZGluZ0NsaWVudFJlY3QoKV07XG59O1xuY29uc3Qgb25JbnRlcnNlY3QgPSAoY2hhbmdlcykgPT4ge1xuICAgIHZpc2libGVJZnJhbWVJZHMgPSBjaGFuZ2VzXG4gICAgICAgIC5maWx0ZXIoKF8pID0+IF8uaW50ZXJzZWN0aW9uUmF0aW8gPiAwKVxuICAgICAgICAubWFwKChfKSA9PiBfLnRhcmdldC5pZCk7XG59O1xuLy8gdHlwZXNjcmlwdCBjb21wbGFpbnMgYWJvdXQgYW4gYXN5bmMgZXZlbnQgaGFuZGxlciwgc28gd3JhcCBpdCBpbiBhIG5vbi1hc3luYyBmdW5jdGlvblxuY29uc3Qgb25TY3JvbGwgPSAoKSA9PiB7XG4gICAgaWYgKCF0YXNrUXVldWVkKSB7XG4gICAgICAgIHRhc2tRdWV1ZWQgPSB0cnVlO1xuICAgICAgICB2b2lkIGZhc3Rkb20ubWVhc3VyZSgoKSA9PiB7XG4gICAgICAgICAgICB0YXNrUXVldWVkID0gZmFsc2U7XG4gICAgICAgICAgICB2aXNpYmxlSWZyYW1lSWRzLm1hcChnZXREaW1lbnNpb25zKS5mb3JFYWNoKChkYXRhKSA9PiB7XG4gICAgICAgICAgICAgICAgc2VuZENvb3JkaW5hdGVzKGRhdGFbMF0sIGRhdGFbMV0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5jb25zdCBhZGRTY3JvbGxMaXN0ZW5lciA9IChpZnJhbWUsIHJlc3BvbmQpID0+IHtcbiAgICBpZiAoaWZyYW1lQ291bnRlciA9PT0gMCkge1xuICAgICAgICB3aW5kb3cuYWRkRXZlbnRMaXN0ZW5lcignc2Nyb2xsJywgb25TY3JvbGwsIHtcbiAgICAgICAgICAgIHBhc3NpdmU6IHRydWUsXG4gICAgICAgIH0pO1xuICAgICAgICBvYnNlcnZlciA9IG5ldyBJbnRlcnNlY3Rpb25PYnNlcnZlcihvbkludGVyc2VjdCk7XG4gICAgfVxuICAgIGlmcmFtZXNbaWZyYW1lLmlkXSA9IHtcbiAgICAgICAgbm9kZTogaWZyYW1lLFxuICAgICAgICB2aXNpYmxlOiBmYWxzZSxcbiAgICAgICAgcmVzcG9uZCxcbiAgICB9O1xuICAgIGlmcmFtZUNvdW50ZXIgKz0gMTtcbiAgICBpZiAob2JzZXJ2ZXIpIHtcbiAgICAgICAgb2JzZXJ2ZXIub2JzZXJ2ZShpZnJhbWUpO1xuICAgIH1cbiAgICB2b2lkIGZhc3Rkb21cbiAgICAgICAgLm1lYXN1cmUoKCkgPT4gaWZyYW1lLmdldEJvdW5kaW5nQ2xpZW50UmVjdCgpKVxuICAgICAgICAudGhlbigoZG9tUmVjdCkgPT4ge1xuICAgICAgICBzZW5kQ29vcmRpbmF0ZXMoaWZyYW1lLmlkLCBkb21SZWN0KTtcbiAgICB9KTtcbn07XG5jb25zdCByZW1vdmVTY3JvbGxMaXN0ZW5lciA9IChpZnJhbWUpID0+IHtcbiAgICBpZiAoaWZyYW1lLmlkIGluIGlmcmFtZXMpIHtcbiAgICAgICAgaWYgKG9ic2VydmVyKSB7XG4gICAgICAgICAgICBvYnNlcnZlci51bm9ic2VydmUoaWZyYW1lKTtcbiAgICAgICAgfVxuICAgICAgICBkZWxldGUgaWZyYW1lc1tpZnJhbWUuaWRdO1xuICAgICAgICBpZnJhbWVDb3VudGVyIC09IDE7XG4gICAgfVxuICAgIGlmIChpZnJhbWVDb3VudGVyID09PSAwKSB7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKCdzY3JvbGwnLCBvblNjcm9sbCk7XG4gICAgICAgIGlmIChvYnNlcnZlcikge1xuICAgICAgICAgICAgb2JzZXJ2ZXIuZGlzY29ubmVjdCgpO1xuICAgICAgICAgICAgb2JzZXJ2ZXIgPSBudWxsO1xuICAgICAgICB9XG4gICAgfVxufTtcbmNvbnN0IGlzQ2FsbGFibGUgPSAoeCkgPT4gdHlwZW9mIHggPT09ICdmdW5jdGlvbic7XG5jb25zdCBpbml0ID0gKHJlZ2lzdGVyKSA9PiB7XG4gICAgcmVnaXN0ZXIoJ3Njcm9sbCcsIChyZXNwb25kLCBzdGFydCwgaWZyYW1lKSA9PiB7XG4gICAgICAgIGlmICghaWZyYW1lKVxuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICBpZiAoc3RhcnQgJiYgaXNDYWxsYWJsZShyZXNwb25kKSkge1xuICAgICAgICAgICAgYWRkU2Nyb2xsTGlzdGVuZXIoaWZyYW1lLCByZXNwb25kKTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJlbW92ZVNjcm9sbExpc3RlbmVyKGlmcmFtZSk7XG4gICAgICAgIH1cbiAgICB9KTtcbn07XG5leHBvcnQgY29uc3QgXyA9IHsgYWRkU2Nyb2xsTGlzdGVuZXIsIHJlbW92ZVNjcm9sbExpc3RlbmVyLCByZXNldCB9O1xuZXhwb3J0IHsgaW5pdCB9O1xuIiwiaW1wb3J0IHsgaXNPYmplY3QgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBzZW5kUHJvZ3Jlc3NPblVubG9hZE9uY2UsIHVwZGF0ZVZpZGVvUHJvZ3Jlc3MsIH0gZnJvbSAnLi4vdmlkZW8tcHJvZ3Jlc3MtcmVwb3J0aW5nJztcbmNvbnN0IGluaXRNZXNzZW5nZXJWaWRlb1Byb2dyZXNzUmVwb3J0aW5nID0gKHJlZ2lzdGVyKSA9PiB7XG4gICAgcmVnaXN0ZXIoJ3ZpZGVvLXByb2dyZXNzJywgYXN5bmMgKHNwZWNzLCByZXQsIGlmcmFtZSkgPT4ge1xuICAgICAgICBjb25zdCBhZFNsb3QgPSBpZnJhbWU/LmNsb3Nlc3QoJy5qcy1hZC1zbG90Jyk7XG4gICAgICAgIGlmIChhZFNsb3QgJiZcbiAgICAgICAgICAgIGlzT2JqZWN0KHNwZWNzKSAmJlxuICAgICAgICAgICAgJ3Byb2dyZXNzJyBpbiBzcGVjcyAmJlxuICAgICAgICAgICAgdHlwZW9mIHNwZWNzLnByb2dyZXNzID09PSAnbnVtYmVyJykge1xuICAgICAgICAgICAgdm9pZCBzZW5kUHJvZ3Jlc3NPblVubG9hZE9uY2UoKTtcbiAgICAgICAgICAgIHVwZGF0ZVZpZGVvUHJvZ3Jlc3MoYWRTbG90LmlkLCBzcGVjcy5wcm9ncmVzcyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IGluaXRNZXNzZW5nZXJWaWRlb1Byb2dyZXNzUmVwb3J0aW5nIH07XG4iLCJpbXBvcnQgeyBnZXRWaWV3cG9ydCB9IGZyb20gJy4uL2RldGVjdC9kZXRlY3Qtdmlld3BvcnQnO1xuaW1wb3J0IGZhc3Rkb20gZnJvbSAnLi4vZmFzdGRvbS1wcm9taXNlJztcbmxldCB3ID0gd2luZG93O1xubGV0IGlmcmFtZXMgPSB7fTtcbmxldCBpZnJhbWVDb3VudGVyID0gMDtcbmxldCB0YXNrUXVldWVkID0gZmFsc2U7XG5jb25zdCBsYXN0Vmlld3BvcnRSZWFkID0gKCkgPT4gZmFzdGRvbS5tZWFzdXJlKCgpID0+IGdldFZpZXdwb3J0KCkpO1xuY29uc3QgcmVzZXQgPSAod2luZG93XykgPT4ge1xuICAgIHcgPSB3aW5kb3dfID8/IHdpbmRvdztcbiAgICB0YXNrUXVldWVkID0gZmFsc2U7XG4gICAgaWZyYW1lcyA9IHt9O1xuICAgIGlmcmFtZUNvdW50ZXIgPSAwO1xufTtcbmNvbnN0IHNlbmRWaWV3cG9ydERpbWVuc2lvbnMgPSAoaWZyYW1lSWQsIHZpZXdwb3J0KSA9PiB7XG4gICAgaWZyYW1lc1tpZnJhbWVJZF0/LnJlc3BvbmQobnVsbCwgdmlld3BvcnQpO1xufTtcbi8qKlxuICogV2hlbiB0aGUgdmlld3BvcnQgcmVzaXplcyBzZW5kIHZpZXdwb3J0IGRpbWVuc2lvbnNcbiAqXG4gKiB0byBhbGwgcmVnaXN0ZXJlZCBpRnJhbWVzXG4gKi9cbmNvbnN0IG9uUmVzaXplID0gKCkgPT4ge1xuICAgIGlmICghdGFza1F1ZXVlZCkge1xuICAgICAgICB0YXNrUXVldWVkID0gdHJ1ZTtcbiAgICAgICAgdm9pZCBsYXN0Vmlld3BvcnRSZWFkKCkudGhlbigodmlld3BvcnQpID0+IHtcbiAgICAgICAgICAgIE9iamVjdC5rZXlzKGlmcmFtZXMpLmZvckVhY2goKGlmcmFtZUlkKSA9PiB7XG4gICAgICAgICAgICAgICAgc2VuZFZpZXdwb3J0RGltZW5zaW9ucyhpZnJhbWVJZCwgdmlld3BvcnQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB0YXNrUXVldWVkID0gZmFsc2U7XG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5jb25zdCBhZGRSZXNpemVMaXN0ZW5lciA9IChpZnJhbWUsIHJlc3BvbmQpID0+IHtcbiAgICAvKipcbiAgICAgKiBJbml0aWFsaXNlIHJlc2l6ZSBsaXN0ZW5lclxuICAgICAqL1xuICAgIGlmIChpZnJhbWVDb3VudGVyID09PSAwKSB7XG4gICAgICAgIHcuYWRkRXZlbnRMaXN0ZW5lcigncmVzaXplJywgb25SZXNpemUpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBZGQgdG8gdGhlIG1hcCBvZiBhbGwgaUZyYW1lcyB3aXRoIHRoZWlyIHJlc3BlY3RpdmVcbiAgICAgKiByZXNwb25kIGZ1bmN0aW9uc1xuICAgICAqL1xuICAgIGlmcmFtZXNbaWZyYW1lLmlkXSA9IHtcbiAgICAgICAgbm9kZTogaWZyYW1lLFxuICAgICAgICByZXNwb25kLFxuICAgIH07XG4gICAgaWZyYW1lQ291bnRlciArPSAxO1xuICAgIC8qKlxuICAgICAqIFNlbmQgdmlld3BvcnQgZGltZW5zaW9ucyBvbiBmaXJzdCByZXF1ZXN0XG4gICAgICovXG4gICAgcmV0dXJuIGxhc3RWaWV3cG9ydFJlYWQoKS50aGVuKCh2aWV3cG9ydCkgPT4ge1xuICAgICAgICBzZW5kVmlld3BvcnREaW1lbnNpb25zKGlmcmFtZS5pZCwgdmlld3BvcnQpO1xuICAgIH0pO1xufTtcbmNvbnN0IHJlbW92ZVJlc2l6ZUxpc3RlbmVyID0gKGlmcmFtZSkgPT4ge1xuICAgIGRlbGV0ZSBpZnJhbWVzW2lmcmFtZS5pZF07XG4gICAgaWZyYW1lQ291bnRlciAtPSAxO1xuICAgIGlmIChpZnJhbWVDb3VudGVyID09PSAwKSB7XG4gICAgICAgIHcucmVtb3ZlRXZlbnRMaXN0ZW5lcigncmVzaXplJywgb25SZXNpemUpO1xuICAgIH1cbn07XG5jb25zdCBvbk1lc3NhZ2UgPSAocmVzcG9uZCwgc3RhcnQsIGlmcmFtZSkgPT4ge1xuICAgIGlmICghaWZyYW1lKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHR5cGVvZiBzdGFydCAhPT0gJ2Jvb2xlYW4nKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgaWYgKHN0YXJ0KSB7XG4gICAgICAgIHZvaWQgYWRkUmVzaXplTGlzdGVuZXIoaWZyYW1lLCByZXNwb25kKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJlbW92ZVJlc2l6ZUxpc3RlbmVyKGlmcmFtZSk7XG4gICAgfVxufTtcbmNvbnN0IGluaXQgPSAocmVnaXN0ZXIpID0+IHtcbiAgICByZWdpc3Rlcigndmlld3BvcnQnLCBvbk1lc3NhZ2UpO1xufTtcbmV4cG9ydCBjb25zdCBfID0geyBhZGRSZXNpemVMaXN0ZW5lciwgcmVtb3ZlUmVzaXplTGlzdGVuZXIsIHJlc2V0LCBvbk1lc3NhZ2UgfTtcbmV4cG9ydCB7IGluaXQgfTtcbiIsImNvbnN0IGlzVFBDVGVzdFBheWxvYWQgPSAocGF5bG9hZCkgPT4gdHlwZW9mIHBheWxvYWQgPT09ICdvYmplY3QnICYmXG4gICAgcGF5bG9hZCAhPT0gbnVsbCAmJlxuICAgICd0cGNUZXN0JyBpbiBwYXlsb2FkICYmXG4gICAgdHlwZW9mIHBheWxvYWQudHBjVGVzdCA9PT0gJ2Jvb2xlYW4nO1xuLyoqXG4gKiBDaGVjayBpZiB0aGlyZCBwYXJ0eSBjb29raWVzIGFyZSBlbmFibGVkXG4gKiBUaGlzIGlzIGRvbmUgYnkgY3JlYXRpbmcgYW4gaWZyYW1lIG9uIGFub3RoZXIgZG9tYWluIGFuZCBjaGVja2luZyBpZiBpdCBjYW4gYWNjZXNzIGNvb2tpZXNcbiAqKi9cbmNvbnN0IGNoZWNrVGhpcmRQYXJ0eUNvb2tpZXNFbmFibGVkID0gKCkgPT4ge1xuICAgIGNvbnN0IGNyb3NzU2l0ZUlyYW1lID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnaWZyYW1lJyk7XG4gICAgY3Jvc3NTaXRlSXJhbWUuc3R5bGUuZGlzcGxheSA9ICdub25lJztcbiAgICBjcm9zc1NpdGVJcmFtZS5zcmMgPSBgJHt3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLmZyb250ZW5kQXNzZXRzRnVsbFVSTH1jb21tZXJjaWFsL3RwYy10ZXN0L3YyL2luZGV4Lmh0bWxgO1xuICAgIHdpbmRvdy5hZGRFdmVudExpc3RlbmVyKCdtZXNzYWdlJywgKHsgZGF0YSB9KSA9PiB7XG4gICAgICAgIGlmIChpc1RQQ1Rlc3RQYXlsb2FkKGRhdGEpKSB7XG4gICAgICAgICAgICBjb25zdCB7IGhhc1N0b3JhZ2VBY2Nlc3MgfSA9IGRhdGE7XG4gICAgICAgICAgICAvLyBvbmx5IHNldCB0YXJnZXRpbmcgaWYgdGhlIHZhbHVlIGlzIGRlZmluZWRcbiAgICAgICAgICAgIGlmIChoYXNTdG9yYWdlQWNjZXNzICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnXG4gICAgICAgICAgICAgICAgICAgIC5wdWJhZHMoKVxuICAgICAgICAgICAgICAgICAgICAuc2V0VGFyZ2V0aW5nKCczcGMnLCBbaGFzU3RvcmFnZUFjY2VzcyA/ICd0JyA6ICdmJ10pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfSk7XG4gICAgZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChjcm9zc1NpdGVJcmFtZSk7XG59O1xuZXhwb3J0IHsgY2hlY2tUaGlyZFBhcnR5Q29va2llc0VuYWJsZWQgfTtcbiIsImltcG9ydCB7IGlzSW5Vc2EgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL2dlby9nZW8tdXRpbHMnO1xuaW1wb3J0IHsgY21wLCBnZXRDb29raWUsIGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IGdldEFkbWlyYWxBYlRlc3RWYXJpYW50LCByZWNvcmRBZG1pcmFsT3BoYW5FdmVudCwgc2V0QWRtaXJhbFRhcmdldGluZywgfSBmcm9tICcuLi8uLi9pbml0L2NvbnNlbnRlZC9hZG1pcmFsJztcbmNvbnN0IEJBU0VfQUpBWF9VUkwgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN0YWdlID09PSAnQ09ERSdcbiAgICA/ICdodHRwczovL2NvZGUuYXBpLm5leHRnZW4uZ3VhcmRpYW5hcHBzLmNvLnVrJ1xuICAgIDogJ2h0dHBzOi8vYXBpLm5leHRnZW4uZ3VhcmRpYW5hcHBzLmNvLnVrJztcbmNvbnN0IGFiVGVzdFZhcmlhbnQgPSBnZXRBZG1pcmFsQWJUZXN0VmFyaWFudCgpO1xuY29uc3QgaXNJblZhcmlhbnQgPSBhYlRlc3RWYXJpYW50Py5zdGFydHNXaXRoKCd2YXJpYW50JykgPz8gZmFsc2U7XG4vKipcbiAqIFRoZSBBZG1pcmFsIGJvb3RzdHJhcCBzY3JpcHQgc2hvdWxkIG9ubHkgcnVuIHVuZGVyIHRoZSBmb2xsb3dpbmcgY29uZGl0aW9uczpcbiAqXG4gKiAtIFNob3VsZCBub3QgcnVuIGlmIHRoZSBDTVAgaXMgZHVlIHRvIHNob3dcbiAqIC0gU2hvdWxkIG9ubHkgcnVuIGluIHRoZSBVU1xuICogLSBTaG91bGQgb25seSBydW4gaWYgaW4gdGhlIHZhcmlhbnQgb2YgdGhlIEFCIHRlc3RcbiAqIC0gU2hvdWxkIG5vdCBydW4gaWYgdGhlIGd1X2hpZGVfc3VwcG9ydF9tZXNzYWdpbmcgY29va2llIGlzIHNldFxuICogLSBTaG91bGQgbm90IHJ1biBmb3IgY29udGVudCBtYXJrZWQgYXM6IHNob3VsZEhpZGVBZHZlcnRzLCBzaG91bGRIaWRlUmVhZGVyUmV2ZW51ZSwgaXNTZW5zaXRpdmVcbiAqIC0gU2hvdWxkIG5vdCBydW4gZm9yIHBhaWQtY29udGVudCBzcG9uc29yc2hpcCB0eXBlIChpbmNsdWRlcyBIb3N0ZWQgQ29udGVudClcbiAqIC0gU2hvdWxkIG5vdCBydW4gZm9yIGNlcnRhaW4gc2VjdGlvbnNcbiAqL1xuY29uc3Qgc2hvdWxkUnVuID0gY21wLmhhc0luaXRpYWxpc2VkKCkgJiZcbiAgICAhY21wLndpbGxTaG93UHJpdmFjeU1lc3NhZ2VTeW5jKCkgJiZcbiAgICBpc0luVXNhKCkgJiZcbiAgICBpc0luVmFyaWFudCAmJlxuICAgICFnZXRDb29raWUoe1xuICAgICAgICBuYW1lOiAnZ3VfaGlkZV9zdXBwb3J0X21lc3NhZ2luZycsXG4gICAgICAgIHNob3VsZE1lbW9pemU6IHRydWUsXG4gICAgfSkgJiZcbiAgICAhd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnNob3VsZEhpZGVBZHZlcnRzICYmXG4gICAgIXdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5zaG91bGRIaWRlUmVhZGVyUmV2ZW51ZSAmJlxuICAgICF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2UuaXNTZW5zaXRpdmUgJiZcbiAgICB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2Uuc3BvbnNvcnNoaXBUeXBlICE9PSAncGFpZC1jb250ZW50JyAmJlxuICAgICFbXG4gICAgICAgICdhYm91dCcsXG4gICAgICAgICdpbmZvJyxcbiAgICAgICAgJ21lbWJlcnNoaXAnLFxuICAgICAgICAnaGVscCcsXG4gICAgICAgICdndWFyZGlhbi1saXZlLWF1c3RyYWxpYScsXG4gICAgICAgICdnbm0tYXJjaGl2ZScsXG4gICAgICAgICdndWFyZGlhbi1sYWJzJyxcbiAgICAgICAgJ3RoZWZpbHRlcicsXG4gICAgXS5pbmNsdWRlcyh3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnBhZ2Uuc2VjdGlvbik7XG4vKipcbiAqIEFkbWlyYWwgYWRibG9jayByZWNvdmVyeSB0YWdcbiAqL1xuY29uc3QgYWRtaXJhbFRhZyA9IHtcbiAgICBzaG91bGRSdW4sXG4gICAgbmFtZTogJ2FkbWlyYWwnLFxuICAgIGFzeW5jOiB0cnVlLFxuICAgIHVybDogYCR7QkFTRV9BSkFYX1VSTH0vY29tbWVyY2lhbC9hZG1pcmFsLWJvb3RzdHJhcC5qc2AsXG4gICAgYmVmb3JlTG9hZDogKCkgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAn8J+boe+4jyBBZG1pcmFsIC0gbG9hZGluZyBzY3JpcHQgb24gdGhlIHBhZ2UnKTtcbiAgICAgICAgcmVjb3JkQWRtaXJhbE9waGFuRXZlbnQoeyBhY3Rpb246ICdJTlNFUlQnIH0pO1xuICAgICAgICAvKiogU2VuZCB0YXJnZXRpbmcgdG8gQWRtaXJhbCBmb3IgQUIgdGVzdCB2YXJpYW50cyAqL1xuICAgICAgICBpZiAoaXNJblZhcmlhbnQgJiYgYWJUZXN0VmFyaWFudCkge1xuICAgICAgICAgICAgc2V0QWRtaXJhbFRhcmdldGluZygnZ3VBYlRlc3QnLCBhYlRlc3RWYXJpYW50KTtcbiAgICAgICAgICAgIGxvZygnY29tbWVyY2lhbCcsIGDwn5uh77iPIEFkbWlyYWwgLSBzZXR0aW5nIHRhcmdldGluZzogZ3VBYlRlc3QgPSAke2FiVGVzdFZhcmlhbnR9YCk7XG4gICAgICAgIH1cbiAgICB9LFxufTtcbmV4cG9ydCB7IGFkbWlyYWxUYWcgfTtcbiIsIi8qKlxuICogSUFTIHNjcmlwdCBmaWx0ZXJzIGJhZCBhZHNcbiAqIGh0dHBzOi8vaW50ZWdyYWxhZHMuY29tL3VrL1xuICogQHBhcmFtICB7fSB7c2hvdWxkUnVufVxuICovXG5leHBvcnQgY29uc3QgaWFzID0ge1xuICAgIHNob3VsZFJ1bjogdHJ1ZSxcbiAgICB1cmw6ICcvL2Nkbi5hZHNhZmVwcm90ZWN0ZWQuY29tL2lhc1BFVC4xLmpzJyxcbiAgICBuYW1lOiAnaWFzJyxcbn07XG4iLCJpbXBvcnQgeyBpc0luQXVPck56IH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9nZW8vZ2VvLXV0aWxzJztcbi8vIG5vbF90IGlzIGEgZ2xvYmFsIGZ1bmN0aW9uIGRlZmluZWQgYnkgdGhlIElNUiB3b3JsZHdpZGUgbGlicmFyeVxuY29uc3Qgb25Mb2FkID0gKCkgPT4ge1xuICAgIGNvbnN0IHB2YXIgPSB7XG4gICAgICAgIGNpZDogJ2F1LWd1YXJkaWFuJyxcbiAgICAgICAgY29udGVudDogJzAnLFxuICAgICAgICBzZXJ2ZXI6ICdzZWN1cmUtZ2wnLFxuICAgIH07XG4gICAgY29uc3QgdHJhYyA9IHdpbmRvdy5ub2xfdChwdmFyKTtcbiAgICB0cmFjLnJlY29yZCgpLnBvc3QoKTtcbn07XG5leHBvcnQgY29uc3QgaW1yV29ybGR3aWRlTGVnYWN5ID0ge1xuICAgIHNob3VsZFJ1bjogISF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLmltcldvcmxkd2lkZSAmJiBpc0luQXVPck56KCksXG4gICAgdXJsOiAnLy9zZWN1cmUtYXUuaW1yd29ybGR3aWRlLmNvbS92NjAuanMnLFxuICAgIG9uTG9hZCxcbn07XG4iLCJpbXBvcnQgeyBpc0luQXVPck56IH0gZnJvbSAnQGd1YXJkaWFuL2NvbW1lcmNpYWwtY29yZS9nZW8vZ2VvLXV0aWxzJztcbi8vIE5PTENNQiBpcyBhIGdsb2JhbCBmdW5jdGlvbiBkZWZpbmVkIGJ5IHRoZSBJTVIgd29ybGR3aWRlIGxpYnJhcnlcbmNvbnN0IGd1TWV0YWRhdGEgPSB7XG4gICAgYm9va3M6ICdQNTAzM0EwODQtRTlCRi00NTNBLTkxRDMtQzU1ODc1MUQ5QTg1JyxcbiAgICBidXNpbmVzczogJ1A1QjEwOTYwOS02MjIzLTQ1QkEtQjA1Mi01NUYzNEE3OUQ3QUQnLFxuICAgIGNvbW1lbnRpc2ZyZWU6ICdQQTg3OEVGQzctOTNDOC00MzUyLTkwNUUtOUUwMzg4M0ZENkJEJyxcbiAgICBhcnRhbmRkZXNpZ246ICdQRTUwNzZFNkYtQjg1RC00QjQ1LTk1MzYtRjE1MEVGM0ZDODUzJyxcbiAgICBjdWx0dXJlOiAnUEU1MDc2RTZGLUI4NUQtNEI0NS05NTM2LUYxNTBFRjNGQzg1MycsXG4gICAgc3RhZ2U6ICdQRTUwNzZFNkYtQjg1RC00QjQ1LTk1MzYtRjE1MEVGM0ZDODUzJyxcbiAgICBlZHVjYXRpb246ICdQNEEwMURCNzQtNUI5Ny00MzVBLTg5RjAtQzA3RUEyQzczOUVDJyxcbiAgICBlbnZpcm9ubWVudDogJ1AyRjM0QTM4OC1BMjgwLTRDM0YtQUY0My1GQUYxNkVGQ0I3QjEnLFxuICAgIGNpdGllczogJ1AyRjM0QTM4OC1BMjgwLTRDM0YtQUY0My1GQUYxNkVGQ0I3QjEnLFxuICAgICdnbG9iYWwtZGV2ZWxvcG1lbnQnOiAnUDJGMzRBMzg4LUEyODAtNEMzRi1BRjQzLUZBRjE2RUZDQjdCMScsXG4gICAgJ3N1c3RhaW5hYmxlLWJ1c2luZXNzJzogJ1AyRjM0QTM4OC1BMjgwLTRDM0YtQUY0My1GQUYxNkVGQ0I3QjEnLFxuICAgIGZhc2hpb246ICdQQ0YzNDU2MjEtRjM0RC00MEIyLTg1MkMtNjIyM0M5QzhGMUUyJyxcbiAgICBmaWxtOiAnUDg3OEVDRkE1LTE0QTctNDAzOC05OTI0LTM2OTZDOTM3MDZGQycsXG4gICAgbGF3OiAnUDFGQTEyOURELTlCOUUtNDlCQi05OEE0LUFBN0VEODUyM0RGRCcsXG4gICAgbGlmZWFuZHN0eWxlOiAnUENGRTA0MjUwLUU1RjYtNDhDNy05MURCLTVDRUQ2ODU0ODE4QycsXG4gICAgbWVkaWE6ICdQMTQzNERDNkQtNjU4NS00OTMyLUFFMTctMjg2NENEMEFBRTk5JyxcbiAgICBtb25leTogJ1BCNzFFN0YxRS1GMjMxLTRGNzMtOUNDOC1CRTg4MjJBREQwQzInLFxuICAgIG11c2ljOiAnUDc4MzgyREVFLUNDOUItNEIzNi1CRDI3LTgwOTAwN0JGRjMwMCcsXG4gICAgaW50ZXJuYXRpb25hbDogJ1A1MDUxODJBQS0xRDcxLTQ5RDgtODI4Ny1BQTIyMkNEMDU0MjQnLFxuICAgIGF1OiAnUDUwNTE4MkFBLTFENzEtNDlEOC04Mjg3LUFBMjIyQ0QwNTQyNCcsXG4gICAgJ2F1c3RyYWxpYS1uZXdzJzogJ1A1MDUxODJBQS0xRDcxLTQ5RDgtODI4Ny1BQTIyMkNEMDU0MjQnLFxuICAgIHVrOiAnUDUwNTE4MkFBLTFENzEtNDlEOC04Mjg3LUFBMjIyQ0QwNTQyNCcsXG4gICAgJ3VrLW5ld3MnOiAnUDUwNTE4MkFBLTFENzEtNDlEOC04Mjg3LUFBMjIyQ0QwNTQyNCcsXG4gICAgdXM6ICdQNTA1MTgyQUEtMUQ3MS00OUQ4LTgyODctQUEyMjJDRDA1NDI0JyxcbiAgICAndXMtbmV3cyc6ICdQNTA1MTgyQUEtMUQ3MS00OUQ4LTgyODctQUEyMjJDRDA1NDI0JyxcbiAgICB3b3JsZDogJ1A1MDUxODJBQS0xRDcxLTQ5RDgtODI4Ny1BQTIyMkNEMDU0MjQnLFxuICAgIHBvbGl0aWNzOiAnUDVCNzQ2OEUzLUNFMDQtNDBGRC05NDQ0LTIyRkI4NzJGRTgzRScsXG4gICAgY2FyZWVyczogJ1AzNjM3REM2Qi1FNDNDLTRFOTItQjIyQy0zRjI1NUNDNTczREEnLFxuICAgICdjdWx0dXJlLXByb2Zlc3Npb25hbHMtbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAnZ2xvYmFsLWRldmVsb3BtZW50LXByb2Zlc3Npb25hbHMtbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAnZ292ZXJubWVudC1jb21wdXRpbmctbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAnZ3VhcmRpYW4tcHJvZmVzc2lvbmFsJzogJ1AzNjM3REM2Qi1FNDNDLTRFOTItQjIyQy0zRjI1NUNDNTczREEnLFxuICAgICdoZWFsdGhjYXJlLW5ldHdvcmsnOiAnUDM2MzdEQzZCLUU0M0MtNEU5Mi1CMjJDLTNGMjU1Q0M1NzNEQScsXG4gICAgJ2hpZ2hlci1lZHVjYXRpb24tbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAnaG91c2luZy1uZXR3b3JrJzogJ1AzNjM3REM2Qi1FNDNDLTRFOTItQjIyQy0zRjI1NUNDNTczREEnLFxuICAgICdsb2NhbC1nb3Zlcm5tZW50LW5ldHdvcmsnOiAnUDM2MzdEQzZCLUU0M0MtNEU5Mi1CMjJDLTNGMjU1Q0M1NzNEQScsXG4gICAgJ2xvY2FsLWxlYWRlcnMtbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAncHVibGljLWxlYWRlcnMtbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAnc21hbGwtYnVzaW5lc3MtbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAnc29jaWFsLWNhcmUtbmV0d29yayc6ICdQMzYzN0RDNkItRTQzQy00RTkyLUIyMkMtM0YyNTVDQzU3M0RBJyxcbiAgICAndGVhY2hlci1uZXR3b3JrJzogJ1AzNjM3REM2Qi1FNDNDLTRFOTItQjIyQy0zRjI1NUNDNTczREEnLFxuICAgICd2b2x1bnRhcnktc2VjdG9yLW5ldHdvcmsnOiAnUDM2MzdEQzZCLUU0M0MtNEU5Mi1CMjJDLTNGMjU1Q0M1NzNEQScsXG4gICAgJ3dvbWVuLWluLWxlYWRlcnNoaXAnOiAnUDM2MzdEQzZCLUU0M0MtNEU5Mi1CMjJDLTNGMjU1Q0M1NzNEQScsXG4gICAgc2NpZW5jZTogJ1BEQUQ2QkMyMi1DOTdCLTQxNTEtOTU2Qi03RjA2OUIyQzU2RTknLFxuICAgIHNvY2lldHk6ICdQN0FGNEE1OTItOTZGQi00MjU1LUIzM0YtMzUyNDA2RjRDN0QyJyxcbiAgICBzcG9ydDogJ1BDQzFBRUJCNi03RDFBLTRGMzQtODI1Ni1FRkMzMTRFNUQwQzMnLFxuICAgIGZvb3RiYWxsOiAnUENDMUFFQkI2LTdEMUEtNEYzNC04MjU2LUVGQzMxNEU1RDBDMycsXG4gICAgdGVjaG5vbG9neTogJ1AyOUVGOTkxQS0zRkVFLTQyMTUtOUYwMy01OEVBQ0E4Mjg2QjknLFxuICAgIHRyYXZlbDogJ1BEMUNFREMzRS0yNjUzLTRDQjYtQTRGRC04QTMxNURFMDc1NDgnLFxuICAgICd0di1hbmQtcmFkaW8nOiAnUDY2RTQ4OTA5LThGQzktNDlFOC1BN0U2LTBEMzFDNjE4MDVBRCcsXG4gICAgJ2JyYW5kLW9ubHknOiAnUDBFRTBGNEY0LThEN0MtNDA4Mi1BMkE0LTgyQzg0NzI4REM1OScsXG59O1xuY29uc3Qgb25Mb2FkID0gKCkgPT4ge1xuICAgIGNvbnN0IHNlY3Rpb25Gcm9tTWV0YSA9IHdpbmRvdy5ndWFyZGlhbi5jb25maWcucGFnZS5zZWN0aW9uLnRvTG93ZXJDYXNlKCk7XG4gICAgY29uc3Qgc3ViQnJhbmRBcElkID0gKGd1TWV0YWRhdGFbc2VjdGlvbkZyb21NZXRhXSA/P1xuICAgICAgICBndU1ldGFkYXRhWydicmFuZC1vbmx5J10pO1xuICAgIGNvbnN0IHNlY3Rpb25SZWYgPSBzZWN0aW9uRnJvbU1ldGEgaW4gZ3VNZXRhZGF0YVxuICAgICAgICA/IHNlY3Rpb25Gcm9tTWV0YVxuICAgICAgICA6ICdUaGUgR3VhcmRpYW4gLSBicmFuZCBvbmx5JztcbiAgICBjb25zdCBub2xnZ0dsb2JhbFBhcmFtcyA9IHtcbiAgICAgICAgc2Zjb2RlOiAnZGNyJyxcbiAgICAgICAgYXBpZDogc3ViQnJhbmRBcElkLFxuICAgICAgICBhcG46ICd0aGVndWFyZGlhbicsXG4gICAgfTtcbiAgICBjb25zdCBuU2RrSW5zdGFuY2UgPSB3aW5kb3cuTk9MQ01CLmdldEluc3RhbmNlKG5vbGdnR2xvYmFsUGFyYW1zLmFwaWQpO1xuICAgIG5TZGtJbnN0YW5jZS5nZ0luaXRpYWxpemUobm9sZ2dHbG9iYWxQYXJhbXMpO1xuICAgIGNvbnN0IGRjclN0YXRpY01ldGFkYXRhID0ge1xuICAgICAgICB0eXBlOiAnc3RhdGljJyxcbiAgICAgICAgYXNzZXRpZDogd2luZG93Lmd1YXJkaWFuLmNvbmZpZy5wYWdlLnBhZ2VJZCxcbiAgICAgICAgc2VjdGlvbjogc2VjdGlvblJlZixcbiAgICB9O1xuICAgIG5TZGtJbnN0YW5jZS5nZ1BNKCdzdGF0aWNzdGFydCcsIGRjclN0YXRpY01ldGFkYXRhKTtcbn07XG5leHBvcnQgY29uc3QgaW1yV29ybGR3aWRlID0ge1xuICAgIHNob3VsZFJ1bjogISF3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLnN3aXRjaGVzLmltcldvcmxkd2lkZSAmJiBpc0luQXVPck56KCksXG4gICAgdXJsOiAnLy9zZWN1cmUtZGNyLmltcndvcmxkd2lkZS5jb20vbm92bXMvanMvMi9nZ2NtYjUxMC5qcycsXG4gICAgb25Mb2FkLFxufTtcbiIsImNvbnN0IGhhbmRsZVF1ZXJ5U3VydmV5RG9uZSA9IChzdXJ2ZXlBdmFpbGFibGUsIHN1cnZleSkgPT4ge1xuICAgIGlmIChzdXJ2ZXlBdmFpbGFibGUpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIEB0eXBlc2NyaXB0LWVzbGludC9uby11bm5lY2Vzc2FyeS1jb25kaXRpb24gLS0gQHR5cGVzL2dvb2dsZXRhZyBkZWNsYXJlcyBpdCwgYnV0IGl0IG1heSBiZSBtaXNzaW5nXG4gICAgICAgIGlmICh3aW5kb3cuZ29vZ2xldGFnKSB7XG4gICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLmNtZC5wdXNoKCgpID0+IHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuZ29vZ2xldGFnLnB1YmFkcygpLnNldFRhcmdldGluZygnaW5pemlvJywgJ3QnKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9XG4gICAgICAgIGNvbnNvbGUubG9nKGBzdXJ2ZXlBdmFpbGFibGU6ICR7c3VydmV5Lm1lYXN1cmVtZW50SWR9YCk7XG4gICAgfVxufTtcbmNvbnN0IG9uTG9hZCA9ICgpID0+IHtcbiAgICB3aW5kb3cuX2JyYW5kbWV0cmljcyA/Pz0gW107XG4gICAgd2luZG93Ll9icmFuZG1ldHJpY3MucHVzaCh7XG4gICAgICAgIGNtZDogJ19xdWVyeVN1cnZleScsXG4gICAgICAgIHZhbDoge1xuICAgICAgICAgICAgY2FsbGJhY2s6IGhhbmRsZVF1ZXJ5U3VydmV5RG9uZSxcbiAgICAgICAgfSxcbiAgICB9KTtcbn07XG4vKipcbiAqIEFsbG93cyBjcmVhdGl2ZXMgdG8gc2hvdyBzdXJ2ZXlcbiAqIGh0dHBzOi8vdHJlbGxvLmNvbS9jL3dIZmZIVkYxLzE3MS1pbnRlZ3JhdGUtYW5kLXRlc3QtaW5pemlvXG4gKiBAcGFyYW0gIHt9IHtzaG91bGRSdW59XG4gKi9cbmV4cG9ydCBjb25zdCBpbml6aW8gPSAoeyBzaG91bGRSdW4gfSkgPT4gKHtcbiAgICBzaG91bGRSdW4sXG4gICAgdXJsOiAnLy9jZG4uYnJhbmRtZXRyaWNzLmNvbS9zdXJ2ZXkvc2NyaXB0L2U5NmQwNGM4MzIwODQ0ODhhODQxYTA2YjQ5YjhmYjJkLmpzJyxcbiAgICBuYW1lOiAnaW5pemlvJyxcbiAgICBvbkxvYWQsXG59KTtcbmV4cG9ydCBjb25zdCBfID0ge1xuICAgIG9uTG9hZCxcbiAgICBoYW5kbGVRdWVyeVN1cnZleURvbmUsXG59O1xuIiwiLyoqXG4gKiBQZXJtdXRpdmUgc2NyaXB0IHVwZGF0ZXMgbG9jYWwgdXNlciBzZWdtZW50YXRpb24gZGF0YVxuICogQHBhcmFtICB7fSB7c2hvdWxkUnVufVxuICovXG5leHBvcnQgY29uc3QgcGVybXV0aXZlID0gKHsgc2hvdWxkUnVuIH0pID0+ICh7XG4gICAgc2hvdWxkUnVuLFxuICAgIHVybDogJy8vY2RuLnBlcm11dGl2ZS5jb20vZDY2OTFhMTctNmZkYi00ZDI2LTg1ZDYtYjNkZDI3ZjU1ZjA4LXdlYi5qcycsXG4gICAgbmFtZTogJ3Blcm11dGl2ZScsXG59KTtcbiIsImNvbnN0IG9uTG9hZCA9ICgpID0+IHtcbiAgICB3aW5kb3cuZ29vZ2xlX3RyYWNrQ29udmVyc2lvbj8uKHtcbiAgICAgICAgZ29vZ2xlX2NvbnZlcnNpb25faWQ6IDk3MTIyNTY0OCxcbiAgICAgICAgZ29vZ2xlX2N1c3RvbV9wYXJhbXM6IHdpbmRvdy5nb29nbGVfdGFnX3BhcmFtcyxcbiAgICAgICAgZ29vZ2xlX3JlbWFya2V0aW5nX29ubHk6IHRydWUsXG4gICAgfSk7XG59O1xuLyoqXG4gKiBHb29nbGUgY29udmVyc2lvbiB0cmFja2luZ1xuICogaHR0cHM6Ly9zdXBwb3J0Lmdvb2dsZS5jb20vZ29vZ2xlLWFkcy9hbnN3ZXIvNjA5NTgyMVxuICogQHBhcmFtICB7fSB7c2hvdWxkUnVufVxuICovXG5leHBvcnQgY29uc3QgcmVtYXJrZXRpbmcgPSAoeyBzaG91bGRSdW4gfSkgPT4gKHtcbiAgICBzaG91bGRSdW4sXG4gICAgdXJsOiAnLy93d3cuZ29vZ2xlYWRzZXJ2aWNlcy5jb20vcGFnZWFkL2NvbnZlcnNpb25fYXN5bmMuanMnLFxuICAgIG5hbWU6ICdyZW1hcmtldGluZycsXG4gICAgb25Mb2FkLFxufSk7XG4iXSwibmFtZXMiOlsiQURfTEFCRUxfSEVJR0hUIiwiUFJFQklEX1RJTUVPVVQiLCJUT1BfQUJPVkVfTkFWX0hFSUdIVCIsImFkQmxvY2tJblVzZSIsInVuZGVmaW5lZCIsImFkRWxlbWVudEJsb2NrZWQiLCJhZCIsIm9mZnNldFBhcmVudCIsIm9mZnNldEhlaWdodCIsIm9mZnNldExlZnQiLCJvZmZzZXRUb3AiLCJvZmZzZXRXaWR0aCIsImNsaWVudEhlaWdodCIsImNsaWVudFdpZHRoIiwiYWRTdHlsZXMiLCJ3aW5kb3ciLCJnZXRDb21wdXRlZFN0eWxlIiwiZ2V0UHJvcGVydHlWYWx1ZSIsIm1vekJpbmRpbmdQcm9wIiwiaW5jbHVkZXMiLCJpc0FkQmxvY2tJblVzZSIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVxdWVzdEFuaW1hdGlvbkZyYW1lIiwiZG9jdW1lbnQiLCJjcmVhdGVFbGVtZW50Iiwic2V0QXR0cmlidXRlIiwiYm9keSIsImFwcGVuZENoaWxkIiwiRXZlbnRUaW1lciIsImFkU2l6ZXMiLCJfY29uc3RhbnRzIiwiY29uc3RhbnRzIiwiYnlwYXNzQ29tbWVyY2lhbE1ldHJpY3NTYW1wbGluZyIsImluaXRDb21tZXJjaWFsTWV0cmljcyIsImJ1aWxkUGFnZVRhcmdldGluZyIsInBvc3RNZXNzYWdlIiwiYnVpbGRJbWFBZFRhZ1VybCIsImdldFBlcm11dGl2ZVBGUFNlZ21lbnRzIiwiaXNFbGlnaWJsZUZvclRlYWRzIiwibG9nIiwiZmlsdGVyVmFsdWVzIiwiZW5jb2RlQ3VzdG9tUGFyYW1zIiwicGFyYW1zIiwiZW5jb2RlZFBhcmFtcyIsIk9iamVjdCIsImVudHJpZXMiLCJtYXAiLCJfcmVmIiwia2V5IiwidmFsdWUiLCJxdWVyeVZhbHVlIiwiQXJyYXkiLCJpc0FycmF5Iiwiam9pbiIsIlN0cmluZyIsImNvbmNhdCIsImVuY29kZVVSSUNvbXBvbmVudCIsIm1lcmdlQ3VzdG9tUGFyYW1zV2l0aFRhcmdldGluZyIsImN1c3RvbVBhcmFtcyIsImNvbnNlbnRTdGF0ZSIsImNsaWVudFNpZGVQYXJ0aWNpcGF0aW9ucyIsImlzU2lnbmVkSW4iLCJwYWdlVGFyZ2V0aW5nIiwiYWRGcmVlIiwiZSIsIm1lcmdlZEN1c3RvbVBhcmFtcyIsIl9vYmplY3RTcHJlYWQiLCJfcmVmMiIsImFkVW5pdCIsInF1ZXJ5UGFyYW1zIiwiaXUiLCJ0ZmNkIiwibnBhIiwic3oiLCJnZGZwX3JlcSIsIm91dHB1dCIsInVudmlld2VkX3Bvc2l0aW9uX3N0YXJ0IiwiZW52IiwiaW1wbCIsInZhZF90eXBlIiwidnBvcyIsInBsY210IiwiZGVzY3JpcHRpb25fdXJsIiwiZ3VhcmRpYW4iLCJjb25maWciLCJwYWdlIiwiaG9zdCIsInBhZ2VJZCIsImN1c3RfcGFyYW1zIiwicXVlcnlQYXJhbXNBcnJheSIsImsiLCJ2IiwicHVzaCIsImlzQm9vbGVhbiIsIl8iLCJwYWdlU2tpbiIsImRmcEVudiIsImxvYWRBZHZlcnQiLCJkaXNwbGF5QWRzIiwiZ29vZ2xldGFnIiwicHViYWRzIiwiZW5hYmxlU2luZ2xlUmVxdWVzdCIsImNvbGxhcHNlRW1wdHlEaXZzIiwiZW5hYmxlU2VydmljZXMiLCJmaXJzdEFkdmVydFRvTG9hZCIsImFkdmVydHNUb0xvYWQiLCJsZW5ndGgiLCJlbmFibGVMYXp5TG9hZCIsImRpc3BsYXlMYXp5QWRzIiwiZm9yRWFjaCIsImdldEFkdmVydEJ5SWQiLCJsb2NhdGlvbiIsInByb3RvY29sIiwib25TbG90TG9hZCIsImV2ZW50IiwiYWR2ZXJ0Iiwic2xvdCIsImdldFNsb3RFbGVtZW50SWQiLCJpZnJhbWUiLCJub2RlIiwiZ2V0RWxlbWVudHNCeVRhZ05hbWUiLCJpdGVtIiwiY29udGVudFdpbmRvdyIsImNvbnNvbGUiLCJpZCIsImNyZWF0ZUFkU2l6ZSIsImlzU3RyaW5nIiwicmVwb3J0RXJyb3IiLCJlbXB0eUFkdmVydCIsInJlbmRlckFkdmVydCIsInJlcG9ydEVtcHR5UmVzcG9uc2UiLCJhZFNsb3RJZCIsIk1hdGgiLCJyYW5kb20iLCJhZFVuaXRQYXRoIiwiZ2V0QWRVbml0UGF0aCIsImFkVGFyZ2V0aW5nS2V5cyIsImdldFRhcmdldGluZ0tleXMiLCJhZFRhcmdldGluZ0tWYWx1ZXMiLCJnZXRUYXJnZXRpbmciLCJhZEtleXdvcmRzIiwiRXJyb3IiLCJhZFNsb3QiLCJzaXplRXZlbnRUb0FkU2l6ZSIsInNpemUiLCJOdW1iZXIiLCJvblNsb3RSZW5kZXIiLCJpc0VtcHR5IiwiZmluaXNoZWRSZW5kZXJpbmciLCJoYXNQcmViaWRTaXplIiwibGluZUl0ZW1JZCIsImNyZWF0aXZlSWQiLCJjcmVhdGl2ZVRlbXBsYXRlSWQiLCJ0aGVuIiwiaXNSZW5kZXJlZCIsIm91dHN0cmVhbVNpemVzIiwiaXNBZFNpemUiLCJtZW1vaXplZEZldGNoTm9uUmVmcmVzaGFibGVMaW5lSXRlbUlkcyIsInNob3VsZFJlZnJlc2giLCJmYXN0ZG9tIiwiZ2V0VXJsVmFycyIsIkFEVkVSVF9SRUZSRVNIX1JBVEUiLCJzZXRBZFNsb3RNaW5IZWlnaHQiLCJjYW5TbG90QmVQYXNzZWRCYWNrIiwidmFsdWVzIiwic29tZSIsIndpZHRoIiwiaGVpZ2h0IiwiaXNTdGFuZGFyZEFkU2l6ZSIsImlzUHJveHkiLCJtZWFzdXJlIiwiZ2V0QXR0cmlidXRlIiwiaGFzTGFiZWwiLCJsYWJlbEhlaWdodCIsIm11dGF0ZSIsImFkU2xvdEhlaWdodCIsInN0eWxlIiwibWluSGVpZ2h0Iiwic2V0U2xvdEFkUmVmcmVzaCIsIm5vblJlZnJlc2hhYmxlTGluZUl0ZW1JZHMiLCJjYXRjaCIsImVycm9yIiwidmlld2FiaWxpdHlUaHJlc2hvbGRNcyIsIm9uRG9jdW1lbnRWaXNpYmxlIiwiaGlkZGVuIiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsInNldFRpbWVvdXQiLCJhZGRFdmVudExpc3RlbmVyIiwib25TbG90Vmlld2FibGVGdW5jdGlvbiIsImdldCIsIm1hcmsiLCJhZHJlZnJlc2giLCJsb2dHdW1HdW1XaW5uaW5nQmlkIiwicmVuZGVyQWR2ZXJ0TGFiZWwiLCJhZGRDbGFzc0lmSGFzQ2xhc3MiLCJuZXdDbGFzc05hbWVzIiwiaGFzQ2xhc3MiLCJjbGFzc05hbWVzIiwib25BZHZlcnRSZW5kZXJlZCIsImNsYXNzTmFtZSIsImNsYXNzTGlzdCIsImNvbnRhaW5zIiwiYWRkIiwiYWRkRmx1aWQyNTAiLCJhZGRGbHVpZCIsInJlbW92ZVN0eWxlRnJvbUFkSWZyYW1lIiwiYWRJZnJhbWUiLCJxdWVyeVNlbGVjdG9yIiwicmVtb3ZlUHJvcGVydHkiLCJzaXplQ2FsbGJhY2tzIiwiZmx1aWQiLCJ0b1N0cmluZyIsIm1wdSIsInVwZGF0ZUV4dHJhU2xvdENsYXNzZXMiLCJoYWxmUGFnZSIsInNreXNjcmFwZXIiLCJvdXRzdHJlYW1EZXNrdG9wIiwib3V0c3RyZWFtR29vZ2xlRGVza3RvcCIsIm91dHN0cmVhbU1vYmlsZSIsImdvb2dsZUNhcmQiLCJwdWJtYXRpY0ludGVyc2Nyb2xsZXIiLCJvdXRPZlBhZ2VDYWxsYmFjayIsInBhcmVudCIsInBhcmVudE5vZGUiLCJhZENvbnRhaW5lciIsImNsb3Nlc3QiLCJkaXNwbGF5Iiwib3V0T2ZQYWdlIiwiZW1wdHkiLCJtZXJjaGFuZGlzaW5nIiwiYWRkQ29udGVudENsYXNzIiwiYWRTbG90Tm9kZSIsImFkU2xvdENvbnRlbnQiLCJhZGRDb250YWluZXJDbGFzcyIsImNlbnRyZUFkU2xvdHMiLCJfYWRTbG90Tm9kZSRwYXJlbnRFbGUiLCJwYXJlbnRFbGVtZW50Iiwic2hvdWxkQ2VudHJlIiwiX2FkU2xvdE5vZGUkcGFyZW50RWxlMiIsImhhc0lmcmFtZSIsImlGcmFtZSIsInNsb3RSZW5kZXJFbmRlZEV2ZW50IiwiX3dpbmRvdyRndWFyZGlhbiRjb21tIiwibWF0Y2hpbmdBZCIsImNvbW1lcmNpYWwiLCJhOVdpbm5pbmdCaWRzIiwiZmluZCIsImJpZFJlc3BvbnNlIiwic2xvdElEIiwiaXNBOUd1bUd1bSIsImFtem5wIiwiYWR2ZXJ0aXNlcklkIiwiX3Nsb3RSZW5kZXJFbmRlZEV2ZW50IiwiY2FsbFNpemVDYWxsYmFjayIsInNpemVDYWxsYmFjayIsImFkZFJlbmRlcmVkQ2xhc3MiLCJlcnIiLCJpbml0IiwicHJlcGFyZUFkVmVyaWZpY2F0aW9uIiwiYm9vdENvbW1lcmNpYWwiLCJhZEZyZWVTbG90UmVtb3ZlIiwiaW5pdENvbXNjb3JlIiwiaW5pdERmcExpc3RlbmVycyIsImluaXREeW5hbWljQWRTbG90cyIsImluaXRGaWxsU2xvdExpc3RlbmVyIiwiaW5pdElwc29zTW9yaSIsImluaXRNZXNzZW5nZXIiLCJpbml0T3BpbmFyeVBvbGxMaXN0ZW5lciIsInByZXBhcmVBOSIsImluaXRBZG1pcmFsQWRibG9ja1JlY292ZXJ5IiwicHJlcGFyZUdvb2dsZXRhZyIsImluaXRQZXJtdXRpdmUiLCJwcmVwYXJlUHJlYmlkIiwicmVtb3ZlRGlzYWJsZWRTbG90cyIsImNsb3NlRGlzYWJsZWRTbG90cyIsImluaXRUZWFkc0Nvb2tpZWxlc3MiLCJpbml0VGhpcmRQYXJ0eVRhZ3MiLCJpbml0VHJhY2tHcGNTaWduYWwiLCJpbml0VHJhY2tTY3JvbGxEZXB0aCIsInJlbG9hZFBhZ2VPbkNvbnNlbnRDaGFuZ2UiLCJzZXRBZFRlc3RDb29raWUiLCJzZXRBZFRlc3RJbkxhYmVsc0Nvb2tpZSIsImNvbW1lcmNpYWxNb2R1bGVzIiwiYm9vdENvbW1lcmNpYWxXaGVuUmVhZHkiLCJtdXN0YXJkQ3V0IiwicG9seWZpbGxlZCIsInF1ZXVlIiwiaXNVc2VySW5WYXJpYW50IiwiYWRtaXJhbEFkYmxvY2tSZWNvdmVyeSIsImdldEFkbWlyYWxBYlRlc3RWYXJpYW50IiwicmVjb3JkQWRtaXJhbE9waGFuRXZlbnQiLCJfd2luZG93JGd1YXJkaWFuJG9waGEiLCJhY3Rpb24iLCJhYlRlc3RWYXJpYW50IiwiY29tcG9uZW50RXZlbnQiLCJjb21wb25lbnQiLCJjb21wb25lbnRUeXBlIiwiYWJUZXN0IiwibmFtZSIsInZhcmlhbnQiLCJvcGhhbiIsInJlY29yZCIsInNldEFkbWlyYWxUYXJnZXRpbmciLCJfd2luZG93JGFkbWlyYWwiLCJfd2luZG93IiwiYWRtaXJhbCIsImNhbGwiLCJmaWxsRHluYW1pY0FkU2xvdCIsImluaXRTcGFjZWZpbmRlciIsImZpbGxBZFNsb3QiLCJfYXN5bmNUb0dlbmVyYXRvciIsImFkZGl0aW9uYWxTaXplcyIsInNob3VsZEZvcmNlRGlzcGxheSIsIl94IiwiX3gyIiwiX3gzIiwiYXBwbHkiLCJhcmd1bWVudHMiLCJpbml0QXJ0aWNsZUJvZHlBZHZlcnRzIiwid3JhcFdpdGhFcnJvclJlcG9ydGluZyIsImNtZCIsImluaXRDb21tZW50c0V4cGFuZGVkQWR2ZXJ0cyIsImluaXRGb290YmFsbFJpZ2h0QWRzIiwiaW5pdEhpZ2hNZXJjaCIsImluaXRNb2JpbGVTdGlja3kiLCJpbml0TGl2ZWJsb2dBZHZlcnRzIiwiZHluYW1pY0FkU2xvdE1vZHVsZXMiLCJhbGwiLCJfcmVmMyIsInRhZyIsImlzQ3VzdG9tRXZlbnQiLCJjcmVhdGVTbG90RmlsbExpc3RlbmVyIiwic2xvdElkIiwiZGV0YWlsIiwiYWR2ZXJ0cyIsImhhcyIsImdldEVsZW1lbnRCeUlkIiwiYmFja2dyb3VuZCIsImRpc2FibGVSZWZyZXNoIiwiZnVsbHdpZHRoIiwiaW5pdEdldFBhZ2VUYXJnZXRpbmciLCJpbml0R2V0UGFnZVVybCIsImdldFN0eWxlcyIsImluaXRNZWFzdXJlQWRMb2FkIiwicGFzc2JhY2siLCJwYXNzYmFja1JlZnJlc2giLCJyZXNpemUiLCJzY3JvbGwiLCJ0eXBlIiwiaW5pdE1lc3NlbmdlclZpZGVvUHJvZ3Jlc3NSZXBvcnRpbmciLCJ2aWV3cG9ydCIsImlzVW5kZWZpbmVkIiwiaXNPcGluYXJ5RXZlbnQiLCJkYXRhIiwicG9sbCIsImRtcEludGVncmF0aW9uIiwib3BpbmFyeVBvbGxMaXN0ZW5lciIsInBlcm11dGl2ZSIsInRyYWNrIiwidm90ZSIsInN1cnZleVJlc3BvbnNlIiwic3VydmV5IiwicG9sbElkIiwic29sdXRpb24iLCJxdWVzdGlvbiIsInRleHQiLCJoZWFkZXIiLCJhbnN3ZXIiLCJsYWJlbCIsInBvc1giLCJ4IiwicG9zWSIsInkiLCJvcHRpb25JZGVudGlmaWVyIiwib3B0aW9uSUQiLCJvcHRpb25Qb3NpdGlvbiIsInBvc2l0aW9uIiwicmF3VmFsdWUiLCJ1bml0IiwiaXNJbkNhbmFkYSIsImdldENvbnNlbnRGb3IiLCJvbkNvbnNlbnQiLCJvbmNlIiwiYTlBcHN0YWciLCJjb21tZXJjaWFsRmVhdHVyZXMiLCJpc0dvb2dsZVByb3h5IiwiYTkiLCJzaG91bGRJbmNsdWRlT25seUE5Iiwic2hvdWxkTG9hZEE5IiwiaXNTZWN1cmVDb250YWN0Iiwic3dpdGNoZXMiLCJhOUhlYWRlckJpZGRpbmciLCJzaG91bGRMb2FkR29vZ2xldGFnIiwiaGFzUGFnZVNraW4iLCJzZXR1cEE5IiwiaW5pdGlhbGlzZSIsInNldHVwQTlPbmNlIiwiaGFuZGxlTWVhc3VyZURldGVjdGVkRXZlbnQiLCJpc01lYXN1cmVEZXRlY3RlZEV2ZW50IiwiYWRibG9ja2luZyIsIndoaXRlbGlzdGVkIiwic3Vic2NyaWJlZCIsIkpTT04iLCJzdHJpbmdpZnkiLCJoYW5kbGVDYW5kaWRhdGVTaG93bkV2ZW50IiwiaXNDYW5kaWRhdGVTaG93bkV2ZW50IiwiY2FuZGlkYXRlSUQiLCJoYW5kbGVDYW5kaWRhdGVEaXNtaXNzZWRFdmVudCIsImlzQ2FuZGlkYXRlRGlzbWlzc2VkRXZlbnQiLCJzZXRVcEFkbWlyYWxFdmVudExvZ2dlciIsInEiLCJsb2FkU2NyaXB0IiwiZ2V0R29vZ2xlVGFnSWQiLCJpc1VzZXJMb2dnZWRJbiIsImdldFBhZ2VUYXJnZXRpbmciLCJjaGVja1RoaXJkUGFydHlDb29raWVzRW5hYmxlZCIsInJlbW92ZVNsb3RzIiwiZmlsbFN0YXRpY0FkdmVydFNsb3RzIiwic2V0UGFnZVRhcmdldGluZyIsInNldFRhcmdldGluZyIsInNldFB1Ymxpc2hlclByb3ZpZGVkSWQiLCJnb29nbGVUYWdJZCIsInNldENvb2tpZURlcHJlY2F0aW9uTGFiZWwiLCJuYXZpZ2F0b3IiLCJfbmF2aWdhdG9yJGNvb2tpZURlcHIiLCJjb29raWVEZXByZWNhdGlvbkxhYmVsIiwiZ2V0VmFsdWUiLCJlbmFibGVUYXJnZXRpbmciLCJjYW5UYXJnZXQiLCJpc0dvb2dsZVRhZ0FsbG93ZWQiLCJjYW5SdW5Hb29nbGV0YWciLCJ0Y2Z2MiIsImhhbmRsZUxvY2FsZVBlcm1pc3Npb25zIiwidXNuYXQiLCJzZXRQcml2YWN5U2V0dGluZ3MiLCJyZXN0cmljdERhdGFQcm9jZXNzaW5nIiwiYXVzIiwibm9uUGVyc29uYWxpemVkQWRzIiwic2V0dXBBZHZlcnRpc2luZyIsImNhblJ1biIsIl93aW5kb3ckZ3VhcmRpYW4kY29uZiIsIl93aW5kb3ckZ3VhcmRpYW4kY29uZjIiLCJsaWJzIiwiYXN5bmMiLCJ1c2VyQWdlbnQiLCJrZXlzIiwicmVtb3ZlRW1wdHkiLCJwYXlsb2FkIiwiZ2VuZXJhdGVQYXlsb2FkIiwidXNlciIsImlzUGFpZENvbnRlbnQiLCJoZWFkbGluZSIsImNvbnRlbnRUeXBlIiwic2VjdGlvbiIsImF1dGhvciIsImtleXdvcmRzIiwid2ViUHVibGljYXRpb25EYXRlIiwic2VyaWVzIiwiZWRpdGlvbiIsInRvbmVJZHMiLCJzYWZlQXV0aG9ycyIsInNwbGl0Iiwic3RyIiwidHJpbSIsInNhZmVLZXl3b3JkcyIsInNhZmVQdWJsaXNoZWRBdCIsIkRhdGUiLCJ0b0lTT1N0cmluZyIsInNhZmVUb25lSWRzIiwiY2xlYW5QYXlsb2FkIiwiY29udGVudCIsInByZW1pdW0iLCJ0aXRsZSIsImF1dGhvcnMiLCJwdWJsaXNoZWRBdCIsInRvbmUiLCJpZGVudGl0eSIsImdlbmVyYXRlUGVybXV0aXZlSWRlbnRpdGllcyIsImJyb3dzZXJJZCIsInJ1blBlcm11dGl2ZSIsInBhZ2VDb25maWciLCJwZXJtdXRpdmVHbG9iYWwiLCJhZGRvbiIsInBlcm11dGl2ZUlkZW50aXRpZXMiLCJpZGVudGlmeSIsImluaXRQZXJtdXRpdmVTZWdtZW50YXRpb24iLCJuIiwibyIsInIiLCJpIiwicHJvamVjdElkIiwiYXBpS2V5IiwiZW52aXJvbm1lbnQiLCJ0IiwiYyIsImYiLCJwcm90b3R5cGUiLCJzbGljZSIsImZ1bmN0aW9uTmFtZSIsImciLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwicGFyc2UiLCJwZXJtdXRpdmVDb25maWciLCJwcmViaWQ5NDYiLCJwcmViaWQiLCJzaG91bGRMb2FkUHJlYmlkIiwicHJlYmlkSGVhZGVyQmlkZGluZyIsInNob3VsZExvYWRQcmViaWQ5NDYiLCJsb2FkUHJlYmlkIiwidGhyb3dJZlVuY29uc2VudGVkIiwiaGFzQ29uc2VudEZvclByZWJpZCIsInNldHVwUHJlYmlkIiwiX2NvbnNlbnRTdGF0ZSRhdXMiLCJfY29uc2VudFN0YXRlJHVzbmF0IiwiZnJhbWV3b3JrIiwicGVyc29uYWxpc2VkQWR2ZXJ0aXNpbmciLCJkb05vdFNlbGwiLCJtZXNzYWdlIiwic2V0dXBQcmViaWRPbmNlIiwiaXNJblVzYSIsImlzTm9uTnVsbGFibGUiLCJjcmVhdGVBZHZlcnQiLCJnZXRDdXJyZW50QnJlYWtwb2ludCIsInF1ZXVlQWR2ZXJ0IiwiZGVjaWRlQWRkaXRpb25hbFNpemVzIiwiZGF0YXNldCIsImRlc2t0b3AiLCJiaWxsYm9hcmQiLCJwaGFibGV0IiwibW9iaWxlIiwiZGVwZW5kZW5jaWVzIiwicmVhc29uIiwiaXNEQ1JNb2JpbGUiLCJpc0RvdGNvbVJlbmRlcmluZyIsInF1ZXJ5U2VsZWN0b3JBbGwiLCJhZFNsb3RTZWxlY3RvciIsImZpbHRlciIsInNldCIsInNob3VsZExhenlMb2FkIiwiYWRtaXJhbFRhZyIsImlhcyIsImltcldvcmxkd2lkZSIsImltcldvcmxkd2lkZUxlZ2FjeSIsImluaXppbyIsInJlbWFya2V0aW5nIiwiY3JlYXRlVGFnU2NyaXB0IiwiX3RhZyRvbkxvYWQiLCJzY3JpcHQiLCJ1cmwiLCJzcmMiLCJvbmxvYWQiLCJvbkxvYWQiLCJhdHRycyIsImF0dHIiLCJhZGRTY3JpcHRzIiwidGFncyIsInJlZiIsInNjcmlwdHMiLCJmcmFnIiwiY3JlYXRlRG9jdW1lbnRGcmFnbWVudCIsImhhc1NjcmlwdHNUb0luc2VydCIsIl90YWckYmVmb3JlTG9hZCIsImxvYWRlZCIsImJlZm9yZUxvYWQiLCJ1c2VJbWFnZSIsIkltYWdlIiwiaW5zZXJ0U25pcHBldCIsImluc2VydEJlZm9yZSIsImluc2VydFNjcmlwdHMiLCJhZHZlcnRpc2luZ1NlcnZpY2VzIiwicGVyZm9ybWFuY2VTZXJ2aWNlcyIsImNvbnNlbnRlZEFkdmVydGlzaW5nU2VydmljZXMiLCJsb2FkT3RoZXIiLCJfd2luZG93JGd1YXJkaWFuJGNvbmYzIiwic2hvdWxkUnVuIiwidGhpcmRQYXJ0eVRhZ3MiLCJjcmVhdGVBZFNsb3QiLCJnZXRCcmVha3BvaW50IiwiZ2V0Vmlld3BvcnQiLCJ0YWxsZXN0Q29tbWVudEFkIiwidGFsbGVzdENvbW1lbnRzRXhwYW5kZWRBZCIsImluc2VydEFkIiwiYW5jaG9yIiwiY2xhc3NlcyIsImFkU2xvdENvbnRhaW5lciIsInRvcCIsInN0aWNreUNvbnRhaW5lciIsImZsZXhHcm93IiwiaW5zZXJ0QWRNb2JpbGUiLCJtYXJnaW4iLCJsaXN0RWxlbWVudCIsImFmdGVyIiwiZ2V0UmlnaHRDb2x1bW4iLCJzZWxlY3RvciIsInJpZ2h0Q29sdW1uIiwiZ2V0Q29tbWVudHNDb2x1bW4iLCJjb21tZW50c0NvbHVtbiIsImlzRW5vdWdoU3BhY2VGb3JBZCIsInJpZ2h0Q29sdW1uTm9kZSIsIm1pbkhlaWdodFRvUGxhY2VBZCIsImlubmVySGVpZ2h0IiwiaXNFbm91Z2hDb21tZW50c0ZvckFkIiwiY2hpbGRFbGVtZW50Q291bnQiLCJjb21tZW50c0V4cGFuZGVkQWRzQWxyZWFkeUV4aXN0IiwiY29tbWVudHNFeHBhbmRlZEFkcyIsInJlbW92ZU1vYmlsZUNvbW1lbnRzRXhwYW5kZWRBZHMiLCJjdXJyZW50QnJlYWtwb2ludCIsImhhbmRsZUNvbW1lbnRzTG9hZGVkRXZlbnQiLCJoYW5kbGVDb21tZW50c0xvYWRlZE1vYmlsZUV2ZW50IiwiaXNEY3IiLCJtaW5Db21tZW50c0JlbG93QWQiLCJjb3VudGVyIiwiY2hpbGRyZW4iLCJjaGlsZEVsZW1lbnQiLCJjb21tZW50QWR2ZXJ0cyIsIndyYXBTbG90SW5Db250YWluZXIiLCJMQVJHRVNUX0FEX1NJWkUiLCJTUEFDSU5HIiwiaW5zZXJ0Rm9vdGJhbGxSaWdodEFkIiwiY29udGFpbmVyIiwibWFyZ2luVG9wIiwiX2FuY2hvciRwYXJlbnRFbGVtZW50IiwiZm9vdGJhbGxGaXh0dXJlc0FkdmVydHMiLCJtaW5TcGFjZUZvckFkIiwiaGlnaE1lcmNoIiwiYW5jaG9yU2VsZWN0b3IiLCJjb21tZW50YWJsZSIsImp1c3RpZnlDb250ZW50Iiwic2hvdWxkSW5jbHVkZU1vYmlsZVN0aWNreSIsImNyZWF0ZUFkV3JhcHBlckNsYXNzaWMiLCJ3cmFwcGVyIiwiY3JlYXRlQWRXcmFwcGVyRENSIiwiY3JlYXRlQWRXcmFwcGVyIiwibW9iaWxlU3RpY2t5V3JhcHBlciIsIm1vYmlsZVN0aWNreUFkU2xvdCIsInNwYWNlRmlsbGVyIiwiTUFYX0FEUyIsIkFEX0dBUF9NVUxUSVBMSUVSIiwiQURfQ09VTlRFUiIsImdldFNsb3ROYW1lIiwiaXNNb2JpbGUiLCJzbG90Q291bnRlciIsImluc2VydEFkQXRQYXJhIiwicGFyYSIsIm5leHRTaWJsaW5nIiwiaW5zZXJ0QWRzIiwicGFyYXMiLCJmYXN0ZG9tUHJvbWlzZXMiLCJyZXN1bHQiLCJmaWxsU3BhY2UiLCJydWxlcyIsIm9wdGlvbnMiLCJwYXNzIiwic2hvdWxkSW5zZXJ0QWQiLCJibG9ja0Fib3ZlQWQiLCJjYW5kaWRhdGVCbG9jayIsIndpbmRvd0hlaWdodCIsImFicyIsImJvdHRvbSIsImdldFNwYWNlRmlsbGVyUnVsZXMiLCJzdGFydEJsb2NrIiwicHJldlNsb3QiLCJmaWx0ZXJTbG90IiwiYm9keVNlbGVjdG9yIiwiY2FuZGlkYXRlU2VsZWN0b3IiLCJmcm9tQm90dG9tIiwic3RhcnRBdCIsImFic29sdXRlTWluRGlzdGFuY2VGcm9tVG9wIiwibWluRGlzdGFuY2VGcm9tVG9wIiwibWluRGlzdGFuY2VGcm9tQm90dG9tIiwiY2xlYXJDb250ZW50TWV0YSIsIm9wcG9uZW50U2VsZWN0b3JSdWxlcyIsImdldEZpcnN0Q29udGVudEJsb2NrQWJvdmVBZCIsInRvcEFkdmVydCIsInByZXZFbGVtZW50IiwicHJldmlvdXNFbGVtZW50U2libGluZyIsImdldExvd2VzdENvbnRlbnRCbG9jayIsIl9yZWY0IiwiX2FsbEJsb2NrcyIsImFsbEJsb2NrcyIsImdldFN0YXJ0aW5nQ29udGVudEJsb2NrIiwiX3JlZjUiLCJzbG90U2VsZWN0b3IiLCJsb29rRm9yU3BhY2VzRm9yQWRTbG90cyIsIl9yZWY2IiwibnVtU2xvdHMiLCJzdGFydENvbnRlbnRCbG9jayIsImRvY3VtZW50RWxlbWVudCIsInN0YXJ0TGlzdGVuaW5nIiwib25VcGRhdGUiLCJzdG9wTGlzdGVuaW5nIiwibGl2ZWJsb2dBZHZlcnRzIiwiYSIsInAiLCJzIiwiQSIsIl9RIiwiZmV0Y2hCaWRzIiwic2V0RGlzcGxheUJpZHMiLCJ0YXJnZXRpbmdLZXlzIiwicmVmcmVzaEFkdmVydCIsInN0cmlwRGZwQWRQcmVmaXhGcm9tIiwiZXJyb3JIYW5kbGVyIiwiY29uZmlhbnRSZWZyZXNoZWRTbG90cyIsIm1heWJlUmVmcmVzaEJsb2NrZWRTbG90T25jZSIsImJsb2NraW5nVHlwZSIsImJsb2NraW5nSWQiLCJpc0Jsb2NrZWQiLCJ3cmFwcGVySWQiLCJ0YWdJZCIsImltcHJlc3Npb25zRGF0YSIsIl9pbXByZXNzaW9uc0RhdGEkcHJlYiIsIl9pbXByZXNzaW9uc0RhdGEkZGZwIiwicHJlYmlkU2xvdEVsZW1lbnRJZCIsImRmcFNsb3RFbGVtZW50SWQiLCJkZnAiLCJibG9ja2VkU2xvdFBhdGgiLCJldmVudFRpbWVyIiwicmVtb3RlU2NyaXB0VXJsIiwiY29uZmlhbnRBZFZlcmlmaWNhdGlvbiIsIl93aW5kb3ckY29uZmlhbnQiLCJjb25maWFudCIsInNldHRpbmdzIiwiaGFzaCIsImRldk1vZGUiLCJjYWxsYmFjayIsImhhc0Nyb3NzZWRCcmVha3BvaW50IiwibWF0Y2hlc0JyZWFrcG9pbnRzIiwiYm9keUVsIiwiaXNJbkFVRWRpdGlvbiIsInRvTG93ZXJDYXNlIiwiYWRMYWJlbEhlaWdodCIsInRvcFBvc2l0aW9uIiwidHJ1c2tpblJlbmRlcmVkIiwicGFnZXNraW5SZW5kZXJlZCIsInRvZ2dsZVBhZ2VTa2luQWN0aXZlQ2xhc3MiLCJ0b2dnbGUiLCJtaW4iLCJ0b2dnbGVQYWdlU2tpbiIsIm1vdmVCYWNrZ3JvdW5kVmVydGljYWxQb3NpdGlvbiIsInZlcnRpY2FsUG9zIiwiYmFja2dyb3VuZFBvc2l0aW9uIiwiaW5pdFRvcFBvc2l0aW9uT25jZSIsIm5hdkhlYWRlciIsInNocmlua0VsZW1lbnQiLCJlbGVtZW50IiwiZnJvbnRDb250YWluZXIiLCJjc3NUZXh0IiwicmVwb3NpdGlvblRydXNraW4iLCJmb290ZXIiLCJ0b3BCYW5uZXJBZCIsInRvcEJhbm5lckFkQ29udGFpbmVyIiwiYm9yZGVyQm90dG9tIiwicGFnZVlPZmZzZXQiLCJoZWFkZXJCb3VuZGFyaWVzIiwiZ2V0Qm91bmRpbmdDbGllbnRSZWN0IiwidG9wQmFubmVyQWRCb3VuZGFyaWVzIiwiaGVhZGVyUG9zaXRpb24iLCJ0b3BCYW5uZXJCb3R0b20iLCJmYWJyaWNTY3JvbGxTdGFydFBvc2l0aW9uIiwicmVwb3NpdGlvblBhZ2VTa2luIiwicGFnZVhPZmZzZXQiLCJyZXBvc2l0aW9uU2tpbnMiLCJHT09HTEVfV0VCX0xJR0hUIiwiR09PR0xFX1dFQl9QUkVWSUVXIiwiQm9vbGVhbiIsIm1lbW9pemUiLCJmZXRjaE5vblJlZnJlc2hhYmxlTGluZUl0ZW1JZHMiLCJpc1Byb2QiLCJmaWxlSG9zdCIsImZpbGVMb2NhdGlvbiIsIlVSTCIsInJlc3BvbnNlIiwiZmV0Y2giLCJvayIsImpzb24iLCJsaW5lSXRlbXNPckVycm9yIiwicmVkdWNlIiwiYWNjdW0iLCJsaW5lSXRlbXMiLCJzdGF0dXMiLCJfYWR2ZXJ0JHNpemUiLCJzaXplU3RyaW5nIiwicmVmcmVzaCIsImlzRmx1aWQiLCJpc091dHN0cmVhbSIsImlzTm9uUmVmcmVzaGFibGVMaW5lSXRlbSIsImVuZHBvaW50IiwiaXNEZXYiLCJtZXRob2QiLCJwcm9wZXJ0aWVzIiwicGFnZVZpZXdJZCIsImtlZXBhbGl2ZSIsImNhY2hlIiwibW9kZSIsInJlZ2lzdGVyIiwic3BlY3MiLCJyZXQiLCJIVE1MRWxlbWVudCIsImZ1bGxXaWR0aCIsInNsb3RDb250YWluZXIiLCJyZW1vdmUiLCJfaWZyYW1lJGNsb3Nlc3QiLCJfaWZyYW1lJGNsb3Nlc3QyIiwic3RhcnRzV2l0aCIsInNoYXJlZEFkVGFyZ2V0aW5nIiwib3JpZ2luIiwicGF0aG5hbWUiLCJpc09iamVjdCIsImlzU3R5bGVTcGVjcyIsInN0eWxlU2hlZXRzIiwiX3N0eWxlU2hlZXRzJGkiLCJvd25lck5vZGUiLCJIVE1MU3R5bGVFbGVtZW50IiwibWF0Y2hlcyIsInRleHRDb250ZW50IiwiZ2V0U2xvdElkIiwiaW5lbGlnaWJsZVBhc3NiYWNrcyIsImJyZWFrcG9pbnRzIiwiYWRTbG90SWRQcmVmaXgiLCJvdXN0cmVhbVNpemVNYXBwaW5ncyIsIm1vYmlsZVN0aWNreSIsIm1vYmlsZXN0aWNreSIsIm1vYmlsZVN0aWNreVNpemVzIiwibW9iaWxlU3RpY2t5U2l6ZU1hcHBpbmdzIiwiZGVmYXVsdFNpemVNYXBwaW5ncyIsImRlY2lkZVNpemVzIiwic291cmNlIiwic2l6ZXMiLCJzaXplTWFwcGluZ3MiLCJtYXBWYWx1ZXMiLCJ2YWx1ZUZuIiwiZ2V0UGFzc2JhY2tWYWx1ZSIsIm1lc3NhZ2VQYXlsb2FkIiwic2xvdEVsZW1lbnQiLCJzbG90SWRXaXRoUHJlZml4IiwiaUZyYW1lQ29udGFpbmVyIiwidXBkYXRlSW5pdGlhbFNsb3RQcm9taXNlIiwidmlzaWJpbGl0eSIsImNyZWF0ZU5ld1Nsb3RFbGVtZW50UHJvbWlzZSIsInBhc3NiYWNrRWxlbWVudCIsImluc2VydEFkamFjZW50RWxlbWVudCIsImluaXRpYWxTbG90IiwiZ2V0U2xvdHMiLCJzbG90VGFyZ2V0aW5nIiwiZnJvbUVudHJpZXMiLCJwYXNzYmFja1RhcmdldGluZyIsImFkSGVpZ2h0Iiwic2xvdEhlaWdodCIsImZsZXhEaXJlY3Rpb24iLCJhbGlnbkl0ZW1zIiwicGFzc2JhY2tTbG90IiwiZGVmaW5lU2xvdCIsImRlZmluZVNpemVNYXBwaW5nIiwiYWRkU2VydmljZSIsImdldFRhcmdldGluZ01hcCIsInRhc2tRdWV1ZWQiLCJpZnJhbWVzIiwiaWZyYW1lQ291bnRlciIsIm9ic2VydmVyIiwidmlzaWJsZUlmcmFtZUlkcyIsInJlc2V0IiwiZG9tUmVjdFRvUmVjdCIsInJlY3QiLCJsZWZ0IiwicmlnaHQiLCJzZW5kQ29vcmRpbmF0ZXMiLCJpZnJhbWVJZCIsImRvbVJlY3QiLCJfaWZyYW1lcyRpZnJhbWVJZCIsInJlc3BvbmQiLCJnZXREaW1lbnNpb25zIiwiX2lmcmFtZXMkaWQiLCJvbkludGVyc2VjdCIsImNoYW5nZXMiLCJpbnRlcnNlY3Rpb25SYXRpbyIsInRhcmdldCIsIm9uU2Nyb2xsIiwiYWRkU2Nyb2xsTGlzdGVuZXIiLCJwYXNzaXZlIiwiSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJ2aXNpYmxlIiwib2JzZXJ2ZSIsInJlbW92ZVNjcm9sbExpc3RlbmVyIiwidW5vYnNlcnZlIiwiZGlzY29ubmVjdCIsImlzQ2FsbGFibGUiLCJzdGFydCIsInNlbmRQcm9ncmVzc09uVW5sb2FkT25jZSIsInVwZGF0ZVZpZGVvUHJvZ3Jlc3MiLCJwcm9ncmVzcyIsInciLCJsYXN0Vmlld3BvcnRSZWFkIiwid2luZG93XyIsInNlbmRWaWV3cG9ydERpbWVuc2lvbnMiLCJvblJlc2l6ZSIsImFkZFJlc2l6ZUxpc3RlbmVyIiwicmVtb3ZlUmVzaXplTGlzdGVuZXIiLCJvbk1lc3NhZ2UiLCJpc1RQQ1Rlc3RQYXlsb2FkIiwidHBjVGVzdCIsImNyb3NzU2l0ZUlyYW1lIiwiZnJvbnRlbmRBc3NldHNGdWxsVVJMIiwiaGFzU3RvcmFnZUFjY2VzcyIsImNtcCIsImdldENvb2tpZSIsIkJBU0VfQUpBWF9VUkwiLCJzdGFnZSIsImlzSW5WYXJpYW50IiwiX2FiVGVzdFZhcmlhbnQkc3RhcnRzIiwiaGFzSW5pdGlhbGlzZWQiLCJ3aWxsU2hvd1ByaXZhY3lNZXNzYWdlU3luYyIsInNob3VsZE1lbW9pemUiLCJzaG91bGRIaWRlQWR2ZXJ0cyIsInNob3VsZEhpZGVSZWFkZXJSZXZlbnVlIiwiaXNTZW5zaXRpdmUiLCJzcG9uc29yc2hpcFR5cGUiLCJpc0luQXVPck56IiwicHZhciIsImNpZCIsInNlcnZlciIsInRyYWMiLCJub2xfdCIsInBvc3QiLCJndU1ldGFkYXRhIiwiYm9va3MiLCJidXNpbmVzcyIsImNvbW1lbnRpc2ZyZWUiLCJhcnRhbmRkZXNpZ24iLCJjdWx0dXJlIiwiZWR1Y2F0aW9uIiwiY2l0aWVzIiwiZmFzaGlvbiIsImZpbG0iLCJsYXciLCJsaWZlYW5kc3R5bGUiLCJtZWRpYSIsIm1vbmV5IiwibXVzaWMiLCJpbnRlcm5hdGlvbmFsIiwiYXUiLCJ1ayIsInVzIiwid29ybGQiLCJwb2xpdGljcyIsImNhcmVlcnMiLCJzY2llbmNlIiwic29jaWV0eSIsInNwb3J0IiwiZm9vdGJhbGwiLCJ0ZWNobm9sb2d5IiwidHJhdmVsIiwiX2d1TWV0YWRhdGEkc2VjdGlvbkZyIiwic2VjdGlvbkZyb21NZXRhIiwic3ViQnJhbmRBcElkIiwic2VjdGlvblJlZiIsIm5vbGdnR2xvYmFsUGFyYW1zIiwic2Zjb2RlIiwiYXBpZCIsImFwbiIsIm5TZGtJbnN0YW5jZSIsIk5PTENNQiIsImdldEluc3RhbmNlIiwiZ2dJbml0aWFsaXplIiwiZGNyU3RhdGljTWV0YWRhdGEiLCJhc3NldGlkIiwiZ2dQTSIsImhhbmRsZVF1ZXJ5U3VydmV5RG9uZSIsInN1cnZleUF2YWlsYWJsZSIsIm1lYXN1cmVtZW50SWQiLCJfd2luZG93JF9icmFuZG1ldHJpY3MiLCJfYnJhbmRtZXRyaWNzIiwidmFsIiwiX3dpbmRvdyRnb29nbGVfdHJhY2tDIiwiZ29vZ2xlX3RyYWNrQ29udmVyc2lvbiIsImdvb2dsZV9jb252ZXJzaW9uX2lkIiwiZ29vZ2xlX2N1c3RvbV9wYXJhbXMiLCJnb29nbGVfdGFnX3BhcmFtcyIsImdvb2dsZV9yZW1hcmtldGluZ19vbmx5Il0sInNvdXJjZVJvb3QiOiIifQ==