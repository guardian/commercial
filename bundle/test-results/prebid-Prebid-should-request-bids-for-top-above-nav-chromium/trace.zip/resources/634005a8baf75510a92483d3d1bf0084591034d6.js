"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["src_lib_header-bidding_prebid_modules_analyticsAdapter_ts-src_lib_header-bidding_prebid_modul-2fc7bf"],{

/***/ "./src/lib/header-bidding/prebid-types.ts":
/*!************************************************!*\
  !*** ./src/lib/header-bidding/prebid-types.ts ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   eventKeys: () => (/* binding */ eventKeys)
/* harmony export */ });
var eventKeys = ['ev', 'aid', 'bid', 'st', 'n', 'sid', 'cpm', 'pb', 'cry', 'net', 'did', 'cid', 'sz', 'ttr', 'lid', 'dsp', 'adv', 'bri', 'brn', 'add'];


/***/ }),

/***/ "./src/lib/header-bidding/prebid/modules/analyticsAdapter.ts":
/*!*******************************************************************!*\
  !*** ./src/lib/header-bidding/prebid/modules/analyticsAdapter.ts ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _: () => (/* binding */ _),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var prebid_js_libraries_analyticsAdapter_AnalyticsAdapter_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prebid.js/libraries/analyticsAdapter/AnalyticsAdapter.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/libraries/analyticsAdapter/AnalyticsAdapter.js");
/* harmony import */ var prebid_js_src_adapterManager_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! prebid.js/src/adapterManager.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/adapterManager.js");
/* harmony import */ var prebid_js_src_ajax_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! prebid.js/src/ajax.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/ajax.js");
/* harmony import */ var prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! prebid.js/src/constants.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/constants.js");
/* harmony import */ var _lib_error_report_error__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../../../../lib/error/report-error */ "./src/lib/error/report-error.ts");
/* harmony import */ var _prebid_types__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ../../prebid-types */ "./src/lib/header-bidding/prebid-types.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
// see http://docs.prebid.org/dev-docs/integrate-with-the-prebid-analytics-api.html







/*
 * Update whenever you want to make sure you're sending the right version of analytics.
 * This is useful when some browsers are using old code and some new, for example.
 */
var VERSION = 9;
var queue = [];
function getBidderCode(args) {
  var _args$bidderCode;
  if (args.bidderCode !== 'ozone') return (_args$bidderCode = args.bidderCode) !== null && _args$bidderCode !== void 0 ? _args$bidderCode : '';
  // Ozone represents several different advertisers
  if (args.adserverTargeting) {
    /**
     * Each Ozone bid contains information about all the other bids.
     * To pinpoint which advertiser is reponsible for the bid,
     * we can match `adId` against the adserverTargeting key-values for each.
     *
     * For example, given `oz_appnexus_adId: "123abc456def789-0-0"`,
     * we want to capture `appnexus` if `adId` matches `123abc456def789-0-0`
     */
    for (var key in args.adserverTargeting) {
      var [, advertiser, info] = key.split('_');
      var value = args.adserverTargeting[key];
      if (info === 'adId' && value === args.adId) {
        return "ozone-".concat(advertiser);
      }
    }
    // If none matched, use ozone's winner as fallback
    if (args.adserverTargeting.oz_winner && typeof args.adserverTargeting.oz_winner === 'string') {
      return "ozone-".concat(args.adserverTargeting.oz_winner);
    }
  }
  return "ozone-unknown";
}
function logEvents(events) {
  var _events$, _events$2;
  var isBid = ((_events$ = events[0]) === null || _events$ === void 0 ? void 0 : _events$.ev) === 'init';
  var isBidWon = ((_events$2 = events[0]) === null || _events$2 === void 0 ? void 0 : _events$2.ev) === 'bidwon';
  var logMsg = '';
  if (isBid) {
    var _events$find;
    var slotId = (_events$find = events.find(e => e.sid)) === null || _events$find === void 0 ? void 0 : _events$find.sid;
    logMsg = "bids for ".concat(slotId !== null && slotId !== void 0 ? slotId : 'unknown slot');
  } else if (isBidWon) {
    var _events$3;
    var bidId = (_events$3 = events[0]) === null || _events$3 === void 0 ? void 0 : _events$3.bid;
    logMsg = "bid won ".concat(bidId !== null && bidId !== void 0 ? bidId : 'unknown bid');
  }
  (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "Prebid.js events: ".concat(logMsg), events);
}
function isEventKey(key) {
  return _prebid_types__WEBPACK_IMPORTED_MODULE_6__.eventKeys.includes(key);
}
// Remove any properties that are undefined or null
function createEvent(event) {
  if (!event.ev) {
    throw new Error('Event must have an "ev" property');
  }
  var cleanedEvent = {
    ev: event.ev
  };
  for (var key in event) {
    if (isEventKey(key) && event[key] !== undefined && event[key] !== null) {
      cleanedEvent[key] = event[key];
    }
  }
  return cleanedEvent;
}
// Handlers for each event type, these create a loggable event from prebid event
var handlers = {
  [prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.AUCTION_INIT]: (adapter, args) => {
    var _adapter$context;
    queue = [];
    if (adapter.context) {
      adapter.context.auctionTimeStart = Date.now();
    }
    var event = createEvent({
      ev: 'init',
      aid: args.auctionId,
      st: (_adapter$context = adapter.context) === null || _adapter$context === void 0 ? void 0 : _adapter$context.auctionTimeStart
    });
    return [event];
  },
  [prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.BID_REQUESTED]: (_, args) => {
    if (args.bids) {
      return args.bids.map(bid => {
        var event = createEvent({
          ev: 'request',
          n: args.bidderCode,
          sid: bid.adUnitCode,
          bid: bid.bidId,
          st: args.start
        });
        return event;
      });
    }
    return null;
  },
  [prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.BID_RESPONSE]: (_, args) => {
    if (args.statusMessage === 'Bid available') {
      var _args$meta, _args$meta2, _args$meta3, _args$meta4, _args$meta5;
      var event = createEvent({
        ev: 'response',
        n: getBidderCode(args),
        bid: args.requestId,
        sid: args.adUnitCode,
        cpm: args.cpm,
        pb: args.pbCg,
        cry: args.currency,
        net: args.netRevenue,
        did: args.adId,
        cid: args.creativeId,
        sz: args.size,
        ttr: args.timeToRespond,
        lid: args.dealId,
        dsp: (_args$meta = args.meta) === null || _args$meta === void 0 ? void 0 : _args$meta.networkId,
        adv: (_args$meta2 = args.meta) === null || _args$meta2 === void 0 ? void 0 : _args$meta2.buyerId,
        bri: (_args$meta3 = args.meta) === null || _args$meta3 === void 0 ? void 0 : _args$meta3.brandId,
        brn: (_args$meta4 = args.meta) === null || _args$meta4 === void 0 ? void 0 : _args$meta4.brandName,
        add: (_args$meta5 = args.meta) === null || _args$meta5 === void 0 ? void 0 : _args$meta5.clickUrl
      });
      return [event];
    }
    return null;
  },
  [prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.NO_BID]: (adapter, args) => {
    var _adapter$context$auct, _adapter$context2, _args$bidder, _args$bidId;
    var duration = Date.now() - ((_adapter$context$auct = (_adapter$context2 = adapter.context) === null || _adapter$context2 === void 0 ? void 0 : _adapter$context2.auctionTimeStart) !== null && _adapter$context$auct !== void 0 ? _adapter$context$auct : 0);
    var event = createEvent({
      ev: 'nobid',
      n: (_args$bidder = args.bidder) !== null && _args$bidder !== void 0 ? _args$bidder : args.bidderCode,
      bid: (_args$bidId = args.bidId) !== null && _args$bidId !== void 0 ? _args$bidId : args.requestId,
      sid: args.adUnitCode,
      aid: args.auctionId,
      ttr: duration
    });
    return [event];
  },
  [prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.AUCTION_END]: (adapter, args) => {
    var _adapter$context$auct2, _adapter$context3;
    var duration = Date.now() - ((_adapter$context$auct2 = (_adapter$context3 = adapter.context) === null || _adapter$context3 === void 0 ? void 0 : _adapter$context3.auctionTimeStart) !== null && _adapter$context$auct2 !== void 0 ? _adapter$context$auct2 : 0);
    var event = createEvent({
      ev: 'end',
      aid: args.auctionId,
      ttr: duration
    });
    return [event];
  },
  [prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.BID_WON]: (_, args) => {
    var event = createEvent({
      ev: 'bidwon',
      aid: args.auctionId,
      bid: args.requestId
    });
    return [event];
  }
};
var createPayload = (events, pv) => {
  return {
    v: VERSION,
    pv,
    hb_ev: events
  };
};
var analyticsAdapter = Object.assign((0,prebid_js_libraries_analyticsAdapter_AnalyticsAdapter_js__WEBPACK_IMPORTED_MODULE_1__["default"])({
  analyticsType: 'endpoint'
}), {
  sendPayload: function () {
    var _ref = _asyncToGenerator(function* (url, payload) {
      var events = [...queue];
      queue = [];
      try {
        var response = yield (0,prebid_js_src_ajax_js__WEBPACK_IMPORTED_MODULE_3__.fetch)(url, {
          method: 'POST',
          body: JSON.stringify(payload),
          keepalive: true,
          headers: {
            'Content-Type': 'application/json'
          }
        });
        if (!response.ok) {
          throw new Error("Failed to send analytics payload: ".concat(response.statusText, " (").concat(response.status, ")"));
        }
        logEvents(events);
      } catch (error) {
        if (error instanceof Error && error.name === 'AbortError') {
          // Ignore abort errors, they are expected when the fetch times out
          return;
        }
        (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_5__.reportError)(error, 'commercial', {}, {
          events
        });
      }
    });
    return function sendPayload(_x, _x2) {
      return _ref.apply(this, arguments);
    };
  }(),
  track(_ref2) {
    var {
      eventType,
      args
    } = _ref2;
    if (!analyticsAdapter.context) {
      // this should never happen
      (0,_lib_error_report_error__WEBPACK_IMPORTED_MODULE_5__.reportError)(new Error('context is not defined, prebid event not being logged'), 'commercial', {}, {
        eventType,
        args
      });
      (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', 'context is not defined, prebid event not being logged');
      return;
    }
    var handler = handlers[eventType];
    if (handler) {
      var events = handler(analyticsAdapter, args);
      if (events) {
        if (eventType === prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.BID_WON) {
          // clear queue to avoid sending late bids with bidWon event
          queue = [];
        }
        queue.push(...events);
      }
      if ([prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.AUCTION_END, prebid_js_src_constants_js__WEBPACK_IMPORTED_MODULE_4__.EVENTS.BID_WON].includes(eventType)) {
        var {
          pv,
          url
        } = analyticsAdapter.context;
        var _events = [...queue];
        queue = [];
        var payload = createPayload(_events, pv);
        void analyticsAdapter.sendPayload(url, payload);
      }
    }
  }
});
analyticsAdapter.originEnableAnalytics = analyticsAdapter.enableAnalytics;
analyticsAdapter.enableAnalytics = config => {
  analyticsAdapter.context = {
    url: config.options.url,
    pv: config.options.pv
  };
  if (analyticsAdapter.originEnableAnalytics) {
    analyticsAdapter.originEnableAnalytics(config);
  }
};
prebid_js_src_adapterManager_js__WEBPACK_IMPORTED_MODULE_2__["default"].registerAnalyticsAdapter({
  adapter: analyticsAdapter,
  code: 'gu'
});
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (analyticsAdapter);
var _ = {
  getBidderCode,
  createEvent,
  handlers
};

/***/ }),

/***/ "./src/lib/header-bidding/prebid/modules/appnexusBidAdapter.ts":
/*!*********************************************************************!*\
  !*** ./src/lib/header-bidding/prebid/modules/appnexusBidAdapter.ts ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prebid_js_adapters_bidderFactory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prebid.js/adapters/bidderFactory */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/adapters/bidderFactory.js");
/* harmony import */ var prebid_js_modules_appnexusBidAdapter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prebid.js/modules/appnexusBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/appnexusBidAdapter.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var customSpec = _objectSpread(_objectSpread({}, prebid_js_modules_appnexusBidAdapter__WEBPACK_IMPORTED_MODULE_1__.spec), {}, {
  aliases: [...prebid_js_modules_appnexusBidAdapter__WEBPACK_IMPORTED_MODULE_1__.spec.aliases, {
    code: 'and'
  }, {
    code: 'xhb'
  }]
});
(0,prebid_js_adapters_bidderFactory__WEBPACK_IMPORTED_MODULE_0__.registerBidder)(customSpec);

/***/ }),

/***/ "./src/lib/header-bidding/prebid/modules/openxBidAdapter.ts":
/*!******************************************************************!*\
  !*** ./src/lib/header-bidding/prebid/modules/openxBidAdapter.ts ***!
  \******************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony import */ var prebid_js_adapters_bidderFactory__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! prebid.js/adapters/bidderFactory */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/adapters/bidderFactory.js");
/* harmony import */ var prebid_js_modules_openxBidAdapter__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! prebid.js/modules/openxBidAdapter */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/modules/openxBidAdapter.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }


var customSpec = _objectSpread(_objectSpread({}, prebid_js_modules_openxBidAdapter__WEBPACK_IMPORTED_MODULE_1__.spec), {}, {
  aliases: ['oxd']
});
(0,prebid_js_adapters_bidderFactory__WEBPACK_IMPORTED_MODULE_0__.registerBidder)(customSpec);

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uc3JjX2xpYl9oZWFkZXItYmlkZGluZ19wcmViaWRfbW9kdWxlc19hbmFseXRpY3NBZGFwdGVyX3RzLXNyY19saWJfaGVhZGVyLWJpZGRpbmdfcHJlYmlkX21vZHVsLTJmYzdiZi5jb21tZXJjaWFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7QUFBQSxJQUFNQSxTQUFTLEdBQUcsQ0FDZCxJQUFJLEVBQ0osS0FBSyxFQUNMLEtBQUssRUFDTCxJQUFJLEVBQ0osR0FBRyxFQUNILEtBQUssRUFDTCxLQUFLLEVBQ0wsSUFBSSxFQUNKLEtBQUssRUFDTCxLQUFLLEVBQ0wsS0FBSyxFQUNMLEtBQUssRUFDTCxJQUFJLEVBQ0osS0FBSyxFQUNMLEtBQUssRUFDTCxLQUFLLEVBQ0wsS0FBSyxFQUNMLEtBQUssRUFDTCxLQUFLLEVBQ0wsS0FBSyxDQUNSOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckJEO0FBQ3FDO0FBQzBDO0FBQ2xCO0FBQ2Y7QUFDTTtBQUNhO0FBQ2pCO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTU8sT0FBTyxHQUFHLENBQUM7QUFDakIsSUFBSUMsS0FBSyxHQUFHLEVBQUU7QUFDZCxTQUFTQyxhQUFhQSxDQUFDQyxJQUFJLEVBQUU7RUFBQSxJQUFBQyxnQkFBQTtFQUN6QixJQUFJRCxJQUFJLENBQUNFLFVBQVUsS0FBSyxPQUFPLEVBQzNCLFFBQUFELGdCQUFBLEdBQU9ELElBQUksQ0FBQ0UsVUFBVSxjQUFBRCxnQkFBQSxjQUFBQSxnQkFBQSxHQUFJLEVBQUU7RUFDaEM7RUFDQSxJQUFJRCxJQUFJLENBQUNHLGlCQUFpQixFQUFFO0lBQ3hCO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7SUFDUSxLQUFLLElBQU1DLEdBQUcsSUFBSUosSUFBSSxDQUFDRyxpQkFBaUIsRUFBRTtNQUN0QyxJQUFNLEdBQUdFLFVBQVUsRUFBRUMsSUFBSSxDQUFDLEdBQUdGLEdBQUcsQ0FBQ0csS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUMzQyxJQUFNQyxLQUFLLEdBQUdSLElBQUksQ0FBQ0csaUJBQWlCLENBQUNDLEdBQUcsQ0FBQztNQUN6QyxJQUFJRSxJQUFJLEtBQUssTUFBTSxJQUFJRSxLQUFLLEtBQUtSLElBQUksQ0FBQ1MsSUFBSSxFQUFFO1FBQ3hDLGdCQUFBQyxNQUFBLENBQWdCTCxVQUFVO01BQzlCO0lBQ0o7SUFDQTtJQUNBLElBQUlMLElBQUksQ0FBQ0csaUJBQWlCLENBQUNRLFNBQVMsSUFDaEMsT0FBT1gsSUFBSSxDQUFDRyxpQkFBaUIsQ0FBQ1EsU0FBUyxLQUFLLFFBQVEsRUFBRTtNQUN0RCxnQkFBQUQsTUFBQSxDQUFnQlYsSUFBSSxDQUFDRyxpQkFBaUIsQ0FBQ1EsU0FBUztJQUNwRDtFQUNKO0VBQ0E7QUFDSjtBQUNBLFNBQVNDLFNBQVNBLENBQUNDLE1BQU0sRUFBRTtFQUFBLElBQUFDLFFBQUEsRUFBQUMsU0FBQTtFQUN2QixJQUFNQyxLQUFLLEdBQUcsRUFBQUYsUUFBQSxHQUFBRCxNQUFNLENBQUMsQ0FBQyxDQUFDLGNBQUFDLFFBQUEsdUJBQVRBLFFBQUEsQ0FBV0csRUFBRSxNQUFLLE1BQU07RUFDdEMsSUFBTUMsUUFBUSxHQUFHLEVBQUFILFNBQUEsR0FBQUYsTUFBTSxDQUFDLENBQUMsQ0FBQyxjQUFBRSxTQUFBLHVCQUFUQSxTQUFBLENBQVdFLEVBQUUsTUFBSyxRQUFRO0VBQzNDLElBQUlFLE1BQU0sR0FBRyxFQUFFO0VBQ2YsSUFBSUgsS0FBSyxFQUFFO0lBQUEsSUFBQUksWUFBQTtJQUNQLElBQU1DLE1BQU0sSUFBQUQsWUFBQSxHQUFHUCxNQUFNLENBQUNTLElBQUksQ0FBRUMsQ0FBQyxJQUFLQSxDQUFDLENBQUNDLEdBQUcsQ0FBQyxjQUFBSixZQUFBLHVCQUF6QkEsWUFBQSxDQUEyQkksR0FBRztJQUM3Q0wsTUFBTSxlQUFBVCxNQUFBLENBQWVXLE1BQU0sYUFBTkEsTUFBTSxjQUFOQSxNQUFNLEdBQUksY0FBYyxDQUFFO0VBQ25ELENBQUMsTUFDSSxJQUFJSCxRQUFRLEVBQUU7SUFBQSxJQUFBTyxTQUFBO0lBQ2YsSUFBTUMsS0FBSyxJQUFBRCxTQUFBLEdBQUdaLE1BQU0sQ0FBQyxDQUFDLENBQUMsY0FBQVksU0FBQSx1QkFBVEEsU0FBQSxDQUFXRSxHQUFHO0lBQzVCUixNQUFNLGNBQUFULE1BQUEsQ0FBY2dCLEtBQUssYUFBTEEsS0FBSyxjQUFMQSxLQUFLLEdBQUksYUFBYSxDQUFFO0VBQ2hEO0VBQ0FuQyxtREFBRyxDQUFDLFlBQVksdUJBQUFtQixNQUFBLENBQXVCUyxNQUFNLEdBQUlOLE1BQU0sQ0FBQztBQUM1RDtBQUNBLFNBQVNlLFVBQVVBLENBQUN4QixHQUFHLEVBQUU7RUFDckIsT0FBT2Qsb0RBQVMsQ0FBQ3VDLFFBQVEsQ0FBQ3pCLEdBQUcsQ0FBQztBQUNsQztBQUNBO0FBQ0EsU0FBUzBCLFdBQVdBLENBQUNDLEtBQUssRUFBRTtFQUN4QixJQUFJLENBQUNBLEtBQUssQ0FBQ2QsRUFBRSxFQUFFO0lBQ1gsTUFBTSxJQUFJZSxLQUFLLENBQUMsa0NBQWtDLENBQUM7RUFDdkQ7RUFDQSxJQUFNQyxZQUFZLEdBQUc7SUFDakJoQixFQUFFLEVBQUVjLEtBQUssQ0FBQ2Q7RUFDZCxDQUFDO0VBQ0QsS0FBSyxJQUFNYixHQUFHLElBQUkyQixLQUFLLEVBQUU7SUFDckIsSUFBSUgsVUFBVSxDQUFDeEIsR0FBRyxDQUFDLElBQ2YyQixLQUFLLENBQUMzQixHQUFHLENBQUMsS0FBSzhCLFNBQVMsSUFDeEJILEtBQUssQ0FBQzNCLEdBQUcsQ0FBQyxLQUFLLElBQUksRUFBRTtNQUNyQjZCLFlBQVksQ0FBQzdCLEdBQUcsQ0FBQyxHQUFHMkIsS0FBSyxDQUFDM0IsR0FBRyxDQUFDO0lBQ2xDO0VBQ0o7RUFDQSxPQUFPNkIsWUFBWTtBQUN2QjtBQUNBO0FBQ0EsSUFBTUUsUUFBUSxHQUFHO0VBQ2IsQ0FBQ3hDLDhEQUFNLENBQUN5QyxZQUFZLEdBQUcsQ0FBQzVDLE9BQU8sRUFBRVEsSUFBSSxLQUFLO0lBQUEsSUFBQXFDLGdCQUFBO0lBQ3RDdkMsS0FBSyxHQUFHLEVBQUU7SUFDVixJQUFJTixPQUFPLENBQUM4QyxPQUFPLEVBQUU7TUFDakI5QyxPQUFPLENBQUM4QyxPQUFPLENBQUNDLGdCQUFnQixHQUFHQyxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDO0lBQ2pEO0lBQ0EsSUFBTVYsS0FBSyxHQUFHRCxXQUFXLENBQUM7TUFDdEJiLEVBQUUsRUFBRSxNQUFNO01BQ1Z5QixHQUFHLEVBQUUxQyxJQUFJLENBQUMyQyxTQUFTO01BQ25CQyxFQUFFLEdBQUFQLGdCQUFBLEdBQUU3QyxPQUFPLENBQUM4QyxPQUFPLGNBQUFELGdCQUFBLHVCQUFmQSxnQkFBQSxDQUFpQkU7SUFDekIsQ0FBQyxDQUFDO0lBQ0YsT0FBTyxDQUFDUixLQUFLLENBQUM7RUFDbEIsQ0FBQztFQUNELENBQUNwQyw4REFBTSxDQUFDa0QsYUFBYSxHQUFHLENBQUNDLENBQUMsRUFBRTlDLElBQUksS0FBSztJQUNqQyxJQUFJQSxJQUFJLENBQUMrQyxJQUFJLEVBQUU7TUFDWCxPQUFPL0MsSUFBSSxDQUFDK0MsSUFBSSxDQUFDQyxHQUFHLENBQUVyQixHQUFHLElBQUs7UUFDMUIsSUFBTUksS0FBSyxHQUFHRCxXQUFXLENBQUM7VUFDdEJiLEVBQUUsRUFBRSxTQUFTO1VBQ2JnQyxDQUFDLEVBQUVqRCxJQUFJLENBQUNFLFVBQVU7VUFDbEJzQixHQUFHLEVBQUVHLEdBQUcsQ0FBQ3VCLFVBQVU7VUFDbkJ2QixHQUFHLEVBQUVBLEdBQUcsQ0FBQ0QsS0FBSztVQUNka0IsRUFBRSxFQUFFNUMsSUFBSSxDQUFDbUQ7UUFDYixDQUFDLENBQUM7UUFDRixPQUFPcEIsS0FBSztNQUNoQixDQUFDLENBQUM7SUFDTjtJQUNBLE9BQU8sSUFBSTtFQUNmLENBQUM7RUFDRCxDQUFDcEMsOERBQU0sQ0FBQ3lELFlBQVksR0FBRyxDQUFDTixDQUFDLEVBQUU5QyxJQUFJLEtBQUs7SUFDaEMsSUFBSUEsSUFBSSxDQUFDcUQsYUFBYSxLQUFLLGVBQWUsRUFBRTtNQUFBLElBQUFDLFVBQUEsRUFBQUMsV0FBQSxFQUFBQyxXQUFBLEVBQUFDLFdBQUEsRUFBQUMsV0FBQTtNQUN4QyxJQUFNM0IsS0FBSyxHQUFHRCxXQUFXLENBQUM7UUFDdEJiLEVBQUUsRUFBRSxVQUFVO1FBQ2RnQyxDQUFDLEVBQUVsRCxhQUFhLENBQUNDLElBQUksQ0FBQztRQUN0QjJCLEdBQUcsRUFBRTNCLElBQUksQ0FBQzJELFNBQVM7UUFDbkJuQyxHQUFHLEVBQUV4QixJQUFJLENBQUNrRCxVQUFVO1FBQ3BCVSxHQUFHLEVBQUU1RCxJQUFJLENBQUM0RCxHQUFHO1FBQ2JDLEVBQUUsRUFBRTdELElBQUksQ0FBQzhELElBQUk7UUFDYkMsR0FBRyxFQUFFL0QsSUFBSSxDQUFDZ0UsUUFBUTtRQUNsQkMsR0FBRyxFQUFFakUsSUFBSSxDQUFDa0UsVUFBVTtRQUNwQkMsR0FBRyxFQUFFbkUsSUFBSSxDQUFDUyxJQUFJO1FBQ2QyRCxHQUFHLEVBQUVwRSxJQUFJLENBQUNxRSxVQUFVO1FBQ3BCQyxFQUFFLEVBQUV0RSxJQUFJLENBQUN1RSxJQUFJO1FBQ2JDLEdBQUcsRUFBRXhFLElBQUksQ0FBQ3lFLGFBQWE7UUFDdkJDLEdBQUcsRUFBRTFFLElBQUksQ0FBQzJFLE1BQU07UUFDaEJDLEdBQUcsR0FBQXRCLFVBQUEsR0FBRXRELElBQUksQ0FBQzZFLElBQUksY0FBQXZCLFVBQUEsdUJBQVRBLFVBQUEsQ0FBV3dCLFNBQVM7UUFDekJDLEdBQUcsR0FBQXhCLFdBQUEsR0FBRXZELElBQUksQ0FBQzZFLElBQUksY0FBQXRCLFdBQUEsdUJBQVRBLFdBQUEsQ0FBV3lCLE9BQU87UUFDdkJDLEdBQUcsR0FBQXpCLFdBQUEsR0FBRXhELElBQUksQ0FBQzZFLElBQUksY0FBQXJCLFdBQUEsdUJBQVRBLFdBQUEsQ0FBVzBCLE9BQU87UUFDdkJDLEdBQUcsR0FBQTFCLFdBQUEsR0FBRXpELElBQUksQ0FBQzZFLElBQUksY0FBQXBCLFdBQUEsdUJBQVRBLFdBQUEsQ0FBVzJCLFNBQVM7UUFDekJDLEdBQUcsR0FBQTNCLFdBQUEsR0FBRTFELElBQUksQ0FBQzZFLElBQUksY0FBQW5CLFdBQUEsdUJBQVRBLFdBQUEsQ0FBVzRCO01BQ3BCLENBQUMsQ0FBQztNQUNGLE9BQU8sQ0FBQ3ZELEtBQUssQ0FBQztJQUNsQjtJQUNBLE9BQU8sSUFBSTtFQUNmLENBQUM7RUFDRCxDQUFDcEMsOERBQU0sQ0FBQzRGLE1BQU0sR0FBRyxDQUFDL0YsT0FBTyxFQUFFUSxJQUFJLEtBQUs7SUFBQSxJQUFBd0YscUJBQUEsRUFBQUMsaUJBQUEsRUFBQUMsWUFBQSxFQUFBQyxXQUFBO0lBQ2hDLElBQU1DLFFBQVEsR0FBR3BELElBQUksQ0FBQ0MsR0FBRyxDQUFDLENBQUMsS0FBQStDLHFCQUFBLElBQUFDLGlCQUFBLEdBQUlqRyxPQUFPLENBQUM4QyxPQUFPLGNBQUFtRCxpQkFBQSx1QkFBZkEsaUJBQUEsQ0FBaUJsRCxnQkFBZ0IsY0FBQWlELHFCQUFBLGNBQUFBLHFCQUFBLEdBQUksQ0FBQyxDQUFDO0lBQ3RFLElBQU16RCxLQUFLLEdBQUdELFdBQVcsQ0FBQztNQUN0QmIsRUFBRSxFQUFFLE9BQU87TUFDWGdDLENBQUMsR0FBQXlDLFlBQUEsR0FBRTFGLElBQUksQ0FBQzZGLE1BQU0sY0FBQUgsWUFBQSxjQUFBQSxZQUFBLEdBQUkxRixJQUFJLENBQUNFLFVBQVU7TUFDakN5QixHQUFHLEdBQUFnRSxXQUFBLEdBQUUzRixJQUFJLENBQUMwQixLQUFLLGNBQUFpRSxXQUFBLGNBQUFBLFdBQUEsR0FBSTNGLElBQUksQ0FBQzJELFNBQVM7TUFDakNuQyxHQUFHLEVBQUV4QixJQUFJLENBQUNrRCxVQUFVO01BQ3BCUixHQUFHLEVBQUUxQyxJQUFJLENBQUMyQyxTQUFTO01BQ25CNkIsR0FBRyxFQUFFb0I7SUFDVCxDQUFDLENBQUM7SUFDRixPQUFPLENBQUM3RCxLQUFLLENBQUM7RUFDbEIsQ0FBQztFQUNELENBQUNwQyw4REFBTSxDQUFDbUcsV0FBVyxHQUFHLENBQUN0RyxPQUFPLEVBQUVRLElBQUksS0FBSztJQUFBLElBQUErRixzQkFBQSxFQUFBQyxpQkFBQTtJQUNyQyxJQUFNSixRQUFRLEdBQUdwRCxJQUFJLENBQUNDLEdBQUcsQ0FBQyxDQUFDLEtBQUFzRCxzQkFBQSxJQUFBQyxpQkFBQSxHQUFJeEcsT0FBTyxDQUFDOEMsT0FBTyxjQUFBMEQsaUJBQUEsdUJBQWZBLGlCQUFBLENBQWlCekQsZ0JBQWdCLGNBQUF3RCxzQkFBQSxjQUFBQSxzQkFBQSxHQUFJLENBQUMsQ0FBQztJQUN0RSxJQUFNaEUsS0FBSyxHQUFHRCxXQUFXLENBQUM7TUFDdEJiLEVBQUUsRUFBRSxLQUFLO01BQ1R5QixHQUFHLEVBQUUxQyxJQUFJLENBQUMyQyxTQUFTO01BQ25CNkIsR0FBRyxFQUFFb0I7SUFDVCxDQUFDLENBQUM7SUFDRixPQUFPLENBQUM3RCxLQUFLLENBQUM7RUFDbEIsQ0FBQztFQUNELENBQUNwQyw4REFBTSxDQUFDc0csT0FBTyxHQUFHLENBQUNuRCxDQUFDLEVBQUU5QyxJQUFJLEtBQUs7SUFDM0IsSUFBTStCLEtBQUssR0FBR0QsV0FBVyxDQUFDO01BQ3RCYixFQUFFLEVBQUUsUUFBUTtNQUNaeUIsR0FBRyxFQUFFMUMsSUFBSSxDQUFDMkMsU0FBUztNQUNuQmhCLEdBQUcsRUFBRTNCLElBQUksQ0FBQzJEO0lBQ2QsQ0FBQyxDQUFDO0lBQ0YsT0FBTyxDQUFDNUIsS0FBSyxDQUFDO0VBQ2xCO0FBQ0osQ0FBQztBQUNELElBQU1tRSxhQUFhLEdBQUdBLENBQUNyRixNQUFNLEVBQUVzRixFQUFFLEtBQUs7RUFDbEMsT0FBTztJQUNIQyxDQUFDLEVBQUV2RyxPQUFPO0lBQ1ZzRyxFQUFFO0lBQ0ZFLEtBQUssRUFBRXhGO0VBQ1gsQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNeUYsZ0JBQWdCLEdBQUdDLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDaEgsb0dBQU8sQ0FBQztFQUFFaUgsYUFBYSxFQUFFO0FBQVcsQ0FBQyxDQUFDLEVBQUU7RUFDM0VDLFdBQVc7SUFBQSxJQUFBQyxJQUFBLEdBQUFDLGlCQUFBLENBQUUsV0FBT0MsR0FBRyxFQUFFQyxPQUFPLEVBQUs7TUFDakMsSUFBTWpHLE1BQU0sR0FBRyxDQUFDLEdBQUdmLEtBQUssQ0FBQztNQUN6QkEsS0FBSyxHQUFHLEVBQUU7TUFDVixJQUFJO1FBQ0EsSUFBTWlILFFBQVEsU0FBU3JILDREQUFLLENBQUNtSCxHQUFHLEVBQUU7VUFDOUJHLE1BQU0sRUFBRSxNQUFNO1VBQ2RDLElBQUksRUFBRUMsSUFBSSxDQUFDQyxTQUFTLENBQUNMLE9BQU8sQ0FBQztVQUM3Qk0sU0FBUyxFQUFFLElBQUk7VUFDZkMsT0FBTyxFQUFFO1lBQ0wsY0FBYyxFQUFFO1VBQ3BCO1FBQ0osQ0FBQyxDQUFDO1FBQ0YsSUFBSSxDQUFDTixRQUFRLENBQUNPLEVBQUUsRUFBRTtVQUNkLE1BQU0sSUFBSXRGLEtBQUssc0NBQUF0QixNQUFBLENBQXNDcUcsUUFBUSxDQUFDUSxVQUFVLFFBQUE3RyxNQUFBLENBQUtxRyxRQUFRLENBQUNTLE1BQU0sTUFBRyxDQUFDO1FBQ3BHO1FBQ0E1RyxTQUFTLENBQUNDLE1BQU0sQ0FBQztNQUNyQixDQUFDLENBQ0QsT0FBTzRHLEtBQUssRUFBRTtRQUNWLElBQUlBLEtBQUssWUFBWXpGLEtBQUssSUFBSXlGLEtBQUssQ0FBQ0MsSUFBSSxLQUFLLFlBQVksRUFBRTtVQUN2RDtVQUNBO1FBQ0o7UUFDQTlILG9FQUFXLENBQUM2SCxLQUFLLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUFFO1VBQ2pDNUc7UUFDSixDQUFDLENBQUM7TUFDTjtJQUNKLENBQUM7SUFBQSxnQkExQkQ2RixXQUFXQSxDQUFBaUIsRUFBQSxFQUFBQyxHQUFBO01BQUEsT0FBQWpCLElBQUEsQ0FBQWtCLEtBQUEsT0FBQUMsU0FBQTtJQUFBO0VBQUEsR0EwQlY7RUFDREMsS0FBS0EsQ0FBQUMsS0FBQSxFQUFzQjtJQUFBLElBQXJCO01BQUVDLFNBQVM7TUFBRWpJO0lBQUssQ0FBQyxHQUFBZ0ksS0FBQTtJQUNyQixJQUFJLENBQUMxQixnQkFBZ0IsQ0FBQ2hFLE9BQU8sRUFBRTtNQUMzQjtNQUNBMUMsb0VBQVcsQ0FBQyxJQUFJb0MsS0FBSyxDQUFDLHVEQUF1RCxDQUFDLEVBQUUsWUFBWSxFQUFFLENBQUMsQ0FBQyxFQUFFO1FBQzlGaUcsU0FBUztRQUNUakk7TUFDSixDQUFDLENBQUM7TUFDRlQsbURBQUcsQ0FBQyxZQUFZLEVBQUUsdURBQXVELENBQUM7TUFDMUU7SUFDSjtJQUNBLElBQU0ySSxPQUFPLEdBQUcvRixRQUFRLENBQUM4RixTQUFTLENBQUM7SUFDbkMsSUFBSUMsT0FBTyxFQUFFO01BQ1QsSUFBTXJILE1BQU0sR0FBR3FILE9BQU8sQ0FBQzVCLGdCQUFnQixFQUFFdEcsSUFBSSxDQUFDO01BQzlDLElBQUlhLE1BQU0sRUFBRTtRQUNSLElBQUlvSCxTQUFTLEtBQUt0SSw4REFBTSxDQUFDc0csT0FBTyxFQUFFO1VBQzlCO1VBQ0FuRyxLQUFLLEdBQUcsRUFBRTtRQUNkO1FBQ0FBLEtBQUssQ0FBQ3FJLElBQUksQ0FBQyxHQUFHdEgsTUFBTSxDQUFDO01BQ3pCO01BQ0EsSUFBSSxDQUFDbEIsOERBQU0sQ0FBQ21HLFdBQVcsRUFBRW5HLDhEQUFNLENBQUNzRyxPQUFPLENBQUMsQ0FBQ3BFLFFBQVEsQ0FBQ29HLFNBQVMsQ0FBQyxFQUFFO1FBQzFELElBQU07VUFBRTlCLEVBQUU7VUFBRVU7UUFBSSxDQUFDLEdBQUdQLGdCQUFnQixDQUFDaEUsT0FBTztRQUM1QyxJQUFNekIsT0FBTSxHQUFHLENBQUMsR0FBR2YsS0FBSyxDQUFDO1FBQ3pCQSxLQUFLLEdBQUcsRUFBRTtRQUNWLElBQU1nSCxPQUFPLEdBQUdaLGFBQWEsQ0FBQ3JGLE9BQU0sRUFBRXNGLEVBQUUsQ0FBQztRQUN6QyxLQUFLRyxnQkFBZ0IsQ0FBQ0ksV0FBVyxDQUFDRyxHQUFHLEVBQUVDLE9BQU8sQ0FBQztNQUNuRDtJQUNKO0VBQ0o7QUFDSixDQUFDLENBQUM7QUFDRlIsZ0JBQWdCLENBQUM4QixxQkFBcUIsR0FBRzlCLGdCQUFnQixDQUFDK0IsZUFBZTtBQUN6RS9CLGdCQUFnQixDQUFDK0IsZUFBZSxHQUFJQyxNQUFNLElBQUs7RUFDM0NoQyxnQkFBZ0IsQ0FBQ2hFLE9BQU8sR0FBRztJQUN2QnVFLEdBQUcsRUFBRXlCLE1BQU0sQ0FBQ0MsT0FBTyxDQUFDMUIsR0FBRztJQUN2QlYsRUFBRSxFQUFFbUMsTUFBTSxDQUFDQyxPQUFPLENBQUNwQztFQUN2QixDQUFDO0VBQ0QsSUFBSUcsZ0JBQWdCLENBQUM4QixxQkFBcUIsRUFBRTtJQUN4QzlCLGdCQUFnQixDQUFDOEIscUJBQXFCLENBQUNFLE1BQU0sQ0FBQztFQUNsRDtBQUNKLENBQUM7QUFDRDdJLHVFQUFjLENBQUMrSSx3QkFBd0IsQ0FBQztFQUNwQ2hKLE9BQU8sRUFBRThHLGdCQUFnQjtFQUN6Qm1DLElBQUksRUFBRTtBQUNWLENBQUMsQ0FBQztBQUNGLGlFQUFlbkMsZ0JBQWdCLEVBQUM7QUFDekIsSUFBTXhELENBQUMsR0FBRztFQUNiL0MsYUFBYTtFQUNiK0IsV0FBVztFQUNYSztBQUNKLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDclBpRTtBQUNOO0FBQzVELElBQU15RyxVQUFVLEdBQUFDLGFBQUEsQ0FBQUEsYUFBQSxLQUNURixzRUFBSTtFQUNQRyxPQUFPLEVBQUUsQ0FBQyxHQUFHSCxzRUFBSSxDQUFDRyxPQUFPLEVBQUU7SUFBRUwsSUFBSSxFQUFFO0VBQU0sQ0FBQyxFQUFFO0lBQUVBLElBQUksRUFBRTtFQUFNLENBQUM7QUFBQyxFQUMvRDtBQUNEQyxnRkFBYyxDQUFDRSxVQUFVLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTndDO0FBQ1Q7QUFDekQsSUFBTUEsVUFBVSxHQUFBQyxhQUFBLENBQUFBLGFBQUEsS0FDVEYsbUVBQUk7RUFDUEcsT0FBTyxFQUFFLENBQUMsS0FBSztBQUFDLEVBQ25CO0FBQ0RKLGdGQUFjLENBQUNFLFVBQVUsQ0FBQyxDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9oZWFkZXItYmlkZGluZy9wcmViaWQtdHlwZXMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2xpYi9oZWFkZXItYmlkZGluZy9wcmViaWQvbW9kdWxlcy9hbmFseXRpY3NBZGFwdGVyLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvaGVhZGVyLWJpZGRpbmcvcHJlYmlkL21vZHVsZXMvYXBwbmV4dXNCaWRBZGFwdGVyLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9saWIvaGVhZGVyLWJpZGRpbmcvcHJlYmlkL21vZHVsZXMvb3BlbnhCaWRBZGFwdGVyLnRzIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGV2ZW50S2V5cyA9IFtcbiAgICAnZXYnLFxuICAgICdhaWQnLFxuICAgICdiaWQnLFxuICAgICdzdCcsXG4gICAgJ24nLFxuICAgICdzaWQnLFxuICAgICdjcG0nLFxuICAgICdwYicsXG4gICAgJ2NyeScsXG4gICAgJ25ldCcsXG4gICAgJ2RpZCcsXG4gICAgJ2NpZCcsXG4gICAgJ3N6JyxcbiAgICAndHRyJyxcbiAgICAnbGlkJyxcbiAgICAnZHNwJyxcbiAgICAnYWR2JyxcbiAgICAnYnJpJyxcbiAgICAnYnJuJyxcbiAgICAnYWRkJyxcbl07XG5leHBvcnQgeyBldmVudEtleXMgfTtcbiIsIi8vIHNlZSBodHRwOi8vZG9jcy5wcmViaWQub3JnL2Rldi1kb2NzL2ludGVncmF0ZS13aXRoLXRoZS1wcmViaWQtYW5hbHl0aWNzLWFwaS5odG1sXG5pbXBvcnQgeyBsb2cgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgYWRhcHRlciBmcm9tICdwcmViaWQuanMvbGlicmFyaWVzL2FuYWx5dGljc0FkYXB0ZXIvQW5hbHl0aWNzQWRhcHRlci5qcyc7XG5pbXBvcnQgYWRhcHRlck1hbmFnZXIgZnJvbSAncHJlYmlkLmpzL3NyYy9hZGFwdGVyTWFuYWdlci5qcyc7XG5pbXBvcnQgeyBmZXRjaCB9IGZyb20gJ3ByZWJpZC5qcy9zcmMvYWpheC5qcyc7XG5pbXBvcnQgeyBFVkVOVFMgfSBmcm9tICdwcmViaWQuanMvc3JjL2NvbnN0YW50cy5qcyc7XG5pbXBvcnQgeyByZXBvcnRFcnJvciB9IGZyb20gJy4uLy4uLy4uLy4uL2xpYi9lcnJvci9yZXBvcnQtZXJyb3InO1xuaW1wb3J0IHsgZXZlbnRLZXlzLCB9IGZyb20gJy4uLy4uL3ByZWJpZC10eXBlcyc7XG4vKlxuICogVXBkYXRlIHdoZW5ldmVyIHlvdSB3YW50IHRvIG1ha2Ugc3VyZSB5b3UncmUgc2VuZGluZyB0aGUgcmlnaHQgdmVyc2lvbiBvZiBhbmFseXRpY3MuXG4gKiBUaGlzIGlzIHVzZWZ1bCB3aGVuIHNvbWUgYnJvd3NlcnMgYXJlIHVzaW5nIG9sZCBjb2RlIGFuZCBzb21lIG5ldywgZm9yIGV4YW1wbGUuXG4gKi9cbmNvbnN0IFZFUlNJT04gPSA5O1xubGV0IHF1ZXVlID0gW107XG5mdW5jdGlvbiBnZXRCaWRkZXJDb2RlKGFyZ3MpIHtcbiAgICBpZiAoYXJncy5iaWRkZXJDb2RlICE9PSAnb3pvbmUnKVxuICAgICAgICByZXR1cm4gYXJncy5iaWRkZXJDb2RlID8/ICcnO1xuICAgIC8vIE96b25lIHJlcHJlc2VudHMgc2V2ZXJhbCBkaWZmZXJlbnQgYWR2ZXJ0aXNlcnNcbiAgICBpZiAoYXJncy5hZHNlcnZlclRhcmdldGluZykge1xuICAgICAgICAvKipcbiAgICAgICAgICogRWFjaCBPem9uZSBiaWQgY29udGFpbnMgaW5mb3JtYXRpb24gYWJvdXQgYWxsIHRoZSBvdGhlciBiaWRzLlxuICAgICAgICAgKiBUbyBwaW5wb2ludCB3aGljaCBhZHZlcnRpc2VyIGlzIHJlcG9uc2libGUgZm9yIHRoZSBiaWQsXG4gICAgICAgICAqIHdlIGNhbiBtYXRjaCBgYWRJZGAgYWdhaW5zdCB0aGUgYWRzZXJ2ZXJUYXJnZXRpbmcga2V5LXZhbHVlcyBmb3IgZWFjaC5cbiAgICAgICAgICpcbiAgICAgICAgICogRm9yIGV4YW1wbGUsIGdpdmVuIGBvel9hcHBuZXh1c19hZElkOiBcIjEyM2FiYzQ1NmRlZjc4OS0wLTBcImAsXG4gICAgICAgICAqIHdlIHdhbnQgdG8gY2FwdHVyZSBgYXBwbmV4dXNgIGlmIGBhZElkYCBtYXRjaGVzIGAxMjNhYmM0NTZkZWY3ODktMC0wYFxuICAgICAgICAgKi9cbiAgICAgICAgZm9yIChjb25zdCBrZXkgaW4gYXJncy5hZHNlcnZlclRhcmdldGluZykge1xuICAgICAgICAgICAgY29uc3QgWywgYWR2ZXJ0aXNlciwgaW5mb10gPSBrZXkuc3BsaXQoJ18nKTtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXJncy5hZHNlcnZlclRhcmdldGluZ1trZXldO1xuICAgICAgICAgICAgaWYgKGluZm8gPT09ICdhZElkJyAmJiB2YWx1ZSA9PT0gYXJncy5hZElkKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGBvem9uZS0ke2FkdmVydGlzZXJ9YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBJZiBub25lIG1hdGNoZWQsIHVzZSBvem9uZSdzIHdpbm5lciBhcyBmYWxsYmFja1xuICAgICAgICBpZiAoYXJncy5hZHNlcnZlclRhcmdldGluZy5vel93aW5uZXIgJiZcbiAgICAgICAgICAgIHR5cGVvZiBhcmdzLmFkc2VydmVyVGFyZ2V0aW5nLm96X3dpbm5lciA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgIHJldHVybiBgb3pvbmUtJHthcmdzLmFkc2VydmVyVGFyZ2V0aW5nLm96X3dpbm5lcn1gO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBgb3pvbmUtdW5rbm93bmA7XG59XG5mdW5jdGlvbiBsb2dFdmVudHMoZXZlbnRzKSB7XG4gICAgY29uc3QgaXNCaWQgPSBldmVudHNbMF0/LmV2ID09PSAnaW5pdCc7XG4gICAgY29uc3QgaXNCaWRXb24gPSBldmVudHNbMF0/LmV2ID09PSAnYmlkd29uJztcbiAgICBsZXQgbG9nTXNnID0gJyc7XG4gICAgaWYgKGlzQmlkKSB7XG4gICAgICAgIGNvbnN0IHNsb3RJZCA9IGV2ZW50cy5maW5kKChlKSA9PiBlLnNpZCk/LnNpZDtcbiAgICAgICAgbG9nTXNnID0gYGJpZHMgZm9yICR7c2xvdElkID8/ICd1bmtub3duIHNsb3QnfWA7XG4gICAgfVxuICAgIGVsc2UgaWYgKGlzQmlkV29uKSB7XG4gICAgICAgIGNvbnN0IGJpZElkID0gZXZlbnRzWzBdPy5iaWQ7XG4gICAgICAgIGxvZ01zZyA9IGBiaWQgd29uICR7YmlkSWQgPz8gJ3Vua25vd24gYmlkJ31gO1xuICAgIH1cbiAgICBsb2coJ2NvbW1lcmNpYWwnLCBgUHJlYmlkLmpzIGV2ZW50czogJHtsb2dNc2d9YCwgZXZlbnRzKTtcbn1cbmZ1bmN0aW9uIGlzRXZlbnRLZXkoa2V5KSB7XG4gICAgcmV0dXJuIGV2ZW50S2V5cy5pbmNsdWRlcyhrZXkpO1xufVxuLy8gUmVtb3ZlIGFueSBwcm9wZXJ0aWVzIHRoYXQgYXJlIHVuZGVmaW5lZCBvciBudWxsXG5mdW5jdGlvbiBjcmVhdGVFdmVudChldmVudCkge1xuICAgIGlmICghZXZlbnQuZXYpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdFdmVudCBtdXN0IGhhdmUgYW4gXCJldlwiIHByb3BlcnR5Jyk7XG4gICAgfVxuICAgIGNvbnN0IGNsZWFuZWRFdmVudCA9IHtcbiAgICAgICAgZXY6IGV2ZW50LmV2LFxuICAgIH07XG4gICAgZm9yIChjb25zdCBrZXkgaW4gZXZlbnQpIHtcbiAgICAgICAgaWYgKGlzRXZlbnRLZXkoa2V5KSAmJlxuICAgICAgICAgICAgZXZlbnRba2V5XSAhPT0gdW5kZWZpbmVkICYmXG4gICAgICAgICAgICBldmVudFtrZXldICE9PSBudWxsKSB7XG4gICAgICAgICAgICBjbGVhbmVkRXZlbnRba2V5XSA9IGV2ZW50W2tleV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGNsZWFuZWRFdmVudDtcbn1cbi8vIEhhbmRsZXJzIGZvciBlYWNoIGV2ZW50IHR5cGUsIHRoZXNlIGNyZWF0ZSBhIGxvZ2dhYmxlIGV2ZW50IGZyb20gcHJlYmlkIGV2ZW50XG5jb25zdCBoYW5kbGVycyA9IHtcbiAgICBbRVZFTlRTLkFVQ1RJT05fSU5JVF06IChhZGFwdGVyLCBhcmdzKSA9PiB7XG4gICAgICAgIHF1ZXVlID0gW107XG4gICAgICAgIGlmIChhZGFwdGVyLmNvbnRleHQpIHtcbiAgICAgICAgICAgIGFkYXB0ZXIuY29udGV4dC5hdWN0aW9uVGltZVN0YXJ0ID0gRGF0ZS5ub3coKTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBldmVudCA9IGNyZWF0ZUV2ZW50KHtcbiAgICAgICAgICAgIGV2OiAnaW5pdCcsXG4gICAgICAgICAgICBhaWQ6IGFyZ3MuYXVjdGlvbklkLFxuICAgICAgICAgICAgc3Q6IGFkYXB0ZXIuY29udGV4dD8uYXVjdGlvblRpbWVTdGFydCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBbZXZlbnRdO1xuICAgIH0sXG4gICAgW0VWRU5UUy5CSURfUkVRVUVTVEVEXTogKF8sIGFyZ3MpID0+IHtcbiAgICAgICAgaWYgKGFyZ3MuYmlkcykge1xuICAgICAgICAgICAgcmV0dXJuIGFyZ3MuYmlkcy5tYXAoKGJpZCkgPT4ge1xuICAgICAgICAgICAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlRXZlbnQoe1xuICAgICAgICAgICAgICAgICAgICBldjogJ3JlcXVlc3QnLFxuICAgICAgICAgICAgICAgICAgICBuOiBhcmdzLmJpZGRlckNvZGUsXG4gICAgICAgICAgICAgICAgICAgIHNpZDogYmlkLmFkVW5pdENvZGUsXG4gICAgICAgICAgICAgICAgICAgIGJpZDogYmlkLmJpZElkLFxuICAgICAgICAgICAgICAgICAgICBzdDogYXJncy5zdGFydCxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZXZlbnQ7XG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9LFxuICAgIFtFVkVOVFMuQklEX1JFU1BPTlNFXTogKF8sIGFyZ3MpID0+IHtcbiAgICAgICAgaWYgKGFyZ3Muc3RhdHVzTWVzc2FnZSA9PT0gJ0JpZCBhdmFpbGFibGUnKSB7XG4gICAgICAgICAgICBjb25zdCBldmVudCA9IGNyZWF0ZUV2ZW50KHtcbiAgICAgICAgICAgICAgICBldjogJ3Jlc3BvbnNlJyxcbiAgICAgICAgICAgICAgICBuOiBnZXRCaWRkZXJDb2RlKGFyZ3MpLFxuICAgICAgICAgICAgICAgIGJpZDogYXJncy5yZXF1ZXN0SWQsXG4gICAgICAgICAgICAgICAgc2lkOiBhcmdzLmFkVW5pdENvZGUsXG4gICAgICAgICAgICAgICAgY3BtOiBhcmdzLmNwbSxcbiAgICAgICAgICAgICAgICBwYjogYXJncy5wYkNnLFxuICAgICAgICAgICAgICAgIGNyeTogYXJncy5jdXJyZW5jeSxcbiAgICAgICAgICAgICAgICBuZXQ6IGFyZ3MubmV0UmV2ZW51ZSxcbiAgICAgICAgICAgICAgICBkaWQ6IGFyZ3MuYWRJZCxcbiAgICAgICAgICAgICAgICBjaWQ6IGFyZ3MuY3JlYXRpdmVJZCxcbiAgICAgICAgICAgICAgICBzejogYXJncy5zaXplLFxuICAgICAgICAgICAgICAgIHR0cjogYXJncy50aW1lVG9SZXNwb25kLFxuICAgICAgICAgICAgICAgIGxpZDogYXJncy5kZWFsSWQsXG4gICAgICAgICAgICAgICAgZHNwOiBhcmdzLm1ldGE/Lm5ldHdvcmtJZCxcbiAgICAgICAgICAgICAgICBhZHY6IGFyZ3MubWV0YT8uYnV5ZXJJZCxcbiAgICAgICAgICAgICAgICBicmk6IGFyZ3MubWV0YT8uYnJhbmRJZCxcbiAgICAgICAgICAgICAgICBicm46IGFyZ3MubWV0YT8uYnJhbmROYW1lLFxuICAgICAgICAgICAgICAgIGFkZDogYXJncy5tZXRhPy5jbGlja1VybCxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgcmV0dXJuIFtldmVudF07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfSxcbiAgICBbRVZFTlRTLk5PX0JJRF06IChhZGFwdGVyLCBhcmdzKSA9PiB7XG4gICAgICAgIGNvbnN0IGR1cmF0aW9uID0gRGF0ZS5ub3coKSAtIChhZGFwdGVyLmNvbnRleHQ/LmF1Y3Rpb25UaW1lU3RhcnQgPz8gMCk7XG4gICAgICAgIGNvbnN0IGV2ZW50ID0gY3JlYXRlRXZlbnQoe1xuICAgICAgICAgICAgZXY6ICdub2JpZCcsXG4gICAgICAgICAgICBuOiBhcmdzLmJpZGRlciA/PyBhcmdzLmJpZGRlckNvZGUsXG4gICAgICAgICAgICBiaWQ6IGFyZ3MuYmlkSWQgPz8gYXJncy5yZXF1ZXN0SWQsXG4gICAgICAgICAgICBzaWQ6IGFyZ3MuYWRVbml0Q29kZSxcbiAgICAgICAgICAgIGFpZDogYXJncy5hdWN0aW9uSWQsXG4gICAgICAgICAgICB0dHI6IGR1cmF0aW9uLFxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIFtldmVudF07XG4gICAgfSxcbiAgICBbRVZFTlRTLkFVQ1RJT05fRU5EXTogKGFkYXB0ZXIsIGFyZ3MpID0+IHtcbiAgICAgICAgY29uc3QgZHVyYXRpb24gPSBEYXRlLm5vdygpIC0gKGFkYXB0ZXIuY29udGV4dD8uYXVjdGlvblRpbWVTdGFydCA/PyAwKTtcbiAgICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVFdmVudCh7XG4gICAgICAgICAgICBldjogJ2VuZCcsXG4gICAgICAgICAgICBhaWQ6IGFyZ3MuYXVjdGlvbklkLFxuICAgICAgICAgICAgdHRyOiBkdXJhdGlvbixcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBbZXZlbnRdO1xuICAgIH0sXG4gICAgW0VWRU5UUy5CSURfV09OXTogKF8sIGFyZ3MpID0+IHtcbiAgICAgICAgY29uc3QgZXZlbnQgPSBjcmVhdGVFdmVudCh7XG4gICAgICAgICAgICBldjogJ2JpZHdvbicsXG4gICAgICAgICAgICBhaWQ6IGFyZ3MuYXVjdGlvbklkLFxuICAgICAgICAgICAgYmlkOiBhcmdzLnJlcXVlc3RJZCxcbiAgICAgICAgfSk7XG4gICAgICAgIHJldHVybiBbZXZlbnRdO1xuICAgIH0sXG59O1xuY29uc3QgY3JlYXRlUGF5bG9hZCA9IChldmVudHMsIHB2KSA9PiB7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgdjogVkVSU0lPTixcbiAgICAgICAgcHYsXG4gICAgICAgIGhiX2V2OiBldmVudHMsXG4gICAgfTtcbn07XG5jb25zdCBhbmFseXRpY3NBZGFwdGVyID0gT2JqZWN0LmFzc2lnbihhZGFwdGVyKHsgYW5hbHl0aWNzVHlwZTogJ2VuZHBvaW50JyB9KSwge1xuICAgIHNlbmRQYXlsb2FkOiBhc3luYyAodXJsLCBwYXlsb2FkKSA9PiB7XG4gICAgICAgIGNvbnN0IGV2ZW50cyA9IFsuLi5xdWV1ZV07XG4gICAgICAgIHF1ZXVlID0gW107XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwge1xuICAgICAgICAgICAgICAgIG1ldGhvZDogJ1BPU1QnLFxuICAgICAgICAgICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpLFxuICAgICAgICAgICAgICAgIGtlZXBhbGl2ZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBoZWFkZXJzOiB7XG4gICAgICAgICAgICAgICAgICAgICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHNlbmQgYW5hbHl0aWNzIHBheWxvYWQ6ICR7cmVzcG9uc2Uuc3RhdHVzVGV4dH0gKCR7cmVzcG9uc2Uuc3RhdHVzfSlgKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGxvZ0V2ZW50cyhldmVudHMpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgJiYgZXJyb3IubmFtZSA9PT0gJ0Fib3J0RXJyb3InKSB7XG4gICAgICAgICAgICAgICAgLy8gSWdub3JlIGFib3J0IGVycm9ycywgdGhleSBhcmUgZXhwZWN0ZWQgd2hlbiB0aGUgZmV0Y2ggdGltZXMgb3V0XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVwb3J0RXJyb3IoZXJyb3IsICdjb21tZXJjaWFsJywge30sIHtcbiAgICAgICAgICAgICAgICBldmVudHMsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgIH0sXG4gICAgdHJhY2soeyBldmVudFR5cGUsIGFyZ3MgfSkge1xuICAgICAgICBpZiAoIWFuYWx5dGljc0FkYXB0ZXIuY29udGV4dCkge1xuICAgICAgICAgICAgLy8gdGhpcyBzaG91bGQgbmV2ZXIgaGFwcGVuXG4gICAgICAgICAgICByZXBvcnRFcnJvcihuZXcgRXJyb3IoJ2NvbnRleHQgaXMgbm90IGRlZmluZWQsIHByZWJpZCBldmVudCBub3QgYmVpbmcgbG9nZ2VkJyksICdjb21tZXJjaWFsJywge30sIHtcbiAgICAgICAgICAgICAgICBldmVudFR5cGUsXG4gICAgICAgICAgICAgICAgYXJncyxcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgbG9nKCdjb21tZXJjaWFsJywgJ2NvbnRleHQgaXMgbm90IGRlZmluZWQsIHByZWJpZCBldmVudCBub3QgYmVpbmcgbG9nZ2VkJyk7XG4gICAgICAgICAgICByZXR1cm47XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgaGFuZGxlciA9IGhhbmRsZXJzW2V2ZW50VHlwZV07XG4gICAgICAgIGlmIChoYW5kbGVyKSB7XG4gICAgICAgICAgICBjb25zdCBldmVudHMgPSBoYW5kbGVyKGFuYWx5dGljc0FkYXB0ZXIsIGFyZ3MpO1xuICAgICAgICAgICAgaWYgKGV2ZW50cykge1xuICAgICAgICAgICAgICAgIGlmIChldmVudFR5cGUgPT09IEVWRU5UUy5CSURfV09OKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIGNsZWFyIHF1ZXVlIHRvIGF2b2lkIHNlbmRpbmcgbGF0ZSBiaWRzIHdpdGggYmlkV29uIGV2ZW50XG4gICAgICAgICAgICAgICAgICAgIHF1ZXVlID0gW107XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHF1ZXVlLnB1c2goLi4uZXZlbnRzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChbRVZFTlRTLkFVQ1RJT05fRU5ELCBFVkVOVFMuQklEX1dPTl0uaW5jbHVkZXMoZXZlbnRUeXBlKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IHsgcHYsIHVybCB9ID0gYW5hbHl0aWNzQWRhcHRlci5jb250ZXh0O1xuICAgICAgICAgICAgICAgIGNvbnN0IGV2ZW50cyA9IFsuLi5xdWV1ZV07XG4gICAgICAgICAgICAgICAgcXVldWUgPSBbXTtcbiAgICAgICAgICAgICAgICBjb25zdCBwYXlsb2FkID0gY3JlYXRlUGF5bG9hZChldmVudHMsIHB2KTtcbiAgICAgICAgICAgICAgICB2b2lkIGFuYWx5dGljc0FkYXB0ZXIuc2VuZFBheWxvYWQodXJsLCBwYXlsb2FkKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH0sXG59KTtcbmFuYWx5dGljc0FkYXB0ZXIub3JpZ2luRW5hYmxlQW5hbHl0aWNzID0gYW5hbHl0aWNzQWRhcHRlci5lbmFibGVBbmFseXRpY3M7XG5hbmFseXRpY3NBZGFwdGVyLmVuYWJsZUFuYWx5dGljcyA9IChjb25maWcpID0+IHtcbiAgICBhbmFseXRpY3NBZGFwdGVyLmNvbnRleHQgPSB7XG4gICAgICAgIHVybDogY29uZmlnLm9wdGlvbnMudXJsLFxuICAgICAgICBwdjogY29uZmlnLm9wdGlvbnMucHYsXG4gICAgfTtcbiAgICBpZiAoYW5hbHl0aWNzQWRhcHRlci5vcmlnaW5FbmFibGVBbmFseXRpY3MpIHtcbiAgICAgICAgYW5hbHl0aWNzQWRhcHRlci5vcmlnaW5FbmFibGVBbmFseXRpY3MoY29uZmlnKTtcbiAgICB9XG59O1xuYWRhcHRlck1hbmFnZXIucmVnaXN0ZXJBbmFseXRpY3NBZGFwdGVyKHtcbiAgICBhZGFwdGVyOiBhbmFseXRpY3NBZGFwdGVyLFxuICAgIGNvZGU6ICdndScsXG59KTtcbmV4cG9ydCBkZWZhdWx0IGFuYWx5dGljc0FkYXB0ZXI7XG5leHBvcnQgY29uc3QgXyA9IHtcbiAgICBnZXRCaWRkZXJDb2RlLFxuICAgIGNyZWF0ZUV2ZW50LFxuICAgIGhhbmRsZXJzLFxufTtcbiIsImltcG9ydCB7IHJlZ2lzdGVyQmlkZGVyIH0gZnJvbSAncHJlYmlkLmpzL2FkYXB0ZXJzL2JpZGRlckZhY3RvcnknO1xuaW1wb3J0IHsgc3BlYyB9IGZyb20gJ3ByZWJpZC5qcy9tb2R1bGVzL2FwcG5leHVzQmlkQWRhcHRlcic7XG5jb25zdCBjdXN0b21TcGVjID0ge1xuICAgIC4uLnNwZWMsXG4gICAgYWxpYXNlczogWy4uLnNwZWMuYWxpYXNlcywgeyBjb2RlOiAnYW5kJyB9LCB7IGNvZGU6ICd4aGInIH1dLFxufTtcbnJlZ2lzdGVyQmlkZGVyKGN1c3RvbVNwZWMpO1xuIiwiaW1wb3J0IHsgcmVnaXN0ZXJCaWRkZXIgfSBmcm9tICdwcmViaWQuanMvYWRhcHRlcnMvYmlkZGVyRmFjdG9yeSc7XG5pbXBvcnQgeyBzcGVjIH0gZnJvbSAncHJlYmlkLmpzL21vZHVsZXMvb3BlbnhCaWRBZGFwdGVyJztcbmNvbnN0IGN1c3RvbVNwZWMgPSB7XG4gICAgLi4uc3BlYyxcbiAgICBhbGlhc2VzOiBbJ294ZCddLFxufTtcbnJlZ2lzdGVyQmlkZGVyKGN1c3RvbVNwZWMpO1xuIl0sIm5hbWVzIjpbImV2ZW50S2V5cyIsImxvZyIsImFkYXB0ZXIiLCJhZGFwdGVyTWFuYWdlciIsImZldGNoIiwiRVZFTlRTIiwicmVwb3J0RXJyb3IiLCJWRVJTSU9OIiwicXVldWUiLCJnZXRCaWRkZXJDb2RlIiwiYXJncyIsIl9hcmdzJGJpZGRlckNvZGUiLCJiaWRkZXJDb2RlIiwiYWRzZXJ2ZXJUYXJnZXRpbmciLCJrZXkiLCJhZHZlcnRpc2VyIiwiaW5mbyIsInNwbGl0IiwidmFsdWUiLCJhZElkIiwiY29uY2F0Iiwib3pfd2lubmVyIiwibG9nRXZlbnRzIiwiZXZlbnRzIiwiX2V2ZW50cyQiLCJfZXZlbnRzJDIiLCJpc0JpZCIsImV2IiwiaXNCaWRXb24iLCJsb2dNc2ciLCJfZXZlbnRzJGZpbmQiLCJzbG90SWQiLCJmaW5kIiwiZSIsInNpZCIsIl9ldmVudHMkMyIsImJpZElkIiwiYmlkIiwiaXNFdmVudEtleSIsImluY2x1ZGVzIiwiY3JlYXRlRXZlbnQiLCJldmVudCIsIkVycm9yIiwiY2xlYW5lZEV2ZW50IiwidW5kZWZpbmVkIiwiaGFuZGxlcnMiLCJBVUNUSU9OX0lOSVQiLCJfYWRhcHRlciRjb250ZXh0IiwiY29udGV4dCIsImF1Y3Rpb25UaW1lU3RhcnQiLCJEYXRlIiwibm93IiwiYWlkIiwiYXVjdGlvbklkIiwic3QiLCJCSURfUkVRVUVTVEVEIiwiXyIsImJpZHMiLCJtYXAiLCJuIiwiYWRVbml0Q29kZSIsInN0YXJ0IiwiQklEX1JFU1BPTlNFIiwic3RhdHVzTWVzc2FnZSIsIl9hcmdzJG1ldGEiLCJfYXJncyRtZXRhMiIsIl9hcmdzJG1ldGEzIiwiX2FyZ3MkbWV0YTQiLCJfYXJncyRtZXRhNSIsInJlcXVlc3RJZCIsImNwbSIsInBiIiwicGJDZyIsImNyeSIsImN1cnJlbmN5IiwibmV0IiwibmV0UmV2ZW51ZSIsImRpZCIsImNpZCIsImNyZWF0aXZlSWQiLCJzeiIsInNpemUiLCJ0dHIiLCJ0aW1lVG9SZXNwb25kIiwibGlkIiwiZGVhbElkIiwiZHNwIiwibWV0YSIsIm5ldHdvcmtJZCIsImFkdiIsImJ1eWVySWQiLCJicmkiLCJicmFuZElkIiwiYnJuIiwiYnJhbmROYW1lIiwiYWRkIiwiY2xpY2tVcmwiLCJOT19CSUQiLCJfYWRhcHRlciRjb250ZXh0JGF1Y3QiLCJfYWRhcHRlciRjb250ZXh0MiIsIl9hcmdzJGJpZGRlciIsIl9hcmdzJGJpZElkIiwiZHVyYXRpb24iLCJiaWRkZXIiLCJBVUNUSU9OX0VORCIsIl9hZGFwdGVyJGNvbnRleHQkYXVjdDIiLCJfYWRhcHRlciRjb250ZXh0MyIsIkJJRF9XT04iLCJjcmVhdGVQYXlsb2FkIiwicHYiLCJ2IiwiaGJfZXYiLCJhbmFseXRpY3NBZGFwdGVyIiwiT2JqZWN0IiwiYXNzaWduIiwiYW5hbHl0aWNzVHlwZSIsInNlbmRQYXlsb2FkIiwiX3JlZiIsIl9hc3luY1RvR2VuZXJhdG9yIiwidXJsIiwicGF5bG9hZCIsInJlc3BvbnNlIiwibWV0aG9kIiwiYm9keSIsIkpTT04iLCJzdHJpbmdpZnkiLCJrZWVwYWxpdmUiLCJoZWFkZXJzIiwib2siLCJzdGF0dXNUZXh0Iiwic3RhdHVzIiwiZXJyb3IiLCJuYW1lIiwiX3giLCJfeDIiLCJhcHBseSIsImFyZ3VtZW50cyIsInRyYWNrIiwiX3JlZjIiLCJldmVudFR5cGUiLCJoYW5kbGVyIiwicHVzaCIsIm9yaWdpbkVuYWJsZUFuYWx5dGljcyIsImVuYWJsZUFuYWx5dGljcyIsImNvbmZpZyIsIm9wdGlvbnMiLCJyZWdpc3RlckFuYWx5dGljc0FkYXB0ZXIiLCJjb2RlIiwicmVnaXN0ZXJCaWRkZXIiLCJzcGVjIiwiY3VzdG9tU3BlYyIsIl9vYmplY3RTcHJlYWQiLCJhbGlhc2VzIl0sInNvdXJjZVJvb3QiOiIifQ==