"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["vendors-node_modules_pnpm_prebid_js_9_27_0_ejs_3_1_10_handlebars_4_7_8_node_modules_prebid_js-3193a3"],{

/***/ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js":
/*!*************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js ***!
  \*************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _defineProperty)
/* harmony export */ });
/* harmony import */ var _toPropertyKey_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./toPropertyKey.js */ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js");

function _defineProperty(e, r, t) {
  return (r = (0,_toPropertyKey_js__WEBPACK_IMPORTED_MODULE_0__["default"])(r)) in e ? Object.defineProperty(e, r, {
    value: t,
    enumerable: !0,
    configurable: !0,
    writable: !0
  }) : e[r] = t, e;
}


/***/ }),

/***/ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js":
/*!**********************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js ***!
  \**********************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ toPrimitive)
/* harmony export */ });
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./typeof.js */ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/typeof.js");

function toPrimitive(t, r) {
  if ("object" != (0,_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(t) || !t) return t;
  var e = t[Symbol.toPrimitive];
  if (void 0 !== e) {
    var i = e.call(t, r || "default");
    if ("object" != (0,_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(i)) return i;
    throw new TypeError("@@toPrimitive must return a primitive value.");
  }
  return ("string" === r ? String : Number)(t);
}


/***/ }),

/***/ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js":
/*!************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/toPropertyKey.js ***!
  \************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ toPropertyKey)
/* harmony export */ });
/* harmony import */ var _typeof_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./typeof.js */ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/typeof.js");
/* harmony import */ var _toPrimitive_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./toPrimitive.js */ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/toPrimitive.js");


function toPropertyKey(t) {
  var i = (0,_toPrimitive_js__WEBPACK_IMPORTED_MODULE_1__["default"])(t, "string");
  return "symbol" == (0,_typeof_js__WEBPACK_IMPORTED_MODULE_0__["default"])(i) ? i : i + "";
}


/***/ }),

/***/ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/typeof.js":
/*!*****************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/typeof.js ***!
  \*****************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ _typeof)
/* harmony export */ });
function _typeof(o) {
  "@babel/helpers - typeof";

  return _typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function (o) {
    return typeof o;
  } : function (o) {
    return o && "function" == typeof Symbol && o.constructor === Symbol && o !== Symbol.prototype ? "symbol" : typeof o;
  }, _typeof(o);
}


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/ab.js":
/*!****************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/ab.js ***!
  \****************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AB: () => (/* binding */ AB)
/* harmony export */ });
/* harmony import */ var _core_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./core.js */ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/core.js");
/* harmony import */ var _ophan_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./ophan.js */ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/ophan.js");


var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
  enumerable: true,
  configurable: true,
  writable: true,
  value
}) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class AB {
  constructor(_ref) {
    var {
      abTestSwitches,
      arrayOfTestObjects,
      errorReporter,
      forcedTestException,
      forcedTestVariants,
      mvtId,
      mvtMaxValue,
      ophanRecord,
      pageIsSensitive,
      serverSideTests
    } = _ref;
    __publicField(this, "_core");
    __publicField(this, "_ophan");
    this._core = (0,_core_js__WEBPACK_IMPORTED_MODULE_0__.initCore)({
      abTestSwitches,
      arrayOfTestObjects,
      forcedTestException,
      forcedTestVariants,
      mvtId,
      mvtMaxValue,
      pageIsSensitive
    });
    this._ophan = (0,_ophan_js__WEBPACK_IMPORTED_MODULE_1__.initOphan)({
      errorReporter,
      ophanRecord,
      serverSideTests
    });
  }
  // CoreAPI
  get allRunnableTests() {
    return this._core.allRunnableTests;
  }
  get firstRunnableTest() {
    return this._core.firstRunnableTest;
  }
  get runnableTest() {
    return this._core.runnableTest;
  }
  get isUserInVariant() {
    return this._core.isUserInVariant;
  }
  // OphanAPI
  get registerCompleteEvents() {
    return this._ophan.registerCompleteEvents;
  }
  get registerImpressionEvents() {
    return this._ophan.registerImpressionEvents;
  }
  get trackABTests() {
    return this._ophan.trackABTests;
  }
}


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/core.js":
/*!******************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/core.js ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initCore: () => (/* binding */ initCore)
/* harmony export */ });
/* harmony import */ var _time_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./time.js */ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/time.js");
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }

var initCore = _ref => {
  var {
    mvtMaxValue = 1e6,
    mvtId,
    pageIsSensitive,
    abTestSwitches,
    forcedTestVariants,
    forcedTestException,
    arrayOfTestObjects = []
  } = _ref;
  var variantCanBeRun = variant => {
    var isInTest = variant.id !== "notintest";
    if (variant.canRun) {
      return variant.canRun() && isInTest;
    } else {
      return isInTest;
    }
  };
  var testCanBeRun = test => {
    var expired = (0,_time_js__WEBPACK_IMPORTED_MODULE_0__.isExpired)(test.expiry);
    var testShouldShowForSensitive = !!test.showForSensitive;
    var isTestOn = abTestSwitches["ab".concat(test.id)] && !!abTestSwitches["ab".concat(test.id)];
    var canTestBeRun = test.canRun();
    return (pageIsSensitive ? testShouldShowForSensitive : true) && !!isTestOn && !expired && canTestBeRun;
  };
  var computeVariantFromMvtCookie = test => {
    var smallestTestId = mvtMaxValue * test.audienceOffset;
    var largestTestId = smallestTestId + mvtMaxValue * test.audience;
    if (mvtId && mvtId > smallestTestId && mvtId <= largestTestId) {
      var _test$variants;
      return (_test$variants = test.variants[mvtId % test.variants.length]) !== null && _test$variants !== void 0 ? _test$variants : null;
    }
    return null;
  };
  var getForcedTestVariant = (test, forcedTestVariants2) => {
    var _forcedTestVariants2$;
    var testId = test.id;
    var getVariantFromIds = (test2, variantId) => {
      var _test2$variants$find;
      return (_test2$variants$find = test2.variants.find(variant => variant.id === variantId)) !== null && _test2$variants$find !== void 0 ? _test2$variants$find : false;
    };
    var forcedTest = forcedTestVariants2 === null || forcedTestVariants2 === void 0 || (_forcedTestVariants2$ = forcedTestVariants2[testId]) === null || _forcedTestVariants2$ === void 0 ? void 0 : _forcedTestVariants2$.variant;
    return forcedTest ? getVariantFromIds(test, forcedTest) : false;
  };
  var runnableTest = test => {
    var fromCookie = computeVariantFromMvtCookie(test);
    var variantFromForcedTest = getForcedTestVariant(test, forcedTestVariants);
    var forcedOutOfTest = forcedTestException === test.id;
    var variantToRun = variantFromForcedTest || fromCookie;
    if (!forcedOutOfTest && (variantFromForcedTest || testCanBeRun(test)) &&
    // We ignore the test's canRun if the test is forced
    variantToRun && (variantFromForcedTest || variantCanBeRun(variantToRun))) {
      return _objectSpread(_objectSpread({}, test), {}, {
        variantToRun
      });
    }
    return null;
  };
  var allRunnableTests = tests => tests.reduce((prev, currentValue) => {
    var rt = runnableTest(currentValue);
    return rt ? [...prev, rt] : prev;
  }, []);
  var firstRunnableTest = tests => {
    var _tests$map$find;
    return (_tests$map$find = tests.map(test => runnableTest(test)).find(rt => rt !== null)) !== null && _tests$map$find !== void 0 ? _tests$map$find : null;
  };
  var isUserInVariant = (testId, variantId) => allRunnableTests(arrayOfTestObjects).some(runnableTest2 => {
    return runnableTest2.id === testId && runnableTest2.variantToRun.id === variantId;
  });
  return {
    allRunnableTests,
    runnableTest,
    firstRunnableTest,
    isUserInVariant
  };
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/ophan.js":
/*!*******************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/ophan.js ***!
  \*******************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initOphan: () => (/* binding */ initOphan)
/* harmony export */ });
var submit = (payload, ophanRecord) => ophanRecord({
  abTestRegister: payload
});
var makeABEvent = (variant, complete) => {
  var event = {
    variantName: variant.id,
    complete
  };
  if (variant.campaignCode) {
    event.campaignCodes = [variant.campaignCode];
  }
  return event;
};
var defersImpression = test => test.variants.every(variant => typeof variant.impression === "function");
var buildOphanSubmitter = (test, variant, complete, ophanRecord) => {
  var data = {
    [test.id]: makeABEvent(variant, complete)
  };
  return () => submit(data, ophanRecord);
};
var registerCompleteEvent = (complete, errorReporter, ophanRecord) => test => {
  var variant = test.variantToRun;
  var listener = complete ? variant.success : variant.impression;
  if (!listener) {
    return;
  }
  try {
    listener(buildOphanSubmitter(test, variant, complete, ophanRecord));
  } catch (error) {
    errorReporter(error);
  }
};
var buildOphanPayload = (tests, errorReporter, serverSideTestObj) => {
  try {
    var log = {};
    var serverSideTests = Object.keys(serverSideTestObj).filter(test => !!serverSideTestObj[test]);
    tests.filter(test => !defersImpression(test)).forEach(test => {
      log[test.id] = makeABEvent(test.variantToRun, false);
    });
    serverSideTests.forEach(test => {
      var serverSideVariant = {
        id: "inTest",
        test: () => void 0
      };
      log["ab".concat(test)] = makeABEvent(serverSideVariant, false);
    });
    return log;
  } catch (error) {
    errorReporter(error);
    return {};
  }
};
var initOphan = _ref => {
  var {
    serverSideTests,
    errorReporter,
    ophanRecord
  } = _ref;
  return {
    registerCompleteEvents: tests => tests.forEach(registerCompleteEvent(true, errorReporter, ophanRecord)),
    registerImpressionEvents: tests => tests.filter(defersImpression).forEach(registerCompleteEvent(false, errorReporter, ophanRecord)),
    trackABTests: tests => submit(buildOphanPayload(tests, errorReporter, serverSideTests), ophanRecord)
  };
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/time.js":
/*!******************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+ab-core@8.0.1_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/ab-core/dist/time.js ***!
  \******************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isExpired: () => (/* binding */ isExpired)
/* harmony export */ });
var isExpired = testExpiry => {
  var currentTime = (/* @__PURE__ */new Date()).valueOf();
  var theTestExpiry = new Date(testExpiry).setHours(23, 59, 59, 59);
  return currentTime > theTestExpiry;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth-frontend@12.0.0_@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0__hy3woi5sfpbstbkj7mijybq7mu/node_modules/@guardian/identity-auth-frontend/dist/index.js":
/*!******************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth-frontend@12.0.0_@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0__hy3woi5sfpbstbkj7mijybq7mu/node_modules/@guardian/identity-auth-frontend/dist/index.js ***!
  \******************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getIdentityAuth: () => (/* binding */ getIdentityAuth)
/* harmony export */ });
/* harmony import */ var _guardian_identity_auth__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/identity-auth */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/identityAuth.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isOneOf/isOneOf.js");


var stages = ["PROD", "CODE", "DEV"];
var isStage = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.isOneOf)(stages);
var getStage = (isDev, stage) => isDev || !isStage(stage) ? "DEV" : stage;
var getIssuer = stage => stage === "PROD" ? "https://profile.theguardian.com/oauth2/aus3xgj525jYQRowl417" : "https://profile.code.dev-theguardian.com/oauth2/aus3v9gla95Toj0EE0x7";
var getClientId = stage => stage === "PROD" ? "0oa79m1fmgzrtaHc1417" : "0oa53x6k5wGYXOGzm0x7";
var getRedirectUri = (stage, origin) => {
  switch (stage) {
    case "PROD":
      if (origin === "https://profile.theguardian.com") {
        return "https://profile.theguardian.com/";
      }
      return "https://www.theguardian.com/";
    case "CODE":
      if (origin === "https://profile.code.dev-theguardian.com") {
        return "https://profile.code.dev-theguardian.com/";
      }
      return "https://m.code.dev-theguardian.com/";
    case "DEV":
    default:
      if (origin === "https://r.thegulocal.com") {
        return "https://r.thegulocal.com/";
      }
      if (origin === "https://m.thegulocal.com") {
        return "https://m.thegulocal.com/";
      }
      return "http://localhost:3030/";
  }
};
var getIdentityAuth = () => {
  var _window$guardian$conf, _a$identityAuth, _switches$idCookieRef;
  var _a;
  if (!window.guardian) {
    throw new Error("window.guardian has not yet been initialized");
  }
  var {
    isDev = false,
    stage = "PROD",
    switches
  } = (_window$guardian$conf = window.guardian.config) !== null && _window$guardian$conf !== void 0 ? _window$guardian$conf : {};
  var stageOrDev = getStage(isDev, stage);
  (_a$identityAuth = (_a = window.guardian).identityAuth) !== null && _a$identityAuth !== void 0 ? _a$identityAuth : _a.identityAuth = new _guardian_identity_auth__WEBPACK_IMPORTED_MODULE_0__.IdentityAuth({
    issuer: getIssuer(stageOrDev),
    clientId: getClientId(stageOrDev),
    redirectUri: getRedirectUri(stageOrDev, window.location.origin),
    idCookieSessionRefresh: (_switches$idCookieRef = switches === null || switches === void 0 ? void 0 : switches.idCookieRefresh) !== null && _switches$idCookieRef !== void 0 ? _switches$idCookieRef : false,
    scopes: ["openid",
    // required for open id connect, returns an id token
    "profile",
    // populates the id token with basic profile information
    "email",
    // populates the id token with the user's email address
    "guardian.discussion-api.private-profile.read.self",
    // allows the access token to be used to make requests to the discussion api to read the user's profile
    "guardian.discussion-api.update.secure",
    // allows the access token to be used to make requests to the discussion api to post comments, upvote etc
    "guardian.identity-api.newsletters.read.self",
    // allows the access token to be used to make requests to the identity api to read the user's newsletter subscriptions
    "guardian.identity-api.newsletters.update.self",
    // allows the access token to be used to make requests to the identity api to update the user's newsletter subscriptions
    "guardian.identity-api.user.username.create.self.secure",
    // allows the access token to set the user's username
    "guardian.members-data-api.read.self",
    // allows the access token to be used to make requests to the members data api to read the user's membership status
    "id_token.profile.theguardian"
    // populates the id token with application specific profile information
    ]
  });
  return window.guardian.identityAuth;
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/@types/OAuth.js":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/@types/OAuth.js ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isProfileUrl: () => (/* binding */ isProfileUrl)
/* harmony export */ });
/* harmony import */ var _guard_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./guard.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/@types/guard.js");

var profileUrls = ["https://profile.theguardian.com", "https://profile.code.dev-theguardian.com", "https://profile.thegulocal.com"];
var isProfileUrl = (0,_guard_js__WEBPACK_IMPORTED_MODULE_0__.guard)(profileUrls);


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/@types/guard.js":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/@types/guard.js ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   guard: () => (/* binding */ guard)
/* harmony export */ });
var guard = array => value => array.includes(value);


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/authState.js":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/authState.js ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AuthStateManager: () => (/* binding */ AuthStateManager)
/* harmony export */ });
var __typeError = msg => {
  throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _authState, _emitter, _tokenManager, _AuthStateManager_instances, updateAuthState_fn;
class AuthStateManager {
  constructor(emitter, tokenManager) {
    __privateAdd(this, _AuthStateManager_instances);
    __privateAdd(this, _authState);
    __privateAdd(this, _emitter);
    __privateAdd(this, _tokenManager);
    __privateSet(this, _emitter, emitter);
    __privateSet(this, _tokenManager, tokenManager);
    __privateSet(this, _authState, {
      accessToken: void 0,
      idToken: void 0,
      isAuthenticated: false
    });
    __privateMethod(this, _AuthStateManager_instances, updateAuthState_fn).call(this);
    __privateGet(this, _emitter).on("added", () => {
      __privateMethod(this, _AuthStateManager_instances, updateAuthState_fn).call(this);
    });
    __privateGet(this, _emitter).on("removed", () => {
      __privateMethod(this, _AuthStateManager_instances, updateAuthState_fn).call(this);
    });
    __privateGet(this, _emitter).on("storage", () => {
      __privateMethod(this, _AuthStateManager_instances, updateAuthState_fn).call(this);
    });
  }
  /**
   * @name getAuthState
   * @description Returns the current auth state
   * @returns IdentityAuthState
   */
  getAuthState() {
    return __privateGet(this, _authState);
  }
  /**
   * @name subscribe
   * @description Subscribes to auth state changes
   * @param handler	- The EventCallback to use to subscribe
   */
  subscribe(handler) {
    __privateGet(this, _emitter).on("authStateChange", handler);
  }
  /**
   * @name unsubscribe
   * @description Unsubscribes from auth state changes
   * @param handler	- The EventCallback to used to subscribe
   */
  unsubscribe(handler) {
    __privateGet(this, _emitter).off("authStateChange", handler);
  }
}
_authState = new WeakMap();
_emitter = new WeakMap();
_tokenManager = new WeakMap();
_AuthStateManager_instances = new WeakSet();
/**
 * @name updateAuthState
 * @description Updates the auth state based on the tokens in storage
 * @returns void
 */
updateAuthState_fn = function () {
  var tokens = __privateGet(this, _tokenManager).getTokensSync();
  if (tokens) {
    __privateSet(this, _authState, {
      accessToken: tokens.accessToken,
      idToken: tokens.idToken,
      isAuthenticated: true
    });
  } else {
    __privateSet(this, _authState, {
      accessToken: void 0,
      idToken: void 0,
      isAuthenticated: false
    });
  }
  __privateGet(this, _emitter).emit("authStateChange", __privateGet(this, _authState));
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/autoRenew.js":
/*!*************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/autoRenew.js ***!
  \*************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AutoRenewService: () => (/* binding */ AutoRenewService)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");

var __defProp = Object.defineProperty;
var __typeError = msg => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
  enumerable: true,
  configurable: true,
  writable: true,
  value
}) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, key + "", value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _options, _emitter, _authStateManager, _renewAtTimeoutId, _AutoRenewService_instances, clearRenewAtTimeout_fn, setRenewAtTimeout_fn, handleAuthStateChange_fn;
class AutoRenewService {
  constructor(options, emitter, authStateManager) {
    __privateAdd(this, _AutoRenewService_instances);
    __privateAdd(this, _options);
    __privateAdd(this, _emitter);
    __privateAdd(this, _authStateManager);
    __publicField(this, "started", false);
    __privateAdd(this, _renewAtTimeoutId);
    __privateSet(this, _options, options);
    __privateSet(this, _emitter, emitter);
    __privateSet(this, _authStateManager, authStateManager);
    __privateGet(this, _emitter).on("storage", () => {
      __privateMethod(this, _AutoRenewService_instances, clearRenewAtTimeout_fn).call(this);
      __privateMethod(this, _AutoRenewService_instances, handleAuthStateChange_fn).call(this);
    });
  }
  /**
   * @name start
   * @description Starts the auto renewal service if autoRenew is enabled
   */
  start() {
    if (__privateGet(this, _options).autoRenew && !this.started) {
      this.started = true;
      __privateGet(this, _emitter).on("authStateChange", state => __privateMethod(this, _AutoRenewService_instances, handleAuthStateChange_fn).call(this, state));
      __privateMethod(this, _AutoRenewService_instances, handleAuthStateChange_fn).call(this);
    }
  }
}
_options = new WeakMap();
_emitter = new WeakMap();
_authStateManager = new WeakMap();
_renewAtTimeoutId = new WeakMap();
_AutoRenewService_instances = new WeakSet();
/**
 * @name clearRenewAtTimeout
 * @description Clears the timeout for renewing the access token, if it exists
 */
clearRenewAtTimeout_fn = function () {
  if (__privateGet(this, _renewAtTimeoutId) !== void 0) {
    window.clearTimeout(__privateGet(this, _renewAtTimeoutId));
    __privateSet(this, _renewAtTimeoutId, void 0);
  }
};
/**
 * @name setRenewAtTimeout
 * @description Sets the timeout for renewing the access token based on the expiry time and the grace period
 * @param expiresAt The time at which the access token expires
 * @returns The timeout id
 */
setRenewAtTimeout_fn = function (expiresAt) {
  var now = Date.now();
  var renewAt = (expiresAt - __privateGet(this, _options).renewGracePeriod) * 1e3;
  var timeout = renewAt - now;
  __privateSet(this, _renewAtTimeoutId, window.setTimeout(() => {
    if (window.document.visibilityState === "hidden") {
      window.document.addEventListener("visibilitychange", () => {
        if (window.document.visibilityState === "visible") {
          var authState = __privateGet(this, _authStateManager).getAuthState();
          if (authState.isAuthenticated && authState.accessToken.expiresAt - __privateGet(this, _options).renewGracePeriod < Math.floor(Date.now() / 1e3)) {
            __privateGet(this, _emitter).emit("renew");
          }
          if (!authState.isAuthenticated && !!(0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
            name: "GU_U",
            shouldMemoize: true
          })) {
            __privateGet(this, _emitter).emit("renew");
          }
        }
      }, {
        once: true
        // only listen for the event once
      });
    } else {
      __privateGet(this, _emitter).emit("renew");
    }
    __privateSet(this, _renewAtTimeoutId, void 0);
  }, timeout));
};
/**
 * @name handleAuthStateChange
 * @description Listens for changes to the auth state and sets the timeout for renewing the access token if required
 * @param state - The IdentityAuthState
 */
handleAuthStateChange_fn = function (state) {
  __privateMethod(this, _AutoRenewService_instances, clearRenewAtTimeout_fn).call(this);
  var authState = state !== null && state !== void 0 ? state : __privateGet(this, _authStateManager).getAuthState();
  if (authState.isAuthenticated) {
    __privateMethod(this, _AutoRenewService_instances, setRenewAtTimeout_fn).call(this, authState.accessToken.expiresAt);
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/cookieRefresh.js":
/*!*****************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/cookieRefresh.js ***!
  \*****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   cookieRefreshIfRequired: () => (/* binding */ cookieRefreshIfRequired)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
/* harmony import */ var _types_OAuth_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./@types/OAuth.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/@types/OAuth.js");
/* harmony import */ var _error_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./error.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/error.js");



var days30InMillis = 1e3 * 60 * 60 * 24 * 30;
var redirectToRefreshEndpoint = (profileUrl, returnUrl) => {
  var endpoint = "".concat(profileUrl, "/signin/refresh?returnUrl=").concat(returnUrl);
  window.location.replace(endpoint);
};
var shouldRefreshCookie = (lastRefresh, currentTime) => {
  var lastRefreshIsValid = !!Number(lastRefresh);
  if (!lastRefreshIsValid) {
    return true;
  }
  return currentTime - Number(lastRefresh) > days30InMillis;
};
var cookieRefreshIfRequired = (enabled, issuer) => {
  var profileUrl = issuer.split("/oauth2")[0];
  if (!(0,_types_OAuth_js__WEBPACK_IMPORTED_MODULE_2__.isProfileUrl)(profileUrl)) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_3__.OAuthError({
      error: "invalid_issuer",
      error_description: "The issuer, ".concat(issuer, ", does not match the expected format.")
    });
  }
  var lastRefreshKey = "identity.lastRefresh";
  if (enabled && _guardian_libs__WEBPACK_IMPORTED_MODULE_1__.storage.local.isAvailable() && (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
    name: "GU_U",
    shouldMemoize: true
  })) {
    var currentTime = (/* @__PURE__ */new Date()).getTime();
    var lastRefresh = _guardian_libs__WEBPACK_IMPORTED_MODULE_1__.storage.local.get(lastRefreshKey);
    if (shouldRefreshCookie(lastRefresh, currentTime)) {
      var newExpiry = currentTime + days30InMillis;
      _guardian_libs__WEBPACK_IMPORTED_MODULE_1__.storage.local.set(lastRefreshKey, currentTime, newExpiry);
      redirectToRefreshEndpoint(profileUrl, encodeURIComponent(document.location.href));
    }
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/crypto.js":
/*!**********************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/crypto.js ***!
  \**********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   base64UrlEncode: () => (/* binding */ base64UrlEncode),
/* harmony export */   base64UrlToBase64: () => (/* binding */ base64UrlToBase64),
/* harmony export */   base64UrlToString: () => (/* binding */ base64UrlToString),
/* harmony export */   dec2hex: () => (/* binding */ dec2hex),
/* harmony export */   generateCodeChallenge: () => (/* binding */ generateCodeChallenge),
/* harmony export */   generateCodeVerifier: () => (/* binding */ generateCodeVerifier),
/* harmony export */   generateSha256Hash: () => (/* binding */ generateSha256Hash),
/* harmony export */   getRandomString: () => (/* binding */ getRandomString),
/* harmony export */   stringToBuffer: () => (/* binding */ stringToBuffer)
/* harmony export */ });
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
var dec2hex = dec => {
  var hex = dec.toString(16);
  return "0".substring(0, 2 - hex.length) + hex;
};
var getRandomString = length => {
  var arr = new Uint8Array(Math.ceil(length / 2));
  window.crypto.getRandomValues(arr);
  var str = Array.from(arr, dec2hex).join("");
  return str.slice(0, length);
};
var generateSha256Hash = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (str) {
    var buffer = new TextEncoder().encode(str);
    var hashBuffer = yield window.crypto.subtle.digest("SHA-256", buffer);
    var hashArray = Array.from(new Uint8Array(hashBuffer));
    var hash = String.fromCharCode.apply(null, new Uint8Array(hashArray));
    return hash;
  });
  return function generateSha256Hash(_x) {
    return _ref.apply(this, arguments);
  };
}();
var generateCodeVerifier = () => getRandomString(128);
var generateCodeChallenge = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* (codeVerifier) {
    var hash = yield generateSha256Hash(codeVerifier);
    var base64url = base64UrlEncode(hash);
    return base64url;
  });
  return function generateCodeChallenge(_x2) {
    return _ref2.apply(this, arguments);
  };
}();
var base64UrlToString = base64Url => {
  var base64 = base64UrlToBase64(base64Url);
  switch (base64.length % 4) {
    case 0:
      break;
    case 2:
      base64 += "==";
      break;
    case 3:
      base64 += "=";
      break;
    default:
      throw new Error("Not a valid Base64Url");
  }
  var utf8str = window.atob(base64);
  try {
    return decodeURIComponent(window.escape(utf8str));
  } catch (e) {
    return utf8str;
  }
};
var stringToBuffer = str => {
  var buffer = new Uint8Array(str.length);
  for (var i = 0; i < str.length; i++) {
    buffer[i] = str.charCodeAt(i);
  }
  return buffer;
};
var base64UrlToBase64 = base64Url => base64Url.replace(/-/g, "+").replace(/_/g, "/");
var base64UrlEncode = str => window.btoa(str).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "");


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/emitter.js":
/*!***********************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/emitter.js ***!
  \***********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Emitter: () => (/* binding */ Emitter)
/* harmony export */ });
var __typeError = msg => {
  throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var _events;
class Emitter {
  constructor() {
    // List of all events
    __privateAdd(this, _events);
    __privateSet(this, _events, {});
  }
  /**
   * @name on
   * @description Used to subscribe to an event by name
   *
   * @param name - The name of the event to subscribe to
   * @param callback - The callback to run when the event is emitted
   * @param ctx - The context to run the callback in
   * @returns this - The emitter for chaining purposes
   */
  on(name, callback, ctx) {
    var _events$name;
    var events = __privateGet(this, _events);
    var eventArr = (_events$name = events[name]) !== null && _events$name !== void 0 ? _events$name : events[name] = [];
    eventArr.push({
      fn: callback,
      ctx
    });
    return this;
  }
  /**
   * @name off
   * @description Used to unsubscribe from an event by name
   *
   * @param name - The name of the event to unsubscribe from
   * @param callback - The callback to unsubscribe
   * @returns this - The emitter for chaining purposes
   */
  off(name, callback) {
    var events = __privateGet(this, _events);
    var eventArr = events[name];
    var liveEvents = [];
    if (eventArr && callback) {
      liveEvents.push(...eventArr.filter(event => event.fn !== callback));
    }
    if (liveEvents.length) {
      events[name] = liveEvents;
    } else {
      delete events[name];
    }
    return this;
  }
  /**
   * @name emit
   * @description Used to emit an event by name
   *
   * @param name - The name of the event to emit
   * @param data - The data to pass to the callback
   * @returns this - The emitter for chaining purposes
   */
  emit(name) {
    var _privateGet$name;
    for (var _len = arguments.length, data = new Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
      data[_key - 1] = arguments[_key];
    }
    var eventArr = ((_privateGet$name = __privateGet(this, _events)[name]) !== null && _privateGet$name !== void 0 ? _privateGet$name : []).slice();
    eventArr.forEach(event => {
      event.fn.apply(event.ctx, data);
    });
    return this;
  }
}
_events = new WeakMap();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/error.js":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/error.js ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   OAuthError: () => (/* binding */ OAuthError)
/* harmony export */ });
var __defProp = Object.defineProperty;
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
  enumerable: true,
  configurable: true,
  writable: true,
  value
}) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
class OAuthError extends Error {
  constructor(error) {
    super(error.message);
    __publicField(this, "error");
    __publicField(this, "error_description");
    this.error = error.error;
    this.error_description = error.error_description;
    this.name = "OAuthError";
  }
}


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/identityAuth.js":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/identityAuth.js ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   IdentityAuth: () => (/* binding */ IdentityAuth)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookie.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/removeCookie.js");
/* harmony import */ var _authState_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./authState.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/authState.js");
/* harmony import */ var _autoRenew_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./autoRenew.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/autoRenew.js");
/* harmony import */ var _cookieRefresh_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cookieRefresh.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/cookieRefresh.js");
/* harmony import */ var _emitter_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./emitter.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/emitter.js");
/* harmony import */ var _error_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./error.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/error.js");
/* harmony import */ var _token_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./token.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/token.js");
/* harmony import */ var _tokenManager_js__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./tokenManager.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/tokenManager.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }
function ownKeys(e, r) { var t = Object.keys(e); if (Object.getOwnPropertySymbols) { var o = Object.getOwnPropertySymbols(e); r && (o = o.filter(function (r) { return Object.getOwnPropertyDescriptor(e, r).enumerable; })), t.push.apply(t, o); } return t; }
function _objectSpread(e) { for (var r = 1; r < arguments.length; r++) { var t = null != arguments[r] ? arguments[r] : {}; r % 2 ? ownKeys(Object(t), !0).forEach(function (r) { _defineProperty(e, r, t[r]); }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) { Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r)); }); } return e; }
function _defineProperty(e, r, t) { return (r = _toPropertyKey(r)) in e ? Object.defineProperty(e, r, { value: t, enumerable: !0, configurable: !0, writable: !0 }) : e[r] = t, e; }
function _toPropertyKey(t) { var i = _toPrimitive(t, "string"); return "symbol" == typeof i ? i : i + ""; }
function _toPrimitive(t, r) { if ("object" != typeof t || !t) return t; var e = t[Symbol.toPrimitive]; if (void 0 !== e) { var i = e.call(t, r || "default"); if ("object" != typeof i) return i; throw new TypeError("@@toPrimitive must return a primitive value."); } return ("string" === r ? String : Number)(t); }








var __defProp = Object.defineProperty;
var __typeError = msg => {
  throw TypeError(msg);
};
var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, {
  enumerable: true,
  configurable: true,
  writable: true,
  value
}) : obj[key] = value;
var __publicField = (obj, key, value) => __defNormalProp(obj, typeof key !== "symbol" ? key + "" : key, value);
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _options, _oauthUrls, _emitter, _autoRenewService, _isSignedInWithAuthStateInProgress, _IdentityAuth_instances, isSignedInWithAuthState_fn;
class IdentityAuth {
  constructor(options) {
    __privateAdd(this, _IdentityAuth_instances);
    __privateAdd(this, _options);
    __privateAdd(this, _oauthUrls);
    __privateAdd(this, _emitter);
    __privateAdd(this, _autoRenewService);
    // holder if there is currently an is signed in check in progress
    __privateAdd(this, _isSignedInWithAuthStateInProgress);
    __publicField(this, "tokenManager");
    __publicField(this, "token");
    __publicField(this, "authStateManager");
    __privateSet(this, _options, _objectSpread({
      autoRenew: true,
      renewGracePeriod: 60,
      maxClockSkew: 300,
      idCookieSessionRefresh: false,
      oauthTimeout: 3e4,
      strictClockSkewCheck: false
    }, options));
    __privateSet(this, _oauthUrls, {
      authorizeUrl: "".concat(__privateGet(this, _options).issuer, "/v1/authorize"),
      tokenUrl: "".concat(__privateGet(this, _options).issuer, "/v1/token"),
      keysUrl: "".concat(__privateGet(this, _options).issuer, "/v1/keys")
    });
    (0,_cookieRefresh_js__WEBPACK_IMPORTED_MODULE_4__.cookieRefreshIfRequired)(__privateGet(this, _options).idCookieSessionRefresh, __privateGet(this, _options).issuer);
    __privateSet(this, _emitter, new _emitter_js__WEBPACK_IMPORTED_MODULE_5__.Emitter());
    this.token = new _token_js__WEBPACK_IMPORTED_MODULE_7__.Token(__privateGet(this, _options), __privateGet(this, _oauthUrls));
    this.tokenManager = new _tokenManager_js__WEBPACK_IMPORTED_MODULE_8__.TokenManager(__privateGet(this, _emitter), this.token);
    this.authStateManager = new _authState_js__WEBPACK_IMPORTED_MODULE_2__.AuthStateManager(__privateGet(this, _emitter), this.tokenManager);
    __privateSet(this, _autoRenewService, new _autoRenew_js__WEBPACK_IMPORTED_MODULE_3__.AutoRenewService(__privateGet(this, _options), __privateGet(this, _emitter), this.authStateManager));
    __privateSet(this, _isSignedInWithAuthStateInProgress, void 0);
    __privateGet(this, _autoRenewService).start();
  }
  /**
   * @name isSignedInWithAuthState
   * @description Checks if the user is signed in, and updates the auth state as necessary, returns the current auth state
   *
   * This performs side effects.
   *
   * This follows the flowchart from https://github.com/guardian/gateway/blob/main/docs/okta/web-apps-integration-guide.md#how-to-know-if-a-reader-is-signed-in to determine if the user is signed in
   *
   * 1. If the user tokens already exist, then verify them to make sure they are still valid
   * 2. If they do, check if the user has a `GU_SO` cookie and compare it to the `iat` value of the id token
   *   a. If the `GU_SO` cookie value is greater than the `iat` value, the user has recently signed out, so we should clear their tokens (side effect)
   *   b. Otherwise, the user is signed in, so return the auth state
   * 3. If the user doesn't have tokens, but they have a `GU_U` cookie, they are "maybe" signed in
   *  a. We can try to get tokens without prompting/redirecting the user for credentials (side effect)
   * 	b. If no tokens are returned, we clear the `GU_U` cookie, as it is likely invalid (side effect)
   *  c. If there is an error getting the tokens:
   *    i. If the error is an `OAuthError` and the error is `login_required`, the user is not signed in, so we clear the `GU_U` cookie, as it is likely invalid (side effect)
   *    ii. Otherwise, there is an unknown error, so clear any tokens and throw the error
   * 4. If the user doesn't have tokens or a GU_U cookie, they are not signed in
   *
   * For optimisation, this method will only run one signed in check at a time,
   * and will return the existing promise if a check is already in progress
   *
   * @returns `AuthState` - Returns the current authentication state
   */
  isSignedInWithAuthState() {
    var _this = this;
    return _asyncToGenerator(function* () {
      if (__privateGet(_this, _isSignedInWithAuthStateInProgress)) {
        return __privateGet(_this, _isSignedInWithAuthStateInProgress);
      }
      __privateSet(_this, _isSignedInWithAuthStateInProgress, __privateMethod(_this, _IdentityAuth_instances, isSignedInWithAuthState_fn).call(_this).finally(() => {
        __privateSet(_this, _isSignedInWithAuthStateInProgress, void 0);
      }));
      return __privateGet(_this, _isSignedInWithAuthStateInProgress);
    })();
  }
  /**
   * @name isSignedIn
   * @description Checks if the user is signed in, and updates the auth state as necessary, returns boolean
   *
   * This performs side effects.
   *
   * This follows the flowchart from https://github.com/guardian/gateway/blob/main/docs/okta/web-apps-integration-guide.md#how-to-know-if-a-reader-is-signed-in to determine if the user is signed in
   *
   * 1. If the user tokens already exist, then verify them to make sure they are still valid
   * 2. If they do, check if the user has a `GU_SO` cookie and compare it to the `iat` value of the id token
   *   a. If the `GU_SO` cookie value is greater than the `iat` value, the user has recently signed out, so we should clear their tokens (side effect)
   *   b. Otherwise, the user is signed in, so return the auth state
   * 3. If the user doesn't have tokens, but they have a `GU_U` cookie, they are "maybe" signed in
   *  a. We can try to get tokens without prompting/redirecting the user for credentials (side effect)
   * 	b. If no tokens are returned, we clear the `GU_U` cookie, as it is likely invalid (side effect)
   *  c. If there is an error getting the tokens:
   *    i. If the error is an `OAuthError` and the error is `login_required`, the user is not signed in, so we clear the `GU_U` cookie, as it is likely invalid (side effect)
   *    ii. Otherwise, there is an unknown error, so clear any tokens and throw the error
   * 4. If the user doesn't have tokens or a GU_U cookie, they are not signed in
   *
   * @returns `boolean` - `true` if the user is signed in, `false` if not
   */
  isSignedIn() {
    var _this2 = this;
    return _asyncToGenerator(function* () {
      return (yield _this2.isSignedInWithAuthState()).isAuthenticated;
    })();
  }
}
_options = new WeakMap();
_oauthUrls = new WeakMap();
_emitter = new WeakMap();
_autoRenewService = new WeakMap();
_isSignedInWithAuthStateInProgress = new WeakMap();
_IdentityAuth_instances = new WeakSet();
isSignedInWithAuthState_fn = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    try {
      var authState = this.authStateManager.getAuthState();
      if (authState.isAuthenticated) {
        var _getCookie;
        yield this.token.verifyTokens(authState.idToken, authState.accessToken);
        var guSoCookie = parseInt((_getCookie = (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
          name: "GU_SO",
          shouldMemoize: true
        })) !== null && _getCookie !== void 0 ? _getCookie : "");
        var normalisedCurrentTime = Math.floor(Date.now() / 1e3) - authState.idToken.clockSkew;
        if (
        // make sure that the GU_SO cookie is in the past
        guSoCookie <= normalisedCurrentTime &&
        // compare the GU_SO cookie to the id token's iat value
        guSoCookie > authState.idToken.claims.iat) {
          this.tokenManager.clear();
        } else {
          return authState;
        }
      }
      if ((0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.getCookie)({
        name: "GU_U",
        shouldMemoize: true
      })) {
        var tokens = yield this.tokenManager.getTokens({
          refreshIfRequired: true
        });
        if (tokens) {
          return {
            accessToken: tokens.accessToken,
            idToken: tokens.idToken,
            isAuthenticated: true
          };
        } else {
          (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.removeCookie)({
            name: "GU_U"
          });
        }
      }
      return {
        accessToken: void 0,
        idToken: void 0,
        isAuthenticated: false
      };
    } catch (error) {
      if (error instanceof _error_js__WEBPACK_IMPORTED_MODULE_6__.OAuthError && error.error === "login_required") {
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.removeCookie)({
          name: "GU_U"
        });
        return {
          accessToken: void 0,
          idToken: void 0,
          isAuthenticated: false
        };
      }
      this.tokenManager.clear();
      throw error;
    }
  });
  return function isSignedInWithAuthState_fn() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/token.js":
/*!*********************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/token.js ***!
  \*********************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Token: () => (/* binding */ Token),
/* harmony export */   addPostMessageListener: () => (/* binding */ addPostMessageListener),
/* harmony export */   exchangeCodeForTokens: () => (/* binding */ exchangeCodeForTokens),
/* harmony export */   handleOAuthResponse: () => (/* binding */ handleOAuthResponse),
/* harmony export */   isAccessToken: () => (/* binding */ isAccessToken),
/* harmony export */   isIDToken: () => (/* binding */ isIDToken),
/* harmony export */   loadFrame: () => (/* binding */ loadFrame),
/* harmony export */   performAuthCodeFlowIframe: () => (/* binding */ performAuthCodeFlowIframe),
/* harmony export */   verifyAccessTokenTimestamps: () => (/* binding */ verifyAccessTokenTimestamps),
/* harmony export */   verifyAccessTokenWithAtHash: () => (/* binding */ verifyAccessTokenWithAtHash),
/* harmony export */   verifyIdTokenClaims: () => (/* binding */ verifyIdTokenClaims),
/* harmony export */   verifySignature: () => (/* binding */ verifySignature),
/* harmony export */   verifyTokens: () => (/* binding */ verifyTokens)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isNonNullable/isNonNullable.js");
/* harmony import */ var _crypto_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./crypto.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/crypto.js");
/* harmony import */ var _error_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./error.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/error.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }



var __typeError = msg => {
  throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _options, _oauthUrls, _getTokensInProgress, _exchangeCodeForTokens, _handleOAuthResponse, _performAuthCodeFlowIframe, _Token_instances, getWithoutPrompt_fn;
var isAccessTokenClaims = claims => {
  var maybeClaims = claims;
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isNonNullable)(maybeClaims) && maybeClaims.aud !== void 0 && maybeClaims.auth_time !== void 0 && maybeClaims.cid !== void 0 && maybeClaims.email_validated !== void 0 && maybeClaims.exp !== void 0 && maybeClaims.iat !== void 0 && maybeClaims.identity_username !== void 0 && maybeClaims.iss !== void 0 && maybeClaims.jti !== void 0 && maybeClaims.legacy_identity_id !== void 0 && maybeClaims.scp !== void 0 && maybeClaims.sub !== void 0 && maybeClaims.uid !== void 0 && maybeClaims.ver !== void 0;
};
var isAccessToken = token => {
  var maybeToken = token;
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isNonNullable)(maybeToken) && maybeToken.accessToken !== void 0 && maybeToken.expiresAt !== void 0 && maybeToken.scopes !== void 0 && maybeToken.tokenType !== void 0 && isAccessTokenClaims(maybeToken.claims);
};
var isIDTokenClaims = claims => {
  var maybeClaims = claims;
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isNonNullable)(maybeClaims) && maybeClaims.amr !== void 0 && maybeClaims.at_hash !== void 0 && maybeClaims.aud !== void 0 && maybeClaims.auth_time !== void 0 && maybeClaims.exp !== void 0 && maybeClaims.iat !== void 0 && maybeClaims.identity_username !== void 0 && maybeClaims.idp !== void 0 && maybeClaims.iss !== void 0 && maybeClaims.jti !== void 0 && maybeClaims.legacy_identity_id !== void 0 && maybeClaims.name !== void 0 && maybeClaims.nonce !== void 0 && maybeClaims.preferred_username !== void 0 && maybeClaims.sub !== void 0 && maybeClaims.user_groups !== void 0 && maybeClaims.ver !== void 0;
};
var isIDToken = token => {
  var maybeToken = token;
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isNonNullable)(maybeToken) && maybeToken.expiresAt !== void 0 && maybeToken.idToken !== void 0 && maybeToken.scopes !== void 0 && isIDTokenClaims(maybeToken.claims);
};
var isOAuthAuthorizeResponseError = response => {
  var maybeResponse = response;
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isNonNullable)(maybeResponse) && maybeResponse.error !== void 0 && maybeResponse.error_description !== void 0 && maybeResponse.state !== void 0;
};
var isOAuthTokenResponseError = response => {
  var maybeResponse = response;
  return (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.isNonNullable)(maybeResponse) && maybeResponse.error !== void 0 && maybeResponse.error_description !== void 0;
};
var calculateClockSkew = (now, token) => {
  var {
    iat
  } = decodeToken(token).payload;
  if (!iat) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "iat claim is missing from token"
    });
  }
  return now - iat;
};
var decodeToken = token => {
  var [headerStr, payloadStr, signature] = token.split(".");
  try {
    if (headerStr === void 0 || payloadStr === void 0 || signature === void 0) {
      throw "Missing token parts";
    }
    var header = JSON.parse((0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.base64UrlToString)(headerStr));
    var payload = JSON.parse((0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.base64UrlToString)(payloadStr));
    if (!header.alg || !header.kid) {
      throw "Missing algorithm in header";
    }
    if (!payload.jti) {
      throw "Possibly malformed payload";
    }
    return {
      header,
      payload,
      signature
    };
  } catch (error) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Malformed token",
      message: error
    });
  }
};
var decodeTokens = _ref => {
  var {
    accessTokenRaw,
    accessTokenClockSkew,
    idTokenRaw,
    idTokenClockSkew,
    nonce,
    options
  } = _ref;
  var now = Math.floor(Date.now() / 1e3);
  var decodedAccessToken = decodeToken(accessTokenRaw);
  var accessTokenPayload = decodedAccessToken.payload;
  if (!isAccessTokenClaims(accessTokenPayload)) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid access token claims",
      message: "Invalid access token claims"
    });
  }
  if (options.strictClockSkewCheck && Math.abs(accessTokenClockSkew) > options.maxClockSkew) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid Access token",
      message: "Clock skew too large"
    });
  }
  var accessToken = {
    accessToken: accessTokenRaw,
    claims: accessTokenPayload,
    expiresAt: accessTokenPayload.exp - accessTokenPayload.iat + now,
    // adjusting expiresAt to be in local (machine) time, to account for clock skew
    clockSkew: accessTokenClockSkew,
    tokenType: "Bearer",
    scopes: accessTokenPayload.scp
  };
  if (!isAccessToken(accessToken)) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid access token",
      message: "Invalid access token"
    });
  }
  var decodedIDToken = decodeToken(idTokenRaw);
  var idTokenPayload = decodedIDToken.payload;
  if (!isIDTokenClaims(idTokenPayload)) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid ID token claims",
      message: "Invalid ID token claims"
    });
  }
  if (options.strictClockSkewCheck && Math.abs(idTokenClockSkew) > options.maxClockSkew) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid ID token",
      message: "Clock skew too large"
    });
  }
  var idToken = {
    idToken: idTokenRaw,
    issuer: options.issuer,
    clientId: options.clientId,
    claims: idTokenPayload,
    expiresAt: idTokenPayload.exp - idTokenPayload.iat + now,
    // adjusting expiresAt to be in local (machine) time, to account for clock skew
    clockSkew: idTokenClockSkew,
    scopes: options.scopes,
    nonce
  };
  if (!isIDToken(idToken)) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid ID token",
      message: "Invalid ID token"
    });
  }
  return {
    accessToken,
    idToken
  };
};
var verifyIdTokenClaims = (decoded, claims, options) => {
  var localTime = Math.floor(Date.now() / 1e3);
  var normalisedTime = localTime - decoded.clockSkew;
  if (claims.nonce !== decoded.nonce) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid nonce in ID token",
      message: "Invalid nonce in ID token"
    });
  }
  if (claims.iss !== options.issuer) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid issuer in ID token",
      message: "Invalid issuer in ID token"
    });
  }
  if (claims.aud !== options.clientId) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Invalid audience in ID token",
      message: "Invalid audience in ID token"
    });
  }
  if (!claims.iat) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Missing iat claim in ID token",
      message: "Token does not contain required claims"
    });
  }
  if (claims.iat > normalisedTime) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Token was issued in the future",
      message: "Token was issued in the future"
    });
  }
};
var verifyAccessTokenWithAtHash = /*#__PURE__*/function () {
  var _ref2 = _asyncToGenerator(function* (at_hash, access_token) {
    var accessTokenHash = yield (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.generateSha256Hash)(access_token);
    var accessTokenHash128 = accessTokenHash.substring(0, 16);
    var accessTokenHashBase64 = (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.base64UrlEncode)(accessTokenHash128);
    if (accessTokenHashBase64 !== at_hash) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "invalid_token",
        error_description: "Invalid token",
        message: "The access token hash does not match the at_hash claim"
      });
    }
    return;
  });
  return function verifyAccessTokenWithAtHash(_x, _x2) {
    return _ref2.apply(this, arguments);
  };
}();
var verifySignature = /*#__PURE__*/function () {
  var _ref3 = _asyncToGenerator(function* (jwksUri, jwt, token) {
    var jwksResponse = yield fetch(jwksUri);
    if (!jwksResponse.ok) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "failed_request",
        error_description: "Failed to fetch JWKS",
        message: "Failed to fetch JWKS"
      });
    }
    var jwks = yield jwksResponse.json();
    if (!jwks.keys || jwks.keys.length === 0) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "invalid_jwks",
        error_description: "No keys found in JWKS",
        message: "No keys found in JWKS"
      });
    }
    for (var key2 of jwks.keys) {
      if (!key2.kty || !key2.n || !key2.e || !key2.alg || !key2.use || !key2.kid) {
        throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
          error: "invalid_jwks",
          error_description: "Invalid key in JWKS",
          message: "Invalid key in JWKS"
        });
      }
    }
    var key = jwks.keys.find(k => k.kid === jwt.header.kid);
    if (key === void 0) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "invalid_jwks",
        error_description: "No key found for token in JWKS",
        message: "No key found for token in JWKS"
      });
    }
    var algorithm = {
      name: "RSASSA-PKCS1-v1_5",
      hash: {
        name: "SHA-256"
      }
    };
    var publicKey = yield window.crypto.subtle.importKey("jwk", {
      kty: key.kty,
      n: key.n,
      e: key.e,
      alg: key.alg,
      use: key.use
    }, algorithm, true, ["verify"]);
    var [header, payload, sig] = token.split(".");
    if (header === void 0 || payload === void 0 || sig === void 0) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "invalid_token",
        error_description: "Malformed token",
        message: "Malformed token"
      });
    }
    var data = "".concat(header, ".").concat(payload);
    var isValid = yield window.crypto.subtle.verify(algorithm, publicKey, (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.stringToBuffer)((0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.base64UrlToString)(sig)), (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.stringToBuffer)(data));
    if (!isValid) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "invalid_token",
        error_description: "Invalid signature",
        message: "Invalid signature"
      });
    }
  });
  return function verifySignature(_x3, _x4, _x5) {
    return _ref3.apply(this, arguments);
  };
}();
var verifyAccessTokenTimestamps = (decoded, claims) => {
  var localTime = Math.floor(Date.now() / 1e3);
  var normalisedTime = localTime - decoded.clockSkew;
  if (!claims.iat || !claims.exp) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Missing iat or exp claim in access token",
      message: "Token does not contain required claims"
    });
  }
  if (claims.iat > claims.exp) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "iat claim is after exp claim in access token",
      message: "Token has expired before it was issued"
    });
  }
  if (normalisedTime > claims.exp) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Token has expired",
      message: "Token has expired"
    });
  }
  if (claims.iat > normalisedTime) {
    throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
      error: "invalid_token",
      error_description: "Token was issued in the future",
      message: "Token was issued in the future"
    });
  }
};
var addPostMessageListener = (opts, state) => {
  var responseHandler;
  var timeoutId;
  var msgReceivedOrTimeout = new Promise((resolve, reject) => {
    responseHandler = e => {
      if (e.data.state !== state) {
        return;
      }
      if (e.origin !== opts.issuer.split("/oauth2/")[0]) {
        return reject(new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
          error: "invalid_origin",
          error_description: "Invalid origin",
          message: "The request does not originate from the issuer"
        }));
      }
      return resolve(e.data);
    };
    window.addEventListener("message", responseHandler);
    timeoutId = window.setTimeout(() => {
      return reject(new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "timeout",
        error_description: "Timeout",
        message: "The oauth request timed out"
      }));
    }, opts.oauthTimeout);
  });
  return msgReceivedOrTimeout.finally(() => {
    window.clearTimeout(timeoutId);
    window.removeEventListener("message", responseHandler);
  });
};
var loadFrame = url => {
  var frame = document.createElement("iframe");
  frame.style.display = "none";
  frame.src = url;
  return document.body.appendChild(frame);
};
var performAuthCodeFlowIframe = /*#__PURE__*/function () {
  var _ref4 = _asyncToGenerator(function* (authorizeParams, options, oauthUrls) {
    var searchParams = new URLSearchParams(authorizeParams);
    var postMessageListener = addPostMessageListener(options, authorizeParams.state);
    var iframe = loadFrame("".concat(oauthUrls.authorizeUrl, "?").concat(searchParams.toString()));
    var authorizeResponse = yield postMessageListener.finally(() => {
      if (document.body.contains(iframe)) {
        document.body.removeChild(iframe);
      }
    });
    return authorizeResponse;
  });
  return function performAuthCodeFlowIframe(_x6, _x7, _x8) {
    return _ref4.apply(this, arguments);
  };
}();
var memoizedVerifyTokens = /* @__PURE__ */new Map();
var verifyTokens = /*#__PURE__*/function () {
  var _ref5 = _asyncToGenerator(function* (idToken, accessToken, options, oauthUrls) {
    if (memoizedVerifyTokens.has(idToken.claims.jti)) {
      var memoized = memoizedVerifyTokens.get(idToken.claims.jti);
      if (memoized === true) {
        return;
      }
      throw memoized;
    }
    try {
      var idTokenJWT = decodeToken(idToken.idToken);
      verifyIdTokenClaims(idToken, idTokenJWT.payload, options);
      yield verifySignature(oauthUrls.keysUrl, idTokenJWT, idToken.idToken);
      yield verifyAccessTokenWithAtHash(idToken.claims.at_hash, accessToken.accessToken);
      var accessTokenJWT = decodeToken(accessToken.accessToken);
      verifyAccessTokenTimestamps(accessToken, accessTokenJWT.payload);
      memoizedVerifyTokens.set(idToken.claims.jti, true);
    } catch (error) {
      memoizedVerifyTokens.set(idToken.claims.jti, error);
      throw error;
    }
  });
  return function verifyTokens(_x9, _x0, _x1, _x10) {
    return _ref5.apply(this, arguments);
  };
}();
var exchangeCodeForTokens = /*#__PURE__*/function () {
  var _ref6 = _asyncToGenerator(function* (code, codeVerifier, options, oauthUrls) {
    var tokenParams = {
      client_id: options.clientId,
      code,
      code_verifier: codeVerifier,
      grant_type: "authorization_code",
      redirect_uri: options.redirectUri
    };
    var response = yield fetch(oauthUrls.tokenUrl, {
      method: "POST",
      body: new URLSearchParams(tokenParams),
      headers: {
        "Content-Type": "application/x-www-form-urlencoded"
      }
    });
    return response.json();
  });
  return function exchangeCodeForTokens(_x11, _x12, _x13, _x14) {
    return _ref6.apply(this, arguments);
  };
}();
var handleOAuthResponse = /*#__PURE__*/function () {
  var _ref7 = _asyncToGenerator(function* (oauthTokenResponse, authorizeParams, options, oauthUrls) {
    var {
      access_token,
      id_token
    } = oauthTokenResponse;
    var now = Math.floor(Date.now() / 1e3);
    var accessTokenClockSkew = calculateClockSkew(now, access_token);
    var idTokenClockSkew = calculateClockSkew(now, id_token);
    var {
      accessToken,
      idToken
    } = decodeTokens({
      accessTokenRaw: access_token,
      accessTokenClockSkew,
      idTokenRaw: id_token,
      idTokenClockSkew,
      nonce: authorizeParams.nonce,
      options
    });
    yield verifyTokens(idToken, accessToken, options, oauthUrls);
    return {
      state: authorizeParams.state,
      tokens: {
        accessToken,
        idToken
      }
    };
  });
  return function handleOAuthResponse(_x15, _x16, _x17, _x18) {
    return _ref7.apply(this, arguments);
  };
}();
class Token {
  constructor(options, oauthUrls) {
    __privateAdd(this, _Token_instances);
    __privateAdd(this, _options);
    __privateAdd(this, _oauthUrls);
    // holder if there is currently a get token flow in progress
    __privateAdd(this, _getTokensInProgress);
    __privateAdd(this, _exchangeCodeForTokens, (code, codeVerifier) => exchangeCodeForTokens(code, codeVerifier, __privateGet(this, _options), __privateGet(this, _oauthUrls)));
    __privateAdd(this, _handleOAuthResponse, (oauthTokenResponse, authorizeParams) => handleOAuthResponse(oauthTokenResponse, authorizeParams, __privateGet(this, _options), __privateGet(this, _oauthUrls)));
    __privateAdd(this, _performAuthCodeFlowIframe, authorizeParams => performAuthCodeFlowIframe(authorizeParams, __privateGet(this, _options), __privateGet(this, _oauthUrls)));
    __privateSet(this, _options, options);
    __privateSet(this, _oauthUrls, oauthUrls);
    __privateSet(this, _getTokensInProgress, void 0);
  }
  /**
   * @name getWithoutPrompt
   * @description Performs the Authorization Code Flow with PKCE, exchanging the authorization code for tokens and verifying the ID token, without prompting the user and using a hidden iframe
   * @returns Promise<TokenResponse> - resolves with the access and ID tokens
   */
  getWithoutPrompt() {
    var _this = this;
    return _asyncToGenerator(function* () {
      if (__privateGet(_this, _getTokensInProgress)) {
        return __privateGet(_this, _getTokensInProgress);
      }
      __privateSet(_this, _getTokensInProgress, __privateMethod(_this, _Token_instances, getWithoutPrompt_fn).call(_this).finally(() => {
        __privateSet(_this, _getTokensInProgress, void 0);
      }));
      return __privateGet(_this, _getTokensInProgress);
    })();
  }
  /**
   * @name verifyTokens
   * @description Verifies the ID token, checking the signature and claims, and verifies the access token using the at_hash claim
   *
   * @param idToken - ID token to verify
   * @param accessToken - Access token to verify
   * @returns void
   */
  verifyTokens(idToken, accessToken) {
    var _this2 = this;
    return _asyncToGenerator(function* () {
      return verifyTokens(idToken, accessToken, __privateGet(_this2, _options), __privateGet(_this2, _oauthUrls));
    })();
  }
  /**
   * @name decodeTokens
   * @description Decodes the access and ID tokens, returning the decoded claims, without verifying the tokens
   *
   * @param accessToken - Raw access token string to decode
   * @param idToken - Raw ID token string to decode
   * @param nonce - Nonce used when generating the tokens
   *
   * @returns Tokens - decoded access and ID tokens
   */
  decodeTokens(_ref8) {
    var {
      accessTokenRaw,
      accessTokenClockSkew,
      idTokenRaw,
      idTokenClockSkew,
      nonce
    } = _ref8;
    return decodeTokens({
      accessTokenRaw,
      accessTokenClockSkew,
      idTokenRaw,
      idTokenClockSkew,
      nonce,
      options: __privateGet(this, _options)
    });
  }
}
_options = new WeakMap();
_oauthUrls = new WeakMap();
_getTokensInProgress = new WeakMap();
_exchangeCodeForTokens = new WeakMap();
_handleOAuthResponse = new WeakMap();
_performAuthCodeFlowIframe = new WeakMap();
_Token_instances = new WeakSet();
getWithoutPrompt_fn = /*#__PURE__*/function () {
  var _ref9 = _asyncToGenerator(function* () {
    var codeVerifier = (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.generateCodeVerifier)();
    var codeChallenge = yield (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.generateCodeChallenge)(codeVerifier);
    var authorizeParams = {
      client_id: __privateGet(this, _options).clientId,
      code_challenge: codeChallenge,
      code_challenge_method: "S256",
      prompt: "none",
      nonce: (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.getRandomString)(16),
      redirect_uri: __privateGet(this, _options).redirectUri,
      response_type: "code",
      response_mode: "okta_post_message",
      scope: __privateGet(this, _options).scopes.join(" "),
      state: (0,_crypto_js__WEBPACK_IMPORTED_MODULE_1__.getRandomString)(42)
    };
    var authorizeResponse = yield __privateGet(this, _performAuthCodeFlowIframe).call(this, authorizeParams);
    if (isOAuthAuthorizeResponseError(authorizeResponse)) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: authorizeResponse.error,
        error_description: authorizeResponse.error_description,
        message: "OAuth Authorize Error | ".concat(authorizeResponse.error, " | ").concat(authorizeResponse.error_description)
      });
    }
    var {
      code,
      state
    } = authorizeResponse;
    if (state !== authorizeParams.state) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: "invalid_state",
        error_description: "Invalid state parameter",
        message: "Invalid state parameter"
      });
    }
    var tokenResponse = yield __privateGet(this, _exchangeCodeForTokens).call(this, code, codeVerifier);
    if (isOAuthTokenResponseError(tokenResponse)) {
      throw new _error_js__WEBPACK_IMPORTED_MODULE_2__.OAuthError({
        error: tokenResponse.error,
        error_description: tokenResponse.error_description,
        message: "OAuth Token Error | ".concat(tokenResponse.error, " | ").concat(tokenResponse.error_description)
      });
    }
    var parsed = yield __privateGet(this, _handleOAuthResponse).call(this, tokenResponse, authorizeParams);
    return parsed;
  });
  return function getWithoutPrompt_fn() {
    return _ref9.apply(this, arguments);
  };
}();


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/tokenManager.js":
/*!****************************************************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/tokenManager.js ***!
  \****************************************************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   TokenManager: () => (/* binding */ TokenManager)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/storage/storage.js");
/* harmony import */ var _token_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./token.js */ "../node_modules/.pnpm/@guardian+identity-auth@10.0.0_@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2_ta7t2fxtddlskixnv6brnrn54a/node_modules/@guardian/identity-auth/dist/token.js");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }


var __typeError = msg => {
  throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
var __privateSet = (obj, member, value, setter) => (__accessCheck(obj, member, "write to private field"), member.set(obj, value), value);
var __privateMethod = (obj, member, method) => (__accessCheck(obj, member, "access private method"), method);
var _token, _emitter, _storage, _accessTokenKey, _idTokenKey, _TokenManager_instances, emitAdded_fn, emitRemoved_fn, emitStorage_fn;
class TokenManager {
  constructor(emitter, tokenClass) {
    var _this = this;
    __privateAdd(this, _TokenManager_instances);
    __privateAdd(this, _token);
    __privateAdd(this, _emitter);
    __privateAdd(this, _storage, _guardian_libs__WEBPACK_IMPORTED_MODULE_0__.storage.local);
    __privateAdd(this, _accessTokenKey, "gu.access_token");
    __privateAdd(this, _idTokenKey, "gu.id_token");
    __privateSet(this, _emitter, emitter);
    __privateSet(this, _token, tokenClass);
    window.addEventListener("storage", event => {
      if (event.key === __privateGet(this, _accessTokenKey) || event.key === __privateGet(this, _idTokenKey)) {
        __privateMethod(this, _TokenManager_instances, emitStorage_fn).call(this);
      }
    });
    __privateGet(this, _emitter).on("renew", /*#__PURE__*/_asyncToGenerator(function* () {
      yield _this.renew();
    }));
  }
  /**
   * @name setTokens
   * @description Sets the tokens in storage and emits an event
   * @param tokens - The tokens to set
   * @returns void
   */
  setTokens(tokens) {
    var tokenTypes = ["accessToken", "idToken"];
    var existingTokens = this.getTokensSync();
    var accessTokenStorage = {
      accessToken: tokens.accessToken.accessToken,
      clockSkew: tokens.accessToken.clockSkew
    };
    var idTokenStorage = {
      idToken: tokens.idToken.idToken,
      nonce: tokens.idToken.nonce,
      clockSkew: tokens.idToken.clockSkew
    };
    __privateGet(this, _storage).set(__privateGet(this, _accessTokenKey), accessTokenStorage, new Date(tokens.accessToken.expiresAt * 1e3));
    __privateGet(this, _storage).set(__privateGet(this, _idTokenKey), idTokenStorage,
    // use access token expiry as id token expiry as id token is always 1 hour
    // while the access token can be between 5 mins and 24 hours
    // the id token is refreshed at the same time as the access token, and is tied to
    // a given access token using the at_hash claim, so it is safe to use the access token expiry
    new Date(tokens.accessToken.expiresAt * 1e3));
    tokenTypes.forEach(tokenType => {
      var newToken = tokens[tokenType];
      var existingToken = existingTokens === null || existingTokens === void 0 ? void 0 : existingTokens[tokenType];
      if (existingToken) {
        __privateMethod(this, _TokenManager_instances, emitRemoved_fn).call(this, tokenType, existingToken);
        __privateMethod(this, _TokenManager_instances, emitAdded_fn).call(this, tokenType, newToken);
      } else {
        __privateMethod(this, _TokenManager_instances, emitAdded_fn).call(this, tokenType, newToken);
      }
    });
  }
  /**
   * @name getTokensSync
   * @description Gets the tokens from storage synchronously, does not refresh tokens or verify them
   *
   * @returns Tokens | undefined - The tokens if they exist
   */
  getTokensSync() {
    var accessTokenFromStorage = __privateGet(this, _storage).get(__privateGet(this, _accessTokenKey));
    var idTokenFromStorage = __privateGet(this, _storage).get(__privateGet(this, _idTokenKey));
    if (!(accessTokenFromStorage !== null && accessTokenFromStorage !== void 0 && accessTokenFromStorage.accessToken) || !(idTokenFromStorage !== null && idTokenFromStorage !== void 0 && idTokenFromStorage.idToken) || !idTokenFromStorage.nonce) {
      return void 0;
    }
    var {
      accessToken,
      idToken
    } = __privateGet(this, _token).decodeTokens({
      accessTokenRaw: accessTokenFromStorage.accessToken,
      accessTokenClockSkew: accessTokenFromStorage.clockSkew,
      idTokenRaw: idTokenFromStorage.idToken,
      idTokenClockSkew: idTokenFromStorage.clockSkew,
      nonce: idTokenFromStorage.nonce
    });
    if (!(0,_token_js__WEBPACK_IMPORTED_MODULE_1__.isAccessToken)(accessToken) || !(0,_token_js__WEBPACK_IMPORTED_MODULE_1__.isIDToken)(idToken)) {
      return void 0;
    }
    return {
      accessToken,
      idToken
    };
  }
  /**
   * @name getTokens
   * @description Gets the tokens from storage asynchronously, can refresh tokens if required and verify them
   *
   * @param verifyTokens - If true, will verify the tokens before returning (default: true)
   * @param refreshIfRequired - If true, will refresh the tokens if they are expired (default: false)
   * @returns Promise<Tokens | undefined> - The tokens if they exist
   */
  getTokens() {
    var _arguments = arguments,
      _this2 = this;
    return _asyncToGenerator(function* () {
      var {
        refreshIfRequired = false,
        verifyTokens = true
      } = _arguments.length > 0 && _arguments[0] !== undefined ? _arguments[0] : {};
      try {
        var tokens = _this2.getTokensSync();
        if (tokens) {
          if (verifyTokens) {
            yield __privateGet(_this2, _token).verifyTokens(tokens.idToken, tokens.accessToken);
            return tokens;
          }
          return tokens;
        }
        if (refreshIfRequired) {
          var tokenResponse = yield __privateGet(_this2, _token).getWithoutPrompt();
          _this2.setTokens(tokenResponse.tokens);
          return tokenResponse.tokens;
        }
        return void 0;
      } catch (error) {
        _this2.clear();
        throw error;
      }
    })();
  }
  /**
   * @name clear
   * @description Clears the tokens from storage and emits an event
   * @returns void
   */
  clear() {
    __privateGet(this, _storage).remove(__privateGet(this, _accessTokenKey));
    __privateGet(this, _storage).remove(__privateGet(this, _idTokenKey));
    __privateMethod(this, _TokenManager_instances, emitRemoved_fn).call(this, "accessToken");
    __privateMethod(this, _TokenManager_instances, emitRemoved_fn).call(this, "idToken");
  }
  /**
   * @name renew
   * @description Attempts to renew the tokens, regardless of whether they are expired or not
   * @returns Promise<Tokens | undefined> - The tokens if they exist
   */
  renew() {
    var _this3 = this;
    return _asyncToGenerator(function* () {
      var tokenResponse = yield __privateGet(_this3, _token).getWithoutPrompt();
      _this3.setTokens(tokenResponse.tokens);
      return tokenResponse.tokens;
    })();
  }
}
_token = new WeakMap();
_emitter = new WeakMap();
_storage = new WeakMap();
_accessTokenKey = new WeakMap();
_idTokenKey = new WeakMap();
_TokenManager_instances = new WeakSet();
/**
 * @name emitAdded
 * @description Emits an event when a token is added
 */
emitAdded_fn = function (key, token) {
  __privateGet(this, _emitter).emit("added", key, token);
};
/**
 * @name emitRemoved
 * @description Emits an event when a token is removed
 */
emitRemoved_fn = function (key, token) {
  __privateGet(this, _emitter).emit("removed", key, token);
};
/**
 * @name emitStorage
 * @description Emits an event when the local storage is updated
 */
emitStorage_fn = function () {
  __privateGet(this, _emitter).emit("storage");
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setCookie.js":
/*!***********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/setCookie.js ***!
  \***********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   setCookie: () => (/* binding */ setCookie)
/* harmony export */ });
/* harmony import */ var _ERR_INVALID_COOKIE_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./ERR_INVALID_COOKIE.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/ERR_INVALID_COOKIE.js");
/* harmony import */ var _getCookieValues_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./getCookieValues.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getCookieValues.js");
/* harmony import */ var _getDomainAttribute_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./getDomainAttribute.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/getDomainAttribute.js");
/* harmony import */ var _isValidCookie_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./isValidCookie.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/isValidCookie.js");
/* harmony import */ var _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./memoizedCookies.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/cookies/memoizedCookies.js");





var setCookie = _ref => {
  var {
    name,
    value,
    daysToLive,
    isCrossSubdomain = false
  } = _ref;
  var expires = /* @__PURE__ */new Date();
  if (!(0,_isValidCookie_js__WEBPACK_IMPORTED_MODULE_3__.isValidCookie)(name, value)) {
    throw new Error("".concat(_ERR_INVALID_COOKIE_js__WEBPACK_IMPORTED_MODULE_0__.ERR_INVALID_COOKIE, " ").concat(name, "=").concat(value));
  }
  if (daysToLive) {
    expires.setUTCDate(expires.getUTCDate() + daysToLive);
  } else {
    expires.setUTCMonth(expires.getUTCMonth() + 5);
    expires.setUTCDate(1);
  }
  document.cookie = "".concat(name, "=").concat(value, "; path=/; expires=").concat(expires.toUTCString(), ";").concat((0,_getDomainAttribute_js__WEBPACK_IMPORTED_MODULE_2__.getDomainAttribute)({
    isCrossSubdomain
  }));
  if (_memoizedCookies_js__WEBPACK_IMPORTED_MODULE_4__.memoizedCookies.has(name)) {
    var [value2] = (0,_getCookieValues_js__WEBPACK_IMPORTED_MODULE_1__.getCookieValues)(name);
    if (value2) {
      _memoizedCookies_js__WEBPACK_IMPORTED_MODULE_4__.memoizedCookies.set(name, value2);
    }
  }
};


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isNonNullable/isNonNullable.js":
/*!*********************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isNonNullable/isNonNullable.js ***!
  \*********************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isNonNullable: () => (/* binding */ isNonNullable)
/* harmony export */ });
var isNonNullable = _ => _ !== void 0 && _ !== null;


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isOneOf/isOneOf.js":
/*!*********************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isOneOf/isOneOf.js ***!
  \*********************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   isOneOf: () => (/* binding */ isOneOf)
/* harmony export */ });
var isOneOf = literals => value => literals.includes(value);


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/performance/getMeasures.js":
/*!*****************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/performance/getMeasures.js ***!
  \*****************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getMeasures: () => (/* binding */ getMeasures)
/* harmony export */ });
/* harmony import */ var _serialise_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./serialise.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/performance/serialise.js");

var getMeasures = subscriptions =>
// https://developer.mozilla.org/en-US/docs/Web/API/Performance/getEntriesByType#browser_compatibility
"getEntriesByType" in window.performance ? window.performance.getEntriesByType("measure").flatMap(_ref => {
  var {
    entryType,
    name,
    duration,
    startTime
  } = _ref;
  var detail = (0,_serialise_js__WEBPACK_IMPORTED_MODULE_0__.deserialise)(name);
  return entryType === "measure" && detail && subscriptions.includes(detail.subscription) ? {
    name,
    detail,
    duration,
    entryType,
    startTime,
    toJson: () => JSON.stringify(void 0)
  } : [];
}) : [];


/***/ }),

/***/ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/performance/serialise.js":
/*!***************************************************************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/performance/serialise.js ***!
  \***************************************************************************************************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   deserialise: () => (/* binding */ deserialise),
/* harmony export */   serialise: () => (/* binding */ serialise)
/* harmony export */ });
/* harmony import */ var _isNonNullable_isNonNullable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../isNonNullable/isNonNullable.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isNonNullable/isNonNullable.js");
/* harmony import */ var _isString_isString_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../isString/isString.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/isString/isString.js");
/* harmony import */ var _logger_subscriptions_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../logger/subscriptions.js */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/subscriptions.js");



var SEPARATOR = ":";
var serialise = _ref => {
  var {
    subscription,
    name,
    action
  } = _ref;
  return [subscription, name, action].filter(_isNonNullable_isNonNullable_js__WEBPACK_IMPORTED_MODULE_0__.isNonNullable).join(SEPARATOR);
};
var deserialise = id => {
  var [subscription, name, action] = id.split(SEPARATOR);
  return (0,_isString_isString_js__WEBPACK_IMPORTED_MODULE_1__.isString)(subscription) && (0,_logger_subscriptions_js__WEBPACK_IMPORTED_MODULE_2__.isSubscription)(subscription) && (0,_isString_isString_js__WEBPACK_IMPORTED_MODULE_1__.isString)(name) ? {
    subscription,
    name,
    action
  } : void 0;
};


/***/ }),

/***/ "../node_modules/.pnpm/dlv@1.1.3/node_modules/dlv/index.js":
/*!*****************************************************************!*\
  !*** ../node_modules/.pnpm/dlv@1.1.3/node_modules/dlv/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (/* binding */ dlv)
/* harmony export */ });
function dlv(obj, key, def, p, undef) {
  key = key.split ? key.split('.') : key;
  for (p = 0; p < key.length; p++) {
    obj = obj ? obj[key[p]] : undef;
  }
  return obj === undef ? def : obj;
}

/***/ }),

/***/ "../node_modules/.pnpm/dset@3.1.4/node_modules/dset/dist/index.mjs":
/*!*************************************************************************!*\
  !*** ../node_modules/.pnpm/dset@3.1.4/node_modules/dset/dist/index.mjs ***!
  \*************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   dset: () => (/* binding */ dset)
/* harmony export */ });
function dset(obj, keys, val) {
  keys.split && (keys = keys.split('.'));
  var i = 0,
    l = keys.length,
    t = obj,
    x,
    k;
  while (i < l) {
    k = '' + keys[i++];
    if (k === '__proto__' || k === 'constructor' || k === 'prototype') break;
    t = t[k] = i === l ? val : typeof (x = t[k]) === typeof keys ? x : keys[i] * 0 !== 0 || !!~('' + keys[i]).indexOf('.') ? {} : [];
  }
}

/***/ }),

/***/ "../node_modules/.pnpm/klona@2.0.6/node_modules/klona/json/index.mjs":
/*!***************************************************************************!*\
  !*** ../node_modules/.pnpm/klona@2.0.6/node_modules/klona/json/index.mjs ***!
  \***************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   klona: () => (/* binding */ klona)
/* harmony export */ });
function klona(val) {
  var k, out, tmp;
  if (Array.isArray(val)) {
    out = Array(k = val.length);
    while (k--) out[k] = (tmp = val[k]) && typeof tmp === 'object' ? klona(tmp) : tmp;
    return out;
  }
  if (Object.prototype.toString.call(val) === '[object Object]') {
    out = {}; // null
    for (k in val) {
      if (k === '__proto__') {
        Object.defineProperty(out, k, {
          value: klona(val[k]),
          configurable: true,
          enumerable: true,
          writable: true
        });
      } else {
        out[k] = (tmp = val[k]) && typeof tmp === 'object' ? klona(tmp) : tmp;
      }
    }
    return out;
  }
  return val;
}

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_arrayPush.js":
/*!************************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_arrayPush.js ***!
  \************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * Appends the elements of `values` to `array`.
 *
 * @private
 * @param {Array} array The array to modify.
 * @param {Array} values The values to append.
 * @returns {Array} Returns `array`.
 */
function arrayPush(array, values) {
  var index = -1,
    length = values.length,
    offset = array.length;
  while (++index < length) {
    array[offset + index] = values[index];
  }
  return array;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (arrayPush);

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseFlatten.js":
/*!**************************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseFlatten.js ***!
  \**************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _arrayPush_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_arrayPush.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_arrayPush.js");
/* harmony import */ var _isFlattenable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./_isFlattenable.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_isFlattenable.js");


/**
 * The base implementation of `_.flatten` with support for restricting flattening.
 *
 * @private
 * @param {Array} array The array to flatten.
 * @param {number} depth The maximum recursion depth.
 * @param {boolean} [predicate=isFlattenable] The function invoked per iteration.
 * @param {boolean} [isStrict] Restrict to values that pass `predicate` checks.
 * @param {Array} [result=[]] The initial result value.
 * @returns {Array} Returns the new flattened array.
 */
function baseFlatten(array, depth, predicate, isStrict, result) {
  var index = -1,
    length = array.length;
  predicate || (predicate = _isFlattenable_js__WEBPACK_IMPORTED_MODULE_1__["default"]);
  result || (result = []);
  while (++index < length) {
    var value = array[index];
    if (depth > 0 && predicate(value)) {
      if (depth > 1) {
        // Recursively flatten arrays (susceptible to call stack limits).
        baseFlatten(value, depth - 1, predicate, isStrict, result);
      } else {
        (0,_arrayPush_js__WEBPACK_IMPORTED_MODULE_0__["default"])(result, value);
      }
    } else if (!isStrict) {
      result[result.length] = value;
    }
  }
  return result;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseFlatten);

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseIsArguments.js":
/*!******************************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseIsArguments.js ***!
  \******************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseGetTag_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseGetTag.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseGetTag.js");
/* harmony import */ var _isObjectLike_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./isObjectLike.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isObjectLike.js");


/** `Object#toString` result references. */
var argsTag = '[object Arguments]';
/**
 * The base implementation of `_.isArguments`.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 */
function baseIsArguments(value) {
  return (0,_isObjectLike_js__WEBPACK_IMPORTED_MODULE_1__["default"])(value) && (0,_baseGetTag_js__WEBPACK_IMPORTED_MODULE_0__["default"])(value) == argsTag;
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (baseIsArguments);

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_isFlattenable.js":
/*!****************************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_isFlattenable.js ***!
  \****************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _Symbol_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_Symbol.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_Symbol.js");
/* harmony import */ var _isArguments_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./isArguments.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isArguments.js");
/* harmony import */ var _isArray_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./isArray.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isArray.js");



/** Built-in value references. */
var spreadableSymbol = _Symbol_js__WEBPACK_IMPORTED_MODULE_0__["default"] ? _Symbol_js__WEBPACK_IMPORTED_MODULE_0__["default"].isConcatSpreadable : undefined;
/**
 * Checks if `value` is a flattenable `arguments` object or array.
 *
 * @private
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is flattenable, else `false`.
 */
function isFlattenable(value) {
  return (0,_isArray_js__WEBPACK_IMPORTED_MODULE_2__["default"])(value) || (0,_isArguments_js__WEBPACK_IMPORTED_MODULE_1__["default"])(value) || !!(spreadableSymbol && value && value[spreadableSymbol]);
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (isFlattenable);

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/flatten.js":
/*!*********************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/flatten.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseFlatten_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseFlatten.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseFlatten.js");

/**
 * Flattens `array` a single level deep.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Array
 * @param {Array} array The array to flatten.
 * @returns {Array} Returns the new flattened array.
 * @example
 *
 * _.flatten([1, [2, [3, [4]], 5]]);
 * // => [1, 2, [3, [4]], 5]
 */
function flatten(array) {
  var length = array == null ? 0 : array.length;
  return length ? (0,_baseFlatten_js__WEBPACK_IMPORTED_MODULE_0__["default"])(array, 1) : [];
}
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (flatten);

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isArguments.js":
/*!*************************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isArguments.js ***!
  \*************************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _baseIsArguments_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./_baseIsArguments.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/_baseIsArguments.js");
/* harmony import */ var _isObjectLike_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./isObjectLike.js */ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isObjectLike.js");


/** Used for built-in method references. */
var objectProto = Object.prototype;
/** Used to check objects for own properties. */
var hasOwnProperty = objectProto.hasOwnProperty;
/** Built-in value references. */
var propertyIsEnumerable = objectProto.propertyIsEnumerable;
/**
 * Checks if `value` is likely an `arguments` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an `arguments` object,
 *  else `false`.
 * @example
 *
 * _.isArguments(function() { return arguments; }());
 * // => true
 *
 * _.isArguments([1, 2, 3]);
 * // => false
 */
var isArguments = (0,_baseIsArguments_js__WEBPACK_IMPORTED_MODULE_0__["default"])(function () {
  return arguments;
}()) ? _baseIsArguments_js__WEBPACK_IMPORTED_MODULE_0__["default"] : function (value) {
  return (0,_isObjectLike_js__WEBPACK_IMPORTED_MODULE_1__["default"])(value) && hasOwnProperty.call(value, 'callee') && !propertyIsEnumerable.call(value, 'callee');
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (isArguments);

/***/ }),

/***/ "../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isArray.js":
/*!*********************************************************************************!*\
  !*** ../node_modules/.pnpm/lodash-es@4.17.21/node_modules/lodash-es/isArray.js ***!
  \*********************************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/**
 * Checks if `value` is classified as an `Array` object.
 *
 * @static
 * @memberOf _
 * @since 0.1.0
 * @category Lang
 * @param {*} value The value to check.
 * @returns {boolean} Returns `true` if `value` is an array, else `false`.
 * @example
 *
 * _.isArray([1, 2, 3]);
 * // => true
 *
 * _.isArray(document.body.children);
 * // => false
 *
 * _.isArray('abc');
 * // => false
 *
 * _.isArray(_.noop);
 * // => false
 */
var isArray = Array.isArray;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (isArray);

/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/config.js":
/*!***************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/config.js ***!
  \***************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   RANDOM: () => (/* binding */ RANDOM),
/* harmony export */   config: () => (/* binding */ config),
/* harmony export */   newConfig: () => (/* binding */ newConfig)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @babel/runtime/helpers/defineProperty */ "../node_modules/.pnpm/@babel+runtime@7.27.6/node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var _cpmBucketManager_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./cpmBucketManager.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/cpmBucketManager.js");
/* harmony import */ var _polyfill_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./polyfill.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/polyfill.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./utils.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils.js */ "../node_modules/.pnpm/dlv@1.1.3/node_modules/dlv/index.js");
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./constants.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/constants.js");

function ownKeys(e, r) {
  var t = Object.keys(e);
  if (Object.getOwnPropertySymbols) {
    var o = Object.getOwnPropertySymbols(e);
    r && (o = o.filter(function (r) {
      return Object.getOwnPropertyDescriptor(e, r).enumerable;
    })), t.push.apply(t, o);
  }
  return t;
}
function _objectSpread(e) {
  for (var r = 1; r < arguments.length; r++) {
    var t = null != arguments[r] ? arguments[r] : {};
    r % 2 ? ownKeys(Object(t), !0).forEach(function (r) {
      (0,_babel_runtime_helpers_defineProperty__WEBPACK_IMPORTED_MODULE_0__["default"])(e, r, t[r]);
    }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function (r) {
      Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
    });
  }
  return e;
}
/*
 * Module for getting and setting Prebid configuration.
*/
/**
 * @typedef {Object} MediaTypePriceGranularity
 *
 * @property {(string|Object)} [banner]
 * @property {(string|Object)} [native]
 * @property {(string|Object)} [video]
 * @property {(string|Object)} [video-instream]
 * @property {(string|Object)} [video-outstream]
 */




var DEFAULT_DEBUG = (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.getParameterByName)(_constants_js__WEBPACK_IMPORTED_MODULE_5__.DEBUG_MODE).toUpperCase() === 'TRUE';
var DEFAULT_BIDDER_TIMEOUT = 3000;
var DEFAULT_ENABLE_SEND_ALL_BIDS = true;
var DEFAULT_DISABLE_AJAX_TIMEOUT = false;
var DEFAULT_BID_CACHE = false;
var DEFAULT_DEVICE_ACCESS = true;
var DEFAULT_MAX_NESTED_IFRAMES = 10;
var DEFAULT_MAXBID_VALUE = 5000;
var DEFAULT_IFRAMES_CONFIG = {};
var RANDOM = 'random';
var FIXED = 'fixed';
var VALID_ORDERS = {};
VALID_ORDERS[RANDOM] = true;
VALID_ORDERS[FIXED] = true;
var DEFAULT_BIDDER_SEQUENCE = RANDOM;
var GRANULARITY_OPTIONS = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  AUTO: 'auto',
  DENSE: 'dense',
  CUSTOM: 'custom'
};
var ALL_TOPICS = '*';
function attachProperties(config) {
  var useDefaultValues = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  var values = useDefaultValues ? {
    priceGranularity: GRANULARITY_OPTIONS.MEDIUM,
    customPriceBucket: {},
    mediaTypePriceGranularity: {},
    bidderSequence: DEFAULT_BIDDER_SEQUENCE,
    auctionOptions: {}
  } : {};
  function getProp(name) {
    return values[name];
  }
  function setProp(name, val) {
    if (!values.hasOwnProperty(name)) {
      Object.defineProperty(config, name, {
        enumerable: true
      });
    }
    values[name] = val;
  }
  var props = {
    publisherDomain: {
      set(val) {
        if (val != null) {
          (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)('publisherDomain is deprecated and has no effect since v7 - use pageUrl instead');
        }
        setProp('publisherDomain', val);
      }
    },
    priceGranularity: {
      set(val) {
        if (validatePriceGranularity(val)) {
          if (typeof val === 'string') {
            setProp('priceGranularity', hasGranularity(val) ? val : GRANULARITY_OPTIONS.MEDIUM);
          } else if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(val)) {
            setProp('customPriceBucket', val);
            setProp('priceGranularity', GRANULARITY_OPTIONS.CUSTOM);
            (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logMessage)('Using custom price granularity');
          }
        }
      }
    },
    customPriceBucket: {},
    mediaTypePriceGranularity: {
      set(val) {
        val != null && setProp('mediaTypePriceGranularity', Object.keys(val).reduce((aggregate, item) => {
          if (validatePriceGranularity(val[item])) {
            if (typeof val === 'string') {
              aggregate[item] = hasGranularity(val[item]) ? val[item] : getProp('priceGranularity');
            } else if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(val)) {
              aggregate[item] = val[item];
              (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logMessage)("Using custom price granularity for ".concat(item));
            }
          } else {
            (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Invalid price granularity for media type: ".concat(item));
          }
          return aggregate;
        }, {}));
      }
    },
    bidderSequence: {
      set(val) {
        if (VALID_ORDERS[val]) {
          setProp('bidderSequence', val);
        } else {
          (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Invalid order: ".concat(val, ". Bidder Sequence was not set."));
        }
      }
    },
    auctionOptions: {
      set(val) {
        if (validateauctionOptions(val)) {
          setProp('auctionOptions', val);
        }
      }
    }
  };
  Object.defineProperties(config, Object.fromEntries(Object.entries(props).map(_ref => {
    var [k, def] = _ref;
    return [k, Object.assign({
      get: getProp.bind(null, k),
      set: setProp.bind(null, k),
      enumerable: values.hasOwnProperty(k),
      configurable: !values.hasOwnProperty(k)
    }, def)];
  })));
  return config;
  function hasGranularity(val) {
    return (0,_polyfill_js__WEBPACK_IMPORTED_MODULE_2__.find)(Object.keys(GRANULARITY_OPTIONS), option => val === GRANULARITY_OPTIONS[option]);
  }
  function validatePriceGranularity(val) {
    if (!val) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)('Prebid Error: no value passed to `setPriceGranularity()`');
      return false;
    }
    if (typeof val === 'string') {
      if (!hasGranularity(val)) {
        (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)('Prebid Warning: setPriceGranularity was called with invalid setting, using `medium` as default.');
      }
    } else if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(val)) {
      if (!(0,_cpmBucketManager_js__WEBPACK_IMPORTED_MODULE_1__.isValidPriceConfig)(val)) {
        (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)('Invalid custom price value passed to `setPriceGranularity()`');
        return false;
      }
    }
    return true;
  }
  function validateauctionOptions(val) {
    if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(val)) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)('Auction Options must be an object');
      return false;
    }
    for (var k of Object.keys(val)) {
      if (k !== 'secondaryBidders' && k !== 'suppressStaleRender' && k !== 'suppressExpiredRender') {
        (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Auction Options given an incorrect param: ".concat(k));
        return false;
      }
      if (k === 'secondaryBidders') {
        if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isArray)(val[k])) {
          (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Auction Options ".concat(k, " must be of type Array"));
          return false;
        } else if (!val[k].every(_utils_js__WEBPACK_IMPORTED_MODULE_3__.isStr)) {
          (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Auction Options ".concat(k, " must be only string"));
          return false;
        }
      } else if (k === 'suppressStaleRender' || k === 'suppressExpiredRender') {
        if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isBoolean)(val[k])) {
          (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Auction Options ".concat(k, " must be of type boolean"));
          return false;
        }
      }
    }
    return true;
  }
}
function newConfig() {
  var listeners = [];
  var defaults;
  var config;
  var bidderConfig;
  var currBidder = null;
  function resetConfig() {
    defaults = {};
    var newConfig = attachProperties({
      // `debug` is equivalent to legacy `pbjs.logging` property
      debug: DEFAULT_DEBUG,
      bidderTimeout: DEFAULT_BIDDER_TIMEOUT,
      enableSendAllBids: DEFAULT_ENABLE_SEND_ALL_BIDS,
      useBidCache: DEFAULT_BID_CACHE,
      /**
       * deviceAccess set to false will disable setCookie, getCookie, hasLocalStorage
       * @type {boolean}
       */
      deviceAccess: DEFAULT_DEVICE_ACCESS,
      disableAjaxTimeout: DEFAULT_DISABLE_AJAX_TIMEOUT,
      // default max nested iframes for referer detection
      maxNestedIframes: DEFAULT_MAX_NESTED_IFRAMES,
      // default max bid
      maxBid: DEFAULT_MAXBID_VALUE,
      userSync: {
        topics: DEFAULT_IFRAMES_CONFIG
      }
    });
    if (config) {
      callSubscribers(Object.keys(config).reduce((memo, topic) => {
        if (config[topic] !== newConfig[topic]) {
          memo[topic] = newConfig[topic] || {};
        }
        return memo;
      }, {}));
    }
    config = newConfig;
    bidderConfig = {};
  }
  /**
   * Returns base config with bidder overrides (if there is currently a bidder)
   * @private
   */
  function _getConfig() {
    if (currBidder && bidderConfig && (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(bidderConfig[currBidder])) {
      var currBidderConfig = bidderConfig[currBidder];
      var configTopicSet = new Set(Object.keys(config).concat(Object.keys(currBidderConfig)));
      return (0,_polyfill_js__WEBPACK_IMPORTED_MODULE_2__.arrayFrom)(configTopicSet).reduce((memo, topic) => {
        if (typeof currBidderConfig[topic] === 'undefined') {
          memo[topic] = config[topic];
        } else if (typeof config[topic] === 'undefined') {
          memo[topic] = currBidderConfig[topic];
        } else {
          if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(currBidderConfig[topic])) {
            memo[topic] = (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.mergeDeep)({}, config[topic], currBidderConfig[topic]);
          } else {
            memo[topic] = currBidderConfig[topic];
          }
        }
        return memo;
      }, {});
    }
    return Object.assign({}, config);
  }
  function _getRestrictedConfig() {
    // This causes reading 'ortb2' to throw an error; with prebid 7, that will almost
    // always be the incorrect way to access FPD configuration (https://github.com/prebid/Prebid.js/issues/7651)
    // code that needs the ortb2 config should explicitly use `getAnyConfig`
    // TODO: this is meant as a temporary tripwire to catch inadvertent use of `getConfig('ortb')` as we transition.
    // It should be removed once the risk of that happening is low enough.
    var conf = _getConfig();
    Object.defineProperty(conf, 'ortb2', {
      get: function () {
        throw new Error('invalid access to \'orbt2\' config - use request parameters instead');
      }
    });
    return conf;
  }
  var [getAnyConfig, getConfig] = [_getConfig, _getRestrictedConfig].map(accessor => {
    /*
     * Returns configuration object if called without parameters,
     * or single configuration property if given a string matching a configuration
     * property name.  Allows deep access e.g. getConfig('currency.adServerCurrency')
     *
     * If called with callback parameter, or a string and a callback parameter,
     * subscribes to configuration updates. See `subscribe` function for usage.
     */
    return function getConfig() {
      if (arguments.length <= 1 && typeof (arguments.length <= 0 ? undefined : arguments[0]) !== 'function') {
        var option = arguments.length <= 0 ? undefined : arguments[0];
        return option ? (0,_utils_js__WEBPACK_IMPORTED_MODULE_4__["default"])(accessor(), option) : _getConfig();
      }
      return subscribe(...arguments);
    };
  });
  var [readConfig, readAnyConfig] = [getConfig, getAnyConfig].map(wrapee => {
    /*
     * Like getConfig, except that it returns a deepClone of the result.
     */
    return function readConfig() {
      var res = wrapee(...arguments);
      if (res && typeof res === 'object') {
        res = (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.deepClone)(res);
      }
      return res;
    };
  });
  /**
   * Internal API for modules (such as prebid-server) that might need access to all bidder config
   */
  function getBidderConfig() {
    return bidderConfig;
  }
  /*
   * Sets configuration given an object containing key-value pairs and calls
   * listeners that were added by the `subscribe` function
   */
  function setConfig(options) {
    if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(options)) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)('setConfig options must be an object');
      return;
    }
    var topics = Object.keys(options);
    var topicalConfig = {};
    topics.forEach(topic => {
      var option = options[topic];
      if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(defaults[topic]) && (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(option)) {
        option = Object.assign({}, defaults[topic], option);
      }
      try {
        topicalConfig[topic] = config[topic] = option;
      } catch (e) {
        (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)("Cannot set config for property ".concat(topic, " : "), e);
      }
    });
    callSubscribers(topicalConfig);
  }
  /**
   * Sets configuration defaults which setConfig values can be applied on top of
   * @param {object} options
   */
  function setDefaults(options) {
    if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(defaults)) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)('defaults must be an object');
      return;
    }
    Object.assign(defaults, options);
    // Add default values to config as well
    Object.assign(config, options);
  }
  /*
   * Adds a function to a set of listeners that are invoked whenever `setConfig`
   * is called. The subscribed function will be passed the options object that
   * was used in the `setConfig` call. Topics can be subscribed to to only get
   * updates when specific properties are updated by passing a topic string as
   * the first parameter.
   *
   * If `options.init` is true, the listener will be immediately called with the current options.
   *
   * Returns an `unsubscribe` function for removing the subscriber from the
   * set of listeners
   *
   * Example use:
   * // subscribe to all configuration changes
   * subscribe((config) => console.log('config set:', config));
   *
   * // subscribe to only 'logging' changes
   * subscribe('logging', (config) => console.log('logging set:', config));
   *
   * // unsubscribe
   * const unsubscribe = subscribe(...);
   * unsubscribe(); // no longer listening
   *
   */
  function subscribe(topic, listener) {
    var options = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var callback = listener;
    if (typeof topic !== 'string') {
      // first param should be callback function in this case,
      // meaning it gets called for any config change
      callback = topic;
      topic = ALL_TOPICS;
      options = listener || {};
    }
    if (typeof callback !== 'function') {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)('listener must be a function');
      return;
    }
    var nl = {
      topic,
      callback
    };
    listeners.push(nl);
    if (options.init) {
      if (topic === ALL_TOPICS) {
        callback(getConfig());
      } else {
        // eslint-disable-next-line standard/no-callback-literal
        callback({
          [topic]: getConfig(topic)
        });
      }
    }
    // save and call this function to remove the listener
    return function unsubscribe() {
      listeners.splice(listeners.indexOf(nl), 1);
    };
  }
  /*
   * Calls listeners that were added by the `subscribe` function
   */
  function callSubscribers(options) {
    var TOPICS = Object.keys(options);
    // call subscribers of a specific topic, passing only that configuration
    listeners.filter(listener => (0,_polyfill_js__WEBPACK_IMPORTED_MODULE_2__.includes)(TOPICS, listener.topic)).forEach(listener => {
      listener.callback({
        [listener.topic]: options[listener.topic]
      });
    });
    // call subscribers that didn't give a topic, passing everything that was set
    listeners.filter(listener => listener.topic === ALL_TOPICS).forEach(listener => listener.callback(options));
  }
  function setBidderConfig(config) {
    var mergeFlag = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : false;
    try {
      check(config);
      config.bidders.forEach(bidder => {
        if (!bidderConfig[bidder]) {
          bidderConfig[bidder] = attachProperties({}, false);
        }
        Object.keys(config.config).forEach(topic => {
          var option = config.config[topic];
          var currentConfig = bidderConfig[bidder][topic];
          if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(option) && (currentConfig == null || (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(currentConfig))) {
            var func = mergeFlag ? _utils_js__WEBPACK_IMPORTED_MODULE_3__.mergeDeep : Object.assign;
            bidderConfig[bidder][topic] = func({}, currentConfig || {}, option);
          } else {
            bidderConfig[bidder][topic] = option;
          }
        });
      });
    } catch (e) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)(e);
    }
    function check(obj) {
      if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(obj)) {
        throw 'setBidderConfig bidder options must be an object';
      }
      if (!(Array.isArray(obj.bidders) && obj.bidders.length)) {
        throw 'setBidderConfig bidder options must contain a bidders list with at least 1 bidder';
      }
      if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(obj.config)) {
        throw 'setBidderConfig bidder options must contain a config object';
      }
    }
  }
  function mergeConfig(obj) {
    if (!(0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.isPlainObject)(obj)) {
      (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logError)('mergeConfig input must be an object');
      return;
    }
    var mergedConfig = (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.mergeDeep)(_getConfig(), obj);
    setConfig(_objectSpread({}, mergedConfig));
    return mergedConfig;
  }
  function mergeBidderConfig(obj) {
    return setBidderConfig(obj, true);
  }
  /**
   * Internal functions for core to execute some synchronous code while having an active bidder set.
   */
  function runWithBidder(bidder, fn) {
    currBidder = bidder;
    try {
      return fn();
    } finally {
      resetBidder();
    }
  }
  function callbackWithBidder(bidder) {
    return function (cb) {
      return function () {
        if (typeof cb === 'function') {
          for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
            args[_key] = arguments[_key];
          }
          return runWithBidder(bidder, cb.bind(this, ...args));
        } else {
          (0,_utils_js__WEBPACK_IMPORTED_MODULE_3__.logWarn)('config.callbackWithBidder callback is not a function');
        }
      };
    };
  }
  function getCurrentBidder() {
    return currBidder;
  }
  function resetBidder() {
    currBidder = null;
  }
  resetConfig();
  return {
    getCurrentBidder,
    resetBidder,
    getConfig,
    getAnyConfig,
    readConfig,
    readAnyConfig,
    setConfig,
    mergeConfig,
    setDefaults,
    resetConfig,
    runWithBidder,
    callbackWithBidder,
    setBidderConfig,
    getBidderConfig,
    mergeBidderConfig
  };
}
/**
 * Set a `cache.url` if we should use prebid-cache to store video bids before adding bids to the auction.
 * This must be set if you want to use the dfpAdServerVideo module.
 */
var config = newConfig();

/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/constants.js":
/*!******************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/constants.js ***!
  \******************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   AD_RENDER_FAILED_REASON: () => (/* binding */ AD_RENDER_FAILED_REASON),
/* harmony export */   BID_STATUS: () => (/* binding */ BID_STATUS),
/* harmony export */   DEBUG_MODE: () => (/* binding */ DEBUG_MODE),
/* harmony export */   DEFAULT_TARGETING_KEYS: () => (/* binding */ DEFAULT_TARGETING_KEYS),
/* harmony export */   EVENTS: () => (/* binding */ EVENTS),
/* harmony export */   EVENT_ID_PATHS: () => (/* binding */ EVENT_ID_PATHS),
/* harmony export */   GRANULARITY_OPTIONS: () => (/* binding */ GRANULARITY_OPTIONS),
/* harmony export */   JSON_MAPPING: () => (/* binding */ JSON_MAPPING),
/* harmony export */   MESSAGES: () => (/* binding */ MESSAGES),
/* harmony export */   NATIVE_ASSET_TYPES: () => (/* binding */ NATIVE_ASSET_TYPES),
/* harmony export */   NATIVE_IMAGE_TYPES: () => (/* binding */ NATIVE_IMAGE_TYPES),
/* harmony export */   NATIVE_KEYS: () => (/* binding */ NATIVE_KEYS),
/* harmony export */   NATIVE_KEYS_THAT_ARE_NOT_ASSETS: () => (/* binding */ NATIVE_KEYS_THAT_ARE_NOT_ASSETS),
/* harmony export */   PB_LOCATOR: () => (/* binding */ PB_LOCATOR),
/* harmony export */   PREBID_NATIVE_DATA_KEYS_TO_ORTB: () => (/* binding */ PREBID_NATIVE_DATA_KEYS_TO_ORTB),
/* harmony export */   REJECTION_REASON: () => (/* binding */ REJECTION_REASON),
/* harmony export */   S2S: () => (/* binding */ S2S),
/* harmony export */   STATUS: () => (/* binding */ STATUS),
/* harmony export */   TARGETING_KEYS: () => (/* binding */ TARGETING_KEYS)
/* harmony export */ });
var JSON_MAPPING = {
  PL_CODE: 'code',
  PL_SIZE: 'sizes',
  PL_BIDS: 'bids',
  BD_BIDDER: 'bidder',
  BD_ID: 'paramsd',
  BD_PL_ID: 'placementId',
  ADSERVER_TARGETING: 'adserverTargeting',
  BD_SETTING_STANDARD: 'standard'
};
var DEBUG_MODE = 'pbjs_debug';
var STATUS = {
  GOOD: 1
};
var EVENTS = {
  AUCTION_INIT: 'auctionInit',
  AUCTION_TIMEOUT: 'auctionTimeout',
  AUCTION_END: 'auctionEnd',
  BID_ADJUSTMENT: 'bidAdjustment',
  BID_TIMEOUT: 'bidTimeout',
  BID_REQUESTED: 'bidRequested',
  BID_RESPONSE: 'bidResponse',
  BID_REJECTED: 'bidRejected',
  NO_BID: 'noBid',
  SEAT_NON_BID: 'seatNonBid',
  BID_WON: 'bidWon',
  BIDDER_DONE: 'bidderDone',
  BIDDER_ERROR: 'bidderError',
  SET_TARGETING: 'setTargeting',
  BEFORE_REQUEST_BIDS: 'beforeRequestBids',
  BEFORE_BIDDER_HTTP: 'beforeBidderHttp',
  REQUEST_BIDS: 'requestBids',
  ADD_AD_UNITS: 'addAdUnits',
  AD_RENDER_FAILED: 'adRenderFailed',
  AD_RENDER_SUCCEEDED: 'adRenderSucceeded',
  TCF2_ENFORCEMENT: 'tcf2Enforcement',
  AUCTION_DEBUG: 'auctionDebug',
  BID_VIEWABLE: 'bidViewable',
  STALE_RENDER: 'staleRender',
  EXPIRED_RENDER: 'expiredRender',
  BILLABLE_EVENT: 'billableEvent',
  BID_ACCEPTED: 'bidAccepted',
  RUN_PAAPI_AUCTION: 'paapiRunAuction',
  PBS_ANALYTICS: 'pbsAnalytics',
  PAAPI_BID: 'paapiBid',
  PAAPI_NO_BID: 'paapiNoBid',
  PAAPI_ERROR: 'paapiError'
};
var AD_RENDER_FAILED_REASON = {
  PREVENT_WRITING_ON_MAIN_DOCUMENT: 'preventWritingOnMainDocument',
  NO_AD: 'noAd',
  EXCEPTION: 'exception',
  CANNOT_FIND_AD: 'cannotFindAd',
  MISSING_DOC_OR_ADID: 'missingDocOrAdid'
};
var EVENT_ID_PATHS = {
  bidWon: 'adUnitCode'
};
var GRANULARITY_OPTIONS = {
  LOW: 'low',
  MEDIUM: 'medium',
  HIGH: 'high',
  AUTO: 'auto',
  DENSE: 'dense',
  CUSTOM: 'custom'
};
var TARGETING_KEYS = {
  BIDDER: 'hb_bidder',
  AD_ID: 'hb_adid',
  PRICE_BUCKET: 'hb_pb',
  SIZE: 'hb_size',
  DEAL: 'hb_deal',
  SOURCE: 'hb_source',
  FORMAT: 'hb_format',
  UUID: 'hb_uuid',
  CACHE_ID: 'hb_cache_id',
  CACHE_HOST: 'hb_cache_host',
  ADOMAIN: 'hb_adomain',
  ACAT: 'hb_acat',
  CRID: 'hb_crid',
  DSP: 'hb_dsp'
};
var DEFAULT_TARGETING_KEYS = {
  BIDDER: 'hb_bidder',
  AD_ID: 'hb_adid',
  PRICE_BUCKET: 'hb_pb',
  SIZE: 'hb_size',
  DEAL: 'hb_deal',
  FORMAT: 'hb_format',
  UUID: 'hb_uuid',
  CACHE_HOST: 'hb_cache_host'
};
var NATIVE_KEYS = {
  title: 'hb_native_title',
  body: 'hb_native_body',
  body2: 'hb_native_body2',
  privacyLink: 'hb_native_privacy',
  privacyIcon: 'hb_native_privicon',
  sponsoredBy: 'hb_native_brand',
  image: 'hb_native_image',
  icon: 'hb_native_icon',
  clickUrl: 'hb_native_linkurl',
  displayUrl: 'hb_native_displayurl',
  cta: 'hb_native_cta',
  rating: 'hb_native_rating',
  address: 'hb_native_address',
  downloads: 'hb_native_downloads',
  likes: 'hb_native_likes',
  phone: 'hb_native_phone',
  price: 'hb_native_price',
  salePrice: 'hb_native_saleprice',
  rendererUrl: 'hb_renderer_url',
  adTemplate: 'hb_adTemplate'
};
var S2S = {
  SRC: 's2s',
  DEFAULT_ENDPOINT: 'https://prebid.adnxs.com/pbs/v1/openrtb2/auction',
  SYNCED_BIDDERS_KEY: 'pbjsSyncs'
};
var BID_STATUS = {
  BID_TARGETING_SET: 'targetingSet',
  RENDERED: 'rendered',
  BID_REJECTED: 'bidRejected'
};
var REJECTION_REASON = {
  INVALID: 'Bid has missing or invalid properties',
  INVALID_REQUEST_ID: 'Invalid request ID',
  BIDDER_DISALLOWED: 'Bidder code is not allowed by allowedAlternateBidderCodes / allowUnknownBidderCodes',
  FLOOR_NOT_MET: 'Bid does not meet price floor',
  CANNOT_CONVERT_CURRENCY: 'Unable to convert currency',
  DSA_REQUIRED: 'Bid does not provide required DSA transparency info',
  DSA_MISMATCH: 'Bid indicates inappropriate DSA rendering method',
  PRICE_TOO_HIGH: 'Bid price exceeds maximum value'
};
var PREBID_NATIVE_DATA_KEYS_TO_ORTB = {
  body: 'desc',
  body2: 'desc2',
  sponsoredBy: 'sponsored',
  cta: 'ctatext',
  rating: 'rating',
  address: 'address',
  downloads: 'downloads',
  likes: 'likes',
  phone: 'phone',
  price: 'price',
  salePrice: 'saleprice',
  displayUrl: 'displayurl'
};
var NATIVE_ASSET_TYPES = {
  sponsored: 1,
  desc: 2,
  rating: 3,
  likes: 4,
  downloads: 5,
  price: 6,
  saleprice: 7,
  phone: 8,
  address: 9,
  desc2: 10,
  displayurl: 11,
  ctatext: 12
};
var NATIVE_IMAGE_TYPES = {
  ICON: 1,
  MAIN: 3
};
var NATIVE_KEYS_THAT_ARE_NOT_ASSETS = ['privacyIcon', 'clickUrl', 'sendTargetingKeys', 'adTemplate', 'rendererUrl', 'type'];
var MESSAGES = {
  REQUEST: 'Prebid Request',
  RESPONSE: 'Prebid Response',
  NATIVE: 'Prebid Native',
  EVENT: 'Prebid Event'
};
var PB_LOCATOR = '__pb_locator__';

/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/cpmBucketManager.js":
/*!*************************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/cpmBucketManager.js ***!
  \*************************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getPriceBucketString: () => (/* binding */ getPriceBucketString),
/* harmony export */   isValidPriceConfig: () => (/* binding */ isValidPriceConfig)
/* harmony export */ });
/* harmony import */ var _polyfill_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./polyfill.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/polyfill.js");
/* harmony import */ var _utils_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./utils.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils.js");
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./config.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/config.js");



var _defaultPrecision = 2;
var _lgPriceConfig = {
  'buckets': [{
    'max': 5,
    'increment': 0.5
  }]
};
var _mgPriceConfig = {
  'buckets': [{
    'max': 20,
    'increment': 0.1
  }]
};
var _hgPriceConfig = {
  'buckets': [{
    'max': 20,
    'increment': 0.01
  }]
};
var _densePriceConfig = {
  'buckets': [{
    'max': 3,
    'increment': 0.01
  }, {
    'max': 8,
    'increment': 0.05
  }, {
    'max': 20,
    'increment': 0.5
  }]
};
var _autoPriceConfig = {
  'buckets': [{
    'max': 5,
    'increment': 0.05
  }, {
    'max': 10,
    'increment': 0.1
  }, {
    'max': 20,
    'increment': 0.5
  }]
};
function getPriceBucketString(cpm, customConfig) {
  var granularityMultiplier = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : 1;
  var cpmFloat = parseFloat(cpm);
  if (isNaN(cpmFloat)) {
    cpmFloat = '';
  }
  return {
    low: cpmFloat === '' ? '' : getCpmStringValue(cpm, _lgPriceConfig, granularityMultiplier),
    med: cpmFloat === '' ? '' : getCpmStringValue(cpm, _mgPriceConfig, granularityMultiplier),
    high: cpmFloat === '' ? '' : getCpmStringValue(cpm, _hgPriceConfig, granularityMultiplier),
    auto: cpmFloat === '' ? '' : getCpmStringValue(cpm, _autoPriceConfig, granularityMultiplier),
    dense: cpmFloat === '' ? '' : getCpmStringValue(cpm, _densePriceConfig, granularityMultiplier),
    custom: cpmFloat === '' ? '' : getCpmStringValue(cpm, customConfig, granularityMultiplier)
  };
}
function getCpmStringValue(cpm, config, granularityMultiplier) {
  var cpmStr = '';
  if (!isValidPriceConfig(config)) {
    return cpmStr;
  }
  var cap = config.buckets.reduce((prev, curr) => {
    if (prev.max > curr.max) {
      return prev;
    }
    return curr;
  }, {
    'max': 0
  });
  var bucketFloor = 0;
  var bucket = (0,_polyfill_js__WEBPACK_IMPORTED_MODULE_0__.find)(config.buckets, bucket => {
    if (cpm > cap.max * granularityMultiplier) {
      // cpm exceeds cap, just return the cap.
      var precision = bucket.precision;
      if (typeof precision === 'undefined') {
        precision = _defaultPrecision;
      }
      cpmStr = (bucket.max * granularityMultiplier).toFixed(precision);
    } else if (cpm <= bucket.max * granularityMultiplier && cpm >= bucketFloor * granularityMultiplier) {
      bucket.min = bucketFloor;
      return bucket;
    } else {
      bucketFloor = bucket.max;
    }
  });
  if (bucket) {
    cpmStr = getCpmTarget(cpm, bucket, granularityMultiplier);
  }
  return cpmStr;
}
function isValidPriceConfig(config) {
  if ((0,_utils_js__WEBPACK_IMPORTED_MODULE_1__.isEmpty)(config) || !config.buckets || !Array.isArray(config.buckets)) {
    return false;
  }
  var isValid = true;
  config.buckets.forEach(bucket => {
    if (!bucket.max || !bucket.increment) {
      isValid = false;
    }
  });
  return isValid;
}
function getCpmTarget(cpm, bucket, granularityMultiplier) {
  var precision = typeof bucket.precision !== 'undefined' ? bucket.precision : _defaultPrecision;
  var increment = bucket.increment * granularityMultiplier;
  var bucketMin = bucket.min * granularityMultiplier;
  var roundingFunction = Math.floor;
  var customRoundingFunction = _config_js__WEBPACK_IMPORTED_MODULE_2__.config.getConfig('cpmRoundingFunction');
  if (typeof customRoundingFunction === 'function') {
    roundingFunction = customRoundingFunction;
  }
  // start increments at the bucket min and then add bucket min back to arrive at the correct rounding
  // note - we're padding the values to avoid using decimals in the math prior to flooring
  // this is done as JS can return values slightly below the expected mark which would skew the price bucket target
  //   (eg 4.01 / 0.01 = 400.99999999999994)
  // min precison should be 2 to move decimal place over.
  var pow = Math.pow(10, precision + 2);
  var cpmToRound = (cpm * pow - bucketMin * pow) / (increment * pow);
  var cpmTarget;
  var invalidRounding;
  // It is likely that we will be passed {cpmRoundingFunction: roundingFunction()}
  // rather than the expected {cpmRoundingFunction: roundingFunction}. Default back to floor in that case
  try {
    cpmTarget = roundingFunction(cpmToRound) * increment + bucketMin;
  } catch (err) {
    invalidRounding = true;
  }
  if (invalidRounding || typeof cpmTarget !== 'number') {
    (0,_utils_js__WEBPACK_IMPORTED_MODULE_1__.logWarn)('Invalid rounding function passed in config');
    cpmTarget = Math.floor(cpmToRound) * increment + bucketMin;
  }
  // force to 10 decimal places to deal with imprecise decimal/binary conversions
  //    (for example 0.1 * 3 = 0.30000000000000004)
  cpmTarget = Number(cpmTarget.toFixed(10));
  return cpmTarget.toFixed(precision);
}


/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/polyfill.js":
/*!*****************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/polyfill.js ***!
  \*****************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   arrayFrom: () => (/* binding */ arrayFrom),
/* harmony export */   find: () => (/* binding */ find),
/* harmony export */   findIndex: () => (/* binding */ findIndex),
/* harmony export */   includes: () => (/* binding */ includes)
/* harmony export */ });
// These stubs are here to help transition away from core-js polyfills for browsers we are no longer supporting.
// You should not need these for new code; use stock JS instead!
function includes(target, elem, start) {
  return target && target.includes(elem, start) || false;
}
function arrayFrom() {
  return Array.from.apply(Array, arguments);
}
function find(arr, pred, thisArg) {
  return arr && arr.find(pred, thisArg);
}
function findIndex(arr, pred, thisArg) {
  return arr && arr.findIndex(pred, thisArg);
}

/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/prebidGlobal.js":
/*!*********************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/prebidGlobal.js ***!
  \*********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   getGlobal: () => (/* binding */ getGlobal),
/* harmony export */   registerModule: () => (/* binding */ registerModule)
/* harmony export */ });
// if $$PREBID_GLOBAL$$ already exists in global document scope, use it, if not, create the object
// global defination should happen BEFORE imports to avoid global undefined errors.
/* global $$DEFINE_PREBID_GLOBAL$$ */
var scope =  false ? 0 : window;
var global = scope.pbjs = scope.pbjs || {};
global.cmd = global.cmd || [];
global.que = global.que || [];
// create a pbjs global pointer
if (scope === window) {
  scope._pbjsGlobals = scope._pbjsGlobals || [];
  scope._pbjsGlobals.push("pbjs");
}
function getGlobal() {
  return global;
}
function registerModule(name) {
  global.installedModules.push(name);
}

/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils.js":
/*!**************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils.js ***!
  \**************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   _each: () => (/* binding */ _each),
/* harmony export */   _map: () => (/* binding */ _map),
/* harmony export */   _setEventEmitter: () => (/* binding */ _setEventEmitter),
/* harmony export */   binarySearch: () => (/* binding */ binarySearch),
/* harmony export */   buildUrl: () => (/* binding */ buildUrl),
/* harmony export */   canAccessWindowTop: () => (/* binding */ canAccessWindowTop),
/* harmony export */   checkCookieSupport: () => (/* binding */ checkCookieSupport),
/* harmony export */   cleanObj: () => (/* binding */ cleanObj),
/* harmony export */   compareCodeAndSlot: () => (/* binding */ compareCodeAndSlot),
/* harmony export */   contains: () => (/* binding */ contains),
/* harmony export */   convertObjectToArray: () => (/* binding */ convertObjectToArray),
/* harmony export */   createIframe: () => (/* binding */ createIframe),
/* harmony export */   createInvisibleIframe: () => (/* binding */ createInvisibleIframe),
/* harmony export */   createTrackPixelHtml: () => (/* binding */ createTrackPixelHtml),
/* harmony export */   createTrackPixelIframeHtml: () => (/* binding */ createTrackPixelIframeHtml),
/* harmony export */   cyrb53Hash: () => (/* binding */ cyrb53Hash),
/* harmony export */   debugTurnedOn: () => (/* binding */ debugTurnedOn),
/* harmony export */   deepAccess: () => (/* reexport safe */ dlv_index_js__WEBPACK_IMPORTED_MODULE_6__["default"]),
/* harmony export */   deepClone: () => (/* binding */ deepClone),
/* harmony export */   deepEqual: () => (/* binding */ deepEqual),
/* harmony export */   deepSetValue: () => (/* reexport safe */ dset__WEBPACK_IMPORTED_MODULE_7__.dset),
/* harmony export */   delayExecution: () => (/* binding */ delayExecution),
/* harmony export */   encodeMacroURI: () => (/* binding */ encodeMacroURI),
/* harmony export */   extractDomainFromHost: () => (/* binding */ extractDomainFromHost),
/* harmony export */   flatten: () => (/* binding */ flatten),
/* harmony export */   formatQS: () => (/* binding */ formatQS),
/* harmony export */   generateUUID: () => (/* binding */ generateUUID),
/* harmony export */   getBidIdParameter: () => (/* binding */ getBidIdParameter),
/* harmony export */   getBidRequest: () => (/* binding */ getBidRequest),
/* harmony export */   getBidderCodes: () => (/* binding */ getBidderCodes),
/* harmony export */   getDNT: () => (/* binding */ getDNT),
/* harmony export */   getDefinedParams: () => (/* binding */ getDefinedParams),
/* harmony export */   getDomLoadingDuration: () => (/* binding */ getDomLoadingDuration),
/* harmony export */   getParameterByName: () => (/* binding */ getParameterByName),
/* harmony export */   getPerformanceNow: () => (/* binding */ getPerformanceNow),
/* harmony export */   getPrebidInternal: () => (/* binding */ getPrebidInternal),
/* harmony export */   getSafeframeGeometry: () => (/* binding */ getSafeframeGeometry),
/* harmony export */   getUniqueIdentifierStr: () => (/* binding */ getUniqueIdentifierStr),
/* harmony export */   getUnixTimestampFromNow: () => (/* binding */ getUnixTimestampFromNow),
/* harmony export */   getUserConfiguredParams: () => (/* binding */ getUserConfiguredParams),
/* harmony export */   getValue: () => (/* binding */ getValue),
/* harmony export */   getWindowLocation: () => (/* binding */ getWindowLocation),
/* harmony export */   getWindowSelf: () => (/* binding */ getWindowSelf),
/* harmony export */   getWindowTop: () => (/* binding */ getWindowTop),
/* harmony export */   groupBy: () => (/* binding */ groupBy),
/* harmony export */   hasConsoleLogger: () => (/* binding */ hasConsoleLogger),
/* harmony export */   hasDeviceAccess: () => (/* binding */ hasDeviceAccess),
/* harmony export */   hasNonSerializableProperty: () => (/* binding */ hasNonSerializableProperty),
/* harmony export */   inIframe: () => (/* binding */ inIframe),
/* harmony export */   insertElement: () => (/* binding */ insertElement),
/* harmony export */   insertHtmlIntoIframe: () => (/* binding */ insertHtmlIntoIframe),
/* harmony export */   insertUserSyncIframe: () => (/* binding */ insertUserSyncIframe),
/* harmony export */   internal: () => (/* binding */ internal),
/* harmony export */   isA: () => (/* binding */ isA),
/* harmony export */   isAdUnitCodeMatchingSlot: () => (/* binding */ isAdUnitCodeMatchingSlot),
/* harmony export */   isApnGetTagDefined: () => (/* binding */ isApnGetTagDefined),
/* harmony export */   isArray: () => (/* binding */ isArray),
/* harmony export */   isArrayOfNums: () => (/* binding */ isArrayOfNums),
/* harmony export */   isBoolean: () => (/* binding */ isBoolean),
/* harmony export */   isEmpty: () => (/* binding */ isEmpty),
/* harmony export */   isEmptyStr: () => (/* binding */ isEmptyStr),
/* harmony export */   isFn: () => (/* binding */ isFn),
/* harmony export */   isGptPubadsDefined: () => (/* binding */ isGptPubadsDefined),
/* harmony export */   isInteger: () => (/* binding */ isInteger),
/* harmony export */   isNumber: () => (/* binding */ isNumber),
/* harmony export */   isPlainObject: () => (/* binding */ isPlainObject),
/* harmony export */   isSafariBrowser: () => (/* binding */ isSafariBrowser),
/* harmony export */   isSafeFrameWindow: () => (/* binding */ isSafeFrameWindow),
/* harmony export */   isStr: () => (/* binding */ isStr),
/* harmony export */   isValidMediaTypes: () => (/* binding */ isValidMediaTypes),
/* harmony export */   logError: () => (/* binding */ logError),
/* harmony export */   logInfo: () => (/* binding */ logInfo),
/* harmony export */   logMessage: () => (/* binding */ logMessage),
/* harmony export */   logWarn: () => (/* binding */ logWarn),
/* harmony export */   memoize: () => (/* binding */ memoize),
/* harmony export */   mergeDeep: () => (/* binding */ mergeDeep),
/* harmony export */   parseGPTSingleSizeArray: () => (/* binding */ parseGPTSingleSizeArray),
/* harmony export */   parseGPTSingleSizeArrayToRtbSize: () => (/* binding */ parseGPTSingleSizeArrayToRtbSize),
/* harmony export */   parseQS: () => (/* binding */ parseQS),
/* harmony export */   parseQueryStringParameters: () => (/* binding */ parseQueryStringParameters),
/* harmony export */   parseSizesInput: () => (/* binding */ parseSizesInput),
/* harmony export */   parseUrl: () => (/* binding */ parseUrl),
/* harmony export */   pick: () => (/* binding */ pick),
/* harmony export */   prefixLog: () => (/* binding */ prefixLog),
/* harmony export */   replaceAuctionPrice: () => (/* binding */ replaceAuctionPrice),
/* harmony export */   replaceClickThrough: () => (/* binding */ replaceClickThrough),
/* harmony export */   replaceMacros: () => (/* binding */ replaceMacros),
/* harmony export */   safeJSONEncode: () => (/* binding */ safeJSONEncode),
/* harmony export */   safeJSONParse: () => (/* binding */ safeJSONParse),
/* harmony export */   setOnAny: () => (/* binding */ setOnAny),
/* harmony export */   setScriptAttributes: () => (/* binding */ setScriptAttributes),
/* harmony export */   shuffle: () => (/* binding */ shuffle),
/* harmony export */   sizeTupleToRtbSize: () => (/* binding */ sizeTupleToRtbSize),
/* harmony export */   sizeTupleToSizeString: () => (/* binding */ sizeTupleToSizeString),
/* harmony export */   sizesToSizeTuples: () => (/* binding */ sizesToSizeTuples),
/* harmony export */   sortByHighestCpm: () => (/* binding */ sortByHighestCpm),
/* harmony export */   timestamp: () => (/* binding */ timestamp),
/* harmony export */   transformAdServerTargetingObj: () => (/* binding */ transformAdServerTargetingObj),
/* harmony export */   triggerNurlWithCpm: () => (/* binding */ triggerNurlWithCpm),
/* harmony export */   triggerPixel: () => (/* binding */ triggerPixel),
/* harmony export */   uniques: () => (/* binding */ uniques),
/* harmony export */   unsupportedBidderMessage: () => (/* binding */ unsupportedBidderMessage),
/* harmony export */   waitForElementToLoad: () => (/* binding */ waitForElementToLoad)
/* harmony export */ });
/* harmony import */ var _config_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./config.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/config.js");
/* harmony import */ var klona_json__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! klona/json */ "../node_modules/.pnpm/klona@2.0.6/node_modules/klona/json/index.mjs");
/* harmony import */ var _polyfill_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./polyfill.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/polyfill.js");
/* harmony import */ var _constants_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./constants.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/constants.js");
/* harmony import */ var _utils_promise_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./utils/promise.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils/promise.js");
/* harmony import */ var _prebidGlobal_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./prebidGlobal.js */ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/prebidGlobal.js");
/* harmony import */ var dlv_index_js__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! dlv/index.js */ "../node_modules/.pnpm/dlv@1.1.3/node_modules/dlv/index.js");
/* harmony import */ var dset__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! dset */ "../node_modules/.pnpm/dset@3.1.4/node_modules/dset/dist/index.mjs");









var tStr = 'String';
var tFn = 'Function';
var tNumb = 'Number';
var tObject = 'Object';
var tBoolean = 'Boolean';
var toString = Object.prototype.toString;
var consoleExists = Boolean(window.console);
var consoleLogExists = Boolean(consoleExists && window.console.log);
var consoleInfoExists = Boolean(consoleExists && window.console.info);
var consoleWarnExists = Boolean(consoleExists && window.console.warn);
var consoleErrorExists = Boolean(consoleExists && window.console.error);
var eventEmitter;
var pbjsInstance = (0,_prebidGlobal_js__WEBPACK_IMPORTED_MODULE_5__.getGlobal)();
function _setEventEmitter(emitFn) {
  // called from events.js - this hoop is to avoid circular imports
  eventEmitter = emitFn;
}
function emitEvent() {
  if (eventEmitter != null) {
    eventEmitter(...arguments);
  }
}
// this allows stubbing of utility functions that are used internally by other utility functions
var internal = {
  checkCookieSupport,
  createTrackPixelIframeHtml,
  getWindowSelf,
  getWindowTop,
  canAccessWindowTop,
  getWindowLocation,
  insertUserSyncIframe,
  insertElement,
  isFn,
  triggerPixel,
  logError,
  logWarn,
  logMessage,
  logInfo,
  parseQS,
  formatQS,
  deepEqual
};
var prebidInternal = {};
/**
 * Returns object that is used as internal prebid namespace
 */
function getPrebidInternal() {
  return prebidInternal;
}
/* utility method to get incremental integer starting from 1 */
var getIncrementalInteger = function () {
  var count = 0;
  return function () {
    count++;
    return count;
  };
}();
// generate a random string (to be used as a dynamic JSONP callback)
function getUniqueIdentifierStr() {
  return getIncrementalInteger() + Math.random().toString(16).substr(2);
}
/**
 * Returns a random v4 UUID of the form xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx,
 * where each x is replaced with a random hexadecimal digit from 0 to f,
 * and y is replaced with a random hexadecimal digit from 8 to b.
 * https://gist.github.com/jed/982883 via node-uuid
 */
function generateUUID(placeholder) {
  return placeholder ? (placeholder ^ _getRandomData() >> placeholder / 4).toString(16) : ([1e7] + -1e3 + -4e3 + -8e3 + -1e11).replace(/[018]/g, generateUUID);
}
/**
 * Returns random data using the Crypto API if available and Math.random if not
 * Method is from https://gist.github.com/jed/982883 like generateUUID, direct link https://gist.github.com/jed/982883#gistcomment-45104
 */
function _getRandomData() {
  if (window && window.crypto && window.crypto.getRandomValues) {
    return crypto.getRandomValues(new Uint8Array(1))[0] % 16;
  } else {
    return Math.random() * 16;
  }
}
function getBidIdParameter(key, paramsObj) {
  return (paramsObj === null || paramsObj === void 0 ? void 0 : paramsObj[key]) || '';
}
// parse a query string object passed in bid params
// bid params should be an object such as {key: "value", key1 : "value1"}
// aliases to formatQS
function parseQueryStringParameters(queryObj) {
  var result = '';
  for (var k in queryObj) {
    if (queryObj.hasOwnProperty(k)) {
      result += k + '=' + encodeURIComponent(queryObj[k]) + '&';
    }
  }
  result = result.replace(/&$/, '');
  return result;
}
// transform an AdServer targeting bids into a query string to send to the adserver
function transformAdServerTargetingObj(targeting) {
  // we expect to receive targeting for a single slot at a time
  if (targeting && Object.getOwnPropertyNames(targeting).length > 0) {
    return Object.keys(targeting).map(key => "".concat(key, "=").concat(encodeURIComponent(targeting[key]))).join('&');
  } else {
    return '';
  }
}
/**
 * Parse a GPT-Style general size Array like `[[300, 250]]` or `"300x250,970x90"` into an array of width, height tuples `[[300, 250]]` or '[[300,250], [970,90]]'
 */
function sizesToSizeTuples(sizes) {
  if (typeof sizes === 'string') {
    // multiple sizes will be comma-separated
    return sizes.split(/\s*,\s*/).map(sz => sz.match(/^(\d+)x(\d+)$/i)).filter(match => match).map(_ref => {
      var [_, w, h] = _ref;
      return [parseInt(w, 10), parseInt(h, 10)];
    });
  } else if (Array.isArray(sizes)) {
    if (isValidGPTSingleSize(sizes)) {
      return [sizes];
    }
    return sizes.filter(isValidGPTSingleSize);
  }
  return [];
}
/**
 * Parse a GPT-Style general size Array like `[[300, 250]]` or `"300x250,970x90"` into an array of sizes `["300x250"]` or '['300x250', '970x90']'
 * @param  {(Array.<number[]>|Array.<number>)} sizeObj Input array or double array [300,250] or [[300,250], [728,90]]
 * @return {Array.<string>}  Array of strings like `["300x250"]` or `["300x250", "728x90"]`
 */
function parseSizesInput(sizeObj) {
  return sizesToSizeTuples(sizeObj).map(sizeTupleToSizeString);
}
function sizeTupleToSizeString(size) {
  return size[0] + 'x' + size[1];
}
// Parse a GPT style single size array, (i.e [300, 250])
// into an AppNexus style string, (i.e. 300x250)
function parseGPTSingleSizeArray(singleSize) {
  if (isValidGPTSingleSize(singleSize)) {
    return sizeTupleToSizeString(singleSize);
  }
}
function sizeTupleToRtbSize(size) {
  return {
    w: size[0],
    h: size[1]
  };
}
// Parse a GPT style single size array, (i.e [300, 250])
// into OpenRTB-compatible (imp.banner.w/h, imp.banner.format.w/h, imp.video.w/h) object(i.e. {w:300, h:250})
function parseGPTSingleSizeArrayToRtbSize(singleSize) {
  if (isValidGPTSingleSize(singleSize)) {
    return sizeTupleToRtbSize(singleSize);
  }
}
function isValidGPTSingleSize(singleSize) {
  // if we aren't exactly 2 items in this array, it is invalid
  return isArray(singleSize) && singleSize.length === 2 && !isNaN(singleSize[0]) && !isNaN(singleSize[1]);
}
function getWindowTop() {
  return window.top;
}
function getWindowSelf() {
  return window.self;
}
function getWindowLocation() {
  return window.location;
}
function canAccessWindowTop() {
  try {
    if (internal.getWindowTop().location.href) {
      return true;
    }
  } catch (e) {
    return false;
  }
}
/**
 * Wrappers to console.(log | info | warn | error). Takes N arguments, the same as the native methods
 */
function logMessage() {
  if (debugTurnedOn() && consoleLogExists) {
    // eslint-disable-next-line no-console
    console.log.apply(console, decorateLog(arguments, 'MESSAGE:'));
  }
}
function logInfo() {
  if (debugTurnedOn() && consoleInfoExists) {
    // eslint-disable-next-line no-console
    console.info.apply(console, decorateLog(arguments, 'INFO:'));
  }
}
function logWarn() {
  if (debugTurnedOn() && consoleWarnExists) {
    // eslint-disable-next-line no-console
    console.warn.apply(console, decorateLog(arguments, 'WARNING:'));
  }
  emitEvent(_constants_js__WEBPACK_IMPORTED_MODULE_3__.EVENTS.AUCTION_DEBUG, {
    type: 'WARNING',
    arguments: arguments
  });
}
function logError() {
  if (debugTurnedOn() && consoleErrorExists) {
    // eslint-disable-next-line no-console
    console.error.apply(console, decorateLog(arguments, 'ERROR:'));
  }
  emitEvent(_constants_js__WEBPACK_IMPORTED_MODULE_3__.EVENTS.AUCTION_DEBUG, {
    type: 'ERROR',
    arguments: arguments
  });
}
function prefixLog(prefix) {
  function decorate(fn) {
    return function () {
      for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }
      fn(prefix, ...args);
    };
  }
  return {
    logError: decorate(logError),
    logWarn: decorate(logWarn),
    logMessage: decorate(logMessage),
    logInfo: decorate(logInfo)
  };
}
function decorateLog(args, prefix) {
  args = [].slice.call(args);
  var bidder = _config_js__WEBPACK_IMPORTED_MODULE_0__.config.getCurrentBidder();
  prefix && args.unshift(prefix);
  if (bidder) {
    args.unshift(label('#aaa'));
  }
  args.unshift(label('#3b88c3'));
  args.unshift('%cPrebid' + (bidder ? "%c".concat(bidder) : ''));
  return args;
  function label(color) {
    return "display: inline-block; color: #fff; background: ".concat(color, "; padding: 1px 4px; border-radius: 3px;");
  }
}
function hasConsoleLogger() {
  return consoleLogExists;
}
function debugTurnedOn() {
  return !!_config_js__WEBPACK_IMPORTED_MODULE_0__.config.getConfig('debug');
}
var createIframe = (() => {
  var DEFAULTS = {
    border: '0px',
    hspace: '0',
    vspace: '0',
    marginWidth: '0',
    marginHeight: '0',
    scrolling: 'no',
    frameBorder: '0',
    allowtransparency: 'true'
  };
  return function (doc, attrs) {
    var style = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
    var f = doc.createElement('iframe');
    Object.assign(f, Object.assign({}, DEFAULTS, attrs));
    Object.assign(f.style, style);
    return f;
  };
})();
function createInvisibleIframe() {
  return createIframe(document, {
    id: getUniqueIdentifierStr(),
    width: 0,
    height: 0,
    src: 'about:blank'
  }, {
    display: 'none',
    height: '0px',
    width: '0px',
    border: '0px'
  });
}
/*
 *   Check if a given parameter name exists in query string
 *   and if it does return the value
 */
function getParameterByName(name) {
  return parseQS(getWindowLocation().search)[name] || '';
}
/**
 * Return if the object is of the
 * given type.
 * @param {*} object to test
 * @param {String} _t type string (e.g., Array)
 * @return {Boolean} if object is of type _t
 */
function isA(object, _t) {
  return toString.call(object) === '[object ' + _t + ']';
}
function isFn(object) {
  return isA(object, tFn);
}
function isStr(object) {
  return isA(object, tStr);
}
var isArray = Array.isArray.bind(Array);
function isNumber(object) {
  return isA(object, tNumb);
}
function isPlainObject(object) {
  return isA(object, tObject);
}
function isBoolean(object) {
  return isA(object, tBoolean);
}
/**
 * Return if the object is "empty";
 * this includes falsey, no keys, or no items at indices
 * @param {*} object object to test
 * @return {Boolean} if object is empty
 */
function isEmpty(object) {
  if (!object) return true;
  if (isArray(object) || isStr(object)) {
    return !(object.length > 0);
  }
  return Object.keys(object).length <= 0;
}
/**
 * Return if string is empty, null, or undefined
 * @param str string to test
 * @returns {boolean} if string is empty
 */
function isEmptyStr(str) {
  return isStr(str) && (!str || str.length === 0);
}
/**
 * Iterate object with the function
 * falls back to es5 `forEach`
 * @param {Array|Object} object
 * @param {Function} fn - The function to execute for each element. It receives three arguments: value, key, and the original object.
 * @returns {void}
 */
function _each(object, fn) {
  if (isFn(object === null || object === void 0 ? void 0 : object.forEach)) return object.forEach(fn, this);
  Object.entries(object || {}).forEach(_ref2 => {
    var [k, v] = _ref2;
    return fn.call(this, v, k);
  });
}
function contains(a, obj) {
  return isFn(a === null || a === void 0 ? void 0 : a.includes) && a.includes(obj);
}
/**
 * Map an array or object into another array
 * given a function
 * @param {Array|Object} object
 * @param {Function} callback - The function to execute for each element. It receives three arguments: value, key, and the original object.
 * @return {Array}
 */
function _map(object, callback) {
  if (isFn(object === null || object === void 0 ? void 0 : object.map)) return object.map(callback);
  return Object.entries(object || {}).map(_ref3 => {
    var [k, v] = _ref3;
    return callback(v, k, object);
  });
}
/*
* Inserts an element(elm) as targets child, by default as first child
* @param {HTMLElement} elm
* @param {HTMLElement} [doc]
* @param {HTMLElement} [target]
* @param {Boolean} [asLastChildChild]
* @return {HTML Element}
*/
function insertElement(elm, doc, target, asLastChildChild) {
  doc = doc || document;
  var parentEl;
  if (target) {
    parentEl = doc.getElementsByTagName(target);
  } else {
    parentEl = doc.getElementsByTagName('head');
  }
  try {
    parentEl = parentEl.length ? parentEl : doc.getElementsByTagName('body');
    if (parentEl.length) {
      parentEl = parentEl[0];
      var insertBeforeEl = asLastChildChild ? null : parentEl.firstChild;
      return parentEl.insertBefore(elm, insertBeforeEl);
    }
  } catch (e) {}
}
/**
 * Returns a promise that completes when the given element triggers a 'load' or 'error' DOM event, or when
 * `timeout` milliseconds have elapsed.
 *
 * @param {HTMLElement} element
 * @param {Number} [timeout]
 * @returns {Promise}
 */
function waitForElementToLoad(element, timeout) {
  var timer = null;
  return new _utils_promise_js__WEBPACK_IMPORTED_MODULE_4__.GreedyPromise(resolve => {
    var onLoad = function () {
      element.removeEventListener('load', onLoad);
      element.removeEventListener('error', onLoad);
      if (timer != null) {
        window.clearTimeout(timer);
      }
      resolve();
    };
    element.addEventListener('load', onLoad);
    element.addEventListener('error', onLoad);
    if (timeout != null) {
      timer = window.setTimeout(onLoad, timeout);
    }
  });
}
/**
 * Inserts an image pixel with the specified `url` for cookie sync
 * @param {string} url URL string of the image pixel to load
 * @param  {function} [done] an optional exit callback, used when this usersync pixel is added during an async process
 * @param  {Number} [timeout] an optional timeout in milliseconds for the image to load before calling `done`
 */
function triggerPixel(url, done, timeout) {
  var img = new Image();
  if (done && internal.isFn(done)) {
    waitForElementToLoad(img, timeout).then(done);
  }
  img.src = url;
}
/**
 * Inserts an empty iframe with the specified `html`, primarily used for tracking purposes
 * (though could be for other purposes)
 * @param {string} htmlCode snippet of HTML code used for tracking purposes
 */
function insertHtmlIntoIframe(htmlCode) {
  if (!htmlCode) {
    return;
  }
  var iframe = createInvisibleIframe();
  internal.insertElement(iframe, document, 'body');
  (doc => {
    doc.open();
    doc.write(htmlCode);
    doc.close();
  })(iframe.contentWindow.document);
}
/**
 * Inserts empty iframe with the specified `url` for cookie sync
 * @param  {string} url URL to be requested
 * @param  {function} [done] an optional exit callback, used when this usersync pixel is added during an async process
 * @param  {Number} [timeout] an optional timeout in milliseconds for the iframe to load before calling `done`
 */
function insertUserSyncIframe(url, done, timeout) {
  var iframeHtml = internal.createTrackPixelIframeHtml(url, false, 'allow-scripts allow-same-origin');
  var div = document.createElement('div');
  div.innerHTML = iframeHtml;
  var iframe = div.firstChild;
  if (done && internal.isFn(done)) {
    waitForElementToLoad(iframe, timeout).then(done);
  }
  internal.insertElement(iframe, document, 'html', true);
}
/**
 * Creates a snippet of HTML that retrieves the specified `url`
 * @param  {string} url URL to be requested
 * @param encode
 * @return {string}     HTML snippet that contains the img src = set to `url`
 */
function createTrackPixelHtml(url) {
  var encode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : encodeURI;
  if (!url) {
    return '';
  }
  var escapedUrl = encode(url);
  var img = '<div style="position:absolute;left:0px;top:0px;visibility:hidden;">';
  img += '<img src="' + escapedUrl + '"></div>';
  return img;
}
;
/**
 * encodeURI, but preserves macros of the form '${MACRO}' (e.g. '${AUCTION_PRICE}')
 * @param url
 * @return {string}
 */
function encodeMacroURI(url) {
  var macros = Array.from(url.matchAll(/\$({[^}]+})/g)).map(match => match[1]);
  return macros.reduce((str, macro) => {
    return str.replace('$' + encodeURIComponent(macro), '$' + macro);
  }, encodeURI(url));
}
/**
 * Creates a snippet of Iframe HTML that retrieves the specified `url`
 * @param  {string} url plain URL to be requested
 * @param  {string} encodeUri boolean if URL should be encoded before inserted. Defaults to true
 * @param  {string} sandbox string if provided the sandbox attribute will be included with the given value
 * @return {string}     HTML snippet that contains the iframe src = set to `url`
 */
function createTrackPixelIframeHtml(url) {
  var encodeUri = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : true;
  var sandbox = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : '';
  if (!url) {
    return '';
  }
  if (encodeUri) {
    url = encodeURI(url);
  }
  if (sandbox) {
    sandbox = "sandbox=\"".concat(sandbox, "\"");
  }
  return "<iframe ".concat(sandbox, " id=\"").concat(getUniqueIdentifierStr(), "\"\n      frameborder=\"0\"\n      allowtransparency=\"true\"\n      marginheight=\"0\" marginwidth=\"0\"\n      width=\"0\" hspace=\"0\" vspace=\"0\" height=\"0\"\n      style=\"height:0px;width:0px;display:none;\"\n      scrolling=\"no\"\n      src=\"").concat(url, "\">\n    </iframe>");
}
function uniques(value, index, arry) {
  return arry.indexOf(value) === index;
}
function flatten(a, b) {
  return a.concat(b);
}
function getBidRequest(id, bidderRequests) {
  if (!id) {
    return;
  }
  return bidderRequests.flatMap(br => br.bids).find(bid => ['bidId', 'adId', 'bid_id'].some(prop => bid[prop] === id));
}
function getValue(obj, key) {
  return obj[key];
}
function getBidderCodes() {
  var adUnits = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : pbjsInstance.adUnits;
  // this could memoize adUnits
  return adUnits.map(unit => unit.bids.map(bid => bid.bidder).reduce(flatten, [])).reduce(flatten, []).filter(bidder => typeof bidder !== 'undefined').filter(uniques);
}
function isGptPubadsDefined() {
  if (window.googletag && isFn(window.googletag.pubads) && isFn(window.googletag.pubads().getSlots)) {
    return true;
  }
}
function isApnGetTagDefined() {
  if (window.apntag && isFn(window.apntag.getTag)) {
    return true;
  }
}
var sortByHighestCpm = (a, b) => {
  return b.cpm - a.cpm;
};
/**
 * Fisher–Yates shuffle
 * http://stackoverflow.com/a/6274398
 * https://bost.ocks.org/mike/shuffle/
 * istanbul ignore next
 */
function shuffle(array) {
  var counter = array.length;
  // while there are elements in the array
  while (counter > 0) {
    // pick a random index
    var index = Math.floor(Math.random() * counter);
    // decrease counter by 1
    counter--;
    // and swap the last element with it
    var temp = array[counter];
    array[counter] = array[index];
    array[index] = temp;
  }
  return array;
}
function deepClone(obj) {
  return (0,klona_json__WEBPACK_IMPORTED_MODULE_1__.klona)(obj) || {};
}
function inIframe() {
  try {
    return internal.getWindowSelf() !== internal.getWindowTop();
  } catch (e) {
    return true;
  }
}
/**
 * https://iabtechlab.com/wp-content/uploads/2016/03/SafeFrames_v1.1_final.pdf
 */
function isSafeFrameWindow() {
  if (!inIframe()) {
    return false;
  }
  var ws = internal.getWindowSelf();
  return !!(ws.$sf && ws.$sf.ext);
}
/**
 * Returns the result of calling the function $sf.ext.geom() if it exists
 * @see https://iabtechlab.com/wp-content/uploads/2016/03/SafeFrames_v1.1_final.pdf — 5.4 Function $sf.ext.geom
 * @returns {Object | undefined} geometric information about the container
 */
function getSafeframeGeometry() {
  try {
    var ws = getWindowSelf();
    return typeof ws.$sf.ext.geom === 'function' ? ws.$sf.ext.geom() : undefined;
  } catch (e) {
    logError('Error getting SafeFrame geometry', e);
    return undefined;
  }
}
function isSafariBrowser() {
  return /^((?!chrome|android|crios|fxios).)*safari/i.test(navigator.userAgent);
}
function replaceMacros(str, subs) {
  if (!str) return;
  return Object.entries(subs).reduce((str, _ref4) => {
    var [key, val] = _ref4;
    return str.replace(new RegExp('\\$\\{' + key + '\\}', 'g'), val || '');
  }, str);
}
function replaceAuctionPrice(str, cpm) {
  return replaceMacros(str, {
    AUCTION_PRICE: cpm
  });
}
function replaceClickThrough(str, clicktag) {
  if (!str || !clicktag || typeof clicktag !== 'string') return;
  return str.replace(/\${CLICKTHROUGH}/g, clicktag);
}
function timestamp() {
  return new Date().getTime();
}
/**
 * The returned value represents the time elapsed since the time origin. @see https://developer.mozilla.org/en-US/docs/Web/API/Performance/now
 * @returns {number}
 */
function getPerformanceNow() {
  return window.performance && window.performance.now && window.performance.now() || 0;
}
/**
 * Retuns the difference between `timing.domLoading` and `timing.navigationStart`.
 * This function uses the deprecated `Performance.timing` API and should be removed in future.
 * It has not been updated yet because it is still used in some modules.
 * @deprecated
 * @param {Window} w The window object used to perform the api call. default to window.self
 * @returns {number}
 */
function getDomLoadingDuration(w) {
  var _w$performance;
  var domLoadingDuration = -1;
  w = w || getWindowSelf();
  var performance = w.performance;
  if ((_w$performance = w.performance) !== null && _w$performance !== void 0 && _w$performance.timing) {
    if (w.performance.timing.navigationStart > 0) {
      var val = performance.timing.domLoading - performance.timing.navigationStart;
      if (val > 0) {
        domLoadingDuration = val;
      }
    }
  }
  return domLoadingDuration;
}
/**
 * When the deviceAccess flag config option is false, no cookies should be read or set
 * @returns {boolean}
 */
function hasDeviceAccess() {
  return _config_js__WEBPACK_IMPORTED_MODULE_0__.config.getConfig('deviceAccess') !== false;
}
/**
 * @returns {(boolean|undefined)}
 */
function checkCookieSupport() {
  // eslint-disable-next-line prebid/no-member
  if (window.navigator.cookieEnabled || !!document.cookie.length) {
    return true;
  }
}
/**
 * Given a function, return a function which only executes the original after
 * it's been called numRequiredCalls times.
 *
 * Note that the arguments from the previous calls will *not* be forwarded to the original function.
 * Only the final call's arguments matter.
 *
 * @param {function} func The function which should be executed, once the returned function has been executed
 *   numRequiredCalls times.
 * @param {number} numRequiredCalls The number of times which the returned function needs to be called before
 *   func is.
 */
function delayExecution(func, numRequiredCalls) {
  if (numRequiredCalls < 1) {
    throw new Error("numRequiredCalls must be a positive number. Got ".concat(numRequiredCalls));
  }
  var numCalls = 0;
  return function () {
    numCalls++;
    if (numCalls === numRequiredCalls) {
      func.apply(this, arguments);
    }
  };
}
/**
 * https://stackoverflow.com/a/34890276/428704
 * @param {Array} xs
 * @param {string} key
 * @returns {Object} {${key_value}: ${groupByArray}, key_value: {groupByArray}}
 */
function groupBy(xs, key) {
  return xs.reduce(function (rv, x) {
    (rv[x[key]] = rv[x[key]] || []).push(x);
    return rv;
  }, {});
}
/**
 * Build an object consisting of only defined parameters to avoid creating an
 * object with defined keys and undefined values.
 * @param {Object} object The object to pick defined params out of
 * @param {string[]} params An array of strings representing properties to look for in the object
 * @returns {Object} An object containing all the specified values that are defined
 */
function getDefinedParams(object, params) {
  return params.filter(param => object[param]).reduce((bid, param) => Object.assign(bid, {
    [param]: object[param]
  }), {});
}
/**
 * @typedef {Object} MediaTypes
 * @property {Object} banner banner configuration
 * @property {Object} native native configuration
 * @property {Object} video video configuration
 */
/**
 * Validates an adunit's `mediaTypes` parameter
 * @param {MediaTypes} mediaTypes mediaTypes parameter to validate
 * @return {boolean} If object is valid
 */
function isValidMediaTypes(mediaTypes) {
  var SUPPORTED_MEDIA_TYPES = ['banner', 'native', 'video'];
  var SUPPORTED_STREAM_TYPES = ['instream', 'outstream', 'adpod'];
  var types = Object.keys(mediaTypes);
  if (!types.every(type => (0,_polyfill_js__WEBPACK_IMPORTED_MODULE_2__.includes)(SUPPORTED_MEDIA_TYPES, type))) {
    return false;
  }
  if ( true && mediaTypes.video && mediaTypes.video.context) {
    return (0,_polyfill_js__WEBPACK_IMPORTED_MODULE_2__.includes)(SUPPORTED_STREAM_TYPES, mediaTypes.video.context);
  }
  return true;
}
/**
 * Returns user configured bidder params from adunit
 * @param {Object} adUnits
 * @param {string} adUnitCode code
 * @param {string} bidder code
 * @return {Array} user configured param for the given bidder adunit configuration
 */
function getUserConfiguredParams(adUnits, adUnitCode, bidder) {
  return adUnits.filter(adUnit => adUnit.code === adUnitCode).flatMap(adUnit => adUnit.bids).filter(bidderData => bidderData.bidder === bidder).map(bidderData => bidderData.params || {});
}
/**
 * Returns Do Not Track state
 */
function getDNT() {
  return navigator.doNotTrack === '1' || window.doNotTrack === '1' || navigator.msDoNotTrack === '1' || navigator.doNotTrack === 'yes';
}
var compareCodeAndSlot = (slot, adUnitCode) => slot.getAdUnitPath() === adUnitCode || slot.getSlotElementId() === adUnitCode;
/**
 * Returns filter function to match adUnitCode in slot
 * @param {Object} slot GoogleTag slot
 * @return {function} filter function
 */
function isAdUnitCodeMatchingSlot(slot) {
  return adUnitCode => compareCodeAndSlot(slot, adUnitCode);
}
/**
 * Constructs warning message for when unsupported bidders are dropped from an adunit
 * @param {Object} adUnit ad unit from which the bidder is being dropped
 * @param {string} bidder bidder code that is not compatible with the adUnit
 * @return {string} warning message to display when condition is met
 */
function unsupportedBidderMessage(adUnit, bidder) {
  var mediaType = Object.keys(adUnit.mediaTypes || {
    'banner': 'banner'
  }).join(', ');
  return "\n    ".concat(adUnit.code, " is a ").concat(mediaType, " ad unit\n    containing bidders that don't support ").concat(mediaType, ": ").concat(bidder, ".\n    This bidder won't fetch demand.\n  ");
}
/**
 * Checks input is integer or not
 * https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Number/isInteger
 * @param {*} value
 */
var isInteger = Number.isInteger.bind(Number);
/**
 * Returns a new object with undefined properties removed from given object
 * @param obj the object to clean
 */
function cleanObj(obj) {
  return Object.fromEntries(Object.entries(obj).filter(_ref5 => {
    var [_, v] = _ref5;
    return typeof v !== 'undefined';
  }));
}
/**
 * Create a new object with selected properties.  Also allows property renaming and transform functions.
 * @param obj the original object
 * @param properties An array of desired properties
 */
function pick(obj, properties) {
  if (typeof obj !== 'object') {
    return {};
  }
  return properties.reduce((newObj, prop, i) => {
    if (typeof prop === 'function') {
      return newObj;
    }
    var newProp = prop;
    var match = prop.match(/^(.+?)\sas\s(.+?)$/i);
    if (match) {
      prop = match[1];
      newProp = match[2];
    }
    var value = obj[prop];
    if (typeof properties[i + 1] === 'function') {
      value = properties[i + 1](value, newObj);
    }
    if (typeof value !== 'undefined') {
      newObj[newProp] = value;
    }
    return newObj;
  }, {});
}
function isArrayOfNums(val, size) {
  return isArray(val) && (size ? val.length === size : true) && val.every(v => isInteger(v));
}
function parseQS(query) {
  return !query ? {} : query.replace(/^\?/, '').split('&').reduce((acc, criteria) => {
    var [k, v] = criteria.split('=');
    if (/\[\]$/.test(k)) {
      k = k.replace('[]', '');
      acc[k] = acc[k] || [];
      acc[k].push(v);
    } else {
      acc[k] = v || '';
    }
    return acc;
  }, {});
}
function formatQS(query) {
  return Object.keys(query).map(k => Array.isArray(query[k]) ? query[k].map(v => "".concat(k, "[]=").concat(v)).join('&') : "".concat(k, "=").concat(query[k])).join('&');
}
function parseUrl(url, options) {
  var parsed = document.createElement('a');
  if (options && 'noDecodeWholeURL' in options && options.noDecodeWholeURL) {
    parsed.href = url;
  } else {
    parsed.href = decodeURIComponent(url);
  }
  // in window.location 'search' is string, not object
  var qsAsString = options && 'decodeSearchAsString' in options && options.decodeSearchAsString;
  return {
    href: parsed.href,
    protocol: (parsed.protocol || '').replace(/:$/, ''),
    hostname: parsed.hostname,
    port: +parsed.port,
    pathname: parsed.pathname.replace(/^(?!\/)/, '/'),
    search: qsAsString ? parsed.search : internal.parseQS(parsed.search || ''),
    hash: (parsed.hash || '').replace(/^#/, ''),
    host: parsed.host || window.location.host
  };
}
function buildUrl(obj) {
  return (obj.protocol || 'http') + '://' + (obj.host || obj.hostname + (obj.port ? ":".concat(obj.port) : '')) + (obj.pathname || '') + (obj.search ? "?".concat(internal.formatQS(obj.search || '')) : '') + (obj.hash ? "#".concat(obj.hash) : '');
}
/**
 * This function deeply compares two objects checking for their equivalence.
 * @param {Object} obj1
 * @param {Object} obj2
 * @param {Object} [options] - Options for comparison.
 * @param {boolean} [options.checkTypes=false] - If set, two objects with identical properties but different constructors will *not* be considered equivalent.
 * @returns {boolean} - Returns `true` if the objects are equivalent, `false` otherwise.
 */
function deepEqual(obj1, obj2) {
  var {
    checkTypes = false
  } = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : {};
  if (obj1 === obj2) return true;else if (typeof obj1 === 'object' && obj1 !== null && typeof obj2 === 'object' && obj2 !== null && (!checkTypes || obj1.constructor === obj2.constructor)) {
    var props1 = Object.keys(obj1);
    if (props1.length !== Object.keys(obj2).length) return false;
    for (var prop of props1) {
      if (obj2.hasOwnProperty(prop)) {
        if (!deepEqual(obj1[prop], obj2[prop], {
          checkTypes
        })) {
          return false;
        }
      } else {
        return false;
      }
    }
    return true;
  } else {
    return false;
  }
}
function mergeDeep(target) {
  for (var _len2 = arguments.length, sources = new Array(_len2 > 1 ? _len2 - 1 : 0), _key2 = 1; _key2 < _len2; _key2++) {
    sources[_key2 - 1] = arguments[_key2];
  }
  if (!sources.length) return target;
  var source = sources.shift();
  if (isPlainObject(target) && isPlainObject(source)) {
    var _loop = function (key) {
      if (isPlainObject(source[key])) {
        if (!target[key]) Object.assign(target, {
          [key]: {}
        });
        mergeDeep(target[key], source[key]);
      } else if (isArray(source[key])) {
        if (!target[key]) {
          Object.assign(target, {
            [key]: [...source[key]]
          });
        } else if (isArray(target[key])) {
          source[key].forEach(obj => {
            var addItFlag = 1;
            for (var i = 0; i < target[key].length; i++) {
              if (deepEqual(target[key][i], obj)) {
                addItFlag = 0;
                break;
              }
            }
            if (addItFlag) {
              target[key].push(obj);
            }
          });
        }
      } else {
        Object.assign(target, {
          [key]: source[key]
        });
      }
    };
    for (var key in source) {
      _loop(key);
    }
  }
  return mergeDeep(target, ...sources);
}
/**
 * returns a hash of a string using a fast algorithm
 * source: https://stackoverflow.com/a/52171480/845390
 * @param str
 * @param seed (optional)
 * @returns {string}
 */
function cyrb53Hash(str) {
  var seed = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 0;
  // IE doesn't support imul
  // https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/imul#Polyfill
  var imul = function (opA, opB) {
    if (isFn(Math.imul)) {
      return Math.imul(opA, opB);
    } else {
      opB |= 0; // ensure that opB is an integer. opA will automatically be coerced.
      // floating points give us 53 bits of precision to work with plus 1 sign bit
      // automatically handled for our convienence:
      // 1. 0x003fffff /*opA & 0x000fffff*/ * 0x7fffffff /*opB*/ = 0x1fffff7fc00001
      //    0x1fffff7fc00001 < Number.MAX_SAFE_INTEGER /*0x1fffffffffffff*/
      var result = (opA & 0x003fffff) * opB;
      // 2. We can remove an integer coersion from the statement above because:
      //    0x1fffff7fc00001 + 0xffc00000 = 0x1fffffff800001
      //    0x1fffffff800001 < Number.MAX_SAFE_INTEGER /*0x1fffffffffffff*/
      if (opA & 0xffc00000) result += (opA & 0xffc00000) * opB | 0;
      return result | 0;
    }
  };
  var h1 = 0xdeadbeef ^ seed;
  var h2 = 0x41c6ce57 ^ seed;
  for (var i = 0, ch; i < str.length; i++) {
    ch = str.charCodeAt(i);
    h1 = imul(h1 ^ ch, 2654435761);
    h2 = imul(h2 ^ ch, 1597334677);
  }
  h1 = imul(h1 ^ h1 >>> 16, 2246822507) ^ imul(h2 ^ h2 >>> 13, 3266489909);
  h2 = imul(h2 ^ h2 >>> 16, 2246822507) ^ imul(h1 ^ h1 >>> 13, 3266489909);
  return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString();
}
/**
 * returns the result of `JSON.parse(data)`, or undefined if that throws an error.
 * @param data
 * @returns {any}
 */
function safeJSONParse(data) {
  try {
    return JSON.parse(data);
  } catch (e) {}
}
function safeJSONEncode(data) {
  try {
    return JSON.stringify(data);
  } catch (e) {
    return '';
  }
}
/**
 * Returns a memoized version of `fn`.
 *
 * @param fn
 * @param key cache key generator, invoked with the same arguments passed to `fn`.
 *        By default, the first argument is used as key.
 * @return {function(): any}
 */
function memoize(fn) {
  var key = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : function (arg) {
    return arg;
  };
  var cache = new Map();
  var memoized = function () {
    var cacheKey = key.apply(this, arguments);
    if (!cache.has(cacheKey)) {
      cache.set(cacheKey, fn.apply(this, arguments));
    }
    return cache.get(cacheKey);
  };
  memoized.clear = cache.clear.bind(cache);
  return memoized;
}
/**
 * Returns a Unix timestamp for given time value and unit.
 * @param {number} timeValue numeric value, defaults to 0 (which means now)
 * @param {string} timeUnit defaults to days (or 'd'), use 'm' for minutes. Any parameter that isn't 'd' or 'm' will return Date.now().
 * @returns {number}
 */
function getUnixTimestampFromNow() {
  var timeValue = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
  var timeUnit = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : 'd';
  var acceptableUnits = ['m', 'd'];
  if (acceptableUnits.indexOf(timeUnit) < 0) {
    return Date.now();
  }
  var multiplication = timeValue / (timeUnit === 'm' ? 1440 : 1);
  return Date.now() + (timeValue && timeValue > 0 ? 1000 * 60 * 60 * 24 * multiplication : 0);
}
/**
 * Converts given object into an array, so {key: 1, anotherKey: 'fred', third: ['fred']} is turned
 * into [{key: 1}, {anotherKey: 'fred'}, {third: ['fred']}]
 * @param {Object} obj the object
 * @returns {Array}
 */
function convertObjectToArray(obj) {
  return Object.keys(obj).map(key => {
    return {
      [key]: obj[key]
    };
  });
}
/**
 * Sets dataset attributes on a script
 * @param {HTMLScriptElement} script
 * @param {object} attributes
 */
function setScriptAttributes(script, attributes) {
  Object.entries(attributes).forEach(_ref6 => {
    var [k, v] = _ref6;
    return script.setAttribute(k, v);
  });
}
/**
 * Perform a binary search for `el` on an ordered array `arr`.
 *
 * @returns the lowest nonnegative integer I that satisfies:
 *   key(arr[i]) >= key(el) for each i between I and arr.length
 *
 *   (if one or more matches are found for `el`, returns the index of the first;
 *   if the element is not found, return the index of the first element that's greater;
 *   if no greater element exists, return `arr.length`)
 */
function binarySearch(arr, el) {
  var key = arguments.length > 2 && arguments[2] !== undefined ? arguments[2] : el => el;
  var left = 0;
  var right = arr.length && arr.length - 1;
  var target = key(el);
  while (right - left > 1) {
    var middle = left + Math.round((right - left) / 2);
    if (target > key(arr[middle])) {
      left = middle;
    } else {
      right = middle;
    }
  }
  while (arr.length > left && target > key(arr[left])) {
    left++;
  }
  return left;
}
/**
 * Checks if an object has non-serializable properties.
 * Non-serializable properties are functions and RegExp objects.
 *
 * @param {Object} obj - The object to check.
 * @param {Set} checkedObjects - A set of properties that have already been checked.
 * @returns {boolean} - Returns true if the object has non-serializable properties, false otherwise.
 */
function hasNonSerializableProperty(obj) {
  var checkedObjects = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : new Set();
  for (var key in obj) {
    var value = obj[key];
    var type = typeof value;
    if (value === undefined || type === 'function' || type === 'symbol' || value instanceof RegExp || value instanceof Map || value instanceof Set || value instanceof Date || value !== null && type === 'object' && value.hasOwnProperty('toJSON')) {
      return true;
    }
    if (value !== null && type === 'object' && value.constructor === Object) {
      if (checkedObjects.has(value)) {
        // circular reference, means we have a non-serializable property
        return true;
      }
      checkedObjects.add(value);
      if (hasNonSerializableProperty(value, checkedObjects)) {
        return true;
      }
    }
  }
  return false;
}
/**
 * Returns the value of a nested property in an array of objects.
 *
 * @param {Array} collection - Array of objects.
 * @param {String} key - Key of nested property.
 * @returns {any, undefined} - Value of nested property.
 */
function setOnAny(collection, key) {
  for (var i = 0, result; i < collection.length; i++) {
    result = (0,dlv_index_js__WEBPACK_IMPORTED_MODULE_6__["default"])(collection[i], key);
    if (result) {
      return result;
    }
  }
  return undefined;
}
function extractDomainFromHost(pageHost) {
  var domain = null;
  try {
    var domains = /[-\w]+\.([-\w]+|[-\w]{3,}|[-\w]{1,3}\.[-\w]{2})$/i.exec(pageHost);
    if (domains != null && domains.length > 0) {
      domain = domains[0];
      for (var i = 1; i < domains.length; i++) {
        if (domains[i].length > domain.length) {
          domain = domains[i];
        }
      }
    }
  } catch (e) {
    domain = null;
  }
  return domain;
}
function triggerNurlWithCpm(bid, cpm) {
  if (isStr(bid.nurl) && bid.nurl !== '') {
    bid.nurl = bid.nurl.replace(/\${AUCTION_PRICE}/, cpm);
    triggerPixel(bid.nurl);
  }
}

/***/ }),

/***/ "../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils/promise.js":
/*!**********************************************************************************************************************!*\
  !*** ../node_modules/.pnpm/prebid.js@9.27.0_ejs@3.1.10_handlebars@4.7.8/node_modules/prebid.js/src/utils/promise.js ***!
  \**********************************************************************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   GreedyPromise: () => (/* binding */ GreedyPromise),
/* harmony export */   defer: () => (/* binding */ defer)
/* harmony export */ });
function _classPrivateFieldInitSpec(e, t, a) {
  _checkPrivateRedeclaration(e, t), t.set(e, a);
}
function _checkPrivateRedeclaration(e, t) {
  if (t.has(e)) throw new TypeError("Cannot initialize the same private elements twice on an object");
}
function _classPrivateFieldGet(s, a) {
  return s.get(_assertClassBrand(s, a));
}
function _classPrivateFieldSet(s, a, r) {
  return s.set(_assertClassBrand(s, a), r), r;
}
function _assertClassBrand(e, t, n) {
  if ("function" == typeof e ? e === t : e.has(t)) return arguments.length < 3 ? t : n;
  throw new TypeError("Private element is not present on this object");
}
var SUCCESS = 0;
var FAIL = 1;
/**
 * A version of Promise that runs callbacks synchronously when it can (i.e. after it's been fulfilled or rejected).
 */
var _result = /*#__PURE__*/new WeakMap();
var _callbacks = /*#__PURE__*/new WeakMap();
class GreedyPromise {
  /**
   * Convenience wrapper for setTimeout; takes care of returning an already fulfilled GreedyPromise when the delay is zero.
   *
   * @param {Number} delayMs delay in milliseconds
   * @returns {GreedyPromise} a promise that resolves (to undefined) in `delayMs` milliseconds
   */
  static timeout() {
    var delayMs = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : 0;
    return new GreedyPromise(resolve => {
      delayMs === 0 ? resolve() : setTimeout(resolve, delayMs);
    });
  }
  constructor(resolver) {
    _classPrivateFieldInitSpec(this, _result, void 0);
    _classPrivateFieldInitSpec(this, _callbacks, void 0);
    if (typeof resolver !== 'function') {
      throw new Error('resolver not a function');
    }
    var result = [];
    var callbacks = [];
    var [resolve, reject] = [SUCCESS, FAIL].map(type => {
      return function (value) {
        if (type === SUCCESS && typeof (value === null || value === void 0 ? void 0 : value.then) === 'function') {
          value.then(resolve, reject);
        } else if (!result.length) {
          result.push(type, value);
          while (callbacks.length) callbacks.shift()();
        }
      };
    });
    try {
      resolver(resolve, reject);
    } catch (e) {
      reject(e);
    }
    _classPrivateFieldSet(_result, this, result);
    _classPrivateFieldSet(_callbacks, this, callbacks);
  }
  then(onSuccess, onError) {
    var result = _classPrivateFieldGet(_result, this);
    return new this.constructor((resolve, reject) => {
      var continuation = () => {
        var value = result[1];
        var [handler, resolveFn] = result[0] === SUCCESS ? [onSuccess, resolve] : [onError, reject];
        if (typeof handler === 'function') {
          try {
            value = handler(value);
          } catch (e) {
            reject(e);
            return;
          }
          resolveFn = resolve;
        }
        resolveFn(value);
      };
      result.length ? continuation() : _classPrivateFieldGet(_callbacks, this).push(continuation);
    });
  }
  catch(onError) {
    return this.then(null, onError);
  }
  finally(onFinally) {
    var val;
    return this.then(v => {
      val = v;
      return onFinally();
    }, e => {
      val = this.constructor.reject(e);
      return onFinally();
    }).then(() => val);
  }
  static race(promises) {
    return new this((resolve, reject) => {
      _assertClassBrand(GreedyPromise, this, _collect).call(this, promises, (success, result) => success ? resolve(result) : reject(result));
    });
  }
  static all(promises) {
    return new this((resolve, reject) => {
      var res = [];
      _assertClassBrand(GreedyPromise, this, _collect).call(this, promises, (success, val, i) => success ? res[i] = val : reject(val), () => resolve(res));
    });
  }
  static allSettled(promises) {
    return new this(resolve => {
      var res = [];
      _assertClassBrand(GreedyPromise, this, _collect).call(this, promises, (success, val, i) => res[i] = success ? {
        status: 'fulfilled',
        value: val
      } : {
        status: 'rejected',
        reason: val
      }, () => resolve(res));
    });
  }
  static resolve(value) {
    return new this(resolve => resolve(value));
  }
  static reject(error) {
    return new this((resolve, reject) => reject(error));
  }
}
/**
 * @returns a {promise, resolve, reject} trio where `promise` is resolved by calling `resolve` or `reject`.
 */
function _collect(promises, collector, done) {
  var cnt = promises.length;
  function clt() {
    collector.apply(this, arguments);
    if (--cnt <= 0 && done) done();
  }
  promises.length === 0 && done ? done() : promises.forEach((p, i) => this.resolve(p).then(val => clt(true, val, i), err => clt(false, err, i)));
}
function defer() {
  var {
    promiseFactory = resolver => new GreedyPromise(resolver)
  } = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {};
  function invoker(delegate) {
    return val => delegate(val);
  }
  var resolveFn, rejectFn;
  return {
    promise: promiseFactory((resolve, reject) => {
      resolveFn = resolve;
      rejectFn = reject;
    }),
    resolve: invoker(resolveFn),
    reject: invoker(rejectFn)
  };
}

/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4udmVuZG9ycy1ub2RlX21vZHVsZXNfcG5wbV9wcmViaWRfanNfOV8yN18wX2Vqc18zXzFfMTBfaGFuZGxlYmFyc180XzdfOF9ub2RlX21vZHVsZXNfcHJlYmlkX2pzLTMxOTNhMy5jb21tZXJjaWFsLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7O0FBQStDO0FBQy9DLFNBQVNDLGVBQWVBLENBQUNDLENBQUMsRUFBRUMsQ0FBQyxFQUFFQyxDQUFDLEVBQUU7RUFDOUIsT0FBTyxDQUFDRCxDQUFDLEdBQUdILDZEQUFhLENBQUNHLENBQUMsQ0FBQyxLQUFLRCxDQUFDLEdBQUdHLE1BQU0sQ0FBQ0MsY0FBYyxDQUFDSixDQUFDLEVBQUVDLENBQUMsRUFBRTtJQUM3REksS0FBSyxFQUFFSCxDQUFDO0lBQ1JJLFVBQVUsRUFBRSxDQUFDLENBQUM7SUFDZEMsWUFBWSxFQUFFLENBQUMsQ0FBQztJQUNoQkMsUUFBUSxFQUFFLENBQUM7RUFDZixDQUFDLENBQUMsR0FBR1IsQ0FBQyxDQUFDQyxDQUFDLENBQUMsR0FBR0MsQ0FBQyxFQUFFRixDQUFDO0FBQ3BCOzs7Ozs7Ozs7Ozs7Ozs7O0FDUmtDO0FBQ2xDLFNBQVNXLFdBQVdBLENBQUNULENBQUMsRUFBRUQsQ0FBQyxFQUFFO0VBQ3ZCLElBQUksUUFBUSxJQUFJUyxzREFBTyxDQUFDUixDQUFDLENBQUMsSUFBSSxDQUFDQSxDQUFDLEVBQzVCLE9BQU9BLENBQUM7RUFDWixJQUFJRixDQUFDLEdBQUdFLENBQUMsQ0FBQ1UsTUFBTSxDQUFDRCxXQUFXLENBQUM7RUFDN0IsSUFBSSxLQUFLLENBQUMsS0FBS1gsQ0FBQyxFQUFFO0lBQ2QsSUFBSWEsQ0FBQyxHQUFHYixDQUFDLENBQUNjLElBQUksQ0FBQ1osQ0FBQyxFQUFFRCxDQUFDLElBQUksU0FBUyxDQUFDO0lBQ2pDLElBQUksUUFBUSxJQUFJUyxzREFBTyxDQUFDRyxDQUFDLENBQUMsRUFDdEIsT0FBT0EsQ0FBQztJQUNaLE1BQU0sSUFBSUUsU0FBUyxDQUFDLDhDQUE4QyxDQUFDO0VBQ3ZFO0VBQ0EsT0FBTyxDQUFDLFFBQVEsS0FBS2QsQ0FBQyxHQUFHZSxNQUFNLEdBQUdDLE1BQU0sRUFBRWYsQ0FBQyxDQUFDO0FBQ2hEOzs7Ozs7Ozs7Ozs7Ozs7OztBQ1prQztBQUNTO0FBQzNDLFNBQVNKLGFBQWFBLENBQUNJLENBQUMsRUFBRTtFQUN0QixJQUFJVyxDQUFDLEdBQUdGLDJEQUFXLENBQUNULENBQUMsRUFBRSxRQUFRLENBQUM7RUFDaEMsT0FBTyxRQUFRLElBQUlRLHNEQUFPLENBQUNHLENBQUMsQ0FBQyxHQUFHQSxDQUFDLEdBQUdBLENBQUMsR0FBRyxFQUFFO0FBQzlDOzs7Ozs7Ozs7Ozs7Ozs7QUNMQSxTQUFTSCxPQUFPQSxDQUFDUSxDQUFDLEVBQUU7RUFDaEIseUJBQXlCOztFQUN6QixPQUFPUixPQUFPLEdBQUcsVUFBVSxJQUFJLE9BQU9FLE1BQU0sSUFBSSxRQUFRLElBQUksT0FBT0EsTUFBTSxDQUFDTyxRQUFRLEdBQUcsVUFBVUQsQ0FBQyxFQUFFO0lBQzlGLE9BQU8sT0FBT0EsQ0FBQztFQUNuQixDQUFDLEdBQUcsVUFBVUEsQ0FBQyxFQUFFO0lBQ2IsT0FBT0EsQ0FBQyxJQUFJLFVBQVUsSUFBSSxPQUFPTixNQUFNLElBQUlNLENBQUMsQ0FBQ0UsV0FBVyxLQUFLUixNQUFNLElBQUlNLENBQUMsS0FBS04sTUFBTSxDQUFDUyxTQUFTLEdBQUcsUUFBUSxHQUFHLE9BQU9ILENBQUM7RUFDdkgsQ0FBQyxFQUFFUixPQUFPLENBQUNRLENBQUMsQ0FBQztBQUNqQjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQcUM7QUFDRTtBQUN2QyxJQUFJTSxTQUFTLEdBQUdyQixNQUFNLENBQUNDLGNBQWM7QUFDckMsSUFBSXFCLGVBQWUsR0FBR0EsQ0FBQ0MsR0FBRyxFQUFFQyxHQUFHLEVBQUV0QixLQUFLLEtBQUtzQixHQUFHLElBQUlELEdBQUcsR0FBR0YsU0FBUyxDQUFDRSxHQUFHLEVBQUVDLEdBQUcsRUFBRTtFQUFFckIsVUFBVSxFQUFFLElBQUk7RUFBRUMsWUFBWSxFQUFFLElBQUk7RUFBRUMsUUFBUSxFQUFFLElBQUk7RUFBRUg7QUFBTSxDQUFDLENBQUMsR0FBR3FCLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDLEdBQUd0QixLQUFLO0FBQy9KLElBQUl1QixhQUFhLEdBQUdBLENBQUNGLEdBQUcsRUFBRUMsR0FBRyxFQUFFdEIsS0FBSyxLQUFLb0IsZUFBZSxDQUFDQyxHQUFHLEVBQUUsT0FBT0MsR0FBRyxLQUFLLFFBQVEsR0FBR0EsR0FBRyxHQUFHLEVBQUUsR0FBR0EsR0FBRyxFQUFFdEIsS0FBSyxDQUFDO0FBQzlHLE1BQU13QixFQUFFLENBQUM7RUFDTFQsV0FBV0EsQ0FBQVUsSUFBQSxFQUFvSztJQUFBLElBQW5LO01BQUVDLGNBQWM7TUFBRUMsa0JBQWtCO01BQUVDLGFBQWE7TUFBRUMsbUJBQW1CO01BQUVDLGtCQUFrQjtNQUFFQyxLQUFLO01BQUVDLFdBQVc7TUFBRUMsV0FBVztNQUFFQyxlQUFlO01BQUVDO0lBQWdCLENBQUMsR0FBQVYsSUFBQTtJQUN6S0YsYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7SUFDNUJBLGFBQWEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDO0lBQzdCLElBQUksQ0FBQ2EsS0FBSyxHQUFHbkIsa0RBQVEsQ0FBQztNQUNsQlMsY0FBYztNQUNkQyxrQkFBa0I7TUFDbEJFLG1CQUFtQjtNQUNuQkMsa0JBQWtCO01BQ2xCQyxLQUFLO01BQ0xDLFdBQVc7TUFDWEU7SUFDSixDQUFDLENBQUM7SUFDRixJQUFJLENBQUNHLE1BQU0sR0FBR25CLG9EQUFTLENBQUM7TUFDcEJVLGFBQWE7TUFDYkssV0FBVztNQUNYRTtJQUNKLENBQUMsQ0FBQztFQUNOO0VBQ0E7RUFDQSxJQUFJRyxnQkFBZ0JBLENBQUEsRUFBRztJQUNuQixPQUFPLElBQUksQ0FBQ0YsS0FBSyxDQUFDRSxnQkFBZ0I7RUFDdEM7RUFDQSxJQUFJQyxpQkFBaUJBLENBQUEsRUFBRztJQUNwQixPQUFPLElBQUksQ0FBQ0gsS0FBSyxDQUFDRyxpQkFBaUI7RUFDdkM7RUFDQSxJQUFJQyxZQUFZQSxDQUFBLEVBQUc7SUFDZixPQUFPLElBQUksQ0FBQ0osS0FBSyxDQUFDSSxZQUFZO0VBQ2xDO0VBQ0EsSUFBSUMsZUFBZUEsQ0FBQSxFQUFHO0lBQ2xCLE9BQU8sSUFBSSxDQUFDTCxLQUFLLENBQUNLLGVBQWU7RUFDckM7RUFDQTtFQUNBLElBQUlDLHNCQUFzQkEsQ0FBQSxFQUFHO0lBQ3pCLE9BQU8sSUFBSSxDQUFDTCxNQUFNLENBQUNLLHNCQUFzQjtFQUM3QztFQUNBLElBQUlDLHdCQUF3QkEsQ0FBQSxFQUFHO0lBQzNCLE9BQU8sSUFBSSxDQUFDTixNQUFNLENBQUNNLHdCQUF3QjtFQUMvQztFQUNBLElBQUlDLFlBQVlBLENBQUEsRUFBRztJQUNmLE9BQU8sSUFBSSxDQUFDUCxNQUFNLENBQUNPLFlBQVk7RUFDbkM7QUFDSjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0NzQztBQUN0QyxJQUFNM0IsUUFBUSxHQUFHUSxJQUFBLElBQXFJO0VBQUEsSUFBcEk7SUFBRU8sV0FBVyxHQUFHLEdBQUc7SUFBRUQsS0FBSztJQUFFRyxlQUFlO0lBQUVSLGNBQWM7SUFBRUksa0JBQWtCO0lBQUVELG1CQUFtQjtJQUFFRixrQkFBa0IsR0FBRztFQUFHLENBQUMsR0FBQUYsSUFBQTtFQUM3SSxJQUFNcUIsZUFBZSxHQUFJQyxPQUFPLElBQUs7SUFDakMsSUFBTUMsUUFBUSxHQUFHRCxPQUFPLENBQUNFLEVBQUUsS0FBSyxXQUFXO0lBQzNDLElBQUlGLE9BQU8sQ0FBQ0csTUFBTSxFQUFFO01BQ2hCLE9BQU9ILE9BQU8sQ0FBQ0csTUFBTSxDQUFDLENBQUMsSUFBSUYsUUFBUTtJQUN2QyxDQUFDLE1BQ0k7TUFDRCxPQUFPQSxRQUFRO0lBQ25CO0VBQ0osQ0FBQztFQUNELElBQU1HLFlBQVksR0FBSUMsSUFBSSxJQUFLO0lBQzNCLElBQU1DLE9BQU8sR0FBR1IsbURBQVMsQ0FBQ08sSUFBSSxDQUFDRSxNQUFNLENBQUM7SUFDdEMsSUFBTUMsMEJBQTBCLEdBQUcsQ0FBQyxDQUFDSCxJQUFJLENBQUNJLGdCQUFnQjtJQUMxRCxJQUFNQyxRQUFRLEdBQUcvQixjQUFjLE1BQUFnQyxNQUFBLENBQU1OLElBQUksQ0FBQ0gsRUFBRSxFQUFHLElBQUksQ0FBQyxDQUFDdkIsY0FBYyxNQUFBZ0MsTUFBQSxDQUFNTixJQUFJLENBQUNILEVBQUUsRUFBRztJQUNuRixJQUFNVSxZQUFZLEdBQUdQLElBQUksQ0FBQ0YsTUFBTSxDQUFDLENBQUM7SUFDbEMsT0FBTyxDQUFDaEIsZUFBZSxHQUFHcUIsMEJBQTBCLEdBQUcsSUFBSSxLQUFLLENBQUMsQ0FBQ0UsUUFBUSxJQUFJLENBQUNKLE9BQU8sSUFBSU0sWUFBWTtFQUMxRyxDQUFDO0VBQ0QsSUFBTUMsMkJBQTJCLEdBQUlSLElBQUksSUFBSztJQUMxQyxJQUFNUyxjQUFjLEdBQUc3QixXQUFXLEdBQUdvQixJQUFJLENBQUNVLGNBQWM7SUFDeEQsSUFBTUMsYUFBYSxHQUFHRixjQUFjLEdBQUc3QixXQUFXLEdBQUdvQixJQUFJLENBQUNZLFFBQVE7SUFDbEUsSUFBSWpDLEtBQUssSUFBSUEsS0FBSyxHQUFHOEIsY0FBYyxJQUFJOUIsS0FBSyxJQUFJZ0MsYUFBYSxFQUFFO01BQUEsSUFBQUUsY0FBQTtNQUMzRCxRQUFBQSxjQUFBLEdBQU9iLElBQUksQ0FBQ2MsUUFBUSxDQUFDbkMsS0FBSyxHQUFHcUIsSUFBSSxDQUFDYyxRQUFRLENBQUNDLE1BQU0sQ0FBQyxjQUFBRixjQUFBLGNBQUFBLGNBQUEsR0FBSSxJQUFJO0lBQzlEO0lBQ0EsT0FBTyxJQUFJO0VBQ2YsQ0FBQztFQUNELElBQU1HLG9CQUFvQixHQUFHQSxDQUFDaEIsSUFBSSxFQUFFaUIsbUJBQW1CLEtBQUs7SUFBQSxJQUFBQyxxQkFBQTtJQUN4RCxJQUFNQyxNQUFNLEdBQUduQixJQUFJLENBQUNILEVBQUU7SUFDdEIsSUFBTXVCLGlCQUFpQixHQUFHQSxDQUFDQyxLQUFLLEVBQUVDLFNBQVM7TUFBQSxJQUFBQyxvQkFBQTtNQUFBLFFBQUFBLG9CQUFBLEdBQUtGLEtBQUssQ0FBQ1AsUUFBUSxDQUFDVSxJQUFJLENBQUU3QixPQUFPLElBQUtBLE9BQU8sQ0FBQ0UsRUFBRSxLQUFLeUIsU0FBUyxDQUFDLGNBQUFDLG9CQUFBLGNBQUFBLG9CQUFBLEdBQUksS0FBSztJQUFBO0lBQ25ILElBQU1FLFVBQVUsR0FBR1IsbUJBQW1CLGFBQW5CQSxtQkFBbUIsZ0JBQUFDLHFCQUFBLEdBQW5CRCxtQkFBbUIsQ0FBR0UsTUFBTSxDQUFDLGNBQUFELHFCQUFBLHVCQUE3QkEscUJBQUEsQ0FBK0J2QixPQUFPO0lBQ3pELE9BQU84QixVQUFVLEdBQUdMLGlCQUFpQixDQUFDcEIsSUFBSSxFQUFFeUIsVUFBVSxDQUFDLEdBQUcsS0FBSztFQUNuRSxDQUFDO0VBQ0QsSUFBTXJDLFlBQVksR0FBSVksSUFBSSxJQUFLO0lBQzNCLElBQU0wQixVQUFVLEdBQUdsQiwyQkFBMkIsQ0FBQ1IsSUFBSSxDQUFDO0lBQ3BELElBQU0yQixxQkFBcUIsR0FBR1gsb0JBQW9CLENBQUNoQixJQUFJLEVBQUV0QixrQkFBa0IsQ0FBQztJQUM1RSxJQUFNa0QsZUFBZSxHQUFHbkQsbUJBQW1CLEtBQUt1QixJQUFJLENBQUNILEVBQUU7SUFDdkQsSUFBTWdDLFlBQVksR0FBR0YscUJBQXFCLElBQUlELFVBQVU7SUFDeEQsSUFBSSxDQUFDRSxlQUFlLEtBQUtELHFCQUFxQixJQUFJNUIsWUFBWSxDQUFDQyxJQUFJLENBQUMsQ0FBQztJQUFJO0lBQ3JFNkIsWUFBWSxLQUFLRixxQkFBcUIsSUFBSWpDLGVBQWUsQ0FBQ21DLFlBQVksQ0FBQyxDQUFDLEVBQUU7TUFDMUUsT0FBQUMsYUFBQSxDQUFBQSxhQUFBLEtBQ085QixJQUFJO1FBQ1A2QjtNQUFZO0lBRXBCO0lBQ0EsT0FBTyxJQUFJO0VBQ2YsQ0FBQztFQUNELElBQU0zQyxnQkFBZ0IsR0FBSTZDLEtBQUssSUFBS0EsS0FBSyxDQUFDQyxNQUFNLENBQUMsQ0FBQ0MsSUFBSSxFQUFFQyxZQUFZLEtBQUs7SUFDckUsSUFBTUMsRUFBRSxHQUFHL0MsWUFBWSxDQUFDOEMsWUFBWSxDQUFDO0lBQ3JDLE9BQU9DLEVBQUUsR0FBRyxDQUFDLEdBQUdGLElBQUksRUFBRUUsRUFBRSxDQUFDLEdBQUdGLElBQUk7RUFDcEMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztFQUNOLElBQU05QyxpQkFBaUIsR0FBSTRDLEtBQUs7SUFBQSxJQUFBSyxlQUFBO0lBQUEsUUFBQUEsZUFBQSxHQUFLTCxLQUFLLENBQUNNLEdBQUcsQ0FBRXJDLElBQUksSUFBS1osWUFBWSxDQUFDWSxJQUFJLENBQUMsQ0FBQyxDQUFDd0IsSUFBSSxDQUFFVyxFQUFFLElBQUtBLEVBQUUsS0FBSyxJQUFJLENBQUMsY0FBQUMsZUFBQSxjQUFBQSxlQUFBLEdBQUksSUFBSTtFQUFBO0VBQzlHLElBQU0vQyxlQUFlLEdBQUdBLENBQUM4QixNQUFNLEVBQUVHLFNBQVMsS0FBS3BDLGdCQUFnQixDQUFDWCxrQkFBa0IsQ0FBQyxDQUFDK0QsSUFBSSxDQUFFQyxhQUFhLElBQUs7SUFDeEcsT0FBT0EsYUFBYSxDQUFDMUMsRUFBRSxLQUFLc0IsTUFBTSxJQUFJb0IsYUFBYSxDQUFDVixZQUFZLENBQUNoQyxFQUFFLEtBQUt5QixTQUFTO0VBQ3JGLENBQUMsQ0FBQztFQUNGLE9BQU87SUFDSHBDLGdCQUFnQjtJQUNoQkUsWUFBWTtJQUNaRCxpQkFBaUI7SUFDakJFO0VBQ0osQ0FBQztBQUNMLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQzVERCxJQUFNbUQsTUFBTSxHQUFHQSxDQUFDQyxPQUFPLEVBQUU1RCxXQUFXLEtBQUtBLFdBQVcsQ0FBQztFQUNqRDZELGNBQWMsRUFBRUQ7QUFDcEIsQ0FBQyxDQUFDO0FBQ0YsSUFBTUUsV0FBVyxHQUFHQSxDQUFDaEQsT0FBTyxFQUFFaUQsUUFBUSxLQUFLO0VBQ3ZDLElBQU1DLEtBQUssR0FBRztJQUNWQyxXQUFXLEVBQUVuRCxPQUFPLENBQUNFLEVBQUU7SUFDdkIrQztFQUNKLENBQUM7RUFDRCxJQUFJakQsT0FBTyxDQUFDb0QsWUFBWSxFQUFFO0lBQ3RCRixLQUFLLENBQUNHLGFBQWEsR0FBRyxDQUFDckQsT0FBTyxDQUFDb0QsWUFBWSxDQUFDO0VBQ2hEO0VBQ0EsT0FBT0YsS0FBSztBQUNoQixDQUFDO0FBQ0QsSUFBTUksZ0JBQWdCLEdBQUlqRCxJQUFJLElBQUtBLElBQUksQ0FBQ2MsUUFBUSxDQUFDb0MsS0FBSyxDQUFFdkQsT0FBTyxJQUFLLE9BQU9BLE9BQU8sQ0FBQ3dELFVBQVUsS0FBSyxVQUFVLENBQUM7QUFDN0csSUFBTUMsbUJBQW1CLEdBQUdBLENBQUNwRCxJQUFJLEVBQUVMLE9BQU8sRUFBRWlELFFBQVEsRUFBRS9ELFdBQVcsS0FBSztFQUNsRSxJQUFNd0UsSUFBSSxHQUFHO0lBQ1QsQ0FBQ3JELElBQUksQ0FBQ0gsRUFBRSxHQUFHOEMsV0FBVyxDQUFDaEQsT0FBTyxFQUFFaUQsUUFBUTtFQUM1QyxDQUFDO0VBQ0QsT0FBTyxNQUFNSixNQUFNLENBQUNhLElBQUksRUFBRXhFLFdBQVcsQ0FBQztBQUMxQyxDQUFDO0FBQ0QsSUFBTXlFLHFCQUFxQixHQUFHQSxDQUFDVixRQUFRLEVBQUVwRSxhQUFhLEVBQUVLLFdBQVcsS0FBTW1CLElBQUksSUFBSztFQUM5RSxJQUFNTCxPQUFPLEdBQUdLLElBQUksQ0FBQzZCLFlBQVk7RUFDakMsSUFBTTBCLFFBQVEsR0FBR1gsUUFBUSxHQUFHakQsT0FBTyxDQUFDNkQsT0FBTyxHQUFHN0QsT0FBTyxDQUFDd0QsVUFBVTtFQUNoRSxJQUFJLENBQUNJLFFBQVEsRUFBRTtJQUNYO0VBQ0o7RUFDQSxJQUFJO0lBQ0FBLFFBQVEsQ0FBQ0gsbUJBQW1CLENBQUNwRCxJQUFJLEVBQUVMLE9BQU8sRUFBRWlELFFBQVEsRUFBRS9ELFdBQVcsQ0FBQyxDQUFDO0VBQ3ZFLENBQUMsQ0FDRCxPQUFPNEUsS0FBSyxFQUFFO0lBQ1ZqRixhQUFhLENBQUNpRixLQUFLLENBQUM7RUFDeEI7QUFDSixDQUFDO0FBQ0QsSUFBTUMsaUJBQWlCLEdBQUdBLENBQUMzQixLQUFLLEVBQUV2RCxhQUFhLEVBQUVtRixpQkFBaUIsS0FBSztFQUNuRSxJQUFJO0lBQ0EsSUFBTUMsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUNkLElBQU03RSxlQUFlLEdBQUdyQyxNQUFNLENBQUNtSCxJQUFJLENBQUNGLGlCQUFpQixDQUFDLENBQUNHLE1BQU0sQ0FBRTlELElBQUksSUFBSyxDQUFDLENBQUMyRCxpQkFBaUIsQ0FBQzNELElBQUksQ0FBQyxDQUFDO0lBQ2xHK0IsS0FBSyxDQUFDK0IsTUFBTSxDQUFFOUQsSUFBSSxJQUFLLENBQUNpRCxnQkFBZ0IsQ0FBQ2pELElBQUksQ0FBQyxDQUFDLENBQUMrRCxPQUFPLENBQUUvRCxJQUFJLElBQUs7TUFDOUQ0RCxHQUFHLENBQUM1RCxJQUFJLENBQUNILEVBQUUsQ0FBQyxHQUFHOEMsV0FBVyxDQUFDM0MsSUFBSSxDQUFDNkIsWUFBWSxFQUFFLEtBQUssQ0FBQztJQUN4RCxDQUFDLENBQUM7SUFDRjlDLGVBQWUsQ0FBQ2dGLE9BQU8sQ0FBRS9ELElBQUksSUFBSztNQUM5QixJQUFNZ0UsaUJBQWlCLEdBQUc7UUFDdEJuRSxFQUFFLEVBQUUsUUFBUTtRQUNaRyxJQUFJLEVBQUVBLENBQUEsS0FBTSxLQUFLO01BQ3JCLENBQUM7TUFDRDRELEdBQUcsTUFBQXRELE1BQUEsQ0FBTU4sSUFBSSxFQUFHLEdBQUcyQyxXQUFXLENBQUNxQixpQkFBaUIsRUFBRSxLQUFLLENBQUM7SUFDNUQsQ0FBQyxDQUFDO0lBQ0YsT0FBT0osR0FBRztFQUNkLENBQUMsQ0FDRCxPQUFPSCxLQUFLLEVBQUU7SUFDVmpGLGFBQWEsQ0FBQ2lGLEtBQUssQ0FBQztJQUNwQixPQUFPLENBQUMsQ0FBQztFQUNiO0FBQ0osQ0FBQztBQUNELElBQU0zRixTQUFTLEdBQUdPLElBQUE7RUFBQSxJQUFDO0lBQUVVLGVBQWU7SUFBRVAsYUFBYTtJQUFFSztFQUFZLENBQUMsR0FBQVIsSUFBQTtFQUFBLE9BQU07SUFDcEVpQixzQkFBc0IsRUFBR3lDLEtBQUssSUFBS0EsS0FBSyxDQUFDZ0MsT0FBTyxDQUFDVCxxQkFBcUIsQ0FBQyxJQUFJLEVBQUU5RSxhQUFhLEVBQUVLLFdBQVcsQ0FBQyxDQUFDO0lBQ3pHVSx3QkFBd0IsRUFBR3dDLEtBQUssSUFBS0EsS0FBSyxDQUFDK0IsTUFBTSxDQUFDYixnQkFBZ0IsQ0FBQyxDQUFDYyxPQUFPLENBQUNULHFCQUFxQixDQUFDLEtBQUssRUFBRTlFLGFBQWEsRUFBRUssV0FBVyxDQUFDLENBQUM7SUFDcklXLFlBQVksRUFBR3VDLEtBQUssSUFBS1MsTUFBTSxDQUFDa0IsaUJBQWlCLENBQUMzQixLQUFLLEVBQUV2RCxhQUFhLEVBQUVPLGVBQWUsQ0FBQyxFQUFFRixXQUFXO0VBQ3pHLENBQUM7QUFBQSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUMxREYsSUFBTVksU0FBUyxHQUFJd0UsVUFBVSxJQUFLO0VBQzlCLElBQU1DLFdBQVcsR0FBRyxDQUFFLGVBQWUsSUFBSUMsSUFBSSxDQUFDLENBQUMsRUFBRUMsT0FBTyxDQUFDLENBQUM7RUFDMUQsSUFBTUMsYUFBYSxHQUFHLElBQUlGLElBQUksQ0FBQ0YsVUFBVSxDQUFDLENBQUNLLFFBQVEsQ0FBQyxFQUFFLEVBQUUsRUFBRSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUM7RUFDbkUsT0FBT0osV0FBVyxHQUFHRyxhQUFhO0FBQ3RDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSnNEO0FBQ2Q7QUFDekMsSUFBTUksTUFBTSxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxLQUFLLENBQUM7QUFDdEMsSUFBTUMsT0FBTyxHQUFHRix1REFBTyxDQUFDQyxNQUFNLENBQUM7QUFDL0IsSUFBTUUsUUFBUSxHQUFHQSxDQUFDQyxLQUFLLEVBQUVDLEtBQUssS0FBS0QsS0FBSyxJQUFJLENBQUNGLE9BQU8sQ0FBQ0csS0FBSyxDQUFDLEdBQUcsS0FBSyxHQUFHQSxLQUFLO0FBQzNFLElBQU1DLFNBQVMsR0FBSUQsS0FBSyxJQUFLQSxLQUFLLEtBQUssTUFBTSxHQUFHLDZEQUE2RCxHQUFHLHNFQUFzRTtBQUN0TCxJQUFNRSxXQUFXLEdBQUlGLEtBQUssSUFBS0EsS0FBSyxLQUFLLE1BQU0sR0FBRyxzQkFBc0IsR0FBRyxzQkFBc0I7QUFDakcsSUFBTUcsY0FBYyxHQUFHQSxDQUFDSCxLQUFLLEVBQUVJLE1BQU0sS0FBSztFQUN0QyxRQUFRSixLQUFLO0lBQ1QsS0FBSyxNQUFNO01BQ1AsSUFBSUksTUFBTSxLQUFLLGlDQUFpQyxFQUFFO1FBQzlDLE9BQU8sa0NBQWtDO01BQzdDO01BQ0EsT0FBTyw4QkFBOEI7SUFDekMsS0FBSyxNQUFNO01BQ1AsSUFBSUEsTUFBTSxLQUFLLDBDQUEwQyxFQUFFO1FBQ3ZELE9BQU8sMkNBQTJDO01BQ3REO01BQ0EsT0FBTyxxQ0FBcUM7SUFDaEQsS0FBSyxLQUFLO0lBQ1Y7TUFDSSxJQUFJQSxNQUFNLEtBQUssMEJBQTBCLEVBQUU7UUFDdkMsT0FBTywyQkFBMkI7TUFDdEM7TUFDQSxJQUFJQSxNQUFNLEtBQUssMEJBQTBCLEVBQUU7UUFDdkMsT0FBTywyQkFBMkI7TUFDdEM7TUFDQSxPQUFPLHdCQUF3QjtFQUN2QztBQUNKLENBQUM7QUFDRCxJQUFNQyxlQUFlLEdBQUdBLENBQUEsS0FBTTtFQUFBLElBQUFDLHFCQUFBLEVBQUFDLGVBQUEsRUFBQUMscUJBQUE7RUFDMUIsSUFBSUMsRUFBRTtFQUNOLElBQUksQ0FBQ0MsTUFBTSxDQUFDQyxRQUFRLEVBQUU7SUFDbEIsTUFBTSxJQUFJQyxLQUFLLENBQUMsOENBQThDLENBQUM7RUFDbkU7RUFDQSxJQUFNO0lBQUViLEtBQUssR0FBRyxLQUFLO0lBQUVDLEtBQUssR0FBRyxNQUFNO0lBQUVhO0VBQVMsQ0FBQyxJQUFBUCxxQkFBQSxHQUFHSSxNQUFNLENBQUNDLFFBQVEsQ0FBQ0csTUFBTSxjQUFBUixxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLENBQUMsQ0FBQztFQUNoRixJQUFNUyxVQUFVLEdBQUdqQixRQUFRLENBQUNDLEtBQUssRUFBRUMsS0FBSyxDQUFDO0VBQ3pDLENBQUFPLGVBQUEsSUFBQ0UsRUFBRSxHQUFHQyxNQUFNLENBQUNDLFFBQVEsRUFBRUssWUFBWSxjQUFBVCxlQUFBLGNBQUFBLGVBQUEsR0FBS0UsRUFBRSxDQUFDTyxZQUFZLEdBQUcsSUFBSXRCLGlFQUFZLENBQUM7SUFDdkV1QixNQUFNLEVBQUVoQixTQUFTLENBQUNjLFVBQVUsQ0FBQztJQUM3QkcsUUFBUSxFQUFFaEIsV0FBVyxDQUFDYSxVQUFVLENBQUM7SUFDakNJLFdBQVcsRUFBRWhCLGNBQWMsQ0FBQ1ksVUFBVSxFQUFFTCxNQUFNLENBQUNVLFFBQVEsQ0FBQ2hCLE1BQU0sQ0FBQztJQUMvRGlCLHNCQUFzQixHQUFBYixxQkFBQSxHQUFFSyxRQUFRLGFBQVJBLFFBQVEsdUJBQVJBLFFBQVEsQ0FBRVMsZUFBZSxjQUFBZCxxQkFBQSxjQUFBQSxxQkFBQSxHQUFJLEtBQUs7SUFDMURlLE1BQU0sRUFBRSxDQUNKLFFBQVE7SUFDUjtJQUNBLFNBQVM7SUFDVDtJQUNBLE9BQU87SUFDUDtJQUNBLG1EQUFtRDtJQUNuRDtJQUNBLHVDQUF1QztJQUN2QztJQUNBLDZDQUE2QztJQUM3QztJQUNBLCtDQUErQztJQUMvQztJQUNBLHdEQUF3RDtJQUN4RDtJQUNBLHFDQUFxQztJQUNyQztJQUNBO0lBQ0E7SUFBQTtFQUVSLENBQUMsQ0FBQztFQUNGLE9BQU9iLE1BQU0sQ0FBQ0MsUUFBUSxDQUFDSyxZQUFZO0FBQ3ZDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRWtDO0FBQ25DLElBQU1TLFdBQVcsR0FBRyxDQUNoQixpQ0FBaUMsRUFDakMsMENBQTBDLEVBQzFDLGdDQUFnQyxDQUNuQztBQUNELElBQU1DLFlBQVksR0FBR0YsZ0RBQUssQ0FBQ0MsV0FBVyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNOdkMsSUFBTUQsS0FBSyxHQUFJRyxLQUFLLElBQU01SixLQUFLLElBQUs0SixLQUFLLENBQUNDLFFBQVEsQ0FBQzdKLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7O0FDQXpELElBQUk4SixXQUFXLEdBQUlDLEdBQUcsSUFBSztFQUN2QixNQUFNckosU0FBUyxDQUFDcUosR0FBRyxDQUFDO0FBQ3hCLENBQUM7QUFDRCxJQUFJQyxhQUFhLEdBQUdBLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUVGLEdBQUcsS0FBS0UsTUFBTSxDQUFDQyxHQUFHLENBQUM3SSxHQUFHLENBQUMsSUFBSXlJLFdBQVcsQ0FBQyxTQUFTLEdBQUdDLEdBQUcsQ0FBQztBQUN6RixJQUFJSSxZQUFZLEdBQUdBLENBQUM5SSxHQUFHLEVBQUU0SSxNQUFNLEVBQUVHLE1BQU0sTUFBTUosYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHlCQUF5QixDQUFDLEVBQUVHLE1BQU0sR0FBR0EsTUFBTSxDQUFDM0osSUFBSSxDQUFDWSxHQUFHLENBQUMsR0FBRzRJLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDaEosR0FBRyxDQUFDLENBQUM7QUFDaEosSUFBSWlKLFlBQVksR0FBR0EsQ0FBQ2pKLEdBQUcsRUFBRTRJLE1BQU0sRUFBRWpLLEtBQUssS0FBS2lLLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDN0ksR0FBRyxDQUFDLEdBQUd5SSxXQUFXLENBQUMsbURBQW1ELENBQUMsR0FBR0csTUFBTSxZQUFZTSxPQUFPLEdBQUdOLE1BQU0sQ0FBQ08sR0FBRyxDQUFDbkosR0FBRyxDQUFDLEdBQUc0SSxNQUFNLENBQUNRLEdBQUcsQ0FBQ3BKLEdBQUcsRUFBRXJCLEtBQUssQ0FBQztBQUNwTSxJQUFJMEssWUFBWSxHQUFHQSxDQUFDckosR0FBRyxFQUFFNEksTUFBTSxFQUFFakssS0FBSyxFQUFFMkssTUFBTSxNQUFNWCxhQUFhLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUUsd0JBQXdCLENBQUMsRUFBRUEsTUFBTSxDQUFDUSxHQUFHLENBQUNwSixHQUFHLEVBQUVyQixLQUFLLENBQUMsRUFBRUEsS0FBSyxDQUFDO0FBQ3hJLElBQUk0SyxlQUFlLEdBQUdBLENBQUN2SixHQUFHLEVBQUU0SSxNQUFNLEVBQUVZLE1BQU0sTUFBTWIsYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHVCQUF1QixDQUFDLEVBQUVZLE1BQU0sQ0FBQztBQUM1RyxJQUFJQyxVQUFVLEVBQUVDLFFBQVEsRUFBRUMsYUFBYSxFQUFFQywyQkFBMkIsRUFBRUMsa0JBQWtCO0FBQ3hGLE1BQU1DLGdCQUFnQixDQUFDO0VBQ25CcEssV0FBV0EsQ0FBQ3FLLE9BQU8sRUFBRUMsWUFBWSxFQUFFO0lBQy9CZixZQUFZLENBQUMsSUFBSSxFQUFFVywyQkFBMkIsQ0FBQztJQUMvQ1gsWUFBWSxDQUFDLElBQUksRUFBRVEsVUFBVSxDQUFDO0lBQzlCUixZQUFZLENBQUMsSUFBSSxFQUFFUyxRQUFRLENBQUM7SUFDNUJULFlBQVksQ0FBQyxJQUFJLEVBQUVVLGFBQWEsQ0FBQztJQUNqQ04sWUFBWSxDQUFDLElBQUksRUFBRUssUUFBUSxFQUFFSyxPQUFPLENBQUM7SUFDckNWLFlBQVksQ0FBQyxJQUFJLEVBQUVNLGFBQWEsRUFBRUssWUFBWSxDQUFDO0lBQy9DWCxZQUFZLENBQUMsSUFBSSxFQUFFSSxVQUFVLEVBQUU7TUFDM0JRLFdBQVcsRUFBRSxLQUFLLENBQUM7TUFDbkJDLE9BQU8sRUFBRSxLQUFLLENBQUM7TUFDZkMsZUFBZSxFQUFFO0lBQ3JCLENBQUMsQ0FBQztJQUNGWixlQUFlLENBQUMsSUFBSSxFQUFFSywyQkFBMkIsRUFBRUMsa0JBQWtCLENBQUMsQ0FBQ3pLLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDakYwSixZQUFZLENBQUMsSUFBSSxFQUFFWSxRQUFRLENBQUMsQ0FBQ1UsRUFBRSxDQUFDLE9BQU8sRUFBRSxNQUFNO01BQzNDYixlQUFlLENBQUMsSUFBSSxFQUFFSywyQkFBMkIsRUFBRUMsa0JBQWtCLENBQUMsQ0FBQ3pLLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDckYsQ0FBQyxDQUFDO0lBQ0YwSixZQUFZLENBQUMsSUFBSSxFQUFFWSxRQUFRLENBQUMsQ0FBQ1UsRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNO01BQzdDYixlQUFlLENBQUMsSUFBSSxFQUFFSywyQkFBMkIsRUFBRUMsa0JBQWtCLENBQUMsQ0FBQ3pLLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDckYsQ0FBQyxDQUFDO0lBQ0YwSixZQUFZLENBQUMsSUFBSSxFQUFFWSxRQUFRLENBQUMsQ0FBQ1UsRUFBRSxDQUFDLFNBQVMsRUFBRSxNQUFNO01BQzdDYixlQUFlLENBQUMsSUFBSSxFQUFFSywyQkFBMkIsRUFBRUMsa0JBQWtCLENBQUMsQ0FBQ3pLLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDckYsQ0FBQyxDQUFDO0VBQ047RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0VBQ0lpTCxZQUFZQSxDQUFBLEVBQUc7SUFDWCxPQUFPdkIsWUFBWSxDQUFDLElBQUksRUFBRVcsVUFBVSxDQUFDO0VBQ3pDO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtFQUNJYSxTQUFTQSxDQUFDQyxPQUFPLEVBQUU7SUFDZnpCLFlBQVksQ0FBQyxJQUFJLEVBQUVZLFFBQVEsQ0FBQyxDQUFDVSxFQUFFLENBQUMsaUJBQWlCLEVBQUVHLE9BQU8sQ0FBQztFQUMvRDtFQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7RUFDSUMsV0FBV0EsQ0FBQ0QsT0FBTyxFQUFFO0lBQ2pCekIsWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLENBQUNlLEdBQUcsQ0FBQyxpQkFBaUIsRUFBRUYsT0FBTyxDQUFDO0VBQ2hFO0FBQ0o7QUFDQWQsVUFBVSxHQUFHLElBQUlpQixPQUFPLENBQUMsQ0FBQztBQUMxQmhCLFFBQVEsR0FBRyxJQUFJZ0IsT0FBTyxDQUFDLENBQUM7QUFDeEJmLGFBQWEsR0FBRyxJQUFJZSxPQUFPLENBQUMsQ0FBQztBQUM3QmQsMkJBQTJCLEdBQUcsSUFBSVYsT0FBTyxDQUFDLENBQUM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBVyxrQkFBa0IsR0FBRyxTQUFBQSxDQUFBLEVBQVk7RUFDN0IsSUFBTWMsTUFBTSxHQUFHN0IsWUFBWSxDQUFDLElBQUksRUFBRWEsYUFBYSxDQUFDLENBQUNpQixhQUFhLENBQUMsQ0FBQztFQUNoRSxJQUFJRCxNQUFNLEVBQUU7SUFDUnRCLFlBQVksQ0FBQyxJQUFJLEVBQUVJLFVBQVUsRUFBRTtNQUMzQlEsV0FBVyxFQUFFVSxNQUFNLENBQUNWLFdBQVc7TUFDL0JDLE9BQU8sRUFBRVMsTUFBTSxDQUFDVCxPQUFPO01BQ3ZCQyxlQUFlLEVBQUU7SUFDckIsQ0FBQyxDQUFDO0VBQ04sQ0FBQyxNQUNJO0lBQ0RkLFlBQVksQ0FBQyxJQUFJLEVBQUVJLFVBQVUsRUFBRTtNQUMzQlEsV0FBVyxFQUFFLEtBQUssQ0FBQztNQUNuQkMsT0FBTyxFQUFFLEtBQUssQ0FBQztNQUNmQyxlQUFlLEVBQUU7SUFDckIsQ0FBQyxDQUFDO0VBQ047RUFDQXJCLFlBQVksQ0FBQyxJQUFJLEVBQUVZLFFBQVEsQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLGlCQUFpQixFQUFFL0IsWUFBWSxDQUFDLElBQUksRUFBRVcsVUFBVSxDQUFDLENBQUM7QUFDeEYsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztBQ3BGMEM7QUFDM0MsSUFBSTNKLFNBQVMsR0FBR3JCLE1BQU0sQ0FBQ0MsY0FBYztBQUNyQyxJQUFJK0osV0FBVyxHQUFJQyxHQUFHLElBQUs7RUFDdkIsTUFBTXJKLFNBQVMsQ0FBQ3FKLEdBQUcsQ0FBQztBQUN4QixDQUFDO0FBQ0QsSUFBSTNJLGVBQWUsR0FBR0EsQ0FBQ0MsR0FBRyxFQUFFQyxHQUFHLEVBQUV0QixLQUFLLEtBQUtzQixHQUFHLElBQUlELEdBQUcsR0FBR0YsU0FBUyxDQUFDRSxHQUFHLEVBQUVDLEdBQUcsRUFBRTtFQUFFckIsVUFBVSxFQUFFLElBQUk7RUFBRUMsWUFBWSxFQUFFLElBQUk7RUFBRUMsUUFBUSxFQUFFLElBQUk7RUFBRUg7QUFBTSxDQUFDLENBQUMsR0FBR3FCLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDLEdBQUd0QixLQUFLO0FBQy9KLElBQUl1QixhQUFhLEdBQUdBLENBQUNGLEdBQUcsRUFBRUMsR0FBRyxFQUFFdEIsS0FBSyxLQUFLb0IsZUFBZSxDQUFDQyxHQUFHLEVBQUVDLEdBQUcsR0FBRyxFQUFFLEVBQUV0QixLQUFLLENBQUM7QUFDOUUsSUFBSWdLLGFBQWEsR0FBR0EsQ0FBQzNJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRUYsR0FBRyxLQUFLRSxNQUFNLENBQUNDLEdBQUcsQ0FBQzdJLEdBQUcsQ0FBQyxJQUFJeUksV0FBVyxDQUFDLFNBQVMsR0FBR0MsR0FBRyxDQUFDO0FBQ3pGLElBQUlJLFlBQVksR0FBR0EsQ0FBQzlJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRUcsTUFBTSxNQUFNSixhQUFhLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUUseUJBQXlCLENBQUMsRUFBRUcsTUFBTSxHQUFHQSxNQUFNLENBQUMzSixJQUFJLENBQUNZLEdBQUcsQ0FBQyxHQUFHNEksTUFBTSxDQUFDSSxHQUFHLENBQUNoSixHQUFHLENBQUMsQ0FBQztBQUNoSixJQUFJaUosWUFBWSxHQUFHQSxDQUFDakosR0FBRyxFQUFFNEksTUFBTSxFQUFFakssS0FBSyxLQUFLaUssTUFBTSxDQUFDQyxHQUFHLENBQUM3SSxHQUFHLENBQUMsR0FBR3lJLFdBQVcsQ0FBQyxtREFBbUQsQ0FBQyxHQUFHRyxNQUFNLFlBQVlNLE9BQU8sR0FBR04sTUFBTSxDQUFDTyxHQUFHLENBQUNuSixHQUFHLENBQUMsR0FBRzRJLE1BQU0sQ0FBQ1EsR0FBRyxDQUFDcEosR0FBRyxFQUFFckIsS0FBSyxDQUFDO0FBQ3BNLElBQUkwSyxZQUFZLEdBQUdBLENBQUNySixHQUFHLEVBQUU0SSxNQUFNLEVBQUVqSyxLQUFLLEVBQUUySyxNQUFNLE1BQU1YLGFBQWEsQ0FBQzNJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRSx3QkFBd0IsQ0FBQyxFQUFFQSxNQUFNLENBQUNRLEdBQUcsQ0FBQ3BKLEdBQUcsRUFBRXJCLEtBQUssQ0FBQyxFQUFFQSxLQUFLLENBQUM7QUFDeEksSUFBSTRLLGVBQWUsR0FBR0EsQ0FBQ3ZKLEdBQUcsRUFBRTRJLE1BQU0sRUFBRVksTUFBTSxNQUFNYixhQUFhLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUUsdUJBQXVCLENBQUMsRUFBRVksTUFBTSxDQUFDO0FBQzVHLElBQUl1QixRQUFRLEVBQUVyQixRQUFRLEVBQUVzQixpQkFBaUIsRUFBRUMsaUJBQWlCLEVBQUVDLDJCQUEyQixFQUFFQyxzQkFBc0IsRUFBRUMsb0JBQW9CLEVBQUVDLHdCQUF3QjtBQUNqSyxNQUFNQyxnQkFBZ0IsQ0FBQztFQUNuQjVMLFdBQVdBLENBQUM2TCxPQUFPLEVBQUV4QixPQUFPLEVBQUV5QixnQkFBZ0IsRUFBRTtJQUM1Q3ZDLFlBQVksQ0FBQyxJQUFJLEVBQUVpQywyQkFBMkIsQ0FBQztJQUMvQ2pDLFlBQVksQ0FBQyxJQUFJLEVBQUU4QixRQUFRLENBQUM7SUFDNUI5QixZQUFZLENBQUMsSUFBSSxFQUFFUyxRQUFRLENBQUM7SUFDNUJULFlBQVksQ0FBQyxJQUFJLEVBQUUrQixpQkFBaUIsQ0FBQztJQUNyQzlLLGFBQWEsQ0FBQyxJQUFJLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQztJQUNyQytJLFlBQVksQ0FBQyxJQUFJLEVBQUVnQyxpQkFBaUIsQ0FBQztJQUNyQzVCLFlBQVksQ0FBQyxJQUFJLEVBQUUwQixRQUFRLEVBQUVRLE9BQU8sQ0FBQztJQUNyQ2xDLFlBQVksQ0FBQyxJQUFJLEVBQUVLLFFBQVEsRUFBRUssT0FBTyxDQUFDO0lBQ3JDVixZQUFZLENBQUMsSUFBSSxFQUFFMkIsaUJBQWlCLEVBQUVRLGdCQUFnQixDQUFDO0lBQ3ZEMUMsWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLENBQUNVLEVBQUUsQ0FBQyxTQUFTLEVBQUUsTUFBTTtNQUM3Q2IsZUFBZSxDQUFDLElBQUksRUFBRTJCLDJCQUEyQixFQUFFQyxzQkFBc0IsQ0FBQyxDQUFDL0wsSUFBSSxDQUFDLElBQUksQ0FBQztNQUNyRm1LLGVBQWUsQ0FBQyxJQUFJLEVBQUUyQiwyQkFBMkIsRUFBRUcsd0JBQXdCLENBQUMsQ0FBQ2pNLElBQUksQ0FBQyxJQUFJLENBQUM7SUFDM0YsQ0FBQyxDQUFDO0VBQ047RUFDQTtBQUNKO0FBQ0E7QUFDQTtFQUNJcU0sS0FBS0EsQ0FBQSxFQUFHO0lBQ0osSUFBSTNDLFlBQVksQ0FBQyxJQUFJLEVBQUVpQyxRQUFRLENBQUMsQ0FBQ1csU0FBUyxJQUFJLENBQUMsSUFBSSxDQUFDQyxPQUFPLEVBQUU7TUFDekQsSUFBSSxDQUFDQSxPQUFPLEdBQUcsSUFBSTtNQUNuQjdDLFlBQVksQ0FBQyxJQUFJLEVBQUVZLFFBQVEsQ0FBQyxDQUFDVSxFQUFFLENBQUMsaUJBQWlCLEVBQUd3QixLQUFLLElBQUtyQyxlQUFlLENBQUMsSUFBSSxFQUFFMkIsMkJBQTJCLEVBQUVHLHdCQUF3QixDQUFDLENBQUNqTSxJQUFJLENBQUMsSUFBSSxFQUFFd00sS0FBSyxDQUFDLENBQUM7TUFDN0pyQyxlQUFlLENBQUMsSUFBSSxFQUFFMkIsMkJBQTJCLEVBQUVHLHdCQUF3QixDQUFDLENBQUNqTSxJQUFJLENBQUMsSUFBSSxDQUFDO0lBQzNGO0VBQ0o7QUFDSjtBQUNBMkwsUUFBUSxHQUFHLElBQUlMLE9BQU8sQ0FBQyxDQUFDO0FBQ3hCaEIsUUFBUSxHQUFHLElBQUlnQixPQUFPLENBQUMsQ0FBQztBQUN4Qk0saUJBQWlCLEdBQUcsSUFBSU4sT0FBTyxDQUFDLENBQUM7QUFDakNPLGlCQUFpQixHQUFHLElBQUlQLE9BQU8sQ0FBQyxDQUFDO0FBQ2pDUSwyQkFBMkIsR0FBRyxJQUFJaEMsT0FBTyxDQUFDLENBQUM7QUFDM0M7QUFDQTtBQUNBO0FBQ0E7QUFDQWlDLHNCQUFzQixHQUFHLFNBQUFBLENBQUEsRUFBWTtFQUNqQyxJQUFJckMsWUFBWSxDQUFDLElBQUksRUFBRW1DLGlCQUFpQixDQUFDLEtBQUssS0FBSyxDQUFDLEVBQUU7SUFDbEQzRCxNQUFNLENBQUN1RSxZQUFZLENBQUMvQyxZQUFZLENBQUMsSUFBSSxFQUFFbUMsaUJBQWlCLENBQUMsQ0FBQztJQUMxRDVCLFlBQVksQ0FBQyxJQUFJLEVBQUU0QixpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztFQUNqRDtBQUNKLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQUcsb0JBQW9CLEdBQUcsU0FBQUEsQ0FBVVUsU0FBUyxFQUFFO0VBQ3hDLElBQU1DLEdBQUcsR0FBRzdGLElBQUksQ0FBQzZGLEdBQUcsQ0FBQyxDQUFDO0VBQ3RCLElBQU1DLE9BQU8sR0FBRyxDQUFDRixTQUFTLEdBQUdoRCxZQUFZLENBQUMsSUFBSSxFQUFFaUMsUUFBUSxDQUFDLENBQUNrQixnQkFBZ0IsSUFBSSxHQUFHO0VBQ2pGLElBQU1DLE9BQU8sR0FBR0YsT0FBTyxHQUFHRCxHQUFHO0VBQzdCMUMsWUFBWSxDQUFDLElBQUksRUFBRTRCLGlCQUFpQixFQUFFM0QsTUFBTSxDQUFDNkUsVUFBVSxDQUFDLE1BQU07SUFDMUQsSUFBSTdFLE1BQU0sQ0FBQzhFLFFBQVEsQ0FBQ0MsZUFBZSxLQUFLLFFBQVEsRUFBRTtNQUM5Qy9FLE1BQU0sQ0FBQzhFLFFBQVEsQ0FBQ0UsZ0JBQWdCLENBQUMsa0JBQWtCLEVBQUUsTUFBTTtRQUN2RCxJQUFJaEYsTUFBTSxDQUFDOEUsUUFBUSxDQUFDQyxlQUFlLEtBQUssU0FBUyxFQUFFO1VBQy9DLElBQU1FLFNBQVMsR0FBR3pELFlBQVksQ0FBQyxJQUFJLEVBQUVrQyxpQkFBaUIsQ0FBQyxDQUFDWCxZQUFZLENBQUMsQ0FBQztVQUN0RSxJQUFJa0MsU0FBUyxDQUFDcEMsZUFBZSxJQUFJb0MsU0FBUyxDQUFDdEMsV0FBVyxDQUFDNkIsU0FBUyxHQUFHaEQsWUFBWSxDQUFDLElBQUksRUFBRWlDLFFBQVEsQ0FBQyxDQUFDa0IsZ0JBQWdCLEdBQUdPLElBQUksQ0FBQ0MsS0FBSyxDQUFDdkcsSUFBSSxDQUFDNkYsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsRUFBRTtZQUM3SWpELFlBQVksQ0FBQyxJQUFJLEVBQUVZLFFBQVEsQ0FBQyxDQUFDbUIsSUFBSSxDQUFDLE9BQU8sQ0FBQztVQUM5QztVQUNBLElBQUksQ0FBQzBCLFNBQVMsQ0FBQ3BDLGVBQWUsSUFBSSxDQUFDLENBQUNXLHlEQUFTLENBQUM7WUFBRTRCLElBQUksRUFBRSxNQUFNO1lBQUVDLGFBQWEsRUFBRTtVQUFLLENBQUMsQ0FBQyxFQUFFO1lBQ2xGN0QsWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLENBQUNtQixJQUFJLENBQUMsT0FBTyxDQUFDO1VBQzlDO1FBQ0o7TUFDSixDQUFDLEVBQUU7UUFDQytCLElBQUksRUFBRTtRQUNOO01BQ0osQ0FBQyxDQUFDO0lBQ04sQ0FBQyxNQUNJO01BQ0Q5RCxZQUFZLENBQUMsSUFBSSxFQUFFWSxRQUFRLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxPQUFPLENBQUM7SUFDOUM7SUFDQXhCLFlBQVksQ0FBQyxJQUFJLEVBQUU0QixpQkFBaUIsRUFBRSxLQUFLLENBQUMsQ0FBQztFQUNqRCxDQUFDLEVBQUVpQixPQUFPLENBQUMsQ0FBQztBQUNoQixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBYix3QkFBd0IsR0FBRyxTQUFBQSxDQUFVTyxLQUFLLEVBQUU7RUFDeENyQyxlQUFlLENBQUMsSUFBSSxFQUFFMkIsMkJBQTJCLEVBQUVDLHNCQUFzQixDQUFDLENBQUMvTCxJQUFJLENBQUMsSUFBSSxDQUFDO0VBQ3JGLElBQU1tTixTQUFTLEdBQUdYLEtBQUssYUFBTEEsS0FBSyxjQUFMQSxLQUFLLEdBQUk5QyxZQUFZLENBQUMsSUFBSSxFQUFFa0MsaUJBQWlCLENBQUMsQ0FBQ1gsWUFBWSxDQUFDLENBQUM7RUFDL0UsSUFBSWtDLFNBQVMsQ0FBQ3BDLGVBQWUsRUFBRTtJQUMzQlosZUFBZSxDQUFDLElBQUksRUFBRTJCLDJCQUEyQixFQUFFRSxvQkFBb0IsQ0FBQyxDQUFDaE0sSUFBSSxDQUFDLElBQUksRUFBRW1OLFNBQVMsQ0FBQ3RDLFdBQVcsQ0FBQzZCLFNBQVMsQ0FBQztFQUN4SDtBQUNKLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwR21EO0FBQ0g7QUFDVDtBQUN4QyxJQUFNaUIsY0FBYyxHQUFHLEdBQUcsR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBRyxFQUFFO0FBQzlDLElBQU1DLHlCQUF5QixHQUFHQSxDQUFDQyxVQUFVLEVBQUVDLFNBQVMsS0FBSztFQUN6RCxJQUFNQyxRQUFRLE1BQUE5SyxNQUFBLENBQU00SyxVQUFVLGdDQUFBNUssTUFBQSxDQUE2QjZLLFNBQVMsQ0FBRTtFQUN0RTVGLE1BQU0sQ0FBQ1UsUUFBUSxDQUFDb0YsT0FBTyxDQUFDRCxRQUFRLENBQUM7QUFDckMsQ0FBQztBQUNELElBQU1FLG1CQUFtQixHQUFHQSxDQUFDQyxXQUFXLEVBQUVySCxXQUFXLEtBQUs7RUFDdEQsSUFBTXNILGtCQUFrQixHQUFHLENBQUMsQ0FBQ2hPLE1BQU0sQ0FBQytOLFdBQVcsQ0FBQztFQUNoRCxJQUFJLENBQUNDLGtCQUFrQixFQUFFO0lBQ3JCLE9BQU8sSUFBSTtFQUNmO0VBQ0EsT0FBT3RILFdBQVcsR0FBRzFHLE1BQU0sQ0FBQytOLFdBQVcsQ0FBQyxHQUFHUCxjQUFjO0FBQzdELENBQUM7QUFDRCxJQUFNUyx1QkFBdUIsR0FBR0EsQ0FBQ0MsT0FBTyxFQUFFNUYsTUFBTSxLQUFLO0VBQ2pELElBQU1vRixVQUFVLEdBQUdwRixNQUFNLENBQUM2RixLQUFLLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzdDLElBQUksQ0FBQ3BGLDZEQUFZLENBQUMyRSxVQUFVLENBQUMsRUFBRTtJQUMzQixNQUFNLElBQUlILGlEQUFVLENBQUM7TUFDakJ0SCxLQUFLLEVBQUUsZ0JBQWdCO01BQ3ZCbUksaUJBQWlCLGlCQUFBdEwsTUFBQSxDQUFpQndGLE1BQU07SUFDNUMsQ0FBQyxDQUFDO0VBQ047RUFDQSxJQUFNK0YsY0FBYyxHQUFHLHNCQUFzQjtFQUM3QyxJQUFJSCxPQUFPLElBQUlaLG1EQUFPLENBQUNnQixLQUFLLENBQUNDLFdBQVcsQ0FBQyxDQUFDLElBQUloRCx5REFBUyxDQUFDO0lBQUU0QixJQUFJLEVBQUUsTUFBTTtJQUFFQyxhQUFhLEVBQUU7RUFBSyxDQUFDLENBQUMsRUFBRTtJQUM1RixJQUFNMUcsV0FBVyxHQUFHLENBQUUsZUFBZSxJQUFJQyxJQUFJLENBQUMsQ0FBQyxFQUFFNkgsT0FBTyxDQUFDLENBQUM7SUFDMUQsSUFBTVQsV0FBVyxHQUFHVCxtREFBTyxDQUFDZ0IsS0FBSyxDQUFDN0UsR0FBRyxDQUFDNEUsY0FBYyxDQUFDO0lBQ3JELElBQUlQLG1CQUFtQixDQUFDQyxXQUFXLEVBQUVySCxXQUFXLENBQUMsRUFBRTtNQUMvQyxJQUFNK0gsU0FBUyxHQUFHL0gsV0FBVyxHQUFHOEcsY0FBYztNQUM5Q0YsbURBQU8sQ0FBQ2dCLEtBQUssQ0FBQ3pFLEdBQUcsQ0FBQ3dFLGNBQWMsRUFBRTNILFdBQVcsRUFBRStILFNBQVMsQ0FBQztNQUN6RGhCLHlCQUF5QixDQUFDQyxVQUFVLEVBQUVnQixrQkFBa0IsQ0FBQzdCLFFBQVEsQ0FBQ3BFLFFBQVEsQ0FBQ2tHLElBQUksQ0FBQyxDQUFDO0lBQ3JGO0VBQ0o7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakNELElBQU1DLE9BQU8sR0FBSUMsR0FBRyxJQUFLO0VBQ3JCLElBQU1DLEdBQUcsR0FBR0QsR0FBRyxDQUFDRSxRQUFRLENBQUMsRUFBRSxDQUFDO0VBQzVCLE9BQU8sR0FBRyxDQUFDQyxTQUFTLENBQUMsQ0FBQyxFQUFFLENBQUMsR0FBR0YsR0FBRyxDQUFDdkwsTUFBTSxDQUFDLEdBQUd1TCxHQUFHO0FBQ2pELENBQUM7QUFDRCxJQUFNRyxlQUFlLEdBQUkxTCxNQUFNLElBQUs7RUFDaEMsSUFBTTJMLEdBQUcsR0FBRyxJQUFJQyxVQUFVLENBQUNsQyxJQUFJLENBQUNtQyxJQUFJLENBQUM3TCxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUM7RUFDakR3RSxNQUFNLENBQUNzSCxNQUFNLENBQUNDLGVBQWUsQ0FBQ0osR0FBRyxDQUFDO0VBQ2xDLElBQU1LLEdBQUcsR0FBR0MsS0FBSyxDQUFDQyxJQUFJLENBQUNQLEdBQUcsRUFBRU4sT0FBTyxDQUFDLENBQUNjLElBQUksQ0FBQyxFQUFFLENBQUM7RUFDN0MsT0FBT0gsR0FBRyxDQUFDSSxLQUFLLENBQUMsQ0FBQyxFQUFFcE0sTUFBTSxDQUFDO0FBQy9CLENBQUM7QUFDRCxJQUFNcU0sa0JBQWtCO0VBQUEsSUFBQS9PLElBQUEsR0FBQWdQLGlCQUFBLENBQUcsV0FBT04sR0FBRyxFQUFLO0lBQ3RDLElBQU1PLE1BQU0sR0FBRyxJQUFJQyxXQUFXLENBQUMsQ0FBQyxDQUFDQyxNQUFNLENBQUNULEdBQUcsQ0FBQztJQUM1QyxJQUFNVSxVQUFVLFNBQVNsSSxNQUFNLENBQUNzSCxNQUFNLENBQUNhLE1BQU0sQ0FBQ0MsTUFBTSxDQUFDLFNBQVMsRUFBRUwsTUFBTSxDQUFDO0lBQ3ZFLElBQU1NLFNBQVMsR0FBR1osS0FBSyxDQUFDQyxJQUFJLENBQUMsSUFBSU4sVUFBVSxDQUFDYyxVQUFVLENBQUMsQ0FBQztJQUN4RCxJQUFNSSxJQUFJLEdBQUd0USxNQUFNLENBQUN1USxZQUFZLENBQUNDLEtBQUssQ0FBQyxJQUFJLEVBQUUsSUFBSXBCLFVBQVUsQ0FBQ2lCLFNBQVMsQ0FBQyxDQUFDO0lBQ3ZFLE9BQU9DLElBQUk7RUFDZixDQUFDO0VBQUEsZ0JBTktULGtCQUFrQkEsQ0FBQVksRUFBQTtJQUFBLE9BQUEzUCxJQUFBLENBQUEwUCxLQUFBLE9BQUFFLFNBQUE7RUFBQTtBQUFBLEdBTXZCO0FBQ0QsSUFBTUMsb0JBQW9CLEdBQUdBLENBQUEsS0FBTXpCLGVBQWUsQ0FBQyxHQUFHLENBQUM7QUFDdkQsSUFBTTBCLHFCQUFxQjtFQUFBLElBQUFDLEtBQUEsR0FBQWYsaUJBQUEsQ0FBRyxXQUFPZ0IsWUFBWSxFQUFLO0lBQ2xELElBQU1SLElBQUksU0FBU1Qsa0JBQWtCLENBQUNpQixZQUFZLENBQUM7SUFDbkQsSUFBTUMsU0FBUyxHQUFHQyxlQUFlLENBQUNWLElBQUksQ0FBQztJQUN2QyxPQUFPUyxTQUFTO0VBQ3BCLENBQUM7RUFBQSxnQkFKS0gscUJBQXFCQSxDQUFBSyxHQUFBO0lBQUEsT0FBQUosS0FBQSxDQUFBTCxLQUFBLE9BQUFFLFNBQUE7RUFBQTtBQUFBLEdBSTFCO0FBQ0QsSUFBTVEsaUJBQWlCLEdBQUlDLFNBQVMsSUFBSztFQUNyQyxJQUFJQyxNQUFNLEdBQUdDLGlCQUFpQixDQUFDRixTQUFTLENBQUM7RUFDekMsUUFBUUMsTUFBTSxDQUFDNU4sTUFBTSxHQUFHLENBQUM7SUFDckIsS0FBSyxDQUFDO01BQ0Y7SUFDSixLQUFLLENBQUM7TUFDRjROLE1BQU0sSUFBSSxJQUFJO01BQ2Q7SUFDSixLQUFLLENBQUM7TUFDRkEsTUFBTSxJQUFJLEdBQUc7TUFDYjtJQUNKO01BQ0ksTUFBTSxJQUFJbEosS0FBSyxDQUFDLHVCQUF1QixDQUFDO0VBQ2hEO0VBQ0EsSUFBTW9KLE9BQU8sR0FBR3RKLE1BQU0sQ0FBQ3VKLElBQUksQ0FBQ0gsTUFBTSxDQUFDO0VBQ25DLElBQUk7SUFDQSxPQUFPSSxrQkFBa0IsQ0FBQ3hKLE1BQU0sQ0FBQ3lKLE1BQU0sQ0FBQ0gsT0FBTyxDQUFDLENBQUM7RUFDckQsQ0FBQyxDQUNELE9BQU90UyxDQUFDLEVBQUU7SUFDTixPQUFPc1MsT0FBTztFQUNsQjtBQUNKLENBQUM7QUFDRCxJQUFNSSxjQUFjLEdBQUlsQyxHQUFHLElBQUs7RUFDNUIsSUFBTU8sTUFBTSxHQUFHLElBQUlYLFVBQVUsQ0FBQ0ksR0FBRyxDQUFDaE0sTUFBTSxDQUFDO0VBQ3pDLEtBQUssSUFBSTNELENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBRzJQLEdBQUcsQ0FBQ2hNLE1BQU0sRUFBRTNELENBQUMsRUFBRSxFQUFFO0lBQ2pDa1EsTUFBTSxDQUFDbFEsQ0FBQyxDQUFDLEdBQUcyUCxHQUFHLENBQUNtQyxVQUFVLENBQUM5UixDQUFDLENBQUM7RUFDakM7RUFDQSxPQUFPa1EsTUFBTTtBQUNqQixDQUFDO0FBQ0QsSUFBTXNCLGlCQUFpQixHQUFJRixTQUFTLElBQUtBLFNBQVMsQ0FBQ3JELE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDLENBQUNBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsR0FBRyxDQUFDO0FBQ3hGLElBQU1rRCxlQUFlLEdBQUl4QixHQUFHLElBQUt4SCxNQUFNLENBQUM0SixJQUFJLENBQUNwQyxHQUFHLENBQUMsQ0FBQzFCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUNBLE9BQU8sQ0FBQyxLQUFLLEVBQUUsR0FBRyxDQUFDLENBQUNBLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUNyRDNHLElBQUkzRSxXQUFXLEdBQUlDLEdBQUcsSUFBSztFQUN2QixNQUFNckosU0FBUyxDQUFDcUosR0FBRyxDQUFDO0FBQ3hCLENBQUM7QUFDRCxJQUFJQyxhQUFhLEdBQUdBLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUVGLEdBQUcsS0FBS0UsTUFBTSxDQUFDQyxHQUFHLENBQUM3SSxHQUFHLENBQUMsSUFBSXlJLFdBQVcsQ0FBQyxTQUFTLEdBQUdDLEdBQUcsQ0FBQztBQUN6RixJQUFJSSxZQUFZLEdBQUdBLENBQUM5SSxHQUFHLEVBQUU0SSxNQUFNLEVBQUVHLE1BQU0sTUFBTUosYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHlCQUF5QixDQUFDLEVBQUVBLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDaEosR0FBRyxDQUFDLENBQUM7QUFDcEgsSUFBSWlKLFlBQVksR0FBR0EsQ0FBQ2pKLEdBQUcsRUFBRTRJLE1BQU0sRUFBRWpLLEtBQUssS0FBS2lLLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDN0ksR0FBRyxDQUFDLEdBQUd5SSxXQUFXLENBQUMsbURBQW1ELENBQUMsR0FBR0csTUFBTSxZQUFZTSxPQUFPLEdBQUdOLE1BQU0sQ0FBQ08sR0FBRyxDQUFDbkosR0FBRyxDQUFDLEdBQUc0SSxNQUFNLENBQUNRLEdBQUcsQ0FBQ3BKLEdBQUcsRUFBRXJCLEtBQUssQ0FBQztBQUNwTSxJQUFJMEssWUFBWSxHQUFHQSxDQUFDckosR0FBRyxFQUFFNEksTUFBTSxFQUFFakssS0FBSyxFQUFFMkssTUFBTSxNQUFNWCxhQUFhLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUUsd0JBQXdCLENBQUMsRUFBRUEsTUFBTSxDQUFDUSxHQUFHLENBQUNwSixHQUFHLEVBQUVyQixLQUFLLENBQUMsRUFBRUEsS0FBSyxDQUFDO0FBQ3hJLElBQUl3UyxPQUFPO0FBQ1gsTUFBTUMsT0FBTyxDQUFDO0VBQ1YxUixXQUFXQSxDQUFBLEVBQUc7SUFDVjtJQUNBdUosWUFBWSxDQUFDLElBQUksRUFBRWtJLE9BQU8sQ0FBQztJQUMzQjlILFlBQVksQ0FBQyxJQUFJLEVBQUU4SCxPQUFPLEVBQUUsQ0FBQyxDQUFDLENBQUM7RUFDbkM7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSS9HLEVBQUVBLENBQUNzQyxJQUFJLEVBQUUyRSxRQUFRLEVBQUVDLEdBQUcsRUFBRTtJQUFBLElBQUFDLFlBQUE7SUFDcEIsSUFBTUMsTUFBTSxHQUFHMUksWUFBWSxDQUFDLElBQUksRUFBRXFJLE9BQU8sQ0FBQztJQUMxQyxJQUFNTSxRQUFRLElBQUFGLFlBQUEsR0FBR0MsTUFBTSxDQUFDOUUsSUFBSSxDQUFDLGNBQUE2RSxZQUFBLGNBQUFBLFlBQUEsR0FBS0MsTUFBTSxDQUFDOUUsSUFBSSxDQUFDLEdBQUcsRUFBRztJQUNwRCtFLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDO01BQ1ZDLEVBQUUsRUFBRU4sUUFBUTtNQUNaQztJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU8sSUFBSTtFQUNmO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJN0csR0FBR0EsQ0FBQ2lDLElBQUksRUFBRTJFLFFBQVEsRUFBRTtJQUNoQixJQUFNRyxNQUFNLEdBQUcxSSxZQUFZLENBQUMsSUFBSSxFQUFFcUksT0FBTyxDQUFDO0lBQzFDLElBQU1NLFFBQVEsR0FBR0QsTUFBTSxDQUFDOUUsSUFBSSxDQUFDO0lBQzdCLElBQU1rRixVQUFVLEdBQUcsRUFBRTtJQUNyQixJQUFJSCxRQUFRLElBQUlKLFFBQVEsRUFBRTtNQUN0Qk8sVUFBVSxDQUFDRixJQUFJLENBQUMsR0FBR0QsUUFBUSxDQUFDNUwsTUFBTSxDQUFFakIsS0FBSyxJQUFLQSxLQUFLLENBQUMrTSxFQUFFLEtBQUtOLFFBQVEsQ0FBQyxDQUFDO0lBQ3pFO0lBQ0EsSUFBSU8sVUFBVSxDQUFDOU8sTUFBTSxFQUFFO01BQ25CME8sTUFBTSxDQUFDOUUsSUFBSSxDQUFDLEdBQUdrRixVQUFVO0lBQzdCLENBQUMsTUFDSTtNQUNELE9BQU9KLE1BQU0sQ0FBQzlFLElBQUksQ0FBQztJQUN2QjtJQUNBLE9BQU8sSUFBSTtFQUNmO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJN0IsSUFBSUEsQ0FBQzZCLElBQUksRUFBVztJQUFBLElBQUFtRixnQkFBQTtJQUFBLFNBQUFDLElBQUEsR0FBQTlCLFNBQUEsQ0FBQWxOLE1BQUEsRUFBTnNDLElBQUksT0FBQTJKLEtBQUEsQ0FBQStDLElBQUEsT0FBQUEsSUFBQSxXQUFBQyxJQUFBLE1BQUFBLElBQUEsR0FBQUQsSUFBQSxFQUFBQyxJQUFBO01BQUozTSxJQUFJLENBQUEyTSxJQUFBLFFBQUEvQixTQUFBLENBQUErQixJQUFBO0lBQUE7SUFDZCxJQUFNTixRQUFRLEdBQUcsRUFBQUksZ0JBQUEsR0FBQy9JLFlBQVksQ0FBQyxJQUFJLEVBQUVxSSxPQUFPLENBQUMsQ0FBQ3pFLElBQUksQ0FBQyxjQUFBbUYsZ0JBQUEsY0FBQUEsZ0JBQUEsR0FBSSxFQUFFLEVBQUUzQyxLQUFLLENBQUMsQ0FBQztJQUNsRXVDLFFBQVEsQ0FBQzNMLE9BQU8sQ0FBRWxCLEtBQUssSUFBSztNQUN4QkEsS0FBSyxDQUFDK00sRUFBRSxDQUFDN0IsS0FBSyxDQUFDbEwsS0FBSyxDQUFDME0sR0FBRyxFQUFFbE0sSUFBSSxDQUFDO0lBQ25DLENBQUMsQ0FBQztJQUNGLE9BQU8sSUFBSTtFQUNmO0FBQ0o7QUFDQStMLE9BQU8sR0FBRyxJQUFJekcsT0FBTyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ3ZFdkIsSUFBSTVLLFNBQVMsR0FBR3JCLE1BQU0sQ0FBQ0MsY0FBYztBQUNyQyxJQUFJcUIsZUFBZSxHQUFHQSxDQUFDQyxHQUFHLEVBQUVDLEdBQUcsRUFBRXRCLEtBQUssS0FBS3NCLEdBQUcsSUFBSUQsR0FBRyxHQUFHRixTQUFTLENBQUNFLEdBQUcsRUFBRUMsR0FBRyxFQUFFO0VBQUVyQixVQUFVLEVBQUUsSUFBSTtFQUFFQyxZQUFZLEVBQUUsSUFBSTtFQUFFQyxRQUFRLEVBQUUsSUFBSTtFQUFFSDtBQUFNLENBQUMsQ0FBQyxHQUFHcUIsR0FBRyxDQUFDQyxHQUFHLENBQUMsR0FBR3RCLEtBQUs7QUFDL0osSUFBSXVCLGFBQWEsR0FBR0EsQ0FBQ0YsR0FBRyxFQUFFQyxHQUFHLEVBQUV0QixLQUFLLEtBQUtvQixlQUFlLENBQUNDLEdBQUcsRUFBRSxPQUFPQyxHQUFHLEtBQUssUUFBUSxHQUFHQSxHQUFHLEdBQUcsRUFBRSxHQUFHQSxHQUFHLEVBQUV0QixLQUFLLENBQUM7QUFDOUcsTUFBTW1PLFVBQVUsU0FBU3RGLEtBQUssQ0FBQztFQUMzQjlILFdBQVdBLENBQUM4RixLQUFLLEVBQUU7SUFDZixLQUFLLENBQUNBLEtBQUssQ0FBQ3dNLE9BQU8sQ0FBQztJQUNwQjlSLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO0lBQzVCQSxhQUFhLENBQUMsSUFBSSxFQUFFLG1CQUFtQixDQUFDO0lBQ3hDLElBQUksQ0FBQ3NGLEtBQUssR0FBR0EsS0FBSyxDQUFDQSxLQUFLO0lBQ3hCLElBQUksQ0FBQ21JLGlCQUFpQixHQUFHbkksS0FBSyxDQUFDbUksaUJBQWlCO0lBQ2hELElBQUksQ0FBQ2pCLElBQUksR0FBRyxZQUFZO0VBQzVCO0FBQ0o7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaeUQ7QUFDUDtBQUNBO0FBQ1c7QUFDdEI7QUFDQztBQUNMO0FBQ2M7QUFDakQsSUFBSTVNLFNBQVMsR0FBR3JCLE1BQU0sQ0FBQ0MsY0FBYztBQUNyQyxJQUFJK0osV0FBVyxHQUFJQyxHQUFHLElBQUs7RUFDdkIsTUFBTXJKLFNBQVMsQ0FBQ3FKLEdBQUcsQ0FBQztBQUN4QixDQUFDO0FBQ0QsSUFBSTNJLGVBQWUsR0FBR0EsQ0FBQ0MsR0FBRyxFQUFFQyxHQUFHLEVBQUV0QixLQUFLLEtBQUtzQixHQUFHLElBQUlELEdBQUcsR0FBR0YsU0FBUyxDQUFDRSxHQUFHLEVBQUVDLEdBQUcsRUFBRTtFQUFFckIsVUFBVSxFQUFFLElBQUk7RUFBRUMsWUFBWSxFQUFFLElBQUk7RUFBRUMsUUFBUSxFQUFFLElBQUk7RUFBRUg7QUFBTSxDQUFDLENBQUMsR0FBR3FCLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDLEdBQUd0QixLQUFLO0FBQy9KLElBQUl1QixhQUFhLEdBQUdBLENBQUNGLEdBQUcsRUFBRUMsR0FBRyxFQUFFdEIsS0FBSyxLQUFLb0IsZUFBZSxDQUFDQyxHQUFHLEVBQUUsT0FBT0MsR0FBRyxLQUFLLFFBQVEsR0FBR0EsR0FBRyxHQUFHLEVBQUUsR0FBR0EsR0FBRyxFQUFFdEIsS0FBSyxDQUFDO0FBQzlHLElBQUlnSyxhQUFhLEdBQUdBLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUVGLEdBQUcsS0FBS0UsTUFBTSxDQUFDQyxHQUFHLENBQUM3SSxHQUFHLENBQUMsSUFBSXlJLFdBQVcsQ0FBQyxTQUFTLEdBQUdDLEdBQUcsQ0FBQztBQUN6RixJQUFJSSxZQUFZLEdBQUdBLENBQUM5SSxHQUFHLEVBQUU0SSxNQUFNLEVBQUVHLE1BQU0sTUFBTUosYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHlCQUF5QixDQUFDLEVBQUVHLE1BQU0sR0FBR0EsTUFBTSxDQUFDM0osSUFBSSxDQUFDWSxHQUFHLENBQUMsR0FBRzRJLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDaEosR0FBRyxDQUFDLENBQUM7QUFDaEosSUFBSWlKLFlBQVksR0FBR0EsQ0FBQ2pKLEdBQUcsRUFBRTRJLE1BQU0sRUFBRWpLLEtBQUssS0FBS2lLLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDN0ksR0FBRyxDQUFDLEdBQUd5SSxXQUFXLENBQUMsbURBQW1ELENBQUMsR0FBR0csTUFBTSxZQUFZTSxPQUFPLEdBQUdOLE1BQU0sQ0FBQ08sR0FBRyxDQUFDbkosR0FBRyxDQUFDLEdBQUc0SSxNQUFNLENBQUNRLEdBQUcsQ0FBQ3BKLEdBQUcsRUFBRXJCLEtBQUssQ0FBQztBQUNwTSxJQUFJMEssWUFBWSxHQUFHQSxDQUFDckosR0FBRyxFQUFFNEksTUFBTSxFQUFFakssS0FBSyxFQUFFMkssTUFBTSxNQUFNWCxhQUFhLENBQUMzSSxHQUFHLEVBQUU0SSxNQUFNLEVBQUUsd0JBQXdCLENBQUMsRUFBRUEsTUFBTSxDQUFDUSxHQUFHLENBQUNwSixHQUFHLEVBQUVyQixLQUFLLENBQUMsRUFBRUEsS0FBSyxDQUFDO0FBQ3hJLElBQUk0SyxlQUFlLEdBQUdBLENBQUN2SixHQUFHLEVBQUU0SSxNQUFNLEVBQUVZLE1BQU0sTUFBTWIsYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHVCQUF1QixDQUFDLEVBQUVZLE1BQU0sQ0FBQztBQUM1RyxJQUFJdUIsUUFBUSxFQUFFcUgsVUFBVSxFQUFFMUksUUFBUSxFQUFFMkksaUJBQWlCLEVBQUVDLGtDQUFrQyxFQUFFQyx1QkFBdUIsRUFBRUMsMEJBQTBCO0FBQzlJLE1BQU1sTSxZQUFZLENBQUM7RUFDZjVHLFdBQVdBLENBQUM2TCxPQUFPLEVBQUU7SUFDakJ0QyxZQUFZLENBQUMsSUFBSSxFQUFFc0osdUJBQXVCLENBQUM7SUFDM0N0SixZQUFZLENBQUMsSUFBSSxFQUFFOEIsUUFBUSxDQUFDO0lBQzVCOUIsWUFBWSxDQUFDLElBQUksRUFBRW1KLFVBQVUsQ0FBQztJQUM5Qm5KLFlBQVksQ0FBQyxJQUFJLEVBQUVTLFFBQVEsQ0FBQztJQUM1QlQsWUFBWSxDQUFDLElBQUksRUFBRW9KLGlCQUFpQixDQUFDO0lBQ3JDO0lBQ0FwSixZQUFZLENBQUMsSUFBSSxFQUFFcUosa0NBQWtDLENBQUM7SUFDdERwUyxhQUFhLENBQUMsSUFBSSxFQUFFLGNBQWMsQ0FBQztJQUNuQ0EsYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7SUFDNUJBLGFBQWEsQ0FBQyxJQUFJLEVBQUUsa0JBQWtCLENBQUM7SUFDdkNtSixZQUFZLENBQUMsSUFBSSxFQUFFMEIsUUFBUSxFQUFBbEgsYUFBQTtNQUN2QjZILFNBQVMsRUFBRSxJQUFJO01BQ2ZPLGdCQUFnQixFQUFFLEVBQUU7TUFDcEJ3RyxZQUFZLEVBQUUsR0FBRztNQUNqQnhLLHNCQUFzQixFQUFFLEtBQUs7TUFDN0J5SyxZQUFZLEVBQUUsR0FBRztNQUNqQkMsb0JBQW9CLEVBQUU7SUFBSyxHQUN4QnBILE9BQU8sQ0FDYixDQUFDO0lBQ0ZsQyxZQUFZLENBQUMsSUFBSSxFQUFFK0ksVUFBVSxFQUFFO01BQzNCUSxZQUFZLEtBQUF2USxNQUFBLENBQUt5RyxZQUFZLENBQUMsSUFBSSxFQUFFaUMsUUFBUSxDQUFDLENBQUNsRCxNQUFNLGtCQUFlO01BQ25FZ0wsUUFBUSxLQUFBeFEsTUFBQSxDQUFLeUcsWUFBWSxDQUFDLElBQUksRUFBRWlDLFFBQVEsQ0FBQyxDQUFDbEQsTUFBTSxjQUFXO01BQzNEaUwsT0FBTyxLQUFBelEsTUFBQSxDQUFLeUcsWUFBWSxDQUFDLElBQUksRUFBRWlDLFFBQVEsQ0FBQyxDQUFDbEQsTUFBTTtJQUNuRCxDQUFDLENBQUM7SUFDRjJGLDBFQUF1QixDQUFDMUUsWUFBWSxDQUFDLElBQUksRUFBRWlDLFFBQVEsQ0FBQyxDQUFDOUMsc0JBQXNCLEVBQUVhLFlBQVksQ0FBQyxJQUFJLEVBQUVpQyxRQUFRLENBQUMsQ0FBQ2xELE1BQU0sQ0FBQztJQUNqSHdCLFlBQVksQ0FBQyxJQUFJLEVBQUVLLFFBQVEsRUFBRSxJQUFJMEgsZ0RBQU8sQ0FBQyxDQUFDLENBQUM7SUFDM0MsSUFBSSxDQUFDMkIsS0FBSyxHQUFHLElBQUliLDRDQUFLLENBQUNwSixZQUFZLENBQUMsSUFBSSxFQUFFaUMsUUFBUSxDQUFDLEVBQUVqQyxZQUFZLENBQUMsSUFBSSxFQUFFc0osVUFBVSxDQUFDLENBQUM7SUFDcEYsSUFBSSxDQUFDcEksWUFBWSxHQUFHLElBQUltSSwwREFBWSxDQUFDckosWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDcUosS0FBSyxDQUFDO0lBQzlFLElBQUksQ0FBQ3ZILGdCQUFnQixHQUFHLElBQUkxQiwyREFBZ0IsQ0FBQ2hCLFlBQVksQ0FBQyxJQUFJLEVBQUVZLFFBQVEsQ0FBQyxFQUFFLElBQUksQ0FBQ00sWUFBWSxDQUFDO0lBQzdGWCxZQUFZLENBQUMsSUFBSSxFQUFFZ0osaUJBQWlCLEVBQUUsSUFBSS9HLDJEQUFnQixDQUFDeEMsWUFBWSxDQUFDLElBQUksRUFBRWlDLFFBQVEsQ0FBQyxFQUFFakMsWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLEVBQUUsSUFBSSxDQUFDOEIsZ0JBQWdCLENBQUMsQ0FBQztJQUM5SW5DLFlBQVksQ0FBQyxJQUFJLEVBQUVpSixrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUM5RHhKLFlBQVksQ0FBQyxJQUFJLEVBQUV1SixpQkFBaUIsQ0FBQyxDQUFDNUcsS0FBSyxDQUFDLENBQUM7RUFDakQ7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNVdUgsdUJBQXVCQSxDQUFBLEVBQUc7SUFBQSxJQUFBQyxLQUFBO0lBQUEsT0FBQTdELGlCQUFBO01BQzVCLElBQUl0RyxZQUFZLENBQUNtSyxLQUFJLEVBQUVYLGtDQUFrQyxDQUFDLEVBQUU7UUFDeEQsT0FBT3hKLFlBQVksQ0FBQ21LLEtBQUksRUFBRVgsa0NBQWtDLENBQUM7TUFDakU7TUFDQWpKLFlBQVksQ0FBQzRKLEtBQUksRUFBRVgsa0NBQWtDLEVBQUUvSSxlQUFlLENBQUMwSixLQUFJLEVBQUVWLHVCQUF1QixFQUFFQywwQkFBMEIsQ0FBQyxDQUFDcFQsSUFBSSxDQUFDNlQsS0FBSSxDQUFDLENBQUNDLE9BQU8sQ0FBQyxNQUFNO1FBQ3ZKN0osWUFBWSxDQUFDNEosS0FBSSxFQUFFWCxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztNQUNsRSxDQUFDLENBQUMsQ0FBQztNQUNILE9BQU94SixZQUFZLENBQUNtSyxLQUFJLEVBQUVYLGtDQUFrQyxDQUFDO0lBQUM7RUFDbEU7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNVYSxVQUFVQSxDQUFBLEVBQUc7SUFBQSxJQUFBQyxNQUFBO0lBQUEsT0FBQWhFLGlCQUFBO01BQ2YsT0FBTyxPQUFPZ0UsTUFBSSxDQUFDSix1QkFBdUIsQ0FBQyxDQUFDLEVBQUU3SSxlQUFlO0lBQUM7RUFDbEU7QUFDSjtBQUNBWSxRQUFRLEdBQUcsSUFBSUwsT0FBTyxDQUFDLENBQUM7QUFDeEIwSCxVQUFVLEdBQUcsSUFBSTFILE9BQU8sQ0FBQyxDQUFDO0FBQzFCaEIsUUFBUSxHQUFHLElBQUlnQixPQUFPLENBQUMsQ0FBQztBQUN4QjJILGlCQUFpQixHQUFHLElBQUkzSCxPQUFPLENBQUMsQ0FBQztBQUNqQzRILGtDQUFrQyxHQUFHLElBQUk1SCxPQUFPLENBQUMsQ0FBQztBQUNsRDZILHVCQUF1QixHQUFHLElBQUlySixPQUFPLENBQUMsQ0FBQztBQUN2Q3NKLDBCQUEwQjtFQUFBLElBQUFwUyxJQUFBLEdBQUFnUCxpQkFBQSxDQUFHLGFBQWtCO0lBQzNDLElBQUk7TUFDQSxJQUFNN0MsU0FBUyxHQUFHLElBQUksQ0FBQ2YsZ0JBQWdCLENBQUNuQixZQUFZLENBQUMsQ0FBQztNQUN0RCxJQUFJa0MsU0FBUyxDQUFDcEMsZUFBZSxFQUFFO1FBQUEsSUFBQWtKLFVBQUE7UUFDM0IsTUFBTSxJQUFJLENBQUNOLEtBQUssQ0FBQ08sWUFBWSxDQUFDL0csU0FBUyxDQUFDckMsT0FBTyxFQUFFcUMsU0FBUyxDQUFDdEMsV0FBVyxDQUFDO1FBQ3ZFLElBQU1zSixVQUFVLEdBQUdDLFFBQVEsRUFBQUgsVUFBQSxHQUFDdkkseURBQVMsQ0FBQztVQUFFNEIsSUFBSSxFQUFFLE9BQU87VUFBRUMsYUFBYSxFQUFFO1FBQUssQ0FBQyxDQUFDLGNBQUEwRyxVQUFBLGNBQUFBLFVBQUEsR0FBSSxFQUFFLENBQUM7UUFDcEYsSUFBTUkscUJBQXFCLEdBQUdqSCxJQUFJLENBQUNDLEtBQUssQ0FBQ3ZHLElBQUksQ0FBQzZGLEdBQUcsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLEdBQUdRLFNBQVMsQ0FBQ3JDLE9BQU8sQ0FBQ3dKLFNBQVM7UUFDeEY7UUFDQTtRQUNBSCxVQUFVLElBQUlFLHFCQUFxQjtRQUFJO1FBQ25DRixVQUFVLEdBQUdoSCxTQUFTLENBQUNyQyxPQUFPLENBQUN5SixNQUFNLENBQUNDLEdBQUcsRUFBRTtVQUMzQyxJQUFJLENBQUM1SixZQUFZLENBQUM2SixLQUFLLENBQUMsQ0FBQztRQUM3QixDQUFDLE1BQ0k7VUFDRCxPQUFPdEgsU0FBUztRQUNwQjtNQUNKO01BQ0EsSUFBSXpCLHlEQUFTLENBQUM7UUFBRTRCLElBQUksRUFBRSxNQUFNO1FBQUVDLGFBQWEsRUFBRTtNQUFLLENBQUMsQ0FBQyxFQUFFO1FBQ2xELElBQU1oQyxNQUFNLFNBQVMsSUFBSSxDQUFDWCxZQUFZLENBQUM4SixTQUFTLENBQUM7VUFDN0NDLGlCQUFpQixFQUFFO1FBQ3ZCLENBQUMsQ0FBQztRQUNGLElBQUlwSixNQUFNLEVBQUU7VUFDUixPQUFPO1lBQ0hWLFdBQVcsRUFBRVUsTUFBTSxDQUFDVixXQUFXO1lBQy9CQyxPQUFPLEVBQUVTLE1BQU0sQ0FBQ1QsT0FBTztZQUN2QkMsZUFBZSxFQUFFO1VBQ3JCLENBQUM7UUFDTCxDQUFDLE1BQ0k7VUFDRDhILDREQUFZLENBQUM7WUFBRXZGLElBQUksRUFBRTtVQUFPLENBQUMsQ0FBQztRQUNsQztNQUNKO01BQ0EsT0FBTztRQUNIekMsV0FBVyxFQUFFLEtBQUssQ0FBQztRQUNuQkMsT0FBTyxFQUFFLEtBQUssQ0FBQztRQUNmQyxlQUFlLEVBQUU7TUFDckIsQ0FBQztJQUNMLENBQUMsQ0FDRCxPQUFPM0UsS0FBSyxFQUFFO01BQ1YsSUFBSUEsS0FBSyxZQUFZc0gsaURBQVUsSUFBSXRILEtBQUssQ0FBQ0EsS0FBSyxLQUFLLGdCQUFnQixFQUFFO1FBQ2pFeU0sNERBQVksQ0FBQztVQUFFdkYsSUFBSSxFQUFFO1FBQU8sQ0FBQyxDQUFDO1FBQzlCLE9BQU87VUFDSHpDLFdBQVcsRUFBRSxLQUFLLENBQUM7VUFDbkJDLE9BQU8sRUFBRSxLQUFLLENBQUM7VUFDZkMsZUFBZSxFQUFFO1FBQ3JCLENBQUM7TUFDTDtNQUNBLElBQUksQ0FBQ0gsWUFBWSxDQUFDNkosS0FBSyxDQUFDLENBQUM7TUFDekIsTUFBTXJPLEtBQUs7SUFDZjtFQUNKLENBQUM7RUFBQSxnQkFsRERnTiwwQkFBMEJBLENBQUE7SUFBQSxPQUFBcFMsSUFBQSxDQUFBMFAsS0FBQSxPQUFBRSxTQUFBO0VBQUE7QUFBQSxHQWtEekI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0s4QztBQUNvSDtBQUMzSDtBQUN4QyxJQUFJdkgsV0FBVyxHQUFJQyxHQUFHLElBQUs7RUFDdkIsTUFBTXJKLFNBQVMsQ0FBQ3FKLEdBQUcsQ0FBQztBQUN4QixDQUFDO0FBQ0QsSUFBSUMsYUFBYSxHQUFHQSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFRixHQUFHLEtBQUtFLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDN0ksR0FBRyxDQUFDLElBQUl5SSxXQUFXLENBQUMsU0FBUyxHQUFHQyxHQUFHLENBQUM7QUFDekYsSUFBSUksWUFBWSxHQUFHQSxDQUFDOUksR0FBRyxFQUFFNEksTUFBTSxFQUFFRyxNQUFNLE1BQU1KLGFBQWEsQ0FBQzNJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRSx5QkFBeUIsQ0FBQyxFQUFFRyxNQUFNLEdBQUdBLE1BQU0sQ0FBQzNKLElBQUksQ0FBQ1ksR0FBRyxDQUFDLEdBQUc0SSxNQUFNLENBQUNJLEdBQUcsQ0FBQ2hKLEdBQUcsQ0FBQyxDQUFDO0FBQ2hKLElBQUlpSixZQUFZLEdBQUdBLENBQUNqSixHQUFHLEVBQUU0SSxNQUFNLEVBQUVqSyxLQUFLLEtBQUtpSyxNQUFNLENBQUNDLEdBQUcsQ0FBQzdJLEdBQUcsQ0FBQyxHQUFHeUksV0FBVyxDQUFDLG1EQUFtRCxDQUFDLEdBQUdHLE1BQU0sWUFBWU0sT0FBTyxHQUFHTixNQUFNLENBQUNPLEdBQUcsQ0FBQ25KLEdBQUcsQ0FBQyxHQUFHNEksTUFBTSxDQUFDUSxHQUFHLENBQUNwSixHQUFHLEVBQUVyQixLQUFLLENBQUM7QUFDcE0sSUFBSTBLLFlBQVksR0FBR0EsQ0FBQ3JKLEdBQUcsRUFBRTRJLE1BQU0sRUFBRWpLLEtBQUssRUFBRTJLLE1BQU0sTUFBTVgsYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHdCQUF3QixDQUFDLEVBQUVBLE1BQU0sQ0FBQ1EsR0FBRyxDQUFDcEosR0FBRyxFQUFFckIsS0FBSyxDQUFDLEVBQUVBLEtBQUssQ0FBQztBQUN4SSxJQUFJNEssZUFBZSxHQUFHQSxDQUFDdkosR0FBRyxFQUFFNEksTUFBTSxFQUFFWSxNQUFNLE1BQU1iLGFBQWEsQ0FBQzNJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxFQUFFWSxNQUFNLENBQUM7QUFDNUcsSUFBSXVCLFFBQVEsRUFBRXFILFVBQVUsRUFBRTZCLG9CQUFvQixFQUFFQyxzQkFBc0IsRUFBRUMsb0JBQW9CLEVBQUVDLDBCQUEwQixFQUFFQyxnQkFBZ0IsRUFBRUMsbUJBQW1CO0FBQy9KLElBQU1DLG1CQUFtQixHQUFJWixNQUFNLElBQUs7RUFDcEMsSUFBTWEsV0FBVyxHQUFHYixNQUFNO0VBQzFCLE9BQU9LLDZEQUFhLENBQUNRLFdBQVcsQ0FBQyxJQUFJQSxXQUFXLENBQUNDLEdBQUcsS0FBSyxLQUFLLENBQUMsSUFBSUQsV0FBVyxDQUFDRSxTQUFTLEtBQUssS0FBSyxDQUFDLElBQUlGLFdBQVcsQ0FBQ0csR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJSCxXQUFXLENBQUNJLGVBQWUsS0FBSyxLQUFLLENBQUMsSUFBSUosV0FBVyxDQUFDSyxHQUFHLEtBQUssS0FBSyxDQUFDLElBQUlMLFdBQVcsQ0FBQ1osR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJWSxXQUFXLENBQUNNLGlCQUFpQixLQUFLLEtBQUssQ0FBQyxJQUFJTixXQUFXLENBQUNPLEdBQUcsS0FBSyxLQUFLLENBQUMsSUFBSVAsV0FBVyxDQUFDUSxHQUFHLEtBQUssS0FBSyxDQUFDLElBQUlSLFdBQVcsQ0FBQ1Msa0JBQWtCLEtBQUssS0FBSyxDQUFDLElBQUlULFdBQVcsQ0FBQ1UsR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJVixXQUFXLENBQUNXLEdBQUcsS0FBSyxLQUFLLENBQUMsSUFBSVgsV0FBVyxDQUFDWSxHQUFHLEtBQUssS0FBSyxDQUFDLElBQUlaLFdBQVcsQ0FBQ2EsR0FBRyxLQUFLLEtBQUssQ0FBQztBQUN4ZixDQUFDO0FBQ0QsSUFBTUMsYUFBYSxHQUFJdkMsS0FBSyxJQUFLO0VBQzdCLElBQU13QyxVQUFVLEdBQUd4QyxLQUFLO0VBQ3hCLE9BQU9pQiw2REFBYSxDQUFDdUIsVUFBVSxDQUFDLElBQUlBLFVBQVUsQ0FBQ3RMLFdBQVcsS0FBSyxLQUFLLENBQUMsSUFBSXNMLFVBQVUsQ0FBQ3pKLFNBQVMsS0FBSyxLQUFLLENBQUMsSUFBSXlKLFVBQVUsQ0FBQ3BOLE1BQU0sS0FBSyxLQUFLLENBQUMsSUFBSW9OLFVBQVUsQ0FBQ0MsU0FBUyxLQUFLLEtBQUssQ0FBQyxJQUFJakIsbUJBQW1CLENBQUNnQixVQUFVLENBQUM1QixNQUFNLENBQUM7QUFDek4sQ0FBQztBQUNELElBQU04QixlQUFlLEdBQUk5QixNQUFNLElBQUs7RUFDaEMsSUFBTWEsV0FBVyxHQUFHYixNQUFNO0VBQzFCLE9BQU9LLDZEQUFhLENBQUNRLFdBQVcsQ0FBQyxJQUFJQSxXQUFXLENBQUNrQixHQUFHLEtBQUssS0FBSyxDQUFDLElBQUlsQixXQUFXLENBQUNtQixPQUFPLEtBQUssS0FBSyxDQUFDLElBQUluQixXQUFXLENBQUNDLEdBQUcsS0FBSyxLQUFLLENBQUMsSUFBSUQsV0FBVyxDQUFDRSxTQUFTLEtBQUssS0FBSyxDQUFDLElBQUlGLFdBQVcsQ0FBQ0ssR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJTCxXQUFXLENBQUNaLEdBQUcsS0FBSyxLQUFLLENBQUMsSUFBSVksV0FBVyxDQUFDTSxpQkFBaUIsS0FBSyxLQUFLLENBQUMsSUFBSU4sV0FBVyxDQUFDb0IsR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJcEIsV0FBVyxDQUFDTyxHQUFHLEtBQUssS0FBSyxDQUFDLElBQUlQLFdBQVcsQ0FBQ1EsR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJUixXQUFXLENBQUNTLGtCQUFrQixLQUFLLEtBQUssQ0FBQyxJQUFJVCxXQUFXLENBQUM5SCxJQUFJLEtBQUssS0FBSyxDQUFDLElBQUk4SCxXQUFXLENBQUNxQixLQUFLLEtBQUssS0FBSyxDQUFDLElBQUlyQixXQUFXLENBQUNzQixrQkFBa0IsS0FBSyxLQUFLLENBQUMsSUFBSXRCLFdBQVcsQ0FBQ1csR0FBRyxLQUFLLEtBQUssQ0FBQyxJQUFJWCxXQUFXLENBQUN1QixXQUFXLEtBQUssS0FBSyxDQUFDLElBQUl2QixXQUFXLENBQUNhLEdBQUcsS0FBSyxLQUFLLENBQUM7QUFDcG1CLENBQUM7QUFDRCxJQUFNVyxTQUFTLEdBQUlqRCxLQUFLLElBQUs7RUFDekIsSUFBTXdDLFVBQVUsR0FBR3hDLEtBQUs7RUFDeEIsT0FBT2lCLDZEQUFhLENBQUN1QixVQUFVLENBQUMsSUFBSUEsVUFBVSxDQUFDekosU0FBUyxLQUFLLEtBQUssQ0FBQyxJQUFJeUosVUFBVSxDQUFDckwsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJcUwsVUFBVSxDQUFDcE4sTUFBTSxLQUFLLEtBQUssQ0FBQyxJQUFJc04sZUFBZSxDQUFDRixVQUFVLENBQUM1QixNQUFNLENBQUM7QUFDOUssQ0FBQztBQUNELElBQU1zQyw2QkFBNkIsR0FBSUMsUUFBUSxJQUFLO0VBQ2hELElBQU1DLGFBQWEsR0FBR0QsUUFBUTtFQUM5QixPQUFPbEMsNkRBQWEsQ0FBQ21DLGFBQWEsQ0FBQyxJQUFJQSxhQUFhLENBQUMzUSxLQUFLLEtBQUssS0FBSyxDQUFDLElBQUkyUSxhQUFhLENBQUN4SSxpQkFBaUIsS0FBSyxLQUFLLENBQUMsSUFBSXdJLGFBQWEsQ0FBQ3ZLLEtBQUssS0FBSyxLQUFLLENBQUM7QUFDekosQ0FBQztBQUNELElBQU13Syx5QkFBeUIsR0FBSUYsUUFBUSxJQUFLO0VBQzVDLElBQU1DLGFBQWEsR0FBR0QsUUFBUTtFQUM5QixPQUFPbEMsNkRBQWEsQ0FBQ21DLGFBQWEsQ0FBQyxJQUFJQSxhQUFhLENBQUMzUSxLQUFLLEtBQUssS0FBSyxDQUFDLElBQUkyUSxhQUFhLENBQUN4SSxpQkFBaUIsS0FBSyxLQUFLLENBQUM7QUFDdkgsQ0FBQztBQUNELElBQU0wSSxrQkFBa0IsR0FBR0EsQ0FBQ3RLLEdBQUcsRUFBRWdILEtBQUssS0FBSztFQUN2QyxJQUFNO0lBQUVhO0VBQUksQ0FBQyxHQUFHMEMsV0FBVyxDQUFDdkQsS0FBSyxDQUFDLENBQUN2TyxPQUFPO0VBQzFDLElBQUksQ0FBQ29QLEdBQUcsRUFBRTtJQUNOLE1BQU0sSUFBSTlHLGlEQUFVLENBQUM7TUFDakJ0SCxLQUFLLEVBQUUsZUFBZTtNQUN0Qm1JLGlCQUFpQixFQUFFO0lBQ3ZCLENBQUMsQ0FBQztFQUNOO0VBQ0EsT0FBTzVCLEdBQUcsR0FBRzZILEdBQUc7QUFDcEIsQ0FBQztBQUNELElBQU0wQyxXQUFXLEdBQUl2RCxLQUFLLElBQUs7RUFDM0IsSUFBTSxDQUFDd0QsU0FBUyxFQUFFQyxVQUFVLEVBQUVDLFNBQVMsQ0FBQyxHQUFHMUQsS0FBSyxDQUFDckYsS0FBSyxDQUFDLEdBQUcsQ0FBQztFQUMzRCxJQUFJO0lBQ0EsSUFBSTZJLFNBQVMsS0FBSyxLQUFLLENBQUMsSUFBSUMsVUFBVSxLQUFLLEtBQUssQ0FBQyxJQUFJQyxTQUFTLEtBQUssS0FBSyxDQUFDLEVBQUU7TUFDdkUsTUFBTSxxQkFBcUI7SUFDL0I7SUFDQSxJQUFNQyxNQUFNLEdBQUdDLElBQUksQ0FBQ0MsS0FBSyxDQUFDcEcsNkRBQWlCLENBQUMrRixTQUFTLENBQUMsQ0FBQztJQUN2RCxJQUFNL1IsT0FBTyxHQUFHbVMsSUFBSSxDQUFDQyxLQUFLLENBQUNwRyw2REFBaUIsQ0FBQ2dHLFVBQVUsQ0FBQyxDQUFDO0lBQ3pELElBQUksQ0FBQ0UsTUFBTSxDQUFDRyxHQUFHLElBQUksQ0FBQ0gsTUFBTSxDQUFDSSxHQUFHLEVBQUU7TUFDNUIsTUFBTSw2QkFBNkI7SUFDdkM7SUFDQSxJQUFJLENBQUN0UyxPQUFPLENBQUN3USxHQUFHLEVBQUU7TUFDZCxNQUFNLDRCQUE0QjtJQUN0QztJQUNBLE9BQU87TUFDSDBCLE1BQU07TUFDTmxTLE9BQU87TUFDUGlTO0lBQ0osQ0FBQztFQUNMLENBQUMsQ0FDRCxPQUFPalIsS0FBSyxFQUFFO0lBQ1YsTUFBTSxJQUFJc0gsaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsaUJBQWlCO01BQ3BDcUUsT0FBTyxFQUFFeE07SUFDYixDQUFDLENBQUM7RUFDTjtBQUNKLENBQUM7QUFDRCxJQUFNdVIsWUFBWSxHQUFHM1csSUFBQSxJQUE0RjtFQUFBLElBQTNGO0lBQUU0VyxjQUFjO0lBQUVDLG9CQUFvQjtJQUFFQyxVQUFVO0lBQUVDLGdCQUFnQjtJQUFFdEIsS0FBSztJQUFFdEs7RUFBUSxDQUFDLEdBQUFuTCxJQUFBO0VBQ3hHLElBQU0yTCxHQUFHLEdBQUdTLElBQUksQ0FBQ0MsS0FBSyxDQUFDdkcsSUFBSSxDQUFDNkYsR0FBRyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUM7RUFDeEMsSUFBTXFMLGtCQUFrQixHQUFHZCxXQUFXLENBQUNVLGNBQWMsQ0FBQztFQUN0RCxJQUFNSyxrQkFBa0IsR0FBR0Qsa0JBQWtCLENBQUM1UyxPQUFPO0VBQ3JELElBQUksQ0FBQytQLG1CQUFtQixDQUFDOEMsa0JBQWtCLENBQUMsRUFBRTtJQUMxQyxNQUFNLElBQUl2SyxpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSw2QkFBNkI7TUFDaERxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQUl6RyxPQUFPLENBQUNvSCxvQkFBb0IsSUFBSW5HLElBQUksQ0FBQzhLLEdBQUcsQ0FBQ0wsb0JBQW9CLENBQUMsR0FBRzFMLE9BQU8sQ0FBQ2tILFlBQVksRUFBRTtJQUN2RixNQUFNLElBQUkzRixpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSxzQkFBc0I7TUFDekNxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQU0vSCxXQUFXLEdBQUc7SUFDaEJBLFdBQVcsRUFBRStNLGNBQWM7SUFDM0JyRCxNQUFNLEVBQUUwRCxrQkFBa0I7SUFDMUJ2TCxTQUFTLEVBQUV1TCxrQkFBa0IsQ0FBQ3hDLEdBQUcsR0FBR3dDLGtCQUFrQixDQUFDekQsR0FBRyxHQUFHN0gsR0FBRztJQUNoRTtJQUNBMkgsU0FBUyxFQUFFdUQsb0JBQW9CO0lBQy9CekIsU0FBUyxFQUFFLFFBQVE7SUFDbkJyTixNQUFNLEVBQUVrUCxrQkFBa0IsQ0FBQ25DO0VBQy9CLENBQUM7RUFDRCxJQUFJLENBQUNJLGFBQWEsQ0FBQ3JMLFdBQVcsQ0FBQyxFQUFFO0lBQzdCLE1BQU0sSUFBSTZDLGlEQUFVLENBQUM7TUFDakJ0SCxLQUFLLEVBQUUsZUFBZTtNQUN0Qm1JLGlCQUFpQixFQUFFLHNCQUFzQjtNQUN6Q3FFLE9BQU8sRUFBRTtJQUNiLENBQUMsQ0FBQztFQUNOO0VBQ0EsSUFBTXVGLGNBQWMsR0FBR2pCLFdBQVcsQ0FBQ1ksVUFBVSxDQUFDO0VBQzlDLElBQU1NLGNBQWMsR0FBR0QsY0FBYyxDQUFDL1MsT0FBTztFQUM3QyxJQUFJLENBQUNpUixlQUFlLENBQUMrQixjQUFjLENBQUMsRUFBRTtJQUNsQyxNQUFNLElBQUkxSyxpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSx5QkFBeUI7TUFDNUNxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQUl6RyxPQUFPLENBQUNvSCxvQkFBb0IsSUFBSW5HLElBQUksQ0FBQzhLLEdBQUcsQ0FBQ0gsZ0JBQWdCLENBQUMsR0FBRzVMLE9BQU8sQ0FBQ2tILFlBQVksRUFBRTtJQUNuRixNQUFNLElBQUkzRixpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSxrQkFBa0I7TUFDckNxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQU05SCxPQUFPLEdBQUc7SUFDWkEsT0FBTyxFQUFFZ04sVUFBVTtJQUNuQnJQLE1BQU0sRUFBRTBELE9BQU8sQ0FBQzFELE1BQU07SUFDdEJDLFFBQVEsRUFBRXlELE9BQU8sQ0FBQ3pELFFBQVE7SUFDMUI2TCxNQUFNLEVBQUU2RCxjQUFjO0lBQ3RCMUwsU0FBUyxFQUFFMEwsY0FBYyxDQUFDM0MsR0FBRyxHQUFHMkMsY0FBYyxDQUFDNUQsR0FBRyxHQUFHN0gsR0FBRztJQUN4RDtJQUNBMkgsU0FBUyxFQUFFeUQsZ0JBQWdCO0lBQzNCaFAsTUFBTSxFQUFFb0QsT0FBTyxDQUFDcEQsTUFBTTtJQUN0QjBOO0VBQ0osQ0FBQztFQUNELElBQUksQ0FBQ0csU0FBUyxDQUFDOUwsT0FBTyxDQUFDLEVBQUU7SUFDckIsTUFBTSxJQUFJNEMsaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsa0JBQWtCO01BQ3JDcUUsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPO0lBQ0gvSCxXQUFXO0lBQ1hDO0VBQ0osQ0FBQztBQUNMLENBQUM7QUFDRCxJQUFNdU4sbUJBQW1CLEdBQUdBLENBQUNDLE9BQU8sRUFBRS9ELE1BQU0sRUFBRXBJLE9BQU8sS0FBSztFQUN0RCxJQUFNb00sU0FBUyxHQUFHbkwsSUFBSSxDQUFDQyxLQUFLLENBQUN2RyxJQUFJLENBQUM2RixHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztFQUM5QyxJQUFNNkwsY0FBYyxHQUFHRCxTQUFTLEdBQUdELE9BQU8sQ0FBQ2hFLFNBQVM7RUFDcEQsSUFBSUMsTUFBTSxDQUFDa0MsS0FBSyxLQUFLNkIsT0FBTyxDQUFDN0IsS0FBSyxFQUFFO0lBQ2hDLE1BQU0sSUFBSS9JLGlEQUFVLENBQUM7TUFDakJ0SCxLQUFLLEVBQUUsZUFBZTtNQUN0Qm1JLGlCQUFpQixFQUFFLDJCQUEyQjtNQUM5Q3FFLE9BQU8sRUFBRTtJQUNiLENBQUMsQ0FBQztFQUNOO0VBQ0EsSUFBSTJCLE1BQU0sQ0FBQ29CLEdBQUcsS0FBS3hKLE9BQU8sQ0FBQzFELE1BQU0sRUFBRTtJQUMvQixNQUFNLElBQUlpRixpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSw0QkFBNEI7TUFDL0NxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQUkyQixNQUFNLENBQUNjLEdBQUcsS0FBS2xKLE9BQU8sQ0FBQ3pELFFBQVEsRUFBRTtJQUNqQyxNQUFNLElBQUlnRixpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSw4QkFBOEI7TUFDakRxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQUksQ0FBQzJCLE1BQU0sQ0FBQ0MsR0FBRyxFQUFFO0lBQ2IsTUFBTSxJQUFJOUcsaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsK0JBQStCO01BQ2xEcUUsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0VBQ047RUFDQSxJQUFJMkIsTUFBTSxDQUFDQyxHQUFHLEdBQUdnRSxjQUFjLEVBQUU7SUFDN0IsTUFBTSxJQUFJOUssaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsZ0NBQWdDO01BQ25EcUUsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0QsSUFBTTZGLDJCQUEyQjtFQUFBLElBQUExSCxLQUFBLEdBQUFmLGlCQUFBLENBQUcsV0FBT3VHLE9BQU8sRUFBRW1DLFlBQVksRUFBSztJQUNqRSxJQUFNQyxlQUFlLFNBQVM1SSw4REFBa0IsQ0FBQzJJLFlBQVksQ0FBQztJQUM5RCxJQUFNRSxrQkFBa0IsR0FBR0QsZUFBZSxDQUFDeEosU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7SUFDM0QsSUFBTTBKLHFCQUFxQixHQUFHM0gsMkRBQWUsQ0FBQzBILGtCQUFrQixDQUFDO0lBQ2pFLElBQUlDLHFCQUFxQixLQUFLdEMsT0FBTyxFQUFFO01BQ25DLE1BQU0sSUFBSTdJLGlEQUFVLENBQUM7UUFDakJ0SCxLQUFLLEVBQUUsZUFBZTtRQUN0Qm1JLGlCQUFpQixFQUFFLGVBQWU7UUFDbENxRSxPQUFPLEVBQUU7TUFDYixDQUFDLENBQUM7SUFDTjtJQUNBO0VBQ0osQ0FBQztFQUFBLGdCQVpLNkYsMkJBQTJCQSxDQUFBOUgsRUFBQSxFQUFBUSxHQUFBO0lBQUEsT0FBQUosS0FBQSxDQUFBTCxLQUFBLE9BQUFFLFNBQUE7RUFBQTtBQUFBLEdBWWhDO0FBQ0QsSUFBTWtJLGVBQWU7RUFBQSxJQUFBQyxLQUFBLEdBQUEvSSxpQkFBQSxDQUFHLFdBQU9nSixPQUFPLEVBQUVDLEdBQUcsRUFBRXRGLEtBQUssRUFBSztJQUNuRCxJQUFNdUYsWUFBWSxTQUFTQyxLQUFLLENBQUNILE9BQU8sQ0FBQztJQUN6QyxJQUFJLENBQUNFLFlBQVksQ0FBQ0UsRUFBRSxFQUFFO01BQ2xCLE1BQU0sSUFBSTFMLGlEQUFVLENBQUM7UUFDakJ0SCxLQUFLLEVBQUUsZ0JBQWdCO1FBQ3ZCbUksaUJBQWlCLEVBQUUsc0JBQXNCO1FBQ3pDcUUsT0FBTyxFQUFFO01BQ2IsQ0FBQyxDQUFDO0lBQ047SUFDQSxJQUFNeUcsSUFBSSxTQUFTSCxZQUFZLENBQUNJLElBQUksQ0FBQyxDQUFDO0lBQ3RDLElBQUksQ0FBQ0QsSUFBSSxDQUFDN1MsSUFBSSxJQUFJNlMsSUFBSSxDQUFDN1MsSUFBSSxDQUFDOUMsTUFBTSxLQUFLLENBQUMsRUFBRTtNQUN0QyxNQUFNLElBQUlnSyxpREFBVSxDQUFDO1FBQ2pCdEgsS0FBSyxFQUFFLGNBQWM7UUFDckJtSSxpQkFBaUIsRUFBRSx1QkFBdUI7UUFDMUNxRSxPQUFPLEVBQUU7TUFDYixDQUFDLENBQUM7SUFDTjtJQUNBLEtBQUssSUFBTTJHLElBQUksSUFBSUYsSUFBSSxDQUFDN1MsSUFBSSxFQUFFO01BQzFCLElBQUksQ0FBQytTLElBQUksQ0FBQ0MsR0FBRyxJQUFJLENBQUNELElBQUksQ0FBQ0UsQ0FBQyxJQUFJLENBQUNGLElBQUksQ0FBQ3JhLENBQUMsSUFBSSxDQUFDcWEsSUFBSSxDQUFDOUIsR0FBRyxJQUFJLENBQUM4QixJQUFJLENBQUNHLEdBQUcsSUFBSSxDQUFDSCxJQUFJLENBQUM3QixHQUFHLEVBQUU7UUFDeEUsTUFBTSxJQUFJaEssaURBQVUsQ0FBQztVQUNqQnRILEtBQUssRUFBRSxjQUFjO1VBQ3JCbUksaUJBQWlCLEVBQUUscUJBQXFCO1VBQ3hDcUUsT0FBTyxFQUFFO1FBQ2IsQ0FBQyxDQUFDO01BQ047SUFDSjtJQUNBLElBQU0vUixHQUFHLEdBQUd3WSxJQUFJLENBQUM3UyxJQUFJLENBQUNyQyxJQUFJLENBQUV3VixDQUFDLElBQUtBLENBQUMsQ0FBQ2pDLEdBQUcsS0FBS3VCLEdBQUcsQ0FBQzNCLE1BQU0sQ0FBQ0ksR0FBRyxDQUFDO0lBQzNELElBQUk3VyxHQUFHLEtBQUssS0FBSyxDQUFDLEVBQUU7TUFDaEIsTUFBTSxJQUFJNk0saURBQVUsQ0FBQztRQUNqQnRILEtBQUssRUFBRSxjQUFjO1FBQ3JCbUksaUJBQWlCLEVBQUUsZ0NBQWdDO1FBQ25EcUUsT0FBTyxFQUFFO01BQ2IsQ0FBQyxDQUFDO0lBQ047SUFDQSxJQUFNZ0gsU0FBUyxHQUFHO01BQ2R0TSxJQUFJLEVBQUUsbUJBQW1CO01BQ3pCa0QsSUFBSSxFQUFFO1FBQUVsRCxJQUFJLEVBQUU7TUFBVTtJQUM1QixDQUFDO0lBQ0QsSUFBTXVNLFNBQVMsU0FBUzNSLE1BQU0sQ0FBQ3NILE1BQU0sQ0FBQ2EsTUFBTSxDQUFDeUosU0FBUyxDQUFDLEtBQUssRUFBRTtNQUMxRE4sR0FBRyxFQUFFM1ksR0FBRyxDQUFDMlksR0FBRztNQUNaQyxDQUFDLEVBQUU1WSxHQUFHLENBQUM0WSxDQUFDO01BQ1J2YSxDQUFDLEVBQUUyQixHQUFHLENBQUMzQixDQUFDO01BQ1J1WSxHQUFHLEVBQUU1VyxHQUFHLENBQUM0VyxHQUFHO01BQ1ppQyxHQUFHLEVBQUU3WSxHQUFHLENBQUM2WTtJQUNiLENBQUMsRUFBRUUsU0FBUyxFQUFFLElBQUksRUFBRSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0lBQy9CLElBQU0sQ0FBQ3RDLE1BQU0sRUFBRWxTLE9BQU8sRUFBRTJVLEdBQUcsQ0FBQyxHQUFHcEcsS0FBSyxDQUFDckYsS0FBSyxDQUFDLEdBQUcsQ0FBQztJQUMvQyxJQUFJZ0osTUFBTSxLQUFLLEtBQUssQ0FBQyxJQUFJbFMsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJMlUsR0FBRyxLQUFLLEtBQUssQ0FBQyxFQUFFO01BQzNELE1BQU0sSUFBSXJNLGlEQUFVLENBQUM7UUFDakJ0SCxLQUFLLEVBQUUsZUFBZTtRQUN0Qm1JLGlCQUFpQixFQUFFLGlCQUFpQjtRQUNwQ3FFLE9BQU8sRUFBRTtNQUNiLENBQUMsQ0FBQztJQUNOO0lBQ0EsSUFBTTVNLElBQUksTUFBQS9DLE1BQUEsQ0FBTXFVLE1BQU0sT0FBQXJVLE1BQUEsQ0FBSW1DLE9BQU8sQ0FBRTtJQUNuQyxJQUFNNFUsT0FBTyxTQUFTOVIsTUFBTSxDQUFDc0gsTUFBTSxDQUFDYSxNQUFNLENBQUM0SixNQUFNLENBQUNMLFNBQVMsRUFBRUMsU0FBUyxFQUFFakksMERBQWMsQ0FBQ1IsNkRBQWlCLENBQUMySSxHQUFHLENBQUMsQ0FBQyxFQUFFbkksMERBQWMsQ0FBQzVMLElBQUksQ0FBQyxDQUFDO0lBQ3JJLElBQUksQ0FBQ2dVLE9BQU8sRUFBRTtNQUNWLE1BQU0sSUFBSXRNLGlEQUFVLENBQUM7UUFDakJ0SCxLQUFLLEVBQUUsZUFBZTtRQUN0Qm1JLGlCQUFpQixFQUFFLG1CQUFtQjtRQUN0Q3FFLE9BQU8sRUFBRTtNQUNiLENBQUMsQ0FBQztJQUNOO0VBQ0osQ0FBQztFQUFBLGdCQTlES2tHLGVBQWVBLENBQUFvQixHQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQTtJQUFBLE9BQUFyQixLQUFBLENBQUFySSxLQUFBLE9BQUFFLFNBQUE7RUFBQTtBQUFBLEdBOERwQjtBQUNELElBQU15SiwyQkFBMkIsR0FBR0EsQ0FBQy9CLE9BQU8sRUFBRS9ELE1BQU0sS0FBSztFQUNyRCxJQUFNZ0UsU0FBUyxHQUFHbkwsSUFBSSxDQUFDQyxLQUFLLENBQUN2RyxJQUFJLENBQUM2RixHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztFQUM5QyxJQUFNNkwsY0FBYyxHQUFHRCxTQUFTLEdBQUdELE9BQU8sQ0FBQ2hFLFNBQVM7RUFDcEQsSUFBSSxDQUFDQyxNQUFNLENBQUNDLEdBQUcsSUFBSSxDQUFDRCxNQUFNLENBQUNrQixHQUFHLEVBQUU7SUFDNUIsTUFBTSxJQUFJL0gsaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsMENBQTBDO01BQzdEcUUsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0VBQ047RUFDQSxJQUFJMkIsTUFBTSxDQUFDQyxHQUFHLEdBQUdELE1BQU0sQ0FBQ2tCLEdBQUcsRUFBRTtJQUN6QixNQUFNLElBQUkvSCxpREFBVSxDQUFDO01BQ2pCdEgsS0FBSyxFQUFFLGVBQWU7TUFDdEJtSSxpQkFBaUIsRUFBRSw4Q0FBOEM7TUFDakVxRSxPQUFPLEVBQUU7SUFDYixDQUFDLENBQUM7RUFDTjtFQUNBLElBQUk0RixjQUFjLEdBQUdqRSxNQUFNLENBQUNrQixHQUFHLEVBQUU7SUFDN0IsTUFBTSxJQUFJL0gsaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsbUJBQW1CO01BQ3RDcUUsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0VBQ047RUFDQSxJQUFJMkIsTUFBTSxDQUFDQyxHQUFHLEdBQUdnRSxjQUFjLEVBQUU7SUFDN0IsTUFBTSxJQUFJOUssaURBQVUsQ0FBQztNQUNqQnRILEtBQUssRUFBRSxlQUFlO01BQ3RCbUksaUJBQWlCLEVBQUUsZ0NBQWdDO01BQ25EcUUsT0FBTyxFQUFFO0lBQ2IsQ0FBQyxDQUFDO0VBQ047QUFDSixDQUFDO0FBQ0QsSUFBTTBILHNCQUFzQixHQUFHQSxDQUFDQyxJQUFJLEVBQUUvTixLQUFLLEtBQUs7RUFDNUMsSUFBSWdPLGVBQWU7RUFDbkIsSUFBSUMsU0FBUztFQUNiLElBQU1DLG9CQUFvQixHQUFHLElBQUlDLE9BQU8sQ0FBQyxDQUFDQyxPQUFPLEVBQUVDLE1BQU0sS0FBSztJQUMxREwsZUFBZSxHQUFJdGIsQ0FBQyxJQUFLO01BQ3JCLElBQUlBLENBQUMsQ0FBQzhHLElBQUksQ0FBQ3dHLEtBQUssS0FBS0EsS0FBSyxFQUFFO1FBQ3hCO01BQ0o7TUFDQSxJQUFJdE4sQ0FBQyxDQUFDMEksTUFBTSxLQUFLMlMsSUFBSSxDQUFDOVIsTUFBTSxDQUFDNkYsS0FBSyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFO1FBQy9DLE9BQU91TSxNQUFNLENBQUMsSUFBSW5OLGlEQUFVLENBQUM7VUFDekJ0SCxLQUFLLEVBQUUsZ0JBQWdCO1VBQ3ZCbUksaUJBQWlCLEVBQUUsZ0JBQWdCO1VBQ25DcUUsT0FBTyxFQUFFO1FBQ2IsQ0FBQyxDQUFDLENBQUM7TUFDUDtNQUNBLE9BQU9nSSxPQUFPLENBQUMxYixDQUFDLENBQUM4RyxJQUFJLENBQUM7SUFDMUIsQ0FBQztJQUNEa0MsTUFBTSxDQUFDZ0YsZ0JBQWdCLENBQUMsU0FBUyxFQUFFc04sZUFBZSxDQUFDO0lBQ25EQyxTQUFTLEdBQUd2UyxNQUFNLENBQUM2RSxVQUFVLENBQUMsTUFBTTtNQUNoQyxPQUFPOE4sTUFBTSxDQUFDLElBQUluTixpREFBVSxDQUFDO1FBQ3pCdEgsS0FBSyxFQUFFLFNBQVM7UUFDaEJtSSxpQkFBaUIsRUFBRSxTQUFTO1FBQzVCcUUsT0FBTyxFQUFFO01BQ2IsQ0FBQyxDQUFDLENBQUM7SUFDUCxDQUFDLEVBQUUySCxJQUFJLENBQUNqSCxZQUFZLENBQUM7RUFDekIsQ0FBQyxDQUFDO0VBQ0YsT0FBT29ILG9CQUFvQixDQUFDNUcsT0FBTyxDQUFDLE1BQU07SUFDdEM1TCxNQUFNLENBQUN1RSxZQUFZLENBQUNnTyxTQUFTLENBQUM7SUFDOUJ2UyxNQUFNLENBQUM0UyxtQkFBbUIsQ0FBQyxTQUFTLEVBQUVOLGVBQWUsQ0FBQztFQUMxRCxDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0QsSUFBTU8sU0FBUyxHQUFJQyxHQUFHLElBQUs7RUFDdkIsSUFBTUMsS0FBSyxHQUFHak8sUUFBUSxDQUFDa08sYUFBYSxDQUFDLFFBQVEsQ0FBQztFQUM5Q0QsS0FBSyxDQUFDRSxLQUFLLENBQUNDLE9BQU8sR0FBRyxNQUFNO0VBQzVCSCxLQUFLLENBQUNJLEdBQUcsR0FBR0wsR0FBRztFQUNmLE9BQU9oTyxRQUFRLENBQUNzTyxJQUFJLENBQUNDLFdBQVcsQ0FBQ04sS0FBSyxDQUFDO0FBQzNDLENBQUM7QUFDRCxJQUFNTyx5QkFBeUI7RUFBQSxJQUFBQyxLQUFBLEdBQUF6TCxpQkFBQSxDQUFHLFdBQU8wTCxlQUFlLEVBQUV2UCxPQUFPLEVBQUV3UCxTQUFTLEVBQUs7SUFDN0UsSUFBTUMsWUFBWSxHQUFHLElBQUlDLGVBQWUsQ0FBQ0gsZUFBZSxDQUFDO0lBQ3pELElBQU1JLG1CQUFtQixHQUFHeEIsc0JBQXNCLENBQUNuTyxPQUFPLEVBQUV1UCxlQUFlLENBQUNsUCxLQUFLLENBQUM7SUFDbEYsSUFBTXVQLE1BQU0sR0FBR2hCLFNBQVMsSUFBQTlYLE1BQUEsQ0FBSTBZLFNBQVMsQ0FBQ25JLFlBQVksT0FBQXZRLE1BQUEsQ0FBSTJZLFlBQVksQ0FBQzFNLFFBQVEsQ0FBQyxDQUFDLENBQUUsQ0FBQztJQUNoRixJQUFNOE0saUJBQWlCLFNBQVNGLG1CQUFtQixDQUFDaEksT0FBTyxDQUFDLE1BQU07TUFDOUQsSUFBSTlHLFFBQVEsQ0FBQ3NPLElBQUksQ0FBQ1csUUFBUSxDQUFDRixNQUFNLENBQUMsRUFBRTtRQUNoQy9PLFFBQVEsQ0FBQ3NPLElBQUksQ0FBQ1ksV0FBVyxDQUFDSCxNQUFNLENBQUM7TUFDckM7SUFDSixDQUFDLENBQUM7SUFDRixPQUFPQyxpQkFBaUI7RUFDNUIsQ0FBQztFQUFBLGdCQVZLUix5QkFBeUJBLENBQUFXLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxHQUFBO0lBQUEsT0FBQVosS0FBQSxDQUFBL0ssS0FBQSxPQUFBRSxTQUFBO0VBQUE7QUFBQSxHQVU5QjtBQUNELElBQU0wTCxvQkFBb0IsR0FBRyxlQUFnQixJQUFJQyxHQUFHLENBQUMsQ0FBQztBQUN0RCxJQUFNckksWUFBWTtFQUFBLElBQUFzSSxLQUFBLEdBQUF4TSxpQkFBQSxDQUFHLFdBQU9sRixPQUFPLEVBQUVELFdBQVcsRUFBRXNCLE9BQU8sRUFBRXdQLFNBQVMsRUFBSztJQUNyRSxJQUFJVyxvQkFBb0IsQ0FBQzdTLEdBQUcsQ0FBQ3FCLE9BQU8sQ0FBQ3lKLE1BQU0sQ0FBQ3FCLEdBQUcsQ0FBQyxFQUFFO01BQzlDLElBQU02RyxRQUFRLEdBQUdILG9CQUFvQixDQUFDMVMsR0FBRyxDQUFDa0IsT0FBTyxDQUFDeUosTUFBTSxDQUFDcUIsR0FBRyxDQUFDO01BQzdELElBQUk2RyxRQUFRLEtBQUssSUFBSSxFQUFFO1FBQ25CO01BQ0o7TUFDQSxNQUFNQSxRQUFRO0lBQ2xCO0lBQ0EsSUFBSTtNQUNBLElBQU1DLFVBQVUsR0FBR3hGLFdBQVcsQ0FBQ3BNLE9BQU8sQ0FBQ0EsT0FBTyxDQUFDO01BQy9DdU4sbUJBQW1CLENBQUN2TixPQUFPLEVBQUU0UixVQUFVLENBQUN0WCxPQUFPLEVBQUUrRyxPQUFPLENBQUM7TUFDekQsTUFBTTJNLGVBQWUsQ0FBQzZDLFNBQVMsQ0FBQ2pJLE9BQU8sRUFBRWdKLFVBQVUsRUFBRTVSLE9BQU8sQ0FBQ0EsT0FBTyxDQUFDO01BQ3JFLE1BQU0yTiwyQkFBMkIsQ0FBQzNOLE9BQU8sQ0FBQ3lKLE1BQU0sQ0FBQ2dDLE9BQU8sRUFBRTFMLFdBQVcsQ0FBQ0EsV0FBVyxDQUFDO01BQ2xGLElBQU04UixjQUFjLEdBQUd6RixXQUFXLENBQUNyTSxXQUFXLENBQUNBLFdBQVcsQ0FBQztNQUMzRHdQLDJCQUEyQixDQUFDeFAsV0FBVyxFQUFFOFIsY0FBYyxDQUFDdlgsT0FBTyxDQUFDO01BQ2hFa1gsb0JBQW9CLENBQUN0UyxHQUFHLENBQUNjLE9BQU8sQ0FBQ3lKLE1BQU0sQ0FBQ3FCLEdBQUcsRUFBRSxJQUFJLENBQUM7SUFDdEQsQ0FBQyxDQUNELE9BQU94UCxLQUFLLEVBQUU7TUFDVmtXLG9CQUFvQixDQUFDdFMsR0FBRyxDQUFDYyxPQUFPLENBQUN5SixNQUFNLENBQUNxQixHQUFHLEVBQUV4UCxLQUFLLENBQUM7TUFDbkQsTUFBTUEsS0FBSztJQUNmO0VBQ0osQ0FBQztFQUFBLGdCQXJCSzhOLFlBQVlBLENBQUEwSSxHQUFBLEVBQUFDLEdBQUEsRUFBQUMsR0FBQSxFQUFBQyxJQUFBO0lBQUEsT0FBQVAsS0FBQSxDQUFBOUwsS0FBQSxPQUFBRSxTQUFBO0VBQUE7QUFBQSxHQXFCakI7QUFDRCxJQUFNb00scUJBQXFCO0VBQUEsSUFBQUMsS0FBQSxHQUFBak4saUJBQUEsQ0FBRyxXQUFPa04sSUFBSSxFQUFFbE0sWUFBWSxFQUFFN0UsT0FBTyxFQUFFd1AsU0FBUyxFQUFLO0lBQzVFLElBQU13QixXQUFXLEdBQUc7TUFDaEJDLFNBQVMsRUFBRWpSLE9BQU8sQ0FBQ3pELFFBQVE7TUFDM0J3VSxJQUFJO01BQ0pHLGFBQWEsRUFBRXJNLFlBQVk7TUFDM0JzTSxVQUFVLEVBQUUsb0JBQW9CO01BQ2hDQyxZQUFZLEVBQUVwUixPQUFPLENBQUN4RDtJQUMxQixDQUFDO0lBQ0QsSUFBTW1PLFFBQVEsU0FBU3FDLEtBQUssQ0FBQ3dDLFNBQVMsQ0FBQ2xJLFFBQVEsRUFBRTtNQUM3Q3JKLE1BQU0sRUFBRSxNQUFNO01BQ2RrUixJQUFJLEVBQUUsSUFBSU8sZUFBZSxDQUFDc0IsV0FBVyxDQUFDO01BQ3RDSyxPQUFPLEVBQUU7UUFDTCxjQUFjLEVBQUU7TUFDcEI7SUFDSixDQUFDLENBQUM7SUFDRixPQUFPMUcsUUFBUSxDQUFDd0MsSUFBSSxDQUFDLENBQUM7RUFDMUIsQ0FBQztFQUFBLGdCQWhCSzBELHFCQUFxQkEsQ0FBQVMsSUFBQSxFQUFBQyxJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQTtJQUFBLE9BQUFYLEtBQUEsQ0FBQXZNLEtBQUEsT0FBQUUsU0FBQTtFQUFBO0FBQUEsR0FnQjFCO0FBQ0QsSUFBTWlOLG1CQUFtQjtFQUFBLElBQUFDLEtBQUEsR0FBQTlOLGlCQUFBLENBQUcsV0FBTytOLGtCQUFrQixFQUFFckMsZUFBZSxFQUFFdlAsT0FBTyxFQUFFd1AsU0FBUyxFQUFLO0lBQzNGLElBQU07TUFBRWpELFlBQVk7TUFBRXNGO0lBQVMsQ0FBQyxHQUFHRCxrQkFBa0I7SUFDckQsSUFBTXBSLEdBQUcsR0FBR1MsSUFBSSxDQUFDQyxLQUFLLENBQUN2RyxJQUFJLENBQUM2RixHQUFHLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQztJQUN4QyxJQUFNa0wsb0JBQW9CLEdBQUdaLGtCQUFrQixDQUFDdEssR0FBRyxFQUFFK0wsWUFBWSxDQUFDO0lBQ2xFLElBQU1YLGdCQUFnQixHQUFHZCxrQkFBa0IsQ0FBQ3RLLEdBQUcsRUFBRXFSLFFBQVEsQ0FBQztJQUMxRCxJQUFNO01BQUVuVCxXQUFXO01BQUVDO0lBQVEsQ0FBQyxHQUFHNk0sWUFBWSxDQUFDO01BQzFDQyxjQUFjLEVBQUVjLFlBQVk7TUFDNUJiLG9CQUFvQjtNQUNwQkMsVUFBVSxFQUFFa0csUUFBUTtNQUNwQmpHLGdCQUFnQjtNQUNoQnRCLEtBQUssRUFBRWlGLGVBQWUsQ0FBQ2pGLEtBQUs7TUFDNUJ0SztJQUNKLENBQUMsQ0FBQztJQUNGLE1BQU0rSCxZQUFZLENBQUNwSixPQUFPLEVBQUVELFdBQVcsRUFBRXNCLE9BQU8sRUFBRXdQLFNBQVMsQ0FBQztJQUM1RCxPQUFPO01BQ0huUCxLQUFLLEVBQUVrUCxlQUFlLENBQUNsUCxLQUFLO01BQzVCakIsTUFBTSxFQUFFO1FBQ0pWLFdBQVc7UUFDWEM7TUFDSjtJQUNKLENBQUM7RUFDTCxDQUFDO0VBQUEsZ0JBckJLK1MsbUJBQW1CQSxDQUFBSSxJQUFBLEVBQUFDLElBQUEsRUFBQUMsSUFBQSxFQUFBQyxJQUFBO0lBQUEsT0FBQU4sS0FBQSxDQUFBcE4sS0FBQSxPQUFBRSxTQUFBO0VBQUE7QUFBQSxHQXFCeEI7QUFDRCxNQUFNa0MsS0FBSyxDQUFDO0VBQ1J4UyxXQUFXQSxDQUFDNkwsT0FBTyxFQUFFd1AsU0FBUyxFQUFFO0lBQzVCOVIsWUFBWSxDQUFDLElBQUksRUFBRW9MLGdCQUFnQixDQUFDO0lBQ3BDcEwsWUFBWSxDQUFDLElBQUksRUFBRThCLFFBQVEsQ0FBQztJQUM1QjlCLFlBQVksQ0FBQyxJQUFJLEVBQUVtSixVQUFVLENBQUM7SUFDOUI7SUFDQW5KLFlBQVksQ0FBQyxJQUFJLEVBQUVnTCxvQkFBb0IsQ0FBQztJQUN4Q2hMLFlBQVksQ0FBQyxJQUFJLEVBQUVpTCxzQkFBc0IsRUFBRSxDQUFDb0ksSUFBSSxFQUFFbE0sWUFBWSxLQUFLZ00scUJBQXFCLENBQUNFLElBQUksRUFBRWxNLFlBQVksRUFBRXRILFlBQVksQ0FBQyxJQUFJLEVBQUVpQyxRQUFRLENBQUMsRUFBRWpDLFlBQVksQ0FBQyxJQUFJLEVBQUVzSixVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQzNLbkosWUFBWSxDQUFDLElBQUksRUFBRWtMLG9CQUFvQixFQUFFLENBQUNnSixrQkFBa0IsRUFBRXJDLGVBQWUsS0FBS21DLG1CQUFtQixDQUFDRSxrQkFBa0IsRUFBRXJDLGVBQWUsRUFBRWhTLFlBQVksQ0FBQyxJQUFJLEVBQUVpQyxRQUFRLENBQUMsRUFBRWpDLFlBQVksQ0FBQyxJQUFJLEVBQUVzSixVQUFVLENBQUMsQ0FBQyxDQUFDO0lBQ3pNbkosWUFBWSxDQUFDLElBQUksRUFBRW1MLDBCQUEwQixFQUFHMEcsZUFBZSxJQUFLRix5QkFBeUIsQ0FBQ0UsZUFBZSxFQUFFaFMsWUFBWSxDQUFDLElBQUksRUFBRWlDLFFBQVEsQ0FBQyxFQUFFakMsWUFBWSxDQUFDLElBQUksRUFBRXNKLFVBQVUsQ0FBQyxDQUFDLENBQUM7SUFDN0svSSxZQUFZLENBQUMsSUFBSSxFQUFFMEIsUUFBUSxFQUFFUSxPQUFPLENBQUM7SUFDckNsQyxZQUFZLENBQUMsSUFBSSxFQUFFK0ksVUFBVSxFQUFFMkksU0FBUyxDQUFDO0lBQ3pDMVIsWUFBWSxDQUFDLElBQUksRUFBRTRLLG9CQUFvQixFQUFFLEtBQUssQ0FBQyxDQUFDO0VBQ3BEO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtFQUNVd0osZ0JBQWdCQSxDQUFBLEVBQUc7SUFBQSxJQUFBeEssS0FBQTtJQUFBLE9BQUE3RCxpQkFBQTtNQUNyQixJQUFJdEcsWUFBWSxDQUFDbUssS0FBSSxFQUFFZ0Isb0JBQW9CLENBQUMsRUFBRTtRQUMxQyxPQUFPbkwsWUFBWSxDQUFDbUssS0FBSSxFQUFFZ0Isb0JBQW9CLENBQUM7TUFDbkQ7TUFDQTVLLFlBQVksQ0FBQzRKLEtBQUksRUFBRWdCLG9CQUFvQixFQUFFMUssZUFBZSxDQUFDMEosS0FBSSxFQUFFb0IsZ0JBQWdCLEVBQUVDLG1CQUFtQixDQUFDLENBQUNsVixJQUFJLENBQUM2VCxLQUFJLENBQUMsQ0FBQ0MsT0FBTyxDQUFDLE1BQU07UUFDM0g3SixZQUFZLENBQUM0SixLQUFJLEVBQUVnQixvQkFBb0IsRUFBRSxLQUFLLENBQUMsQ0FBQztNQUNwRCxDQUFDLENBQUMsQ0FBQztNQUNILE9BQU9uTCxZQUFZLENBQUNtSyxLQUFJLEVBQUVnQixvQkFBb0IsQ0FBQztJQUFDO0VBQ3BEO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNVWCxZQUFZQSxDQUFDcEosT0FBTyxFQUFFRCxXQUFXLEVBQUU7SUFBQSxJQUFBbUosTUFBQTtJQUFBLE9BQUFoRSxpQkFBQTtNQUNyQyxPQUFPa0UsWUFBWSxDQUFDcEosT0FBTyxFQUFFRCxXQUFXLEVBQUVuQixZQUFZLENBQUNzSyxNQUFJLEVBQUVySSxRQUFRLENBQUMsRUFBRWpDLFlBQVksQ0FBQ3NLLE1BQUksRUFBRWhCLFVBQVUsQ0FBQyxDQUFDO0lBQUM7RUFDNUc7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJMkUsWUFBWUEsQ0FBQTJHLEtBQUEsRUFBZ0Y7SUFBQSxJQUEvRTtNQUFFMUcsY0FBYztNQUFFQyxvQkFBb0I7TUFBRUMsVUFBVTtNQUFFQyxnQkFBZ0I7TUFBRXRCO0lBQU0sQ0FBQyxHQUFBNkgsS0FBQTtJQUN0RixPQUFPM0csWUFBWSxDQUFDO01BQ2hCQyxjQUFjO01BQ2RDLG9CQUFvQjtNQUNwQkMsVUFBVTtNQUNWQyxnQkFBZ0I7TUFDaEJ0QixLQUFLO01BQ0x0SyxPQUFPLEVBQUV6QyxZQUFZLENBQUMsSUFBSSxFQUFFaUMsUUFBUTtJQUN4QyxDQUFDLENBQUM7RUFDTjtBQUNKO0FBQ0FBLFFBQVEsR0FBRyxJQUFJTCxPQUFPLENBQUMsQ0FBQztBQUN4QjBILFVBQVUsR0FBRyxJQUFJMUgsT0FBTyxDQUFDLENBQUM7QUFDMUJ1SixvQkFBb0IsR0FBRyxJQUFJdkosT0FBTyxDQUFDLENBQUM7QUFDcEN3SixzQkFBc0IsR0FBRyxJQUFJeEosT0FBTyxDQUFDLENBQUM7QUFDdEN5SixvQkFBb0IsR0FBRyxJQUFJekosT0FBTyxDQUFDLENBQUM7QUFDcEMwSiwwQkFBMEIsR0FBRyxJQUFJMUosT0FBTyxDQUFDLENBQUM7QUFDMUMySixnQkFBZ0IsR0FBRyxJQUFJbkwsT0FBTyxDQUFDLENBQUM7QUFDaENvTCxtQkFBbUI7RUFBQSxJQUFBcUosS0FBQSxHQUFBdk8saUJBQUEsQ0FBRyxhQUFrQjtJQUNwQyxJQUFNZ0IsWUFBWSxHQUFHSCxnRUFBb0IsQ0FBQyxDQUFDO0lBQzNDLElBQU0yTixhQUFhLFNBQVMxTixpRUFBcUIsQ0FBQ0UsWUFBWSxDQUFDO0lBQy9ELElBQU0wSyxlQUFlLEdBQUc7TUFDcEIwQixTQUFTLEVBQUUxVCxZQUFZLENBQUMsSUFBSSxFQUFFaUMsUUFBUSxDQUFDLENBQUNqRCxRQUFRO01BQ2hEK1YsY0FBYyxFQUFFRCxhQUFhO01BQzdCRSxxQkFBcUIsRUFBRSxNQUFNO01BQzdCQyxNQUFNLEVBQUUsTUFBTTtNQUNkbEksS0FBSyxFQUFFckgsMkRBQWUsQ0FBQyxFQUFFLENBQUM7TUFDMUJtTyxZQUFZLEVBQUU3VCxZQUFZLENBQUMsSUFBSSxFQUFFaUMsUUFBUSxDQUFDLENBQUNoRCxXQUFXO01BQ3REaVcsYUFBYSxFQUFFLE1BQU07TUFDckJDLGFBQWEsRUFBRSxtQkFBbUI7TUFDbENDLEtBQUssRUFBRXBWLFlBQVksQ0FBQyxJQUFJLEVBQUVpQyxRQUFRLENBQUMsQ0FBQzVDLE1BQU0sQ0FBQzhHLElBQUksQ0FBQyxHQUFHLENBQUM7TUFDcERyRCxLQUFLLEVBQUU0QywyREFBZSxDQUFDLEVBQUU7SUFDN0IsQ0FBQztJQUNELElBQU00TSxpQkFBaUIsU0FBU3RTLFlBQVksQ0FBQyxJQUFJLEVBQUVzTCwwQkFBMEIsQ0FBQyxDQUFDaFYsSUFBSSxDQUFDLElBQUksRUFBRTBiLGVBQWUsQ0FBQztJQUMxRyxJQUFJN0UsNkJBQTZCLENBQUNtRixpQkFBaUIsQ0FBQyxFQUFFO01BQ2xELE1BQU0sSUFBSXRPLGlEQUFVLENBQUM7UUFDakJ0SCxLQUFLLEVBQUU0VixpQkFBaUIsQ0FBQzVWLEtBQUs7UUFDOUJtSSxpQkFBaUIsRUFBRXlOLGlCQUFpQixDQUFDek4saUJBQWlCO1FBQ3REcUUsT0FBTyw2QkFBQTNQLE1BQUEsQ0FBNkIrWSxpQkFBaUIsQ0FBQzVWLEtBQUssU0FBQW5ELE1BQUEsQ0FBTStZLGlCQUFpQixDQUFDek4saUJBQWlCO01BQ3hHLENBQUMsQ0FBQztJQUNOO0lBQ0EsSUFBTTtNQUFFMk8sSUFBSTtNQUFFMVE7SUFBTSxDQUFDLEdBQUd3UCxpQkFBaUI7SUFDekMsSUFBSXhQLEtBQUssS0FBS2tQLGVBQWUsQ0FBQ2xQLEtBQUssRUFBRTtNQUNqQyxNQUFNLElBQUlrQixpREFBVSxDQUFDO1FBQ2pCdEgsS0FBSyxFQUFFLGVBQWU7UUFDdEJtSSxpQkFBaUIsRUFBRSx5QkFBeUI7UUFDNUNxRSxPQUFPLEVBQUU7TUFDYixDQUFDLENBQUM7SUFDTjtJQUNBLElBQU1tTSxhQUFhLFNBQVNyVixZQUFZLENBQUMsSUFBSSxFQUFFb0wsc0JBQXNCLENBQUMsQ0FBQzlVLElBQUksQ0FBQyxJQUFJLEVBQUVrZCxJQUFJLEVBQUVsTSxZQUFZLENBQUM7SUFDckcsSUFBSWdHLHlCQUF5QixDQUFDK0gsYUFBYSxDQUFDLEVBQUU7TUFDMUMsTUFBTSxJQUFJclIsaURBQVUsQ0FBQztRQUNqQnRILEtBQUssRUFBRTJZLGFBQWEsQ0FBQzNZLEtBQUs7UUFDMUJtSSxpQkFBaUIsRUFBRXdRLGFBQWEsQ0FBQ3hRLGlCQUFpQjtRQUNsRHFFLE9BQU8seUJBQUEzUCxNQUFBLENBQXlCOGIsYUFBYSxDQUFDM1ksS0FBSyxTQUFBbkQsTUFBQSxDQUFNOGIsYUFBYSxDQUFDeFEsaUJBQWlCO01BQzVGLENBQUMsQ0FBQztJQUNOO0lBQ0EsSUFBTXlRLE1BQU0sU0FBU3RWLFlBQVksQ0FBQyxJQUFJLEVBQUVxTCxvQkFBb0IsQ0FBQyxDQUFDL1UsSUFBSSxDQUFDLElBQUksRUFBRStlLGFBQWEsRUFBRXJELGVBQWUsQ0FBQztJQUN4RyxPQUFPc0QsTUFBTTtFQUNqQixDQUFDO0VBQUEsZ0JBekNEOUosbUJBQW1CQSxDQUFBO0lBQUEsT0FBQXFKLEtBQUEsQ0FBQTdOLEtBQUEsT0FBQUUsU0FBQTtFQUFBO0FBQUEsR0F5Q2xCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaGdCd0M7QUFDYTtBQUN0RCxJQUFJdkgsV0FBVyxHQUFJQyxHQUFHLElBQUs7RUFDdkIsTUFBTXJKLFNBQVMsQ0FBQ3FKLEdBQUcsQ0FBQztBQUN4QixDQUFDO0FBQ0QsSUFBSUMsYUFBYSxHQUFHQSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFRixHQUFHLEtBQUtFLE1BQU0sQ0FBQ0MsR0FBRyxDQUFDN0ksR0FBRyxDQUFDLElBQUl5SSxXQUFXLENBQUMsU0FBUyxHQUFHQyxHQUFHLENBQUM7QUFDekYsSUFBSUksWUFBWSxHQUFHQSxDQUFDOUksR0FBRyxFQUFFNEksTUFBTSxFQUFFRyxNQUFNLE1BQU1KLGFBQWEsQ0FBQzNJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRSx5QkFBeUIsQ0FBQyxFQUFFQSxNQUFNLENBQUNJLEdBQUcsQ0FBQ2hKLEdBQUcsQ0FBQyxDQUFDO0FBQ3BILElBQUlpSixZQUFZLEdBQUdBLENBQUNqSixHQUFHLEVBQUU0SSxNQUFNLEVBQUVqSyxLQUFLLEtBQUtpSyxNQUFNLENBQUNDLEdBQUcsQ0FBQzdJLEdBQUcsQ0FBQyxHQUFHeUksV0FBVyxDQUFDLG1EQUFtRCxDQUFDLEdBQUdHLE1BQU0sWUFBWU0sT0FBTyxHQUFHTixNQUFNLENBQUNPLEdBQUcsQ0FBQ25KLEdBQUcsQ0FBQyxHQUFHNEksTUFBTSxDQUFDUSxHQUFHLENBQUNwSixHQUFHLEVBQUVyQixLQUFLLENBQUM7QUFDcE0sSUFBSTBLLFlBQVksR0FBR0EsQ0FBQ3JKLEdBQUcsRUFBRTRJLE1BQU0sRUFBRWpLLEtBQUssRUFBRTJLLE1BQU0sTUFBTVgsYUFBYSxDQUFDM0ksR0FBRyxFQUFFNEksTUFBTSxFQUFFLHdCQUF3QixDQUFDLEVBQUVBLE1BQU0sQ0FBQ1EsR0FBRyxDQUFDcEosR0FBRyxFQUFFckIsS0FBSyxDQUFDLEVBQUVBLEtBQUssQ0FBQztBQUN4SSxJQUFJNEssZUFBZSxHQUFHQSxDQUFDdkosR0FBRyxFQUFFNEksTUFBTSxFQUFFWSxNQUFNLE1BQU1iLGFBQWEsQ0FBQzNJLEdBQUcsRUFBRTRJLE1BQU0sRUFBRSx1QkFBdUIsQ0FBQyxFQUFFWSxNQUFNLENBQUM7QUFDNUcsSUFBSTZVLE1BQU0sRUFBRTNVLFFBQVEsRUFBRTRVLFFBQVEsRUFBRUMsZUFBZSxFQUFFQyxXQUFXLEVBQUVDLHVCQUF1QixFQUFFQyxZQUFZLEVBQUVDLGNBQWMsRUFBRUMsY0FBYztBQUNuSSxNQUFNek0sWUFBWSxDQUFDO0VBQ2Z6UyxXQUFXQSxDQUFDcUssT0FBTyxFQUFFOFUsVUFBVSxFQUFFO0lBQUEsSUFBQTVMLEtBQUE7SUFDN0JoSyxZQUFZLENBQUMsSUFBSSxFQUFFd1YsdUJBQXVCLENBQUM7SUFDM0N4VixZQUFZLENBQUMsSUFBSSxFQUFFb1YsTUFBTSxDQUFDO0lBQzFCcFYsWUFBWSxDQUFDLElBQUksRUFBRVMsUUFBUSxDQUFDO0lBQzVCVCxZQUFZLENBQUMsSUFBSSxFQUFFcVYsUUFBUSxFQUFFelIsbURBQU8sQ0FBQ2dCLEtBQUssQ0FBQztJQUMzQzVFLFlBQVksQ0FBQyxJQUFJLEVBQUVzVixlQUFlLEVBQUUsaUJBQWlCLENBQUM7SUFDdER0VixZQUFZLENBQUMsSUFBSSxFQUFFdVYsV0FBVyxFQUFFLGFBQWEsQ0FBQztJQUM5Q25WLFlBQVksQ0FBQyxJQUFJLEVBQUVLLFFBQVEsRUFBRUssT0FBTyxDQUFDO0lBQ3JDVixZQUFZLENBQUMsSUFBSSxFQUFFZ1YsTUFBTSxFQUFFUSxVQUFVLENBQUM7SUFDdEN2WCxNQUFNLENBQUNnRixnQkFBZ0IsQ0FBQyxTQUFTLEVBQUcxSCxLQUFLLElBQUs7TUFDMUMsSUFBSUEsS0FBSyxDQUFDM0UsR0FBRyxLQUFLNkksWUFBWSxDQUFDLElBQUksRUFBRXlWLGVBQWUsQ0FBQyxJQUFJM1osS0FBSyxDQUFDM0UsR0FBRyxLQUFLNkksWUFBWSxDQUFDLElBQUksRUFBRTBWLFdBQVcsQ0FBQyxFQUFFO1FBQ3BHalYsZUFBZSxDQUFDLElBQUksRUFBRWtWLHVCQUF1QixFQUFFRyxjQUFjLENBQUMsQ0FBQ3hmLElBQUksQ0FBQyxJQUFJLENBQUM7TUFDN0U7SUFDSixDQUFDLENBQUM7SUFDRjBKLFlBQVksQ0FBQyxJQUFJLEVBQUVZLFFBQVEsQ0FBQyxDQUFDVSxFQUFFLENBQUMsT0FBTyxlQUFBZ0YsaUJBQUEsQ0FBRSxhQUFZO01BQ2pELE1BQU02RCxLQUFJLENBQUM2TCxLQUFLLENBQUMsQ0FBQztJQUN0QixDQUFDLEVBQUM7RUFDTjtFQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJQyxTQUFTQSxDQUFDcFUsTUFBTSxFQUFFO0lBQ2QsSUFBTXFVLFVBQVUsR0FBRyxDQUFDLGFBQWEsRUFBRSxTQUFTLENBQUM7SUFDN0MsSUFBTUMsY0FBYyxHQUFHLElBQUksQ0FBQ3JVLGFBQWEsQ0FBQyxDQUFDO0lBQzNDLElBQU1zVSxrQkFBa0IsR0FBRztNQUN2QmpWLFdBQVcsRUFBRVUsTUFBTSxDQUFDVixXQUFXLENBQUNBLFdBQVc7TUFDM0N5SixTQUFTLEVBQUUvSSxNQUFNLENBQUNWLFdBQVcsQ0FBQ3lKO0lBQ2xDLENBQUM7SUFDRCxJQUFNeUwsY0FBYyxHQUFHO01BQ25CalYsT0FBTyxFQUFFUyxNQUFNLENBQUNULE9BQU8sQ0FBQ0EsT0FBTztNQUMvQjJMLEtBQUssRUFBRWxMLE1BQU0sQ0FBQ1QsT0FBTyxDQUFDMkwsS0FBSztNQUMzQm5DLFNBQVMsRUFBRS9JLE1BQU0sQ0FBQ1QsT0FBTyxDQUFDd0o7SUFDOUIsQ0FBQztJQUNENUssWUFBWSxDQUFDLElBQUksRUFBRXdWLFFBQVEsQ0FBQyxDQUFDbFYsR0FBRyxDQUFDTixZQUFZLENBQUMsSUFBSSxFQUFFeVYsZUFBZSxDQUFDLEVBQUVXLGtCQUFrQixFQUFFLElBQUloWixJQUFJLENBQUN5RSxNQUFNLENBQUNWLFdBQVcsQ0FBQzZCLFNBQVMsR0FBRyxHQUFHLENBQUMsQ0FBQztJQUN2SWhELFlBQVksQ0FBQyxJQUFJLEVBQUV3VixRQUFRLENBQUMsQ0FBQ2xWLEdBQUcsQ0FBQ04sWUFBWSxDQUFDLElBQUksRUFBRTBWLFdBQVcsQ0FBQyxFQUFFVyxjQUFjO0lBQ2hGO0lBQ0E7SUFDQTtJQUNBO0lBQ0EsSUFBSWpaLElBQUksQ0FBQ3lFLE1BQU0sQ0FBQ1YsV0FBVyxDQUFDNkIsU0FBUyxHQUFHLEdBQUcsQ0FBQyxDQUFDO0lBQzdDa1QsVUFBVSxDQUFDbFosT0FBTyxDQUFFMFAsU0FBUyxJQUFLO01BQzlCLElBQU00SixRQUFRLEdBQUd6VSxNQUFNLENBQUM2SyxTQUFTLENBQUM7TUFDbEMsSUFBTTZKLGFBQWEsR0FBR0osY0FBYyxhQUFkQSxjQUFjLHVCQUFkQSxjQUFjLENBQUd6SixTQUFTLENBQUM7TUFDakQsSUFBSTZKLGFBQWEsRUFBRTtRQUNmOVYsZUFBZSxDQUFDLElBQUksRUFBRWtWLHVCQUF1QixFQUFFRSxjQUFjLENBQUMsQ0FBQ3ZmLElBQUksQ0FBQyxJQUFJLEVBQUVvVyxTQUFTLEVBQUU2SixhQUFhLENBQUM7UUFDbkc5VixlQUFlLENBQUMsSUFBSSxFQUFFa1YsdUJBQXVCLEVBQUVDLFlBQVksQ0FBQyxDQUFDdGYsSUFBSSxDQUFDLElBQUksRUFBRW9XLFNBQVMsRUFBRTRKLFFBQVEsQ0FBQztNQUNoRyxDQUFDLE1BQ0k7UUFDRDdWLGVBQWUsQ0FBQyxJQUFJLEVBQUVrVix1QkFBdUIsRUFBRUMsWUFBWSxDQUFDLENBQUN0ZixJQUFJLENBQUMsSUFBSSxFQUFFb1csU0FBUyxFQUFFNEosUUFBUSxDQUFDO01BQ2hHO0lBQ0osQ0FBQyxDQUFDO0VBQ047RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSXhVLGFBQWFBLENBQUEsRUFBRztJQUNaLElBQU0wVSxzQkFBc0IsR0FBR3hXLFlBQVksQ0FBQyxJQUFJLEVBQUV3VixRQUFRLENBQUMsQ0FBQ3RWLEdBQUcsQ0FBQ0YsWUFBWSxDQUFDLElBQUksRUFBRXlWLGVBQWUsQ0FBQyxDQUFDO0lBQ3BHLElBQU1nQixrQkFBa0IsR0FBR3pXLFlBQVksQ0FBQyxJQUFJLEVBQUV3VixRQUFRLENBQUMsQ0FBQ3RWLEdBQUcsQ0FBQ0YsWUFBWSxDQUFDLElBQUksRUFBRTBWLFdBQVcsQ0FBQyxDQUFDO0lBQzVGLElBQUksRUFBQ2Msc0JBQXNCLGFBQXRCQSxzQkFBc0IsZUFBdEJBLHNCQUFzQixDQUFFclYsV0FBVyxLQUFJLEVBQUNzVixrQkFBa0IsYUFBbEJBLGtCQUFrQixlQUFsQkEsa0JBQWtCLENBQUVyVixPQUFPLEtBQUksQ0FBQ3FWLGtCQUFrQixDQUFDMUosS0FBSyxFQUFFO01BQ25HLE9BQU8sS0FBSyxDQUFDO0lBQ2pCO0lBQ0EsSUFBTTtNQUFFNUwsV0FBVztNQUFFQztJQUFRLENBQUMsR0FBR3BCLFlBQVksQ0FBQyxJQUFJLEVBQUV1VixNQUFNLENBQUMsQ0FBQ3RILFlBQVksQ0FBQztNQUNyRUMsY0FBYyxFQUFFc0ksc0JBQXNCLENBQUNyVixXQUFXO01BQ2xEZ04sb0JBQW9CLEVBQUVxSSxzQkFBc0IsQ0FBQzVMLFNBQVM7TUFDdER3RCxVQUFVLEVBQUVxSSxrQkFBa0IsQ0FBQ3JWLE9BQU87TUFDdENpTixnQkFBZ0IsRUFBRW9JLGtCQUFrQixDQUFDN0wsU0FBUztNQUM5Q21DLEtBQUssRUFBRTBKLGtCQUFrQixDQUFDMUo7SUFDOUIsQ0FBQyxDQUFDO0lBQ0YsSUFBSSxDQUFDUCx3REFBYSxDQUFDckwsV0FBVyxDQUFDLElBQUksQ0FBQytMLG9EQUFTLENBQUM5TCxPQUFPLENBQUMsRUFBRTtNQUNwRCxPQUFPLEtBQUssQ0FBQztJQUNqQjtJQUNBLE9BQU87TUFDSEQsV0FBVztNQUNYQztJQUNKLENBQUM7RUFDTDtFQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDVTRKLFNBQVNBLENBQUEsRUFBMEQ7SUFBQSxJQUFBMEwsVUFBQSxHQUFBeFAsU0FBQTtNQUFBb0QsTUFBQTtJQUFBLE9BQUFoRSxpQkFBQTtNQUFBLElBQXpEO1FBQUUyRSxpQkFBaUIsR0FBRyxLQUFLO1FBQUVULFlBQVksR0FBRztNQUFLLENBQUMsR0FBQWtNLFVBQUEsQ0FBQTFjLE1BQUEsUUFBQTBjLFVBQUEsUUFBQUMsU0FBQSxHQUFBRCxVQUFBLE1BQUcsQ0FBQyxDQUFDO01BQ25FLElBQUk7UUFDQSxJQUFNN1UsTUFBTSxHQUFHeUksTUFBSSxDQUFDeEksYUFBYSxDQUFDLENBQUM7UUFDbkMsSUFBSUQsTUFBTSxFQUFFO1VBQ1IsSUFBSTJJLFlBQVksRUFBRTtZQUNkLE1BQU14SyxZQUFZLENBQUNzSyxNQUFJLEVBQUVpTCxNQUFNLENBQUMsQ0FBQy9LLFlBQVksQ0FBQzNJLE1BQU0sQ0FBQ1QsT0FBTyxFQUFFUyxNQUFNLENBQUNWLFdBQVcsQ0FBQztZQUNqRixPQUFPVSxNQUFNO1VBQ2pCO1VBQ0EsT0FBT0EsTUFBTTtRQUNqQjtRQUNBLElBQUlvSixpQkFBaUIsRUFBRTtVQUNuQixJQUFNb0ssYUFBYSxTQUFTclYsWUFBWSxDQUFDc0ssTUFBSSxFQUFFaUwsTUFBTSxDQUFDLENBQUNaLGdCQUFnQixDQUFDLENBQUM7VUFDekVySyxNQUFJLENBQUMyTCxTQUFTLENBQUNaLGFBQWEsQ0FBQ3hULE1BQU0sQ0FBQztVQUNwQyxPQUFPd1QsYUFBYSxDQUFDeFQsTUFBTTtRQUMvQjtRQUNBLE9BQU8sS0FBSyxDQUFDO01BQ2pCLENBQUMsQ0FDRCxPQUFPbkYsS0FBSyxFQUFFO1FBQ1Y0TixNQUFJLENBQUNTLEtBQUssQ0FBQyxDQUFDO1FBQ1osTUFBTXJPLEtBQUs7TUFDZjtJQUFDO0VBQ0w7RUFDQTtBQUNKO0FBQ0E7QUFDQTtBQUNBO0VBQ0lxTyxLQUFLQSxDQUFBLEVBQUc7SUFDSi9LLFlBQVksQ0FBQyxJQUFJLEVBQUV3VixRQUFRLENBQUMsQ0FBQ29CLE1BQU0sQ0FBQzVXLFlBQVksQ0FBQyxJQUFJLEVBQUV5VixlQUFlLENBQUMsQ0FBQztJQUN4RXpWLFlBQVksQ0FBQyxJQUFJLEVBQUV3VixRQUFRLENBQUMsQ0FBQ29CLE1BQU0sQ0FBQzVXLFlBQVksQ0FBQyxJQUFJLEVBQUUwVixXQUFXLENBQUMsQ0FBQztJQUNwRWpWLGVBQWUsQ0FBQyxJQUFJLEVBQUVrVix1QkFBdUIsRUFBRUUsY0FBYyxDQUFDLENBQUN2ZixJQUFJLENBQUMsSUFBSSxFQUFFLGFBQWEsQ0FBQztJQUN4Rm1LLGVBQWUsQ0FBQyxJQUFJLEVBQUVrVix1QkFBdUIsRUFBRUUsY0FBYyxDQUFDLENBQUN2ZixJQUFJLENBQUMsSUFBSSxFQUFFLFNBQVMsQ0FBQztFQUN4RjtFQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7RUFDVTBmLEtBQUtBLENBQUEsRUFBRztJQUFBLElBQUFhLE1BQUE7SUFBQSxPQUFBdlEsaUJBQUE7TUFDVixJQUFNK08sYUFBYSxTQUFTclYsWUFBWSxDQUFDNlcsTUFBSSxFQUFFdEIsTUFBTSxDQUFDLENBQUNaLGdCQUFnQixDQUFDLENBQUM7TUFDekVrQyxNQUFJLENBQUNaLFNBQVMsQ0FBQ1osYUFBYSxDQUFDeFQsTUFBTSxDQUFDO01BQ3BDLE9BQU93VCxhQUFhLENBQUN4VCxNQUFNO0lBQUM7RUFDaEM7QUFDSjtBQUNBMFQsTUFBTSxHQUFHLElBQUkzVCxPQUFPLENBQUMsQ0FBQztBQUN0QmhCLFFBQVEsR0FBRyxJQUFJZ0IsT0FBTyxDQUFDLENBQUM7QUFDeEI0VCxRQUFRLEdBQUcsSUFBSTVULE9BQU8sQ0FBQyxDQUFDO0FBQ3hCNlQsZUFBZSxHQUFHLElBQUk3VCxPQUFPLENBQUMsQ0FBQztBQUMvQjhULFdBQVcsR0FBRyxJQUFJOVQsT0FBTyxDQUFDLENBQUM7QUFDM0IrVCx1QkFBdUIsR0FBRyxJQUFJdlYsT0FBTyxDQUFDLENBQUM7QUFDdkM7QUFDQTtBQUNBO0FBQ0E7QUFDQXdWLFlBQVksR0FBRyxTQUFBQSxDQUFVemUsR0FBRyxFQUFFOFMsS0FBSyxFQUFFO0VBQ2pDakssWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLENBQUNtQixJQUFJLENBQUMsT0FBTyxFQUFFNUssR0FBRyxFQUFFOFMsS0FBSyxDQUFDO0FBQzFELENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBNEwsY0FBYyxHQUFHLFNBQUFBLENBQVUxZSxHQUFHLEVBQUU4UyxLQUFLLEVBQUU7RUFDbkNqSyxZQUFZLENBQUMsSUFBSSxFQUFFWSxRQUFRLENBQUMsQ0FBQ21CLElBQUksQ0FBQyxTQUFTLEVBQUU1SyxHQUFHLEVBQUU4UyxLQUFLLENBQUM7QUFDNUQsQ0FBQztBQUNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E2TCxjQUFjLEdBQUcsU0FBQUEsQ0FBQSxFQUFZO0VBQ3pCOVYsWUFBWSxDQUFDLElBQUksRUFBRVksUUFBUSxDQUFDLENBQUNtQixJQUFJLENBQUMsU0FBUyxDQUFDO0FBQ2hELENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDNUs0RDtBQUNOO0FBQ007QUFDVjtBQUNJO0FBQ3ZELElBQU1vVixTQUFTLEdBQUc3ZixJQUFBLElBQTJEO0VBQUEsSUFBMUQ7SUFBRXNNLElBQUk7SUFBRS9OLEtBQUs7SUFBRXVoQixVQUFVO0lBQUVDLGdCQUFnQixHQUFHO0VBQU0sQ0FBQyxHQUFBL2YsSUFBQTtFQUNwRSxJQUFNZ2dCLE9BQU8sR0FBRyxlQUFnQixJQUFJbGEsSUFBSSxDQUFDLENBQUM7RUFDMUMsSUFBSSxDQUFDNlosZ0VBQWEsQ0FBQ3JULElBQUksRUFBRS9OLEtBQUssQ0FBQyxFQUFFO0lBQzdCLE1BQU0sSUFBSTZJLEtBQUssSUFBQW5GLE1BQUEsQ0FBSXVkLHNFQUFrQixPQUFBdmQsTUFBQSxDQUFJcUssSUFBSSxPQUFBckssTUFBQSxDQUFJMUQsS0FBSyxDQUFFLENBQUM7RUFDN0Q7RUFDQSxJQUFJdWhCLFVBQVUsRUFBRTtJQUNaRSxPQUFPLENBQUNDLFVBQVUsQ0FBQ0QsT0FBTyxDQUFDRSxVQUFVLENBQUMsQ0FBQyxHQUFHSixVQUFVLENBQUM7RUFDekQsQ0FBQyxNQUNJO0lBQ0RFLE9BQU8sQ0FBQ0csV0FBVyxDQUFDSCxPQUFPLENBQUNJLFdBQVcsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0lBQzlDSixPQUFPLENBQUNDLFVBQVUsQ0FBQyxDQUFDLENBQUM7RUFDekI7RUFDQWpVLFFBQVEsQ0FBQ3FVLE1BQU0sTUFBQXBlLE1BQUEsQ0FBTXFLLElBQUksT0FBQXJLLE1BQUEsQ0FBSTFELEtBQUssd0JBQUEwRCxNQUFBLENBQXFCK2QsT0FBTyxDQUFDTSxXQUFXLENBQUMsQ0FBQyxPQUFBcmUsTUFBQSxDQUFJeWQsMEVBQWtCLENBQUM7SUFDL0ZLO0VBQ0osQ0FBQyxDQUFDLENBQUU7RUFDSixJQUFJSCxnRUFBZSxDQUFDblgsR0FBRyxDQUFDNkQsSUFBSSxDQUFDLEVBQUU7SUFDM0IsSUFBTSxDQUFDaVUsTUFBTSxDQUFDLEdBQUdkLG9FQUFlLENBQUNuVCxJQUFJLENBQUM7SUFDdEMsSUFBSWlVLE1BQU0sRUFBRTtNQUNSWCxnRUFBZSxDQUFDNVcsR0FBRyxDQUFDc0QsSUFBSSxFQUFFaVUsTUFBTSxDQUFDO0lBQ3JDO0VBQ0o7QUFDSixDQUFDOzs7Ozs7Ozs7Ozs7Ozs7QUMxQkQsSUFBTTNNLGFBQWEsR0FBSTRNLENBQUMsSUFBS0EsQ0FBQyxLQUFLLEtBQUssQ0FBQyxJQUFJQSxDQUFDLEtBQUssSUFBSTs7Ozs7Ozs7Ozs7Ozs7O0FDQXZELElBQU1yYSxPQUFPLEdBQUlzYSxRQUFRLElBQU1saUIsS0FBSyxJQUFLa2lCLFFBQVEsQ0FBQ3JZLFFBQVEsQ0FBQzdKLEtBQUssQ0FBQzs7Ozs7Ozs7Ozs7Ozs7OztBQ0FwQjtBQUM3QyxJQUFNb2lCLFdBQVcsR0FBSUMsYUFBYTtBQUNsQztBQUNBLGtCQUFrQixJQUFJMVosTUFBTSxDQUFDMlosV0FBVyxHQUFHM1osTUFBTSxDQUFDMlosV0FBVyxDQUFDQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQ0MsT0FBTyxDQUFDL2dCLElBQUEsSUFBOEM7RUFBQSxJQUE3QztJQUFFZ2hCLFNBQVM7SUFBRTFVLElBQUk7SUFBRTJVLFFBQVE7SUFBRUM7RUFBVSxDQUFDLEdBQUFsaEIsSUFBQTtFQUN2SSxJQUFNbWhCLE1BQU0sR0FBR1QsMERBQVcsQ0FBQ3BVLElBQUksQ0FBQztFQUNoQyxPQUFPMFUsU0FBUyxLQUFLLFNBQVMsSUFBSUcsTUFBTSxJQUFJUCxhQUFhLENBQUN4WSxRQUFRLENBQUMrWSxNQUFNLENBQUNDLFlBQVksQ0FBQyxHQUFHO0lBQ3RGOVUsSUFBSTtJQUNKNlUsTUFBTTtJQUNORixRQUFRO0lBQ1JELFNBQVM7SUFDVEUsU0FBUztJQUNURyxNQUFNLEVBQUVBLENBQUEsS0FBTTlLLElBQUksQ0FBQytLLFNBQVMsQ0FBQyxLQUFLLENBQUM7RUFDdkMsQ0FBQyxHQUFHLEVBQUU7QUFDVixDQUFDLENBQUMsR0FBRyxFQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYjBEO0FBQ2Y7QUFDUztBQUM1RCxJQUFNRyxTQUFTLEdBQUcsR0FBRztBQUNyQixJQUFNQyxTQUFTLEdBQUcxaEIsSUFBQTtFQUFBLElBQUM7SUFBRW9oQixZQUFZO0lBQUU5VSxJQUFJO0lBQUVxVjtFQUFPLENBQUMsR0FBQTNoQixJQUFBO0VBQUEsT0FBSyxDQUFDb2hCLFlBQVksRUFBRTlVLElBQUksRUFBRXFWLE1BQU0sQ0FBQyxDQUFDbGMsTUFBTSxDQUFDbU8sMEVBQWEsQ0FBQyxDQUFDL0UsSUFBSSxDQUFDNFMsU0FBUyxDQUFDO0FBQUE7QUFDeEgsSUFBTWYsV0FBVyxHQUFJbGYsRUFBRSxJQUFLO0VBQ3hCLElBQU0sQ0FBQzRmLFlBQVksRUFBRTlVLElBQUksRUFBRXFWLE1BQU0sQ0FBQyxHQUFHbmdCLEVBQUUsQ0FBQzhMLEtBQUssQ0FBQ21VLFNBQVMsQ0FBQztFQUN4RCxPQUFPRiwrREFBUSxDQUFDSCxZQUFZLENBQUMsSUFBSUksd0VBQWMsQ0FBQ0osWUFBWSxDQUFDLElBQUlHLCtEQUFRLENBQUNqVixJQUFJLENBQUMsR0FBRztJQUFFOFUsWUFBWTtJQUFFOVUsSUFBSTtJQUFFcVY7RUFBTyxDQUFDLEdBQUcsS0FBSyxDQUFDO0FBQzdILENBQUM7Ozs7Ozs7Ozs7Ozs7OztBQ1JjLFNBQVNDLEdBQUdBLENBQUNoaUIsR0FBRyxFQUFFQyxHQUFHLEVBQUVnaUIsR0FBRyxFQUFFQyxDQUFDLEVBQUVDLEtBQUssRUFBRTtFQUNqRGxpQixHQUFHLEdBQUdBLEdBQUcsQ0FBQ3lOLEtBQUssR0FBR3pOLEdBQUcsQ0FBQ3lOLEtBQUssQ0FBQyxHQUFHLENBQUMsR0FBR3pOLEdBQUc7RUFDdEMsS0FBS2lpQixDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdqaUIsR0FBRyxDQUFDNkMsTUFBTSxFQUFFb2YsQ0FBQyxFQUFFLEVBQUU7SUFDN0JsaUIsR0FBRyxHQUFHQSxHQUFHLEdBQUdBLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDaWlCLENBQUMsQ0FBQyxDQUFDLEdBQUdDLEtBQUs7RUFDbkM7RUFDQSxPQUFPbmlCLEdBQUcsS0FBS21pQixLQUFLLEdBQUdGLEdBQUcsR0FBR2ppQixHQUFHO0FBQ3BDLEM7Ozs7Ozs7Ozs7Ozs7O0FDTk8sU0FBU29pQixJQUFJQSxDQUFDcGlCLEdBQUcsRUFBRTRGLElBQUksRUFBRXljLEdBQUcsRUFBRTtFQUNqQ3pjLElBQUksQ0FBQzhILEtBQUssS0FBSzlILElBQUksR0FBR0EsSUFBSSxDQUFDOEgsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ3RDLElBQUl2TyxDQUFDLEdBQUcsQ0FBQztJQUFFbWpCLENBQUMsR0FBRzFjLElBQUksQ0FBQzlDLE1BQU07SUFBRXRFLENBQUMsR0FBR3dCLEdBQUc7SUFBRXVpQixDQUFDO0lBQUV4SixDQUFDO0VBQ3pDLE9BQU81WixDQUFDLEdBQUdtakIsQ0FBQyxFQUFFO0lBQ1Z2SixDQUFDLEdBQUcsRUFBRSxHQUFHblQsSUFBSSxDQUFDekcsQ0FBQyxFQUFFLENBQUM7SUFDbEIsSUFBSTRaLENBQUMsS0FBSyxXQUFXLElBQUlBLENBQUMsS0FBSyxhQUFhLElBQUlBLENBQUMsS0FBSyxXQUFXLEVBQzdEO0lBQ0p2YSxDQUFDLEdBQUdBLENBQUMsQ0FBQ3VhLENBQUMsQ0FBQyxHQUFJNVosQ0FBQyxLQUFLbWpCLENBQUMsR0FBSUQsR0FBRyxHQUFJLFFBQVFFLENBQUMsR0FBRy9qQixDQUFDLENBQUN1YSxDQUFDLENBQUMsQ0FBQyxLQUFLLE9BQVFuVCxJQUFLLEdBQUkyYyxDQUFDLEdBQUkzYyxJQUFJLENBQUN6RyxDQUFDLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxHQUFHeUcsSUFBSSxDQUFDekcsQ0FBQyxDQUFDLEVBQUVxakIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFJLENBQUMsQ0FBQyxHQUFHLEVBQUU7RUFDNUk7QUFDSixDOzs7Ozs7Ozs7Ozs7OztBQ1RPLFNBQVNDLEtBQUtBLENBQUNKLEdBQUcsRUFBRTtFQUN2QixJQUFJdEosQ0FBQyxFQUFFMkosR0FBRyxFQUFFQyxHQUFHO0VBQ2YsSUFBSTVULEtBQUssQ0FBQzZULE9BQU8sQ0FBQ1AsR0FBRyxDQUFDLEVBQUU7SUFDcEJLLEdBQUcsR0FBRzNULEtBQUssQ0FBQ2dLLENBQUMsR0FBR3NKLEdBQUcsQ0FBQ3ZmLE1BQU0sQ0FBQztJQUMzQixPQUFPaVcsQ0FBQyxFQUFFLEVBQ04ySixHQUFHLENBQUMzSixDQUFDLENBQUMsR0FBRyxDQUFDNEosR0FBRyxHQUFHTixHQUFHLENBQUN0SixDQUFDLENBQUMsS0FBSyxPQUFPNEosR0FBRyxLQUFLLFFBQVEsR0FBR0YsS0FBSyxDQUFDRSxHQUFHLENBQUMsR0FBR0EsR0FBRztJQUN6RSxPQUFPRCxHQUFHO0VBQ2Q7RUFDQSxJQUFJamtCLE1BQU0sQ0FBQ2tCLFNBQVMsQ0FBQzJPLFFBQVEsQ0FBQ2xQLElBQUksQ0FBQ2lqQixHQUFHLENBQUMsS0FBSyxpQkFBaUIsRUFBRTtJQUMzREssR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDVixLQUFLM0osQ0FBQyxJQUFJc0osR0FBRyxFQUFFO01BQ1gsSUFBSXRKLENBQUMsS0FBSyxXQUFXLEVBQUU7UUFDbkJ0YSxNQUFNLENBQUNDLGNBQWMsQ0FBQ2drQixHQUFHLEVBQUUzSixDQUFDLEVBQUU7VUFDMUJwYSxLQUFLLEVBQUU4akIsS0FBSyxDQUFDSixHQUFHLENBQUN0SixDQUFDLENBQUMsQ0FBQztVQUNwQmxhLFlBQVksRUFBRSxJQUFJO1VBQ2xCRCxVQUFVLEVBQUUsSUFBSTtVQUNoQkUsUUFBUSxFQUFFO1FBQ2QsQ0FBQyxDQUFDO01BQ04sQ0FBQyxNQUNJO1FBQ0Q0akIsR0FBRyxDQUFDM0osQ0FBQyxDQUFDLEdBQUcsQ0FBQzRKLEdBQUcsR0FBR04sR0FBRyxDQUFDdEosQ0FBQyxDQUFDLEtBQUssT0FBTzRKLEdBQUcsS0FBSyxRQUFRLEdBQUdGLEtBQUssQ0FBQ0UsR0FBRyxDQUFDLEdBQUdBLEdBQUc7TUFDekU7SUFDSjtJQUNBLE9BQU9ELEdBQUc7RUFDZDtFQUNBLE9BQU9MLEdBQUc7QUFDZCxDOzs7Ozs7Ozs7Ozs7OztBQzFCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU1EsU0FBU0EsQ0FBQ3RhLEtBQUssRUFBRXVhLE1BQU0sRUFBRTtFQUM5QixJQUFJQyxLQUFLLEdBQUcsQ0FBQyxDQUFDO0lBQUVqZ0IsTUFBTSxHQUFHZ2dCLE1BQU0sQ0FBQ2hnQixNQUFNO0lBQUVrZ0IsTUFBTSxHQUFHemEsS0FBSyxDQUFDekYsTUFBTTtFQUM3RCxPQUFPLEVBQUVpZ0IsS0FBSyxHQUFHamdCLE1BQU0sRUFBRTtJQUNyQnlGLEtBQUssQ0FBQ3lhLE1BQU0sR0FBR0QsS0FBSyxDQUFDLEdBQUdELE1BQU0sQ0FBQ0MsS0FBSyxDQUFDO0VBQ3pDO0VBQ0EsT0FBT3hhLEtBQUs7QUFDaEI7QUFDQSxpRUFBZXNhLFNBQVMsRTs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZnQjtBQUNRO0FBQ2hEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTSyxXQUFXQSxDQUFDM2EsS0FBSyxFQUFFNGEsS0FBSyxFQUFFQyxTQUFTLEVBQUVDLFFBQVEsRUFBRUMsTUFBTSxFQUFFO0VBQzVELElBQUlQLEtBQUssR0FBRyxDQUFDLENBQUM7SUFBRWpnQixNQUFNLEdBQUd5RixLQUFLLENBQUN6RixNQUFNO0VBQ3JDc2dCLFNBQVMsS0FBS0EsU0FBUyxHQUFHSCx5REFBYSxDQUFDO0VBQ3hDSyxNQUFNLEtBQUtBLE1BQU0sR0FBRyxFQUFFLENBQUM7RUFDdkIsT0FBTyxFQUFFUCxLQUFLLEdBQUdqZ0IsTUFBTSxFQUFFO0lBQ3JCLElBQUluRSxLQUFLLEdBQUc0SixLQUFLLENBQUN3YSxLQUFLLENBQUM7SUFDeEIsSUFBSUksS0FBSyxHQUFHLENBQUMsSUFBSUMsU0FBUyxDQUFDemtCLEtBQUssQ0FBQyxFQUFFO01BQy9CLElBQUl3a0IsS0FBSyxHQUFHLENBQUMsRUFBRTtRQUNYO1FBQ0FELFdBQVcsQ0FBQ3ZrQixLQUFLLEVBQUV3a0IsS0FBSyxHQUFHLENBQUMsRUFBRUMsU0FBUyxFQUFFQyxRQUFRLEVBQUVDLE1BQU0sQ0FBQztNQUM5RCxDQUFDLE1BQ0k7UUFDRFQseURBQVMsQ0FBQ1MsTUFBTSxFQUFFM2tCLEtBQUssQ0FBQztNQUM1QjtJQUNKLENBQUMsTUFDSSxJQUFJLENBQUMwa0IsUUFBUSxFQUFFO01BQ2hCQyxNQUFNLENBQUNBLE1BQU0sQ0FBQ3hnQixNQUFNLENBQUMsR0FBR25FLEtBQUs7SUFDakM7RUFDSjtFQUNBLE9BQU8ya0IsTUFBTTtBQUNqQjtBQUNBLGlFQUFlSixXQUFXLEU7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsQ2dCO0FBQ0c7QUFDN0M7QUFDQSxJQUFJTyxPQUFPLEdBQUcsb0JBQW9CO0FBQ2xDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0MsZUFBZUEsQ0FBQy9rQixLQUFLLEVBQUU7RUFDNUIsT0FBTzZrQiw0REFBWSxDQUFDN2tCLEtBQUssQ0FBQyxJQUFJNGtCLDBEQUFVLENBQUM1a0IsS0FBSyxDQUFDLElBQUk4a0IsT0FBTztBQUM5RDtBQUNBLGlFQUFlQyxlQUFlLEU7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZEk7QUFDUztBQUNSO0FBQ25DO0FBQ0EsSUFBSUUsZ0JBQWdCLEdBQUcxa0Isa0RBQU0sR0FBR0Esa0RBQU0sQ0FBQzJrQixrQkFBa0IsR0FBR3BFLFNBQVM7QUFDckU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxTQUFTd0QsYUFBYUEsQ0FBQ3RrQixLQUFLLEVBQUU7RUFDMUIsT0FBT2lrQix1REFBTyxDQUFDamtCLEtBQUssQ0FBQyxJQUFJZ2xCLDJEQUFXLENBQUNobEIsS0FBSyxDQUFDLElBQ3ZDLENBQUMsRUFBRWlsQixnQkFBZ0IsSUFBSWpsQixLQUFLLElBQUlBLEtBQUssQ0FBQ2lsQixnQkFBZ0IsQ0FBQyxDQUFDO0FBQ2hFO0FBQ0EsaUVBQWVYLGFBQWEsRTs7Ozs7Ozs7Ozs7Ozs7O0FDaEJnQjtBQUM1QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU2EsT0FBT0EsQ0FBQ3ZiLEtBQUssRUFBRTtFQUNwQixJQUFJekYsTUFBTSxHQUFHeUYsS0FBSyxJQUFJLElBQUksR0FBRyxDQUFDLEdBQUdBLEtBQUssQ0FBQ3pGLE1BQU07RUFDN0MsT0FBT0EsTUFBTSxHQUFHb2dCLDJEQUFXLENBQUMzYSxLQUFLLEVBQUUsQ0FBQyxDQUFDLEdBQUcsRUFBRTtBQUM5QztBQUNBLGlFQUFldWIsT0FBTyxFOzs7Ozs7Ozs7Ozs7Ozs7O0FDbkI4QjtBQUNQO0FBQzdDO0FBQ0EsSUFBSUMsV0FBVyxHQUFHdGxCLE1BQU0sQ0FBQ2tCLFNBQVM7QUFDbEM7QUFDQSxJQUFJcWtCLGNBQWMsR0FBR0QsV0FBVyxDQUFDQyxjQUFjO0FBQy9DO0FBQ0EsSUFBSUMsb0JBQW9CLEdBQUdGLFdBQVcsQ0FBQ0Usb0JBQW9CO0FBQzNEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlOLFdBQVcsR0FBR0QsK0RBQWUsQ0FBQyxZQUFZO0VBQUUsT0FBTzFULFNBQVM7QUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcwVCwyREFBZSxHQUFHLFVBQVUva0IsS0FBSyxFQUFFO0VBQ3hHLE9BQU82a0IsNERBQVksQ0FBQzdrQixLQUFLLENBQUMsSUFBSXFsQixjQUFjLENBQUM1a0IsSUFBSSxDQUFDVCxLQUFLLEVBQUUsUUFBUSxDQUFDLElBQzlELENBQUNzbEIsb0JBQW9CLENBQUM3a0IsSUFBSSxDQUFDVCxLQUFLLEVBQUUsUUFBUSxDQUFDO0FBQ25ELENBQUM7QUFDRCxpRUFBZWdsQixXQUFXLEU7Ozs7Ozs7Ozs7Ozs7O0FDOUIxQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBSWYsT0FBTyxHQUFHN1QsS0FBSyxDQUFDNlQsT0FBTztBQUMzQixpRUFBZUEsT0FBTyxFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDeEI4QztBQUNwRSxTQUFTc0IsT0FBT0EsQ0FBQzVsQixDQUFDLEVBQUVDLENBQUMsRUFBRTtFQUFFLElBQUlDLENBQUMsR0FBR0MsTUFBTSxDQUFDbUgsSUFBSSxDQUFDdEgsQ0FBQyxDQUFDO0VBQUUsSUFBSUcsTUFBTSxDQUFDMGxCLHFCQUFxQixFQUFFO0lBQy9FLElBQUkza0IsQ0FBQyxHQUFHZixNQUFNLENBQUMwbEIscUJBQXFCLENBQUM3bEIsQ0FBQyxDQUFDO0lBQ3ZDQyxDQUFDLEtBQUtpQixDQUFDLEdBQUdBLENBQUMsQ0FBQ3FHLE1BQU0sQ0FBQyxVQUFVdEgsQ0FBQyxFQUFFO01BQUUsT0FBT0UsTUFBTSxDQUFDMmxCLHdCQUF3QixDQUFDOWxCLENBQUMsRUFBRUMsQ0FBQyxDQUFDLENBQUNLLFVBQVU7SUFBRSxDQUFDLENBQUMsQ0FBQyxFQUFFSixDQUFDLENBQUNrVCxJQUFJLENBQUM1QixLQUFLLENBQUN0UixDQUFDLEVBQUVnQixDQUFDLENBQUM7RUFDdEg7RUFBRSxPQUFPaEIsQ0FBQztBQUFFO0FBQ1osU0FBU3FGLGFBQWFBLENBQUN2RixDQUFDLEVBQUU7RUFBRSxLQUFLLElBQUlDLENBQUMsR0FBRyxDQUFDLEVBQUVBLENBQUMsR0FBR3lSLFNBQVMsQ0FBQ2xOLE1BQU0sRUFBRXZFLENBQUMsRUFBRSxFQUFFO0lBQ25FLElBQUlDLENBQUMsR0FBRyxJQUFJLElBQUl3UixTQUFTLENBQUN6UixDQUFDLENBQUMsR0FBR3lSLFNBQVMsQ0FBQ3pSLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNoREEsQ0FBQyxHQUFHLENBQUMsR0FBRzJsQixPQUFPLENBQUN6bEIsTUFBTSxDQUFDRCxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDc0gsT0FBTyxDQUFDLFVBQVV2SCxDQUFDLEVBQUU7TUFBRUYsaUZBQWUsQ0FBQ0MsQ0FBQyxFQUFFQyxDQUFDLEVBQUVDLENBQUMsQ0FBQ0QsQ0FBQyxDQUFDLENBQUM7SUFBRSxDQUFDLENBQUMsR0FBR0UsTUFBTSxDQUFDNGxCLHlCQUF5QixHQUFHNWxCLE1BQU0sQ0FBQzZsQixnQkFBZ0IsQ0FBQ2htQixDQUFDLEVBQUVHLE1BQU0sQ0FBQzRsQix5QkFBeUIsQ0FBQzdsQixDQUFDLENBQUMsQ0FBQyxHQUFHMGxCLE9BQU8sQ0FBQ3psQixNQUFNLENBQUNELENBQUMsQ0FBQyxDQUFDLENBQUNzSCxPQUFPLENBQUMsVUFBVXZILENBQUMsRUFBRTtNQUFFRSxNQUFNLENBQUNDLGNBQWMsQ0FBQ0osQ0FBQyxFQUFFQyxDQUFDLEVBQUVFLE1BQU0sQ0FBQzJsQix3QkFBd0IsQ0FBQzVsQixDQUFDLEVBQUVELENBQUMsQ0FBQyxDQUFDO0lBQUUsQ0FBQyxDQUFDO0VBQ2pUO0VBQUUsT0FBT0QsQ0FBQztBQUFFO0FBQ1o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQzJEO0FBQ087QUFDeUY7QUFDL0c7QUFDNUMsSUFBSThtQixhQUFhLEdBQUdULDZEQUFrQixDQUFDUSxxREFBVSxDQUFDLENBQUNFLFdBQVcsQ0FBQyxDQUFDLEtBQUssTUFBTTtBQUMzRSxJQUFJQyxzQkFBc0IsR0FBRyxJQUFJO0FBQ2pDLElBQUlDLDRCQUE0QixHQUFHLElBQUk7QUFDdkMsSUFBSUMsNEJBQTRCLEdBQUcsS0FBSztBQUN4QyxJQUFJQyxpQkFBaUIsR0FBRyxLQUFLO0FBQzdCLElBQUlDLHFCQUFxQixHQUFHLElBQUk7QUFDaEMsSUFBSUMsMEJBQTBCLEdBQUcsRUFBRTtBQUNuQyxJQUFJQyxvQkFBb0IsR0FBRyxJQUFJO0FBQy9CLElBQUlDLHNCQUFzQixHQUFHLENBQUMsQ0FBQztBQUN4QixJQUFJQyxNQUFNLEdBQUcsUUFBUTtBQUM1QixJQUFJQyxLQUFLLEdBQUcsT0FBTztBQUNuQixJQUFJQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO0FBQ3JCQSxZQUFZLENBQUNGLE1BQU0sQ0FBQyxHQUFHLElBQUk7QUFDM0JFLFlBQVksQ0FBQ0QsS0FBSyxDQUFDLEdBQUcsSUFBSTtBQUMxQixJQUFJRSx1QkFBdUIsR0FBR0gsTUFBTTtBQUNwQyxJQUFJSSxtQkFBbUIsR0FBRztFQUN0QkMsR0FBRyxFQUFFLEtBQUs7RUFDVkMsTUFBTSxFQUFFLFFBQVE7RUFDaEJDLElBQUksRUFBRSxNQUFNO0VBQ1pDLElBQUksRUFBRSxNQUFNO0VBQ1pDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLE1BQU0sRUFBRTtBQUNaLENBQUM7QUFDRCxJQUFJQyxVQUFVLEdBQUcsR0FBRztBQUNwQixTQUFTQyxnQkFBZ0JBLENBQUNoZixNQUFNLEVBQUU7RUFDOUIsSUFBSWlmLGdCQUFnQixHQUFHM1csU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJO0VBQy9GLElBQUk4UyxNQUFNLEdBQUc2RCxnQkFBZ0IsR0FBRztJQUM1QkMsZ0JBQWdCLEVBQUVWLG1CQUFtQixDQUFDRSxNQUFNO0lBQzVDUyxpQkFBaUIsRUFBRSxDQUFDLENBQUM7SUFDckJDLHlCQUF5QixFQUFFLENBQUMsQ0FBQztJQUM3QkMsY0FBYyxFQUFFZCx1QkFBdUI7SUFDdkNlLGNBQWMsRUFBRSxDQUFDO0VBQ3JCLENBQUMsR0FBRyxDQUFDLENBQUM7RUFDTixTQUFTQyxPQUFPQSxDQUFDdmEsSUFBSSxFQUFFO0lBQ25CLE9BQU9vVyxNQUFNLENBQUNwVyxJQUFJLENBQUM7RUFDdkI7RUFDQSxTQUFTd2EsT0FBT0EsQ0FBQ3hhLElBQUksRUFBRTJWLEdBQUcsRUFBRTtJQUN4QixJQUFJLENBQUNTLE1BQU0sQ0FBQ2tCLGNBQWMsQ0FBQ3RYLElBQUksQ0FBQyxFQUFFO01BQzlCak8sTUFBTSxDQUFDQyxjQUFjLENBQUNnSixNQUFNLEVBQUVnRixJQUFJLEVBQUU7UUFDaEM5TixVQUFVLEVBQUU7TUFDaEIsQ0FBQyxDQUFDO0lBQ047SUFDQWtrQixNQUFNLENBQUNwVyxJQUFJLENBQUMsR0FBRzJWLEdBQUc7RUFDdEI7RUFDQSxJQUFJOEUsS0FBSyxHQUFHO0lBQ1JDLGVBQWUsRUFBRTtNQUNiaGUsR0FBR0EsQ0FBQ2laLEdBQUcsRUFBRTtRQUNMLElBQUlBLEdBQUcsSUFBSSxJQUFJLEVBQUU7VUFDYjRDLGtEQUFPLENBQUMsZ0ZBQWdGLENBQUM7UUFDN0Y7UUFDQWlDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRTdFLEdBQUcsQ0FBQztNQUNuQztJQUNKLENBQUM7SUFDRHVFLGdCQUFnQixFQUFFO01BQ2R4ZCxHQUFHQSxDQUFDaVosR0FBRyxFQUFFO1FBQ0wsSUFBSWdGLHdCQUF3QixDQUFDaEYsR0FBRyxDQUFDLEVBQUU7VUFDL0IsSUFBSSxPQUFPQSxHQUFHLEtBQUssUUFBUSxFQUFFO1lBQ3pCNkUsT0FBTyxDQUFDLGtCQUFrQixFQUFFSSxjQUFjLENBQUNqRixHQUFHLENBQUMsR0FBR0EsR0FBRyxHQUFHNkQsbUJBQW1CLENBQUNFLE1BQU0sQ0FBQztVQUN2RixDQUFDLE1BQ0ksSUFBSXZCLHdEQUFhLENBQUN4QyxHQUFHLENBQUMsRUFBRTtZQUN6QjZFLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRTdFLEdBQUcsQ0FBQztZQUNqQzZFLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRWhCLG1CQUFtQixDQUFDTSxNQUFNLENBQUM7WUFDdkR4QixxREFBVSxDQUFDLGdDQUFnQyxDQUFDO1VBQ2hEO1FBQ0o7TUFDSjtJQUNKLENBQUM7SUFDRDZCLGlCQUFpQixFQUFFLENBQUMsQ0FBQztJQUNyQkMseUJBQXlCLEVBQUU7TUFDdkIxZCxHQUFHQSxDQUFDaVosR0FBRyxFQUFFO1FBQ0xBLEdBQUcsSUFBSSxJQUFJLElBQUk2RSxPQUFPLENBQUMsMkJBQTJCLEVBQUV6b0IsTUFBTSxDQUFDbUgsSUFBSSxDQUFDeWMsR0FBRyxDQUFDLENBQUN0ZSxNQUFNLENBQUMsQ0FBQ3dqQixTQUFTLEVBQUVDLElBQUksS0FBSztVQUM3RixJQUFJSCx3QkFBd0IsQ0FBQ2hGLEdBQUcsQ0FBQ21GLElBQUksQ0FBQyxDQUFDLEVBQUU7WUFDckMsSUFBSSxPQUFPbkYsR0FBRyxLQUFLLFFBQVEsRUFBRTtjQUN6QmtGLFNBQVMsQ0FBQ0MsSUFBSSxDQUFDLEdBQUdGLGNBQWMsQ0FBQ2pGLEdBQUcsQ0FBQ21GLElBQUksQ0FBQyxDQUFDLEdBQUduRixHQUFHLENBQUNtRixJQUFJLENBQUMsR0FBR1AsT0FBTyxDQUFDLGtCQUFrQixDQUFDO1lBQ3pGLENBQUMsTUFDSSxJQUFJcEMsd0RBQWEsQ0FBQ3hDLEdBQUcsQ0FBQyxFQUFFO2NBQ3pCa0YsU0FBUyxDQUFDQyxJQUFJLENBQUMsR0FBR25GLEdBQUcsQ0FBQ21GLElBQUksQ0FBQztjQUMzQnhDLHFEQUFVLENBQUMscUNBQXFDLENBQUMzaUIsTUFBTSxDQUFDbWxCLElBQUksQ0FBQyxDQUFDO1lBQ2xFO1VBQ0osQ0FBQyxNQUNJO1lBQ0R2QyxrREFBTyxDQUFDLDRDQUE0QyxDQUFDNWlCLE1BQU0sQ0FBQ21sQixJQUFJLENBQUMsQ0FBQztVQUN0RTtVQUNBLE9BQU9ELFNBQVM7UUFDcEIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7TUFDWDtJQUNKLENBQUM7SUFDRFIsY0FBYyxFQUFFO01BQ1ozZCxHQUFHQSxDQUFDaVosR0FBRyxFQUFFO1FBQ0wsSUFBSTJELFlBQVksQ0FBQzNELEdBQUcsQ0FBQyxFQUFFO1VBQ25CNkUsT0FBTyxDQUFDLGdCQUFnQixFQUFFN0UsR0FBRyxDQUFDO1FBQ2xDLENBQUMsTUFDSTtVQUNENEMsa0RBQU8sQ0FBQyxpQkFBaUIsQ0FBQzVpQixNQUFNLENBQUNnZ0IsR0FBRyxFQUFFLGdDQUFnQyxDQUFDLENBQUM7UUFDNUU7TUFDSjtJQUNKLENBQUM7SUFDRDJFLGNBQWMsRUFBRTtNQUNaNWQsR0FBR0EsQ0FBQ2laLEdBQUcsRUFBRTtRQUNMLElBQUlvRixzQkFBc0IsQ0FBQ3BGLEdBQUcsQ0FBQyxFQUFFO1VBQzdCNkUsT0FBTyxDQUFDLGdCQUFnQixFQUFFN0UsR0FBRyxDQUFDO1FBQ2xDO01BQ0o7SUFDSjtFQUNKLENBQUM7RUFDRDVqQixNQUFNLENBQUM2bEIsZ0JBQWdCLENBQUM1YyxNQUFNLEVBQUVqSixNQUFNLENBQUNpcEIsV0FBVyxDQUFDanBCLE1BQU0sQ0FBQ2twQixPQUFPLENBQUNSLEtBQUssQ0FBQyxDQUFDL2lCLEdBQUcsQ0FBQ2hFLElBQUksSUFBSTtJQUNqRixJQUFJLENBQUMyWSxDQUFDLEVBQUVrSixHQUFHLENBQUMsR0FBRzdoQixJQUFJO0lBQ25CLE9BQU8sQ0FBQzJZLENBQUMsRUFBRXRhLE1BQU0sQ0FBQ21wQixNQUFNLENBQUM7TUFDakI1ZSxHQUFHLEVBQUVpZSxPQUFPLENBQUNZLElBQUksQ0FBQyxJQUFJLEVBQUU5TyxDQUFDLENBQUM7TUFDMUIzUCxHQUFHLEVBQUU4ZCxPQUFPLENBQUNXLElBQUksQ0FBQyxJQUFJLEVBQUU5TyxDQUFDLENBQUM7TUFDMUJuYSxVQUFVLEVBQUVra0IsTUFBTSxDQUFDa0IsY0FBYyxDQUFDakwsQ0FBQyxDQUFDO01BQ3BDbGEsWUFBWSxFQUFFLENBQUNpa0IsTUFBTSxDQUFDa0IsY0FBYyxDQUFDakwsQ0FBQztJQUMxQyxDQUFDLEVBQUVrSixHQUFHLENBQUMsQ0FBQztFQUNoQixDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ0osT0FBT3ZhLE1BQU07RUFDYixTQUFTNGYsY0FBY0EsQ0FBQ2pGLEdBQUcsRUFBRTtJQUN6QixPQUFPOWUsa0RBQUksQ0FBQzlFLE1BQU0sQ0FBQ21ILElBQUksQ0FBQ3NnQixtQkFBbUIsQ0FBQyxFQUFFNEIsTUFBTSxJQUFJekYsR0FBRyxLQUFLNkQsbUJBQW1CLENBQUM0QixNQUFNLENBQUMsQ0FBQztFQUNoRztFQUNBLFNBQVNULHdCQUF3QkEsQ0FBQ2hGLEdBQUcsRUFBRTtJQUNuQyxJQUFJLENBQUNBLEdBQUcsRUFBRTtNQUNOMEMsbURBQVEsQ0FBQywwREFBMEQsQ0FBQztNQUNwRSxPQUFPLEtBQUs7SUFDaEI7SUFDQSxJQUFJLE9BQU8xQyxHQUFHLEtBQUssUUFBUSxFQUFFO01BQ3pCLElBQUksQ0FBQ2lGLGNBQWMsQ0FBQ2pGLEdBQUcsQ0FBQyxFQUFFO1FBQ3RCNEMsa0RBQU8sQ0FBQyxpR0FBaUcsQ0FBQztNQUM5RztJQUNKLENBQUMsTUFDSSxJQUFJSix3REFBYSxDQUFDeEMsR0FBRyxDQUFDLEVBQUU7TUFDekIsSUFBSSxDQUFDa0Msd0VBQWtCLENBQUNsQyxHQUFHLENBQUMsRUFBRTtRQUMxQjBDLG1EQUFRLENBQUMsOERBQThELENBQUM7UUFDeEUsT0FBTyxLQUFLO01BQ2hCO0lBQ0o7SUFDQSxPQUFPLElBQUk7RUFDZjtFQUNBLFNBQVMwQyxzQkFBc0JBLENBQUNwRixHQUFHLEVBQUU7SUFDakMsSUFBSSxDQUFDd0Msd0RBQWEsQ0FBQ3hDLEdBQUcsQ0FBQyxFQUFFO01BQ3JCNEMsa0RBQU8sQ0FBQyxtQ0FBbUMsQ0FBQztNQUM1QyxPQUFPLEtBQUs7SUFDaEI7SUFDQSxLQUFLLElBQUlsTSxDQUFDLElBQUl0YSxNQUFNLENBQUNtSCxJQUFJLENBQUN5YyxHQUFHLENBQUMsRUFBRTtNQUM1QixJQUFJdEosQ0FBQyxLQUFLLGtCQUFrQixJQUFJQSxDQUFDLEtBQUsscUJBQXFCLElBQUlBLENBQUMsS0FBSyx1QkFBdUIsRUFBRTtRQUMxRmtNLGtEQUFPLENBQUMsNENBQTRDLENBQUM1aUIsTUFBTSxDQUFDMFcsQ0FBQyxDQUFDLENBQUM7UUFDL0QsT0FBTyxLQUFLO01BQ2hCO01BQ0EsSUFBSUEsQ0FBQyxLQUFLLGtCQUFrQixFQUFFO1FBQzFCLElBQUksQ0FBQzZKLGtEQUFPLENBQUNQLEdBQUcsQ0FBQ3RKLENBQUMsQ0FBQyxDQUFDLEVBQUU7VUFDbEJrTSxrREFBTyxDQUFDLGtCQUFrQixDQUFDNWlCLE1BQU0sQ0FBQzBXLENBQUMsRUFBRSx3QkFBd0IsQ0FBQyxDQUFDO1VBQy9ELE9BQU8sS0FBSztRQUNoQixDQUFDLE1BQ0ksSUFBSSxDQUFDc0osR0FBRyxDQUFDdEosQ0FBQyxDQUFDLENBQUM5VCxLQUFLLENBQUM2Ziw0Q0FBSyxDQUFDLEVBQUU7VUFDM0JHLGtEQUFPLENBQUMsa0JBQWtCLENBQUM1aUIsTUFBTSxDQUFDMFcsQ0FBQyxFQUFFLHNCQUFzQixDQUFDLENBQUM7VUFDN0QsT0FBTyxLQUFLO1FBQ2hCO01BQ0osQ0FBQyxNQUNJLElBQUlBLENBQUMsS0FBSyxxQkFBcUIsSUFBSUEsQ0FBQyxLQUFLLHVCQUF1QixFQUFFO1FBQ25FLElBQUksQ0FBQzZMLG9EQUFTLENBQUN2QyxHQUFHLENBQUN0SixDQUFDLENBQUMsQ0FBQyxFQUFFO1VBQ3BCa00sa0RBQU8sQ0FBQyxrQkFBa0IsQ0FBQzVpQixNQUFNLENBQUMwVyxDQUFDLEVBQUUsMEJBQTBCLENBQUMsQ0FBQztVQUNqRSxPQUFPLEtBQUs7UUFDaEI7TUFDSjtJQUNKO0lBQ0EsT0FBTyxJQUFJO0VBQ2Y7QUFDSjtBQUNPLFNBQVNnUCxTQUFTQSxDQUFBLEVBQUc7RUFDeEIsSUFBSUMsU0FBUyxHQUFHLEVBQUU7RUFDbEIsSUFBSUMsUUFBUTtFQUNaLElBQUl2Z0IsTUFBTTtFQUNWLElBQUl3Z0IsWUFBWTtFQUNoQixJQUFJQyxVQUFVLEdBQUcsSUFBSTtFQUNyQixTQUFTQyxXQUFXQSxDQUFBLEVBQUc7SUFDbkJILFFBQVEsR0FBRyxDQUFDLENBQUM7SUFDYixJQUFJRixTQUFTLEdBQUdyQixnQkFBZ0IsQ0FBQztNQUM3QjtNQUNBMkIsS0FBSyxFQUFFakQsYUFBYTtNQUNwQmtELGFBQWEsRUFBRWhELHNCQUFzQjtNQUNyQ2lELGlCQUFpQixFQUFFaEQsNEJBQTRCO01BQy9DaUQsV0FBVyxFQUFFL0MsaUJBQWlCO01BQzlCO0FBQ1o7QUFDQTtBQUNBO01BQ1lnRCxZQUFZLEVBQUUvQyxxQkFBcUI7TUFDbkNnRCxrQkFBa0IsRUFBRWxELDRCQUE0QjtNQUNoRDtNQUNBbUQsZ0JBQWdCLEVBQUVoRCwwQkFBMEI7TUFDNUM7TUFDQWlELE1BQU0sRUFBRWhELG9CQUFvQjtNQUM1QmlELFFBQVEsRUFBRTtRQUNOQyxNQUFNLEVBQUVqRDtNQUNaO0lBQ0osQ0FBQyxDQUFDO0lBQ0YsSUFBSW5lLE1BQU0sRUFBRTtNQUNScWhCLGVBQWUsQ0FBQ3RxQixNQUFNLENBQUNtSCxJQUFJLENBQUM4QixNQUFNLENBQUMsQ0FBQzNELE1BQU0sQ0FBQyxDQUFDaWxCLElBQUksRUFBRUMsS0FBSyxLQUFLO1FBQ3hELElBQUl2aEIsTUFBTSxDQUFDdWhCLEtBQUssQ0FBQyxLQUFLbEIsU0FBUyxDQUFDa0IsS0FBSyxDQUFDLEVBQUU7VUFDcENELElBQUksQ0FBQ0MsS0FBSyxDQUFDLEdBQUdsQixTQUFTLENBQUNrQixLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDeEM7UUFDQSxPQUFPRCxJQUFJO01BQ2YsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDWDtJQUNBdGhCLE1BQU0sR0FBR3FnQixTQUFTO0lBQ2xCRyxZQUFZLEdBQUcsQ0FBQyxDQUFDO0VBQ3JCO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7RUFDSSxTQUFTZ0IsVUFBVUEsQ0FBQSxFQUFHO0lBQ2xCLElBQUlmLFVBQVUsSUFBSUQsWUFBWSxJQUFJckQsd0RBQWEsQ0FBQ3FELFlBQVksQ0FBQ0MsVUFBVSxDQUFDLENBQUMsRUFBRTtNQUN2RSxJQUFJZ0IsZ0JBQWdCLEdBQUdqQixZQUFZLENBQUNDLFVBQVUsQ0FBQztNQUMvQyxJQUFJaUIsY0FBYyxHQUFHLElBQUlDLEdBQUcsQ0FBQzVxQixNQUFNLENBQUNtSCxJQUFJLENBQUM4QixNQUFNLENBQUMsQ0FBQ3JGLE1BQU0sQ0FBQzVELE1BQU0sQ0FBQ21ILElBQUksQ0FBQ3VqQixnQkFBZ0IsQ0FBQyxDQUFDLENBQUM7TUFDdkYsT0FBT25hLHVEQUFJLENBQUNvYSxjQUFjLENBQUMsQ0FBQ3JsQixNQUFNLENBQUMsQ0FBQ2lsQixJQUFJLEVBQUVDLEtBQUssS0FBSztRQUNoRCxJQUFJLE9BQU9FLGdCQUFnQixDQUFDRixLQUFLLENBQUMsS0FBSyxXQUFXLEVBQUU7VUFDaERELElBQUksQ0FBQ0MsS0FBSyxDQUFDLEdBQUd2aEIsTUFBTSxDQUFDdWhCLEtBQUssQ0FBQztRQUMvQixDQUFDLE1BQ0ksSUFBSSxPQUFPdmhCLE1BQU0sQ0FBQ3VoQixLQUFLLENBQUMsS0FBSyxXQUFXLEVBQUU7VUFDM0NELElBQUksQ0FBQ0MsS0FBSyxDQUFDLEdBQUdFLGdCQUFnQixDQUFDRixLQUFLLENBQUM7UUFDekMsQ0FBQyxNQUNJO1VBQ0QsSUFBSXBFLHdEQUFhLENBQUNzRSxnQkFBZ0IsQ0FBQ0YsS0FBSyxDQUFDLENBQUMsRUFBRTtZQUN4Q0QsSUFBSSxDQUFDQyxLQUFLLENBQUMsR0FBRy9ELG9EQUFTLENBQUMsQ0FBQyxDQUFDLEVBQUV4ZCxNQUFNLENBQUN1aEIsS0FBSyxDQUFDLEVBQUVFLGdCQUFnQixDQUFDRixLQUFLLENBQUMsQ0FBQztVQUN2RSxDQUFDLE1BQ0k7WUFDREQsSUFBSSxDQUFDQyxLQUFLLENBQUMsR0FBR0UsZ0JBQWdCLENBQUNGLEtBQUssQ0FBQztVQUN6QztRQUNKO1FBQ0EsT0FBT0QsSUFBSTtNQUNmLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztJQUNWO0lBQ0EsT0FBT3ZxQixNQUFNLENBQUNtcEIsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFbGdCLE1BQU0sQ0FBQztFQUNwQztFQUNBLFNBQVM0aEIsb0JBQW9CQSxDQUFBLEVBQUc7SUFDNUI7SUFDQTtJQUNBO0lBQ0E7SUFDQTtJQUNBLElBQUlDLElBQUksR0FBR0wsVUFBVSxDQUFDLENBQUM7SUFDdkJ6cUIsTUFBTSxDQUFDQyxjQUFjLENBQUM2cUIsSUFBSSxFQUFFLE9BQU8sRUFBRTtNQUNqQ3ZnQixHQUFHLEVBQUUsU0FBQUEsQ0FBQSxFQUFZO1FBQ2IsTUFBTSxJQUFJeEIsS0FBSyxDQUFDLHFFQUFxRSxDQUFDO01BQzFGO0lBQ0osQ0FBQyxDQUFDO0lBQ0YsT0FBTytoQixJQUFJO0VBQ2Y7RUFDQSxJQUFJLENBQUNDLFlBQVksRUFBRUMsU0FBUyxDQUFDLEdBQUcsQ0FBQ1AsVUFBVSxFQUFFSSxvQkFBb0IsQ0FBQyxDQUFDbGxCLEdBQUcsQ0FBQ3NsQixRQUFRLElBQUk7SUFDL0U7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtJQUNRLE9BQU8sU0FBU0QsU0FBU0EsQ0FBQSxFQUFHO01BQ3hCLElBQUl6WixTQUFTLENBQUNsTixNQUFNLElBQUksQ0FBQyxJQUFJLFFBQVFrTixTQUFTLENBQUNsTixNQUFNLElBQUksQ0FBQyxHQUFHMmMsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssVUFBVSxFQUFFO1FBQ25HLElBQUk4WCxNQUFNLEdBQUc5WCxTQUFTLENBQUNsTixNQUFNLElBQUksQ0FBQyxHQUFHMmMsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQztRQUM3RCxPQUFPOFgsTUFBTSxHQUFHckQscURBQVUsQ0FBQ2lGLFFBQVEsQ0FBQyxDQUFDLEVBQUU1QixNQUFNLENBQUMsR0FBR29CLFVBQVUsQ0FBQyxDQUFDO01BQ2pFO01BQ0EsT0FBTzVlLFNBQVMsQ0FBQyxHQUFHMEYsU0FBUyxDQUFDO0lBQ2xDLENBQUM7RUFDTCxDQUFDLENBQUM7RUFDRixJQUFJLENBQUMyWixVQUFVLEVBQUVDLGFBQWEsQ0FBQyxHQUFHLENBQUNILFNBQVMsRUFBRUQsWUFBWSxDQUFDLENBQUNwbEIsR0FBRyxDQUFDeWxCLE1BQU0sSUFBSTtJQUN0RTtBQUNSO0FBQ0E7SUFDUSxPQUFPLFNBQVNGLFVBQVVBLENBQUEsRUFBRztNQUN6QixJQUFJRyxHQUFHLEdBQUdELE1BQU0sQ0FBQyxHQUFHN1osU0FBUyxDQUFDO01BQzlCLElBQUk4WixHQUFHLElBQUksT0FBT0EsR0FBRyxLQUFLLFFBQVEsRUFBRTtRQUNoQ0EsR0FBRyxHQUFHcEYsb0RBQVMsQ0FBQ29GLEdBQUcsQ0FBQztNQUN4QjtNQUNBLE9BQU9BLEdBQUc7SUFDZCxDQUFDO0VBQ0wsQ0FBQyxDQUFDO0VBQ0Y7QUFDSjtBQUNBO0VBQ0ksU0FBU0MsZUFBZUEsQ0FBQSxFQUFHO0lBQ3ZCLE9BQU83QixZQUFZO0VBQ3ZCO0VBQ0E7QUFDSjtBQUNBO0FBQ0E7RUFDSSxTQUFTOEIsU0FBU0EsQ0FBQ3plLE9BQU8sRUFBRTtJQUN4QixJQUFJLENBQUNzWix3REFBYSxDQUFDdFosT0FBTyxDQUFDLEVBQUU7TUFDekJ3WixtREFBUSxDQUFDLHFDQUFxQyxDQUFDO01BQy9DO0lBQ0o7SUFDQSxJQUFJK0QsTUFBTSxHQUFHcnFCLE1BQU0sQ0FBQ21ILElBQUksQ0FBQzJGLE9BQU8sQ0FBQztJQUNqQyxJQUFJMGUsYUFBYSxHQUFHLENBQUMsQ0FBQztJQUN0Qm5CLE1BQU0sQ0FBQ2hqQixPQUFPLENBQUNtakIsS0FBSyxJQUFJO01BQ3BCLElBQUluQixNQUFNLEdBQUd2YyxPQUFPLENBQUMwZCxLQUFLLENBQUM7TUFDM0IsSUFBSXBFLHdEQUFhLENBQUNvRCxRQUFRLENBQUNnQixLQUFLLENBQUMsQ0FBQyxJQUFJcEUsd0RBQWEsQ0FBQ2lELE1BQU0sQ0FBQyxFQUFFO1FBQ3pEQSxNQUFNLEdBQUdycEIsTUFBTSxDQUFDbXBCLE1BQU0sQ0FBQyxDQUFDLENBQUMsRUFBRUssUUFBUSxDQUFDZ0IsS0FBSyxDQUFDLEVBQUVuQixNQUFNLENBQUM7TUFDdkQ7TUFDQSxJQUFJO1FBQ0FtQyxhQUFhLENBQUNoQixLQUFLLENBQUMsR0FBR3ZoQixNQUFNLENBQUN1aEIsS0FBSyxDQUFDLEdBQUduQixNQUFNO01BQ2pELENBQUMsQ0FDRCxPQUFPeHBCLENBQUMsRUFBRTtRQUNOMm1CLGtEQUFPLENBQUMsaUNBQWlDLENBQUM1aUIsTUFBTSxDQUFDNG1CLEtBQUssRUFBRSxLQUFLLENBQUMsRUFBRTNxQixDQUFDLENBQUM7TUFDdEU7SUFDSixDQUFDLENBQUM7SUFDRnlxQixlQUFlLENBQUNrQixhQUFhLENBQUM7RUFDbEM7RUFDQTtBQUNKO0FBQ0E7QUFDQTtFQUNJLFNBQVNDLFdBQVdBLENBQUMzZSxPQUFPLEVBQUU7SUFDMUIsSUFBSSxDQUFDc1osd0RBQWEsQ0FBQ29ELFFBQVEsQ0FBQyxFQUFFO01BQzFCbEQsbURBQVEsQ0FBQyw0QkFBNEIsQ0FBQztNQUN0QztJQUNKO0lBQ0F0bUIsTUFBTSxDQUFDbXBCLE1BQU0sQ0FBQ0ssUUFBUSxFQUFFMWMsT0FBTyxDQUFDO0lBQ2hDO0lBQ0E5TSxNQUFNLENBQUNtcEIsTUFBTSxDQUFDbGdCLE1BQU0sRUFBRTZELE9BQU8sQ0FBQztFQUNsQztFQUNBO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtFQUNJLFNBQVNqQixTQUFTQSxDQUFDMmUsS0FBSyxFQUFFM2pCLFFBQVEsRUFBRTtJQUNoQyxJQUFJaUcsT0FBTyxHQUFHeUUsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7SUFDcEYsSUFBSXFCLFFBQVEsR0FBRy9MLFFBQVE7SUFDdkIsSUFBSSxPQUFPMmpCLEtBQUssS0FBSyxRQUFRLEVBQUU7TUFDM0I7TUFDQTtNQUNBNVgsUUFBUSxHQUFHNFgsS0FBSztNQUNoQkEsS0FBSyxHQUFHeEMsVUFBVTtNQUNsQmxiLE9BQU8sR0FBR2pHLFFBQVEsSUFBSSxDQUFDLENBQUM7SUFDNUI7SUFDQSxJQUFJLE9BQU8rTCxRQUFRLEtBQUssVUFBVSxFQUFFO01BQ2hDMFQsbURBQVEsQ0FBQyw2QkFBNkIsQ0FBQztNQUN2QztJQUNKO0lBQ0EsSUFBSW9GLEVBQUUsR0FBRztNQUNMbEIsS0FBSztNQUNMNVg7SUFDSixDQUFDO0lBQ0QyVyxTQUFTLENBQUN0VyxJQUFJLENBQUN5WSxFQUFFLENBQUM7SUFDbEIsSUFBSTVlLE9BQU8sQ0FBQzZlLElBQUksRUFBRTtNQUNkLElBQUluQixLQUFLLEtBQUt4QyxVQUFVLEVBQUU7UUFDdEJwVixRQUFRLENBQUNvWSxTQUFTLENBQUMsQ0FBQyxDQUFDO01BQ3pCLENBQUMsTUFDSTtRQUNEO1FBQ0FwWSxRQUFRLENBQUM7VUFDTCxDQUFDNFgsS0FBSyxHQUFHUSxTQUFTLENBQUNSLEtBQUs7UUFDNUIsQ0FBQyxDQUFDO01BQ047SUFDSjtJQUNBO0lBQ0EsT0FBTyxTQUFTemUsV0FBV0EsQ0FBQSxFQUFHO01BQzFCd2QsU0FBUyxDQUFDcUMsTUFBTSxDQUFDckMsU0FBUyxDQUFDeEYsT0FBTyxDQUFDMkgsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzlDLENBQUM7RUFDTDtFQUNBO0FBQ0o7QUFDQTtFQUNJLFNBQVNwQixlQUFlQSxDQUFDeGQsT0FBTyxFQUFFO0lBQzlCLElBQUkrZSxNQUFNLEdBQUc3ckIsTUFBTSxDQUFDbUgsSUFBSSxDQUFDMkYsT0FBTyxDQUFDO0lBQ2pDO0lBQ0F5YyxTQUFTLENBQUNuaUIsTUFBTSxDQUFDUCxRQUFRLElBQUlrRCxzREFBUSxDQUFDOGhCLE1BQU0sRUFBRWhsQixRQUFRLENBQUMyakIsS0FBSyxDQUFDLENBQUMsQ0FBQ25qQixPQUFPLENBQUNSLFFBQVEsSUFBSTtNQUMvRUEsUUFBUSxDQUFDK0wsUUFBUSxDQUFDO1FBQ2QsQ0FBQy9MLFFBQVEsQ0FBQzJqQixLQUFLLEdBQUcxZCxPQUFPLENBQUNqRyxRQUFRLENBQUMyakIsS0FBSztNQUM1QyxDQUFDLENBQUM7SUFDTixDQUFDLENBQUM7SUFDRjtJQUNBakIsU0FBUyxDQUFDbmlCLE1BQU0sQ0FBQ1AsUUFBUSxJQUFJQSxRQUFRLENBQUMyakIsS0FBSyxLQUFLeEMsVUFBVSxDQUFDLENBQUMzZ0IsT0FBTyxDQUFDUixRQUFRLElBQUlBLFFBQVEsQ0FBQytMLFFBQVEsQ0FBQzlGLE9BQU8sQ0FBQyxDQUFDO0VBQy9HO0VBQ0EsU0FBU2dmLGVBQWVBLENBQUM3aUIsTUFBTSxFQUFFO0lBQzdCLElBQUk4aUIsU0FBUyxHQUFHeGEsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLO0lBQ3pGLElBQUk7TUFDQXlhLEtBQUssQ0FBQy9pQixNQUFNLENBQUM7TUFDYkEsTUFBTSxDQUFDZ2pCLE9BQU8sQ0FBQzVrQixPQUFPLENBQUM2a0IsTUFBTSxJQUFJO1FBQzdCLElBQUksQ0FBQ3pDLFlBQVksQ0FBQ3lDLE1BQU0sQ0FBQyxFQUFFO1VBQ3ZCekMsWUFBWSxDQUFDeUMsTUFBTSxDQUFDLEdBQUdqRSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUM7UUFDdEQ7UUFDQWpvQixNQUFNLENBQUNtSCxJQUFJLENBQUM4QixNQUFNLENBQUNBLE1BQU0sQ0FBQyxDQUFDNUIsT0FBTyxDQUFDbWpCLEtBQUssSUFBSTtVQUN4QyxJQUFJbkIsTUFBTSxHQUFHcGdCLE1BQU0sQ0FBQ0EsTUFBTSxDQUFDdWhCLEtBQUssQ0FBQztVQUNqQyxJQUFJMkIsYUFBYSxHQUFHMUMsWUFBWSxDQUFDeUMsTUFBTSxDQUFDLENBQUMxQixLQUFLLENBQUM7VUFDL0MsSUFBSXBFLHdEQUFhLENBQUNpRCxNQUFNLENBQUMsS0FBSzhDLGFBQWEsSUFBSSxJQUFJLElBQUkvRix3REFBYSxDQUFDK0YsYUFBYSxDQUFDLENBQUMsRUFBRTtZQUNsRixJQUFJQyxJQUFJLEdBQUdMLFNBQVMsR0FBR3RGLGdEQUFTLEdBQUd6bUIsTUFBTSxDQUFDbXBCLE1BQU07WUFDaERNLFlBQVksQ0FBQ3lDLE1BQU0sQ0FBQyxDQUFDMUIsS0FBSyxDQUFDLEdBQUc0QixJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUVELGFBQWEsSUFBSSxDQUFDLENBQUMsRUFBRTlDLE1BQU0sQ0FBQztVQUN2RSxDQUFDLE1BQ0k7WUFDREksWUFBWSxDQUFDeUMsTUFBTSxDQUFDLENBQUMxQixLQUFLLENBQUMsR0FBR25CLE1BQU07VUFDeEM7UUFDSixDQUFDLENBQUM7TUFDTixDQUFDLENBQUM7SUFDTixDQUFDLENBQ0QsT0FBT3hwQixDQUFDLEVBQUU7TUFDTnltQixtREFBUSxDQUFDem1CLENBQUMsQ0FBQztJQUNmO0lBQ0EsU0FBU21zQixLQUFLQSxDQUFDenFCLEdBQUcsRUFBRTtNQUNoQixJQUFJLENBQUM2a0Isd0RBQWEsQ0FBQzdrQixHQUFHLENBQUMsRUFBRTtRQUNyQixNQUFNLGtEQUFrRDtNQUM1RDtNQUNBLElBQUksRUFBRStPLEtBQUssQ0FBQzZULE9BQU8sQ0FBQzVpQixHQUFHLENBQUMwcUIsT0FBTyxDQUFDLElBQUkxcUIsR0FBRyxDQUFDMHFCLE9BQU8sQ0FBQzVuQixNQUFNLENBQUMsRUFBRTtRQUNyRCxNQUFNLG1GQUFtRjtNQUM3RjtNQUNBLElBQUksQ0FBQytoQix3REFBYSxDQUFDN2tCLEdBQUcsQ0FBQzBILE1BQU0sQ0FBQyxFQUFFO1FBQzVCLE1BQU0sNkRBQTZEO01BQ3ZFO0lBQ0o7RUFDSjtFQUNBLFNBQVNvakIsV0FBV0EsQ0FBQzlxQixHQUFHLEVBQUU7SUFDdEIsSUFBSSxDQUFDNmtCLHdEQUFhLENBQUM3a0IsR0FBRyxDQUFDLEVBQUU7TUFDckIra0IsbURBQVEsQ0FBQyxxQ0FBcUMsQ0FBQztNQUMvQztJQUNKO0lBQ0EsSUFBSWdHLFlBQVksR0FBRzdGLG9EQUFTLENBQUNnRSxVQUFVLENBQUMsQ0FBQyxFQUFFbHBCLEdBQUcsQ0FBQztJQUMvQ2dxQixTQUFTLENBQUNubUIsYUFBYSxDQUFDLENBQUMsQ0FBQyxFQUFFa25CLFlBQVksQ0FBQyxDQUFDO0lBQzFDLE9BQU9BLFlBQVk7RUFDdkI7RUFDQSxTQUFTQyxpQkFBaUJBLENBQUNockIsR0FBRyxFQUFFO0lBQzVCLE9BQU91cUIsZUFBZSxDQUFDdnFCLEdBQUcsRUFBRSxJQUFJLENBQUM7RUFDckM7RUFDQTtBQUNKO0FBQ0E7RUFDSSxTQUFTaXJCLGFBQWFBLENBQUNOLE1BQU0sRUFBRWhaLEVBQUUsRUFBRTtJQUMvQndXLFVBQVUsR0FBR3dDLE1BQU07SUFDbkIsSUFBSTtNQUNBLE9BQU9oWixFQUFFLENBQUMsQ0FBQztJQUNmLENBQUMsU0FDTztNQUNKdVosV0FBVyxDQUFDLENBQUM7SUFDakI7RUFDSjtFQUNBLFNBQVNDLGtCQUFrQkEsQ0FBQ1IsTUFBTSxFQUFFO0lBQ2hDLE9BQU8sVUFBVVMsRUFBRSxFQUFFO01BQ2pCLE9BQU8sWUFBWTtRQUNmLElBQUksT0FBT0EsRUFBRSxLQUFLLFVBQVUsRUFBRTtVQUMxQixLQUFLLElBQUl0WixJQUFJLEdBQUc5QixTQUFTLENBQUNsTixNQUFNLEVBQUV1b0IsSUFBSSxHQUFHLElBQUl0YyxLQUFLLENBQUMrQyxJQUFJLENBQUMsRUFBRUMsSUFBSSxHQUFHLENBQUMsRUFBRUEsSUFBSSxHQUFHRCxJQUFJLEVBQUVDLElBQUksRUFBRSxFQUFFO1lBQ3JGc1osSUFBSSxDQUFDdFosSUFBSSxDQUFDLEdBQUcvQixTQUFTLENBQUMrQixJQUFJLENBQUM7VUFDaEM7VUFDQSxPQUFPa1osYUFBYSxDQUFDTixNQUFNLEVBQUVTLEVBQUUsQ0FBQ3ZELElBQUksQ0FBQyxJQUFJLEVBQUUsR0FBR3dELElBQUksQ0FBQyxDQUFDO1FBQ3hELENBQUMsTUFDSTtVQUNEcEcsa0RBQU8sQ0FBQyxzREFBc0QsQ0FBQztRQUNuRTtNQUNKLENBQUM7SUFDTCxDQUFDO0VBQ0w7RUFDQSxTQUFTcUcsZ0JBQWdCQSxDQUFBLEVBQUc7SUFDeEIsT0FBT25ELFVBQVU7RUFDckI7RUFDQSxTQUFTK0MsV0FBV0EsQ0FBQSxFQUFHO0lBQ25CL0MsVUFBVSxHQUFHLElBQUk7RUFDckI7RUFDQUMsV0FBVyxDQUFDLENBQUM7RUFDYixPQUFPO0lBQ0hrRCxnQkFBZ0I7SUFDaEJKLFdBQVc7SUFDWHpCLFNBQVM7SUFDVEQsWUFBWTtJQUNaRyxVQUFVO0lBQ1ZDLGFBQWE7SUFDYkksU0FBUztJQUNUYyxXQUFXO0lBQ1haLFdBQVc7SUFDWDlCLFdBQVc7SUFDWDZDLGFBQWE7SUFDYkUsa0JBQWtCO0lBQ2xCWixlQUFlO0lBQ2ZSLGVBQWU7SUFDZmlCO0VBQ0osQ0FBQztBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxJQUFJdGpCLE1BQU0sR0FBR3FnQixTQUFTLENBQUMsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFnQnhCLElBQUl3RCxZQUFZLEdBQUc7RUFDdEJDLE9BQU8sRUFBRSxNQUFNO0VBQ2ZDLE9BQU8sRUFBRSxPQUFPO0VBQ2hCQyxPQUFPLEVBQUUsTUFBTTtFQUNmQyxTQUFTLEVBQUUsUUFBUTtFQUNuQkMsS0FBSyxFQUFFLFNBQVM7RUFDaEJDLFFBQVEsRUFBRSxhQUFhO0VBQ3ZCQyxrQkFBa0IsRUFBRSxtQkFBbUI7RUFDdkNDLG1CQUFtQixFQUFFO0FBQ3pCLENBQUM7QUFDTSxJQUFJNUcsVUFBVSxHQUFHLFlBQVk7QUFDN0IsSUFBSTZHLE1BQU0sR0FBRztFQUNoQkMsSUFBSSxFQUFFO0FBQ1YsQ0FBQztBQUNNLElBQUlDLE1BQU0sR0FBRztFQUNoQkMsWUFBWSxFQUFFLGFBQWE7RUFDM0JDLGVBQWUsRUFBRSxnQkFBZ0I7RUFDakNDLFdBQVcsRUFBRSxZQUFZO0VBQ3pCQyxjQUFjLEVBQUUsZUFBZTtFQUMvQkMsV0FBVyxFQUFFLFlBQVk7RUFDekJDLGFBQWEsRUFBRSxjQUFjO0VBQzdCQyxZQUFZLEVBQUUsYUFBYTtFQUMzQkMsWUFBWSxFQUFFLGFBQWE7RUFDM0JDLE1BQU0sRUFBRSxPQUFPO0VBQ2ZDLFlBQVksRUFBRSxZQUFZO0VBQzFCQyxPQUFPLEVBQUUsUUFBUTtFQUNqQkMsV0FBVyxFQUFFLFlBQVk7RUFDekJDLFlBQVksRUFBRSxhQUFhO0VBQzNCQyxhQUFhLEVBQUUsY0FBYztFQUM3QkMsbUJBQW1CLEVBQUUsbUJBQW1CO0VBQ3hDQyxrQkFBa0IsRUFBRSxrQkFBa0I7RUFDdENDLFlBQVksRUFBRSxhQUFhO0VBQzNCQyxZQUFZLEVBQUUsWUFBWTtFQUMxQkMsZ0JBQWdCLEVBQUUsZ0JBQWdCO0VBQ2xDQyxtQkFBbUIsRUFBRSxtQkFBbUI7RUFDeENDLGdCQUFnQixFQUFFLGlCQUFpQjtFQUNuQ0MsYUFBYSxFQUFFLGNBQWM7RUFDN0JDLFlBQVksRUFBRSxhQUFhO0VBQzNCQyxZQUFZLEVBQUUsYUFBYTtFQUMzQkMsY0FBYyxFQUFFLGVBQWU7RUFDL0JDLGNBQWMsRUFBRSxlQUFlO0VBQy9CQyxZQUFZLEVBQUUsYUFBYTtFQUMzQkMsaUJBQWlCLEVBQUUsaUJBQWlCO0VBQ3BDQyxhQUFhLEVBQUUsY0FBYztFQUM3QkMsU0FBUyxFQUFFLFVBQVU7RUFDckJDLFlBQVksRUFBRSxZQUFZO0VBQzFCQyxXQUFXLEVBQUU7QUFDakIsQ0FBQztBQUNNLElBQUlDLHVCQUF1QixHQUFHO0VBQ2pDQyxnQ0FBZ0MsRUFBRSw4QkFBOEI7RUFDaEVDLEtBQUssRUFBRSxNQUFNO0VBQ2JDLFNBQVMsRUFBRSxXQUFXO0VBQ3RCQyxjQUFjLEVBQUUsY0FBYztFQUM5QkMsbUJBQW1CLEVBQUU7QUFDekIsQ0FBQztBQUNNLElBQUlDLGNBQWMsR0FBRztFQUN4QkMsTUFBTSxFQUFFO0FBQ1osQ0FBQztBQUNNLElBQUl4SSxtQkFBbUIsR0FBRztFQUM3QkMsR0FBRyxFQUFFLEtBQUs7RUFDVkMsTUFBTSxFQUFFLFFBQVE7RUFDaEJDLElBQUksRUFBRSxNQUFNO0VBQ1pDLElBQUksRUFBRSxNQUFNO0VBQ1pDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLE1BQU0sRUFBRTtBQUNaLENBQUM7QUFDTSxJQUFJbUksY0FBYyxHQUFHO0VBQ3hCQyxNQUFNLEVBQUUsV0FBVztFQUNuQkMsS0FBSyxFQUFFLFNBQVM7RUFDaEJDLFlBQVksRUFBRSxPQUFPO0VBQ3JCQyxJQUFJLEVBQUUsU0FBUztFQUNmQyxJQUFJLEVBQUUsU0FBUztFQUNmQyxNQUFNLEVBQUUsV0FBVztFQUNuQkMsTUFBTSxFQUFFLFdBQVc7RUFDbkJDLElBQUksRUFBRSxTQUFTO0VBQ2ZDLFFBQVEsRUFBRSxhQUFhO0VBQ3ZCQyxVQUFVLEVBQUUsZUFBZTtFQUMzQkMsT0FBTyxFQUFFLFlBQVk7RUFDckJDLElBQUksRUFBRSxTQUFTO0VBQ2ZDLElBQUksRUFBRSxTQUFTO0VBQ2ZDLEdBQUcsRUFBRTtBQUNULENBQUM7QUFDTSxJQUFJQyxzQkFBc0IsR0FBRztFQUNoQ2QsTUFBTSxFQUFFLFdBQVc7RUFDbkJDLEtBQUssRUFBRSxTQUFTO0VBQ2hCQyxZQUFZLEVBQUUsT0FBTztFQUNyQkMsSUFBSSxFQUFFLFNBQVM7RUFDZkMsSUFBSSxFQUFFLFNBQVM7RUFDZkUsTUFBTSxFQUFFLFdBQVc7RUFDbkJDLElBQUksRUFBRSxTQUFTO0VBQ2ZFLFVBQVUsRUFBRTtBQUNoQixDQUFDO0FBQ00sSUFBSU0sV0FBVyxHQUFHO0VBQ3JCQyxLQUFLLEVBQUUsaUJBQWlCO0VBQ3hCbFYsSUFBSSxFQUFFLGdCQUFnQjtFQUN0Qm1WLEtBQUssRUFBRSxpQkFBaUI7RUFDeEJDLFdBQVcsRUFBRSxtQkFBbUI7RUFDaENDLFdBQVcsRUFBRSxvQkFBb0I7RUFDakNDLFdBQVcsRUFBRSxpQkFBaUI7RUFDOUJDLEtBQUssRUFBRSxpQkFBaUI7RUFDeEJDLElBQUksRUFBRSxnQkFBZ0I7RUFDdEJDLFFBQVEsRUFBRSxtQkFBbUI7RUFDN0JDLFVBQVUsRUFBRSxzQkFBc0I7RUFDbENDLEdBQUcsRUFBRSxlQUFlO0VBQ3BCQyxNQUFNLEVBQUUsa0JBQWtCO0VBQzFCQyxPQUFPLEVBQUUsbUJBQW1CO0VBQzVCQyxTQUFTLEVBQUUscUJBQXFCO0VBQ2hDQyxLQUFLLEVBQUUsaUJBQWlCO0VBQ3hCQyxLQUFLLEVBQUUsaUJBQWlCO0VBQ3hCQyxLQUFLLEVBQUUsaUJBQWlCO0VBQ3hCQyxTQUFTLEVBQUUscUJBQXFCO0VBQ2hDQyxXQUFXLEVBQUUsaUJBQWlCO0VBQzlCQyxVQUFVLEVBQUU7QUFDaEIsQ0FBQztBQUNNLElBQUlDLEdBQUcsR0FBRztFQUNiQyxHQUFHLEVBQUUsS0FBSztFQUNWQyxnQkFBZ0IsRUFBRSxrREFBa0Q7RUFDcEVDLGtCQUFrQixFQUFFO0FBQ3hCLENBQUM7QUFDTSxJQUFJQyxVQUFVLEdBQUc7RUFDcEJDLGlCQUFpQixFQUFFLGNBQWM7RUFDakNDLFFBQVEsRUFBRSxVQUFVO0VBQ3BCM0UsWUFBWSxFQUFFO0FBQ2xCLENBQUM7QUFDTSxJQUFJNEUsZ0JBQWdCLEdBQUc7RUFDMUJDLE9BQU8sRUFBRSx1Q0FBdUM7RUFDaERDLGtCQUFrQixFQUFFLG9CQUFvQjtFQUN4Q0MsaUJBQWlCLEVBQUUscUZBQXFGO0VBQ3hHQyxhQUFhLEVBQUUsK0JBQStCO0VBQzlDQyx1QkFBdUIsRUFBRSw0QkFBNEI7RUFDckRDLFlBQVksRUFBRSxxREFBcUQ7RUFDbkVDLFlBQVksRUFBRSxrREFBa0Q7RUFDaEVDLGNBQWMsRUFBRTtBQUNwQixDQUFDO0FBQ00sSUFBSUMsK0JBQStCLEdBQUc7RUFDekNyWCxJQUFJLEVBQUUsTUFBTTtFQUNabVYsS0FBSyxFQUFFLE9BQU87RUFDZEcsV0FBVyxFQUFFLFdBQVc7RUFDeEJLLEdBQUcsRUFBRSxTQUFTO0VBQ2RDLE1BQU0sRUFBRSxRQUFRO0VBQ2hCQyxPQUFPLEVBQUUsU0FBUztFQUNsQkMsU0FBUyxFQUFFLFdBQVc7RUFDdEJDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLEtBQUssRUFBRSxPQUFPO0VBQ2RDLFNBQVMsRUFBRSxXQUFXO0VBQ3RCUixVQUFVLEVBQUU7QUFDaEIsQ0FBQztBQUNNLElBQUk0QixrQkFBa0IsR0FBRztFQUM1QkMsU0FBUyxFQUFFLENBQUM7RUFDWkMsSUFBSSxFQUFFLENBQUM7RUFDUDVCLE1BQU0sRUFBRSxDQUFDO0VBQ1RHLEtBQUssRUFBRSxDQUFDO0VBQ1JELFNBQVMsRUFBRSxDQUFDO0VBQ1pHLEtBQUssRUFBRSxDQUFDO0VBQ1J3QixTQUFTLEVBQUUsQ0FBQztFQUNaekIsS0FBSyxFQUFFLENBQUM7RUFDUkgsT0FBTyxFQUFFLENBQUM7RUFDVjZCLEtBQUssRUFBRSxFQUFFO0VBQ1RDLFVBQVUsRUFBRSxFQUFFO0VBQ2RDLE9BQU8sRUFBRTtBQUNiLENBQUM7QUFDTSxJQUFJQyxrQkFBa0IsR0FBRztFQUM1QkMsSUFBSSxFQUFFLENBQUM7RUFDUEMsSUFBSSxFQUFFO0FBQ1YsQ0FBQztBQUNNLElBQUlDLCtCQUErQixHQUFHLENBQUMsYUFBYSxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxZQUFZLEVBQUUsYUFBYSxFQUFFLE1BQU0sQ0FBQztBQUMzSCxJQUFJQyxRQUFRLEdBQUc7RUFDbEJDLE9BQU8sRUFBRSxnQkFBZ0I7RUFDekJDLFFBQVEsRUFBRSxpQkFBaUI7RUFDM0JDLE1BQU0sRUFBRSxlQUFlO0VBQ3ZCQyxLQUFLLEVBQUU7QUFDWCxDQUFDO0FBQ00sSUFBSUMsVUFBVSxHQUFHLGdCQUFnQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3S0g7QUFDUztBQUNUO0FBQ3JDLElBQUlFLGlCQUFpQixHQUFHLENBQUM7QUFDekIsSUFBSUMsY0FBYyxHQUFHO0VBQ2pCLFNBQVMsRUFBRSxDQUFDO0lBQ0osS0FBSyxFQUFFLENBQUM7SUFDUixXQUFXLEVBQUU7RUFDakIsQ0FBQztBQUNULENBQUM7QUFDRCxJQUFJQyxjQUFjLEdBQUc7RUFDakIsU0FBUyxFQUFFLENBQUM7SUFDSixLQUFLLEVBQUUsRUFBRTtJQUNULFdBQVcsRUFBRTtFQUNqQixDQUFDO0FBQ1QsQ0FBQztBQUNELElBQUlDLGNBQWMsR0FBRztFQUNqQixTQUFTLEVBQUUsQ0FBQztJQUNKLEtBQUssRUFBRSxFQUFFO0lBQ1QsV0FBVyxFQUFFO0VBQ2pCLENBQUM7QUFDVCxDQUFDO0FBQ0QsSUFBSUMsaUJBQWlCLEdBQUc7RUFDcEIsU0FBUyxFQUFFLENBQUM7SUFDSixLQUFLLEVBQUUsQ0FBQztJQUNSLFdBQVcsRUFBRTtFQUNqQixDQUFDLEVBQUU7SUFDQyxLQUFLLEVBQUUsQ0FBQztJQUNSLFdBQVcsRUFBRTtFQUNqQixDQUFDLEVBQUU7SUFDQyxLQUFLLEVBQUUsRUFBRTtJQUNULFdBQVcsRUFBRTtFQUNqQixDQUFDO0FBQ1QsQ0FBQztBQUNELElBQUlDLGdCQUFnQixHQUFHO0VBQ25CLFNBQVMsRUFBRSxDQUFDO0lBQ0osS0FBSyxFQUFFLENBQUM7SUFDUixXQUFXLEVBQUU7RUFDakIsQ0FBQyxFQUFFO0lBQ0MsS0FBSyxFQUFFLEVBQUU7SUFDVCxXQUFXLEVBQUU7RUFDakIsQ0FBQyxFQUFFO0lBQ0MsS0FBSyxFQUFFLEVBQUU7SUFDVCxXQUFXLEVBQUU7RUFDakIsQ0FBQztBQUNULENBQUM7QUFDRCxTQUFTQyxvQkFBb0JBLENBQUNDLEdBQUcsRUFBRUMsWUFBWSxFQUFFO0VBQzdDLElBQUlDLHFCQUFxQixHQUFHM2pCLFNBQVMsQ0FBQ2xOLE1BQU0sR0FBRyxDQUFDLElBQUlrTixTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUt5UCxTQUFTLEdBQUd6UCxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztFQUNqRyxJQUFJNGpCLFFBQVEsR0FBR0MsVUFBVSxDQUFDSixHQUFHLENBQUM7RUFDOUIsSUFBSUssS0FBSyxDQUFDRixRQUFRLENBQUMsRUFBRTtJQUNqQkEsUUFBUSxHQUFHLEVBQUU7RUFDakI7RUFDQSxPQUFPO0lBQ0hHLEdBQUcsRUFBRUgsUUFBUSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUdJLGlCQUFpQixDQUFDUCxHQUFHLEVBQUVOLGNBQWMsRUFBRVEscUJBQXFCLENBQUM7SUFDekZNLEdBQUcsRUFBRUwsUUFBUSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUdJLGlCQUFpQixDQUFDUCxHQUFHLEVBQUVMLGNBQWMsRUFBRU8scUJBQXFCLENBQUM7SUFDekZPLElBQUksRUFBRU4sUUFBUSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUdJLGlCQUFpQixDQUFDUCxHQUFHLEVBQUVKLGNBQWMsRUFBRU0scUJBQXFCLENBQUM7SUFDMUZRLElBQUksRUFBRVAsUUFBUSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUdJLGlCQUFpQixDQUFDUCxHQUFHLEVBQUVGLGdCQUFnQixFQUFFSSxxQkFBcUIsQ0FBQztJQUM1RlMsS0FBSyxFQUFFUixRQUFRLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBR0ksaUJBQWlCLENBQUNQLEdBQUcsRUFBRUgsaUJBQWlCLEVBQUVLLHFCQUFxQixDQUFDO0lBQzlGVSxNQUFNLEVBQUVULFFBQVEsS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHSSxpQkFBaUIsQ0FBQ1AsR0FBRyxFQUFFQyxZQUFZLEVBQUVDLHFCQUFxQjtFQUM3RixDQUFDO0FBQ0w7QUFDQSxTQUFTSyxpQkFBaUJBLENBQUNQLEdBQUcsRUFBRS9yQixNQUFNLEVBQUVpc0IscUJBQXFCLEVBQUU7RUFDM0QsSUFBSVcsTUFBTSxHQUFHLEVBQUU7RUFDZixJQUFJLENBQUMvUCxrQkFBa0IsQ0FBQzdjLE1BQU0sQ0FBQyxFQUFFO0lBQzdCLE9BQU80c0IsTUFBTTtFQUNqQjtFQUNBLElBQUlDLEdBQUcsR0FBRzdzQixNQUFNLENBQUM4c0IsT0FBTyxDQUFDendCLE1BQU0sQ0FBQyxDQUFDQyxJQUFJLEVBQUV5d0IsSUFBSSxLQUFLO0lBQzVDLElBQUl6d0IsSUFBSSxDQUFDMHdCLEdBQUcsR0FBR0QsSUFBSSxDQUFDQyxHQUFHLEVBQUU7TUFDckIsT0FBTzF3QixJQUFJO0lBQ2Y7SUFDQSxPQUFPeXdCLElBQUk7RUFDZixDQUFDLEVBQUU7SUFDQyxLQUFLLEVBQUU7RUFDWCxDQUFDLENBQUM7RUFDRixJQUFJRSxXQUFXLEdBQUcsQ0FBQztFQUNuQixJQUFJQyxNQUFNLEdBQUdyeEIsa0RBQUksQ0FBQ21FLE1BQU0sQ0FBQzhzQixPQUFPLEVBQUVJLE1BQU0sSUFBSTtJQUN4QyxJQUFJbkIsR0FBRyxHQUFHYyxHQUFHLENBQUNHLEdBQUcsR0FBR2YscUJBQXFCLEVBQUU7TUFDdkM7TUFDQSxJQUFJa0IsU0FBUyxHQUFHRCxNQUFNLENBQUNDLFNBQVM7TUFDaEMsSUFBSSxPQUFPQSxTQUFTLEtBQUssV0FBVyxFQUFFO1FBQ2xDQSxTQUFTLEdBQUczQixpQkFBaUI7TUFDakM7TUFDQW9CLE1BQU0sR0FBRyxDQUFDTSxNQUFNLENBQUNGLEdBQUcsR0FBR2YscUJBQXFCLEVBQUVtQixPQUFPLENBQUNELFNBQVMsQ0FBQztJQUNwRSxDQUFDLE1BQ0ksSUFBSXBCLEdBQUcsSUFBSW1CLE1BQU0sQ0FBQ0YsR0FBRyxHQUFHZixxQkFBcUIsSUFBSUYsR0FBRyxJQUFJa0IsV0FBVyxHQUFHaEIscUJBQXFCLEVBQUU7TUFDOUZpQixNQUFNLENBQUNHLEdBQUcsR0FBR0osV0FBVztNQUN4QixPQUFPQyxNQUFNO0lBQ2pCLENBQUMsTUFDSTtNQUNERCxXQUFXLEdBQUdDLE1BQU0sQ0FBQ0YsR0FBRztJQUM1QjtFQUNKLENBQUMsQ0FBQztFQUNGLElBQUlFLE1BQU0sRUFBRTtJQUNSTixNQUFNLEdBQUdVLFlBQVksQ0FBQ3ZCLEdBQUcsRUFBRW1CLE1BQU0sRUFBRWpCLHFCQUFxQixDQUFDO0VBQzdEO0VBQ0EsT0FBT1csTUFBTTtBQUNqQjtBQUNBLFNBQVMvUCxrQkFBa0JBLENBQUM3YyxNQUFNLEVBQUU7RUFDaEMsSUFBSXVyQixrREFBTyxDQUFDdnJCLE1BQU0sQ0FBQyxJQUFJLENBQUNBLE1BQU0sQ0FBQzhzQixPQUFPLElBQUksQ0FBQ3psQixLQUFLLENBQUM2VCxPQUFPLENBQUNsYixNQUFNLENBQUM4c0IsT0FBTyxDQUFDLEVBQUU7SUFDdEUsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBSXBiLE9BQU8sR0FBRyxJQUFJO0VBQ2xCMVIsTUFBTSxDQUFDOHNCLE9BQU8sQ0FBQzF1QixPQUFPLENBQUM4dUIsTUFBTSxJQUFJO0lBQzdCLElBQUksQ0FBQ0EsTUFBTSxDQUFDRixHQUFHLElBQUksQ0FBQ0UsTUFBTSxDQUFDSyxTQUFTLEVBQUU7TUFDbEM3YixPQUFPLEdBQUcsS0FBSztJQUNuQjtFQUNKLENBQUMsQ0FBQztFQUNGLE9BQU9BLE9BQU87QUFDbEI7QUFDQSxTQUFTNGIsWUFBWUEsQ0FBQ3ZCLEdBQUcsRUFBRW1CLE1BQU0sRUFBRWpCLHFCQUFxQixFQUFFO0VBQ3RELElBQUlrQixTQUFTLEdBQUcsT0FBT0QsTUFBTSxDQUFDQyxTQUFTLEtBQUssV0FBVyxHQUFHRCxNQUFNLENBQUNDLFNBQVMsR0FBRzNCLGlCQUFpQjtFQUM5RixJQUFJK0IsU0FBUyxHQUFHTCxNQUFNLENBQUNLLFNBQVMsR0FBR3RCLHFCQUFxQjtFQUN4RCxJQUFJdUIsU0FBUyxHQUFHTixNQUFNLENBQUNHLEdBQUcsR0FBR3BCLHFCQUFxQjtFQUNsRCxJQUFJd0IsZ0JBQWdCLEdBQUczb0IsSUFBSSxDQUFDQyxLQUFLO0VBQ2pDLElBQUkyb0Isc0JBQXNCLEdBQUcxdEIsOENBQU0sQ0FBQytoQixTQUFTLENBQUMscUJBQXFCLENBQUM7RUFDcEUsSUFBSSxPQUFPMkwsc0JBQXNCLEtBQUssVUFBVSxFQUFFO0lBQzlDRCxnQkFBZ0IsR0FBR0Msc0JBQXNCO0VBQzdDO0VBQ0E7RUFDQTtFQUNBO0VBQ0E7RUFDQTtFQUNBLElBQUlDLEdBQUcsR0FBRzdvQixJQUFJLENBQUM2b0IsR0FBRyxDQUFDLEVBQUUsRUFBRVIsU0FBUyxHQUFHLENBQUMsQ0FBQztFQUNyQyxJQUFJUyxVQUFVLEdBQUcsQ0FBQzdCLEdBQUcsR0FBRzRCLEdBQUcsR0FBR0gsU0FBUyxHQUFHRyxHQUFHLEtBQUtKLFNBQVMsR0FBR0ksR0FBRyxDQUFDO0VBQ2xFLElBQUlFLFNBQVM7RUFDYixJQUFJQyxlQUFlO0VBQ25CO0VBQ0E7RUFDQSxJQUFJO0lBQ0FELFNBQVMsR0FBR0osZ0JBQWdCLENBQUNHLFVBQVUsQ0FBQyxHQUFHTCxTQUFTLEdBQUdDLFNBQVM7RUFDcEUsQ0FBQyxDQUNELE9BQU9PLEdBQUcsRUFBRTtJQUNSRCxlQUFlLEdBQUcsSUFBSTtFQUMxQjtFQUNBLElBQUlBLGVBQWUsSUFBSSxPQUFPRCxTQUFTLEtBQUssUUFBUSxFQUFFO0lBQ2xEdFEsa0RBQU8sQ0FBQyw0Q0FBNEMsQ0FBQztJQUNyRHNRLFNBQVMsR0FBRy9vQixJQUFJLENBQUNDLEtBQUssQ0FBQzZvQixVQUFVLENBQUMsR0FBR0wsU0FBUyxHQUFHQyxTQUFTO0VBQzlEO0VBQ0E7RUFDQTtFQUNBSyxTQUFTLEdBQUdoMkIsTUFBTSxDQUFDZzJCLFNBQVMsQ0FBQ1QsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0VBQ3pDLE9BQU9TLFNBQVMsQ0FBQ1QsT0FBTyxDQUFDRCxTQUFTLENBQUM7QUFDdkM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9JQTtBQUNBO0FBQ08sU0FBU3JzQixRQUFRQSxDQUFDa3RCLE1BQU0sRUFBRUMsSUFBSSxFQUFFbHFCLEtBQUssRUFBRTtFQUMxQyxPQUFPaXFCLE1BQU0sSUFBSUEsTUFBTSxDQUFDbHRCLFFBQVEsQ0FBQ210QixJQUFJLEVBQUVscUIsS0FBSyxDQUFDLElBQUksS0FBSztBQUMxRDtBQUNPLFNBQVMrWSxTQUFTQSxDQUFBLEVBQUc7RUFDeEIsT0FBT3pWLEtBQUssQ0FBQ0MsSUFBSSxDQUFDYyxLQUFLLENBQUNmLEtBQUssRUFBRWlCLFNBQVMsQ0FBQztBQUM3QztBQUNPLFNBQVN6TSxJQUFJQSxDQUFDa0wsR0FBRyxFQUFFbW5CLElBQUksRUFBRUMsT0FBTyxFQUFFO0VBQ3JDLE9BQU9wbkIsR0FBRyxJQUFJQSxHQUFHLENBQUNsTCxJQUFJLENBQUNxeUIsSUFBSSxFQUFFQyxPQUFPLENBQUM7QUFDekM7QUFDTyxTQUFTQyxTQUFTQSxDQUFDcm5CLEdBQUcsRUFBRW1uQixJQUFJLEVBQUVDLE9BQU8sRUFBRTtFQUMxQyxPQUFPcG5CLEdBQUcsSUFBSUEsR0FBRyxDQUFDcW5CLFNBQVMsQ0FBQ0YsSUFBSSxFQUFFQyxPQUFPLENBQUM7QUFDOUMsQzs7Ozs7Ozs7Ozs7Ozs7O0FDYkE7QUFDQTtBQUNBO0FBQ0EsSUFBSTNYLEtBQUssR0FBRyxNQUFLLEdBQUcsQ0FBRSxHQUFHNVcsTUFBTTtBQUMvQixJQUFJeXVCLE1BQU0sR0FBRzdYLEtBQUssQ0FBQzhYLElBQUksR0FBRzlYLEtBQUssQ0FBQzhYLElBQUksSUFBSSxDQUFDLENBQUM7QUFDMUNELE1BQU0sQ0FBQ0UsR0FBRyxHQUFHRixNQUFNLENBQUNFLEdBQUcsSUFBSSxFQUFFO0FBQzdCRixNQUFNLENBQUNHLEdBQUcsR0FBR0gsTUFBTSxDQUFDRyxHQUFHLElBQUksRUFBRTtBQUM3QjtBQUNBLElBQUloWSxLQUFLLEtBQUs1VyxNQUFNLEVBQUU7RUFDbEI0VyxLQUFLLENBQUNpWSxZQUFZLEdBQUdqWSxLQUFLLENBQUNpWSxZQUFZLElBQUksRUFBRTtFQUM3Q2pZLEtBQUssQ0FBQ2lZLFlBQVksQ0FBQ3prQixJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ25DO0FBQ08sU0FBUzBrQixTQUFTQSxDQUFBLEVBQUc7RUFDeEIsT0FBT0wsTUFBTTtBQUNqQjtBQUNPLFNBQVNNLGNBQWNBLENBQUMzcEIsSUFBSSxFQUFFO0VBQ2pDcXBCLE1BQU0sQ0FBQ08sZ0JBQWdCLENBQUM1a0IsSUFBSSxDQUFDaEYsSUFBSSxDQUFDO0FBQ3RDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqQnFDO0FBQ0Y7QUFDTTtBQUNEO0FBQ1c7QUFDTDtBQUNPO0FBQy9CO0FBQ3NCO0FBQzVDLElBQUkrcEIsSUFBSSxHQUFHLFFBQVE7QUFDbkIsSUFBSUMsR0FBRyxHQUFHLFVBQVU7QUFDcEIsSUFBSUMsS0FBSyxHQUFHLFFBQVE7QUFDcEIsSUFBSUMsT0FBTyxHQUFHLFFBQVE7QUFDdEIsSUFBSUMsUUFBUSxHQUFHLFNBQVM7QUFDeEIsSUFBSXZvQixRQUFRLEdBQUc3UCxNQUFNLENBQUNrQixTQUFTLENBQUMyTyxRQUFRO0FBQ3hDLElBQUl3b0IsYUFBYSxHQUFHQyxPQUFPLENBQUN6dkIsTUFBTSxDQUFDMHZCLE9BQU8sQ0FBQztBQUMzQyxJQUFJQyxnQkFBZ0IsR0FBR0YsT0FBTyxDQUFDRCxhQUFhLElBQUl4dkIsTUFBTSxDQUFDMHZCLE9BQU8sQ0FBQ3J4QixHQUFHLENBQUM7QUFDbkUsSUFBSXV4QixpQkFBaUIsR0FBR0gsT0FBTyxDQUFDRCxhQUFhLElBQUl4dkIsTUFBTSxDQUFDMHZCLE9BQU8sQ0FBQ0csSUFBSSxDQUFDO0FBQ3JFLElBQUlDLGlCQUFpQixHQUFHTCxPQUFPLENBQUNELGFBQWEsSUFBSXh2QixNQUFNLENBQUMwdkIsT0FBTyxDQUFDSyxJQUFJLENBQUM7QUFDckUsSUFBSUMsa0JBQWtCLEdBQUdQLE9BQU8sQ0FBQ0QsYUFBYSxJQUFJeHZCLE1BQU0sQ0FBQzB2QixPQUFPLENBQUN4eEIsS0FBSyxDQUFDO0FBQ3ZFLElBQUkreEIsWUFBWTtBQUNoQixJQUFJQyxZQUFZLEdBQUdwQiwyREFBUyxDQUFDLENBQUM7QUFDdkIsU0FBU3FCLGdCQUFnQkEsQ0FBQ0MsTUFBTSxFQUFFO0VBQ3JDO0VBQ0FILFlBQVksR0FBR0csTUFBTTtBQUN6QjtBQUNBLFNBQVNDLFNBQVNBLENBQUEsRUFBRztFQUNqQixJQUFJSixZQUFZLElBQUksSUFBSSxFQUFFO0lBQ3RCQSxZQUFZLENBQUMsR0FBR3ZuQixTQUFTLENBQUM7RUFDOUI7QUFDSjtBQUNBO0FBQ08sSUFBSTRuQixRQUFRLEdBQUc7RUFDbEJDLGtCQUFrQjtFQUNsQkMsMEJBQTBCO0VBQzFCQyxhQUFhO0VBQ2JDLFlBQVk7RUFDWkMsa0JBQWtCO0VBQ2xCQyxpQkFBaUI7RUFDakJDLG9CQUFvQjtFQUNwQkMsYUFBYTtFQUNiQyxJQUFJO0VBQ0pDLFlBQVk7RUFDWnZULFFBQVE7RUFDUkUsT0FBTztFQUNQRCxVQUFVO0VBQ1Z1VCxPQUFPO0VBQ1BDLE9BQU87RUFDUEMsUUFBUTtFQUNSQztBQUNKLENBQUM7QUFDRCxJQUFJQyxjQUFjLEdBQUcsQ0FBQyxDQUFDO0FBQ3ZCO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGlCQUFpQkEsQ0FBQSxFQUFHO0VBQ2hDLE9BQU9ELGNBQWM7QUFDekI7QUFDQTtBQUNBLElBQUlFLHFCQUFxQixHQUFHLFlBQVk7RUFDcEMsSUFBSUMsS0FBSyxHQUFHLENBQUM7RUFDYixPQUFPLFlBQVk7SUFDZkEsS0FBSyxFQUFFO0lBQ1AsT0FBT0EsS0FBSztFQUNoQixDQUFDO0FBQ0wsQ0FBQyxDQUFDLENBQUM7QUFDSDtBQUNPLFNBQVNDLHNCQUFzQkEsQ0FBQSxFQUFHO0VBQ3JDLE9BQU9GLHFCQUFxQixDQUFDLENBQUMsR0FBR3JzQixJQUFJLENBQUN3c0IsTUFBTSxDQUFDLENBQUMsQ0FBQzFxQixRQUFRLENBQUMsRUFBRSxDQUFDLENBQUMycUIsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUN6RTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLFlBQVlBLENBQUNDLFdBQVcsRUFBRTtFQUN0QyxPQUFPQSxXQUFXLEdBQUcsQ0FBQ0EsV0FBVyxHQUFHQyxjQUFjLENBQUMsQ0FBQyxJQUFJRCxXQUFXLEdBQUcsQ0FBQyxFQUFFN3FCLFFBQVEsQ0FBQyxFQUFFLENBQUMsR0FBRyxDQUFDLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUVsQixPQUFPLENBQUMsUUFBUSxFQUFFOHJCLFlBQVksQ0FBQztBQUNoSztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU0UsY0FBY0EsQ0FBQSxFQUFHO0VBQ3RCLElBQUk5eEIsTUFBTSxJQUFJQSxNQUFNLENBQUNzSCxNQUFNLElBQUl0SCxNQUFNLENBQUNzSCxNQUFNLENBQUNDLGVBQWUsRUFBRTtJQUMxRCxPQUFPRCxNQUFNLENBQUNDLGVBQWUsQ0FBQyxJQUFJSCxVQUFVLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQzVELENBQUMsTUFDSTtJQUNELE9BQU9sQyxJQUFJLENBQUN3c0IsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFO0VBQzdCO0FBQ0o7QUFDTyxTQUFTSyxpQkFBaUJBLENBQUNwNUIsR0FBRyxFQUFFcTVCLFNBQVMsRUFBRTtFQUM5QyxPQUFPLENBQUNBLFNBQVMsS0FBSyxJQUFJLElBQUlBLFNBQVMsS0FBSyxLQUFLLENBQUMsR0FBRyxLQUFLLENBQUMsR0FBR0EsU0FBUyxDQUFDcjVCLEdBQUcsQ0FBQyxLQUFLLEVBQUU7QUFDdkY7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTczVCLDBCQUEwQkEsQ0FBQ0MsUUFBUSxFQUFFO0VBQ2pELElBQUlsVyxNQUFNLEdBQUcsRUFBRTtFQUNmLEtBQUssSUFBSXZLLENBQUMsSUFBSXlnQixRQUFRLEVBQUU7SUFDcEIsSUFBSUEsUUFBUSxDQUFDeFYsY0FBYyxDQUFDakwsQ0FBQyxDQUFDLEVBQUU7TUFDNUJ1SyxNQUFNLElBQUl2SyxDQUFDLEdBQUcsR0FBRyxHQUFHOUssa0JBQWtCLENBQUN1ckIsUUFBUSxDQUFDemdCLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRztJQUM3RDtFQUNKO0VBQ0F1SyxNQUFNLEdBQUdBLE1BQU0sQ0FBQ2xXLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0VBQ2pDLE9BQU9rVyxNQUFNO0FBQ2pCO0FBQ0E7QUFDTyxTQUFTbVcsNkJBQTZCQSxDQUFDQyxTQUFTLEVBQUU7RUFDckQ7RUFDQSxJQUFJQSxTQUFTLElBQUlqN0IsTUFBTSxDQUFDazdCLG1CQUFtQixDQUFDRCxTQUFTLENBQUMsQ0FBQzUyQixNQUFNLEdBQUcsQ0FBQyxFQUFFO0lBQy9ELE9BQU9yRSxNQUFNLENBQUNtSCxJQUFJLENBQUM4ekIsU0FBUyxDQUFDLENBQUN0MUIsR0FBRyxDQUFDbkUsR0FBRyxJQUFJLEVBQUUsQ0FBQ29DLE1BQU0sQ0FBQ3BDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQ29DLE1BQU0sQ0FBQzRMLGtCQUFrQixDQUFDeXJCLFNBQVMsQ0FBQ3o1QixHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQ2dQLElBQUksQ0FBQyxHQUFHLENBQUM7RUFDdEgsQ0FBQyxNQUNJO0lBQ0QsT0FBTyxFQUFFO0VBQ2I7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMycUIsaUJBQWlCQSxDQUFDQyxLQUFLLEVBQUU7RUFDckMsSUFBSSxPQUFPQSxLQUFLLEtBQUssUUFBUSxFQUFFO0lBQzNCO0lBQ0EsT0FBT0EsS0FBSyxDQUFDbnNCLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQ3RKLEdBQUcsQ0FBQzAxQixFQUFFLElBQUlBLEVBQUUsQ0FBQ0MsS0FBSyxDQUFDLGdCQUFnQixDQUFDLENBQUMsQ0FBQ2wwQixNQUFNLENBQUNrMEIsS0FBSyxJQUFJQSxLQUFLLENBQUMsQ0FBQzMxQixHQUFHLENBQUNoRSxJQUFJLElBQUk7TUFDbkcsSUFBSSxDQUFDd2dCLENBQUMsRUFBRW9aLENBQUMsRUFBRUMsQ0FBQyxDQUFDLEdBQUc3NUIsSUFBSTtNQUNwQixPQUFPLENBQUNvVCxRQUFRLENBQUN3bUIsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxFQUFFeG1CLFFBQVEsQ0FBQ3ltQixDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDN0MsQ0FBQyxDQUFDO0VBQ04sQ0FBQyxNQUNJLElBQUlsckIsS0FBSyxDQUFDNlQsT0FBTyxDQUFDaVgsS0FBSyxDQUFDLEVBQUU7SUFDM0IsSUFBSUssb0JBQW9CLENBQUNMLEtBQUssQ0FBQyxFQUFFO01BQzdCLE9BQU8sQ0FBQ0EsS0FBSyxDQUFDO0lBQ2xCO0lBQ0EsT0FBT0EsS0FBSyxDQUFDaDBCLE1BQU0sQ0FBQ3EwQixvQkFBb0IsQ0FBQztFQUM3QztFQUNBLE9BQU8sRUFBRTtBQUNiO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLGVBQWVBLENBQUNDLE9BQU8sRUFBRTtFQUNyQyxPQUFPUixpQkFBaUIsQ0FBQ1EsT0FBTyxDQUFDLENBQUNoMkIsR0FBRyxDQUFDaTJCLHFCQUFxQixDQUFDO0FBQ2hFO0FBQ08sU0FBU0EscUJBQXFCQSxDQUFDQyxJQUFJLEVBQUU7RUFDeEMsT0FBT0EsSUFBSSxDQUFDLENBQUMsQ0FBQyxHQUFHLEdBQUcsR0FBR0EsSUFBSSxDQUFDLENBQUMsQ0FBQztBQUNsQztBQUNBO0FBQ0E7QUFDTyxTQUFTQyx1QkFBdUJBLENBQUNDLFVBQVUsRUFBRTtFQUNoRCxJQUFJTixvQkFBb0IsQ0FBQ00sVUFBVSxDQUFDLEVBQUU7SUFDbEMsT0FBT0gscUJBQXFCLENBQUNHLFVBQVUsQ0FBQztFQUM1QztBQUNKO0FBQ08sU0FBU0Msa0JBQWtCQSxDQUFDSCxJQUFJLEVBQUU7RUFDckMsT0FBTztJQUNITixDQUFDLEVBQUVNLElBQUksQ0FBQyxDQUFDLENBQUM7SUFDVkwsQ0FBQyxFQUFFSyxJQUFJLENBQUMsQ0FBQztFQUNiLENBQUM7QUFDTDtBQUNBO0FBQ0E7QUFDTyxTQUFTSSxnQ0FBZ0NBLENBQUNGLFVBQVUsRUFBRTtFQUN6RCxJQUFJTixvQkFBb0IsQ0FBQ00sVUFBVSxDQUFDLEVBQUU7SUFDbEMsT0FBT0Msa0JBQWtCLENBQUNELFVBQVUsQ0FBQztFQUN6QztBQUNKO0FBQ0EsU0FBU04sb0JBQW9CQSxDQUFDTSxVQUFVLEVBQUU7RUFDdEM7RUFDQSxPQUFPNVgsT0FBTyxDQUFDNFgsVUFBVSxDQUFDLElBQUlBLFVBQVUsQ0FBQzEzQixNQUFNLEtBQUssQ0FBQyxJQUFJLENBQUNneEIsS0FBSyxDQUFDMEcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzFHLEtBQUssQ0FBQzBHLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzRztBQUNPLFNBQVN4QyxZQUFZQSxDQUFBLEVBQUc7RUFDM0IsT0FBTzF3QixNQUFNLENBQUNxekIsR0FBRztBQUNyQjtBQUNPLFNBQVM1QyxhQUFhQSxDQUFBLEVBQUc7RUFDNUIsT0FBT3p3QixNQUFNLENBQUNzekIsSUFBSTtBQUN0QjtBQUNPLFNBQVMxQyxpQkFBaUJBLENBQUEsRUFBRztFQUNoQyxPQUFPNXdCLE1BQU0sQ0FBQ1UsUUFBUTtBQUMxQjtBQUNPLFNBQVNpd0Isa0JBQWtCQSxDQUFBLEVBQUc7RUFDakMsSUFBSTtJQUNBLElBQUlMLFFBQVEsQ0FBQ0ksWUFBWSxDQUFDLENBQUMsQ0FBQ2h3QixRQUFRLENBQUNrRyxJQUFJLEVBQUU7TUFDdkMsT0FBTyxJQUFJO0lBQ2Y7RUFDSixDQUFDLENBQ0QsT0FBTzVQLENBQUMsRUFBRTtJQUNOLE9BQU8sS0FBSztFQUNoQjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzBtQixVQUFVQSxDQUFBLEVBQUc7RUFDekIsSUFBSTZWLGFBQWEsQ0FBQyxDQUFDLElBQUk1RCxnQkFBZ0IsRUFBRTtJQUNyQztJQUNBRCxPQUFPLENBQUNyeEIsR0FBRyxDQUFDbUssS0FBSyxDQUFDa25CLE9BQU8sRUFBRThELFdBQVcsQ0FBQzlxQixTQUFTLEVBQUUsVUFBVSxDQUFDLENBQUM7RUFDbEU7QUFDSjtBQUNPLFNBQVN1b0IsT0FBT0EsQ0FBQSxFQUFHO0VBQ3RCLElBQUlzQyxhQUFhLENBQUMsQ0FBQyxJQUFJM0QsaUJBQWlCLEVBQUU7SUFDdEM7SUFDQUYsT0FBTyxDQUFDRyxJQUFJLENBQUNybkIsS0FBSyxDQUFDa25CLE9BQU8sRUFBRThELFdBQVcsQ0FBQzlxQixTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7RUFDaEU7QUFDSjtBQUNPLFNBQVNpVixPQUFPQSxDQUFBLEVBQUc7RUFDdEIsSUFBSTRWLGFBQWEsQ0FBQyxDQUFDLElBQUl6RCxpQkFBaUIsRUFBRTtJQUN0QztJQUNBSixPQUFPLENBQUNLLElBQUksQ0FBQ3ZuQixLQUFLLENBQUNrbkIsT0FBTyxFQUFFOEQsV0FBVyxDQUFDOXFCLFNBQVMsRUFBRSxVQUFVLENBQUMsQ0FBQztFQUNuRTtFQUNBMm5CLFNBQVMsQ0FBQ3pMLGlEQUFNLENBQUNzQixhQUFhLEVBQUU7SUFDNUJ1TixJQUFJLEVBQUUsU0FBUztJQUNmL3FCLFNBQVMsRUFBRUE7RUFDZixDQUFDLENBQUM7QUFDTjtBQUNPLFNBQVMrVSxRQUFRQSxDQUFBLEVBQUc7RUFDdkIsSUFBSThWLGFBQWEsQ0FBQyxDQUFDLElBQUl2RCxrQkFBa0IsRUFBRTtJQUN2QztJQUNBTixPQUFPLENBQUN4eEIsS0FBSyxDQUFDc0ssS0FBSyxDQUFDa25CLE9BQU8sRUFBRThELFdBQVcsQ0FBQzlxQixTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7RUFDbEU7RUFDQTJuQixTQUFTLENBQUN6TCxpREFBTSxDQUFDc0IsYUFBYSxFQUFFO0lBQzVCdU4sSUFBSSxFQUFFLE9BQU87SUFDYi9xQixTQUFTLEVBQUVBO0VBQ2YsQ0FBQyxDQUFDO0FBQ047QUFDTyxTQUFTZ3JCLFNBQVNBLENBQUNDLE1BQU0sRUFBRTtFQUM5QixTQUFTQyxRQUFRQSxDQUFDdnBCLEVBQUUsRUFBRTtJQUNsQixPQUFPLFlBQVk7TUFDZixLQUFLLElBQUlHLElBQUksR0FBRzlCLFNBQVMsQ0FBQ2xOLE1BQU0sRUFBRXVvQixJQUFJLEdBQUcsSUFBSXRjLEtBQUssQ0FBQytDLElBQUksQ0FBQyxFQUFFQyxJQUFJLEdBQUcsQ0FBQyxFQUFFQSxJQUFJLEdBQUdELElBQUksRUFBRUMsSUFBSSxFQUFFLEVBQUU7UUFDckZzWixJQUFJLENBQUN0WixJQUFJLENBQUMsR0FBRy9CLFNBQVMsQ0FBQytCLElBQUksQ0FBQztNQUNoQztNQUNBSixFQUFFLENBQUNzcEIsTUFBTSxFQUFFLEdBQUc1UCxJQUFJLENBQUM7SUFDdkIsQ0FBQztFQUNMO0VBQ0EsT0FBTztJQUNIdEcsUUFBUSxFQUFFbVcsUUFBUSxDQUFDblcsUUFBUSxDQUFDO0lBQzVCRSxPQUFPLEVBQUVpVyxRQUFRLENBQUNqVyxPQUFPLENBQUM7SUFDMUJELFVBQVUsRUFBRWtXLFFBQVEsQ0FBQ2xXLFVBQVUsQ0FBQztJQUNoQ3VULE9BQU8sRUFBRTJDLFFBQVEsQ0FBQzNDLE9BQU87RUFDN0IsQ0FBQztBQUNMO0FBQ0EsU0FBU3VDLFdBQVdBLENBQUN6UCxJQUFJLEVBQUU0UCxNQUFNLEVBQUU7RUFDL0I1UCxJQUFJLEdBQUcsRUFBRSxDQUFDbmMsS0FBSyxDQUFDOVAsSUFBSSxDQUFDaXNCLElBQUksQ0FBQztFQUMxQixJQUFJVixNQUFNLEdBQUdqakIsOENBQU0sQ0FBQzRqQixnQkFBZ0IsQ0FBQyxDQUFDO0VBQ3RDMlAsTUFBTSxJQUFJNVAsSUFBSSxDQUFDOFAsT0FBTyxDQUFDRixNQUFNLENBQUM7RUFDOUIsSUFBSXRRLE1BQU0sRUFBRTtJQUNSVSxJQUFJLENBQUM4UCxPQUFPLENBQUNDLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztFQUMvQjtFQUNBL1AsSUFBSSxDQUFDOFAsT0FBTyxDQUFDQyxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7RUFDOUIvUCxJQUFJLENBQUM4UCxPQUFPLENBQUMsVUFBVSxJQUFJeFEsTUFBTSxHQUFHLElBQUksQ0FBQ3RvQixNQUFNLENBQUNzb0IsTUFBTSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7RUFDOUQsT0FBT1UsSUFBSTtFQUNYLFNBQVMrUCxLQUFLQSxDQUFDQyxLQUFLLEVBQUU7SUFDbEIsT0FBTyxrREFBa0QsQ0FBQ2g1QixNQUFNLENBQUNnNUIsS0FBSyxFQUFFLHlDQUF5QyxDQUFDO0VBQ3RIO0FBQ0o7QUFDTyxTQUFTQyxnQkFBZ0JBLENBQUEsRUFBRztFQUMvQixPQUFPckUsZ0JBQWdCO0FBQzNCO0FBQ08sU0FBUzRELGFBQWFBLENBQUEsRUFBRztFQUM1QixPQUFPLENBQUMsQ0FBQ256Qiw4Q0FBTSxDQUFDK2hCLFNBQVMsQ0FBQyxPQUFPLENBQUM7QUFDdEM7QUFDTyxJQUFJOFIsWUFBWSxHQUFHLENBQUMsTUFBTTtFQUM3QixJQUFJQyxRQUFRLEdBQUc7SUFDWEMsTUFBTSxFQUFFLEtBQUs7SUFDYkMsTUFBTSxFQUFFLEdBQUc7SUFDWEMsTUFBTSxFQUFFLEdBQUc7SUFDWEMsV0FBVyxFQUFFLEdBQUc7SUFDaEJDLFlBQVksRUFBRSxHQUFHO0lBQ2pCQyxTQUFTLEVBQUUsSUFBSTtJQUNmQyxXQUFXLEVBQUUsR0FBRztJQUNoQkMsaUJBQWlCLEVBQUU7RUFDdkIsQ0FBQztFQUNELE9BQU8sVUFBVUMsR0FBRyxFQUFFQyxLQUFLLEVBQUU7SUFDekIsSUFBSTNoQixLQUFLLEdBQUd2SyxTQUFTLENBQUNsTixNQUFNLEdBQUcsQ0FBQyxJQUFJa04sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLeVAsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztJQUNsRixJQUFJbXNCLENBQUMsR0FBR0YsR0FBRyxDQUFDM2hCLGFBQWEsQ0FBQyxRQUFRLENBQUM7SUFDbkM3YixNQUFNLENBQUNtcEIsTUFBTSxDQUFDdVUsQ0FBQyxFQUFFMTlCLE1BQU0sQ0FBQ21wQixNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUU0VCxRQUFRLEVBQUVVLEtBQUssQ0FBQyxDQUFDO0lBQ3BEejlCLE1BQU0sQ0FBQ21wQixNQUFNLENBQUN1VSxDQUFDLENBQUM1aEIsS0FBSyxFQUFFQSxLQUFLLENBQUM7SUFDN0IsT0FBTzRoQixDQUFDO0VBQ1osQ0FBQztBQUNMLENBQUMsRUFBRSxDQUFDO0FBQ0csU0FBU0MscUJBQXFCQSxDQUFBLEVBQUc7RUFDcEMsT0FBT2IsWUFBWSxDQUFDbnZCLFFBQVEsRUFBRTtJQUMxQnhLLEVBQUUsRUFBRW0zQixzQkFBc0IsQ0FBQyxDQUFDO0lBQzVCc0QsS0FBSyxFQUFFLENBQUM7SUFDUkMsTUFBTSxFQUFFLENBQUM7SUFDVDdoQixHQUFHLEVBQUU7RUFDVCxDQUFDLEVBQUU7SUFDQ0QsT0FBTyxFQUFFLE1BQU07SUFDZjhoQixNQUFNLEVBQUUsS0FBSztJQUNiRCxLQUFLLEVBQUUsS0FBSztJQUNaWixNQUFNLEVBQUU7RUFDWixDQUFDLENBQUM7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzlXLGtCQUFrQkEsQ0FBQ2pZLElBQUksRUFBRTtFQUNyQyxPQUFPOHJCLE9BQU8sQ0FBQ04saUJBQWlCLENBQUMsQ0FBQyxDQUFDcUUsTUFBTSxDQUFDLENBQUM3dkIsSUFBSSxDQUFDLElBQUksRUFBRTtBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzh2QixHQUFHQSxDQUFDQyxNQUFNLEVBQUVDLEVBQUUsRUFBRTtFQUM1QixPQUFPcHVCLFFBQVEsQ0FBQ2xQLElBQUksQ0FBQ3E5QixNQUFNLENBQUMsS0FBSyxVQUFVLEdBQUdDLEVBQUUsR0FBRyxHQUFHO0FBQzFEO0FBQ08sU0FBU3JFLElBQUlBLENBQUNvRSxNQUFNLEVBQUU7RUFDekIsT0FBT0QsR0FBRyxDQUFDQyxNQUFNLEVBQUUvRixHQUFHLENBQUM7QUFDM0I7QUFDTyxTQUFTNVIsS0FBS0EsQ0FBQzJYLE1BQU0sRUFBRTtFQUMxQixPQUFPRCxHQUFHLENBQUNDLE1BQU0sRUFBRWhHLElBQUksQ0FBQztBQUM1QjtBQUNPLElBQUk3VCxPQUFPLEdBQUc3VCxLQUFLLENBQUM2VCxPQUFPLENBQUNpRixJQUFJLENBQUM5WSxLQUFLLENBQUM7QUFDdkMsU0FBUzR0QixRQUFRQSxDQUFDRixNQUFNLEVBQUU7RUFDN0IsT0FBT0QsR0FBRyxDQUFDQyxNQUFNLEVBQUU5RixLQUFLLENBQUM7QUFDN0I7QUFDTyxTQUFTOVIsYUFBYUEsQ0FBQzRYLE1BQU0sRUFBRTtFQUNsQyxPQUFPRCxHQUFHLENBQUNDLE1BQU0sRUFBRTdGLE9BQU8sQ0FBQztBQUMvQjtBQUNPLFNBQVNoUyxTQUFTQSxDQUFDNlgsTUFBTSxFQUFFO0VBQzlCLE9BQU9ELEdBQUcsQ0FBQ0MsTUFBTSxFQUFFNUYsUUFBUSxDQUFDO0FBQ2hDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzVELE9BQU9BLENBQUN3SixNQUFNLEVBQUU7RUFDNUIsSUFBSSxDQUFDQSxNQUFNLEVBQ1AsT0FBTyxJQUFJO0VBQ2YsSUFBSTdaLE9BQU8sQ0FBQzZaLE1BQU0sQ0FBQyxJQUFJM1gsS0FBSyxDQUFDMlgsTUFBTSxDQUFDLEVBQUU7SUFDbEMsT0FBTyxFQUFFQSxNQUFNLENBQUMzNUIsTUFBTSxHQUFHLENBQUMsQ0FBQztFQUMvQjtFQUNBLE9BQU9yRSxNQUFNLENBQUNtSCxJQUFJLENBQUM2MkIsTUFBTSxDQUFDLENBQUMzNUIsTUFBTSxJQUFJLENBQUM7QUFDMUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzg1QixVQUFVQSxDQUFDOXRCLEdBQUcsRUFBRTtFQUM1QixPQUFPZ1csS0FBSyxDQUFDaFcsR0FBRyxDQUFDLEtBQUssQ0FBQ0EsR0FBRyxJQUFJQSxHQUFHLENBQUNoTSxNQUFNLEtBQUssQ0FBQyxDQUFDO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTKzVCLEtBQUtBLENBQUNKLE1BQU0sRUFBRTlxQixFQUFFLEVBQUU7RUFDOUIsSUFBSTBtQixJQUFJLENBQUNvRSxNQUFNLEtBQUssSUFBSSxJQUFJQSxNQUFNLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUdBLE1BQU0sQ0FBQzMyQixPQUFPLENBQUMsRUFDcEUsT0FBTzIyQixNQUFNLENBQUMzMkIsT0FBTyxDQUFDNkwsRUFBRSxFQUFFLElBQUksQ0FBQztFQUNuQ2xULE1BQU0sQ0FBQ2twQixPQUFPLENBQUM4VSxNQUFNLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzMyQixPQUFPLENBQUNxSyxLQUFLLElBQUk7SUFDMUMsSUFBSSxDQUFDNEksQ0FBQyxFQUFFK2pCLENBQUMsQ0FBQyxHQUFHM3NCLEtBQUs7SUFDbEIsT0FBT3dCLEVBQUUsQ0FBQ3ZTLElBQUksQ0FBQyxJQUFJLEVBQUUwOUIsQ0FBQyxFQUFFL2pCLENBQUMsQ0FBQztFQUM5QixDQUFDLENBQUM7QUFDTjtBQUNPLFNBQVNzQyxRQUFRQSxDQUFDMGhCLENBQUMsRUFBRS84QixHQUFHLEVBQUU7RUFDN0IsT0FBT3E0QixJQUFJLENBQUMwRSxDQUFDLEtBQUssSUFBSSxJQUFJQSxDQUFDLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUdBLENBQUMsQ0FBQ3YwQixRQUFRLENBQUMsSUFBSXUwQixDQUFDLENBQUN2MEIsUUFBUSxDQUFDeEksR0FBRyxDQUFDO0FBQ3BGO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTZzlCLElBQUlBLENBQUNQLE1BQU0sRUFBRXByQixRQUFRLEVBQUU7RUFDbkMsSUFBSWduQixJQUFJLENBQUNvRSxNQUFNLEtBQUssSUFBSSxJQUFJQSxNQUFNLEtBQUssS0FBSyxDQUFDLEdBQUcsS0FBSyxDQUFDLEdBQUdBLE1BQU0sQ0FBQ3I0QixHQUFHLENBQUMsRUFDaEUsT0FBT3E0QixNQUFNLENBQUNyNEIsR0FBRyxDQUFDaU4sUUFBUSxDQUFDO0VBQy9CLE9BQU81UyxNQUFNLENBQUNrcEIsT0FBTyxDQUFDOFUsTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUNyNEIsR0FBRyxDQUFDK1QsS0FBSyxJQUFJO0lBQzdDLElBQUksQ0FBQ1ksQ0FBQyxFQUFFK2pCLENBQUMsQ0FBQyxHQUFHM2tCLEtBQUs7SUFDbEIsT0FBTzlHLFFBQVEsQ0FBQ3lyQixDQUFDLEVBQUUvakIsQ0FBQyxFQUFFMGpCLE1BQU0sQ0FBQztFQUNqQyxDQUFDLENBQUM7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTckUsYUFBYUEsQ0FBQzZFLEdBQUcsRUFBRWhCLEdBQUcsRUFBRXZHLE1BQU0sRUFBRXdILGdCQUFnQixFQUFFO0VBQzlEakIsR0FBRyxHQUFHQSxHQUFHLElBQUk3dkIsUUFBUTtFQUNyQixJQUFJK3dCLFFBQVE7RUFDWixJQUFJekgsTUFBTSxFQUFFO0lBQ1J5SCxRQUFRLEdBQUdsQixHQUFHLENBQUNtQixvQkFBb0IsQ0FBQzFILE1BQU0sQ0FBQztFQUMvQyxDQUFDLE1BQ0k7SUFDRHlILFFBQVEsR0FBR2xCLEdBQUcsQ0FBQ21CLG9CQUFvQixDQUFDLE1BQU0sQ0FBQztFQUMvQztFQUNBLElBQUk7SUFDQUQsUUFBUSxHQUFHQSxRQUFRLENBQUNyNkIsTUFBTSxHQUFHcTZCLFFBQVEsR0FBR2xCLEdBQUcsQ0FBQ21CLG9CQUFvQixDQUFDLE1BQU0sQ0FBQztJQUN4RSxJQUFJRCxRQUFRLENBQUNyNkIsTUFBTSxFQUFFO01BQ2pCcTZCLFFBQVEsR0FBR0EsUUFBUSxDQUFDLENBQUMsQ0FBQztNQUN0QixJQUFJRSxjQUFjLEdBQUdILGdCQUFnQixHQUFHLElBQUksR0FBR0MsUUFBUSxDQUFDRyxVQUFVO01BQ2xFLE9BQU9ILFFBQVEsQ0FBQ0ksWUFBWSxDQUFDTixHQUFHLEVBQUVJLGNBQWMsQ0FBQztJQUNyRDtFQUNKLENBQUMsQ0FDRCxPQUFPLytCLENBQUMsRUFBRSxDQUFFO0FBQ2hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNrL0Isb0JBQW9CQSxDQUFDQyxPQUFPLEVBQUV2eEIsT0FBTyxFQUFFO0VBQ25ELElBQUl3eEIsS0FBSyxHQUFHLElBQUk7RUFDaEIsT0FBTyxJQUFJbkgsNERBQWEsQ0FBQ3ZjLE9BQU8sSUFBSTtJQUNoQyxJQUFJMmpCLE1BQU0sR0FBRyxTQUFBQSxDQUFBLEVBQVk7TUFDckJGLE9BQU8sQ0FBQ3ZqQixtQkFBbUIsQ0FBQyxNQUFNLEVBQUV5akIsTUFBTSxDQUFDO01BQzNDRixPQUFPLENBQUN2akIsbUJBQW1CLENBQUMsT0FBTyxFQUFFeWpCLE1BQU0sQ0FBQztNQUM1QyxJQUFJRCxLQUFLLElBQUksSUFBSSxFQUFFO1FBQ2ZwMkIsTUFBTSxDQUFDdUUsWUFBWSxDQUFDNnhCLEtBQUssQ0FBQztNQUM5QjtNQUNBMWpCLE9BQU8sQ0FBQyxDQUFDO0lBQ2IsQ0FBQztJQUNEeWpCLE9BQU8sQ0FBQ254QixnQkFBZ0IsQ0FBQyxNQUFNLEVBQUVxeEIsTUFBTSxDQUFDO0lBQ3hDRixPQUFPLENBQUNueEIsZ0JBQWdCLENBQUMsT0FBTyxFQUFFcXhCLE1BQU0sQ0FBQztJQUN6QyxJQUFJenhCLE9BQU8sSUFBSSxJQUFJLEVBQUU7TUFDakJ3eEIsS0FBSyxHQUFHcDJCLE1BQU0sQ0FBQzZFLFVBQVUsQ0FBQ3d4QixNQUFNLEVBQUV6eEIsT0FBTyxDQUFDO0lBQzlDO0VBQ0osQ0FBQyxDQUFDO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTb3NCLFlBQVlBLENBQUNsZSxHQUFHLEVBQUV3akIsSUFBSSxFQUFFMXhCLE9BQU8sRUFBRTtFQUM3QyxJQUFJMnhCLEdBQUcsR0FBRyxJQUFJQyxLQUFLLENBQUMsQ0FBQztFQUNyQixJQUFJRixJQUFJLElBQUloRyxRQUFRLENBQUNTLElBQUksQ0FBQ3VGLElBQUksQ0FBQyxFQUFFO0lBQzdCSixvQkFBb0IsQ0FBQ0ssR0FBRyxFQUFFM3hCLE9BQU8sQ0FBQyxDQUFDNnhCLElBQUksQ0FBQ0gsSUFBSSxDQUFDO0VBQ2pEO0VBQ0FDLEdBQUcsQ0FBQ3BqQixHQUFHLEdBQUdMLEdBQUc7QUFDakI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzRqQixvQkFBb0JBLENBQUNDLFFBQVEsRUFBRTtFQUMzQyxJQUFJLENBQUNBLFFBQVEsRUFBRTtJQUNYO0VBQ0o7RUFDQSxJQUFJOWlCLE1BQU0sR0FBR2loQixxQkFBcUIsQ0FBQyxDQUFDO0VBQ3BDeEUsUUFBUSxDQUFDUSxhQUFhLENBQUNqZCxNQUFNLEVBQUUvTyxRQUFRLEVBQUUsTUFBTSxDQUFDO0VBQ2hELENBQUM2dkIsR0FBRyxJQUFJO0lBQ0pBLEdBQUcsQ0FBQ2lDLElBQUksQ0FBQyxDQUFDO0lBQ1ZqQyxHQUFHLENBQUNrQyxLQUFLLENBQUNGLFFBQVEsQ0FBQztJQUNuQmhDLEdBQUcsQ0FBQ21DLEtBQUssQ0FBQyxDQUFDO0VBQ2YsQ0FBQyxFQUFFampCLE1BQU0sQ0FBQ2tqQixhQUFhLENBQUNqeUIsUUFBUSxDQUFDO0FBQ3JDO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUytyQixvQkFBb0JBLENBQUMvZCxHQUFHLEVBQUV3akIsSUFBSSxFQUFFMXhCLE9BQU8sRUFBRTtFQUNyRCxJQUFJb3lCLFVBQVUsR0FBRzFHLFFBQVEsQ0FBQ0UsMEJBQTBCLENBQUMxZCxHQUFHLEVBQUUsS0FBSyxFQUFFLGlDQUFpQyxDQUFDO0VBQ25HLElBQUlta0IsR0FBRyxHQUFHbnlCLFFBQVEsQ0FBQ2tPLGFBQWEsQ0FBQyxLQUFLLENBQUM7RUFDdkNpa0IsR0FBRyxDQUFDQyxTQUFTLEdBQUdGLFVBQVU7RUFDMUIsSUFBSW5qQixNQUFNLEdBQUdvakIsR0FBRyxDQUFDakIsVUFBVTtFQUMzQixJQUFJTSxJQUFJLElBQUloRyxRQUFRLENBQUNTLElBQUksQ0FBQ3VGLElBQUksQ0FBQyxFQUFFO0lBQzdCSixvQkFBb0IsQ0FBQ3JpQixNQUFNLEVBQUVqUCxPQUFPLENBQUMsQ0FBQzZ4QixJQUFJLENBQUNILElBQUksQ0FBQztFQUNwRDtFQUNBaEcsUUFBUSxDQUFDUSxhQUFhLENBQUNqZCxNQUFNLEVBQUUvTyxRQUFRLEVBQUUsTUFBTSxFQUFFLElBQUksQ0FBQztBQUMxRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNxeUIsb0JBQW9CQSxDQUFDcmtCLEdBQUcsRUFBRTtFQUN0QyxJQUFJN0ssTUFBTSxHQUFHUyxTQUFTLENBQUNsTixNQUFNLEdBQUcsQ0FBQyxJQUFJa04sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLeVAsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHMHVCLFNBQVM7RUFDMUYsSUFBSSxDQUFDdGtCLEdBQUcsRUFBRTtJQUNOLE9BQU8sRUFBRTtFQUNiO0VBQ0EsSUFBSXVrQixVQUFVLEdBQUdwdkIsTUFBTSxDQUFDNkssR0FBRyxDQUFDO0VBQzVCLElBQUl5akIsR0FBRyxHQUFHLHFFQUFxRTtFQUMvRUEsR0FBRyxJQUFJLFlBQVksR0FBR2MsVUFBVSxHQUFHLFVBQVU7RUFDN0MsT0FBT2QsR0FBRztBQUNkO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2UsY0FBY0EsQ0FBQ3hrQixHQUFHLEVBQUU7RUFDaEMsSUFBSXlrQixNQUFNLEdBQUc5dkIsS0FBSyxDQUFDQyxJQUFJLENBQUNvTCxHQUFHLENBQUMwa0IsUUFBUSxDQUFDLGNBQWMsQ0FBQyxDQUFDLENBQUMxNkIsR0FBRyxDQUFDMjFCLEtBQUssSUFBSUEsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQzVFLE9BQU84RSxNQUFNLENBQUM5NkIsTUFBTSxDQUFDLENBQUMrSyxHQUFHLEVBQUVpd0IsS0FBSyxLQUFLO0lBQ2pDLE9BQU9qd0IsR0FBRyxDQUFDMUIsT0FBTyxDQUFDLEdBQUcsR0FBR2Esa0JBQWtCLENBQUM4d0IsS0FBSyxDQUFDLEVBQUUsR0FBRyxHQUFHQSxLQUFLLENBQUM7RUFDcEUsQ0FBQyxFQUFFTCxTQUFTLENBQUN0a0IsR0FBRyxDQUFDLENBQUM7QUFDdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVMwZCwwQkFBMEJBLENBQUMxZCxHQUFHLEVBQUU7RUFDNUMsSUFBSTRrQixTQUFTLEdBQUdodkIsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJO0VBQ3hGLElBQUlpdkIsT0FBTyxHQUFHanZCLFNBQVMsQ0FBQ2xOLE1BQU0sR0FBRyxDQUFDLElBQUlrTixTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUt5UCxTQUFTLEdBQUd6UCxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRTtFQUNwRixJQUFJLENBQUNvSyxHQUFHLEVBQUU7SUFDTixPQUFPLEVBQUU7RUFDYjtFQUNBLElBQUk0a0IsU0FBUyxFQUFFO0lBQ1g1a0IsR0FBRyxHQUFHc2tCLFNBQVMsQ0FBQ3RrQixHQUFHLENBQUM7RUFDeEI7RUFDQSxJQUFJNmtCLE9BQU8sRUFBRTtJQUNUQSxPQUFPLEdBQUcsWUFBWSxDQUFDNThCLE1BQU0sQ0FBQzQ4QixPQUFPLEVBQUUsSUFBSSxDQUFDO0VBQ2hEO0VBQ0EsT0FBTyxVQUFVLENBQUM1OEIsTUFBTSxDQUFDNDhCLE9BQU8sRUFBRSxRQUFRLENBQUMsQ0FBQzU4QixNQUFNLENBQUMwMkIsc0JBQXNCLENBQUMsQ0FBQyxFQUFFLCtQQUErUCxDQUFDLENBQUMxMkIsTUFBTSxDQUFDK1gsR0FBRyxFQUFFLG9CQUFvQixDQUFDO0FBQ25YO0FBQ08sU0FBUzhrQixPQUFPQSxDQUFDdmdDLEtBQUssRUFBRW9rQixLQUFLLEVBQUVvYyxJQUFJLEVBQUU7RUFDeEMsT0FBT0EsSUFBSSxDQUFDM2MsT0FBTyxDQUFDN2pCLEtBQUssQ0FBQyxLQUFLb2tCLEtBQUs7QUFDeEM7QUFDTyxTQUFTZSxPQUFPQSxDQUFDaVosQ0FBQyxFQUFFcUMsQ0FBQyxFQUFFO0VBQzFCLE9BQU9yQyxDQUFDLENBQUMxNkIsTUFBTSxDQUFDKzhCLENBQUMsQ0FBQztBQUN0QjtBQUNPLFNBQVNDLGFBQWFBLENBQUN6OUIsRUFBRSxFQUFFMDlCLGNBQWMsRUFBRTtFQUM5QyxJQUFJLENBQUMxOUIsRUFBRSxFQUFFO0lBQ0w7RUFDSjtFQUNBLE9BQU8wOUIsY0FBYyxDQUFDbmUsT0FBTyxDQUFDb2UsRUFBRSxJQUFJQSxFQUFFLENBQUNDLElBQUksQ0FBQyxDQUFDajhCLElBQUksQ0FBQ2s4QixHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLFFBQVEsQ0FBQyxDQUFDcDdCLElBQUksQ0FBQ3E3QixJQUFJLElBQUlELEdBQUcsQ0FBQ0MsSUFBSSxDQUFDLEtBQUs5OUIsRUFBRSxDQUFDLENBQUM7QUFDeEg7QUFDTyxTQUFTKzlCLFFBQVFBLENBQUMzL0IsR0FBRyxFQUFFQyxHQUFHLEVBQUU7RUFDL0IsT0FBT0QsR0FBRyxDQUFDQyxHQUFHLENBQUM7QUFDbkI7QUFDTyxTQUFTMi9CLGNBQWNBLENBQUEsRUFBRztFQUM3QixJQUFJQyxPQUFPLEdBQUc3dkIsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBR3duQixZQUFZLENBQUNxSSxPQUFPO0VBQ3RHO0VBQ0EsT0FBT0EsT0FBTyxDQUFDejdCLEdBQUcsQ0FBQzA3QixJQUFJLElBQUlBLElBQUksQ0FBQ04sSUFBSSxDQUFDcDdCLEdBQUcsQ0FBQ3E3QixHQUFHLElBQUlBLEdBQUcsQ0FBQzlVLE1BQU0sQ0FBQyxDQUFDNW1CLE1BQU0sQ0FBQytmLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDL2YsTUFBTSxDQUFDK2YsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDamUsTUFBTSxDQUFDOGtCLE1BQU0sSUFBSSxPQUFPQSxNQUFNLEtBQUssV0FBVyxDQUFDLENBQUM5a0IsTUFBTSxDQUFDcTVCLE9BQU8sQ0FBQztBQUN4SztBQUNPLFNBQVNhLGtCQUFrQkEsQ0FBQSxFQUFHO0VBQ2pDLElBQUl6NEIsTUFBTSxDQUFDMDRCLFNBQVMsSUFBSTNILElBQUksQ0FBQy93QixNQUFNLENBQUMwNEIsU0FBUyxDQUFDQyxNQUFNLENBQUMsSUFBSTVILElBQUksQ0FBQy93QixNQUFNLENBQUMwNEIsU0FBUyxDQUFDQyxNQUFNLENBQUMsQ0FBQyxDQUFDQyxRQUFRLENBQUMsRUFBRTtJQUMvRixPQUFPLElBQUk7RUFDZjtBQUNKO0FBQ08sU0FBU0Msa0JBQWtCQSxDQUFBLEVBQUc7RUFDakMsSUFBSTc0QixNQUFNLENBQUM4NEIsTUFBTSxJQUFJL0gsSUFBSSxDQUFDL3dCLE1BQU0sQ0FBQzg0QixNQUFNLENBQUNDLE1BQU0sQ0FBQyxFQUFFO0lBQzdDLE9BQU8sSUFBSTtFQUNmO0FBQ0o7QUFDTyxJQUFJQyxnQkFBZ0IsR0FBR0EsQ0FBQ3ZELENBQUMsRUFBRXFDLENBQUMsS0FBSztFQUNwQyxPQUFPQSxDQUFDLENBQUMzTCxHQUFHLEdBQUdzSixDQUFDLENBQUN0SixHQUFHO0FBQ3hCLENBQUM7QUFDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTOE0sT0FBT0EsQ0FBQ2g0QixLQUFLLEVBQUU7RUFDM0IsSUFBSWk0QixPQUFPLEdBQUdqNEIsS0FBSyxDQUFDekYsTUFBTTtFQUMxQjtFQUNBLE9BQU8wOUIsT0FBTyxHQUFHLENBQUMsRUFBRTtJQUNoQjtJQUNBLElBQUl6ZCxLQUFLLEdBQUd2VyxJQUFJLENBQUNDLEtBQUssQ0FBQ0QsSUFBSSxDQUFDd3NCLE1BQU0sQ0FBQyxDQUFDLEdBQUd3SCxPQUFPLENBQUM7SUFDL0M7SUFDQUEsT0FBTyxFQUFFO0lBQ1Q7SUFDQSxJQUFJQyxJQUFJLEdBQUdsNEIsS0FBSyxDQUFDaTRCLE9BQU8sQ0FBQztJQUN6Qmo0QixLQUFLLENBQUNpNEIsT0FBTyxDQUFDLEdBQUdqNEIsS0FBSyxDQUFDd2EsS0FBSyxDQUFDO0lBQzdCeGEsS0FBSyxDQUFDd2EsS0FBSyxDQUFDLEdBQUcwZCxJQUFJO0VBQ3ZCO0VBQ0EsT0FBT2w0QixLQUFLO0FBQ2hCO0FBQ08sU0FBU21jLFNBQVNBLENBQUMxa0IsR0FBRyxFQUFFO0VBQzNCLE9BQU95aUIsaURBQUssQ0FBQ3ppQixHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0I7QUFDTyxTQUFTMGdDLFFBQVFBLENBQUEsRUFBRztFQUN2QixJQUFJO0lBQ0EsT0FBTzlJLFFBQVEsQ0FBQ0csYUFBYSxDQUFDLENBQUMsS0FBS0gsUUFBUSxDQUFDSSxZQUFZLENBQUMsQ0FBQztFQUMvRCxDQUFDLENBQ0QsT0FBTzE1QixDQUFDLEVBQUU7SUFDTixPQUFPLElBQUk7RUFDZjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU3FpQyxpQkFBaUJBLENBQUEsRUFBRztFQUNoQyxJQUFJLENBQUNELFFBQVEsQ0FBQyxDQUFDLEVBQUU7SUFDYixPQUFPLEtBQUs7RUFDaEI7RUFDQSxJQUFJRSxFQUFFLEdBQUdoSixRQUFRLENBQUNHLGFBQWEsQ0FBQyxDQUFDO0VBQ2pDLE9BQU8sQ0FBQyxFQUFFNkksRUFBRSxDQUFDQyxHQUFHLElBQUlELEVBQUUsQ0FBQ0MsR0FBRyxDQUFDQyxHQUFHLENBQUM7QUFDbkM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0Msb0JBQW9CQSxDQUFBLEVBQUc7RUFDbkMsSUFBSTtJQUNBLElBQUlILEVBQUUsR0FBRzdJLGFBQWEsQ0FBQyxDQUFDO0lBQ3hCLE9BQU8sT0FBTzZJLEVBQUUsQ0FBQ0MsR0FBRyxDQUFDQyxHQUFHLENBQUNFLElBQUksS0FBSyxVQUFVLEdBQUdKLEVBQUUsQ0FBQ0MsR0FBRyxDQUFDQyxHQUFHLENBQUNFLElBQUksQ0FBQyxDQUFDLEdBQUd2aEIsU0FBUztFQUNoRixDQUFDLENBQ0QsT0FBT25oQixDQUFDLEVBQUU7SUFDTnltQixRQUFRLENBQUMsa0NBQWtDLEVBQUV6bUIsQ0FBQyxDQUFDO0lBQy9DLE9BQU9taEIsU0FBUztFQUNwQjtBQUNKO0FBQ08sU0FBU3doQixlQUFlQSxDQUFBLEVBQUc7RUFDOUIsT0FBTyw0Q0FBNEMsQ0FBQ2wvQixJQUFJLENBQUNtL0IsU0FBUyxDQUFDQyxTQUFTLENBQUM7QUFDakY7QUFDTyxTQUFTQyxhQUFhQSxDQUFDdHlCLEdBQUcsRUFBRXV5QixJQUFJLEVBQUU7RUFDckMsSUFBSSxDQUFDdnlCLEdBQUcsRUFDSjtFQUNKLE9BQU9yUSxNQUFNLENBQUNrcEIsT0FBTyxDQUFDMFosSUFBSSxDQUFDLENBQUN0OUIsTUFBTSxDQUFDLENBQUMrSyxHQUFHLEVBQUUrTCxLQUFLLEtBQUs7SUFDL0MsSUFBSSxDQUFDNWEsR0FBRyxFQUFFb2lCLEdBQUcsQ0FBQyxHQUFHeEgsS0FBSztJQUN0QixPQUFPL0wsR0FBRyxDQUFDMUIsT0FBTyxDQUFDLElBQUlrMEIsTUFBTSxDQUFDLFFBQVEsR0FBR3JoQyxHQUFHLEdBQUcsS0FBSyxFQUFFLEdBQUcsQ0FBQyxFQUFFb2lCLEdBQUcsSUFBSSxFQUFFLENBQUM7RUFDMUUsQ0FBQyxFQUFFdlQsR0FBRyxDQUFDO0FBQ1g7QUFDTyxTQUFTeXlCLG1CQUFtQkEsQ0FBQ3p5QixHQUFHLEVBQUUya0IsR0FBRyxFQUFFO0VBQzFDLE9BQU8yTixhQUFhLENBQUN0eUIsR0FBRyxFQUFFO0lBQ3RCMHlCLGFBQWEsRUFBRS9OO0VBQ25CLENBQUMsQ0FBQztBQUNOO0FBQ08sU0FBU2dPLG1CQUFtQkEsQ0FBQzN5QixHQUFHLEVBQUU0eUIsUUFBUSxFQUFFO0VBQy9DLElBQUksQ0FBQzV5QixHQUFHLElBQUksQ0FBQzR5QixRQUFRLElBQUksT0FBT0EsUUFBUSxLQUFLLFFBQVEsRUFDakQ7RUFDSixPQUFPNXlCLEdBQUcsQ0FBQzFCLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRXMwQixRQUFRLENBQUM7QUFDckQ7QUFDTyxTQUFTQyxTQUFTQSxDQUFBLEVBQUc7RUFDeEIsT0FBTyxJQUFJejdCLElBQUksQ0FBQyxDQUFDLENBQUM2SCxPQUFPLENBQUMsQ0FBQztBQUMvQjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBUzZ6QixpQkFBaUJBLENBQUEsRUFBRztFQUNoQyxPQUFPdDZCLE1BQU0sQ0FBQzJaLFdBQVcsSUFBSTNaLE1BQU0sQ0FBQzJaLFdBQVcsQ0FBQ2xWLEdBQUcsSUFBSXpFLE1BQU0sQ0FBQzJaLFdBQVcsQ0FBQ2xWLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQztBQUN4RjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTODFCLHFCQUFxQkEsQ0FBQzdILENBQUMsRUFBRTtFQUNyQyxJQUFJOEgsY0FBYztFQUNsQixJQUFJQyxrQkFBa0IsR0FBRyxDQUFDLENBQUM7RUFDM0IvSCxDQUFDLEdBQUdBLENBQUMsSUFBSWpDLGFBQWEsQ0FBQyxDQUFDO0VBQ3hCLElBQUk5VyxXQUFXLEdBQUcrWSxDQUFDLENBQUMvWSxXQUFXO0VBQy9CLElBQUksQ0FBQzZnQixjQUFjLEdBQUc5SCxDQUFDLENBQUMvWSxXQUFXLE1BQU0sSUFBSSxJQUFJNmdCLGNBQWMsS0FBSyxLQUFLLENBQUMsSUFBSUEsY0FBYyxDQUFDRSxNQUFNLEVBQUU7SUFDakcsSUFBSWhJLENBQUMsQ0FBQy9ZLFdBQVcsQ0FBQytnQixNQUFNLENBQUNDLGVBQWUsR0FBRyxDQUFDLEVBQUU7TUFDMUMsSUFBSTVmLEdBQUcsR0FBR3BCLFdBQVcsQ0FBQytnQixNQUFNLENBQUNFLFVBQVUsR0FBR2poQixXQUFXLENBQUMrZ0IsTUFBTSxDQUFDQyxlQUFlO01BQzVFLElBQUk1ZixHQUFHLEdBQUcsQ0FBQyxFQUFFO1FBQ1QwZixrQkFBa0IsR0FBRzFmLEdBQUc7TUFDNUI7SUFDSjtFQUNKO0VBQ0EsT0FBTzBmLGtCQUFrQjtBQUM3QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0ksZUFBZUEsQ0FBQSxFQUFHO0VBQzlCLE9BQU96NkIsOENBQU0sQ0FBQytoQixTQUFTLENBQUMsY0FBYyxDQUFDLEtBQUssS0FBSztBQUNyRDtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNvTyxrQkFBa0JBLENBQUEsRUFBRztFQUNqQztFQUNBLElBQUl2d0IsTUFBTSxDQUFDNDVCLFNBQVMsQ0FBQ2tCLGFBQWEsSUFBSSxDQUFDLENBQUNoMkIsUUFBUSxDQUFDcVUsTUFBTSxDQUFDM2QsTUFBTSxFQUFFO0lBQzVELE9BQU8sSUFBSTtFQUNmO0FBQ0o7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTdS9CLGNBQWNBLENBQUN4WCxJQUFJLEVBQUV5WCxnQkFBZ0IsRUFBRTtFQUNuRCxJQUFJQSxnQkFBZ0IsR0FBRyxDQUFDLEVBQUU7SUFDdEIsTUFBTSxJQUFJOTZCLEtBQUssQ0FBQyxrREFBa0QsQ0FBQ25GLE1BQU0sQ0FBQ2lnQyxnQkFBZ0IsQ0FBQyxDQUFDO0VBQ2hHO0VBQ0EsSUFBSUMsUUFBUSxHQUFHLENBQUM7RUFDaEIsT0FBTyxZQUFZO0lBQ2ZBLFFBQVEsRUFBRTtJQUNWLElBQUlBLFFBQVEsS0FBS0QsZ0JBQWdCLEVBQUU7TUFDL0J6WCxJQUFJLENBQUMvYSxLQUFLLENBQUMsSUFBSSxFQUFFRSxTQUFTLENBQUM7SUFDL0I7RUFDSixDQUFDO0FBQ0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTd3lCLE9BQU9BLENBQUNDLEVBQUUsRUFBRXhpQyxHQUFHLEVBQUU7RUFDN0IsT0FBT3dpQyxFQUFFLENBQUMxK0IsTUFBTSxDQUFDLFVBQVUyK0IsRUFBRSxFQUFFbmdCLENBQUMsRUFBRTtJQUM5QixDQUFDbWdCLEVBQUUsQ0FBQ25nQixDQUFDLENBQUN0aUIsR0FBRyxDQUFDLENBQUMsR0FBR3lpQyxFQUFFLENBQUNuZ0IsQ0FBQyxDQUFDdGlCLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFeVIsSUFBSSxDQUFDNlEsQ0FBQyxDQUFDO0lBQ3ZDLE9BQU9tZ0IsRUFBRTtFQUNiLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQztBQUNWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTQyxnQkFBZ0JBLENBQUNsRyxNQUFNLEVBQUVtRyxNQUFNLEVBQUU7RUFDN0MsT0FBT0EsTUFBTSxDQUFDLzhCLE1BQU0sQ0FBQ2c5QixLQUFLLElBQUlwRyxNQUFNLENBQUNvRyxLQUFLLENBQUMsQ0FBQyxDQUFDOStCLE1BQU0sQ0FBQyxDQUFDMDdCLEdBQUcsRUFBRW9ELEtBQUssS0FBS3BrQyxNQUFNLENBQUNtcEIsTUFBTSxDQUFDNlgsR0FBRyxFQUFFO0lBQ25GLENBQUNvRCxLQUFLLEdBQUdwRyxNQUFNLENBQUNvRyxLQUFLO0VBQ3pCLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1g7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsaUJBQWlCQSxDQUFDQyxVQUFVLEVBQUU7RUFDMUMsSUFBSUMscUJBQXFCLEdBQUcsQ0FBQyxRQUFRLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQztFQUN6RCxJQUFJQyxzQkFBc0IsR0FBRyxDQUFDLFVBQVUsRUFBRSxXQUFXLEVBQUUsT0FBTyxDQUFDO0VBQy9ELElBQUlDLEtBQUssR0FBR3prQyxNQUFNLENBQUNtSCxJQUFJLENBQUNtOUIsVUFBVSxDQUFDO0VBQ25DLElBQUksQ0FBQ0csS0FBSyxDQUFDaitCLEtBQUssQ0FBQzgxQixJQUFJLElBQUl2eUIsc0RBQVEsQ0FBQ3c2QixxQkFBcUIsRUFBRWpJLElBQUksQ0FBQyxDQUFDLEVBQUU7SUFDN0QsT0FBTyxLQUFLO0VBQ2hCO0VBQ0EsSUFBSSxLQUFJLElBQUlnSSxVQUFVLENBQUNJLEtBQUssSUFBSUosVUFBVSxDQUFDSSxLQUFLLENBQUNDLE9BQU8sRUFBRTtJQUN0RCxPQUFPNTZCLHNEQUFRLENBQUN5NkIsc0JBQXNCLEVBQUVGLFVBQVUsQ0FBQ0ksS0FBSyxDQUFDQyxPQUFPLENBQUM7RUFDckU7RUFDQSxPQUFPLElBQUk7QUFDZjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0MsdUJBQXVCQSxDQUFDeEQsT0FBTyxFQUFFeUQsVUFBVSxFQUFFM1ksTUFBTSxFQUFFO0VBQ2pFLE9BQU9rVixPQUFPLENBQUNoNkIsTUFBTSxDQUFDMDlCLE1BQU0sSUFBSUEsTUFBTSxDQUFDam5CLElBQUksS0FBS2duQixVQUFVLENBQUMsQ0FBQ25pQixPQUFPLENBQUNvaUIsTUFBTSxJQUFJQSxNQUFNLENBQUMvRCxJQUFJLENBQUMsQ0FBQzM1QixNQUFNLENBQUMyOUIsVUFBVSxJQUFJQSxVQUFVLENBQUM3WSxNQUFNLEtBQUtBLE1BQU0sQ0FBQyxDQUFDdm1CLEdBQUcsQ0FBQ28vQixVQUFVLElBQUlBLFVBQVUsQ0FBQ1osTUFBTSxJQUFJLENBQUMsQ0FBQyxDQUFDO0FBQzVMO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU2EsTUFBTUEsQ0FBQSxFQUFHO0VBQ3JCLE9BQU92QyxTQUFTLENBQUN3QyxVQUFVLEtBQUssR0FBRyxJQUFJcDhCLE1BQU0sQ0FBQ284QixVQUFVLEtBQUssR0FBRyxJQUFJeEMsU0FBUyxDQUFDeUMsWUFBWSxLQUFLLEdBQUcsSUFBSXpDLFNBQVMsQ0FBQ3dDLFVBQVUsS0FBSyxLQUFLO0FBQ3hJO0FBQ08sSUFBSUUsa0JBQWtCLEdBQUdBLENBQUNDLElBQUksRUFBRVAsVUFBVSxLQUFLTyxJQUFJLENBQUNDLGFBQWEsQ0FBQyxDQUFDLEtBQUtSLFVBQVUsSUFBSU8sSUFBSSxDQUFDRSxnQkFBZ0IsQ0FBQyxDQUFDLEtBQUtULFVBQVU7QUFDbkk7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNVLHdCQUF3QkEsQ0FBQ0gsSUFBSSxFQUFFO0VBQzNDLE9BQU9QLFVBQVUsSUFBSU0sa0JBQWtCLENBQUNDLElBQUksRUFBRVAsVUFBVSxDQUFDO0FBQzdEO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU1csd0JBQXdCQSxDQUFDVixNQUFNLEVBQUU1WSxNQUFNLEVBQUU7RUFDckQsSUFBSXVaLFNBQVMsR0FBR3psQyxNQUFNLENBQUNtSCxJQUFJLENBQUMyOUIsTUFBTSxDQUFDUixVQUFVLElBQUk7SUFDN0MsUUFBUSxFQUFFO0VBQ2QsQ0FBQyxDQUFDLENBQUM5ekIsSUFBSSxDQUFDLElBQUksQ0FBQztFQUNiLE9BQU8sUUFBUSxDQUFDNU0sTUFBTSxDQUFDa2hDLE1BQU0sQ0FBQ2puQixJQUFJLEVBQUUsUUFBUSxDQUFDLENBQUNqYSxNQUFNLENBQUM2aEMsU0FBUyxFQUFFLHNEQUFzRCxDQUFDLENBQUM3aEMsTUFBTSxDQUFDNmhDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQzdoQyxNQUFNLENBQUNzb0IsTUFBTSxFQUFFLDRDQUE0QyxDQUFDO0FBQ2hOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLElBQUl3WixTQUFTLEdBQUc1a0MsTUFBTSxDQUFDNGtDLFNBQVMsQ0FBQ3RjLElBQUksQ0FBQ3RvQixNQUFNLENBQUM7QUFDcEQ7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTNmtDLFFBQVFBLENBQUNwa0MsR0FBRyxFQUFFO0VBQzFCLE9BQU92QixNQUFNLENBQUNpcEIsV0FBVyxDQUFDanBCLE1BQU0sQ0FBQ2twQixPQUFPLENBQUMzbkIsR0FBRyxDQUFDLENBQUM2RixNQUFNLENBQUMrVixLQUFLLElBQUk7SUFDMUQsSUFBSSxDQUFDZ0YsQ0FBQyxFQUFFa2MsQ0FBQyxDQUFDLEdBQUdsaEIsS0FBSztJQUNsQixPQUFPLE9BQU9raEIsQ0FBQyxLQUFLLFdBQVc7RUFDbkMsQ0FBQyxDQUFDLENBQUM7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTdUgsSUFBSUEsQ0FBQ3JrQyxHQUFHLEVBQUVza0MsVUFBVSxFQUFFO0VBQ2xDLElBQUksT0FBT3RrQyxHQUFHLEtBQUssUUFBUSxFQUFFO0lBQ3pCLE9BQU8sQ0FBQyxDQUFDO0VBQ2I7RUFDQSxPQUFPc2tDLFVBQVUsQ0FBQ3ZnQyxNQUFNLENBQUMsQ0FBQ3dnQyxNQUFNLEVBQUU3RSxJQUFJLEVBQUV2Z0MsQ0FBQyxLQUFLO0lBQzFDLElBQUksT0FBT3VnQyxJQUFJLEtBQUssVUFBVSxFQUFFO01BQzVCLE9BQU82RSxNQUFNO0lBQ2pCO0lBQ0EsSUFBSUMsT0FBTyxHQUFHOUUsSUFBSTtJQUNsQixJQUFJM0YsS0FBSyxHQUFHMkYsSUFBSSxDQUFDM0YsS0FBSyxDQUFDLHFCQUFxQixDQUFDO0lBQzdDLElBQUlBLEtBQUssRUFBRTtNQUNQMkYsSUFBSSxHQUFHM0YsS0FBSyxDQUFDLENBQUMsQ0FBQztNQUNmeUssT0FBTyxHQUFHekssS0FBSyxDQUFDLENBQUMsQ0FBQztJQUN0QjtJQUNBLElBQUlwN0IsS0FBSyxHQUFHcUIsR0FBRyxDQUFDMC9CLElBQUksQ0FBQztJQUNyQixJQUFJLE9BQU80RSxVQUFVLENBQUNubEMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLFVBQVUsRUFBRTtNQUN6Q1IsS0FBSyxHQUFHMmxDLFVBQVUsQ0FBQ25sQyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUNSLEtBQUssRUFBRTRsQyxNQUFNLENBQUM7SUFDNUM7SUFDQSxJQUFJLE9BQU81bEMsS0FBSyxLQUFLLFdBQVcsRUFBRTtNQUM5QjRsQyxNQUFNLENBQUNDLE9BQU8sQ0FBQyxHQUFHN2xDLEtBQUs7SUFDM0I7SUFDQSxPQUFPNGxDLE1BQU07RUFDakIsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDO0FBQ1Y7QUFDTyxTQUFTRSxhQUFhQSxDQUFDcGlCLEdBQUcsRUFBRWlZLElBQUksRUFBRTtFQUNyQyxPQUFPMVgsT0FBTyxDQUFDUCxHQUFHLENBQUMsS0FBS2lZLElBQUksR0FBR2pZLEdBQUcsQ0FBQ3ZmLE1BQU0sS0FBS3czQixJQUFJLEdBQUcsSUFBSSxDQUFDLElBQUlqWSxHQUFHLENBQUNwZCxLQUFLLENBQUM2M0IsQ0FBQyxJQUFJcUgsU0FBUyxDQUFDckgsQ0FBQyxDQUFDLENBQUM7QUFDOUY7QUFDTyxTQUFTdEUsT0FBT0EsQ0FBQ2tNLEtBQUssRUFBRTtFQUMzQixPQUFPLENBQUNBLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBR0EsS0FBSyxDQUFDdDNCLE9BQU8sQ0FBQyxLQUFLLEVBQUUsRUFBRSxDQUFDLENBQUNNLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQzNKLE1BQU0sQ0FBQyxDQUFDNGdDLEdBQUcsRUFBRUMsUUFBUSxLQUFLO0lBQy9FLElBQUksQ0FBQzdyQixDQUFDLEVBQUUrakIsQ0FBQyxDQUFDLEdBQUc4SCxRQUFRLENBQUNsM0IsS0FBSyxDQUFDLEdBQUcsQ0FBQztJQUNoQyxJQUFJLE9BQU8sQ0FBQzNMLElBQUksQ0FBQ2dYLENBQUMsQ0FBQyxFQUFFO01BQ2pCQSxDQUFDLEdBQUdBLENBQUMsQ0FBQzNMLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO01BQ3ZCdTNCLEdBQUcsQ0FBQzVyQixDQUFDLENBQUMsR0FBRzRyQixHQUFHLENBQUM1ckIsQ0FBQyxDQUFDLElBQUksRUFBRTtNQUNyQjRyQixHQUFHLENBQUM1ckIsQ0FBQyxDQUFDLENBQUNySCxJQUFJLENBQUNvckIsQ0FBQyxDQUFDO0lBQ2xCLENBQUMsTUFDSTtNQUNENkgsR0FBRyxDQUFDNXJCLENBQUMsQ0FBQyxHQUFHK2pCLENBQUMsSUFBSSxFQUFFO0lBQ3BCO0lBQ0EsT0FBTzZILEdBQUc7RUFDZCxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7QUFDVjtBQUNPLFNBQVNsTSxRQUFRQSxDQUFDaU0sS0FBSyxFQUFFO0VBQzVCLE9BQU9qbUMsTUFBTSxDQUFDbUgsSUFBSSxDQUFDOCtCLEtBQUssQ0FBQyxDQUFDdGdDLEdBQUcsQ0FBQzJVLENBQUMsSUFBSWhLLEtBQUssQ0FBQzZULE9BQU8sQ0FBQzhoQixLQUFLLENBQUMzckIsQ0FBQyxDQUFDLENBQUMsR0FBRzJyQixLQUFLLENBQUMzckIsQ0FBQyxDQUFDLENBQUMzVSxHQUFHLENBQUMwNEIsQ0FBQyxJQUFJLEVBQUUsQ0FBQ3o2QixNQUFNLENBQUMwVyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUMxVyxNQUFNLENBQUN5NkIsQ0FBQyxDQUFDLENBQUMsQ0FBQzd0QixJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsRUFBRSxDQUFDNU0sTUFBTSxDQUFDMFcsQ0FBQyxFQUFFLEdBQUcsQ0FBQyxDQUFDMVcsTUFBTSxDQUFDcWlDLEtBQUssQ0FBQzNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM5SixJQUFJLENBQUMsR0FBRyxDQUFDO0FBQzNLO0FBQ08sU0FBUzQxQixRQUFRQSxDQUFDenFCLEdBQUcsRUFBRTdPLE9BQU8sRUFBRTtFQUNuQyxJQUFJNlMsTUFBTSxHQUFHaFMsUUFBUSxDQUFDa08sYUFBYSxDQUFDLEdBQUcsQ0FBQztFQUN4QyxJQUFJL08sT0FBTyxJQUFJLGtCQUFrQixJQUFJQSxPQUFPLElBQUlBLE9BQU8sQ0FBQ3U1QixnQkFBZ0IsRUFBRTtJQUN0RTFtQixNQUFNLENBQUNsUSxJQUFJLEdBQUdrTSxHQUFHO0VBQ3JCLENBQUMsTUFDSTtJQUNEZ0UsTUFBTSxDQUFDbFEsSUFBSSxHQUFHNEMsa0JBQWtCLENBQUNzSixHQUFHLENBQUM7RUFDekM7RUFDQTtFQUNBLElBQUkycUIsVUFBVSxHQUFHeDVCLE9BQU8sSUFBSSxzQkFBc0IsSUFBSUEsT0FBTyxJQUFJQSxPQUFPLENBQUN5NUIsb0JBQW9CO0VBQzdGLE9BQU87SUFDSDkyQixJQUFJLEVBQUVrUSxNQUFNLENBQUNsUSxJQUFJO0lBQ2pCKzJCLFFBQVEsRUFBRSxDQUFDN21CLE1BQU0sQ0FBQzZtQixRQUFRLElBQUksRUFBRSxFQUFFNzNCLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDO0lBQ25EODNCLFFBQVEsRUFBRTltQixNQUFNLENBQUM4bUIsUUFBUTtJQUN6QkMsSUFBSSxFQUFFLENBQUMvbUIsTUFBTSxDQUFDK21CLElBQUk7SUFDbEJDLFFBQVEsRUFBRWhuQixNQUFNLENBQUNnbkIsUUFBUSxDQUFDaDRCLE9BQU8sQ0FBQyxTQUFTLEVBQUUsR0FBRyxDQUFDO0lBQ2pEbXZCLE1BQU0sRUFBRXdJLFVBQVUsR0FBRzNtQixNQUFNLENBQUNtZSxNQUFNLEdBQUczRSxRQUFRLENBQUNZLE9BQU8sQ0FBQ3BhLE1BQU0sQ0FBQ21lLE1BQU0sSUFBSSxFQUFFLENBQUM7SUFDMUUzc0IsSUFBSSxFQUFFLENBQUN3TyxNQUFNLENBQUN4TyxJQUFJLElBQUksRUFBRSxFQUFFeEMsT0FBTyxDQUFDLElBQUksRUFBRSxFQUFFLENBQUM7SUFDM0NpNEIsSUFBSSxFQUFFam5CLE1BQU0sQ0FBQ2luQixJQUFJLElBQUkvOUIsTUFBTSxDQUFDVSxRQUFRLENBQUNxOUI7RUFDekMsQ0FBQztBQUNMO0FBQ08sU0FBU0MsUUFBUUEsQ0FBQ3RsQyxHQUFHLEVBQUU7RUFDMUIsT0FBTyxDQUFDQSxHQUFHLENBQUNpbEMsUUFBUSxJQUFJLE1BQU0sSUFBSSxLQUFLLElBQUlqbEMsR0FBRyxDQUFDcWxDLElBQUksSUFBSXJsQyxHQUFHLENBQUNrbEMsUUFBUSxJQUFJbGxDLEdBQUcsQ0FBQ21sQyxJQUFJLEdBQUcsR0FBRyxDQUFDOWlDLE1BQU0sQ0FBQ3JDLEdBQUcsQ0FBQ21sQyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxJQUFJbmxDLEdBQUcsQ0FBQ29sQyxRQUFRLElBQUksRUFBRSxDQUFDLElBQUlwbEMsR0FBRyxDQUFDdThCLE1BQU0sR0FBRyxHQUFHLENBQUNsNkIsTUFBTSxDQUFDdTFCLFFBQVEsQ0FBQ2EsUUFBUSxDQUFDejRCLEdBQUcsQ0FBQ3U4QixNQUFNLElBQUksRUFBRSxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsSUFBSXY4QixHQUFHLENBQUM0UCxJQUFJLEdBQUcsR0FBRyxDQUFDdk4sTUFBTSxDQUFDckMsR0FBRyxDQUFDNFAsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO0FBQ3ZQO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVM4b0IsU0FBU0EsQ0FBQzZNLElBQUksRUFBRUMsSUFBSSxFQUFFO0VBQ2xDLElBQUk7SUFBRUMsVUFBVSxHQUFHO0VBQU0sQ0FBQyxHQUFHejFCLFNBQVMsQ0FBQ2xOLE1BQU0sR0FBRyxDQUFDLElBQUlrTixTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUt5UCxTQUFTLEdBQUd6UCxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0VBQ25HLElBQUl1MUIsSUFBSSxLQUFLQyxJQUFJLEVBQ2IsT0FBTyxJQUFJLENBQUMsS0FDWCxJQUFJLE9BQU9ELElBQUksS0FBSyxRQUFRLElBQUlBLElBQUksS0FBSyxJQUFJLElBQUksT0FBT0MsSUFBSSxLQUFLLFFBQVEsSUFBSUEsSUFBSSxLQUFLLElBQUksS0FBSyxDQUFDQyxVQUFVLElBQUlGLElBQUksQ0FBQzdsQyxXQUFXLEtBQUs4bEMsSUFBSSxDQUFDOWxDLFdBQVcsQ0FBQyxFQUFFO0lBQ3ZKLElBQUlnbUMsTUFBTSxHQUFHam5DLE1BQU0sQ0FBQ21ILElBQUksQ0FBQzIvQixJQUFJLENBQUM7SUFDOUIsSUFBSUcsTUFBTSxDQUFDNWlDLE1BQU0sS0FBS3JFLE1BQU0sQ0FBQ21ILElBQUksQ0FBQzQvQixJQUFJLENBQUMsQ0FBQzFpQyxNQUFNLEVBQzFDLE9BQU8sS0FBSztJQUNoQixLQUFLLElBQUk0OEIsSUFBSSxJQUFJZ0csTUFBTSxFQUFFO01BQ3JCLElBQUlGLElBQUksQ0FBQ3hoQixjQUFjLENBQUMwYixJQUFJLENBQUMsRUFBRTtRQUMzQixJQUFJLENBQUNoSCxTQUFTLENBQUM2TSxJQUFJLENBQUM3RixJQUFJLENBQUMsRUFBRThGLElBQUksQ0FBQzlGLElBQUksQ0FBQyxFQUFFO1VBQ25DK0Y7UUFDSixDQUFDLENBQUMsRUFBRTtVQUNBLE9BQU8sS0FBSztRQUNoQjtNQUNKLENBQUMsTUFDSTtRQUNELE9BQU8sS0FBSztNQUNoQjtJQUNKO0lBQ0EsT0FBTyxJQUFJO0VBQ2YsQ0FBQyxNQUNJO0lBQ0QsT0FBTyxLQUFLO0VBQ2hCO0FBQ0o7QUFDTyxTQUFTdmdCLFNBQVNBLENBQUN3USxNQUFNLEVBQUU7RUFDOUIsS0FBSyxJQUFJaVEsS0FBSyxHQUFHMzFCLFNBQVMsQ0FBQ2xOLE1BQU0sRUFBRThpQyxPQUFPLEdBQUcsSUFBSTcyQixLQUFLLENBQUM0MkIsS0FBSyxHQUFHLENBQUMsR0FBR0EsS0FBSyxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRUUsS0FBSyxHQUFHLENBQUMsRUFBRUEsS0FBSyxHQUFHRixLQUFLLEVBQUVFLEtBQUssRUFBRSxFQUFFO0lBQ2xIRCxPQUFPLENBQUNDLEtBQUssR0FBRyxDQUFDLENBQUMsR0FBRzcxQixTQUFTLENBQUM2MUIsS0FBSyxDQUFDO0VBQ3pDO0VBQ0EsSUFBSSxDQUFDRCxPQUFPLENBQUM5aUMsTUFBTSxFQUNmLE9BQU80eUIsTUFBTTtFQUNqQixJQUFJb1EsTUFBTSxHQUFHRixPQUFPLENBQUNHLEtBQUssQ0FBQyxDQUFDO0VBQzVCLElBQUlsaEIsYUFBYSxDQUFDNlEsTUFBTSxDQUFDLElBQUk3USxhQUFhLENBQUNpaEIsTUFBTSxDQUFDLEVBQUU7SUFDaEQsSUFBSUUsS0FBSyxHQUFHLFNBQUFBLENBQVUvbEMsR0FBRyxFQUFFO01BQ3ZCLElBQUk0a0IsYUFBYSxDQUFDaWhCLE1BQU0sQ0FBQzdsQyxHQUFHLENBQUMsQ0FBQyxFQUFFO1FBQzVCLElBQUksQ0FBQ3kxQixNQUFNLENBQUN6MUIsR0FBRyxDQUFDLEVBQ1p4QixNQUFNLENBQUNtcEIsTUFBTSxDQUFDOE4sTUFBTSxFQUFFO1VBQ2xCLENBQUN6MUIsR0FBRyxHQUFHLENBQUM7UUFDWixDQUFDLENBQUM7UUFDTmlsQixTQUFTLENBQUN3USxNQUFNLENBQUN6MUIsR0FBRyxDQUFDLEVBQUU2bEMsTUFBTSxDQUFDN2xDLEdBQUcsQ0FBQyxDQUFDO01BQ3ZDLENBQUMsTUFDSSxJQUFJMmlCLE9BQU8sQ0FBQ2tqQixNQUFNLENBQUM3bEMsR0FBRyxDQUFDLENBQUMsRUFBRTtRQUMzQixJQUFJLENBQUN5MUIsTUFBTSxDQUFDejFCLEdBQUcsQ0FBQyxFQUFFO1VBQ2R4QixNQUFNLENBQUNtcEIsTUFBTSxDQUFDOE4sTUFBTSxFQUFFO1lBQ2xCLENBQUN6MUIsR0FBRyxHQUFHLENBQUMsR0FBRzZsQyxNQUFNLENBQUM3bEMsR0FBRyxDQUFDO1VBQzFCLENBQUMsQ0FBQztRQUNOLENBQUMsTUFDSSxJQUFJMmlCLE9BQU8sQ0FBQzhTLE1BQU0sQ0FBQ3oxQixHQUFHLENBQUMsQ0FBQyxFQUFFO1VBQzNCNmxDLE1BQU0sQ0FBQzdsQyxHQUFHLENBQUMsQ0FBQzZGLE9BQU8sQ0FBQzlGLEdBQUcsSUFBSTtZQUN2QixJQUFJaW1DLFNBQVMsR0FBRyxDQUFDO1lBQ2pCLEtBQUssSUFBSTltQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUd1MkIsTUFBTSxDQUFDejFCLEdBQUcsQ0FBQyxDQUFDNkMsTUFBTSxFQUFFM0QsQ0FBQyxFQUFFLEVBQUU7Y0FDekMsSUFBSXU1QixTQUFTLENBQUNoRCxNQUFNLENBQUN6MUIsR0FBRyxDQUFDLENBQUNkLENBQUMsQ0FBQyxFQUFFYSxHQUFHLENBQUMsRUFBRTtnQkFDaENpbUMsU0FBUyxHQUFHLENBQUM7Z0JBQ2I7Y0FDSjtZQUNKO1lBQ0EsSUFBSUEsU0FBUyxFQUFFO2NBQ1h2USxNQUFNLENBQUN6MUIsR0FBRyxDQUFDLENBQUN5UixJQUFJLENBQUMxUixHQUFHLENBQUM7WUFDekI7VUFDSixDQUFDLENBQUM7UUFDTjtNQUNKLENBQUMsTUFDSTtRQUNEdkIsTUFBTSxDQUFDbXBCLE1BQU0sQ0FBQzhOLE1BQU0sRUFBRTtVQUNsQixDQUFDejFCLEdBQUcsR0FBRzZsQyxNQUFNLENBQUM3bEMsR0FBRztRQUNyQixDQUFDLENBQUM7TUFDTjtJQUNKLENBQUM7SUFDRCxLQUFLLElBQUlBLEdBQUcsSUFBSTZsQyxNQUFNLEVBQUU7TUFDcEJFLEtBQUssQ0FBQy9sQyxHQUFHLENBQUM7SUFDZDtFQUNKO0VBQ0EsT0FBT2lsQixTQUFTLENBQUN3USxNQUFNLEVBQUUsR0FBR2tRLE9BQU8sQ0FBQztBQUN4QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU00sVUFBVUEsQ0FBQ3AzQixHQUFHLEVBQUU7RUFDNUIsSUFBSXEzQixJQUFJLEdBQUduMkIsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0VBQ2hGO0VBQ0E7RUFDQSxJQUFJbzJCLElBQUksR0FBRyxTQUFBQSxDQUFVQyxHQUFHLEVBQUVDLEdBQUcsRUFBRTtJQUMzQixJQUFJak8sSUFBSSxDQUFDN3JCLElBQUksQ0FBQzQ1QixJQUFJLENBQUMsRUFBRTtNQUNqQixPQUFPNTVCLElBQUksQ0FBQzQ1QixJQUFJLENBQUNDLEdBQUcsRUFBRUMsR0FBRyxDQUFDO0lBQzlCLENBQUMsTUFDSTtNQUNEQSxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7TUFDVjtNQUNBO01BQ0E7TUFDQTtNQUNBLElBQUloakIsTUFBTSxHQUFHLENBQUMraUIsR0FBRyxHQUFHLFVBQVUsSUFBSUMsR0FBRztNQUNyQztNQUNBO01BQ0E7TUFDQSxJQUFJRCxHQUFHLEdBQUcsVUFBVSxFQUNoQi9pQixNQUFNLElBQUksQ0FBQytpQixHQUFHLEdBQUcsVUFBVSxJQUFJQyxHQUFHLEdBQUcsQ0FBQztNQUMxQyxPQUFPaGpCLE1BQU0sR0FBRyxDQUFDO0lBQ3JCO0VBQ0osQ0FBQztFQUNELElBQUlpakIsRUFBRSxHQUFHLFVBQVUsR0FBR0osSUFBSTtFQUMxQixJQUFJSyxFQUFFLEdBQUcsVUFBVSxHQUFHTCxJQUFJO0VBQzFCLEtBQUssSUFBSWhuQyxDQUFDLEdBQUcsQ0FBQyxFQUFFc25DLEVBQUUsRUFBRXRuQyxDQUFDLEdBQUcyUCxHQUFHLENBQUNoTSxNQUFNLEVBQUUzRCxDQUFDLEVBQUUsRUFBRTtJQUNyQ3NuQyxFQUFFLEdBQUczM0IsR0FBRyxDQUFDbUMsVUFBVSxDQUFDOVIsQ0FBQyxDQUFDO0lBQ3RCb25DLEVBQUUsR0FBR0gsSUFBSSxDQUFDRyxFQUFFLEdBQUdFLEVBQUUsRUFBRSxVQUFVLENBQUM7SUFDOUJELEVBQUUsR0FBR0osSUFBSSxDQUFDSSxFQUFFLEdBQUdDLEVBQUUsRUFBRSxVQUFVLENBQUM7RUFDbEM7RUFDQUYsRUFBRSxHQUFHSCxJQUFJLENBQUNHLEVBQUUsR0FBR0EsRUFBRSxLQUFLLEVBQUUsRUFBRSxVQUFVLENBQUMsR0FBR0gsSUFBSSxDQUFDSSxFQUFFLEdBQUdBLEVBQUUsS0FBSyxFQUFFLEVBQUUsVUFBVSxDQUFDO0VBQ3hFQSxFQUFFLEdBQUdKLElBQUksQ0FBQ0ksRUFBRSxHQUFHQSxFQUFFLEtBQUssRUFBRSxFQUFFLFVBQVUsQ0FBQyxHQUFHSixJQUFJLENBQUNHLEVBQUUsR0FBR0EsRUFBRSxLQUFLLEVBQUUsRUFBRSxVQUFVLENBQUM7RUFDeEUsT0FBTyxDQUFDLFVBQVUsSUFBSSxPQUFPLEdBQUdDLEVBQUUsQ0FBQyxJQUFJRCxFQUFFLEtBQUssQ0FBQyxDQUFDLEVBQUVqNEIsUUFBUSxDQUFDLENBQUM7QUFDaEU7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU280QixhQUFhQSxDQUFDdGhDLElBQUksRUFBRTtFQUNoQyxJQUFJO0lBQ0EsT0FBT3VSLElBQUksQ0FBQ0MsS0FBSyxDQUFDeFIsSUFBSSxDQUFDO0VBQzNCLENBQUMsQ0FDRCxPQUFPOUcsQ0FBQyxFQUFFLENBQUU7QUFDaEI7QUFDTyxTQUFTcW9DLGNBQWNBLENBQUN2aEMsSUFBSSxFQUFFO0VBQ2pDLElBQUk7SUFDQSxPQUFPdVIsSUFBSSxDQUFDK0ssU0FBUyxDQUFDdGMsSUFBSSxDQUFDO0VBQy9CLENBQUMsQ0FDRCxPQUFPOUcsQ0FBQyxFQUFFO0lBQ04sT0FBTyxFQUFFO0VBQ2I7QUFDSjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTc29DLE9BQU9BLENBQUNqMUIsRUFBRSxFQUFFO0VBQ3hCLElBQUkxUixHQUFHLEdBQUcrUCxTQUFTLENBQUNsTixNQUFNLEdBQUcsQ0FBQyxJQUFJa04sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLeVAsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLFVBQVU2MkIsR0FBRyxFQUFFO0lBQ3pGLE9BQU9BLEdBQUc7RUFDZCxDQUFDO0VBQ0QsSUFBSUMsS0FBSyxHQUFHLElBQUluckIsR0FBRyxDQUFDLENBQUM7RUFDckIsSUFBSUUsUUFBUSxHQUFHLFNBQUFBLENBQUEsRUFBWTtJQUN2QixJQUFJa3JCLFFBQVEsR0FBRzltQyxHQUFHLENBQUM2UCxLQUFLLENBQUMsSUFBSSxFQUFFRSxTQUFTLENBQUM7SUFDekMsSUFBSSxDQUFDODJCLEtBQUssQ0FBQ2orQixHQUFHLENBQUNrK0IsUUFBUSxDQUFDLEVBQUU7TUFDdEJELEtBQUssQ0FBQzE5QixHQUFHLENBQUMyOUIsUUFBUSxFQUFFcDFCLEVBQUUsQ0FBQzdCLEtBQUssQ0FBQyxJQUFJLEVBQUVFLFNBQVMsQ0FBQyxDQUFDO0lBQ2xEO0lBQ0EsT0FBTzgyQixLQUFLLENBQUM5OUIsR0FBRyxDQUFDKzlCLFFBQVEsQ0FBQztFQUM5QixDQUFDO0VBQ0RsckIsUUFBUSxDQUFDaEksS0FBSyxHQUFHaXpCLEtBQUssQ0FBQ2p6QixLQUFLLENBQUNnVSxJQUFJLENBQUNpZixLQUFLLENBQUM7RUFDeEMsT0FBT2pyQixRQUFRO0FBQ25CO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU21yQix1QkFBdUJBLENBQUEsRUFBRztFQUN0QyxJQUFJQyxTQUFTLEdBQUdqM0IsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO0VBQ3JGLElBQUlrM0IsUUFBUSxHQUFHbDNCLFNBQVMsQ0FBQ2xOLE1BQU0sR0FBRyxDQUFDLElBQUlrTixTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUt5UCxTQUFTLEdBQUd6UCxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRztFQUN0RixJQUFJbTNCLGVBQWUsR0FBRyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7RUFDaEMsSUFBSUEsZUFBZSxDQUFDM2tCLE9BQU8sQ0FBQzBrQixRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUU7SUFDdkMsT0FBT2hoQyxJQUFJLENBQUM2RixHQUFHLENBQUMsQ0FBQztFQUNyQjtFQUNBLElBQUlxN0IsY0FBYyxHQUFHSCxTQUFTLElBQUlDLFFBQVEsS0FBSyxHQUFHLEdBQUcsSUFBSSxHQUFHLENBQUMsQ0FBQztFQUM5RCxPQUFPaGhDLElBQUksQ0FBQzZGLEdBQUcsQ0FBQyxDQUFDLElBQUlrN0IsU0FBUyxJQUFJQSxTQUFTLEdBQUcsQ0FBQyxHQUFHLElBQUksR0FBRyxFQUFFLEdBQUcsRUFBRSxHQUFHLEVBQUUsR0FBR0csY0FBYyxHQUFHLENBQUMsQ0FBQztBQUMvRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLG9CQUFvQkEsQ0FBQ3JuQyxHQUFHLEVBQUU7RUFDdEMsT0FBT3ZCLE1BQU0sQ0FBQ21ILElBQUksQ0FBQzVGLEdBQUcsQ0FBQyxDQUFDb0UsR0FBRyxDQUFDbkUsR0FBRyxJQUFJO0lBQy9CLE9BQU87TUFDSCxDQUFDQSxHQUFHLEdBQUdELEdBQUcsQ0FBQ0MsR0FBRztJQUNsQixDQUFDO0VBQ0wsQ0FBQyxDQUFDO0FBQ047QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU3FuQyxtQkFBbUJBLENBQUNDLE1BQU0sRUFBRUMsVUFBVSxFQUFFO0VBQ3BEL29DLE1BQU0sQ0FBQ2twQixPQUFPLENBQUM2ZixVQUFVLENBQUMsQ0FBQzFoQyxPQUFPLENBQUN1VyxLQUFLLElBQUk7SUFDeEMsSUFBSSxDQUFDdEQsQ0FBQyxFQUFFK2pCLENBQUMsQ0FBQyxHQUFHemdCLEtBQUs7SUFDbEIsT0FBT2tyQixNQUFNLENBQUNFLFlBQVksQ0FBQzF1QixDQUFDLEVBQUUrakIsQ0FBQyxDQUFDO0VBQ3BDLENBQUMsQ0FBQztBQUNOO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTyxTQUFTNEssWUFBWUEsQ0FBQ2o1QixHQUFHLEVBQUVrNUIsRUFBRSxFQUFFO0VBQ2xDLElBQUkxbkMsR0FBRyxHQUFHK1AsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsSUFBSWtOLFNBQVMsQ0FBQyxDQUFDLENBQUMsS0FBS3lQLFNBQVMsR0FBR3pQLFNBQVMsQ0FBQyxDQUFDLENBQUMsR0FBRzIzQixFQUFFLElBQUlBLEVBQUU7RUFDdEYsSUFBSUMsSUFBSSxHQUFHLENBQUM7RUFDWixJQUFJQyxLQUFLLEdBQUdwNUIsR0FBRyxDQUFDM0wsTUFBTSxJQUFJMkwsR0FBRyxDQUFDM0wsTUFBTSxHQUFHLENBQUM7RUFDeEMsSUFBSTR5QixNQUFNLEdBQUd6MUIsR0FBRyxDQUFDMG5DLEVBQUUsQ0FBQztFQUNwQixPQUFPRSxLQUFLLEdBQUdELElBQUksR0FBRyxDQUFDLEVBQUU7SUFDckIsSUFBSUUsTUFBTSxHQUFHRixJQUFJLEdBQUdwN0IsSUFBSSxDQUFDdTdCLEtBQUssQ0FBQyxDQUFDRixLQUFLLEdBQUdELElBQUksSUFBSSxDQUFDLENBQUM7SUFDbEQsSUFBSWxTLE1BQU0sR0FBR3oxQixHQUFHLENBQUN3TyxHQUFHLENBQUNxNUIsTUFBTSxDQUFDLENBQUMsRUFBRTtNQUMzQkYsSUFBSSxHQUFHRSxNQUFNO0lBQ2pCLENBQUMsTUFDSTtNQUNERCxLQUFLLEdBQUdDLE1BQU07SUFDbEI7RUFDSjtFQUNBLE9BQU9yNUIsR0FBRyxDQUFDM0wsTUFBTSxHQUFHOGtDLElBQUksSUFBSWxTLE1BQU0sR0FBR3oxQixHQUFHLENBQUN3TyxHQUFHLENBQUNtNUIsSUFBSSxDQUFDLENBQUMsRUFBRTtJQUNqREEsSUFBSSxFQUFFO0VBQ1Y7RUFDQSxPQUFPQSxJQUFJO0FBQ2Y7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ08sU0FBU0ksMEJBQTBCQSxDQUFDaG9DLEdBQUcsRUFBRTtFQUM1QyxJQUFJaW9DLGNBQWMsR0FBR2o0QixTQUFTLENBQUNsTixNQUFNLEdBQUcsQ0FBQyxJQUFJa04sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLeVAsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUlxWixHQUFHLENBQUMsQ0FBQztFQUNsRyxLQUFLLElBQUlwcEIsR0FBRyxJQUFJRCxHQUFHLEVBQUU7SUFDakIsSUFBSXJCLEtBQUssR0FBR3FCLEdBQUcsQ0FBQ0MsR0FBRyxDQUFDO0lBQ3BCLElBQUk4NkIsSUFBSSxHQUFHLE9BQU9wOEIsS0FBSztJQUN2QixJQUFJQSxLQUFLLEtBQUs4Z0IsU0FBUyxJQUFJc2IsSUFBSSxLQUFLLFVBQVUsSUFBSUEsSUFBSSxLQUFLLFFBQVEsSUFBSXA4QixLQUFLLFlBQVkyaUMsTUFBTSxJQUFJM2lDLEtBQUssWUFBWWdkLEdBQUcsSUFBSWhkLEtBQUssWUFBWTBxQixHQUFHLElBQUkxcUIsS0FBSyxZQUFZdUgsSUFBSSxJQUFJdkgsS0FBSyxLQUFLLElBQUksSUFBSW84QixJQUFJLEtBQUssUUFBUSxJQUFJcDhCLEtBQUssQ0FBQ3FsQixjQUFjLENBQUMsUUFBUSxDQUFDLEVBQUU7TUFDOU8sT0FBTyxJQUFJO0lBQ2Y7SUFDQSxJQUFJcmxCLEtBQUssS0FBSyxJQUFJLElBQUlvOEIsSUFBSSxLQUFLLFFBQVEsSUFBSXA4QixLQUFLLENBQUNlLFdBQVcsS0FBS2pCLE1BQU0sRUFBRTtNQUNyRSxJQUFJd3BDLGNBQWMsQ0FBQ3AvQixHQUFHLENBQUNsSyxLQUFLLENBQUMsRUFBRTtRQUMzQjtRQUNBLE9BQU8sSUFBSTtNQUNmO01BQ0FzcEMsY0FBYyxDQUFDOStCLEdBQUcsQ0FBQ3hLLEtBQUssQ0FBQztNQUN6QixJQUFJcXBDLDBCQUEwQixDQUFDcnBDLEtBQUssRUFBRXNwQyxjQUFjLENBQUMsRUFBRTtRQUNuRCxPQUFPLElBQUk7TUFDZjtJQUNKO0VBQ0o7RUFDQSxPQUFPLEtBQUs7QUFDaEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNPLFNBQVNDLFFBQVFBLENBQUNDLFVBQVUsRUFBRWxvQyxHQUFHLEVBQUU7RUFDdEMsS0FBSyxJQUFJZCxDQUFDLEdBQUcsQ0FBQyxFQUFFbWtCLE1BQU0sRUFBRW5rQixDQUFDLEdBQUdncEMsVUFBVSxDQUFDcmxDLE1BQU0sRUFBRTNELENBQUMsRUFBRSxFQUFFO0lBQ2hEbWtCLE1BQU0sR0FBR21CLHdEQUFVLENBQUMwakIsVUFBVSxDQUFDaHBDLENBQUMsQ0FBQyxFQUFFYyxHQUFHLENBQUM7SUFDdkMsSUFBSXFqQixNQUFNLEVBQUU7TUFDUixPQUFPQSxNQUFNO0lBQ2pCO0VBQ0o7RUFDQSxPQUFPN0QsU0FBUztBQUNwQjtBQUNPLFNBQVMyb0IscUJBQXFCQSxDQUFDQyxRQUFRLEVBQUU7RUFDNUMsSUFBSUMsTUFBTSxHQUFHLElBQUk7RUFDakIsSUFBSTtJQUNBLElBQUlDLE9BQU8sR0FBRyxtREFBbUQsQ0FBQ0MsSUFBSSxDQUFDSCxRQUFRLENBQUM7SUFDaEYsSUFBSUUsT0FBTyxJQUFJLElBQUksSUFBSUEsT0FBTyxDQUFDemxDLE1BQU0sR0FBRyxDQUFDLEVBQUU7TUFDdkN3bEMsTUFBTSxHQUFHQyxPQUFPLENBQUMsQ0FBQyxDQUFDO01BQ25CLEtBQUssSUFBSXBwQyxDQUFDLEdBQUcsQ0FBQyxFQUFFQSxDQUFDLEdBQUdvcEMsT0FBTyxDQUFDemxDLE1BQU0sRUFBRTNELENBQUMsRUFBRSxFQUFFO1FBQ3JDLElBQUlvcEMsT0FBTyxDQUFDcHBDLENBQUMsQ0FBQyxDQUFDMkQsTUFBTSxHQUFHd2xDLE1BQU0sQ0FBQ3hsQyxNQUFNLEVBQUU7VUFDbkN3bEMsTUFBTSxHQUFHQyxPQUFPLENBQUNwcEMsQ0FBQyxDQUFDO1FBQ3ZCO01BQ0o7SUFDSjtFQUNKLENBQUMsQ0FDRCxPQUFPYixDQUFDLEVBQUU7SUFDTmdxQyxNQUFNLEdBQUcsSUFBSTtFQUNqQjtFQUNBLE9BQU9BLE1BQU07QUFDakI7QUFDTyxTQUFTRyxrQkFBa0JBLENBQUNoSixHQUFHLEVBQUVoTSxHQUFHLEVBQUU7RUFDekMsSUFBSTNPLEtBQUssQ0FBQzJhLEdBQUcsQ0FBQ2lKLElBQUksQ0FBQyxJQUFJakosR0FBRyxDQUFDaUosSUFBSSxLQUFLLEVBQUUsRUFBRTtJQUNwQ2pKLEdBQUcsQ0FBQ2lKLElBQUksR0FBR2pKLEdBQUcsQ0FBQ2lKLElBQUksQ0FBQ3Q3QixPQUFPLENBQUMsbUJBQW1CLEVBQUVxbUIsR0FBRyxDQUFDO0lBQ3JENkUsWUFBWSxDQUFDbUgsR0FBRyxDQUFDaUosSUFBSSxDQUFDO0VBQzFCO0FBQ0osQzs7Ozs7Ozs7Ozs7Ozs7O0FDcnFDQSxTQUFTQywwQkFBMEJBLENBQUNycUMsQ0FBQyxFQUFFRSxDQUFDLEVBQUV1K0IsQ0FBQyxFQUFFO0VBQUU2TCwwQkFBMEIsQ0FBQ3RxQyxDQUFDLEVBQUVFLENBQUMsQ0FBQyxFQUFFQSxDQUFDLENBQUM0SyxHQUFHLENBQUM5SyxDQUFDLEVBQUV5K0IsQ0FBQyxDQUFDO0FBQUU7QUFDOUYsU0FBUzZMLDBCQUEwQkEsQ0FBQ3RxQyxDQUFDLEVBQUVFLENBQUMsRUFBRTtFQUFFLElBQUlBLENBQUMsQ0FBQ3FLLEdBQUcsQ0FBQ3ZLLENBQUMsQ0FBQyxFQUNwRCxNQUFNLElBQUllLFNBQVMsQ0FBQyxnRUFBZ0UsQ0FBQztBQUFFO0FBQzNGLFNBQVN3cEMscUJBQXFCQSxDQUFDQyxDQUFDLEVBQUUvTCxDQUFDLEVBQUU7RUFBRSxPQUFPK0wsQ0FBQyxDQUFDOS9CLEdBQUcsQ0FBQysvQixpQkFBaUIsQ0FBQ0QsQ0FBQyxFQUFFL0wsQ0FBQyxDQUFDLENBQUM7QUFBRTtBQUM5RSxTQUFTaU0scUJBQXFCQSxDQUFDRixDQUFDLEVBQUUvTCxDQUFDLEVBQUV4K0IsQ0FBQyxFQUFFO0VBQUUsT0FBT3VxQyxDQUFDLENBQUMxL0IsR0FBRyxDQUFDMi9CLGlCQUFpQixDQUFDRCxDQUFDLEVBQUUvTCxDQUFDLENBQUMsRUFBRXgrQixDQUFDLENBQUMsRUFBRUEsQ0FBQztBQUFFO0FBQ3ZGLFNBQVN3cUMsaUJBQWlCQSxDQUFDenFDLENBQUMsRUFBRUUsQ0FBQyxFQUFFcWEsQ0FBQyxFQUFFO0VBQUUsSUFBSSxVQUFVLElBQUksT0FBT3ZhLENBQUMsR0FBR0EsQ0FBQyxLQUFLRSxDQUFDLEdBQUdGLENBQUMsQ0FBQ3VLLEdBQUcsQ0FBQ3JLLENBQUMsQ0FBQyxFQUNqRixPQUFPd1IsU0FBUyxDQUFDbE4sTUFBTSxHQUFHLENBQUMsR0FBR3RFLENBQUMsR0FBR3FhLENBQUM7RUFBRSxNQUFNLElBQUl4WixTQUFTLENBQUMsK0NBQStDLENBQUM7QUFBRTtBQUMvRyxJQUFJNHBDLE9BQU8sR0FBRyxDQUFDO0FBQ2YsSUFBSUMsSUFBSSxHQUFHLENBQUM7QUFDWjtBQUNBO0FBQ0E7QUFDQSxJQUFJQyxPQUFPLEdBQUcsYUFBYyxJQUFJeitCLE9BQU8sQ0FBQyxDQUFDO0FBQ3pDLElBQUkwK0IsVUFBVSxHQUFHLGFBQWMsSUFBSTErQixPQUFPLENBQUMsQ0FBQztBQUNyQyxNQUFNNnJCLGFBQWEsQ0FBQztFQUN2QjtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7RUFDSSxPQUFPcnFCLE9BQU9BLENBQUEsRUFBRztJQUNiLElBQUltOUIsT0FBTyxHQUFHcjVCLFNBQVMsQ0FBQ2xOLE1BQU0sR0FBRyxDQUFDLElBQUlrTixTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUt5UCxTQUFTLEdBQUd6UCxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQztJQUNuRixPQUFPLElBQUl1bUIsYUFBYSxDQUFDdmMsT0FBTyxJQUFJO01BQ2hDcXZCLE9BQU8sS0FBSyxDQUFDLEdBQUdydkIsT0FBTyxDQUFDLENBQUMsR0FBRzdOLFVBQVUsQ0FBQzZOLE9BQU8sRUFBRXF2QixPQUFPLENBQUM7SUFDNUQsQ0FBQyxDQUFDO0VBQ047RUFDQTNwQyxXQUFXQSxDQUFDNHBDLFFBQVEsRUFBRTtJQUNsQlgsMEJBQTBCLENBQUMsSUFBSSxFQUFFUSxPQUFPLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDakRSLDBCQUEwQixDQUFDLElBQUksRUFBRVMsVUFBVSxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ3BELElBQUksT0FBT0UsUUFBUSxLQUFLLFVBQVUsRUFBRTtNQUNoQyxNQUFNLElBQUk5aEMsS0FBSyxDQUFDLHlCQUF5QixDQUFDO0lBQzlDO0lBQ0EsSUFBSThiLE1BQU0sR0FBRyxFQUFFO0lBQ2YsSUFBSWltQixTQUFTLEdBQUcsRUFBRTtJQUNsQixJQUFJLENBQUN2dkIsT0FBTyxFQUFFQyxNQUFNLENBQUMsR0FBRyxDQUFDZ3ZCLE9BQU8sRUFBRUMsSUFBSSxDQUFDLENBQUM5a0MsR0FBRyxDQUFDMjJCLElBQUksSUFBSTtNQUNoRCxPQUFPLFVBQVVwOEIsS0FBSyxFQUFFO1FBQ3BCLElBQUlvOEIsSUFBSSxLQUFLa08sT0FBTyxJQUFJLFFBQVF0cUMsS0FBSyxLQUFLLElBQUksSUFBSUEsS0FBSyxLQUFLLEtBQUssQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHQSxLQUFLLENBQUNvL0IsSUFBSSxDQUFDLEtBQUssVUFBVSxFQUFFO1VBQ3RHcC9CLEtBQUssQ0FBQ28vQixJQUFJLENBQUMvakIsT0FBTyxFQUFFQyxNQUFNLENBQUM7UUFDL0IsQ0FBQyxNQUNJLElBQUksQ0FBQ3FKLE1BQU0sQ0FBQ3hnQixNQUFNLEVBQUU7VUFDckJ3Z0IsTUFBTSxDQUFDNVIsSUFBSSxDQUFDcXBCLElBQUksRUFBRXA4QixLQUFLLENBQUM7VUFDeEIsT0FBTzRxQyxTQUFTLENBQUN6bUMsTUFBTSxFQUNuQnltQyxTQUFTLENBQUN4RCxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0I7TUFDSixDQUFDO0lBQ0wsQ0FBQyxDQUFDO0lBQ0YsSUFBSTtNQUNBdUQsUUFBUSxDQUFDdHZCLE9BQU8sRUFBRUMsTUFBTSxDQUFDO0lBQzdCLENBQUMsQ0FDRCxPQUFPM2IsQ0FBQyxFQUFFO01BQ04yYixNQUFNLENBQUMzYixDQUFDLENBQUM7SUFDYjtJQUNBMHFDLHFCQUFxQixDQUFDRyxPQUFPLEVBQUUsSUFBSSxFQUFFN2xCLE1BQU0sQ0FBQztJQUM1QzBsQixxQkFBcUIsQ0FBQ0ksVUFBVSxFQUFFLElBQUksRUFBRUcsU0FBUyxDQUFDO0VBQ3REO0VBQ0F4TCxJQUFJQSxDQUFDeUwsU0FBUyxFQUFFQyxPQUFPLEVBQUU7SUFDckIsSUFBSW5tQixNQUFNLEdBQUd1bEIscUJBQXFCLENBQUNNLE9BQU8sRUFBRSxJQUFJLENBQUM7SUFDakQsT0FBTyxJQUFJLElBQUksQ0FBQ3pwQyxXQUFXLENBQUMsQ0FBQ3NhLE9BQU8sRUFBRUMsTUFBTSxLQUFLO01BQzdDLElBQUl5dkIsWUFBWSxHQUFHQSxDQUFBLEtBQU07UUFDckIsSUFBSS9xQyxLQUFLLEdBQUcya0IsTUFBTSxDQUFDLENBQUMsQ0FBQztRQUNyQixJQUFJLENBQUMvWSxPQUFPLEVBQUVvL0IsU0FBUyxDQUFDLEdBQUdybUIsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLMmxCLE9BQU8sR0FBRyxDQUFDTyxTQUFTLEVBQUV4dkIsT0FBTyxDQUFDLEdBQUcsQ0FBQ3l2QixPQUFPLEVBQUV4dkIsTUFBTSxDQUFDO1FBQzNGLElBQUksT0FBTzFQLE9BQU8sS0FBSyxVQUFVLEVBQUU7VUFDL0IsSUFBSTtZQUNBNUwsS0FBSyxHQUFHNEwsT0FBTyxDQUFDNUwsS0FBSyxDQUFDO1VBQzFCLENBQUMsQ0FDRCxPQUFPTCxDQUFDLEVBQUU7WUFDTjJiLE1BQU0sQ0FBQzNiLENBQUMsQ0FBQztZQUNUO1VBQ0o7VUFDQXFyQyxTQUFTLEdBQUczdkIsT0FBTztRQUN2QjtRQUNBMnZCLFNBQVMsQ0FBQ2hyQyxLQUFLLENBQUM7TUFDcEIsQ0FBQztNQUNEMmtCLE1BQU0sQ0FBQ3hnQixNQUFNLEdBQUc0bUMsWUFBWSxDQUFDLENBQUMsR0FBR2IscUJBQXFCLENBQUNPLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQzEzQixJQUFJLENBQUNnNEIsWUFBWSxDQUFDO0lBQy9GLENBQUMsQ0FBQztFQUNOO0VBQ0FFLEtBQUtBLENBQUNILE9BQU8sRUFBRTtJQUNYLE9BQU8sSUFBSSxDQUFDMUwsSUFBSSxDQUFDLElBQUksRUFBRTBMLE9BQU8sQ0FBQztFQUNuQztFQUNBdjJCLE9BQU9BLENBQUMyMkIsU0FBUyxFQUFFO0lBQ2YsSUFBSXhuQixHQUFHO0lBQ1AsT0FBTyxJQUFJLENBQUMwYixJQUFJLENBQUNqQixDQUFDLElBQUk7TUFDbEJ6YSxHQUFHLEdBQUd5YSxDQUFDO01BQ1AsT0FBTytNLFNBQVMsQ0FBQyxDQUFDO0lBQ3RCLENBQUMsRUFBRXZyQyxDQUFDLElBQUk7TUFDSitqQixHQUFHLEdBQUcsSUFBSSxDQUFDM2lCLFdBQVcsQ0FBQ3VhLE1BQU0sQ0FBQzNiLENBQUMsQ0FBQztNQUNoQyxPQUFPdXJDLFNBQVMsQ0FBQyxDQUFDO0lBQ3RCLENBQUMsQ0FBQyxDQUFDOUwsSUFBSSxDQUFDLE1BQU0xYixHQUFHLENBQUM7RUFDdEI7RUFDQSxPQUFPeW5CLElBQUlBLENBQUNDLFFBQVEsRUFBRTtJQUNsQixPQUFPLElBQUksSUFBSSxDQUFDLENBQUMvdkIsT0FBTyxFQUFFQyxNQUFNLEtBQUs7TUFDakM4dUIsaUJBQWlCLENBQUN4UyxhQUFhLEVBQUUsSUFBSSxFQUFFeVQsUUFBUSxDQUFDLENBQUM1cUMsSUFBSSxDQUFDLElBQUksRUFBRTJxQyxRQUFRLEVBQUUsQ0FBQ3hrQyxPQUFPLEVBQUUrZCxNQUFNLEtBQUsvZCxPQUFPLEdBQUd5VSxPQUFPLENBQUNzSixNQUFNLENBQUMsR0FBR3JKLE1BQU0sQ0FBQ3FKLE1BQU0sQ0FBQyxDQUFDO0lBQzFJLENBQUMsQ0FBQztFQUNOO0VBQ0EsT0FBTzJtQixHQUFHQSxDQUFDRixRQUFRLEVBQUU7SUFDakIsT0FBTyxJQUFJLElBQUksQ0FBQyxDQUFDL3ZCLE9BQU8sRUFBRUMsTUFBTSxLQUFLO01BQ2pDLElBQUk2UCxHQUFHLEdBQUcsRUFBRTtNQUNaaWYsaUJBQWlCLENBQUN4UyxhQUFhLEVBQUUsSUFBSSxFQUFFeVQsUUFBUSxDQUFDLENBQUM1cUMsSUFBSSxDQUFDLElBQUksRUFBRTJxQyxRQUFRLEVBQUUsQ0FBQ3hrQyxPQUFPLEVBQUU4YyxHQUFHLEVBQUVsakIsQ0FBQyxLQUFLb0csT0FBTyxHQUFHdWtCLEdBQUcsQ0FBQzNxQixDQUFDLENBQUMsR0FBR2tqQixHQUFHLEdBQUdwSSxNQUFNLENBQUNvSSxHQUFHLENBQUMsRUFBRSxNQUFNckksT0FBTyxDQUFDOFAsR0FBRyxDQUFDLENBQUM7SUFDeEosQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPb2dCLFVBQVVBLENBQUNILFFBQVEsRUFBRTtJQUN4QixPQUFPLElBQUksSUFBSSxDQUFDL3ZCLE9BQU8sSUFBSTtNQUN2QixJQUFJOFAsR0FBRyxHQUFHLEVBQUU7TUFDWmlmLGlCQUFpQixDQUFDeFMsYUFBYSxFQUFFLElBQUksRUFBRXlULFFBQVEsQ0FBQyxDQUFDNXFDLElBQUksQ0FBQyxJQUFJLEVBQUUycUMsUUFBUSxFQUFFLENBQUN4a0MsT0FBTyxFQUFFOGMsR0FBRyxFQUFFbGpCLENBQUMsS0FBSzJxQixHQUFHLENBQUMzcUIsQ0FBQyxDQUFDLEdBQUdvRyxPQUFPLEdBQUc7UUFDMUc0a0MsTUFBTSxFQUFFLFdBQVc7UUFDbkJ4ckMsS0FBSyxFQUFFMGpCO01BQ1gsQ0FBQyxHQUFHO1FBQ0E4bkIsTUFBTSxFQUFFLFVBQVU7UUFDbEJDLE1BQU0sRUFBRS9uQjtNQUNaLENBQUMsRUFBRSxNQUFNckksT0FBTyxDQUFDOFAsR0FBRyxDQUFDLENBQUM7SUFDMUIsQ0FBQyxDQUFDO0VBQ047RUFDQSxPQUFPOVAsT0FBT0EsQ0FBQ3JiLEtBQUssRUFBRTtJQUNsQixPQUFPLElBQUksSUFBSSxDQUFDcWIsT0FBTyxJQUFJQSxPQUFPLENBQUNyYixLQUFLLENBQUMsQ0FBQztFQUM5QztFQUNBLE9BQU9zYixNQUFNQSxDQUFDelUsS0FBSyxFQUFFO0lBQ2pCLE9BQU8sSUFBSSxJQUFJLENBQUMsQ0FBQ3dVLE9BQU8sRUFBRUMsTUFBTSxLQUFLQSxNQUFNLENBQUN6VSxLQUFLLENBQUMsQ0FBQztFQUN2RDtBQUNKO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsU0FBU3drQyxRQUFRQSxDQUFDRCxRQUFRLEVBQUVNLFNBQVMsRUFBRXpNLElBQUksRUFBRTtFQUN6QyxJQUFJME0sR0FBRyxHQUFHUCxRQUFRLENBQUNqbkMsTUFBTTtFQUN6QixTQUFTeW5DLEdBQUdBLENBQUEsRUFBRztJQUNYRixTQUFTLENBQUN2NkIsS0FBSyxDQUFDLElBQUksRUFBRUUsU0FBUyxDQUFDO0lBQ2hDLElBQUksRUFBRXM2QixHQUFHLElBQUksQ0FBQyxJQUFJMU0sSUFBSSxFQUNsQkEsSUFBSSxDQUFDLENBQUM7RUFDZDtFQUNBbU0sUUFBUSxDQUFDam5DLE1BQU0sS0FBSyxDQUFDLElBQUk4NkIsSUFBSSxHQUFHQSxJQUFJLENBQUMsQ0FBQyxHQUFHbU0sUUFBUSxDQUFDamtDLE9BQU8sQ0FBQyxDQUFDb2MsQ0FBQyxFQUFFL2lCLENBQUMsS0FBSyxJQUFJLENBQUM2YSxPQUFPLENBQUNrSSxDQUFDLENBQUMsQ0FBQzZiLElBQUksQ0FBQzFiLEdBQUcsSUFBSWtvQixHQUFHLENBQUMsSUFBSSxFQUFFbG9CLEdBQUcsRUFBRWxqQixDQUFDLENBQUMsRUFBRXMyQixHQUFHLElBQUk4VSxHQUFHLENBQUMsS0FBSyxFQUFFOVUsR0FBRyxFQUFFdDJCLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEo7QUFDTyxTQUFTcXJDLEtBQUtBLENBQUEsRUFBRztFQUNwQixJQUFJO0lBQUVDLGNBQWMsR0FBR25CLFFBQVEsSUFBSSxJQUFJL1MsYUFBYSxDQUFDK1MsUUFBUTtFQUFFLENBQUMsR0FBR3Q1QixTQUFTLENBQUNsTixNQUFNLEdBQUcsQ0FBQyxJQUFJa04sU0FBUyxDQUFDLENBQUMsQ0FBQyxLQUFLeVAsU0FBUyxHQUFHelAsU0FBUyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQztFQUN6SSxTQUFTMDZCLE9BQU9BLENBQUNDLFFBQVEsRUFBRTtJQUN2QixPQUFPdG9CLEdBQUcsSUFBSXNvQixRQUFRLENBQUN0b0IsR0FBRyxDQUFDO0VBQy9CO0VBQ0EsSUFBSXNuQixTQUFTLEVBQUVpQixRQUFRO0VBQ3ZCLE9BQU87SUFDSEMsT0FBTyxFQUFFSixjQUFjLENBQUMsQ0FBQ3p3QixPQUFPLEVBQUVDLE1BQU0sS0FBSztNQUN6QzB2QixTQUFTLEdBQUczdkIsT0FBTztNQUNuQjR3QixRQUFRLEdBQUczd0IsTUFBTTtJQUNyQixDQUFDLENBQUM7SUFDRkQsT0FBTyxFQUFFMHdCLE9BQU8sQ0FBQ2YsU0FBUyxDQUFDO0lBQzNCMXZCLE1BQU0sRUFBRXl3QixPQUFPLENBQUNFLFFBQVE7RUFDNUIsQ0FBQztBQUNMLEMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BiYWJlbCtydW50aW1lQDcuMjcuNi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9lc20vZGVmaW5lUHJvcGVydHkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AYmFiZWwrcnVudGltZUA3LjI3LjYvbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXNtL3RvUHJpbWl0aXZlLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGJhYmVsK3J1bnRpbWVANy4yNy42L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2VzbS90b1Byb3BlcnR5S2V5LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGJhYmVsK3J1bnRpbWVANy4yNy42L25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2VzbS90eXBlb2YuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rYWItY29yZUA4LjAuMV90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vYWItY29yZS9kaXN0L2FiLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2FiLWNvcmVAOC4wLjFfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2FiLWNvcmUvZGlzdC9jb3JlLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2FiLWNvcmVAOC4wLjFfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2FiLWNvcmUvZGlzdC9vcGhhbi5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbithYi1jb3JlQDguMC4xX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9hYi1jb3JlL2Rpc3QvdGltZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitpZGVudGl0eS1hdXRoLWZyb250ZW5kQDEyLjAuMF9AZ3VhcmRpYW4raWRlbnRpdHktYXV0aEAxMC4wLjBfQGd1YXJkaWFuK2xpYnNAMjUuMi4wX19oeTN3b2k1c2ZwYnN0YmtqN21panlicTdtdS9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgtZnJvbnRlbmQvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitpZGVudGl0eS1hdXRoQDEwLjAuMF9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMl90YTd0MmZ4dGRkbHNraXhudjZicm5ybjU0YS9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgvZGlzdC9AdHlwZXMvT0F1dGguanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4raWRlbnRpdHktYXV0aEAxMC4wLjBfQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDJfdGE3dDJmeHRkZGxza2l4bnY2YnJucm41NGEvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9pZGVudGl0eS1hdXRoL2Rpc3QvQHR5cGVzL2d1YXJkLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2lkZW50aXR5LWF1dGhAMTAuMC4wX0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyX3RhN3QyZnh0ZGRsc2tpeG52NmJybnJuNTRhL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vaWRlbnRpdHktYXV0aC9kaXN0L2F1dGhTdGF0ZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitpZGVudGl0eS1hdXRoQDEwLjAuMF9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMl90YTd0MmZ4dGRkbHNraXhudjZicm5ybjU0YS9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgvZGlzdC9hdXRvUmVuZXcuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4raWRlbnRpdHktYXV0aEAxMC4wLjBfQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDJfdGE3dDJmeHRkZGxza2l4bnY2YnJucm41NGEvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9pZGVudGl0eS1hdXRoL2Rpc3QvY29va2llUmVmcmVzaC5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitpZGVudGl0eS1hdXRoQDEwLjAuMF9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMl90YTd0MmZ4dGRkbHNraXhudjZicm5ybjU0YS9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgvZGlzdC9jcnlwdG8uanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4raWRlbnRpdHktYXV0aEAxMC4wLjBfQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDJfdGE3dDJmeHRkZGxza2l4bnY2YnJucm41NGEvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9pZGVudGl0eS1hdXRoL2Rpc3QvZW1pdHRlci5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitpZGVudGl0eS1hdXRoQDEwLjAuMF9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMl90YTd0MmZ4dGRkbHNraXhudjZicm5ybjU0YS9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgvZGlzdC9lcnJvci5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitpZGVudGl0eS1hdXRoQDEwLjAuMF9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMl90YTd0MmZ4dGRkbHNraXhudjZicm5ybjU0YS9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgvZGlzdC9pZGVudGl0eUF1dGguanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4raWRlbnRpdHktYXV0aEAxMC4wLjBfQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDJfdGE3dDJmeHRkZGxza2l4bnY2YnJucm41NGEvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9pZGVudGl0eS1hdXRoL2Rpc3QvdG9rZW4uanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4raWRlbnRpdHktYXV0aEAxMC4wLjBfQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDJfdGE3dDJmeHRkZGxza2l4bnY2YnJucm41NGEvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9pZGVudGl0eS1hdXRoL2Rpc3QvdG9rZW5NYW5hZ2VyLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vQGd1YXJkaWFuK2xpYnNAMjUuMi4wX0BndWFyZGlhbitvcGhhbi10cmFja2VyLWpzQDIuNC4wX3RzbGliQDIuOC4xX3R5cGVzY3JpcHRANS44LjMvbm9kZV9tb2R1bGVzL0BndWFyZGlhbi9saWJzL2Rpc3QvY29va2llcy9zZXRDb29raWUuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9pc05vbk51bGxhYmxlL2lzTm9uTnVsbGFibGUuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9pc09uZU9mL2lzT25lT2YuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9AZ3VhcmRpYW4rbGlic0AyNS4yLjBfQGd1YXJkaWFuK29waGFuLXRyYWNrZXItanNAMi40LjBfdHNsaWJAMi44LjFfdHlwZXNjcmlwdEA1LjguMy9ub2RlX21vZHVsZXMvQGd1YXJkaWFuL2xpYnMvZGlzdC9wZXJmb3JtYW5jZS9nZXRNZWFzdXJlcy5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL0BndWFyZGlhbitsaWJzQDI1LjIuMF9AZ3VhcmRpYW4rb3BoYW4tdHJhY2tlci1qc0AyLjQuMF90c2xpYkAyLjguMV90eXBlc2NyaXB0QDUuOC4zL25vZGVfbW9kdWxlcy9AZ3VhcmRpYW4vbGlicy9kaXN0L3BlcmZvcm1hbmNlL3NlcmlhbGlzZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2RsdkAxLjEuMy9ub2RlX21vZHVsZXMvZGx2L2luZGV4LmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vZHNldEAzLjEuNC9ub2RlX21vZHVsZXMvZHNldC9kaXN0L2luZGV4Lm1qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2tsb25hQDIuMC42L25vZGVfbW9kdWxlcy9rbG9uYS9qc29uL2luZGV4Lm1qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2xvZGFzaC1lc0A0LjE3LjIxL25vZGVfbW9kdWxlcy9sb2Rhc2gtZXMvX2FycmF5UHVzaC5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2xvZGFzaC1lc0A0LjE3LjIxL25vZGVfbW9kdWxlcy9sb2Rhc2gtZXMvX2Jhc2VGbGF0dGVuLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vbG9kYXNoLWVzQDQuMTcuMjEvbm9kZV9tb2R1bGVzL2xvZGFzaC1lcy9fYmFzZUlzQXJndW1lbnRzLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vbG9kYXNoLWVzQDQuMTcuMjEvbm9kZV9tb2R1bGVzL2xvZGFzaC1lcy9faXNGbGF0dGVuYWJsZS5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2xvZGFzaC1lc0A0LjE3LjIxL25vZGVfbW9kdWxlcy9sb2Rhc2gtZXMvZmxhdHRlbi5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL2xvZGFzaC1lc0A0LjE3LjIxL25vZGVfbW9kdWxlcy9sb2Rhc2gtZXMvaXNBcmd1bWVudHMuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9sb2Rhc2gtZXNANC4xNy4yMS9ub2RlX21vZHVsZXMvbG9kYXNoLWVzL2lzQXJyYXkuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9wcmViaWQuanNAOS4yNy4wX2Vqc0AzLjEuMTBfaGFuZGxlYmFyc0A0LjcuOC9ub2RlX21vZHVsZXMvcHJlYmlkLmpzL3NyYy9jb25maWcuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9wcmViaWQuanNAOS4yNy4wX2Vqc0AzLjEuMTBfaGFuZGxlYmFyc0A0LjcuOC9ub2RlX21vZHVsZXMvcHJlYmlkLmpzL3NyYy9jb25zdGFudHMuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9wcmViaWQuanNAOS4yNy4wX2Vqc0AzLjEuMTBfaGFuZGxlYmFyc0A0LjcuOC9ub2RlX21vZHVsZXMvcHJlYmlkLmpzL3NyYy9jcG1CdWNrZXRNYW5hZ2VyLmpzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uLi9ub2RlX21vZHVsZXMvLnBucG0vcHJlYmlkLmpzQDkuMjcuMF9lanNAMy4xLjEwX2hhbmRsZWJhcnNANC43Ljgvbm9kZV9tb2R1bGVzL3ByZWJpZC5qcy9zcmMvcG9seWZpbGwuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9wcmViaWQuanNAOS4yNy4wX2Vqc0AzLjEuMTBfaGFuZGxlYmFyc0A0LjcuOC9ub2RlX21vZHVsZXMvcHJlYmlkLmpzL3NyYy9wcmViaWRHbG9iYWwuanMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4uL25vZGVfbW9kdWxlcy8ucG5wbS9wcmViaWQuanNAOS4yNy4wX2Vqc0AzLjEuMTBfaGFuZGxlYmFyc0A0LjcuOC9ub2RlX21vZHVsZXMvcHJlYmlkLmpzL3NyYy91dGlscy5qcyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi4vbm9kZV9tb2R1bGVzLy5wbnBtL3ByZWJpZC5qc0A5LjI3LjBfZWpzQDMuMS4xMF9oYW5kbGViYXJzQDQuNy44L25vZGVfbW9kdWxlcy9wcmViaWQuanMvc3JjL3V0aWxzL3Byb21pc2UuanMiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHRvUHJvcGVydHlLZXkgZnJvbSBcIi4vdG9Qcm9wZXJ0eUtleS5qc1wiO1xuZnVuY3Rpb24gX2RlZmluZVByb3BlcnR5KGUsIHIsIHQpIHtcbiAgICByZXR1cm4gKHIgPSB0b1Byb3BlcnR5S2V5KHIpKSBpbiBlID8gT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIHtcbiAgICAgICAgdmFsdWU6IHQsXG4gICAgICAgIGVudW1lcmFibGU6ICEwLFxuICAgICAgICBjb25maWd1cmFibGU6ICEwLFxuICAgICAgICB3cml0YWJsZTogITBcbiAgICB9KSA6IGVbcl0gPSB0LCBlO1xufVxuZXhwb3J0IHsgX2RlZmluZVByb3BlcnR5IGFzIGRlZmF1bHQgfTtcbiIsImltcG9ydCBfdHlwZW9mIGZyb20gXCIuL3R5cGVvZi5qc1wiO1xuZnVuY3Rpb24gdG9QcmltaXRpdmUodCwgcikge1xuICAgIGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YodCkgfHwgIXQpXG4gICAgICAgIHJldHVybiB0O1xuICAgIHZhciBlID0gdFtTeW1ib2wudG9QcmltaXRpdmVdO1xuICAgIGlmICh2b2lkIDAgIT09IGUpIHtcbiAgICAgICAgdmFyIGkgPSBlLmNhbGwodCwgciB8fCBcImRlZmF1bHRcIik7XG4gICAgICAgIGlmIChcIm9iamVjdFwiICE9IF90eXBlb2YoaSkpXG4gICAgICAgICAgICByZXR1cm4gaTtcbiAgICAgICAgdGhyb3cgbmV3IFR5cGVFcnJvcihcIkBAdG9QcmltaXRpdmUgbXVzdCByZXR1cm4gYSBwcmltaXRpdmUgdmFsdWUuXCIpO1xuICAgIH1cbiAgICByZXR1cm4gKFwic3RyaW5nXCIgPT09IHIgPyBTdHJpbmcgOiBOdW1iZXIpKHQpO1xufVxuZXhwb3J0IHsgdG9QcmltaXRpdmUgYXMgZGVmYXVsdCB9O1xuIiwiaW1wb3J0IF90eXBlb2YgZnJvbSBcIi4vdHlwZW9mLmpzXCI7XG5pbXBvcnQgdG9QcmltaXRpdmUgZnJvbSBcIi4vdG9QcmltaXRpdmUuanNcIjtcbmZ1bmN0aW9uIHRvUHJvcGVydHlLZXkodCkge1xuICAgIHZhciBpID0gdG9QcmltaXRpdmUodCwgXCJzdHJpbmdcIik7XG4gICAgcmV0dXJuIFwic3ltYm9sXCIgPT0gX3R5cGVvZihpKSA/IGkgOiBpICsgXCJcIjtcbn1cbmV4cG9ydCB7IHRvUHJvcGVydHlLZXkgYXMgZGVmYXVsdCB9O1xuIiwiZnVuY3Rpb24gX3R5cGVvZihvKSB7XG4gICAgXCJAYmFiZWwvaGVscGVycyAtIHR5cGVvZlwiO1xuICAgIHJldHVybiBfdHlwZW9mID0gXCJmdW5jdGlvblwiID09IHR5cGVvZiBTeW1ib2wgJiYgXCJzeW1ib2xcIiA9PSB0eXBlb2YgU3ltYm9sLml0ZXJhdG9yID8gZnVuY3Rpb24gKG8pIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiBvO1xuICAgIH0gOiBmdW5jdGlvbiAobykge1xuICAgICAgICByZXR1cm4gbyAmJiBcImZ1bmN0aW9uXCIgPT0gdHlwZW9mIFN5bWJvbCAmJiBvLmNvbnN0cnVjdG9yID09PSBTeW1ib2wgJiYgbyAhPT0gU3ltYm9sLnByb3RvdHlwZSA/IFwic3ltYm9sXCIgOiB0eXBlb2YgbztcbiAgICB9LCBfdHlwZW9mKG8pO1xufVxuZXhwb3J0IHsgX3R5cGVvZiBhcyBkZWZhdWx0IH07XG4iLCJpbXBvcnQgeyBpbml0Q29yZSB9IGZyb20gJy4vY29yZS5qcyc7XG5pbXBvcnQgeyBpbml0T3BoYW4gfSBmcm9tICcuL29waGFuLmpzJztcbnZhciBfX2RlZlByb3AgPSBPYmplY3QuZGVmaW5lUHJvcGVydHk7XG52YXIgX19kZWZOb3JtYWxQcm9wID0gKG9iaiwga2V5LCB2YWx1ZSkgPT4ga2V5IGluIG9iaiA/IF9fZGVmUHJvcChvYmosIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlLCB2YWx1ZSB9KSA6IG9ialtrZXldID0gdmFsdWU7XG52YXIgX19wdWJsaWNGaWVsZCA9IChvYmosIGtleSwgdmFsdWUpID0+IF9fZGVmTm9ybWFsUHJvcChvYmosIHR5cGVvZiBrZXkgIT09IFwic3ltYm9sXCIgPyBrZXkgKyBcIlwiIDoga2V5LCB2YWx1ZSk7XG5jbGFzcyBBQiB7XG4gICAgY29uc3RydWN0b3IoeyBhYlRlc3RTd2l0Y2hlcywgYXJyYXlPZlRlc3RPYmplY3RzLCBlcnJvclJlcG9ydGVyLCBmb3JjZWRUZXN0RXhjZXB0aW9uLCBmb3JjZWRUZXN0VmFyaWFudHMsIG12dElkLCBtdnRNYXhWYWx1ZSwgb3BoYW5SZWNvcmQsIHBhZ2VJc1NlbnNpdGl2ZSwgc2VydmVyU2lkZVRlc3RzIH0pIHtcbiAgICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcIl9jb3JlXCIpO1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiX29waGFuXCIpO1xuICAgICAgICB0aGlzLl9jb3JlID0gaW5pdENvcmUoe1xuICAgICAgICAgICAgYWJUZXN0U3dpdGNoZXMsXG4gICAgICAgICAgICBhcnJheU9mVGVzdE9iamVjdHMsXG4gICAgICAgICAgICBmb3JjZWRUZXN0RXhjZXB0aW9uLFxuICAgICAgICAgICAgZm9yY2VkVGVzdFZhcmlhbnRzLFxuICAgICAgICAgICAgbXZ0SWQsXG4gICAgICAgICAgICBtdnRNYXhWYWx1ZSxcbiAgICAgICAgICAgIHBhZ2VJc1NlbnNpdGl2ZVxuICAgICAgICB9KTtcbiAgICAgICAgdGhpcy5fb3BoYW4gPSBpbml0T3BoYW4oe1xuICAgICAgICAgICAgZXJyb3JSZXBvcnRlcixcbiAgICAgICAgICAgIG9waGFuUmVjb3JkLFxuICAgICAgICAgICAgc2VydmVyU2lkZVRlc3RzXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvLyBDb3JlQVBJXG4gICAgZ2V0IGFsbFJ1bm5hYmxlVGVzdHMoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jb3JlLmFsbFJ1bm5hYmxlVGVzdHM7XG4gICAgfVxuICAgIGdldCBmaXJzdFJ1bm5hYmxlVGVzdCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvcmUuZmlyc3RSdW5uYWJsZVRlc3Q7XG4gICAgfVxuICAgIGdldCBydW5uYWJsZVRlc3QoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9jb3JlLnJ1bm5hYmxlVGVzdDtcbiAgICB9XG4gICAgZ2V0IGlzVXNlckluVmFyaWFudCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2NvcmUuaXNVc2VySW5WYXJpYW50O1xuICAgIH1cbiAgICAvLyBPcGhhbkFQSVxuICAgIGdldCByZWdpc3RlckNvbXBsZXRlRXZlbnRzKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fb3BoYW4ucmVnaXN0ZXJDb21wbGV0ZUV2ZW50cztcbiAgICB9XG4gICAgZ2V0IHJlZ2lzdGVySW1wcmVzc2lvbkV2ZW50cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX29waGFuLnJlZ2lzdGVySW1wcmVzc2lvbkV2ZW50cztcbiAgICB9XG4gICAgZ2V0IHRyYWNrQUJUZXN0cygpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX29waGFuLnRyYWNrQUJUZXN0cztcbiAgICB9XG59XG5leHBvcnQgeyBBQiB9O1xuIiwiaW1wb3J0IHsgaXNFeHBpcmVkIH0gZnJvbSAnLi90aW1lLmpzJztcbmNvbnN0IGluaXRDb3JlID0gKHsgbXZ0TWF4VmFsdWUgPSAxZTYsIG12dElkLCBwYWdlSXNTZW5zaXRpdmUsIGFiVGVzdFN3aXRjaGVzLCBmb3JjZWRUZXN0VmFyaWFudHMsIGZvcmNlZFRlc3RFeGNlcHRpb24sIGFycmF5T2ZUZXN0T2JqZWN0cyA9IFtdIH0pID0+IHtcbiAgICBjb25zdCB2YXJpYW50Q2FuQmVSdW4gPSAodmFyaWFudCkgPT4ge1xuICAgICAgICBjb25zdCBpc0luVGVzdCA9IHZhcmlhbnQuaWQgIT09IFwibm90aW50ZXN0XCI7XG4gICAgICAgIGlmICh2YXJpYW50LmNhblJ1bikge1xuICAgICAgICAgICAgcmV0dXJuIHZhcmlhbnQuY2FuUnVuKCkgJiYgaXNJblRlc3Q7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICByZXR1cm4gaXNJblRlc3Q7XG4gICAgICAgIH1cbiAgICB9O1xuICAgIGNvbnN0IHRlc3RDYW5CZVJ1biA9ICh0ZXN0KSA9PiB7XG4gICAgICAgIGNvbnN0IGV4cGlyZWQgPSBpc0V4cGlyZWQodGVzdC5leHBpcnkpO1xuICAgICAgICBjb25zdCB0ZXN0U2hvdWxkU2hvd0ZvclNlbnNpdGl2ZSA9ICEhdGVzdC5zaG93Rm9yU2Vuc2l0aXZlO1xuICAgICAgICBjb25zdCBpc1Rlc3RPbiA9IGFiVGVzdFN3aXRjaGVzW2BhYiR7dGVzdC5pZH1gXSAmJiAhIWFiVGVzdFN3aXRjaGVzW2BhYiR7dGVzdC5pZH1gXTtcbiAgICAgICAgY29uc3QgY2FuVGVzdEJlUnVuID0gdGVzdC5jYW5SdW4oKTtcbiAgICAgICAgcmV0dXJuIChwYWdlSXNTZW5zaXRpdmUgPyB0ZXN0U2hvdWxkU2hvd0ZvclNlbnNpdGl2ZSA6IHRydWUpICYmICEhaXNUZXN0T24gJiYgIWV4cGlyZWQgJiYgY2FuVGVzdEJlUnVuO1xuICAgIH07XG4gICAgY29uc3QgY29tcHV0ZVZhcmlhbnRGcm9tTXZ0Q29va2llID0gKHRlc3QpID0+IHtcbiAgICAgICAgY29uc3Qgc21hbGxlc3RUZXN0SWQgPSBtdnRNYXhWYWx1ZSAqIHRlc3QuYXVkaWVuY2VPZmZzZXQ7XG4gICAgICAgIGNvbnN0IGxhcmdlc3RUZXN0SWQgPSBzbWFsbGVzdFRlc3RJZCArIG12dE1heFZhbHVlICogdGVzdC5hdWRpZW5jZTtcbiAgICAgICAgaWYgKG12dElkICYmIG12dElkID4gc21hbGxlc3RUZXN0SWQgJiYgbXZ0SWQgPD0gbGFyZ2VzdFRlc3RJZCkge1xuICAgICAgICAgICAgcmV0dXJuIHRlc3QudmFyaWFudHNbbXZ0SWQgJSB0ZXN0LnZhcmlhbnRzLmxlbmd0aF0gPz8gbnVsbDtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9O1xuICAgIGNvbnN0IGdldEZvcmNlZFRlc3RWYXJpYW50ID0gKHRlc3QsIGZvcmNlZFRlc3RWYXJpYW50czIpID0+IHtcbiAgICAgICAgY29uc3QgdGVzdElkID0gdGVzdC5pZDtcbiAgICAgICAgY29uc3QgZ2V0VmFyaWFudEZyb21JZHMgPSAodGVzdDIsIHZhcmlhbnRJZCkgPT4gdGVzdDIudmFyaWFudHMuZmluZCgodmFyaWFudCkgPT4gdmFyaWFudC5pZCA9PT0gdmFyaWFudElkKSA/PyBmYWxzZTtcbiAgICAgICAgY29uc3QgZm9yY2VkVGVzdCA9IGZvcmNlZFRlc3RWYXJpYW50czI/Llt0ZXN0SWRdPy52YXJpYW50O1xuICAgICAgICByZXR1cm4gZm9yY2VkVGVzdCA/IGdldFZhcmlhbnRGcm9tSWRzKHRlc3QsIGZvcmNlZFRlc3QpIDogZmFsc2U7XG4gICAgfTtcbiAgICBjb25zdCBydW5uYWJsZVRlc3QgPSAodGVzdCkgPT4ge1xuICAgICAgICBjb25zdCBmcm9tQ29va2llID0gY29tcHV0ZVZhcmlhbnRGcm9tTXZ0Q29va2llKHRlc3QpO1xuICAgICAgICBjb25zdCB2YXJpYW50RnJvbUZvcmNlZFRlc3QgPSBnZXRGb3JjZWRUZXN0VmFyaWFudCh0ZXN0LCBmb3JjZWRUZXN0VmFyaWFudHMpO1xuICAgICAgICBjb25zdCBmb3JjZWRPdXRPZlRlc3QgPSBmb3JjZWRUZXN0RXhjZXB0aW9uID09PSB0ZXN0LmlkO1xuICAgICAgICBjb25zdCB2YXJpYW50VG9SdW4gPSB2YXJpYW50RnJvbUZvcmNlZFRlc3QgfHwgZnJvbUNvb2tpZTtcbiAgICAgICAgaWYgKCFmb3JjZWRPdXRPZlRlc3QgJiYgKHZhcmlhbnRGcm9tRm9yY2VkVGVzdCB8fCB0ZXN0Q2FuQmVSdW4odGVzdCkpICYmIC8vIFdlIGlnbm9yZSB0aGUgdGVzdCdzIGNhblJ1biBpZiB0aGUgdGVzdCBpcyBmb3JjZWRcbiAgICAgICAgICAgIHZhcmlhbnRUb1J1biAmJiAodmFyaWFudEZyb21Gb3JjZWRUZXN0IHx8IHZhcmlhbnRDYW5CZVJ1bih2YXJpYW50VG9SdW4pKSkge1xuICAgICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgICAgICAuLi50ZXN0LFxuICAgICAgICAgICAgICAgIHZhcmlhbnRUb1J1blxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICB9O1xuICAgIGNvbnN0IGFsbFJ1bm5hYmxlVGVzdHMgPSAodGVzdHMpID0+IHRlc3RzLnJlZHVjZSgocHJldiwgY3VycmVudFZhbHVlKSA9PiB7XG4gICAgICAgIGNvbnN0IHJ0ID0gcnVubmFibGVUZXN0KGN1cnJlbnRWYWx1ZSk7XG4gICAgICAgIHJldHVybiBydCA/IFsuLi5wcmV2LCBydF0gOiBwcmV2O1xuICAgIH0sIFtdKTtcbiAgICBjb25zdCBmaXJzdFJ1bm5hYmxlVGVzdCA9ICh0ZXN0cykgPT4gdGVzdHMubWFwKCh0ZXN0KSA9PiBydW5uYWJsZVRlc3QodGVzdCkpLmZpbmQoKHJ0KSA9PiBydCAhPT0gbnVsbCkgPz8gbnVsbDtcbiAgICBjb25zdCBpc1VzZXJJblZhcmlhbnQgPSAodGVzdElkLCB2YXJpYW50SWQpID0+IGFsbFJ1bm5hYmxlVGVzdHMoYXJyYXlPZlRlc3RPYmplY3RzKS5zb21lKChydW5uYWJsZVRlc3QyKSA9PiB7XG4gICAgICAgIHJldHVybiBydW5uYWJsZVRlc3QyLmlkID09PSB0ZXN0SWQgJiYgcnVubmFibGVUZXN0Mi52YXJpYW50VG9SdW4uaWQgPT09IHZhcmlhbnRJZDtcbiAgICB9KTtcbiAgICByZXR1cm4ge1xuICAgICAgICBhbGxSdW5uYWJsZVRlc3RzLFxuICAgICAgICBydW5uYWJsZVRlc3QsXG4gICAgICAgIGZpcnN0UnVubmFibGVUZXN0LFxuICAgICAgICBpc1VzZXJJblZhcmlhbnRcbiAgICB9O1xufTtcbmV4cG9ydCB7IGluaXRDb3JlIH07XG4iLCJjb25zdCBzdWJtaXQgPSAocGF5bG9hZCwgb3BoYW5SZWNvcmQpID0+IG9waGFuUmVjb3JkKHtcbiAgICBhYlRlc3RSZWdpc3RlcjogcGF5bG9hZFxufSk7XG5jb25zdCBtYWtlQUJFdmVudCA9ICh2YXJpYW50LCBjb21wbGV0ZSkgPT4ge1xuICAgIGNvbnN0IGV2ZW50ID0ge1xuICAgICAgICB2YXJpYW50TmFtZTogdmFyaWFudC5pZCxcbiAgICAgICAgY29tcGxldGVcbiAgICB9O1xuICAgIGlmICh2YXJpYW50LmNhbXBhaWduQ29kZSkge1xuICAgICAgICBldmVudC5jYW1wYWlnbkNvZGVzID0gW3ZhcmlhbnQuY2FtcGFpZ25Db2RlXTtcbiAgICB9XG4gICAgcmV0dXJuIGV2ZW50O1xufTtcbmNvbnN0IGRlZmVyc0ltcHJlc3Npb24gPSAodGVzdCkgPT4gdGVzdC52YXJpYW50cy5ldmVyeSgodmFyaWFudCkgPT4gdHlwZW9mIHZhcmlhbnQuaW1wcmVzc2lvbiA9PT0gXCJmdW5jdGlvblwiKTtcbmNvbnN0IGJ1aWxkT3BoYW5TdWJtaXR0ZXIgPSAodGVzdCwgdmFyaWFudCwgY29tcGxldGUsIG9waGFuUmVjb3JkKSA9PiB7XG4gICAgY29uc3QgZGF0YSA9IHtcbiAgICAgICAgW3Rlc3QuaWRdOiBtYWtlQUJFdmVudCh2YXJpYW50LCBjb21wbGV0ZSlcbiAgICB9O1xuICAgIHJldHVybiAoKSA9PiBzdWJtaXQoZGF0YSwgb3BoYW5SZWNvcmQpO1xufTtcbmNvbnN0IHJlZ2lzdGVyQ29tcGxldGVFdmVudCA9IChjb21wbGV0ZSwgZXJyb3JSZXBvcnRlciwgb3BoYW5SZWNvcmQpID0+ICh0ZXN0KSA9PiB7XG4gICAgY29uc3QgdmFyaWFudCA9IHRlc3QudmFyaWFudFRvUnVuO1xuICAgIGNvbnN0IGxpc3RlbmVyID0gY29tcGxldGUgPyB2YXJpYW50LnN1Y2Nlc3MgOiB2YXJpYW50LmltcHJlc3Npb247XG4gICAgaWYgKCFsaXN0ZW5lcikge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIHRyeSB7XG4gICAgICAgIGxpc3RlbmVyKGJ1aWxkT3BoYW5TdWJtaXR0ZXIodGVzdCwgdmFyaWFudCwgY29tcGxldGUsIG9waGFuUmVjb3JkKSk7XG4gICAgfVxuICAgIGNhdGNoIChlcnJvcikge1xuICAgICAgICBlcnJvclJlcG9ydGVyKGVycm9yKTtcbiAgICB9XG59O1xuY29uc3QgYnVpbGRPcGhhblBheWxvYWQgPSAodGVzdHMsIGVycm9yUmVwb3J0ZXIsIHNlcnZlclNpZGVUZXN0T2JqKSA9PiB7XG4gICAgdHJ5IHtcbiAgICAgICAgY29uc3QgbG9nID0ge307XG4gICAgICAgIGNvbnN0IHNlcnZlclNpZGVUZXN0cyA9IE9iamVjdC5rZXlzKHNlcnZlclNpZGVUZXN0T2JqKS5maWx0ZXIoKHRlc3QpID0+ICEhc2VydmVyU2lkZVRlc3RPYmpbdGVzdF0pO1xuICAgICAgICB0ZXN0cy5maWx0ZXIoKHRlc3QpID0+ICFkZWZlcnNJbXByZXNzaW9uKHRlc3QpKS5mb3JFYWNoKCh0ZXN0KSA9PiB7XG4gICAgICAgICAgICBsb2dbdGVzdC5pZF0gPSBtYWtlQUJFdmVudCh0ZXN0LnZhcmlhbnRUb1J1biwgZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgICAgc2VydmVyU2lkZVRlc3RzLmZvckVhY2goKHRlc3QpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHNlcnZlclNpZGVWYXJpYW50ID0ge1xuICAgICAgICAgICAgICAgIGlkOiBcImluVGVzdFwiLFxuICAgICAgICAgICAgICAgIHRlc3Q6ICgpID0+IHZvaWQgMFxuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIGxvZ1tgYWIke3Rlc3R9YF0gPSBtYWtlQUJFdmVudChzZXJ2ZXJTaWRlVmFyaWFudCwgZmFsc2UpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGxvZztcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGVycm9yUmVwb3J0ZXIoZXJyb3IpO1xuICAgICAgICByZXR1cm4ge307XG4gICAgfVxufTtcbmNvbnN0IGluaXRPcGhhbiA9ICh7IHNlcnZlclNpZGVUZXN0cywgZXJyb3JSZXBvcnRlciwgb3BoYW5SZWNvcmQgfSkgPT4gKHtcbiAgICByZWdpc3RlckNvbXBsZXRlRXZlbnRzOiAodGVzdHMpID0+IHRlc3RzLmZvckVhY2gocmVnaXN0ZXJDb21wbGV0ZUV2ZW50KHRydWUsIGVycm9yUmVwb3J0ZXIsIG9waGFuUmVjb3JkKSksXG4gICAgcmVnaXN0ZXJJbXByZXNzaW9uRXZlbnRzOiAodGVzdHMpID0+IHRlc3RzLmZpbHRlcihkZWZlcnNJbXByZXNzaW9uKS5mb3JFYWNoKHJlZ2lzdGVyQ29tcGxldGVFdmVudChmYWxzZSwgZXJyb3JSZXBvcnRlciwgb3BoYW5SZWNvcmQpKSxcbiAgICB0cmFja0FCVGVzdHM6ICh0ZXN0cykgPT4gc3VibWl0KGJ1aWxkT3BoYW5QYXlsb2FkKHRlc3RzLCBlcnJvclJlcG9ydGVyLCBzZXJ2ZXJTaWRlVGVzdHMpLCBvcGhhblJlY29yZClcbn0pO1xuZXhwb3J0IHsgaW5pdE9waGFuIH07XG4iLCJjb25zdCBpc0V4cGlyZWQgPSAodGVzdEV4cGlyeSkgPT4ge1xuICAgIGNvbnN0IGN1cnJlbnRUaW1lID0gKCAvKiBAX19QVVJFX18gKi9uZXcgRGF0ZSgpKS52YWx1ZU9mKCk7XG4gICAgY29uc3QgdGhlVGVzdEV4cGlyeSA9IG5ldyBEYXRlKHRlc3RFeHBpcnkpLnNldEhvdXJzKDIzLCA1OSwgNTksIDU5KTtcbiAgICByZXR1cm4gY3VycmVudFRpbWUgPiB0aGVUZXN0RXhwaXJ5O1xufTtcbmV4cG9ydCB7IGlzRXhwaXJlZCB9O1xuIiwiaW1wb3J0IHsgSWRlbnRpdHlBdXRoIH0gZnJvbSAnQGd1YXJkaWFuL2lkZW50aXR5LWF1dGgnO1xuaW1wb3J0IHsgaXNPbmVPZiB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmNvbnN0IHN0YWdlcyA9IFtcIlBST0RcIiwgXCJDT0RFXCIsIFwiREVWXCJdO1xuY29uc3QgaXNTdGFnZSA9IGlzT25lT2Yoc3RhZ2VzKTtcbmNvbnN0IGdldFN0YWdlID0gKGlzRGV2LCBzdGFnZSkgPT4gaXNEZXYgfHwgIWlzU3RhZ2Uoc3RhZ2UpID8gXCJERVZcIiA6IHN0YWdlO1xuY29uc3QgZ2V0SXNzdWVyID0gKHN0YWdlKSA9PiBzdGFnZSA9PT0gXCJQUk9EXCIgPyBcImh0dHBzOi8vcHJvZmlsZS50aGVndWFyZGlhbi5jb20vb2F1dGgyL2F1czN4Z2o1MjVqWVFSb3dsNDE3XCIgOiBcImh0dHBzOi8vcHJvZmlsZS5jb2RlLmRldi10aGVndWFyZGlhbi5jb20vb2F1dGgyL2F1czN2OWdsYTk1VG9qMEVFMHg3XCI7XG5jb25zdCBnZXRDbGllbnRJZCA9IChzdGFnZSkgPT4gc3RhZ2UgPT09IFwiUFJPRFwiID8gXCIwb2E3OW0xZm1nenJ0YUhjMTQxN1wiIDogXCIwb2E1M3g2azV3R1lYT0d6bTB4N1wiO1xuY29uc3QgZ2V0UmVkaXJlY3RVcmkgPSAoc3RhZ2UsIG9yaWdpbikgPT4ge1xuICAgIHN3aXRjaCAoc3RhZ2UpIHtcbiAgICAgICAgY2FzZSBcIlBST0RcIjpcbiAgICAgICAgICAgIGlmIChvcmlnaW4gPT09IFwiaHR0cHM6Ly9wcm9maWxlLnRoZWd1YXJkaWFuLmNvbVwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9wcm9maWxlLnRoZWd1YXJkaWFuLmNvbS9cIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBcImh0dHBzOi8vd3d3LnRoZWd1YXJkaWFuLmNvbS9cIjtcbiAgICAgICAgY2FzZSBcIkNPREVcIjpcbiAgICAgICAgICAgIGlmIChvcmlnaW4gPT09IFwiaHR0cHM6Ly9wcm9maWxlLmNvZGUuZGV2LXRoZWd1YXJkaWFuLmNvbVwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9wcm9maWxlLmNvZGUuZGV2LXRoZWd1YXJkaWFuLmNvbS9cIjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBcImh0dHBzOi8vbS5jb2RlLmRldi10aGVndWFyZGlhbi5jb20vXCI7XG4gICAgICAgIGNhc2UgXCJERVZcIjpcbiAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgIGlmIChvcmlnaW4gPT09IFwiaHR0cHM6Ly9yLnRoZWd1bG9jYWwuY29tXCIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gXCJodHRwczovL3IudGhlZ3Vsb2NhbC5jb20vXCI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAob3JpZ2luID09PSBcImh0dHBzOi8vbS50aGVndWxvY2FsLmNvbVwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIFwiaHR0cHM6Ly9tLnRoZWd1bG9jYWwuY29tL1wiO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIFwiaHR0cDovL2xvY2FsaG9zdDozMDMwL1wiO1xuICAgIH1cbn07XG5jb25zdCBnZXRJZGVudGl0eUF1dGggPSAoKSA9PiB7XG4gICAgdmFyIF9hO1xuICAgIGlmICghd2luZG93Lmd1YXJkaWFuKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcIndpbmRvdy5ndWFyZGlhbiBoYXMgbm90IHlldCBiZWVuIGluaXRpYWxpemVkXCIpO1xuICAgIH1cbiAgICBjb25zdCB7IGlzRGV2ID0gZmFsc2UsIHN0YWdlID0gXCJQUk9EXCIsIHN3aXRjaGVzIH0gPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnID8/IHt9O1xuICAgIGNvbnN0IHN0YWdlT3JEZXYgPSBnZXRTdGFnZShpc0Rldiwgc3RhZ2UpO1xuICAgIChfYSA9IHdpbmRvdy5ndWFyZGlhbikuaWRlbnRpdHlBdXRoID8/IChfYS5pZGVudGl0eUF1dGggPSBuZXcgSWRlbnRpdHlBdXRoKHtcbiAgICAgICAgaXNzdWVyOiBnZXRJc3N1ZXIoc3RhZ2VPckRldiksXG4gICAgICAgIGNsaWVudElkOiBnZXRDbGllbnRJZChzdGFnZU9yRGV2KSxcbiAgICAgICAgcmVkaXJlY3RVcmk6IGdldFJlZGlyZWN0VXJpKHN0YWdlT3JEZXYsIHdpbmRvdy5sb2NhdGlvbi5vcmlnaW4pLFxuICAgICAgICBpZENvb2tpZVNlc3Npb25SZWZyZXNoOiBzd2l0Y2hlcz8uaWRDb29raWVSZWZyZXNoID8/IGZhbHNlLFxuICAgICAgICBzY29wZXM6IFtcbiAgICAgICAgICAgIFwib3BlbmlkXCIsXG4gICAgICAgICAgICAvLyByZXF1aXJlZCBmb3Igb3BlbiBpZCBjb25uZWN0LCByZXR1cm5zIGFuIGlkIHRva2VuXG4gICAgICAgICAgICBcInByb2ZpbGVcIixcbiAgICAgICAgICAgIC8vIHBvcHVsYXRlcyB0aGUgaWQgdG9rZW4gd2l0aCBiYXNpYyBwcm9maWxlIGluZm9ybWF0aW9uXG4gICAgICAgICAgICBcImVtYWlsXCIsXG4gICAgICAgICAgICAvLyBwb3B1bGF0ZXMgdGhlIGlkIHRva2VuIHdpdGggdGhlIHVzZXIncyBlbWFpbCBhZGRyZXNzXG4gICAgICAgICAgICBcImd1YXJkaWFuLmRpc2N1c3Npb24tYXBpLnByaXZhdGUtcHJvZmlsZS5yZWFkLnNlbGZcIixcbiAgICAgICAgICAgIC8vIGFsbG93cyB0aGUgYWNjZXNzIHRva2VuIHRvIGJlIHVzZWQgdG8gbWFrZSByZXF1ZXN0cyB0byB0aGUgZGlzY3Vzc2lvbiBhcGkgdG8gcmVhZCB0aGUgdXNlcidzIHByb2ZpbGVcbiAgICAgICAgICAgIFwiZ3VhcmRpYW4uZGlzY3Vzc2lvbi1hcGkudXBkYXRlLnNlY3VyZVwiLFxuICAgICAgICAgICAgLy8gYWxsb3dzIHRoZSBhY2Nlc3MgdG9rZW4gdG8gYmUgdXNlZCB0byBtYWtlIHJlcXVlc3RzIHRvIHRoZSBkaXNjdXNzaW9uIGFwaSB0byBwb3N0IGNvbW1lbnRzLCB1cHZvdGUgZXRjXG4gICAgICAgICAgICBcImd1YXJkaWFuLmlkZW50aXR5LWFwaS5uZXdzbGV0dGVycy5yZWFkLnNlbGZcIixcbiAgICAgICAgICAgIC8vIGFsbG93cyB0aGUgYWNjZXNzIHRva2VuIHRvIGJlIHVzZWQgdG8gbWFrZSByZXF1ZXN0cyB0byB0aGUgaWRlbnRpdHkgYXBpIHRvIHJlYWQgdGhlIHVzZXIncyBuZXdzbGV0dGVyIHN1YnNjcmlwdGlvbnNcbiAgICAgICAgICAgIFwiZ3VhcmRpYW4uaWRlbnRpdHktYXBpLm5ld3NsZXR0ZXJzLnVwZGF0ZS5zZWxmXCIsXG4gICAgICAgICAgICAvLyBhbGxvd3MgdGhlIGFjY2VzcyB0b2tlbiB0byBiZSB1c2VkIHRvIG1ha2UgcmVxdWVzdHMgdG8gdGhlIGlkZW50aXR5IGFwaSB0byB1cGRhdGUgdGhlIHVzZXIncyBuZXdzbGV0dGVyIHN1YnNjcmlwdGlvbnNcbiAgICAgICAgICAgIFwiZ3VhcmRpYW4uaWRlbnRpdHktYXBpLnVzZXIudXNlcm5hbWUuY3JlYXRlLnNlbGYuc2VjdXJlXCIsXG4gICAgICAgICAgICAvLyBhbGxvd3MgdGhlIGFjY2VzcyB0b2tlbiB0byBzZXQgdGhlIHVzZXIncyB1c2VybmFtZVxuICAgICAgICAgICAgXCJndWFyZGlhbi5tZW1iZXJzLWRhdGEtYXBpLnJlYWQuc2VsZlwiLFxuICAgICAgICAgICAgLy8gYWxsb3dzIHRoZSBhY2Nlc3MgdG9rZW4gdG8gYmUgdXNlZCB0byBtYWtlIHJlcXVlc3RzIHRvIHRoZSBtZW1iZXJzIGRhdGEgYXBpIHRvIHJlYWQgdGhlIHVzZXIncyBtZW1iZXJzaGlwIHN0YXR1c1xuICAgICAgICAgICAgXCJpZF90b2tlbi5wcm9maWxlLnRoZWd1YXJkaWFuXCJcbiAgICAgICAgICAgIC8vIHBvcHVsYXRlcyB0aGUgaWQgdG9rZW4gd2l0aCBhcHBsaWNhdGlvbiBzcGVjaWZpYyBwcm9maWxlIGluZm9ybWF0aW9uXG4gICAgICAgIF1cbiAgICB9KSk7XG4gICAgcmV0dXJuIHdpbmRvdy5ndWFyZGlhbi5pZGVudGl0eUF1dGg7XG59O1xuZXhwb3J0IHsgZ2V0SWRlbnRpdHlBdXRoIH07XG4iLCJpbXBvcnQgeyBndWFyZCB9IGZyb20gJy4vZ3VhcmQuanMnO1xuY29uc3QgcHJvZmlsZVVybHMgPSBbXG4gICAgXCJodHRwczovL3Byb2ZpbGUudGhlZ3VhcmRpYW4uY29tXCIsXG4gICAgXCJodHRwczovL3Byb2ZpbGUuY29kZS5kZXYtdGhlZ3VhcmRpYW4uY29tXCIsXG4gICAgXCJodHRwczovL3Byb2ZpbGUudGhlZ3Vsb2NhbC5jb21cIlxuXTtcbmNvbnN0IGlzUHJvZmlsZVVybCA9IGd1YXJkKHByb2ZpbGVVcmxzKTtcbmV4cG9ydCB7IGlzUHJvZmlsZVVybCB9O1xuIiwiY29uc3QgZ3VhcmQgPSAoYXJyYXkpID0+ICh2YWx1ZSkgPT4gYXJyYXkuaW5jbHVkZXModmFsdWUpO1xuZXhwb3J0IHsgZ3VhcmQgfTtcbiIsInZhciBfX3R5cGVFcnJvciA9IChtc2cpID0+IHtcbiAgICB0aHJvdyBUeXBlRXJyb3IobXNnKTtcbn07XG52YXIgX19hY2Nlc3NDaGVjayA9IChvYmosIG1lbWJlciwgbXNnKSA9PiBtZW1iZXIuaGFzKG9iaikgfHwgX190eXBlRXJyb3IoXCJDYW5ub3QgXCIgKyBtc2cpO1xudmFyIF9fcHJpdmF0ZUdldCA9IChvYmosIG1lbWJlciwgZ2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJyZWFkIGZyb20gcHJpdmF0ZSBmaWVsZFwiKSwgZ2V0dGVyID8gZ2V0dGVyLmNhbGwob2JqKSA6IG1lbWJlci5nZXQob2JqKSk7XG52YXIgX19wcml2YXRlQWRkID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSkgPT4gbWVtYmVyLmhhcyhvYmopID8gX190eXBlRXJyb3IoXCJDYW5ub3QgYWRkIHRoZSBzYW1lIHByaXZhdGUgbWVtYmVyIG1vcmUgdGhhbiBvbmNlXCIpIDogbWVtYmVyIGluc3RhbmNlb2YgV2Vha1NldCA/IG1lbWJlci5hZGQob2JqKSA6IG1lbWJlci5zZXQob2JqLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlU2V0ID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSwgc2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJ3cml0ZSB0byBwcml2YXRlIGZpZWxkXCIpLCBtZW1iZXIuc2V0KG9iaiwgdmFsdWUpLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlTWV0aG9kID0gKG9iaiwgbWVtYmVyLCBtZXRob2QpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcImFjY2VzcyBwcml2YXRlIG1ldGhvZFwiKSwgbWV0aG9kKTtcbnZhciBfYXV0aFN0YXRlLCBfZW1pdHRlciwgX3Rva2VuTWFuYWdlciwgX0F1dGhTdGF0ZU1hbmFnZXJfaW5zdGFuY2VzLCB1cGRhdGVBdXRoU3RhdGVfZm47XG5jbGFzcyBBdXRoU3RhdGVNYW5hZ2VyIHtcbiAgICBjb25zdHJ1Y3RvcihlbWl0dGVyLCB0b2tlbk1hbmFnZXIpIHtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9BdXRoU3RhdGVNYW5hZ2VyX2luc3RhbmNlcyk7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfYXV0aFN0YXRlKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9lbWl0dGVyKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF90b2tlbk1hbmFnZXIpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX2VtaXR0ZXIsIGVtaXR0ZXIpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX3Rva2VuTWFuYWdlciwgdG9rZW5NYW5hZ2VyKTtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9hdXRoU3RhdGUsIHtcbiAgICAgICAgICAgIGFjY2Vzc1Rva2VuOiB2b2lkIDAsXG4gICAgICAgICAgICBpZFRva2VuOiB2b2lkIDAsXG4gICAgICAgICAgICBpc0F1dGhlbnRpY2F0ZWQ6IGZhbHNlXG4gICAgICAgIH0pO1xuICAgICAgICBfX3ByaXZhdGVNZXRob2QodGhpcywgX0F1dGhTdGF0ZU1hbmFnZXJfaW5zdGFuY2VzLCB1cGRhdGVBdXRoU3RhdGVfZm4pLmNhbGwodGhpcyk7XG4gICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfZW1pdHRlcikub24oXCJhZGRlZFwiLCAoKSA9PiB7XG4gICAgICAgICAgICBfX3ByaXZhdGVNZXRob2QodGhpcywgX0F1dGhTdGF0ZU1hbmFnZXJfaW5zdGFuY2VzLCB1cGRhdGVBdXRoU3RhdGVfZm4pLmNhbGwodGhpcyk7XG4gICAgICAgIH0pO1xuICAgICAgICBfX3ByaXZhdGVHZXQodGhpcywgX2VtaXR0ZXIpLm9uKFwicmVtb3ZlZFwiLCAoKSA9PiB7XG4gICAgICAgICAgICBfX3ByaXZhdGVNZXRob2QodGhpcywgX0F1dGhTdGF0ZU1hbmFnZXJfaW5zdGFuY2VzLCB1cGRhdGVBdXRoU3RhdGVfZm4pLmNhbGwodGhpcyk7XG4gICAgICAgIH0pO1xuICAgICAgICBfX3ByaXZhdGVHZXQodGhpcywgX2VtaXR0ZXIpLm9uKFwic3RvcmFnZVwiLCAoKSA9PiB7XG4gICAgICAgICAgICBfX3ByaXZhdGVNZXRob2QodGhpcywgX0F1dGhTdGF0ZU1hbmFnZXJfaW5zdGFuY2VzLCB1cGRhdGVBdXRoU3RhdGVfZm4pLmNhbGwodGhpcyk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAbmFtZSBnZXRBdXRoU3RhdGVcbiAgICAgKiBAZGVzY3JpcHRpb24gUmV0dXJucyB0aGUgY3VycmVudCBhdXRoIHN0YXRlXG4gICAgICogQHJldHVybnMgSWRlbnRpdHlBdXRoU3RhdGVcbiAgICAgKi9cbiAgICBnZXRBdXRoU3RhdGUoKSB7XG4gICAgICAgIHJldHVybiBfX3ByaXZhdGVHZXQodGhpcywgX2F1dGhTdGF0ZSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBuYW1lIHN1YnNjcmliZVxuICAgICAqIEBkZXNjcmlwdGlvbiBTdWJzY3JpYmVzIHRvIGF1dGggc3RhdGUgY2hhbmdlc1xuICAgICAqIEBwYXJhbSBoYW5kbGVyXHQtIFRoZSBFdmVudENhbGxiYWNrIHRvIHVzZSB0byBzdWJzY3JpYmVcbiAgICAgKi9cbiAgICBzdWJzY3JpYmUoaGFuZGxlcikge1xuICAgICAgICBfX3ByaXZhdGVHZXQodGhpcywgX2VtaXR0ZXIpLm9uKFwiYXV0aFN0YXRlQ2hhbmdlXCIsIGhhbmRsZXIpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAbmFtZSB1bnN1YnNjcmliZVxuICAgICAqIEBkZXNjcmlwdGlvbiBVbnN1YnNjcmliZXMgZnJvbSBhdXRoIHN0YXRlIGNoYW5nZXNcbiAgICAgKiBAcGFyYW0gaGFuZGxlclx0LSBUaGUgRXZlbnRDYWxsYmFjayB0byB1c2VkIHRvIHN1YnNjcmliZVxuICAgICAqL1xuICAgIHVuc3Vic2NyaWJlKGhhbmRsZXIpIHtcbiAgICAgICAgX19wcml2YXRlR2V0KHRoaXMsIF9lbWl0dGVyKS5vZmYoXCJhdXRoU3RhdGVDaGFuZ2VcIiwgaGFuZGxlcik7XG4gICAgfVxufVxuX2F1dGhTdGF0ZSA9IG5ldyBXZWFrTWFwKCk7XG5fZW1pdHRlciA9IG5ldyBXZWFrTWFwKCk7XG5fdG9rZW5NYW5hZ2VyID0gbmV3IFdlYWtNYXAoKTtcbl9BdXRoU3RhdGVNYW5hZ2VyX2luc3RhbmNlcyA9IG5ldyBXZWFrU2V0KCk7XG4vKipcbiAqIEBuYW1lIHVwZGF0ZUF1dGhTdGF0ZVxuICogQGRlc2NyaXB0aW9uIFVwZGF0ZXMgdGhlIGF1dGggc3RhdGUgYmFzZWQgb24gdGhlIHRva2VucyBpbiBzdG9yYWdlXG4gKiBAcmV0dXJucyB2b2lkXG4gKi9cbnVwZGF0ZUF1dGhTdGF0ZV9mbiA9IGZ1bmN0aW9uICgpIHtcbiAgICBjb25zdCB0b2tlbnMgPSBfX3ByaXZhdGVHZXQodGhpcywgX3Rva2VuTWFuYWdlcikuZ2V0VG9rZW5zU3luYygpO1xuICAgIGlmICh0b2tlbnMpIHtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9hdXRoU3RhdGUsIHtcbiAgICAgICAgICAgIGFjY2Vzc1Rva2VuOiB0b2tlbnMuYWNjZXNzVG9rZW4sXG4gICAgICAgICAgICBpZFRva2VuOiB0b2tlbnMuaWRUb2tlbixcbiAgICAgICAgICAgIGlzQXV0aGVudGljYXRlZDogdHJ1ZVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfYXV0aFN0YXRlLCB7XG4gICAgICAgICAgICBhY2Nlc3NUb2tlbjogdm9pZCAwLFxuICAgICAgICAgICAgaWRUb2tlbjogdm9pZCAwLFxuICAgICAgICAgICAgaXNBdXRoZW50aWNhdGVkOiBmYWxzZVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgX19wcml2YXRlR2V0KHRoaXMsIF9lbWl0dGVyKS5lbWl0KFwiYXV0aFN0YXRlQ2hhbmdlXCIsIF9fcHJpdmF0ZUdldCh0aGlzLCBfYXV0aFN0YXRlKSk7XG59O1xuZXhwb3J0IHsgQXV0aFN0YXRlTWFuYWdlciB9O1xuIiwiaW1wb3J0IHsgZ2V0Q29va2llIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX3R5cGVFcnJvciA9IChtc2cpID0+IHtcbiAgICB0aHJvdyBUeXBlRXJyb3IobXNnKTtcbn07XG52YXIgX19kZWZOb3JtYWxQcm9wID0gKG9iaiwga2V5LCB2YWx1ZSkgPT4ga2V5IGluIG9iaiA/IF9fZGVmUHJvcChvYmosIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlLCB2YWx1ZSB9KSA6IG9ialtrZXldID0gdmFsdWU7XG52YXIgX19wdWJsaWNGaWVsZCA9IChvYmosIGtleSwgdmFsdWUpID0+IF9fZGVmTm9ybWFsUHJvcChvYmosIGtleSArIFwiXCIsIHZhbHVlKTtcbnZhciBfX2FjY2Vzc0NoZWNrID0gKG9iaiwgbWVtYmVyLCBtc2cpID0+IG1lbWJlci5oYXMob2JqKSB8fCBfX3R5cGVFcnJvcihcIkNhbm5vdCBcIiArIG1zZyk7XG52YXIgX19wcml2YXRlR2V0ID0gKG9iaiwgbWVtYmVyLCBnZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcInJlYWQgZnJvbSBwcml2YXRlIGZpZWxkXCIpLCBnZXR0ZXIgPyBnZXR0ZXIuY2FsbChvYmopIDogbWVtYmVyLmdldChvYmopKTtcbnZhciBfX3ByaXZhdGVBZGQgPSAob2JqLCBtZW1iZXIsIHZhbHVlKSA9PiBtZW1iZXIuaGFzKG9iaikgPyBfX3R5cGVFcnJvcihcIkNhbm5vdCBhZGQgdGhlIHNhbWUgcHJpdmF0ZSBtZW1iZXIgbW9yZSB0aGFuIG9uY2VcIikgOiBtZW1iZXIgaW5zdGFuY2VvZiBXZWFrU2V0ID8gbWVtYmVyLmFkZChvYmopIDogbWVtYmVyLnNldChvYmosIHZhbHVlKTtcbnZhciBfX3ByaXZhdGVTZXQgPSAob2JqLCBtZW1iZXIsIHZhbHVlLCBzZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcIndyaXRlIHRvIHByaXZhdGUgZmllbGRcIiksIG1lbWJlci5zZXQob2JqLCB2YWx1ZSksIHZhbHVlKTtcbnZhciBfX3ByaXZhdGVNZXRob2QgPSAob2JqLCBtZW1iZXIsIG1ldGhvZCkgPT4gKF9fYWNjZXNzQ2hlY2sob2JqLCBtZW1iZXIsIFwiYWNjZXNzIHByaXZhdGUgbWV0aG9kXCIpLCBtZXRob2QpO1xudmFyIF9vcHRpb25zLCBfZW1pdHRlciwgX2F1dGhTdGF0ZU1hbmFnZXIsIF9yZW5ld0F0VGltZW91dElkLCBfQXV0b1JlbmV3U2VydmljZV9pbnN0YW5jZXMsIGNsZWFyUmVuZXdBdFRpbWVvdXRfZm4sIHNldFJlbmV3QXRUaW1lb3V0X2ZuLCBoYW5kbGVBdXRoU3RhdGVDaGFuZ2VfZm47XG5jbGFzcyBBdXRvUmVuZXdTZXJ2aWNlIHtcbiAgICBjb25zdHJ1Y3RvcihvcHRpb25zLCBlbWl0dGVyLCBhdXRoU3RhdGVNYW5hZ2VyKSB7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfQXV0b1JlbmV3U2VydmljZV9pbnN0YW5jZXMpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX29wdGlvbnMpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2VtaXR0ZXIpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2F1dGhTdGF0ZU1hbmFnZXIpO1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwic3RhcnRlZFwiLCBmYWxzZSk7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfcmVuZXdBdFRpbWVvdXRJZCk7XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfb3B0aW9ucywgb3B0aW9ucyk7XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfZW1pdHRlciwgZW1pdHRlcik7XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfYXV0aFN0YXRlTWFuYWdlciwgYXV0aFN0YXRlTWFuYWdlcik7XG4gICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfZW1pdHRlcikub24oXCJzdG9yYWdlXCIsICgpID0+IHtcbiAgICAgICAgICAgIF9fcHJpdmF0ZU1ldGhvZCh0aGlzLCBfQXV0b1JlbmV3U2VydmljZV9pbnN0YW5jZXMsIGNsZWFyUmVuZXdBdFRpbWVvdXRfZm4pLmNhbGwodGhpcyk7XG4gICAgICAgICAgICBfX3ByaXZhdGVNZXRob2QodGhpcywgX0F1dG9SZW5ld1NlcnZpY2VfaW5zdGFuY2VzLCBoYW5kbGVBdXRoU3RhdGVDaGFuZ2VfZm4pLmNhbGwodGhpcyk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAbmFtZSBzdGFydFxuICAgICAqIEBkZXNjcmlwdGlvbiBTdGFydHMgdGhlIGF1dG8gcmVuZXdhbCBzZXJ2aWNlIGlmIGF1dG9SZW5ldyBpcyBlbmFibGVkXG4gICAgICovXG4gICAgc3RhcnQoKSB7XG4gICAgICAgIGlmIChfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLmF1dG9SZW5ldyAmJiAhdGhpcy5zdGFydGVkKSB7XG4gICAgICAgICAgICB0aGlzLnN0YXJ0ZWQgPSB0cnVlO1xuICAgICAgICAgICAgX19wcml2YXRlR2V0KHRoaXMsIF9lbWl0dGVyKS5vbihcImF1dGhTdGF0ZUNoYW5nZVwiLCAoc3RhdGUpID0+IF9fcHJpdmF0ZU1ldGhvZCh0aGlzLCBfQXV0b1JlbmV3U2VydmljZV9pbnN0YW5jZXMsIGhhbmRsZUF1dGhTdGF0ZUNoYW5nZV9mbikuY2FsbCh0aGlzLCBzdGF0ZSkpO1xuICAgICAgICAgICAgX19wcml2YXRlTWV0aG9kKHRoaXMsIF9BdXRvUmVuZXdTZXJ2aWNlX2luc3RhbmNlcywgaGFuZGxlQXV0aFN0YXRlQ2hhbmdlX2ZuKS5jYWxsKHRoaXMpO1xuICAgICAgICB9XG4gICAgfVxufVxuX29wdGlvbnMgPSBuZXcgV2Vha01hcCgpO1xuX2VtaXR0ZXIgPSBuZXcgV2Vha01hcCgpO1xuX2F1dGhTdGF0ZU1hbmFnZXIgPSBuZXcgV2Vha01hcCgpO1xuX3JlbmV3QXRUaW1lb3V0SWQgPSBuZXcgV2Vha01hcCgpO1xuX0F1dG9SZW5ld1NlcnZpY2VfaW5zdGFuY2VzID0gbmV3IFdlYWtTZXQoKTtcbi8qKlxuICogQG5hbWUgY2xlYXJSZW5ld0F0VGltZW91dFxuICogQGRlc2NyaXB0aW9uIENsZWFycyB0aGUgdGltZW91dCBmb3IgcmVuZXdpbmcgdGhlIGFjY2VzcyB0b2tlbiwgaWYgaXQgZXhpc3RzXG4gKi9cbmNsZWFyUmVuZXdBdFRpbWVvdXRfZm4gPSBmdW5jdGlvbiAoKSB7XG4gICAgaWYgKF9fcHJpdmF0ZUdldCh0aGlzLCBfcmVuZXdBdFRpbWVvdXRJZCkgIT09IHZvaWQgMCkge1xuICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KF9fcHJpdmF0ZUdldCh0aGlzLCBfcmVuZXdBdFRpbWVvdXRJZCkpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX3JlbmV3QXRUaW1lb3V0SWQsIHZvaWQgMCk7XG4gICAgfVxufTtcbi8qKlxuICogQG5hbWUgc2V0UmVuZXdBdFRpbWVvdXRcbiAqIEBkZXNjcmlwdGlvbiBTZXRzIHRoZSB0aW1lb3V0IGZvciByZW5ld2luZyB0aGUgYWNjZXNzIHRva2VuIGJhc2VkIG9uIHRoZSBleHBpcnkgdGltZSBhbmQgdGhlIGdyYWNlIHBlcmlvZFxuICogQHBhcmFtIGV4cGlyZXNBdCBUaGUgdGltZSBhdCB3aGljaCB0aGUgYWNjZXNzIHRva2VuIGV4cGlyZXNcbiAqIEByZXR1cm5zIFRoZSB0aW1lb3V0IGlkXG4gKi9cbnNldFJlbmV3QXRUaW1lb3V0X2ZuID0gZnVuY3Rpb24gKGV4cGlyZXNBdCkge1xuICAgIGNvbnN0IG5vdyA9IERhdGUubm93KCk7XG4gICAgY29uc3QgcmVuZXdBdCA9IChleHBpcmVzQXQgLSBfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLnJlbmV3R3JhY2VQZXJpb2QpICogMWUzO1xuICAgIGNvbnN0IHRpbWVvdXQgPSByZW5ld0F0IC0gbm93O1xuICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfcmVuZXdBdFRpbWVvdXRJZCwgd2luZG93LnNldFRpbWVvdXQoKCkgPT4ge1xuICAgICAgICBpZiAod2luZG93LmRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gXCJoaWRkZW5cIikge1xuICAgICAgICAgICAgd2luZG93LmRvY3VtZW50LmFkZEV2ZW50TGlzdGVuZXIoXCJ2aXNpYmlsaXR5Y2hhbmdlXCIsICgpID0+IHtcbiAgICAgICAgICAgICAgICBpZiAod2luZG93LmRvY3VtZW50LnZpc2liaWxpdHlTdGF0ZSA9PT0gXCJ2aXNpYmxlXCIpIHtcbiAgICAgICAgICAgICAgICAgICAgY29uc3QgYXV0aFN0YXRlID0gX19wcml2YXRlR2V0KHRoaXMsIF9hdXRoU3RhdGVNYW5hZ2VyKS5nZXRBdXRoU3RhdGUoKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGF1dGhTdGF0ZS5pc0F1dGhlbnRpY2F0ZWQgJiYgYXV0aFN0YXRlLmFjY2Vzc1Rva2VuLmV4cGlyZXNBdCAtIF9fcHJpdmF0ZUdldCh0aGlzLCBfb3B0aW9ucykucmVuZXdHcmFjZVBlcmlvZCA8IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDFlMykpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfZW1pdHRlcikuZW1pdChcInJlbmV3XCIpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGlmICghYXV0aFN0YXRlLmlzQXV0aGVudGljYXRlZCAmJiAhIWdldENvb2tpZSh7IG5hbWU6IFwiR1VfVVwiLCBzaG91bGRNZW1vaXplOiB0cnVlIH0pKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBfX3ByaXZhdGVHZXQodGhpcywgX2VtaXR0ZXIpLmVtaXQoXCJyZW5ld1wiKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICBvbmNlOiB0cnVlXG4gICAgICAgICAgICAgICAgLy8gb25seSBsaXN0ZW4gZm9yIHRoZSBldmVudCBvbmNlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfZW1pdHRlcikuZW1pdChcInJlbmV3XCIpO1xuICAgICAgICB9XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfcmVuZXdBdFRpbWVvdXRJZCwgdm9pZCAwKTtcbiAgICB9LCB0aW1lb3V0KSk7XG59O1xuLyoqXG4gKiBAbmFtZSBoYW5kbGVBdXRoU3RhdGVDaGFuZ2VcbiAqIEBkZXNjcmlwdGlvbiBMaXN0ZW5zIGZvciBjaGFuZ2VzIHRvIHRoZSBhdXRoIHN0YXRlIGFuZCBzZXRzIHRoZSB0aW1lb3V0IGZvciByZW5ld2luZyB0aGUgYWNjZXNzIHRva2VuIGlmIHJlcXVpcmVkXG4gKiBAcGFyYW0gc3RhdGUgLSBUaGUgSWRlbnRpdHlBdXRoU3RhdGVcbiAqL1xuaGFuZGxlQXV0aFN0YXRlQ2hhbmdlX2ZuID0gZnVuY3Rpb24gKHN0YXRlKSB7XG4gICAgX19wcml2YXRlTWV0aG9kKHRoaXMsIF9BdXRvUmVuZXdTZXJ2aWNlX2luc3RhbmNlcywgY2xlYXJSZW5ld0F0VGltZW91dF9mbikuY2FsbCh0aGlzKTtcbiAgICBjb25zdCBhdXRoU3RhdGUgPSBzdGF0ZSA/PyBfX3ByaXZhdGVHZXQodGhpcywgX2F1dGhTdGF0ZU1hbmFnZXIpLmdldEF1dGhTdGF0ZSgpO1xuICAgIGlmIChhdXRoU3RhdGUuaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgICAgIF9fcHJpdmF0ZU1ldGhvZCh0aGlzLCBfQXV0b1JlbmV3U2VydmljZV9pbnN0YW5jZXMsIHNldFJlbmV3QXRUaW1lb3V0X2ZuKS5jYWxsKHRoaXMsIGF1dGhTdGF0ZS5hY2Nlc3NUb2tlbi5leHBpcmVzQXQpO1xuICAgIH1cbn07XG5leHBvcnQgeyBBdXRvUmVuZXdTZXJ2aWNlIH07XG4iLCJpbXBvcnQgeyBzdG9yYWdlLCBnZXRDb29raWUgfSBmcm9tICdAZ3VhcmRpYW4vbGlicyc7XG5pbXBvcnQgeyBpc1Byb2ZpbGVVcmwgfSBmcm9tICcuL0B0eXBlcy9PQXV0aC5qcyc7XG5pbXBvcnQgeyBPQXV0aEVycm9yIH0gZnJvbSAnLi9lcnJvci5qcyc7XG5jb25zdCBkYXlzMzBJbk1pbGxpcyA9IDFlMyAqIDYwICogNjAgKiAyNCAqIDMwO1xuY29uc3QgcmVkaXJlY3RUb1JlZnJlc2hFbmRwb2ludCA9IChwcm9maWxlVXJsLCByZXR1cm5VcmwpID0+IHtcbiAgICBjb25zdCBlbmRwb2ludCA9IGAke3Byb2ZpbGVVcmx9L3NpZ25pbi9yZWZyZXNoP3JldHVyblVybD0ke3JldHVyblVybH1gO1xuICAgIHdpbmRvdy5sb2NhdGlvbi5yZXBsYWNlKGVuZHBvaW50KTtcbn07XG5jb25zdCBzaG91bGRSZWZyZXNoQ29va2llID0gKGxhc3RSZWZyZXNoLCBjdXJyZW50VGltZSkgPT4ge1xuICAgIGNvbnN0IGxhc3RSZWZyZXNoSXNWYWxpZCA9ICEhTnVtYmVyKGxhc3RSZWZyZXNoKTtcbiAgICBpZiAoIWxhc3RSZWZyZXNoSXNWYWxpZCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGN1cnJlbnRUaW1lIC0gTnVtYmVyKGxhc3RSZWZyZXNoKSA+IGRheXMzMEluTWlsbGlzO1xufTtcbmNvbnN0IGNvb2tpZVJlZnJlc2hJZlJlcXVpcmVkID0gKGVuYWJsZWQsIGlzc3VlcikgPT4ge1xuICAgIGNvbnN0IHByb2ZpbGVVcmwgPSBpc3N1ZXIuc3BsaXQoXCIvb2F1dGgyXCIpWzBdO1xuICAgIGlmICghaXNQcm9maWxlVXJsKHByb2ZpbGVVcmwpKSB7XG4gICAgICAgIHRocm93IG5ldyBPQXV0aEVycm9yKHtcbiAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfaXNzdWVyXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogYFRoZSBpc3N1ZXIsICR7aXNzdWVyfSwgZG9lcyBub3QgbWF0Y2ggdGhlIGV4cGVjdGVkIGZvcm1hdC5gXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBsYXN0UmVmcmVzaEtleSA9IFwiaWRlbnRpdHkubGFzdFJlZnJlc2hcIjtcbiAgICBpZiAoZW5hYmxlZCAmJiBzdG9yYWdlLmxvY2FsLmlzQXZhaWxhYmxlKCkgJiYgZ2V0Q29va2llKHsgbmFtZTogXCJHVV9VXCIsIHNob3VsZE1lbW9pemU6IHRydWUgfSkpIHtcbiAgICAgICAgY29uc3QgY3VycmVudFRpbWUgPSAoIC8qIEBfX1BVUkVfXyAqL25ldyBEYXRlKCkpLmdldFRpbWUoKTtcbiAgICAgICAgY29uc3QgbGFzdFJlZnJlc2ggPSBzdG9yYWdlLmxvY2FsLmdldChsYXN0UmVmcmVzaEtleSk7XG4gICAgICAgIGlmIChzaG91bGRSZWZyZXNoQ29va2llKGxhc3RSZWZyZXNoLCBjdXJyZW50VGltZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IG5ld0V4cGlyeSA9IGN1cnJlbnRUaW1lICsgZGF5czMwSW5NaWxsaXM7XG4gICAgICAgICAgICBzdG9yYWdlLmxvY2FsLnNldChsYXN0UmVmcmVzaEtleSwgY3VycmVudFRpbWUsIG5ld0V4cGlyeSk7XG4gICAgICAgICAgICByZWRpcmVjdFRvUmVmcmVzaEVuZHBvaW50KHByb2ZpbGVVcmwsIGVuY29kZVVSSUNvbXBvbmVudChkb2N1bWVudC5sb2NhdGlvbi5ocmVmKSk7XG4gICAgICAgIH1cbiAgICB9XG59O1xuZXhwb3J0IHsgY29va2llUmVmcmVzaElmUmVxdWlyZWQgfTtcbiIsImNvbnN0IGRlYzJoZXggPSAoZGVjKSA9PiB7XG4gICAgY29uc3QgaGV4ID0gZGVjLnRvU3RyaW5nKDE2KTtcbiAgICByZXR1cm4gXCIwXCIuc3Vic3RyaW5nKDAsIDIgLSBoZXgubGVuZ3RoKSArIGhleDtcbn07XG5jb25zdCBnZXRSYW5kb21TdHJpbmcgPSAobGVuZ3RoKSA9PiB7XG4gICAgY29uc3QgYXJyID0gbmV3IFVpbnQ4QXJyYXkoTWF0aC5jZWlsKGxlbmd0aCAvIDIpKTtcbiAgICB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhhcnIpO1xuICAgIGNvbnN0IHN0ciA9IEFycmF5LmZyb20oYXJyLCBkZWMyaGV4KS5qb2luKFwiXCIpO1xuICAgIHJldHVybiBzdHIuc2xpY2UoMCwgbGVuZ3RoKTtcbn07XG5jb25zdCBnZW5lcmF0ZVNoYTI1Nkhhc2ggPSBhc3luYyAoc3RyKSA9PiB7XG4gICAgY29uc3QgYnVmZmVyID0gbmV3IFRleHRFbmNvZGVyKCkuZW5jb2RlKHN0cik7XG4gICAgY29uc3QgaGFzaEJ1ZmZlciA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLmRpZ2VzdChcIlNIQS0yNTZcIiwgYnVmZmVyKTtcbiAgICBjb25zdCBoYXNoQXJyYXkgPSBBcnJheS5mcm9tKG5ldyBVaW50OEFycmF5KGhhc2hCdWZmZXIpKTtcbiAgICBjb25zdCBoYXNoID0gU3RyaW5nLmZyb21DaGFyQ29kZS5hcHBseShudWxsLCBuZXcgVWludDhBcnJheShoYXNoQXJyYXkpKTtcbiAgICByZXR1cm4gaGFzaDtcbn07XG5jb25zdCBnZW5lcmF0ZUNvZGVWZXJpZmllciA9ICgpID0+IGdldFJhbmRvbVN0cmluZygxMjgpO1xuY29uc3QgZ2VuZXJhdGVDb2RlQ2hhbGxlbmdlID0gYXN5bmMgKGNvZGVWZXJpZmllcikgPT4ge1xuICAgIGNvbnN0IGhhc2ggPSBhd2FpdCBnZW5lcmF0ZVNoYTI1Nkhhc2goY29kZVZlcmlmaWVyKTtcbiAgICBjb25zdCBiYXNlNjR1cmwgPSBiYXNlNjRVcmxFbmNvZGUoaGFzaCk7XG4gICAgcmV0dXJuIGJhc2U2NHVybDtcbn07XG5jb25zdCBiYXNlNjRVcmxUb1N0cmluZyA9IChiYXNlNjRVcmwpID0+IHtcbiAgICBsZXQgYmFzZTY0ID0gYmFzZTY0VXJsVG9CYXNlNjQoYmFzZTY0VXJsKTtcbiAgICBzd2l0Y2ggKGJhc2U2NC5sZW5ndGggJSA0KSB7XG4gICAgICAgIGNhc2UgMDpcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlIDI6XG4gICAgICAgICAgICBiYXNlNjQgKz0gXCI9PVwiO1xuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgMzpcbiAgICAgICAgICAgIGJhc2U2NCArPSBcIj1cIjtcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiTm90IGEgdmFsaWQgQmFzZTY0VXJsXCIpO1xuICAgIH1cbiAgICBjb25zdCB1dGY4c3RyID0gd2luZG93LmF0b2IoYmFzZTY0KTtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gZGVjb2RlVVJJQ29tcG9uZW50KHdpbmRvdy5lc2NhcGUodXRmOHN0cikpO1xuICAgIH1cbiAgICBjYXRjaCAoZSkge1xuICAgICAgICByZXR1cm4gdXRmOHN0cjtcbiAgICB9XG59O1xuY29uc3Qgc3RyaW5nVG9CdWZmZXIgPSAoc3RyKSA9PiB7XG4gICAgY29uc3QgYnVmZmVyID0gbmV3IFVpbnQ4QXJyYXkoc3RyLmxlbmd0aCk7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBzdHIubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgYnVmZmVyW2ldID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgfVxuICAgIHJldHVybiBidWZmZXI7XG59O1xuY29uc3QgYmFzZTY0VXJsVG9CYXNlNjQgPSAoYmFzZTY0VXJsKSA9PiBiYXNlNjRVcmwucmVwbGFjZSgvLS9nLCBcIitcIikucmVwbGFjZSgvXy9nLCBcIi9cIik7XG5jb25zdCBiYXNlNjRVcmxFbmNvZGUgPSAoc3RyKSA9PiB3aW5kb3cuYnRvYShzdHIpLnJlcGxhY2UoL1xcKy9nLCBcIi1cIikucmVwbGFjZSgvXFwvL2csIFwiX1wiKS5yZXBsYWNlKC89L2csIFwiXCIpO1xuZXhwb3J0IHsgYmFzZTY0VXJsRW5jb2RlLCBiYXNlNjRVcmxUb0Jhc2U2NCwgYmFzZTY0VXJsVG9TdHJpbmcsIGRlYzJoZXgsIGdlbmVyYXRlQ29kZUNoYWxsZW5nZSwgZ2VuZXJhdGVDb2RlVmVyaWZpZXIsIGdlbmVyYXRlU2hhMjU2SGFzaCwgZ2V0UmFuZG9tU3RyaW5nLCBzdHJpbmdUb0J1ZmZlciB9O1xuIiwidmFyIF9fdHlwZUVycm9yID0gKG1zZykgPT4ge1xuICAgIHRocm93IFR5cGVFcnJvcihtc2cpO1xufTtcbnZhciBfX2FjY2Vzc0NoZWNrID0gKG9iaiwgbWVtYmVyLCBtc2cpID0+IG1lbWJlci5oYXMob2JqKSB8fCBfX3R5cGVFcnJvcihcIkNhbm5vdCBcIiArIG1zZyk7XG52YXIgX19wcml2YXRlR2V0ID0gKG9iaiwgbWVtYmVyLCBnZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcInJlYWQgZnJvbSBwcml2YXRlIGZpZWxkXCIpLCBtZW1iZXIuZ2V0KG9iaikpO1xudmFyIF9fcHJpdmF0ZUFkZCA9IChvYmosIG1lbWJlciwgdmFsdWUpID0+IG1lbWJlci5oYXMob2JqKSA/IF9fdHlwZUVycm9yKFwiQ2Fubm90IGFkZCB0aGUgc2FtZSBwcml2YXRlIG1lbWJlciBtb3JlIHRoYW4gb25jZVwiKSA6IG1lbWJlciBpbnN0YW5jZW9mIFdlYWtTZXQgPyBtZW1iZXIuYWRkKG9iaikgOiBtZW1iZXIuc2V0KG9iaiwgdmFsdWUpO1xudmFyIF9fcHJpdmF0ZVNldCA9IChvYmosIG1lbWJlciwgdmFsdWUsIHNldHRlcikgPT4gKF9fYWNjZXNzQ2hlY2sob2JqLCBtZW1iZXIsIFwid3JpdGUgdG8gcHJpdmF0ZSBmaWVsZFwiKSwgbWVtYmVyLnNldChvYmosIHZhbHVlKSwgdmFsdWUpO1xudmFyIF9ldmVudHM7XG5jbGFzcyBFbWl0dGVyIHtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgLy8gTGlzdCBvZiBhbGwgZXZlbnRzXG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfZXZlbnRzKTtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9ldmVudHMsIHt9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQG5hbWUgb25cbiAgICAgKiBAZGVzY3JpcHRpb24gVXNlZCB0byBzdWJzY3JpYmUgdG8gYW4gZXZlbnQgYnkgbmFtZVxuICAgICAqXG4gICAgICogQHBhcmFtIG5hbWUgLSBUaGUgbmFtZSBvZiB0aGUgZXZlbnQgdG8gc3Vic2NyaWJlIHRvXG4gICAgICogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGNhbGxiYWNrIHRvIHJ1biB3aGVuIHRoZSBldmVudCBpcyBlbWl0dGVkXG4gICAgICogQHBhcmFtIGN0eCAtIFRoZSBjb250ZXh0IHRvIHJ1biB0aGUgY2FsbGJhY2sgaW5cbiAgICAgKiBAcmV0dXJucyB0aGlzIC0gVGhlIGVtaXR0ZXIgZm9yIGNoYWluaW5nIHB1cnBvc2VzXG4gICAgICovXG4gICAgb24obmFtZSwgY2FsbGJhY2ssIGN0eCkge1xuICAgICAgICBjb25zdCBldmVudHMgPSBfX3ByaXZhdGVHZXQodGhpcywgX2V2ZW50cyk7XG4gICAgICAgIGNvbnN0IGV2ZW50QXJyID0gZXZlbnRzW25hbWVdID8/IChldmVudHNbbmFtZV0gPSBbXSk7XG4gICAgICAgIGV2ZW50QXJyLnB1c2goe1xuICAgICAgICAgICAgZm46IGNhbGxiYWNrLFxuICAgICAgICAgICAgY3R4XG4gICAgICAgIH0pO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgLyoqXG4gICAgICogQG5hbWUgb2ZmXG4gICAgICogQGRlc2NyaXB0aW9uIFVzZWQgdG8gdW5zdWJzY3JpYmUgZnJvbSBhbiBldmVudCBieSBuYW1lXG4gICAgICpcbiAgICAgKiBAcGFyYW0gbmFtZSAtIFRoZSBuYW1lIG9mIHRoZSBldmVudCB0byB1bnN1YnNjcmliZSBmcm9tXG4gICAgICogQHBhcmFtIGNhbGxiYWNrIC0gVGhlIGNhbGxiYWNrIHRvIHVuc3Vic2NyaWJlXG4gICAgICogQHJldHVybnMgdGhpcyAtIFRoZSBlbWl0dGVyIGZvciBjaGFpbmluZyBwdXJwb3Nlc1xuICAgICAqL1xuICAgIG9mZihuYW1lLCBjYWxsYmFjaykge1xuICAgICAgICBjb25zdCBldmVudHMgPSBfX3ByaXZhdGVHZXQodGhpcywgX2V2ZW50cyk7XG4gICAgICAgIGNvbnN0IGV2ZW50QXJyID0gZXZlbnRzW25hbWVdO1xuICAgICAgICBjb25zdCBsaXZlRXZlbnRzID0gW107XG4gICAgICAgIGlmIChldmVudEFyciAmJiBjYWxsYmFjaykge1xuICAgICAgICAgICAgbGl2ZUV2ZW50cy5wdXNoKC4uLmV2ZW50QXJyLmZpbHRlcigoZXZlbnQpID0+IGV2ZW50LmZuICE9PSBjYWxsYmFjaykpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChsaXZlRXZlbnRzLmxlbmd0aCkge1xuICAgICAgICAgICAgZXZlbnRzW25hbWVdID0gbGl2ZUV2ZW50cztcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIGRlbGV0ZSBldmVudHNbbmFtZV07XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBuYW1lIGVtaXRcbiAgICAgKiBAZGVzY3JpcHRpb24gVXNlZCB0byBlbWl0IGFuIGV2ZW50IGJ5IG5hbWVcbiAgICAgKlxuICAgICAqIEBwYXJhbSBuYW1lIC0gVGhlIG5hbWUgb2YgdGhlIGV2ZW50IHRvIGVtaXRcbiAgICAgKiBAcGFyYW0gZGF0YSAtIFRoZSBkYXRhIHRvIHBhc3MgdG8gdGhlIGNhbGxiYWNrXG4gICAgICogQHJldHVybnMgdGhpcyAtIFRoZSBlbWl0dGVyIGZvciBjaGFpbmluZyBwdXJwb3Nlc1xuICAgICAqL1xuICAgIGVtaXQobmFtZSwgLi4uZGF0YSkge1xuICAgICAgICBjb25zdCBldmVudEFyciA9IChfX3ByaXZhdGVHZXQodGhpcywgX2V2ZW50cylbbmFtZV0gPz8gW10pLnNsaWNlKCk7XG4gICAgICAgIGV2ZW50QXJyLmZvckVhY2goKGV2ZW50KSA9PiB7XG4gICAgICAgICAgICBldmVudC5mbi5hcHBseShldmVudC5jdHgsIGRhdGEpO1xuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxufVxuX2V2ZW50cyA9IG5ldyBXZWFrTWFwKCk7XG5leHBvcnQgeyBFbWl0dGVyIH07XG4iLCJ2YXIgX19kZWZQcm9wID0gT2JqZWN0LmRlZmluZVByb3BlcnR5O1xudmFyIF9fZGVmTm9ybWFsUHJvcCA9IChvYmosIGtleSwgdmFsdWUpID0+IGtleSBpbiBvYmogPyBfX2RlZlByb3Aob2JqLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgY29uZmlndXJhYmxlOiB0cnVlLCB3cml0YWJsZTogdHJ1ZSwgdmFsdWUgfSkgOiBvYmpba2V5XSA9IHZhbHVlO1xudmFyIF9fcHVibGljRmllbGQgPSAob2JqLCBrZXksIHZhbHVlKSA9PiBfX2RlZk5vcm1hbFByb3Aob2JqLCB0eXBlb2Yga2V5ICE9PSBcInN5bWJvbFwiID8ga2V5ICsgXCJcIiA6IGtleSwgdmFsdWUpO1xuY2xhc3MgT0F1dGhFcnJvciBleHRlbmRzIEVycm9yIHtcbiAgICBjb25zdHJ1Y3RvcihlcnJvcikge1xuICAgICAgICBzdXBlcihlcnJvci5tZXNzYWdlKTtcbiAgICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImVycm9yXCIpO1xuICAgICAgICBfX3B1YmxpY0ZpZWxkKHRoaXMsIFwiZXJyb3JfZGVzY3JpcHRpb25cIik7XG4gICAgICAgIHRoaXMuZXJyb3IgPSBlcnJvci5lcnJvcjtcbiAgICAgICAgdGhpcy5lcnJvcl9kZXNjcmlwdGlvbiA9IGVycm9yLmVycm9yX2Rlc2NyaXB0aW9uO1xuICAgICAgICB0aGlzLm5hbWUgPSBcIk9BdXRoRXJyb3JcIjtcbiAgICB9XG59XG5leHBvcnQgeyBPQXV0aEVycm9yIH07XG4iLCJpbXBvcnQgeyBnZXRDb29raWUsIHJlbW92ZUNvb2tpZSB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCB7IEF1dGhTdGF0ZU1hbmFnZXIgfSBmcm9tICcuL2F1dGhTdGF0ZS5qcyc7XG5pbXBvcnQgeyBBdXRvUmVuZXdTZXJ2aWNlIH0gZnJvbSAnLi9hdXRvUmVuZXcuanMnO1xuaW1wb3J0IHsgY29va2llUmVmcmVzaElmUmVxdWlyZWQgfSBmcm9tICcuL2Nvb2tpZVJlZnJlc2guanMnO1xuaW1wb3J0IHsgRW1pdHRlciB9IGZyb20gJy4vZW1pdHRlci5qcyc7XG5pbXBvcnQgeyBPQXV0aEVycm9yIH0gZnJvbSAnLi9lcnJvci5qcyc7XG5pbXBvcnQgeyBUb2tlbiB9IGZyb20gJy4vdG9rZW4uanMnO1xuaW1wb3J0IHsgVG9rZW5NYW5hZ2VyIH0gZnJvbSAnLi90b2tlbk1hbmFnZXIuanMnO1xudmFyIF9fZGVmUHJvcCA9IE9iamVjdC5kZWZpbmVQcm9wZXJ0eTtcbnZhciBfX3R5cGVFcnJvciA9IChtc2cpID0+IHtcbiAgICB0aHJvdyBUeXBlRXJyb3IobXNnKTtcbn07XG52YXIgX19kZWZOb3JtYWxQcm9wID0gKG9iaiwga2V5LCB2YWx1ZSkgPT4ga2V5IGluIG9iaiA/IF9fZGVmUHJvcChvYmosIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBjb25maWd1cmFibGU6IHRydWUsIHdyaXRhYmxlOiB0cnVlLCB2YWx1ZSB9KSA6IG9ialtrZXldID0gdmFsdWU7XG52YXIgX19wdWJsaWNGaWVsZCA9IChvYmosIGtleSwgdmFsdWUpID0+IF9fZGVmTm9ybWFsUHJvcChvYmosIHR5cGVvZiBrZXkgIT09IFwic3ltYm9sXCIgPyBrZXkgKyBcIlwiIDoga2V5LCB2YWx1ZSk7XG52YXIgX19hY2Nlc3NDaGVjayA9IChvYmosIG1lbWJlciwgbXNnKSA9PiBtZW1iZXIuaGFzKG9iaikgfHwgX190eXBlRXJyb3IoXCJDYW5ub3QgXCIgKyBtc2cpO1xudmFyIF9fcHJpdmF0ZUdldCA9IChvYmosIG1lbWJlciwgZ2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJyZWFkIGZyb20gcHJpdmF0ZSBmaWVsZFwiKSwgZ2V0dGVyID8gZ2V0dGVyLmNhbGwob2JqKSA6IG1lbWJlci5nZXQob2JqKSk7XG52YXIgX19wcml2YXRlQWRkID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSkgPT4gbWVtYmVyLmhhcyhvYmopID8gX190eXBlRXJyb3IoXCJDYW5ub3QgYWRkIHRoZSBzYW1lIHByaXZhdGUgbWVtYmVyIG1vcmUgdGhhbiBvbmNlXCIpIDogbWVtYmVyIGluc3RhbmNlb2YgV2Vha1NldCA/IG1lbWJlci5hZGQob2JqKSA6IG1lbWJlci5zZXQob2JqLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlU2V0ID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSwgc2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJ3cml0ZSB0byBwcml2YXRlIGZpZWxkXCIpLCBtZW1iZXIuc2V0KG9iaiwgdmFsdWUpLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlTWV0aG9kID0gKG9iaiwgbWVtYmVyLCBtZXRob2QpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcImFjY2VzcyBwcml2YXRlIG1ldGhvZFwiKSwgbWV0aG9kKTtcbnZhciBfb3B0aW9ucywgX29hdXRoVXJscywgX2VtaXR0ZXIsIF9hdXRvUmVuZXdTZXJ2aWNlLCBfaXNTaWduZWRJbldpdGhBdXRoU3RhdGVJblByb2dyZXNzLCBfSWRlbnRpdHlBdXRoX2luc3RhbmNlcywgaXNTaWduZWRJbldpdGhBdXRoU3RhdGVfZm47XG5jbGFzcyBJZGVudGl0eUF1dGgge1xuICAgIGNvbnN0cnVjdG9yKG9wdGlvbnMpIHtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9JZGVudGl0eUF1dGhfaW5zdGFuY2VzKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9vcHRpb25zKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9vYXV0aFVybHMpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2VtaXR0ZXIpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2F1dG9SZW5ld1NlcnZpY2UpO1xuICAgICAgICAvLyBob2xkZXIgaWYgdGhlcmUgaXMgY3VycmVudGx5IGFuIGlzIHNpZ25lZCBpbiBjaGVjayBpbiBwcm9ncmVzc1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2lzU2lnbmVkSW5XaXRoQXV0aFN0YXRlSW5Qcm9ncmVzcyk7XG4gICAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJ0b2tlbk1hbmFnZXJcIik7XG4gICAgICAgIF9fcHVibGljRmllbGQodGhpcywgXCJ0b2tlblwiKTtcbiAgICAgICAgX19wdWJsaWNGaWVsZCh0aGlzLCBcImF1dGhTdGF0ZU1hbmFnZXJcIik7XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfb3B0aW9ucywge1xuICAgICAgICAgICAgYXV0b1JlbmV3OiB0cnVlLFxuICAgICAgICAgICAgcmVuZXdHcmFjZVBlcmlvZDogNjAsXG4gICAgICAgICAgICBtYXhDbG9ja1NrZXc6IDMwMCxcbiAgICAgICAgICAgIGlkQ29va2llU2Vzc2lvblJlZnJlc2g6IGZhbHNlLFxuICAgICAgICAgICAgb2F1dGhUaW1lb3V0OiAzZTQsXG4gICAgICAgICAgICBzdHJpY3RDbG9ja1NrZXdDaGVjazogZmFsc2UsXG4gICAgICAgICAgICAuLi5vcHRpb25zXG4gICAgICAgIH0pO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX29hdXRoVXJscywge1xuICAgICAgICAgICAgYXV0aG9yaXplVXJsOiBgJHtfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLmlzc3Vlcn0vdjEvYXV0aG9yaXplYCxcbiAgICAgICAgICAgIHRva2VuVXJsOiBgJHtfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLmlzc3Vlcn0vdjEvdG9rZW5gLFxuICAgICAgICAgICAga2V5c1VybDogYCR7X19wcml2YXRlR2V0KHRoaXMsIF9vcHRpb25zKS5pc3N1ZXJ9L3YxL2tleXNgXG4gICAgICAgIH0pO1xuICAgICAgICBjb29raWVSZWZyZXNoSWZSZXF1aXJlZChfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLmlkQ29va2llU2Vzc2lvblJlZnJlc2gsIF9fcHJpdmF0ZUdldCh0aGlzLCBfb3B0aW9ucykuaXNzdWVyKTtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9lbWl0dGVyLCBuZXcgRW1pdHRlcigpKTtcbiAgICAgICAgdGhpcy50b2tlbiA9IG5ldyBUb2tlbihfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLCBfX3ByaXZhdGVHZXQodGhpcywgX29hdXRoVXJscykpO1xuICAgICAgICB0aGlzLnRva2VuTWFuYWdlciA9IG5ldyBUb2tlbk1hbmFnZXIoX19wcml2YXRlR2V0KHRoaXMsIF9lbWl0dGVyKSwgdGhpcy50b2tlbik7XG4gICAgICAgIHRoaXMuYXV0aFN0YXRlTWFuYWdlciA9IG5ldyBBdXRoU3RhdGVNYW5hZ2VyKF9fcHJpdmF0ZUdldCh0aGlzLCBfZW1pdHRlciksIHRoaXMudG9rZW5NYW5hZ2VyKTtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9hdXRvUmVuZXdTZXJ2aWNlLCBuZXcgQXV0b1JlbmV3U2VydmljZShfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLCBfX3ByaXZhdGVHZXQodGhpcywgX2VtaXR0ZXIpLCB0aGlzLmF1dGhTdGF0ZU1hbmFnZXIpKTtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9pc1NpZ25lZEluV2l0aEF1dGhTdGF0ZUluUHJvZ3Jlc3MsIHZvaWQgMCk7XG4gICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfYXV0b1JlbmV3U2VydmljZSkuc3RhcnQoKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQG5hbWUgaXNTaWduZWRJbldpdGhBdXRoU3RhdGVcbiAgICAgKiBAZGVzY3JpcHRpb24gQ2hlY2tzIGlmIHRoZSB1c2VyIGlzIHNpZ25lZCBpbiwgYW5kIHVwZGF0ZXMgdGhlIGF1dGggc3RhdGUgYXMgbmVjZXNzYXJ5LCByZXR1cm5zIHRoZSBjdXJyZW50IGF1dGggc3RhdGVcbiAgICAgKlxuICAgICAqIFRoaXMgcGVyZm9ybXMgc2lkZSBlZmZlY3RzLlxuICAgICAqXG4gICAgICogVGhpcyBmb2xsb3dzIHRoZSBmbG93Y2hhcnQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vZ3VhcmRpYW4vZ2F0ZXdheS9ibG9iL21haW4vZG9jcy9va3RhL3dlYi1hcHBzLWludGVncmF0aW9uLWd1aWRlLm1kI2hvdy10by1rbm93LWlmLWEtcmVhZGVyLWlzLXNpZ25lZC1pbiB0byBkZXRlcm1pbmUgaWYgdGhlIHVzZXIgaXMgc2lnbmVkIGluXG4gICAgICpcbiAgICAgKiAxLiBJZiB0aGUgdXNlciB0b2tlbnMgYWxyZWFkeSBleGlzdCwgdGhlbiB2ZXJpZnkgdGhlbSB0byBtYWtlIHN1cmUgdGhleSBhcmUgc3RpbGwgdmFsaWRcbiAgICAgKiAyLiBJZiB0aGV5IGRvLCBjaGVjayBpZiB0aGUgdXNlciBoYXMgYSBgR1VfU09gIGNvb2tpZSBhbmQgY29tcGFyZSBpdCB0byB0aGUgYGlhdGAgdmFsdWUgb2YgdGhlIGlkIHRva2VuXG4gICAgICogICBhLiBJZiB0aGUgYEdVX1NPYCBjb29raWUgdmFsdWUgaXMgZ3JlYXRlciB0aGFuIHRoZSBgaWF0YCB2YWx1ZSwgdGhlIHVzZXIgaGFzIHJlY2VudGx5IHNpZ25lZCBvdXQsIHNvIHdlIHNob3VsZCBjbGVhciB0aGVpciB0b2tlbnMgKHNpZGUgZWZmZWN0KVxuICAgICAqICAgYi4gT3RoZXJ3aXNlLCB0aGUgdXNlciBpcyBzaWduZWQgaW4sIHNvIHJldHVybiB0aGUgYXV0aCBzdGF0ZVxuICAgICAqIDMuIElmIHRoZSB1c2VyIGRvZXNuJ3QgaGF2ZSB0b2tlbnMsIGJ1dCB0aGV5IGhhdmUgYSBgR1VfVWAgY29va2llLCB0aGV5IGFyZSBcIm1heWJlXCIgc2lnbmVkIGluXG4gICAgICogIGEuIFdlIGNhbiB0cnkgdG8gZ2V0IHRva2VucyB3aXRob3V0IHByb21wdGluZy9yZWRpcmVjdGluZyB0aGUgdXNlciBmb3IgY3JlZGVudGlhbHMgKHNpZGUgZWZmZWN0KVxuICAgICAqIFx0Yi4gSWYgbm8gdG9rZW5zIGFyZSByZXR1cm5lZCwgd2UgY2xlYXIgdGhlIGBHVV9VYCBjb29raWUsIGFzIGl0IGlzIGxpa2VseSBpbnZhbGlkIChzaWRlIGVmZmVjdClcbiAgICAgKiAgYy4gSWYgdGhlcmUgaXMgYW4gZXJyb3IgZ2V0dGluZyB0aGUgdG9rZW5zOlxuICAgICAqICAgIGkuIElmIHRoZSBlcnJvciBpcyBhbiBgT0F1dGhFcnJvcmAgYW5kIHRoZSBlcnJvciBpcyBgbG9naW5fcmVxdWlyZWRgLCB0aGUgdXNlciBpcyBub3Qgc2lnbmVkIGluLCBzbyB3ZSBjbGVhciB0aGUgYEdVX1VgIGNvb2tpZSwgYXMgaXQgaXMgbGlrZWx5IGludmFsaWQgKHNpZGUgZWZmZWN0KVxuICAgICAqICAgIGlpLiBPdGhlcndpc2UsIHRoZXJlIGlzIGFuIHVua25vd24gZXJyb3IsIHNvIGNsZWFyIGFueSB0b2tlbnMgYW5kIHRocm93IHRoZSBlcnJvclxuICAgICAqIDQuIElmIHRoZSB1c2VyIGRvZXNuJ3QgaGF2ZSB0b2tlbnMgb3IgYSBHVV9VIGNvb2tpZSwgdGhleSBhcmUgbm90IHNpZ25lZCBpblxuICAgICAqXG4gICAgICogRm9yIG9wdGltaXNhdGlvbiwgdGhpcyBtZXRob2Qgd2lsbCBvbmx5IHJ1biBvbmUgc2lnbmVkIGluIGNoZWNrIGF0IGEgdGltZSxcbiAgICAgKiBhbmQgd2lsbCByZXR1cm4gdGhlIGV4aXN0aW5nIHByb21pc2UgaWYgYSBjaGVjayBpcyBhbHJlYWR5IGluIHByb2dyZXNzXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBgQXV0aFN0YXRlYCAtIFJldHVybnMgdGhlIGN1cnJlbnQgYXV0aGVudGljYXRpb24gc3RhdGVcbiAgICAgKi9cbiAgICBhc3luYyBpc1NpZ25lZEluV2l0aEF1dGhTdGF0ZSgpIHtcbiAgICAgICAgaWYgKF9fcHJpdmF0ZUdldCh0aGlzLCBfaXNTaWduZWRJbldpdGhBdXRoU3RhdGVJblByb2dyZXNzKSkge1xuICAgICAgICAgICAgcmV0dXJuIF9fcHJpdmF0ZUdldCh0aGlzLCBfaXNTaWduZWRJbldpdGhBdXRoU3RhdGVJblByb2dyZXNzKTtcbiAgICAgICAgfVxuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX2lzU2lnbmVkSW5XaXRoQXV0aFN0YXRlSW5Qcm9ncmVzcywgX19wcml2YXRlTWV0aG9kKHRoaXMsIF9JZGVudGl0eUF1dGhfaW5zdGFuY2VzLCBpc1NpZ25lZEluV2l0aEF1dGhTdGF0ZV9mbikuY2FsbCh0aGlzKS5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfaXNTaWduZWRJbldpdGhBdXRoU3RhdGVJblByb2dyZXNzLCB2b2lkIDApO1xuICAgICAgICB9KSk7XG4gICAgICAgIHJldHVybiBfX3ByaXZhdGVHZXQodGhpcywgX2lzU2lnbmVkSW5XaXRoQXV0aFN0YXRlSW5Qcm9ncmVzcyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBuYW1lIGlzU2lnbmVkSW5cbiAgICAgKiBAZGVzY3JpcHRpb24gQ2hlY2tzIGlmIHRoZSB1c2VyIGlzIHNpZ25lZCBpbiwgYW5kIHVwZGF0ZXMgdGhlIGF1dGggc3RhdGUgYXMgbmVjZXNzYXJ5LCByZXR1cm5zIGJvb2xlYW5cbiAgICAgKlxuICAgICAqIFRoaXMgcGVyZm9ybXMgc2lkZSBlZmZlY3RzLlxuICAgICAqXG4gICAgICogVGhpcyBmb2xsb3dzIHRoZSBmbG93Y2hhcnQgZnJvbSBodHRwczovL2dpdGh1Yi5jb20vZ3VhcmRpYW4vZ2F0ZXdheS9ibG9iL21haW4vZG9jcy9va3RhL3dlYi1hcHBzLWludGVncmF0aW9uLWd1aWRlLm1kI2hvdy10by1rbm93LWlmLWEtcmVhZGVyLWlzLXNpZ25lZC1pbiB0byBkZXRlcm1pbmUgaWYgdGhlIHVzZXIgaXMgc2lnbmVkIGluXG4gICAgICpcbiAgICAgKiAxLiBJZiB0aGUgdXNlciB0b2tlbnMgYWxyZWFkeSBleGlzdCwgdGhlbiB2ZXJpZnkgdGhlbSB0byBtYWtlIHN1cmUgdGhleSBhcmUgc3RpbGwgdmFsaWRcbiAgICAgKiAyLiBJZiB0aGV5IGRvLCBjaGVjayBpZiB0aGUgdXNlciBoYXMgYSBgR1VfU09gIGNvb2tpZSBhbmQgY29tcGFyZSBpdCB0byB0aGUgYGlhdGAgdmFsdWUgb2YgdGhlIGlkIHRva2VuXG4gICAgICogICBhLiBJZiB0aGUgYEdVX1NPYCBjb29raWUgdmFsdWUgaXMgZ3JlYXRlciB0aGFuIHRoZSBgaWF0YCB2YWx1ZSwgdGhlIHVzZXIgaGFzIHJlY2VudGx5IHNpZ25lZCBvdXQsIHNvIHdlIHNob3VsZCBjbGVhciB0aGVpciB0b2tlbnMgKHNpZGUgZWZmZWN0KVxuICAgICAqICAgYi4gT3RoZXJ3aXNlLCB0aGUgdXNlciBpcyBzaWduZWQgaW4sIHNvIHJldHVybiB0aGUgYXV0aCBzdGF0ZVxuICAgICAqIDMuIElmIHRoZSB1c2VyIGRvZXNuJ3QgaGF2ZSB0b2tlbnMsIGJ1dCB0aGV5IGhhdmUgYSBgR1VfVWAgY29va2llLCB0aGV5IGFyZSBcIm1heWJlXCIgc2lnbmVkIGluXG4gICAgICogIGEuIFdlIGNhbiB0cnkgdG8gZ2V0IHRva2VucyB3aXRob3V0IHByb21wdGluZy9yZWRpcmVjdGluZyB0aGUgdXNlciBmb3IgY3JlZGVudGlhbHMgKHNpZGUgZWZmZWN0KVxuICAgICAqIFx0Yi4gSWYgbm8gdG9rZW5zIGFyZSByZXR1cm5lZCwgd2UgY2xlYXIgdGhlIGBHVV9VYCBjb29raWUsIGFzIGl0IGlzIGxpa2VseSBpbnZhbGlkIChzaWRlIGVmZmVjdClcbiAgICAgKiAgYy4gSWYgdGhlcmUgaXMgYW4gZXJyb3IgZ2V0dGluZyB0aGUgdG9rZW5zOlxuICAgICAqICAgIGkuIElmIHRoZSBlcnJvciBpcyBhbiBgT0F1dGhFcnJvcmAgYW5kIHRoZSBlcnJvciBpcyBgbG9naW5fcmVxdWlyZWRgLCB0aGUgdXNlciBpcyBub3Qgc2lnbmVkIGluLCBzbyB3ZSBjbGVhciB0aGUgYEdVX1VgIGNvb2tpZSwgYXMgaXQgaXMgbGlrZWx5IGludmFsaWQgKHNpZGUgZWZmZWN0KVxuICAgICAqICAgIGlpLiBPdGhlcndpc2UsIHRoZXJlIGlzIGFuIHVua25vd24gZXJyb3IsIHNvIGNsZWFyIGFueSB0b2tlbnMgYW5kIHRocm93IHRoZSBlcnJvclxuICAgICAqIDQuIElmIHRoZSB1c2VyIGRvZXNuJ3QgaGF2ZSB0b2tlbnMgb3IgYSBHVV9VIGNvb2tpZSwgdGhleSBhcmUgbm90IHNpZ25lZCBpblxuICAgICAqXG4gICAgICogQHJldHVybnMgYGJvb2xlYW5gIC0gYHRydWVgIGlmIHRoZSB1c2VyIGlzIHNpZ25lZCBpbiwgYGZhbHNlYCBpZiBub3RcbiAgICAgKi9cbiAgICBhc3luYyBpc1NpZ25lZEluKCkge1xuICAgICAgICByZXR1cm4gKGF3YWl0IHRoaXMuaXNTaWduZWRJbldpdGhBdXRoU3RhdGUoKSkuaXNBdXRoZW50aWNhdGVkO1xuICAgIH1cbn1cbl9vcHRpb25zID0gbmV3IFdlYWtNYXAoKTtcbl9vYXV0aFVybHMgPSBuZXcgV2Vha01hcCgpO1xuX2VtaXR0ZXIgPSBuZXcgV2Vha01hcCgpO1xuX2F1dG9SZW5ld1NlcnZpY2UgPSBuZXcgV2Vha01hcCgpO1xuX2lzU2lnbmVkSW5XaXRoQXV0aFN0YXRlSW5Qcm9ncmVzcyA9IG5ldyBXZWFrTWFwKCk7XG5fSWRlbnRpdHlBdXRoX2luc3RhbmNlcyA9IG5ldyBXZWFrU2V0KCk7XG5pc1NpZ25lZEluV2l0aEF1dGhTdGF0ZV9mbiA9IGFzeW5jIGZ1bmN0aW9uICgpIHtcbiAgICB0cnkge1xuICAgICAgICBjb25zdCBhdXRoU3RhdGUgPSB0aGlzLmF1dGhTdGF0ZU1hbmFnZXIuZ2V0QXV0aFN0YXRlKCk7XG4gICAgICAgIGlmIChhdXRoU3RhdGUuaXNBdXRoZW50aWNhdGVkKSB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnRva2VuLnZlcmlmeVRva2VucyhhdXRoU3RhdGUuaWRUb2tlbiwgYXV0aFN0YXRlLmFjY2Vzc1Rva2VuKTtcbiAgICAgICAgICAgIGNvbnN0IGd1U29Db29raWUgPSBwYXJzZUludChnZXRDb29raWUoeyBuYW1lOiBcIkdVX1NPXCIsIHNob3VsZE1lbW9pemU6IHRydWUgfSkgPz8gXCJcIik7XG4gICAgICAgICAgICBjb25zdCBub3JtYWxpc2VkQ3VycmVudFRpbWUgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxZTMpIC0gYXV0aFN0YXRlLmlkVG9rZW4uY2xvY2tTa2V3O1xuICAgICAgICAgICAgaWYgKFxuICAgICAgICAgICAgLy8gbWFrZSBzdXJlIHRoYXQgdGhlIEdVX1NPIGNvb2tpZSBpcyBpbiB0aGUgcGFzdFxuICAgICAgICAgICAgZ3VTb0Nvb2tpZSA8PSBub3JtYWxpc2VkQ3VycmVudFRpbWUgJiYgLy8gY29tcGFyZSB0aGUgR1VfU08gY29va2llIHRvIHRoZSBpZCB0b2tlbidzIGlhdCB2YWx1ZVxuICAgICAgICAgICAgICAgIGd1U29Db29raWUgPiBhdXRoU3RhdGUuaWRUb2tlbi5jbGFpbXMuaWF0KSB7XG4gICAgICAgICAgICAgICAgdGhpcy50b2tlbk1hbmFnZXIuY2xlYXIoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJldHVybiBhdXRoU3RhdGU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGdldENvb2tpZSh7IG5hbWU6IFwiR1VfVVwiLCBzaG91bGRNZW1vaXplOiB0cnVlIH0pKSB7XG4gICAgICAgICAgICBjb25zdCB0b2tlbnMgPSBhd2FpdCB0aGlzLnRva2VuTWFuYWdlci5nZXRUb2tlbnMoe1xuICAgICAgICAgICAgICAgIHJlZnJlc2hJZlJlcXVpcmVkOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIGlmICh0b2tlbnMpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgICAgICAgICBhY2Nlc3NUb2tlbjogdG9rZW5zLmFjY2Vzc1Rva2VuLFxuICAgICAgICAgICAgICAgICAgICBpZFRva2VuOiB0b2tlbnMuaWRUb2tlbixcbiAgICAgICAgICAgICAgICAgICAgaXNBdXRoZW50aWNhdGVkOiB0cnVlXG4gICAgICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHJlbW92ZUNvb2tpZSh7IG5hbWU6IFwiR1VfVVwiIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBhY2Nlc3NUb2tlbjogdm9pZCAwLFxuICAgICAgICAgICAgaWRUb2tlbjogdm9pZCAwLFxuICAgICAgICAgICAgaXNBdXRoZW50aWNhdGVkOiBmYWxzZVxuICAgICAgICB9O1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgaWYgKGVycm9yIGluc3RhbmNlb2YgT0F1dGhFcnJvciAmJiBlcnJvci5lcnJvciA9PT0gXCJsb2dpbl9yZXF1aXJlZFwiKSB7XG4gICAgICAgICAgICByZW1vdmVDb29raWUoeyBuYW1lOiBcIkdVX1VcIiB9KTtcbiAgICAgICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICAgICAgYWNjZXNzVG9rZW46IHZvaWQgMCxcbiAgICAgICAgICAgICAgICBpZFRva2VuOiB2b2lkIDAsXG4gICAgICAgICAgICAgICAgaXNBdXRoZW50aWNhdGVkOiBmYWxzZVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLnRva2VuTWFuYWdlci5jbGVhcigpO1xuICAgICAgICB0aHJvdyBlcnJvcjtcbiAgICB9XG59O1xuZXhwb3J0IHsgSWRlbnRpdHlBdXRoIH07XG4iLCJpbXBvcnQgeyBpc05vbk51bGxhYmxlIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgYmFzZTY0VXJsVG9TdHJpbmcsIHN0cmluZ1RvQnVmZmVyLCBnZW5lcmF0ZVNoYTI1Nkhhc2gsIGJhc2U2NFVybEVuY29kZSwgZ2VuZXJhdGVDb2RlVmVyaWZpZXIsIGdlbmVyYXRlQ29kZUNoYWxsZW5nZSwgZ2V0UmFuZG9tU3RyaW5nIH0gZnJvbSAnLi9jcnlwdG8uanMnO1xuaW1wb3J0IHsgT0F1dGhFcnJvciB9IGZyb20gJy4vZXJyb3IuanMnO1xudmFyIF9fdHlwZUVycm9yID0gKG1zZykgPT4ge1xuICAgIHRocm93IFR5cGVFcnJvcihtc2cpO1xufTtcbnZhciBfX2FjY2Vzc0NoZWNrID0gKG9iaiwgbWVtYmVyLCBtc2cpID0+IG1lbWJlci5oYXMob2JqKSB8fCBfX3R5cGVFcnJvcihcIkNhbm5vdCBcIiArIG1zZyk7XG52YXIgX19wcml2YXRlR2V0ID0gKG9iaiwgbWVtYmVyLCBnZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcInJlYWQgZnJvbSBwcml2YXRlIGZpZWxkXCIpLCBnZXR0ZXIgPyBnZXR0ZXIuY2FsbChvYmopIDogbWVtYmVyLmdldChvYmopKTtcbnZhciBfX3ByaXZhdGVBZGQgPSAob2JqLCBtZW1iZXIsIHZhbHVlKSA9PiBtZW1iZXIuaGFzKG9iaikgPyBfX3R5cGVFcnJvcihcIkNhbm5vdCBhZGQgdGhlIHNhbWUgcHJpdmF0ZSBtZW1iZXIgbW9yZSB0aGFuIG9uY2VcIikgOiBtZW1iZXIgaW5zdGFuY2VvZiBXZWFrU2V0ID8gbWVtYmVyLmFkZChvYmopIDogbWVtYmVyLnNldChvYmosIHZhbHVlKTtcbnZhciBfX3ByaXZhdGVTZXQgPSAob2JqLCBtZW1iZXIsIHZhbHVlLCBzZXR0ZXIpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcIndyaXRlIHRvIHByaXZhdGUgZmllbGRcIiksIG1lbWJlci5zZXQob2JqLCB2YWx1ZSksIHZhbHVlKTtcbnZhciBfX3ByaXZhdGVNZXRob2QgPSAob2JqLCBtZW1iZXIsIG1ldGhvZCkgPT4gKF9fYWNjZXNzQ2hlY2sob2JqLCBtZW1iZXIsIFwiYWNjZXNzIHByaXZhdGUgbWV0aG9kXCIpLCBtZXRob2QpO1xudmFyIF9vcHRpb25zLCBfb2F1dGhVcmxzLCBfZ2V0VG9rZW5zSW5Qcm9ncmVzcywgX2V4Y2hhbmdlQ29kZUZvclRva2VucywgX2hhbmRsZU9BdXRoUmVzcG9uc2UsIF9wZXJmb3JtQXV0aENvZGVGbG93SWZyYW1lLCBfVG9rZW5faW5zdGFuY2VzLCBnZXRXaXRob3V0UHJvbXB0X2ZuO1xuY29uc3QgaXNBY2Nlc3NUb2tlbkNsYWltcyA9IChjbGFpbXMpID0+IHtcbiAgICBjb25zdCBtYXliZUNsYWltcyA9IGNsYWltcztcbiAgICByZXR1cm4gaXNOb25OdWxsYWJsZShtYXliZUNsYWltcykgJiYgbWF5YmVDbGFpbXMuYXVkICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMuYXV0aF90aW1lICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMuY2lkICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMuZW1haWxfdmFsaWRhdGVkICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMuZXhwICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMuaWF0ICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMuaWRlbnRpdHlfdXNlcm5hbWUgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5pc3MgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5qdGkgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5sZWdhY3lfaWRlbnRpdHlfaWQgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5zY3AgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5zdWIgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy51aWQgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy52ZXIgIT09IHZvaWQgMDtcbn07XG5jb25zdCBpc0FjY2Vzc1Rva2VuID0gKHRva2VuKSA9PiB7XG4gICAgY29uc3QgbWF5YmVUb2tlbiA9IHRva2VuO1xuICAgIHJldHVybiBpc05vbk51bGxhYmxlKG1heWJlVG9rZW4pICYmIG1heWJlVG9rZW4uYWNjZXNzVG9rZW4gIT09IHZvaWQgMCAmJiBtYXliZVRva2VuLmV4cGlyZXNBdCAhPT0gdm9pZCAwICYmIG1heWJlVG9rZW4uc2NvcGVzICE9PSB2b2lkIDAgJiYgbWF5YmVUb2tlbi50b2tlblR5cGUgIT09IHZvaWQgMCAmJiBpc0FjY2Vzc1Rva2VuQ2xhaW1zKG1heWJlVG9rZW4uY2xhaW1zKTtcbn07XG5jb25zdCBpc0lEVG9rZW5DbGFpbXMgPSAoY2xhaW1zKSA9PiB7XG4gICAgY29uc3QgbWF5YmVDbGFpbXMgPSBjbGFpbXM7XG4gICAgcmV0dXJuIGlzTm9uTnVsbGFibGUobWF5YmVDbGFpbXMpICYmIG1heWJlQ2xhaW1zLmFtciAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLmF0X2hhc2ggIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5hdWQgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5hdXRoX3RpbWUgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5leHAgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5pYXQgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5pZGVudGl0eV91c2VybmFtZSAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLmlkcCAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLmlzcyAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLmp0aSAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLmxlZ2FjeV9pZGVudGl0eV9pZCAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLm5hbWUgIT09IHZvaWQgMCAmJiBtYXliZUNsYWltcy5ub25jZSAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLnByZWZlcnJlZF91c2VybmFtZSAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLnN1YiAhPT0gdm9pZCAwICYmIG1heWJlQ2xhaW1zLnVzZXJfZ3JvdXBzICE9PSB2b2lkIDAgJiYgbWF5YmVDbGFpbXMudmVyICE9PSB2b2lkIDA7XG59O1xuY29uc3QgaXNJRFRva2VuID0gKHRva2VuKSA9PiB7XG4gICAgY29uc3QgbWF5YmVUb2tlbiA9IHRva2VuO1xuICAgIHJldHVybiBpc05vbk51bGxhYmxlKG1heWJlVG9rZW4pICYmIG1heWJlVG9rZW4uZXhwaXJlc0F0ICE9PSB2b2lkIDAgJiYgbWF5YmVUb2tlbi5pZFRva2VuICE9PSB2b2lkIDAgJiYgbWF5YmVUb2tlbi5zY29wZXMgIT09IHZvaWQgMCAmJiBpc0lEVG9rZW5DbGFpbXMobWF5YmVUb2tlbi5jbGFpbXMpO1xufTtcbmNvbnN0IGlzT0F1dGhBdXRob3JpemVSZXNwb25zZUVycm9yID0gKHJlc3BvbnNlKSA9PiB7XG4gICAgY29uc3QgbWF5YmVSZXNwb25zZSA9IHJlc3BvbnNlO1xuICAgIHJldHVybiBpc05vbk51bGxhYmxlKG1heWJlUmVzcG9uc2UpICYmIG1heWJlUmVzcG9uc2UuZXJyb3IgIT09IHZvaWQgMCAmJiBtYXliZVJlc3BvbnNlLmVycm9yX2Rlc2NyaXB0aW9uICE9PSB2b2lkIDAgJiYgbWF5YmVSZXNwb25zZS5zdGF0ZSAhPT0gdm9pZCAwO1xufTtcbmNvbnN0IGlzT0F1dGhUb2tlblJlc3BvbnNlRXJyb3IgPSAocmVzcG9uc2UpID0+IHtcbiAgICBjb25zdCBtYXliZVJlc3BvbnNlID0gcmVzcG9uc2U7XG4gICAgcmV0dXJuIGlzTm9uTnVsbGFibGUobWF5YmVSZXNwb25zZSkgJiYgbWF5YmVSZXNwb25zZS5lcnJvciAhPT0gdm9pZCAwICYmIG1heWJlUmVzcG9uc2UuZXJyb3JfZGVzY3JpcHRpb24gIT09IHZvaWQgMDtcbn07XG5jb25zdCBjYWxjdWxhdGVDbG9ja1NrZXcgPSAobm93LCB0b2tlbikgPT4ge1xuICAgIGNvbnN0IHsgaWF0IH0gPSBkZWNvZGVUb2tlbih0b2tlbikucGF5bG9hZDtcbiAgICBpZiAoIWlhdCkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJpYXQgY2xhaW0gaXMgbWlzc2luZyBmcm9tIHRva2VuXCJcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBub3cgLSBpYXQ7XG59O1xuY29uc3QgZGVjb2RlVG9rZW4gPSAodG9rZW4pID0+IHtcbiAgICBjb25zdCBbaGVhZGVyU3RyLCBwYXlsb2FkU3RyLCBzaWduYXR1cmVdID0gdG9rZW4uc3BsaXQoXCIuXCIpO1xuICAgIHRyeSB7XG4gICAgICAgIGlmIChoZWFkZXJTdHIgPT09IHZvaWQgMCB8fCBwYXlsb2FkU3RyID09PSB2b2lkIDAgfHwgc2lnbmF0dXJlID09PSB2b2lkIDApIHtcbiAgICAgICAgICAgIHRocm93IFwiTWlzc2luZyB0b2tlbiBwYXJ0c1wiO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGhlYWRlciA9IEpTT04ucGFyc2UoYmFzZTY0VXJsVG9TdHJpbmcoaGVhZGVyU3RyKSk7XG4gICAgICAgIGNvbnN0IHBheWxvYWQgPSBKU09OLnBhcnNlKGJhc2U2NFVybFRvU3RyaW5nKHBheWxvYWRTdHIpKTtcbiAgICAgICAgaWYgKCFoZWFkZXIuYWxnIHx8ICFoZWFkZXIua2lkKSB7XG4gICAgICAgICAgICB0aHJvdyBcIk1pc3NpbmcgYWxnb3JpdGhtIGluIGhlYWRlclwiO1xuICAgICAgICB9XG4gICAgICAgIGlmICghcGF5bG9hZC5qdGkpIHtcbiAgICAgICAgICAgIHRocm93IFwiUG9zc2libHkgbWFsZm9ybWVkIHBheWxvYWRcIjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgaGVhZGVyLFxuICAgICAgICAgICAgcGF5bG9hZCxcbiAgICAgICAgICAgIHNpZ25hdHVyZVxuICAgICAgICB9O1xuICAgIH1cbiAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiTWFsZm9ybWVkIHRva2VuXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBlcnJvclxuICAgICAgICB9KTtcbiAgICB9XG59O1xuY29uc3QgZGVjb2RlVG9rZW5zID0gKHsgYWNjZXNzVG9rZW5SYXcsIGFjY2Vzc1Rva2VuQ2xvY2tTa2V3LCBpZFRva2VuUmF3LCBpZFRva2VuQ2xvY2tTa2V3LCBub25jZSwgb3B0aW9ucyB9KSA9PiB7XG4gICAgY29uc3Qgbm93ID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMWUzKTtcbiAgICBjb25zdCBkZWNvZGVkQWNjZXNzVG9rZW4gPSBkZWNvZGVUb2tlbihhY2Nlc3NUb2tlblJhdyk7XG4gICAgY29uc3QgYWNjZXNzVG9rZW5QYXlsb2FkID0gZGVjb2RlZEFjY2Vzc1Rva2VuLnBheWxvYWQ7XG4gICAgaWYgKCFpc0FjY2Vzc1Rva2VuQ2xhaW1zKGFjY2Vzc1Rva2VuUGF5bG9hZCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiSW52YWxpZCBhY2Nlc3MgdG9rZW4gY2xhaW1zXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkludmFsaWQgYWNjZXNzIHRva2VuIGNsYWltc1wiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAob3B0aW9ucy5zdHJpY3RDbG9ja1NrZXdDaGVjayAmJiBNYXRoLmFicyhhY2Nlc3NUb2tlbkNsb2NrU2tldykgPiBvcHRpb25zLm1heENsb2NrU2tldykge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIEFjY2VzcyB0b2tlblwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJDbG9jayBza2V3IHRvbyBsYXJnZVwiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBhY2Nlc3NUb2tlbiA9IHtcbiAgICAgICAgYWNjZXNzVG9rZW46IGFjY2Vzc1Rva2VuUmF3LFxuICAgICAgICBjbGFpbXM6IGFjY2Vzc1Rva2VuUGF5bG9hZCxcbiAgICAgICAgZXhwaXJlc0F0OiBhY2Nlc3NUb2tlblBheWxvYWQuZXhwIC0gYWNjZXNzVG9rZW5QYXlsb2FkLmlhdCArIG5vdyxcbiAgICAgICAgLy8gYWRqdXN0aW5nIGV4cGlyZXNBdCB0byBiZSBpbiBsb2NhbCAobWFjaGluZSkgdGltZSwgdG8gYWNjb3VudCBmb3IgY2xvY2sgc2tld1xuICAgICAgICBjbG9ja1NrZXc6IGFjY2Vzc1Rva2VuQ2xvY2tTa2V3LFxuICAgICAgICB0b2tlblR5cGU6IFwiQmVhcmVyXCIsXG4gICAgICAgIHNjb3BlczogYWNjZXNzVG9rZW5QYXlsb2FkLnNjcFxuICAgIH07XG4gICAgaWYgKCFpc0FjY2Vzc1Rva2VuKGFjY2Vzc1Rva2VuKSkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIGFjY2VzcyB0b2tlblwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJJbnZhbGlkIGFjY2VzcyB0b2tlblwiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBkZWNvZGVkSURUb2tlbiA9IGRlY29kZVRva2VuKGlkVG9rZW5SYXcpO1xuICAgIGNvbnN0IGlkVG9rZW5QYXlsb2FkID0gZGVjb2RlZElEVG9rZW4ucGF5bG9hZDtcbiAgICBpZiAoIWlzSURUb2tlbkNsYWltcyhpZFRva2VuUGF5bG9hZCkpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiSW52YWxpZCBJRCB0b2tlbiBjbGFpbXNcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiSW52YWxpZCBJRCB0b2tlbiBjbGFpbXNcIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG9wdGlvbnMuc3RyaWN0Q2xvY2tTa2V3Q2hlY2sgJiYgTWF0aC5hYnMoaWRUb2tlbkNsb2NrU2tldykgPiBvcHRpb25zLm1heENsb2NrU2tldykge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIElEIHRva2VuXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkNsb2NrIHNrZXcgdG9vIGxhcmdlXCJcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGNvbnN0IGlkVG9rZW4gPSB7XG4gICAgICAgIGlkVG9rZW46IGlkVG9rZW5SYXcsXG4gICAgICAgIGlzc3Vlcjogb3B0aW9ucy5pc3N1ZXIsXG4gICAgICAgIGNsaWVudElkOiBvcHRpb25zLmNsaWVudElkLFxuICAgICAgICBjbGFpbXM6IGlkVG9rZW5QYXlsb2FkLFxuICAgICAgICBleHBpcmVzQXQ6IGlkVG9rZW5QYXlsb2FkLmV4cCAtIGlkVG9rZW5QYXlsb2FkLmlhdCArIG5vdyxcbiAgICAgICAgLy8gYWRqdXN0aW5nIGV4cGlyZXNBdCB0byBiZSBpbiBsb2NhbCAobWFjaGluZSkgdGltZSwgdG8gYWNjb3VudCBmb3IgY2xvY2sgc2tld1xuICAgICAgICBjbG9ja1NrZXc6IGlkVG9rZW5DbG9ja1NrZXcsXG4gICAgICAgIHNjb3Blczogb3B0aW9ucy5zY29wZXMsXG4gICAgICAgIG5vbmNlXG4gICAgfTtcbiAgICBpZiAoIWlzSURUb2tlbihpZFRva2VuKSkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIElEIHRva2VuXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkludmFsaWQgSUQgdG9rZW5cIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgYWNjZXNzVG9rZW4sXG4gICAgICAgIGlkVG9rZW5cbiAgICB9O1xufTtcbmNvbnN0IHZlcmlmeUlkVG9rZW5DbGFpbXMgPSAoZGVjb2RlZCwgY2xhaW1zLCBvcHRpb25zKSA9PiB7XG4gICAgY29uc3QgbG9jYWxUaW1lID0gTWF0aC5mbG9vcihEYXRlLm5vdygpIC8gMWUzKTtcbiAgICBjb25zdCBub3JtYWxpc2VkVGltZSA9IGxvY2FsVGltZSAtIGRlY29kZWQuY2xvY2tTa2V3O1xuICAgIGlmIChjbGFpbXMubm9uY2UgIT09IGRlY29kZWQubm9uY2UpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiSW52YWxpZCBub25jZSBpbiBJRCB0b2tlblwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJJbnZhbGlkIG5vbmNlIGluIElEIHRva2VuXCJcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChjbGFpbXMuaXNzICE9PSBvcHRpb25zLmlzc3Vlcikge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIGlzc3VlciBpbiBJRCB0b2tlblwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJJbnZhbGlkIGlzc3VlciBpbiBJRCB0b2tlblwiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoY2xhaW1zLmF1ZCAhPT0gb3B0aW9ucy5jbGllbnRJZCkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIGF1ZGllbmNlIGluIElEIHRva2VuXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIkludmFsaWQgYXVkaWVuY2UgaW4gSUQgdG9rZW5cIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKCFjbGFpbXMuaWF0KSB7XG4gICAgICAgIHRocm93IG5ldyBPQXV0aEVycm9yKHtcbiAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfdG9rZW5cIixcbiAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBcIk1pc3NpbmcgaWF0IGNsYWltIGluIElEIHRva2VuXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlRva2VuIGRvZXMgbm90IGNvbnRhaW4gcmVxdWlyZWQgY2xhaW1zXCJcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGlmIChjbGFpbXMuaWF0ID4gbm9ybWFsaXNlZFRpbWUpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiVG9rZW4gd2FzIGlzc3VlZCBpbiB0aGUgZnV0dXJlXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlRva2VuIHdhcyBpc3N1ZWQgaW4gdGhlIGZ1dHVyZVwiXG4gICAgICAgIH0pO1xuICAgIH1cbn07XG5jb25zdCB2ZXJpZnlBY2Nlc3NUb2tlbldpdGhBdEhhc2ggPSBhc3luYyAoYXRfaGFzaCwgYWNjZXNzX3Rva2VuKSA9PiB7XG4gICAgY29uc3QgYWNjZXNzVG9rZW5IYXNoID0gYXdhaXQgZ2VuZXJhdGVTaGEyNTZIYXNoKGFjY2Vzc190b2tlbik7XG4gICAgY29uc3QgYWNjZXNzVG9rZW5IYXNoMTI4ID0gYWNjZXNzVG9rZW5IYXNoLnN1YnN0cmluZygwLCAxNik7XG4gICAgY29uc3QgYWNjZXNzVG9rZW5IYXNoQmFzZTY0ID0gYmFzZTY0VXJsRW5jb2RlKGFjY2Vzc1Rva2VuSGFzaDEyOCk7XG4gICAgaWYgKGFjY2Vzc1Rva2VuSGFzaEJhc2U2NCAhPT0gYXRfaGFzaCkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJJbnZhbGlkIHRva2VuXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIlRoZSBhY2Nlc3MgdG9rZW4gaGFzaCBkb2VzIG5vdCBtYXRjaCB0aGUgYXRfaGFzaCBjbGFpbVwiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICByZXR1cm47XG59O1xuY29uc3QgdmVyaWZ5U2lnbmF0dXJlID0gYXN5bmMgKGp3a3NVcmksIGp3dCwgdG9rZW4pID0+IHtcbiAgICBjb25zdCBqd2tzUmVzcG9uc2UgPSBhd2FpdCBmZXRjaChqd2tzVXJpKTtcbiAgICBpZiAoIWp3a3NSZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJmYWlsZWRfcmVxdWVzdFwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiRmFpbGVkIHRvIGZldGNoIEpXS1NcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiRmFpbGVkIHRvIGZldGNoIEpXS1NcIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgandrcyA9IGF3YWl0IGp3a3NSZXNwb25zZS5qc29uKCk7XG4gICAgaWYgKCFqd2tzLmtleXMgfHwgandrcy5rZXlzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX2p3a3NcIixcbiAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBcIk5vIGtleXMgZm91bmQgaW4gSldLU1wiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJObyBrZXlzIGZvdW5kIGluIEpXS1NcIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrZXkyIG9mIGp3a3Mua2V5cykge1xuICAgICAgICBpZiAoIWtleTIua3R5IHx8ICFrZXkyLm4gfHwgIWtleTIuZSB8fCAha2V5Mi5hbGcgfHwgIWtleTIudXNlIHx8ICFrZXkyLmtpZCkge1xuICAgICAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfandrc1wiLFxuICAgICAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBcIkludmFsaWQga2V5IGluIEpXS1NcIixcbiAgICAgICAgICAgICAgICBtZXNzYWdlOiBcIkludmFsaWQga2V5IGluIEpXS1NcIlxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY29uc3Qga2V5ID0gandrcy5rZXlzLmZpbmQoKGspID0+IGsua2lkID09PSBqd3QuaGVhZGVyLmtpZCk7XG4gICAgaWYgKGtleSA9PT0gdm9pZCAwKSB7XG4gICAgICAgIHRocm93IG5ldyBPQXV0aEVycm9yKHtcbiAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfandrc1wiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiTm8ga2V5IGZvdW5kIGZvciB0b2tlbiBpbiBKV0tTXCIsXG4gICAgICAgICAgICBtZXNzYWdlOiBcIk5vIGtleSBmb3VuZCBmb3IgdG9rZW4gaW4gSldLU1wiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjb25zdCBhbGdvcml0aG0gPSB7XG4gICAgICAgIG5hbWU6IFwiUlNBU1NBLVBLQ1MxLXYxXzVcIixcbiAgICAgICAgaGFzaDogeyBuYW1lOiBcIlNIQS0yNTZcIiB9XG4gICAgfTtcbiAgICBjb25zdCBwdWJsaWNLZXkgPSBhd2FpdCB3aW5kb3cuY3J5cHRvLnN1YnRsZS5pbXBvcnRLZXkoXCJqd2tcIiwge1xuICAgICAgICBrdHk6IGtleS5rdHksXG4gICAgICAgIG46IGtleS5uLFxuICAgICAgICBlOiBrZXkuZSxcbiAgICAgICAgYWxnOiBrZXkuYWxnLFxuICAgICAgICB1c2U6IGtleS51c2VcbiAgICB9LCBhbGdvcml0aG0sIHRydWUsIFtcInZlcmlmeVwiXSk7XG4gICAgY29uc3QgW2hlYWRlciwgcGF5bG9hZCwgc2lnXSA9IHRva2VuLnNwbGl0KFwiLlwiKTtcbiAgICBpZiAoaGVhZGVyID09PSB2b2lkIDAgfHwgcGF5bG9hZCA9PT0gdm9pZCAwIHx8IHNpZyA9PT0gdm9pZCAwKSB7XG4gICAgICAgIHRocm93IG5ldyBPQXV0aEVycm9yKHtcbiAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfdG9rZW5cIixcbiAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBcIk1hbGZvcm1lZCB0b2tlblwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJNYWxmb3JtZWQgdG9rZW5cIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgZGF0YSA9IGAke2hlYWRlcn0uJHtwYXlsb2FkfWA7XG4gICAgY29uc3QgaXNWYWxpZCA9IGF3YWl0IHdpbmRvdy5jcnlwdG8uc3VidGxlLnZlcmlmeShhbGdvcml0aG0sIHB1YmxpY0tleSwgc3RyaW5nVG9CdWZmZXIoYmFzZTY0VXJsVG9TdHJpbmcoc2lnKSksIHN0cmluZ1RvQnVmZmVyKGRhdGEpKTtcbiAgICBpZiAoIWlzVmFsaWQpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiSW52YWxpZCBzaWduYXR1cmVcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiSW52YWxpZCBzaWduYXR1cmVcIlxuICAgICAgICB9KTtcbiAgICB9XG59O1xuY29uc3QgdmVyaWZ5QWNjZXNzVG9rZW5UaW1lc3RhbXBzID0gKGRlY29kZWQsIGNsYWltcykgPT4ge1xuICAgIGNvbnN0IGxvY2FsVGltZSA9IE1hdGguZmxvb3IoRGF0ZS5ub3coKSAvIDFlMyk7XG4gICAgY29uc3Qgbm9ybWFsaXNlZFRpbWUgPSBsb2NhbFRpbWUgLSBkZWNvZGVkLmNsb2NrU2tldztcbiAgICBpZiAoIWNsYWltcy5pYXQgfHwgIWNsYWltcy5leHApIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiTWlzc2luZyBpYXQgb3IgZXhwIGNsYWltIGluIGFjY2VzcyB0b2tlblwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJUb2tlbiBkb2VzIG5vdCBjb250YWluIHJlcXVpcmVkIGNsYWltc1wiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoY2xhaW1zLmlhdCA+IGNsYWltcy5leHApIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF90b2tlblwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiaWF0IGNsYWltIGlzIGFmdGVyIGV4cCBjbGFpbSBpbiBhY2Nlc3MgdG9rZW5cIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiVG9rZW4gaGFzIGV4cGlyZWQgYmVmb3JlIGl0IHdhcyBpc3N1ZWRcIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgaWYgKG5vcm1hbGlzZWRUaW1lID4gY2xhaW1zLmV4cCkge1xuICAgICAgICB0aHJvdyBuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICBlcnJvcjogXCJpbnZhbGlkX3Rva2VuXCIsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJUb2tlbiBoYXMgZXhwaXJlZFwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJUb2tlbiBoYXMgZXhwaXJlZFwiXG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBpZiAoY2xhaW1zLmlhdCA+IG5vcm1hbGlzZWRUaW1lKSB7XG4gICAgICAgIHRocm93IG5ldyBPQXV0aEVycm9yKHtcbiAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfdG9rZW5cIixcbiAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBcIlRva2VuIHdhcyBpc3N1ZWQgaW4gdGhlIGZ1dHVyZVwiLFxuICAgICAgICAgICAgbWVzc2FnZTogXCJUb2tlbiB3YXMgaXNzdWVkIGluIHRoZSBmdXR1cmVcIlxuICAgICAgICB9KTtcbiAgICB9XG59O1xuY29uc3QgYWRkUG9zdE1lc3NhZ2VMaXN0ZW5lciA9IChvcHRzLCBzdGF0ZSkgPT4ge1xuICAgIGxldCByZXNwb25zZUhhbmRsZXI7XG4gICAgbGV0IHRpbWVvdXRJZDtcbiAgICBjb25zdCBtc2dSZWNlaXZlZE9yVGltZW91dCA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgcmVzcG9uc2VIYW5kbGVyID0gKGUpID0+IHtcbiAgICAgICAgICAgIGlmIChlLmRhdGEuc3RhdGUgIT09IHN0YXRlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGUub3JpZ2luICE9PSBvcHRzLmlzc3Vlci5zcGxpdChcIi9vYXV0aDIvXCIpWzBdKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHJlamVjdChuZXcgT0F1dGhFcnJvcih7XG4gICAgICAgICAgICAgICAgICAgIGVycm9yOiBcImludmFsaWRfb3JpZ2luXCIsXG4gICAgICAgICAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBcIkludmFsaWQgb3JpZ2luXCIsXG4gICAgICAgICAgICAgICAgICAgIG1lc3NhZ2U6IFwiVGhlIHJlcXVlc3QgZG9lcyBub3Qgb3JpZ2luYXRlIGZyb20gdGhlIGlzc3VlclwiXG4gICAgICAgICAgICAgICAgfSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHJlc29sdmUoZS5kYXRhKTtcbiAgICAgICAgfTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJtZXNzYWdlXCIsIHJlc3BvbnNlSGFuZGxlcik7XG4gICAgICAgIHRpbWVvdXRJZCA9IHdpbmRvdy5zZXRUaW1lb3V0KCgpID0+IHtcbiAgICAgICAgICAgIHJldHVybiByZWplY3QobmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgICAgIGVycm9yOiBcInRpbWVvdXRcIixcbiAgICAgICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogXCJUaW1lb3V0XCIsXG4gICAgICAgICAgICAgICAgbWVzc2FnZTogXCJUaGUgb2F1dGggcmVxdWVzdCB0aW1lZCBvdXRcIlxuICAgICAgICAgICAgfSkpO1xuICAgICAgICB9LCBvcHRzLm9hdXRoVGltZW91dCk7XG4gICAgfSk7XG4gICAgcmV0dXJuIG1zZ1JlY2VpdmVkT3JUaW1lb3V0LmZpbmFsbHkoKCkgPT4ge1xuICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVvdXRJZCk7XG4gICAgICAgIHdpbmRvdy5yZW1vdmVFdmVudExpc3RlbmVyKFwibWVzc2FnZVwiLCByZXNwb25zZUhhbmRsZXIpO1xuICAgIH0pO1xufTtcbmNvbnN0IGxvYWRGcmFtZSA9ICh1cmwpID0+IHtcbiAgICBjb25zdCBmcmFtZSA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoXCJpZnJhbWVcIik7XG4gICAgZnJhbWUuc3R5bGUuZGlzcGxheSA9IFwibm9uZVwiO1xuICAgIGZyYW1lLnNyYyA9IHVybDtcbiAgICByZXR1cm4gZG9jdW1lbnQuYm9keS5hcHBlbmRDaGlsZChmcmFtZSk7XG59O1xuY29uc3QgcGVyZm9ybUF1dGhDb2RlRmxvd0lmcmFtZSA9IGFzeW5jIChhdXRob3JpemVQYXJhbXMsIG9wdGlvbnMsIG9hdXRoVXJscykgPT4ge1xuICAgIGNvbnN0IHNlYXJjaFBhcmFtcyA9IG5ldyBVUkxTZWFyY2hQYXJhbXMoYXV0aG9yaXplUGFyYW1zKTtcbiAgICBjb25zdCBwb3N0TWVzc2FnZUxpc3RlbmVyID0gYWRkUG9zdE1lc3NhZ2VMaXN0ZW5lcihvcHRpb25zLCBhdXRob3JpemVQYXJhbXMuc3RhdGUpO1xuICAgIGNvbnN0IGlmcmFtZSA9IGxvYWRGcmFtZShgJHtvYXV0aFVybHMuYXV0aG9yaXplVXJsfT8ke3NlYXJjaFBhcmFtcy50b1N0cmluZygpfWApO1xuICAgIGNvbnN0IGF1dGhvcml6ZVJlc3BvbnNlID0gYXdhaXQgcG9zdE1lc3NhZ2VMaXN0ZW5lci5maW5hbGx5KCgpID0+IHtcbiAgICAgICAgaWYgKGRvY3VtZW50LmJvZHkuY29udGFpbnMoaWZyYW1lKSkge1xuICAgICAgICAgICAgZG9jdW1lbnQuYm9keS5yZW1vdmVDaGlsZChpZnJhbWUpO1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIGF1dGhvcml6ZVJlc3BvbnNlO1xufTtcbmNvbnN0IG1lbW9pemVkVmVyaWZ5VG9rZW5zID0gLyogQF9fUFVSRV9fICovIG5ldyBNYXAoKTtcbmNvbnN0IHZlcmlmeVRva2VucyA9IGFzeW5jIChpZFRva2VuLCBhY2Nlc3NUb2tlbiwgb3B0aW9ucywgb2F1dGhVcmxzKSA9PiB7XG4gICAgaWYgKG1lbW9pemVkVmVyaWZ5VG9rZW5zLmhhcyhpZFRva2VuLmNsYWltcy5qdGkpKSB7XG4gICAgICAgIGNvbnN0IG1lbW9pemVkID0gbWVtb2l6ZWRWZXJpZnlUb2tlbnMuZ2V0KGlkVG9rZW4uY2xhaW1zLmp0aSk7XG4gICAgICAgIGlmIChtZW1vaXplZCA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHRocm93IG1lbW9pemVkO1xuICAgIH1cbiAgICB0cnkge1xuICAgICAgICBjb25zdCBpZFRva2VuSldUID0gZGVjb2RlVG9rZW4oaWRUb2tlbi5pZFRva2VuKTtcbiAgICAgICAgdmVyaWZ5SWRUb2tlbkNsYWltcyhpZFRva2VuLCBpZFRva2VuSldULnBheWxvYWQsIG9wdGlvbnMpO1xuICAgICAgICBhd2FpdCB2ZXJpZnlTaWduYXR1cmUob2F1dGhVcmxzLmtleXNVcmwsIGlkVG9rZW5KV1QsIGlkVG9rZW4uaWRUb2tlbik7XG4gICAgICAgIGF3YWl0IHZlcmlmeUFjY2Vzc1Rva2VuV2l0aEF0SGFzaChpZFRva2VuLmNsYWltcy5hdF9oYXNoLCBhY2Nlc3NUb2tlbi5hY2Nlc3NUb2tlbik7XG4gICAgICAgIGNvbnN0IGFjY2Vzc1Rva2VuSldUID0gZGVjb2RlVG9rZW4oYWNjZXNzVG9rZW4uYWNjZXNzVG9rZW4pO1xuICAgICAgICB2ZXJpZnlBY2Nlc3NUb2tlblRpbWVzdGFtcHMoYWNjZXNzVG9rZW4sIGFjY2Vzc1Rva2VuSldULnBheWxvYWQpO1xuICAgICAgICBtZW1vaXplZFZlcmlmeVRva2Vucy5zZXQoaWRUb2tlbi5jbGFpbXMuanRpLCB0cnVlKTtcbiAgICB9XG4gICAgY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIG1lbW9pemVkVmVyaWZ5VG9rZW5zLnNldChpZFRva2VuLmNsYWltcy5qdGksIGVycm9yKTtcbiAgICAgICAgdGhyb3cgZXJyb3I7XG4gICAgfVxufTtcbmNvbnN0IGV4Y2hhbmdlQ29kZUZvclRva2VucyA9IGFzeW5jIChjb2RlLCBjb2RlVmVyaWZpZXIsIG9wdGlvbnMsIG9hdXRoVXJscykgPT4ge1xuICAgIGNvbnN0IHRva2VuUGFyYW1zID0ge1xuICAgICAgICBjbGllbnRfaWQ6IG9wdGlvbnMuY2xpZW50SWQsXG4gICAgICAgIGNvZGUsXG4gICAgICAgIGNvZGVfdmVyaWZpZXI6IGNvZGVWZXJpZmllcixcbiAgICAgICAgZ3JhbnRfdHlwZTogXCJhdXRob3JpemF0aW9uX2NvZGVcIixcbiAgICAgICAgcmVkaXJlY3RfdXJpOiBvcHRpb25zLnJlZGlyZWN0VXJpXG4gICAgfTtcbiAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKG9hdXRoVXJscy50b2tlblVybCwge1xuICAgICAgICBtZXRob2Q6IFwiUE9TVFwiLFxuICAgICAgICBib2R5OiBuZXcgVVJMU2VhcmNoUGFyYW1zKHRva2VuUGFyYW1zKSxcbiAgICAgICAgaGVhZGVyczoge1xuICAgICAgICAgICAgXCJDb250ZW50LVR5cGVcIjogXCJhcHBsaWNhdGlvbi94LXd3dy1mb3JtLXVybGVuY29kZWRcIlxuICAgICAgICB9XG4gICAgfSk7XG4gICAgcmV0dXJuIHJlc3BvbnNlLmpzb24oKTtcbn07XG5jb25zdCBoYW5kbGVPQXV0aFJlc3BvbnNlID0gYXN5bmMgKG9hdXRoVG9rZW5SZXNwb25zZSwgYXV0aG9yaXplUGFyYW1zLCBvcHRpb25zLCBvYXV0aFVybHMpID0+IHtcbiAgICBjb25zdCB7IGFjY2Vzc190b2tlbiwgaWRfdG9rZW4gfSA9IG9hdXRoVG9rZW5SZXNwb25zZTtcbiAgICBjb25zdCBub3cgPSBNYXRoLmZsb29yKERhdGUubm93KCkgLyAxZTMpO1xuICAgIGNvbnN0IGFjY2Vzc1Rva2VuQ2xvY2tTa2V3ID0gY2FsY3VsYXRlQ2xvY2tTa2V3KG5vdywgYWNjZXNzX3Rva2VuKTtcbiAgICBjb25zdCBpZFRva2VuQ2xvY2tTa2V3ID0gY2FsY3VsYXRlQ2xvY2tTa2V3KG5vdywgaWRfdG9rZW4pO1xuICAgIGNvbnN0IHsgYWNjZXNzVG9rZW4sIGlkVG9rZW4gfSA9IGRlY29kZVRva2Vucyh7XG4gICAgICAgIGFjY2Vzc1Rva2VuUmF3OiBhY2Nlc3NfdG9rZW4sXG4gICAgICAgIGFjY2Vzc1Rva2VuQ2xvY2tTa2V3LFxuICAgICAgICBpZFRva2VuUmF3OiBpZF90b2tlbixcbiAgICAgICAgaWRUb2tlbkNsb2NrU2tldyxcbiAgICAgICAgbm9uY2U6IGF1dGhvcml6ZVBhcmFtcy5ub25jZSxcbiAgICAgICAgb3B0aW9uc1xuICAgIH0pO1xuICAgIGF3YWl0IHZlcmlmeVRva2VucyhpZFRva2VuLCBhY2Nlc3NUb2tlbiwgb3B0aW9ucywgb2F1dGhVcmxzKTtcbiAgICByZXR1cm4ge1xuICAgICAgICBzdGF0ZTogYXV0aG9yaXplUGFyYW1zLnN0YXRlLFxuICAgICAgICB0b2tlbnM6IHtcbiAgICAgICAgICAgIGFjY2Vzc1Rva2VuLFxuICAgICAgICAgICAgaWRUb2tlblxuICAgICAgICB9XG4gICAgfTtcbn07XG5jbGFzcyBUb2tlbiB7XG4gICAgY29uc3RydWN0b3Iob3B0aW9ucywgb2F1dGhVcmxzKSB7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfVG9rZW5faW5zdGFuY2VzKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9vcHRpb25zKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9vYXV0aFVybHMpO1xuICAgICAgICAvLyBob2xkZXIgaWYgdGhlcmUgaXMgY3VycmVudGx5IGEgZ2V0IHRva2VuIGZsb3cgaW4gcHJvZ3Jlc3NcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9nZXRUb2tlbnNJblByb2dyZXNzKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9leGNoYW5nZUNvZGVGb3JUb2tlbnMsIChjb2RlLCBjb2RlVmVyaWZpZXIpID0+IGV4Y2hhbmdlQ29kZUZvclRva2Vucyhjb2RlLCBjb2RlVmVyaWZpZXIsIF9fcHJpdmF0ZUdldCh0aGlzLCBfb3B0aW9ucyksIF9fcHJpdmF0ZUdldCh0aGlzLCBfb2F1dGhVcmxzKSkpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2hhbmRsZU9BdXRoUmVzcG9uc2UsIChvYXV0aFRva2VuUmVzcG9uc2UsIGF1dGhvcml6ZVBhcmFtcykgPT4gaGFuZGxlT0F1dGhSZXNwb25zZShvYXV0aFRva2VuUmVzcG9uc2UsIGF1dGhvcml6ZVBhcmFtcywgX19wcml2YXRlR2V0KHRoaXMsIF9vcHRpb25zKSwgX19wcml2YXRlR2V0KHRoaXMsIF9vYXV0aFVybHMpKSk7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfcGVyZm9ybUF1dGhDb2RlRmxvd0lmcmFtZSwgKGF1dGhvcml6ZVBhcmFtcykgPT4gcGVyZm9ybUF1dGhDb2RlRmxvd0lmcmFtZShhdXRob3JpemVQYXJhbXMsIF9fcHJpdmF0ZUdldCh0aGlzLCBfb3B0aW9ucyksIF9fcHJpdmF0ZUdldCh0aGlzLCBfb2F1dGhVcmxzKSkpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX29wdGlvbnMsIG9wdGlvbnMpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX29hdXRoVXJscywgb2F1dGhVcmxzKTtcbiAgICAgICAgX19wcml2YXRlU2V0KHRoaXMsIF9nZXRUb2tlbnNJblByb2dyZXNzLCB2b2lkIDApO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAbmFtZSBnZXRXaXRob3V0UHJvbXB0XG4gICAgICogQGRlc2NyaXB0aW9uIFBlcmZvcm1zIHRoZSBBdXRob3JpemF0aW9uIENvZGUgRmxvdyB3aXRoIFBLQ0UsIGV4Y2hhbmdpbmcgdGhlIGF1dGhvcml6YXRpb24gY29kZSBmb3IgdG9rZW5zIGFuZCB2ZXJpZnlpbmcgdGhlIElEIHRva2VuLCB3aXRob3V0IHByb21wdGluZyB0aGUgdXNlciBhbmQgdXNpbmcgYSBoaWRkZW4gaWZyYW1lXG4gICAgICogQHJldHVybnMgUHJvbWlzZTxUb2tlblJlc3BvbnNlPiAtIHJlc29sdmVzIHdpdGggdGhlIGFjY2VzcyBhbmQgSUQgdG9rZW5zXG4gICAgICovXG4gICAgYXN5bmMgZ2V0V2l0aG91dFByb21wdCgpIHtcbiAgICAgICAgaWYgKF9fcHJpdmF0ZUdldCh0aGlzLCBfZ2V0VG9rZW5zSW5Qcm9ncmVzcykpIHtcbiAgICAgICAgICAgIHJldHVybiBfX3ByaXZhdGVHZXQodGhpcywgX2dldFRva2Vuc0luUHJvZ3Jlc3MpO1xuICAgICAgICB9XG4gICAgICAgIF9fcHJpdmF0ZVNldCh0aGlzLCBfZ2V0VG9rZW5zSW5Qcm9ncmVzcywgX19wcml2YXRlTWV0aG9kKHRoaXMsIF9Ub2tlbl9pbnN0YW5jZXMsIGdldFdpdGhvdXRQcm9tcHRfZm4pLmNhbGwodGhpcykuZmluYWxseSgoKSA9PiB7XG4gICAgICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX2dldFRva2Vuc0luUHJvZ3Jlc3MsIHZvaWQgMCk7XG4gICAgICAgIH0pKTtcbiAgICAgICAgcmV0dXJuIF9fcHJpdmF0ZUdldCh0aGlzLCBfZ2V0VG9rZW5zSW5Qcm9ncmVzcyk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBuYW1lIHZlcmlmeVRva2Vuc1xuICAgICAqIEBkZXNjcmlwdGlvbiBWZXJpZmllcyB0aGUgSUQgdG9rZW4sIGNoZWNraW5nIHRoZSBzaWduYXR1cmUgYW5kIGNsYWltcywgYW5kIHZlcmlmaWVzIHRoZSBhY2Nlc3MgdG9rZW4gdXNpbmcgdGhlIGF0X2hhc2ggY2xhaW1cbiAgICAgKlxuICAgICAqIEBwYXJhbSBpZFRva2VuIC0gSUQgdG9rZW4gdG8gdmVyaWZ5XG4gICAgICogQHBhcmFtIGFjY2Vzc1Rva2VuIC0gQWNjZXNzIHRva2VuIHRvIHZlcmlmeVxuICAgICAqIEByZXR1cm5zIHZvaWRcbiAgICAgKi9cbiAgICBhc3luYyB2ZXJpZnlUb2tlbnMoaWRUb2tlbiwgYWNjZXNzVG9rZW4pIHtcbiAgICAgICAgcmV0dXJuIHZlcmlmeVRva2VucyhpZFRva2VuLCBhY2Nlc3NUb2tlbiwgX19wcml2YXRlR2V0KHRoaXMsIF9vcHRpb25zKSwgX19wcml2YXRlR2V0KHRoaXMsIF9vYXV0aFVybHMpKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQG5hbWUgZGVjb2RlVG9rZW5zXG4gICAgICogQGRlc2NyaXB0aW9uIERlY29kZXMgdGhlIGFjY2VzcyBhbmQgSUQgdG9rZW5zLCByZXR1cm5pbmcgdGhlIGRlY29kZWQgY2xhaW1zLCB3aXRob3V0IHZlcmlmeWluZyB0aGUgdG9rZW5zXG4gICAgICpcbiAgICAgKiBAcGFyYW0gYWNjZXNzVG9rZW4gLSBSYXcgYWNjZXNzIHRva2VuIHN0cmluZyB0byBkZWNvZGVcbiAgICAgKiBAcGFyYW0gaWRUb2tlbiAtIFJhdyBJRCB0b2tlbiBzdHJpbmcgdG8gZGVjb2RlXG4gICAgICogQHBhcmFtIG5vbmNlIC0gTm9uY2UgdXNlZCB3aGVuIGdlbmVyYXRpbmcgdGhlIHRva2Vuc1xuICAgICAqXG4gICAgICogQHJldHVybnMgVG9rZW5zIC0gZGVjb2RlZCBhY2Nlc3MgYW5kIElEIHRva2Vuc1xuICAgICAqL1xuICAgIGRlY29kZVRva2Vucyh7IGFjY2Vzc1Rva2VuUmF3LCBhY2Nlc3NUb2tlbkNsb2NrU2tldywgaWRUb2tlblJhdywgaWRUb2tlbkNsb2NrU2tldywgbm9uY2UgfSkge1xuICAgICAgICByZXR1cm4gZGVjb2RlVG9rZW5zKHtcbiAgICAgICAgICAgIGFjY2Vzc1Rva2VuUmF3LFxuICAgICAgICAgICAgYWNjZXNzVG9rZW5DbG9ja1NrZXcsXG4gICAgICAgICAgICBpZFRva2VuUmF3LFxuICAgICAgICAgICAgaWRUb2tlbkNsb2NrU2tldyxcbiAgICAgICAgICAgIG5vbmNlLFxuICAgICAgICAgICAgb3B0aW9uczogX19wcml2YXRlR2V0KHRoaXMsIF9vcHRpb25zKVxuICAgICAgICB9KTtcbiAgICB9XG59XG5fb3B0aW9ucyA9IG5ldyBXZWFrTWFwKCk7XG5fb2F1dGhVcmxzID0gbmV3IFdlYWtNYXAoKTtcbl9nZXRUb2tlbnNJblByb2dyZXNzID0gbmV3IFdlYWtNYXAoKTtcbl9leGNoYW5nZUNvZGVGb3JUb2tlbnMgPSBuZXcgV2Vha01hcCgpO1xuX2hhbmRsZU9BdXRoUmVzcG9uc2UgPSBuZXcgV2Vha01hcCgpO1xuX3BlcmZvcm1BdXRoQ29kZUZsb3dJZnJhbWUgPSBuZXcgV2Vha01hcCgpO1xuX1Rva2VuX2luc3RhbmNlcyA9IG5ldyBXZWFrU2V0KCk7XG5nZXRXaXRob3V0UHJvbXB0X2ZuID0gYXN5bmMgZnVuY3Rpb24gKCkge1xuICAgIGNvbnN0IGNvZGVWZXJpZmllciA9IGdlbmVyYXRlQ29kZVZlcmlmaWVyKCk7XG4gICAgY29uc3QgY29kZUNoYWxsZW5nZSA9IGF3YWl0IGdlbmVyYXRlQ29kZUNoYWxsZW5nZShjb2RlVmVyaWZpZXIpO1xuICAgIGNvbnN0IGF1dGhvcml6ZVBhcmFtcyA9IHtcbiAgICAgICAgY2xpZW50X2lkOiBfX3ByaXZhdGVHZXQodGhpcywgX29wdGlvbnMpLmNsaWVudElkLFxuICAgICAgICBjb2RlX2NoYWxsZW5nZTogY29kZUNoYWxsZW5nZSxcbiAgICAgICAgY29kZV9jaGFsbGVuZ2VfbWV0aG9kOiBcIlMyNTZcIixcbiAgICAgICAgcHJvbXB0OiBcIm5vbmVcIixcbiAgICAgICAgbm9uY2U6IGdldFJhbmRvbVN0cmluZygxNiksXG4gICAgICAgIHJlZGlyZWN0X3VyaTogX19wcml2YXRlR2V0KHRoaXMsIF9vcHRpb25zKS5yZWRpcmVjdFVyaSxcbiAgICAgICAgcmVzcG9uc2VfdHlwZTogXCJjb2RlXCIsXG4gICAgICAgIHJlc3BvbnNlX21vZGU6IFwib2t0YV9wb3N0X21lc3NhZ2VcIixcbiAgICAgICAgc2NvcGU6IF9fcHJpdmF0ZUdldCh0aGlzLCBfb3B0aW9ucykuc2NvcGVzLmpvaW4oXCIgXCIpLFxuICAgICAgICBzdGF0ZTogZ2V0UmFuZG9tU3RyaW5nKDQyKVxuICAgIH07XG4gICAgY29uc3QgYXV0aG9yaXplUmVzcG9uc2UgPSBhd2FpdCBfX3ByaXZhdGVHZXQodGhpcywgX3BlcmZvcm1BdXRoQ29kZUZsb3dJZnJhbWUpLmNhbGwodGhpcywgYXV0aG9yaXplUGFyYW1zKTtcbiAgICBpZiAoaXNPQXV0aEF1dGhvcml6ZVJlc3BvbnNlRXJyb3IoYXV0aG9yaXplUmVzcG9uc2UpKSB7XG4gICAgICAgIHRocm93IG5ldyBPQXV0aEVycm9yKHtcbiAgICAgICAgICAgIGVycm9yOiBhdXRob3JpemVSZXNwb25zZS5lcnJvcixcbiAgICAgICAgICAgIGVycm9yX2Rlc2NyaXB0aW9uOiBhdXRob3JpemVSZXNwb25zZS5lcnJvcl9kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBPQXV0aCBBdXRob3JpemUgRXJyb3IgfCAke2F1dGhvcml6ZVJlc3BvbnNlLmVycm9yfSB8ICR7YXV0aG9yaXplUmVzcG9uc2UuZXJyb3JfZGVzY3JpcHRpb259YFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgeyBjb2RlLCBzdGF0ZSB9ID0gYXV0aG9yaXplUmVzcG9uc2U7XG4gICAgaWYgKHN0YXRlICE9PSBhdXRob3JpemVQYXJhbXMuc3RhdGUpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IFwiaW52YWxpZF9zdGF0ZVwiLFxuICAgICAgICAgICAgZXJyb3JfZGVzY3JpcHRpb246IFwiSW52YWxpZCBzdGF0ZSBwYXJhbWV0ZXJcIixcbiAgICAgICAgICAgIG1lc3NhZ2U6IFwiSW52YWxpZCBzdGF0ZSBwYXJhbWV0ZXJcIlxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgdG9rZW5SZXNwb25zZSA9IGF3YWl0IF9fcHJpdmF0ZUdldCh0aGlzLCBfZXhjaGFuZ2VDb2RlRm9yVG9rZW5zKS5jYWxsKHRoaXMsIGNvZGUsIGNvZGVWZXJpZmllcik7XG4gICAgaWYgKGlzT0F1dGhUb2tlblJlc3BvbnNlRXJyb3IodG9rZW5SZXNwb25zZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IE9BdXRoRXJyb3Ioe1xuICAgICAgICAgICAgZXJyb3I6IHRva2VuUmVzcG9uc2UuZXJyb3IsXG4gICAgICAgICAgICBlcnJvcl9kZXNjcmlwdGlvbjogdG9rZW5SZXNwb25zZS5lcnJvcl9kZXNjcmlwdGlvbixcbiAgICAgICAgICAgIG1lc3NhZ2U6IGBPQXV0aCBUb2tlbiBFcnJvciB8ICR7dG9rZW5SZXNwb25zZS5lcnJvcn0gfCAke3Rva2VuUmVzcG9uc2UuZXJyb3JfZGVzY3JpcHRpb259YFxuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3QgcGFyc2VkID0gYXdhaXQgX19wcml2YXRlR2V0KHRoaXMsIF9oYW5kbGVPQXV0aFJlc3BvbnNlKS5jYWxsKHRoaXMsIHRva2VuUmVzcG9uc2UsIGF1dGhvcml6ZVBhcmFtcyk7XG4gICAgcmV0dXJuIHBhcnNlZDtcbn07XG5leHBvcnQgeyBUb2tlbiwgYWRkUG9zdE1lc3NhZ2VMaXN0ZW5lciwgZXhjaGFuZ2VDb2RlRm9yVG9rZW5zLCBoYW5kbGVPQXV0aFJlc3BvbnNlLCBpc0FjY2Vzc1Rva2VuLCBpc0lEVG9rZW4sIGxvYWRGcmFtZSwgcGVyZm9ybUF1dGhDb2RlRmxvd0lmcmFtZSwgdmVyaWZ5QWNjZXNzVG9rZW5UaW1lc3RhbXBzLCB2ZXJpZnlBY2Nlc3NUb2tlbldpdGhBdEhhc2gsIHZlcmlmeUlkVG9rZW5DbGFpbXMsIHZlcmlmeVNpZ25hdHVyZSwgdmVyaWZ5VG9rZW5zIH07XG4iLCJpbXBvcnQgeyBzdG9yYWdlIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgaXNBY2Nlc3NUb2tlbiwgaXNJRFRva2VuIH0gZnJvbSAnLi90b2tlbi5qcyc7XG52YXIgX190eXBlRXJyb3IgPSAobXNnKSA9PiB7XG4gICAgdGhyb3cgVHlwZUVycm9yKG1zZyk7XG59O1xudmFyIF9fYWNjZXNzQ2hlY2sgPSAob2JqLCBtZW1iZXIsIG1zZykgPT4gbWVtYmVyLmhhcyhvYmopIHx8IF9fdHlwZUVycm9yKFwiQ2Fubm90IFwiICsgbXNnKTtcbnZhciBfX3ByaXZhdGVHZXQgPSAob2JqLCBtZW1iZXIsIGdldHRlcikgPT4gKF9fYWNjZXNzQ2hlY2sob2JqLCBtZW1iZXIsIFwicmVhZCBmcm9tIHByaXZhdGUgZmllbGRcIiksIG1lbWJlci5nZXQob2JqKSk7XG52YXIgX19wcml2YXRlQWRkID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSkgPT4gbWVtYmVyLmhhcyhvYmopID8gX190eXBlRXJyb3IoXCJDYW5ub3QgYWRkIHRoZSBzYW1lIHByaXZhdGUgbWVtYmVyIG1vcmUgdGhhbiBvbmNlXCIpIDogbWVtYmVyIGluc3RhbmNlb2YgV2Vha1NldCA/IG1lbWJlci5hZGQob2JqKSA6IG1lbWJlci5zZXQob2JqLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlU2V0ID0gKG9iaiwgbWVtYmVyLCB2YWx1ZSwgc2V0dGVyKSA9PiAoX19hY2Nlc3NDaGVjayhvYmosIG1lbWJlciwgXCJ3cml0ZSB0byBwcml2YXRlIGZpZWxkXCIpLCBtZW1iZXIuc2V0KG9iaiwgdmFsdWUpLCB2YWx1ZSk7XG52YXIgX19wcml2YXRlTWV0aG9kID0gKG9iaiwgbWVtYmVyLCBtZXRob2QpID0+IChfX2FjY2Vzc0NoZWNrKG9iaiwgbWVtYmVyLCBcImFjY2VzcyBwcml2YXRlIG1ldGhvZFwiKSwgbWV0aG9kKTtcbnZhciBfdG9rZW4sIF9lbWl0dGVyLCBfc3RvcmFnZSwgX2FjY2Vzc1Rva2VuS2V5LCBfaWRUb2tlbktleSwgX1Rva2VuTWFuYWdlcl9pbnN0YW5jZXMsIGVtaXRBZGRlZF9mbiwgZW1pdFJlbW92ZWRfZm4sIGVtaXRTdG9yYWdlX2ZuO1xuY2xhc3MgVG9rZW5NYW5hZ2VyIHtcbiAgICBjb25zdHJ1Y3RvcihlbWl0dGVyLCB0b2tlbkNsYXNzKSB7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfVG9rZW5NYW5hZ2VyX2luc3RhbmNlcyk7XG4gICAgICAgIF9fcHJpdmF0ZUFkZCh0aGlzLCBfdG9rZW4pO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2VtaXR0ZXIpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX3N0b3JhZ2UsIHN0b3JhZ2UubG9jYWwpO1xuICAgICAgICBfX3ByaXZhdGVBZGQodGhpcywgX2FjY2Vzc1Rva2VuS2V5LCBcImd1LmFjY2Vzc190b2tlblwiKTtcbiAgICAgICAgX19wcml2YXRlQWRkKHRoaXMsIF9pZFRva2VuS2V5LCBcImd1LmlkX3Rva2VuXCIpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX2VtaXR0ZXIsIGVtaXR0ZXIpO1xuICAgICAgICBfX3ByaXZhdGVTZXQodGhpcywgX3Rva2VuLCB0b2tlbkNsYXNzKTtcbiAgICAgICAgd2luZG93LmFkZEV2ZW50TGlzdGVuZXIoXCJzdG9yYWdlXCIsIChldmVudCkgPT4ge1xuICAgICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gX19wcml2YXRlR2V0KHRoaXMsIF9hY2Nlc3NUb2tlbktleSkgfHwgZXZlbnQua2V5ID09PSBfX3ByaXZhdGVHZXQodGhpcywgX2lkVG9rZW5LZXkpKSB7XG4gICAgICAgICAgICAgICAgX19wcml2YXRlTWV0aG9kKHRoaXMsIF9Ub2tlbk1hbmFnZXJfaW5zdGFuY2VzLCBlbWl0U3RvcmFnZV9mbikuY2FsbCh0aGlzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfZW1pdHRlcikub24oXCJyZW5ld1wiLCBhc3luYyAoKSA9PiB7XG4gICAgICAgICAgICBhd2FpdCB0aGlzLnJlbmV3KCk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAbmFtZSBzZXRUb2tlbnNcbiAgICAgKiBAZGVzY3JpcHRpb24gU2V0cyB0aGUgdG9rZW5zIGluIHN0b3JhZ2UgYW5kIGVtaXRzIGFuIGV2ZW50XG4gICAgICogQHBhcmFtIHRva2VucyAtIFRoZSB0b2tlbnMgdG8gc2V0XG4gICAgICogQHJldHVybnMgdm9pZFxuICAgICAqL1xuICAgIHNldFRva2Vucyh0b2tlbnMpIHtcbiAgICAgICAgY29uc3QgdG9rZW5UeXBlcyA9IFtcImFjY2Vzc1Rva2VuXCIsIFwiaWRUb2tlblwiXTtcbiAgICAgICAgY29uc3QgZXhpc3RpbmdUb2tlbnMgPSB0aGlzLmdldFRva2Vuc1N5bmMoKTtcbiAgICAgICAgY29uc3QgYWNjZXNzVG9rZW5TdG9yYWdlID0ge1xuICAgICAgICAgICAgYWNjZXNzVG9rZW46IHRva2Vucy5hY2Nlc3NUb2tlbi5hY2Nlc3NUb2tlbixcbiAgICAgICAgICAgIGNsb2NrU2tldzogdG9rZW5zLmFjY2Vzc1Rva2VuLmNsb2NrU2tld1xuICAgICAgICB9O1xuICAgICAgICBjb25zdCBpZFRva2VuU3RvcmFnZSA9IHtcbiAgICAgICAgICAgIGlkVG9rZW46IHRva2Vucy5pZFRva2VuLmlkVG9rZW4sXG4gICAgICAgICAgICBub25jZTogdG9rZW5zLmlkVG9rZW4ubm9uY2UsXG4gICAgICAgICAgICBjbG9ja1NrZXc6IHRva2Vucy5pZFRva2VuLmNsb2NrU2tld1xuICAgICAgICB9O1xuICAgICAgICBfX3ByaXZhdGVHZXQodGhpcywgX3N0b3JhZ2UpLnNldChfX3ByaXZhdGVHZXQodGhpcywgX2FjY2Vzc1Rva2VuS2V5KSwgYWNjZXNzVG9rZW5TdG9yYWdlLCBuZXcgRGF0ZSh0b2tlbnMuYWNjZXNzVG9rZW4uZXhwaXJlc0F0ICogMWUzKSk7XG4gICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfc3RvcmFnZSkuc2V0KF9fcHJpdmF0ZUdldCh0aGlzLCBfaWRUb2tlbktleSksIGlkVG9rZW5TdG9yYWdlLCBcbiAgICAgICAgLy8gdXNlIGFjY2VzcyB0b2tlbiBleHBpcnkgYXMgaWQgdG9rZW4gZXhwaXJ5IGFzIGlkIHRva2VuIGlzIGFsd2F5cyAxIGhvdXJcbiAgICAgICAgLy8gd2hpbGUgdGhlIGFjY2VzcyB0b2tlbiBjYW4gYmUgYmV0d2VlbiA1IG1pbnMgYW5kIDI0IGhvdXJzXG4gICAgICAgIC8vIHRoZSBpZCB0b2tlbiBpcyByZWZyZXNoZWQgYXQgdGhlIHNhbWUgdGltZSBhcyB0aGUgYWNjZXNzIHRva2VuLCBhbmQgaXMgdGllZCB0b1xuICAgICAgICAvLyBhIGdpdmVuIGFjY2VzcyB0b2tlbiB1c2luZyB0aGUgYXRfaGFzaCBjbGFpbSwgc28gaXQgaXMgc2FmZSB0byB1c2UgdGhlIGFjY2VzcyB0b2tlbiBleHBpcnlcbiAgICAgICAgbmV3IERhdGUodG9rZW5zLmFjY2Vzc1Rva2VuLmV4cGlyZXNBdCAqIDFlMykpO1xuICAgICAgICB0b2tlblR5cGVzLmZvckVhY2goKHRva2VuVHlwZSkgPT4ge1xuICAgICAgICAgICAgY29uc3QgbmV3VG9rZW4gPSB0b2tlbnNbdG9rZW5UeXBlXTtcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nVG9rZW4gPSBleGlzdGluZ1Rva2Vucz8uW3Rva2VuVHlwZV07XG4gICAgICAgICAgICBpZiAoZXhpc3RpbmdUb2tlbikge1xuICAgICAgICAgICAgICAgIF9fcHJpdmF0ZU1ldGhvZCh0aGlzLCBfVG9rZW5NYW5hZ2VyX2luc3RhbmNlcywgZW1pdFJlbW92ZWRfZm4pLmNhbGwodGhpcywgdG9rZW5UeXBlLCBleGlzdGluZ1Rva2VuKTtcbiAgICAgICAgICAgICAgICBfX3ByaXZhdGVNZXRob2QodGhpcywgX1Rva2VuTWFuYWdlcl9pbnN0YW5jZXMsIGVtaXRBZGRlZF9mbikuY2FsbCh0aGlzLCB0b2tlblR5cGUsIG5ld1Rva2VuKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIF9fcHJpdmF0ZU1ldGhvZCh0aGlzLCBfVG9rZW5NYW5hZ2VyX2luc3RhbmNlcywgZW1pdEFkZGVkX2ZuKS5jYWxsKHRoaXMsIHRva2VuVHlwZSwgbmV3VG9rZW4pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQG5hbWUgZ2V0VG9rZW5zU3luY1xuICAgICAqIEBkZXNjcmlwdGlvbiBHZXRzIHRoZSB0b2tlbnMgZnJvbSBzdG9yYWdlIHN5bmNocm9ub3VzbHksIGRvZXMgbm90IHJlZnJlc2ggdG9rZW5zIG9yIHZlcmlmeSB0aGVtXG4gICAgICpcbiAgICAgKiBAcmV0dXJucyBUb2tlbnMgfCB1bmRlZmluZWQgLSBUaGUgdG9rZW5zIGlmIHRoZXkgZXhpc3RcbiAgICAgKi9cbiAgICBnZXRUb2tlbnNTeW5jKCkge1xuICAgICAgICBjb25zdCBhY2Nlc3NUb2tlbkZyb21TdG9yYWdlID0gX19wcml2YXRlR2V0KHRoaXMsIF9zdG9yYWdlKS5nZXQoX19wcml2YXRlR2V0KHRoaXMsIF9hY2Nlc3NUb2tlbktleSkpO1xuICAgICAgICBjb25zdCBpZFRva2VuRnJvbVN0b3JhZ2UgPSBfX3ByaXZhdGVHZXQodGhpcywgX3N0b3JhZ2UpLmdldChfX3ByaXZhdGVHZXQodGhpcywgX2lkVG9rZW5LZXkpKTtcbiAgICAgICAgaWYgKCFhY2Nlc3NUb2tlbkZyb21TdG9yYWdlPy5hY2Nlc3NUb2tlbiB8fCAhaWRUb2tlbkZyb21TdG9yYWdlPy5pZFRva2VuIHx8ICFpZFRva2VuRnJvbVN0b3JhZ2Uubm9uY2UpIHtcbiAgICAgICAgICAgIHJldHVybiB2b2lkIDA7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgeyBhY2Nlc3NUb2tlbiwgaWRUb2tlbiB9ID0gX19wcml2YXRlR2V0KHRoaXMsIF90b2tlbikuZGVjb2RlVG9rZW5zKHtcbiAgICAgICAgICAgIGFjY2Vzc1Rva2VuUmF3OiBhY2Nlc3NUb2tlbkZyb21TdG9yYWdlLmFjY2Vzc1Rva2VuLFxuICAgICAgICAgICAgYWNjZXNzVG9rZW5DbG9ja1NrZXc6IGFjY2Vzc1Rva2VuRnJvbVN0b3JhZ2UuY2xvY2tTa2V3LFxuICAgICAgICAgICAgaWRUb2tlblJhdzogaWRUb2tlbkZyb21TdG9yYWdlLmlkVG9rZW4sXG4gICAgICAgICAgICBpZFRva2VuQ2xvY2tTa2V3OiBpZFRva2VuRnJvbVN0b3JhZ2UuY2xvY2tTa2V3LFxuICAgICAgICAgICAgbm9uY2U6IGlkVG9rZW5Gcm9tU3RvcmFnZS5ub25jZVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKCFpc0FjY2Vzc1Rva2VuKGFjY2Vzc1Rva2VuKSB8fCAhaXNJRFRva2VuKGlkVG9rZW4pKSB7XG4gICAgICAgICAgICByZXR1cm4gdm9pZCAwO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBhY2Nlc3NUb2tlbixcbiAgICAgICAgICAgIGlkVG9rZW5cbiAgICAgICAgfTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQG5hbWUgZ2V0VG9rZW5zXG4gICAgICogQGRlc2NyaXB0aW9uIEdldHMgdGhlIHRva2VucyBmcm9tIHN0b3JhZ2UgYXN5bmNocm9ub3VzbHksIGNhbiByZWZyZXNoIHRva2VucyBpZiByZXF1aXJlZCBhbmQgdmVyaWZ5IHRoZW1cbiAgICAgKlxuICAgICAqIEBwYXJhbSB2ZXJpZnlUb2tlbnMgLSBJZiB0cnVlLCB3aWxsIHZlcmlmeSB0aGUgdG9rZW5zIGJlZm9yZSByZXR1cm5pbmcgKGRlZmF1bHQ6IHRydWUpXG4gICAgICogQHBhcmFtIHJlZnJlc2hJZlJlcXVpcmVkIC0gSWYgdHJ1ZSwgd2lsbCByZWZyZXNoIHRoZSB0b2tlbnMgaWYgdGhleSBhcmUgZXhwaXJlZCAoZGVmYXVsdDogZmFsc2UpXG4gICAgICogQHJldHVybnMgUHJvbWlzZTxUb2tlbnMgfCB1bmRlZmluZWQ+IC0gVGhlIHRva2VucyBpZiB0aGV5IGV4aXN0XG4gICAgICovXG4gICAgYXN5bmMgZ2V0VG9rZW5zKHsgcmVmcmVzaElmUmVxdWlyZWQgPSBmYWxzZSwgdmVyaWZ5VG9rZW5zID0gdHJ1ZSB9ID0ge30pIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNvbnN0IHRva2VucyA9IHRoaXMuZ2V0VG9rZW5zU3luYygpO1xuICAgICAgICAgICAgaWYgKHRva2Vucykge1xuICAgICAgICAgICAgICAgIGlmICh2ZXJpZnlUb2tlbnMpIHtcbiAgICAgICAgICAgICAgICAgICAgYXdhaXQgX19wcml2YXRlR2V0KHRoaXMsIF90b2tlbikudmVyaWZ5VG9rZW5zKHRva2Vucy5pZFRva2VuLCB0b2tlbnMuYWNjZXNzVG9rZW4pO1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdG9rZW5zO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdG9rZW5zO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKHJlZnJlc2hJZlJlcXVpcmVkKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdG9rZW5SZXNwb25zZSA9IGF3YWl0IF9fcHJpdmF0ZUdldCh0aGlzLCBfdG9rZW4pLmdldFdpdGhvdXRQcm9tcHQoKTtcbiAgICAgICAgICAgICAgICB0aGlzLnNldFRva2Vucyh0b2tlblJlc3BvbnNlLnRva2Vucyk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRva2VuUmVzcG9uc2UudG9rZW5zO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHZvaWQgMDtcbiAgICAgICAgfVxuICAgICAgICBjYXRjaCAoZXJyb3IpIHtcbiAgICAgICAgICAgIHRoaXMuY2xlYXIoKTtcbiAgICAgICAgICAgIHRocm93IGVycm9yO1xuICAgICAgICB9XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBuYW1lIGNsZWFyXG4gICAgICogQGRlc2NyaXB0aW9uIENsZWFycyB0aGUgdG9rZW5zIGZyb20gc3RvcmFnZSBhbmQgZW1pdHMgYW4gZXZlbnRcbiAgICAgKiBAcmV0dXJucyB2b2lkXG4gICAgICovXG4gICAgY2xlYXIoKSB7XG4gICAgICAgIF9fcHJpdmF0ZUdldCh0aGlzLCBfc3RvcmFnZSkucmVtb3ZlKF9fcHJpdmF0ZUdldCh0aGlzLCBfYWNjZXNzVG9rZW5LZXkpKTtcbiAgICAgICAgX19wcml2YXRlR2V0KHRoaXMsIF9zdG9yYWdlKS5yZW1vdmUoX19wcml2YXRlR2V0KHRoaXMsIF9pZFRva2VuS2V5KSk7XG4gICAgICAgIF9fcHJpdmF0ZU1ldGhvZCh0aGlzLCBfVG9rZW5NYW5hZ2VyX2luc3RhbmNlcywgZW1pdFJlbW92ZWRfZm4pLmNhbGwodGhpcywgXCJhY2Nlc3NUb2tlblwiKTtcbiAgICAgICAgX19wcml2YXRlTWV0aG9kKHRoaXMsIF9Ub2tlbk1hbmFnZXJfaW5zdGFuY2VzLCBlbWl0UmVtb3ZlZF9mbikuY2FsbCh0aGlzLCBcImlkVG9rZW5cIik7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBuYW1lIHJlbmV3XG4gICAgICogQGRlc2NyaXB0aW9uIEF0dGVtcHRzIHRvIHJlbmV3IHRoZSB0b2tlbnMsIHJlZ2FyZGxlc3Mgb2Ygd2hldGhlciB0aGV5IGFyZSBleHBpcmVkIG9yIG5vdFxuICAgICAqIEByZXR1cm5zIFByb21pc2U8VG9rZW5zIHwgdW5kZWZpbmVkPiAtIFRoZSB0b2tlbnMgaWYgdGhleSBleGlzdFxuICAgICAqL1xuICAgIGFzeW5jIHJlbmV3KCkge1xuICAgICAgICBjb25zdCB0b2tlblJlc3BvbnNlID0gYXdhaXQgX19wcml2YXRlR2V0KHRoaXMsIF90b2tlbikuZ2V0V2l0aG91dFByb21wdCgpO1xuICAgICAgICB0aGlzLnNldFRva2Vucyh0b2tlblJlc3BvbnNlLnRva2Vucyk7XG4gICAgICAgIHJldHVybiB0b2tlblJlc3BvbnNlLnRva2VucztcbiAgICB9XG59XG5fdG9rZW4gPSBuZXcgV2Vha01hcCgpO1xuX2VtaXR0ZXIgPSBuZXcgV2Vha01hcCgpO1xuX3N0b3JhZ2UgPSBuZXcgV2Vha01hcCgpO1xuX2FjY2Vzc1Rva2VuS2V5ID0gbmV3IFdlYWtNYXAoKTtcbl9pZFRva2VuS2V5ID0gbmV3IFdlYWtNYXAoKTtcbl9Ub2tlbk1hbmFnZXJfaW5zdGFuY2VzID0gbmV3IFdlYWtTZXQoKTtcbi8qKlxuICogQG5hbWUgZW1pdEFkZGVkXG4gKiBAZGVzY3JpcHRpb24gRW1pdHMgYW4gZXZlbnQgd2hlbiBhIHRva2VuIGlzIGFkZGVkXG4gKi9cbmVtaXRBZGRlZF9mbiA9IGZ1bmN0aW9uIChrZXksIHRva2VuKSB7XG4gICAgX19wcml2YXRlR2V0KHRoaXMsIF9lbWl0dGVyKS5lbWl0KFwiYWRkZWRcIiwga2V5LCB0b2tlbik7XG59O1xuLyoqXG4gKiBAbmFtZSBlbWl0UmVtb3ZlZFxuICogQGRlc2NyaXB0aW9uIEVtaXRzIGFuIGV2ZW50IHdoZW4gYSB0b2tlbiBpcyByZW1vdmVkXG4gKi9cbmVtaXRSZW1vdmVkX2ZuID0gZnVuY3Rpb24gKGtleSwgdG9rZW4pIHtcbiAgICBfX3ByaXZhdGVHZXQodGhpcywgX2VtaXR0ZXIpLmVtaXQoXCJyZW1vdmVkXCIsIGtleSwgdG9rZW4pO1xufTtcbi8qKlxuICogQG5hbWUgZW1pdFN0b3JhZ2VcbiAqIEBkZXNjcmlwdGlvbiBFbWl0cyBhbiBldmVudCB3aGVuIHRoZSBsb2NhbCBzdG9yYWdlIGlzIHVwZGF0ZWRcbiAqL1xuZW1pdFN0b3JhZ2VfZm4gPSBmdW5jdGlvbiAoKSB7XG4gICAgX19wcml2YXRlR2V0KHRoaXMsIF9lbWl0dGVyKS5lbWl0KFwic3RvcmFnZVwiKTtcbn07XG5leHBvcnQgeyBUb2tlbk1hbmFnZXIgfTtcbiIsImltcG9ydCB7IEVSUl9JTlZBTElEX0NPT0tJRSB9IGZyb20gJy4vRVJSX0lOVkFMSURfQ09PS0lFLmpzJztcbmltcG9ydCB7IGdldENvb2tpZVZhbHVlcyB9IGZyb20gJy4vZ2V0Q29va2llVmFsdWVzLmpzJztcbmltcG9ydCB7IGdldERvbWFpbkF0dHJpYnV0ZSB9IGZyb20gJy4vZ2V0RG9tYWluQXR0cmlidXRlLmpzJztcbmltcG9ydCB7IGlzVmFsaWRDb29raWUgfSBmcm9tICcuL2lzVmFsaWRDb29raWUuanMnO1xuaW1wb3J0IHsgbWVtb2l6ZWRDb29raWVzIH0gZnJvbSAnLi9tZW1vaXplZENvb2tpZXMuanMnO1xuY29uc3Qgc2V0Q29va2llID0gKHsgbmFtZSwgdmFsdWUsIGRheXNUb0xpdmUsIGlzQ3Jvc3NTdWJkb21haW4gPSBmYWxzZSB9KSA9PiB7XG4gICAgY29uc3QgZXhwaXJlcyA9IC8qIEBfX1BVUkVfXyAqLyBuZXcgRGF0ZSgpO1xuICAgIGlmICghaXNWYWxpZENvb2tpZShuYW1lLCB2YWx1ZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGAke0VSUl9JTlZBTElEX0NPT0tJRX0gJHtuYW1lfT0ke3ZhbHVlfWApO1xuICAgIH1cbiAgICBpZiAoZGF5c1RvTGl2ZSkge1xuICAgICAgICBleHBpcmVzLnNldFVUQ0RhdGUoZXhwaXJlcy5nZXRVVENEYXRlKCkgKyBkYXlzVG9MaXZlKTtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIGV4cGlyZXMuc2V0VVRDTW9udGgoZXhwaXJlcy5nZXRVVENNb250aCgpICsgNSk7XG4gICAgICAgIGV4cGlyZXMuc2V0VVRDRGF0ZSgxKTtcbiAgICB9XG4gICAgZG9jdW1lbnQuY29va2llID0gYCR7bmFtZX09JHt2YWx1ZX07IHBhdGg9LzsgZXhwaXJlcz0ke2V4cGlyZXMudG9VVENTdHJpbmcoKX07JHtnZXREb21haW5BdHRyaWJ1dGUoe1xuICAgICAgICBpc0Nyb3NzU3ViZG9tYWluXG4gICAgfSl9YDtcbiAgICBpZiAobWVtb2l6ZWRDb29raWVzLmhhcyhuYW1lKSkge1xuICAgICAgICBjb25zdCBbdmFsdWUyXSA9IGdldENvb2tpZVZhbHVlcyhuYW1lKTtcbiAgICAgICAgaWYgKHZhbHVlMikge1xuICAgICAgICAgICAgbWVtb2l6ZWRDb29raWVzLnNldChuYW1lLCB2YWx1ZTIpO1xuICAgICAgICB9XG4gICAgfVxufTtcbmV4cG9ydCB7IHNldENvb2tpZSB9O1xuIiwiY29uc3QgaXNOb25OdWxsYWJsZSA9IChfKSA9PiBfICE9PSB2b2lkIDAgJiYgXyAhPT0gbnVsbDtcbmV4cG9ydCB7IGlzTm9uTnVsbGFibGUgfTtcbiIsImNvbnN0IGlzT25lT2YgPSAobGl0ZXJhbHMpID0+ICh2YWx1ZSkgPT4gbGl0ZXJhbHMuaW5jbHVkZXModmFsdWUpO1xuZXhwb3J0IHsgaXNPbmVPZiB9O1xuIiwiaW1wb3J0IHsgZGVzZXJpYWxpc2UgfSBmcm9tICcuL3NlcmlhbGlzZS5qcyc7XG5jb25zdCBnZXRNZWFzdXJlcyA9IChzdWJzY3JpcHRpb25zKSA9PiAoXG4vLyBodHRwczovL2RldmVsb3Blci5tb3ppbGxhLm9yZy9lbi1VUy9kb2NzL1dlYi9BUEkvUGVyZm9ybWFuY2UvZ2V0RW50cmllc0J5VHlwZSNicm93c2VyX2NvbXBhdGliaWxpdHlcblwiZ2V0RW50cmllc0J5VHlwZVwiIGluIHdpbmRvdy5wZXJmb3JtYW5jZSA/IHdpbmRvdy5wZXJmb3JtYW5jZS5nZXRFbnRyaWVzQnlUeXBlKFwibWVhc3VyZVwiKS5mbGF0TWFwKCh7IGVudHJ5VHlwZSwgbmFtZSwgZHVyYXRpb24sIHN0YXJ0VGltZSB9KSA9PiB7XG4gICAgY29uc3QgZGV0YWlsID0gZGVzZXJpYWxpc2UobmFtZSk7XG4gICAgcmV0dXJuIGVudHJ5VHlwZSA9PT0gXCJtZWFzdXJlXCIgJiYgZGV0YWlsICYmIHN1YnNjcmlwdGlvbnMuaW5jbHVkZXMoZGV0YWlsLnN1YnNjcmlwdGlvbikgPyB7XG4gICAgICAgIG5hbWUsXG4gICAgICAgIGRldGFpbCxcbiAgICAgICAgZHVyYXRpb24sXG4gICAgICAgIGVudHJ5VHlwZSxcbiAgICAgICAgc3RhcnRUaW1lLFxuICAgICAgICB0b0pzb246ICgpID0+IEpTT04uc3RyaW5naWZ5KHZvaWQgMClcbiAgICB9IDogW107XG59KSA6IFtdKTtcbmV4cG9ydCB7IGdldE1lYXN1cmVzIH07XG4iLCJpbXBvcnQgeyBpc05vbk51bGxhYmxlIH0gZnJvbSAnLi4vaXNOb25OdWxsYWJsZS9pc05vbk51bGxhYmxlLmpzJztcbmltcG9ydCB7IGlzU3RyaW5nIH0gZnJvbSAnLi4vaXNTdHJpbmcvaXNTdHJpbmcuanMnO1xuaW1wb3J0IHsgaXNTdWJzY3JpcHRpb24gfSBmcm9tICcuLi9sb2dnZXIvc3Vic2NyaXB0aW9ucy5qcyc7XG5jb25zdCBTRVBBUkFUT1IgPSBcIjpcIjtcbmNvbnN0IHNlcmlhbGlzZSA9ICh7IHN1YnNjcmlwdGlvbiwgbmFtZSwgYWN0aW9uIH0pID0+IFtzdWJzY3JpcHRpb24sIG5hbWUsIGFjdGlvbl0uZmlsdGVyKGlzTm9uTnVsbGFibGUpLmpvaW4oU0VQQVJBVE9SKTtcbmNvbnN0IGRlc2VyaWFsaXNlID0gKGlkKSA9PiB7XG4gICAgY29uc3QgW3N1YnNjcmlwdGlvbiwgbmFtZSwgYWN0aW9uXSA9IGlkLnNwbGl0KFNFUEFSQVRPUik7XG4gICAgcmV0dXJuIGlzU3RyaW5nKHN1YnNjcmlwdGlvbikgJiYgaXNTdWJzY3JpcHRpb24oc3Vic2NyaXB0aW9uKSAmJiBpc1N0cmluZyhuYW1lKSA/IHsgc3Vic2NyaXB0aW9uLCBuYW1lLCBhY3Rpb24gfSA6IHZvaWQgMDtcbn07XG5leHBvcnQgeyBkZXNlcmlhbGlzZSwgc2VyaWFsaXNlIH07XG4iLCJleHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBkbHYob2JqLCBrZXksIGRlZiwgcCwgdW5kZWYpIHtcbiAgICBrZXkgPSBrZXkuc3BsaXQgPyBrZXkuc3BsaXQoJy4nKSA6IGtleTtcbiAgICBmb3IgKHAgPSAwOyBwIDwga2V5Lmxlbmd0aDsgcCsrKSB7XG4gICAgICAgIG9iaiA9IG9iaiA/IG9ialtrZXlbcF1dIDogdW5kZWY7XG4gICAgfVxuICAgIHJldHVybiBvYmogPT09IHVuZGVmID8gZGVmIDogb2JqO1xufVxuIiwiZXhwb3J0IGZ1bmN0aW9uIGRzZXQob2JqLCBrZXlzLCB2YWwpIHtcbiAgICBrZXlzLnNwbGl0ICYmIChrZXlzID0ga2V5cy5zcGxpdCgnLicpKTtcbiAgICB2YXIgaSA9IDAsIGwgPSBrZXlzLmxlbmd0aCwgdCA9IG9iaiwgeCwgaztcbiAgICB3aGlsZSAoaSA8IGwpIHtcbiAgICAgICAgayA9ICcnICsga2V5c1tpKytdO1xuICAgICAgICBpZiAoayA9PT0gJ19fcHJvdG9fXycgfHwgayA9PT0gJ2NvbnN0cnVjdG9yJyB8fCBrID09PSAncHJvdG90eXBlJylcbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICB0ID0gdFtrXSA9IChpID09PSBsKSA/IHZhbCA6ICh0eXBlb2YgKHggPSB0W2tdKSA9PT0gdHlwZW9mIChrZXlzKSkgPyB4IDogKGtleXNbaV0gKiAwICE9PSAwIHx8ICEhfignJyArIGtleXNbaV0pLmluZGV4T2YoJy4nKSkgPyB7fSA6IFtdO1xuICAgIH1cbn1cbiIsImV4cG9ydCBmdW5jdGlvbiBrbG9uYSh2YWwpIHtcbiAgICB2YXIgaywgb3V0LCB0bXA7XG4gICAgaWYgKEFycmF5LmlzQXJyYXkodmFsKSkge1xuICAgICAgICBvdXQgPSBBcnJheShrID0gdmFsLmxlbmd0aCk7XG4gICAgICAgIHdoaWxlIChrLS0pXG4gICAgICAgICAgICBvdXRba10gPSAodG1wID0gdmFsW2tdKSAmJiB0eXBlb2YgdG1wID09PSAnb2JqZWN0JyA/IGtsb25hKHRtcCkgOiB0bXA7XG4gICAgICAgIHJldHVybiBvdXQ7XG4gICAgfVxuICAgIGlmIChPYmplY3QucHJvdG90eXBlLnRvU3RyaW5nLmNhbGwodmFsKSA9PT0gJ1tvYmplY3QgT2JqZWN0XScpIHtcbiAgICAgICAgb3V0ID0ge307IC8vIG51bGxcbiAgICAgICAgZm9yIChrIGluIHZhbCkge1xuICAgICAgICAgICAgaWYgKGsgPT09ICdfX3Byb3RvX18nKSB7XG4gICAgICAgICAgICAgICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG91dCwgaywge1xuICAgICAgICAgICAgICAgICAgICB2YWx1ZToga2xvbmEodmFsW2tdKSxcbiAgICAgICAgICAgICAgICAgICAgY29uZmlndXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuICAgICAgICAgICAgICAgICAgICB3cml0YWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIG91dFtrXSA9ICh0bXAgPSB2YWxba10pICYmIHR5cGVvZiB0bXAgPT09ICdvYmplY3QnID8ga2xvbmEodG1wKSA6IHRtcDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gb3V0O1xuICAgIH1cbiAgICByZXR1cm4gdmFsO1xufVxuIiwiLyoqXG4gKiBBcHBlbmRzIHRoZSBlbGVtZW50cyBvZiBgdmFsdWVzYCB0byBgYXJyYXlgLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge0FycmF5fSBhcnJheSBUaGUgYXJyYXkgdG8gbW9kaWZ5LlxuICogQHBhcmFtIHtBcnJheX0gdmFsdWVzIFRoZSB2YWx1ZXMgdG8gYXBwZW5kLlxuICogQHJldHVybnMge0FycmF5fSBSZXR1cm5zIGBhcnJheWAuXG4gKi9cbmZ1bmN0aW9uIGFycmF5UHVzaChhcnJheSwgdmFsdWVzKSB7XG4gICAgdmFyIGluZGV4ID0gLTEsIGxlbmd0aCA9IHZhbHVlcy5sZW5ndGgsIG9mZnNldCA9IGFycmF5Lmxlbmd0aDtcbiAgICB3aGlsZSAoKytpbmRleCA8IGxlbmd0aCkge1xuICAgICAgICBhcnJheVtvZmZzZXQgKyBpbmRleF0gPSB2YWx1ZXNbaW5kZXhdO1xuICAgIH1cbiAgICByZXR1cm4gYXJyYXk7XG59XG5leHBvcnQgZGVmYXVsdCBhcnJheVB1c2g7XG4iLCJpbXBvcnQgYXJyYXlQdXNoIGZyb20gJy4vX2FycmF5UHVzaC5qcyc7XG5pbXBvcnQgaXNGbGF0dGVuYWJsZSBmcm9tICcuL19pc0ZsYXR0ZW5hYmxlLmpzJztcbi8qKlxuICogVGhlIGJhc2UgaW1wbGVtZW50YXRpb24gb2YgYF8uZmxhdHRlbmAgd2l0aCBzdXBwb3J0IGZvciByZXN0cmljdGluZyBmbGF0dGVuaW5nLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0ge0FycmF5fSBhcnJheSBUaGUgYXJyYXkgdG8gZmxhdHRlbi5cbiAqIEBwYXJhbSB7bnVtYmVyfSBkZXB0aCBUaGUgbWF4aW11bSByZWN1cnNpb24gZGVwdGguXG4gKiBAcGFyYW0ge2Jvb2xlYW59IFtwcmVkaWNhdGU9aXNGbGF0dGVuYWJsZV0gVGhlIGZ1bmN0aW9uIGludm9rZWQgcGVyIGl0ZXJhdGlvbi5cbiAqIEBwYXJhbSB7Ym9vbGVhbn0gW2lzU3RyaWN0XSBSZXN0cmljdCB0byB2YWx1ZXMgdGhhdCBwYXNzIGBwcmVkaWNhdGVgIGNoZWNrcy5cbiAqIEBwYXJhbSB7QXJyYXl9IFtyZXN1bHQ9W11dIFRoZSBpbml0aWFsIHJlc3VsdCB2YWx1ZS5cbiAqIEByZXR1cm5zIHtBcnJheX0gUmV0dXJucyB0aGUgbmV3IGZsYXR0ZW5lZCBhcnJheS5cbiAqL1xuZnVuY3Rpb24gYmFzZUZsYXR0ZW4oYXJyYXksIGRlcHRoLCBwcmVkaWNhdGUsIGlzU3RyaWN0LCByZXN1bHQpIHtcbiAgICB2YXIgaW5kZXggPSAtMSwgbGVuZ3RoID0gYXJyYXkubGVuZ3RoO1xuICAgIHByZWRpY2F0ZSB8fCAocHJlZGljYXRlID0gaXNGbGF0dGVuYWJsZSk7XG4gICAgcmVzdWx0IHx8IChyZXN1bHQgPSBbXSk7XG4gICAgd2hpbGUgKCsraW5kZXggPCBsZW5ndGgpIHtcbiAgICAgICAgdmFyIHZhbHVlID0gYXJyYXlbaW5kZXhdO1xuICAgICAgICBpZiAoZGVwdGggPiAwICYmIHByZWRpY2F0ZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGlmIChkZXB0aCA+IDEpIHtcbiAgICAgICAgICAgICAgICAvLyBSZWN1cnNpdmVseSBmbGF0dGVuIGFycmF5cyAoc3VzY2VwdGlibGUgdG8gY2FsbCBzdGFjayBsaW1pdHMpLlxuICAgICAgICAgICAgICAgIGJhc2VGbGF0dGVuKHZhbHVlLCBkZXB0aCAtIDEsIHByZWRpY2F0ZSwgaXNTdHJpY3QsIHJlc3VsdCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBhcnJheVB1c2gocmVzdWx0LCB2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoIWlzU3RyaWN0KSB7XG4gICAgICAgICAgICByZXN1bHRbcmVzdWx0Lmxlbmd0aF0gPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZXhwb3J0IGRlZmF1bHQgYmFzZUZsYXR0ZW47XG4iLCJpbXBvcnQgYmFzZUdldFRhZyBmcm9tICcuL19iYXNlR2V0VGFnLmpzJztcbmltcG9ydCBpc09iamVjdExpa2UgZnJvbSAnLi9pc09iamVjdExpa2UuanMnO1xuLyoqIGBPYmplY3QjdG9TdHJpbmdgIHJlc3VsdCByZWZlcmVuY2VzLiAqL1xudmFyIGFyZ3NUYWcgPSAnW29iamVjdCBBcmd1bWVudHNdJztcbi8qKlxuICogVGhlIGJhc2UgaW1wbGVtZW50YXRpb24gb2YgYF8uaXNBcmd1bWVudHNgLlxuICpcbiAqIEBwcml2YXRlXG4gKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byBjaGVjay5cbiAqIEByZXR1cm5zIHtib29sZWFufSBSZXR1cm5zIGB0cnVlYCBpZiBgdmFsdWVgIGlzIGFuIGBhcmd1bWVudHNgIG9iamVjdCxcbiAqL1xuZnVuY3Rpb24gYmFzZUlzQXJndW1lbnRzKHZhbHVlKSB7XG4gICAgcmV0dXJuIGlzT2JqZWN0TGlrZSh2YWx1ZSkgJiYgYmFzZUdldFRhZyh2YWx1ZSkgPT0gYXJnc1RhZztcbn1cbmV4cG9ydCBkZWZhdWx0IGJhc2VJc0FyZ3VtZW50cztcbiIsImltcG9ydCBTeW1ib2wgZnJvbSAnLi9fU3ltYm9sLmpzJztcbmltcG9ydCBpc0FyZ3VtZW50cyBmcm9tICcuL2lzQXJndW1lbnRzLmpzJztcbmltcG9ydCBpc0FycmF5IGZyb20gJy4vaXNBcnJheS5qcyc7XG4vKiogQnVpbHQtaW4gdmFsdWUgcmVmZXJlbmNlcy4gKi9cbnZhciBzcHJlYWRhYmxlU3ltYm9sID0gU3ltYm9sID8gU3ltYm9sLmlzQ29uY2F0U3ByZWFkYWJsZSA6IHVuZGVmaW5lZDtcbi8qKlxuICogQ2hlY2tzIGlmIGB2YWx1ZWAgaXMgYSBmbGF0dGVuYWJsZSBgYXJndW1lbnRzYCBvYmplY3Qgb3IgYXJyYXkuXG4gKlxuICogQHByaXZhdGVcbiAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIGNoZWNrLlxuICogQHJldHVybnMge2Jvb2xlYW59IFJldHVybnMgYHRydWVgIGlmIGB2YWx1ZWAgaXMgZmxhdHRlbmFibGUsIGVsc2UgYGZhbHNlYC5cbiAqL1xuZnVuY3Rpb24gaXNGbGF0dGVuYWJsZSh2YWx1ZSkge1xuICAgIHJldHVybiBpc0FycmF5KHZhbHVlKSB8fCBpc0FyZ3VtZW50cyh2YWx1ZSkgfHxcbiAgICAgICAgISEoc3ByZWFkYWJsZVN5bWJvbCAmJiB2YWx1ZSAmJiB2YWx1ZVtzcHJlYWRhYmxlU3ltYm9sXSk7XG59XG5leHBvcnQgZGVmYXVsdCBpc0ZsYXR0ZW5hYmxlO1xuIiwiaW1wb3J0IGJhc2VGbGF0dGVuIGZyb20gJy4vX2Jhc2VGbGF0dGVuLmpzJztcbi8qKlxuICogRmxhdHRlbnMgYGFycmF5YCBhIHNpbmdsZSBsZXZlbCBkZWVwLlxuICpcbiAqIEBzdGF0aWNcbiAqIEBtZW1iZXJPZiBfXG4gKiBAc2luY2UgMC4xLjBcbiAqIEBjYXRlZ29yeSBBcnJheVxuICogQHBhcmFtIHtBcnJheX0gYXJyYXkgVGhlIGFycmF5IHRvIGZsYXR0ZW4uXG4gKiBAcmV0dXJucyB7QXJyYXl9IFJldHVybnMgdGhlIG5ldyBmbGF0dGVuZWQgYXJyYXkuXG4gKiBAZXhhbXBsZVxuICpcbiAqIF8uZmxhdHRlbihbMSwgWzIsIFszLCBbNF1dLCA1XV0pO1xuICogLy8gPT4gWzEsIDIsIFszLCBbNF1dLCA1XVxuICovXG5mdW5jdGlvbiBmbGF0dGVuKGFycmF5KSB7XG4gICAgdmFyIGxlbmd0aCA9IGFycmF5ID09IG51bGwgPyAwIDogYXJyYXkubGVuZ3RoO1xuICAgIHJldHVybiBsZW5ndGggPyBiYXNlRmxhdHRlbihhcnJheSwgMSkgOiBbXTtcbn1cbmV4cG9ydCBkZWZhdWx0IGZsYXR0ZW47XG4iLCJpbXBvcnQgYmFzZUlzQXJndW1lbnRzIGZyb20gJy4vX2Jhc2VJc0FyZ3VtZW50cy5qcyc7XG5pbXBvcnQgaXNPYmplY3RMaWtlIGZyb20gJy4vaXNPYmplY3RMaWtlLmpzJztcbi8qKiBVc2VkIGZvciBidWlsdC1pbiBtZXRob2QgcmVmZXJlbmNlcy4gKi9cbnZhciBvYmplY3RQcm90byA9IE9iamVjdC5wcm90b3R5cGU7XG4vKiogVXNlZCB0byBjaGVjayBvYmplY3RzIGZvciBvd24gcHJvcGVydGllcy4gKi9cbnZhciBoYXNPd25Qcm9wZXJ0eSA9IG9iamVjdFByb3RvLmhhc093blByb3BlcnR5O1xuLyoqIEJ1aWx0LWluIHZhbHVlIHJlZmVyZW5jZXMuICovXG52YXIgcHJvcGVydHlJc0VudW1lcmFibGUgPSBvYmplY3RQcm90by5wcm9wZXJ0eUlzRW51bWVyYWJsZTtcbi8qKlxuICogQ2hlY2tzIGlmIGB2YWx1ZWAgaXMgbGlrZWx5IGFuIGBhcmd1bWVudHNgIG9iamVjdC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDAuMS4wXG4gKiBAY2F0ZWdvcnkgTGFuZ1xuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhbiBgYXJndW1lbnRzYCBvYmplY3QsXG4gKiAgZWxzZSBgZmFsc2VgLlxuICogQGV4YW1wbGVcbiAqXG4gKiBfLmlzQXJndW1lbnRzKGZ1bmN0aW9uKCkgeyByZXR1cm4gYXJndW1lbnRzOyB9KCkpO1xuICogLy8gPT4gdHJ1ZVxuICpcbiAqIF8uaXNBcmd1bWVudHMoWzEsIDIsIDNdKTtcbiAqIC8vID0+IGZhbHNlXG4gKi9cbnZhciBpc0FyZ3VtZW50cyA9IGJhc2VJc0FyZ3VtZW50cyhmdW5jdGlvbiAoKSB7IHJldHVybiBhcmd1bWVudHM7IH0oKSkgPyBiYXNlSXNBcmd1bWVudHMgOiBmdW5jdGlvbiAodmFsdWUpIHtcbiAgICByZXR1cm4gaXNPYmplY3RMaWtlKHZhbHVlKSAmJiBoYXNPd25Qcm9wZXJ0eS5jYWxsKHZhbHVlLCAnY2FsbGVlJykgJiZcbiAgICAgICAgIXByb3BlcnR5SXNFbnVtZXJhYmxlLmNhbGwodmFsdWUsICdjYWxsZWUnKTtcbn07XG5leHBvcnQgZGVmYXVsdCBpc0FyZ3VtZW50cztcbiIsIi8qKlxuICogQ2hlY2tzIGlmIGB2YWx1ZWAgaXMgY2xhc3NpZmllZCBhcyBhbiBgQXJyYXlgIG9iamVjdC5cbiAqXG4gKiBAc3RhdGljXG4gKiBAbWVtYmVyT2YgX1xuICogQHNpbmNlIDAuMS4wXG4gKiBAY2F0ZWdvcnkgTGFuZ1xuICogQHBhcmFtIHsqfSB2YWx1ZSBUaGUgdmFsdWUgdG8gY2hlY2suXG4gKiBAcmV0dXJucyB7Ym9vbGVhbn0gUmV0dXJucyBgdHJ1ZWAgaWYgYHZhbHVlYCBpcyBhbiBhcnJheSwgZWxzZSBgZmFsc2VgLlxuICogQGV4YW1wbGVcbiAqXG4gKiBfLmlzQXJyYXkoWzEsIDIsIDNdKTtcbiAqIC8vID0+IHRydWVcbiAqXG4gKiBfLmlzQXJyYXkoZG9jdW1lbnQuYm9keS5jaGlsZHJlbik7XG4gKiAvLyA9PiBmYWxzZVxuICpcbiAqIF8uaXNBcnJheSgnYWJjJyk7XG4gKiAvLyA9PiBmYWxzZVxuICpcbiAqIF8uaXNBcnJheShfLm5vb3ApO1xuICogLy8gPT4gZmFsc2VcbiAqL1xudmFyIGlzQXJyYXkgPSBBcnJheS5pc0FycmF5O1xuZXhwb3J0IGRlZmF1bHQgaXNBcnJheTtcbiIsImltcG9ydCBfZGVmaW5lUHJvcGVydHkgZnJvbSBcIkBiYWJlbC9ydW50aW1lL2hlbHBlcnMvZGVmaW5lUHJvcGVydHlcIjtcbmZ1bmN0aW9uIG93bktleXMoZSwgcikgeyB2YXIgdCA9IE9iamVjdC5rZXlzKGUpOyBpZiAoT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scykge1xuICAgIHZhciBvID0gT2JqZWN0LmdldE93blByb3BlcnR5U3ltYm9scyhlKTtcbiAgICByICYmIChvID0gby5maWx0ZXIoZnVuY3Rpb24gKHIpIHsgcmV0dXJuIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IoZSwgcikuZW51bWVyYWJsZTsgfSkpLCB0LnB1c2guYXBwbHkodCwgbyk7XG59IHJldHVybiB0OyB9XG5mdW5jdGlvbiBfb2JqZWN0U3ByZWFkKGUpIHsgZm9yICh2YXIgciA9IDE7IHIgPCBhcmd1bWVudHMubGVuZ3RoOyByKyspIHtcbiAgICB2YXIgdCA9IG51bGwgIT0gYXJndW1lbnRzW3JdID8gYXJndW1lbnRzW3JdIDoge307XG4gICAgciAlIDIgPyBvd25LZXlzKE9iamVjdCh0KSwgITApLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgX2RlZmluZVByb3BlcnR5KGUsIHIsIHRbcl0pOyB9KSA6IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzID8gT2JqZWN0LmRlZmluZVByb3BlcnRpZXMoZSwgT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcnModCkpIDogb3duS2V5cyhPYmplY3QodCkpLmZvckVhY2goZnVuY3Rpb24gKHIpIHsgT2JqZWN0LmRlZmluZVByb3BlcnR5KGUsIHIsIE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IodCwgcikpOyB9KTtcbn0gcmV0dXJuIGU7IH1cbi8qXG4gKiBNb2R1bGUgZm9yIGdldHRpbmcgYW5kIHNldHRpbmcgUHJlYmlkIGNvbmZpZ3VyYXRpb24uXG4qL1xuLyoqXG4gKiBAdHlwZWRlZiB7T2JqZWN0fSBNZWRpYVR5cGVQcmljZUdyYW51bGFyaXR5XG4gKlxuICogQHByb3BlcnR5IHsoc3RyaW5nfE9iamVjdCl9IFtiYW5uZXJdXG4gKiBAcHJvcGVydHkgeyhzdHJpbmd8T2JqZWN0KX0gW25hdGl2ZV1cbiAqIEBwcm9wZXJ0eSB7KHN0cmluZ3xPYmplY3QpfSBbdmlkZW9dXG4gKiBAcHJvcGVydHkgeyhzdHJpbmd8T2JqZWN0KX0gW3ZpZGVvLWluc3RyZWFtXVxuICogQHByb3BlcnR5IHsoc3RyaW5nfE9iamVjdCl9IFt2aWRlby1vdXRzdHJlYW1dXG4gKi9cbmltcG9ydCB7IGlzVmFsaWRQcmljZUNvbmZpZyB9IGZyb20gJy4vY3BtQnVja2V0TWFuYWdlci5qcyc7XG5pbXBvcnQgeyBhcnJheUZyb20gYXMgZnJvbSwgZmluZCwgaW5jbHVkZXMgfSBmcm9tICcuL3BvbHlmaWxsLmpzJztcbmltcG9ydCB7IGRlZXBBY2Nlc3MsIGRlZXBDbG9uZSwgZ2V0UGFyYW1ldGVyQnlOYW1lLCBpc0FycmF5LCBpc0Jvb2xlYW4sIGlzUGxhaW5PYmplY3QsIGlzU3RyLCBsb2dFcnJvciwgbG9nTWVzc2FnZSwgbG9nV2FybiwgbWVyZ2VEZWVwIH0gZnJvbSAnLi91dGlscy5qcyc7XG5pbXBvcnQgeyBERUJVR19NT0RFIH0gZnJvbSAnLi9jb25zdGFudHMuanMnO1xudmFyIERFRkFVTFRfREVCVUcgPSBnZXRQYXJhbWV0ZXJCeU5hbWUoREVCVUdfTU9ERSkudG9VcHBlckNhc2UoKSA9PT0gJ1RSVUUnO1xudmFyIERFRkFVTFRfQklEREVSX1RJTUVPVVQgPSAzMDAwO1xudmFyIERFRkFVTFRfRU5BQkxFX1NFTkRfQUxMX0JJRFMgPSB0cnVlO1xudmFyIERFRkFVTFRfRElTQUJMRV9BSkFYX1RJTUVPVVQgPSBmYWxzZTtcbnZhciBERUZBVUxUX0JJRF9DQUNIRSA9IGZhbHNlO1xudmFyIERFRkFVTFRfREVWSUNFX0FDQ0VTUyA9IHRydWU7XG52YXIgREVGQVVMVF9NQVhfTkVTVEVEX0lGUkFNRVMgPSAxMDtcbnZhciBERUZBVUxUX01BWEJJRF9WQUxVRSA9IDUwMDA7XG52YXIgREVGQVVMVF9JRlJBTUVTX0NPTkZJRyA9IHt9O1xuZXhwb3J0IHZhciBSQU5ET00gPSAncmFuZG9tJztcbnZhciBGSVhFRCA9ICdmaXhlZCc7XG52YXIgVkFMSURfT1JERVJTID0ge307XG5WQUxJRF9PUkRFUlNbUkFORE9NXSA9IHRydWU7XG5WQUxJRF9PUkRFUlNbRklYRURdID0gdHJ1ZTtcbnZhciBERUZBVUxUX0JJRERFUl9TRVFVRU5DRSA9IFJBTkRPTTtcbnZhciBHUkFOVUxBUklUWV9PUFRJT05TID0ge1xuICAgIExPVzogJ2xvdycsXG4gICAgTUVESVVNOiAnbWVkaXVtJyxcbiAgICBISUdIOiAnaGlnaCcsXG4gICAgQVVUTzogJ2F1dG8nLFxuICAgIERFTlNFOiAnZGVuc2UnLFxuICAgIENVU1RPTTogJ2N1c3RvbSdcbn07XG52YXIgQUxMX1RPUElDUyA9ICcqJztcbmZ1bmN0aW9uIGF0dGFjaFByb3BlcnRpZXMoY29uZmlnKSB7XG4gICAgdmFyIHVzZURlZmF1bHRWYWx1ZXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IHRydWU7XG4gICAgdmFyIHZhbHVlcyA9IHVzZURlZmF1bHRWYWx1ZXMgPyB7XG4gICAgICAgIHByaWNlR3JhbnVsYXJpdHk6IEdSQU5VTEFSSVRZX09QVElPTlMuTUVESVVNLFxuICAgICAgICBjdXN0b21QcmljZUJ1Y2tldDoge30sXG4gICAgICAgIG1lZGlhVHlwZVByaWNlR3JhbnVsYXJpdHk6IHt9LFxuICAgICAgICBiaWRkZXJTZXF1ZW5jZTogREVGQVVMVF9CSURERVJfU0VRVUVOQ0UsXG4gICAgICAgIGF1Y3Rpb25PcHRpb25zOiB7fVxuICAgIH0gOiB7fTtcbiAgICBmdW5jdGlvbiBnZXRQcm9wKG5hbWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlc1tuYW1lXTtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2V0UHJvcChuYW1lLCB2YWwpIHtcbiAgICAgICAgaWYgKCF2YWx1ZXMuaGFzT3duUHJvcGVydHkobmFtZSkpIHtcbiAgICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25maWcsIG5hbWUsIHtcbiAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgfVxuICAgICAgICB2YWx1ZXNbbmFtZV0gPSB2YWw7XG4gICAgfVxuICAgIHZhciBwcm9wcyA9IHtcbiAgICAgICAgcHVibGlzaGVyRG9tYWluOiB7XG4gICAgICAgICAgICBzZXQodmFsKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbCAhPSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ1dhcm4oJ3B1Ymxpc2hlckRvbWFpbiBpcyBkZXByZWNhdGVkIGFuZCBoYXMgbm8gZWZmZWN0IHNpbmNlIHY3IC0gdXNlIHBhZ2VVcmwgaW5zdGVhZCcpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBzZXRQcm9wKCdwdWJsaXNoZXJEb21haW4nLCB2YWwpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBwcmljZUdyYW51bGFyaXR5OiB7XG4gICAgICAgICAgICBzZXQodmFsKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbGlkYXRlUHJpY2VHcmFudWxhcml0eSh2YWwpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsID09PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgICAgICAgICAgICAgc2V0UHJvcCgncHJpY2VHcmFudWxhcml0eScsIGhhc0dyYW51bGFyaXR5KHZhbCkgPyB2YWwgOiBHUkFOVUxBUklUWV9PUFRJT05TLk1FRElVTSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgZWxzZSBpZiAoaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRQcm9wKCdjdXN0b21QcmljZUJ1Y2tldCcsIHZhbCk7XG4gICAgICAgICAgICAgICAgICAgICAgICBzZXRQcm9wKCdwcmljZUdyYW51bGFyaXR5JywgR1JBTlVMQVJJVFlfT1BUSU9OUy5DVVNUT00pO1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9nTWVzc2FnZSgnVXNpbmcgY3VzdG9tIHByaWNlIGdyYW51bGFyaXR5Jyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIGN1c3RvbVByaWNlQnVja2V0OiB7fSxcbiAgICAgICAgbWVkaWFUeXBlUHJpY2VHcmFudWxhcml0eToge1xuICAgICAgICAgICAgc2V0KHZhbCkge1xuICAgICAgICAgICAgICAgIHZhbCAhPSBudWxsICYmIHNldFByb3AoJ21lZGlhVHlwZVByaWNlR3JhbnVsYXJpdHknLCBPYmplY3Qua2V5cyh2YWwpLnJlZHVjZSgoYWdncmVnYXRlLCBpdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICh2YWxpZGF0ZVByaWNlR3JhbnVsYXJpdHkodmFsW2l0ZW1dKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgYWdncmVnYXRlW2l0ZW1dID0gaGFzR3JhbnVsYXJpdHkodmFsW2l0ZW1dKSA/IHZhbFtpdGVtXSA6IGdldFByb3AoJ3ByaWNlR3JhbnVsYXJpdHknKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGVsc2UgaWYgKGlzUGxhaW5PYmplY3QodmFsKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFnZ3JlZ2F0ZVtpdGVtXSA9IHZhbFtpdGVtXTtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBsb2dNZXNzYWdlKFwiVXNpbmcgY3VzdG9tIHByaWNlIGdyYW51bGFyaXR5IGZvciBcIi5jb25jYXQoaXRlbSkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICAgICAgbG9nV2FybihcIkludmFsaWQgcHJpY2UgZ3JhbnVsYXJpdHkgZm9yIG1lZGlhIHR5cGU6IFwiLmNvbmNhdChpdGVtKSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGFnZ3JlZ2F0ZTtcbiAgICAgICAgICAgICAgICB9LCB7fSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBiaWRkZXJTZXF1ZW5jZToge1xuICAgICAgICAgICAgc2V0KHZhbCkge1xuICAgICAgICAgICAgICAgIGlmIChWQUxJRF9PUkRFUlNbdmFsXSkge1xuICAgICAgICAgICAgICAgICAgICBzZXRQcm9wKCdiaWRkZXJTZXF1ZW5jZScsIHZhbCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgICAgICBsb2dXYXJuKFwiSW52YWxpZCBvcmRlcjogXCIuY29uY2F0KHZhbCwgXCIuIEJpZGRlciBTZXF1ZW5jZSB3YXMgbm90IHNldC5cIikpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgYXVjdGlvbk9wdGlvbnM6IHtcbiAgICAgICAgICAgIHNldCh2YWwpIHtcbiAgICAgICAgICAgICAgICBpZiAodmFsaWRhdGVhdWN0aW9uT3B0aW9ucyh2YWwpKSB7XG4gICAgICAgICAgICAgICAgICAgIHNldFByb3AoJ2F1Y3Rpb25PcHRpb25zJywgdmFsKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9O1xuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0aWVzKGNvbmZpZywgT2JqZWN0LmZyb21FbnRyaWVzKE9iamVjdC5lbnRyaWVzKHByb3BzKS5tYXAoX3JlZiA9PiB7XG4gICAgICAgIHZhciBbaywgZGVmXSA9IF9yZWY7XG4gICAgICAgIHJldHVybiBbaywgT2JqZWN0LmFzc2lnbih7XG4gICAgICAgICAgICAgICAgZ2V0OiBnZXRQcm9wLmJpbmQobnVsbCwgayksXG4gICAgICAgICAgICAgICAgc2V0OiBzZXRQcm9wLmJpbmQobnVsbCwgayksXG4gICAgICAgICAgICAgICAgZW51bWVyYWJsZTogdmFsdWVzLmhhc093blByb3BlcnR5KGspLFxuICAgICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogIXZhbHVlcy5oYXNPd25Qcm9wZXJ0eShrKVxuICAgICAgICAgICAgfSwgZGVmKV07XG4gICAgfSkpKTtcbiAgICByZXR1cm4gY29uZmlnO1xuICAgIGZ1bmN0aW9uIGhhc0dyYW51bGFyaXR5KHZhbCkge1xuICAgICAgICByZXR1cm4gZmluZChPYmplY3Qua2V5cyhHUkFOVUxBUklUWV9PUFRJT05TKSwgb3B0aW9uID0+IHZhbCA9PT0gR1JBTlVMQVJJVFlfT1BUSU9OU1tvcHRpb25dKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gdmFsaWRhdGVQcmljZUdyYW51bGFyaXR5KHZhbCkge1xuICAgICAgICBpZiAoIXZhbCkge1xuICAgICAgICAgICAgbG9nRXJyb3IoJ1ByZWJpZCBFcnJvcjogbm8gdmFsdWUgcGFzc2VkIHRvIGBzZXRQcmljZUdyYW51bGFyaXR5KClgJyk7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKHR5cGVvZiB2YWwgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICBpZiAoIWhhc0dyYW51bGFyaXR5KHZhbCkpIHtcbiAgICAgICAgICAgICAgICBsb2dXYXJuKCdQcmViaWQgV2FybmluZzogc2V0UHJpY2VHcmFudWxhcml0eSB3YXMgY2FsbGVkIHdpdGggaW52YWxpZCBzZXR0aW5nLCB1c2luZyBgbWVkaXVtYCBhcyBkZWZhdWx0LicpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGVsc2UgaWYgKGlzUGxhaW5PYmplY3QodmFsKSkge1xuICAgICAgICAgICAgaWYgKCFpc1ZhbGlkUHJpY2VDb25maWcodmFsKSkge1xuICAgICAgICAgICAgICAgIGxvZ0Vycm9yKCdJbnZhbGlkIGN1c3RvbSBwcmljZSB2YWx1ZSBwYXNzZWQgdG8gYHNldFByaWNlR3JhbnVsYXJpdHkoKWAnKTtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGZ1bmN0aW9uIHZhbGlkYXRlYXVjdGlvbk9wdGlvbnModmFsKSB7XG4gICAgICAgIGlmICghaXNQbGFpbk9iamVjdCh2YWwpKSB7XG4gICAgICAgICAgICBsb2dXYXJuKCdBdWN0aW9uIE9wdGlvbnMgbXVzdCBiZSBhbiBvYmplY3QnKTtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKHZhciBrIG9mIE9iamVjdC5rZXlzKHZhbCkpIHtcbiAgICAgICAgICAgIGlmIChrICE9PSAnc2Vjb25kYXJ5QmlkZGVycycgJiYgayAhPT0gJ3N1cHByZXNzU3RhbGVSZW5kZXInICYmIGsgIT09ICdzdXBwcmVzc0V4cGlyZWRSZW5kZXInKSB7XG4gICAgICAgICAgICAgICAgbG9nV2FybihcIkF1Y3Rpb24gT3B0aW9ucyBnaXZlbiBhbiBpbmNvcnJlY3QgcGFyYW06IFwiLmNvbmNhdChrKSk7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGsgPT09ICdzZWNvbmRhcnlCaWRkZXJzJykge1xuICAgICAgICAgICAgICAgIGlmICghaXNBcnJheSh2YWxba10pKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ1dhcm4oXCJBdWN0aW9uIE9wdGlvbnMgXCIuY29uY2F0KGssIFwiIG11c3QgYmUgb2YgdHlwZSBBcnJheVwiKSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoIXZhbFtrXS5ldmVyeShpc1N0cikpIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nV2FybihcIkF1Y3Rpb24gT3B0aW9ucyBcIi5jb25jYXQoaywgXCIgbXVzdCBiZSBvbmx5IHN0cmluZ1wiKSk7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChrID09PSAnc3VwcHJlc3NTdGFsZVJlbmRlcicgfHwgayA9PT0gJ3N1cHByZXNzRXhwaXJlZFJlbmRlcicpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWlzQm9vbGVhbih2YWxba10pKSB7XG4gICAgICAgICAgICAgICAgICAgIGxvZ1dhcm4oXCJBdWN0aW9uIE9wdGlvbnMgXCIuY29uY2F0KGssIFwiIG11c3QgYmUgb2YgdHlwZSBib29sZWFuXCIpKTtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gbmV3Q29uZmlnKCkge1xuICAgIHZhciBsaXN0ZW5lcnMgPSBbXTtcbiAgICB2YXIgZGVmYXVsdHM7XG4gICAgdmFyIGNvbmZpZztcbiAgICB2YXIgYmlkZGVyQ29uZmlnO1xuICAgIHZhciBjdXJyQmlkZGVyID0gbnVsbDtcbiAgICBmdW5jdGlvbiByZXNldENvbmZpZygpIHtcbiAgICAgICAgZGVmYXVsdHMgPSB7fTtcbiAgICAgICAgdmFyIG5ld0NvbmZpZyA9IGF0dGFjaFByb3BlcnRpZXMoe1xuICAgICAgICAgICAgLy8gYGRlYnVnYCBpcyBlcXVpdmFsZW50IHRvIGxlZ2FjeSBgcGJqcy5sb2dnaW5nYCBwcm9wZXJ0eVxuICAgICAgICAgICAgZGVidWc6IERFRkFVTFRfREVCVUcsXG4gICAgICAgICAgICBiaWRkZXJUaW1lb3V0OiBERUZBVUxUX0JJRERFUl9USU1FT1VULFxuICAgICAgICAgICAgZW5hYmxlU2VuZEFsbEJpZHM6IERFRkFVTFRfRU5BQkxFX1NFTkRfQUxMX0JJRFMsXG4gICAgICAgICAgICB1c2VCaWRDYWNoZTogREVGQVVMVF9CSURfQ0FDSEUsXG4gICAgICAgICAgICAvKipcbiAgICAgICAgICAgICAqIGRldmljZUFjY2VzcyBzZXQgdG8gZmFsc2Ugd2lsbCBkaXNhYmxlIHNldENvb2tpZSwgZ2V0Q29va2llLCBoYXNMb2NhbFN0b3JhZ2VcbiAgICAgICAgICAgICAqIEB0eXBlIHtib29sZWFufVxuICAgICAgICAgICAgICovXG4gICAgICAgICAgICBkZXZpY2VBY2Nlc3M6IERFRkFVTFRfREVWSUNFX0FDQ0VTUyxcbiAgICAgICAgICAgIGRpc2FibGVBamF4VGltZW91dDogREVGQVVMVF9ESVNBQkxFX0FKQVhfVElNRU9VVCxcbiAgICAgICAgICAgIC8vIGRlZmF1bHQgbWF4IG5lc3RlZCBpZnJhbWVzIGZvciByZWZlcmVyIGRldGVjdGlvblxuICAgICAgICAgICAgbWF4TmVzdGVkSWZyYW1lczogREVGQVVMVF9NQVhfTkVTVEVEX0lGUkFNRVMsXG4gICAgICAgICAgICAvLyBkZWZhdWx0IG1heCBiaWRcbiAgICAgICAgICAgIG1heEJpZDogREVGQVVMVF9NQVhCSURfVkFMVUUsXG4gICAgICAgICAgICB1c2VyU3luYzoge1xuICAgICAgICAgICAgICAgIHRvcGljczogREVGQVVMVF9JRlJBTUVTX0NPTkZJR1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgaWYgKGNvbmZpZykge1xuICAgICAgICAgICAgY2FsbFN1YnNjcmliZXJzKE9iamVjdC5rZXlzKGNvbmZpZykucmVkdWNlKChtZW1vLCB0b3BpYykgPT4ge1xuICAgICAgICAgICAgICAgIGlmIChjb25maWdbdG9waWNdICE9PSBuZXdDb25maWdbdG9waWNdKSB7XG4gICAgICAgICAgICAgICAgICAgIG1lbW9bdG9waWNdID0gbmV3Q29uZmlnW3RvcGljXSB8fCB7fTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lbW87XG4gICAgICAgICAgICB9LCB7fSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbmZpZyA9IG5ld0NvbmZpZztcbiAgICAgICAgYmlkZGVyQ29uZmlnID0ge307XG4gICAgfVxuICAgIC8qKlxuICAgICAqIFJldHVybnMgYmFzZSBjb25maWcgd2l0aCBiaWRkZXIgb3ZlcnJpZGVzIChpZiB0aGVyZSBpcyBjdXJyZW50bHkgYSBiaWRkZXIpXG4gICAgICogQHByaXZhdGVcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBfZ2V0Q29uZmlnKCkge1xuICAgICAgICBpZiAoY3VyckJpZGRlciAmJiBiaWRkZXJDb25maWcgJiYgaXNQbGFpbk9iamVjdChiaWRkZXJDb25maWdbY3VyckJpZGRlcl0pKSB7XG4gICAgICAgICAgICB2YXIgY3VyckJpZGRlckNvbmZpZyA9IGJpZGRlckNvbmZpZ1tjdXJyQmlkZGVyXTtcbiAgICAgICAgICAgIHZhciBjb25maWdUb3BpY1NldCA9IG5ldyBTZXQoT2JqZWN0LmtleXMoY29uZmlnKS5jb25jYXQoT2JqZWN0LmtleXMoY3VyckJpZGRlckNvbmZpZykpKTtcbiAgICAgICAgICAgIHJldHVybiBmcm9tKGNvbmZpZ1RvcGljU2V0KS5yZWR1Y2UoKG1lbW8sIHRvcGljKSA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKHR5cGVvZiBjdXJyQmlkZGVyQ29uZmlnW3RvcGljXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgbWVtb1t0b3BpY10gPSBjb25maWdbdG9waWNdO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmICh0eXBlb2YgY29uZmlnW3RvcGljXSA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICAgICAgbWVtb1t0b3BpY10gPSBjdXJyQmlkZGVyQ29uZmlnW3RvcGljXTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1BsYWluT2JqZWN0KGN1cnJCaWRkZXJDb25maWdbdG9waWNdKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgbWVtb1t0b3BpY10gPSBtZXJnZURlZXAoe30sIGNvbmZpZ1t0b3BpY10sIGN1cnJCaWRkZXJDb25maWdbdG9waWNdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIG1lbW9bdG9waWNdID0gY3VyckJpZGRlckNvbmZpZ1t0b3BpY107XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIG1lbW87XG4gICAgICAgICAgICB9LCB7fSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE9iamVjdC5hc3NpZ24oe30sIGNvbmZpZyk7XG4gICAgfVxuICAgIGZ1bmN0aW9uIF9nZXRSZXN0cmljdGVkQ29uZmlnKCkge1xuICAgICAgICAvLyBUaGlzIGNhdXNlcyByZWFkaW5nICdvcnRiMicgdG8gdGhyb3cgYW4gZXJyb3I7IHdpdGggcHJlYmlkIDcsIHRoYXQgd2lsbCBhbG1vc3RcbiAgICAgICAgLy8gYWx3YXlzIGJlIHRoZSBpbmNvcnJlY3Qgd2F5IHRvIGFjY2VzcyBGUEQgY29uZmlndXJhdGlvbiAoaHR0cHM6Ly9naXRodWIuY29tL3ByZWJpZC9QcmViaWQuanMvaXNzdWVzLzc2NTEpXG4gICAgICAgIC8vIGNvZGUgdGhhdCBuZWVkcyB0aGUgb3J0YjIgY29uZmlnIHNob3VsZCBleHBsaWNpdGx5IHVzZSBgZ2V0QW55Q29uZmlnYFxuICAgICAgICAvLyBUT0RPOiB0aGlzIGlzIG1lYW50IGFzIGEgdGVtcG9yYXJ5IHRyaXB3aXJlIHRvIGNhdGNoIGluYWR2ZXJ0ZW50IHVzZSBvZiBgZ2V0Q29uZmlnKCdvcnRiJylgIGFzIHdlIHRyYW5zaXRpb24uXG4gICAgICAgIC8vIEl0IHNob3VsZCBiZSByZW1vdmVkIG9uY2UgdGhlIHJpc2sgb2YgdGhhdCBoYXBwZW5pbmcgaXMgbG93IGVub3VnaC5cbiAgICAgICAgdmFyIGNvbmYgPSBfZ2V0Q29uZmlnKCk7XG4gICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjb25mLCAnb3J0YjInLCB7XG4gICAgICAgICAgICBnZXQ6IGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgYWNjZXNzIHRvIFxcJ29yYnQyXFwnIGNvbmZpZyAtIHVzZSByZXF1ZXN0IHBhcmFtZXRlcnMgaW5zdGVhZCcpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgICAgcmV0dXJuIGNvbmY7XG4gICAgfVxuICAgIHZhciBbZ2V0QW55Q29uZmlnLCBnZXRDb25maWddID0gW19nZXRDb25maWcsIF9nZXRSZXN0cmljdGVkQ29uZmlnXS5tYXAoYWNjZXNzb3IgPT4ge1xuICAgICAgICAvKlxuICAgICAgICAgKiBSZXR1cm5zIGNvbmZpZ3VyYXRpb24gb2JqZWN0IGlmIGNhbGxlZCB3aXRob3V0IHBhcmFtZXRlcnMsXG4gICAgICAgICAqIG9yIHNpbmdsZSBjb25maWd1cmF0aW9uIHByb3BlcnR5IGlmIGdpdmVuIGEgc3RyaW5nIG1hdGNoaW5nIGEgY29uZmlndXJhdGlvblxuICAgICAgICAgKiBwcm9wZXJ0eSBuYW1lLiAgQWxsb3dzIGRlZXAgYWNjZXNzIGUuZy4gZ2V0Q29uZmlnKCdjdXJyZW5jeS5hZFNlcnZlckN1cnJlbmN5JylcbiAgICAgICAgICpcbiAgICAgICAgICogSWYgY2FsbGVkIHdpdGggY2FsbGJhY2sgcGFyYW1ldGVyLCBvciBhIHN0cmluZyBhbmQgYSBjYWxsYmFjayBwYXJhbWV0ZXIsXG4gICAgICAgICAqIHN1YnNjcmliZXMgdG8gY29uZmlndXJhdGlvbiB1cGRhdGVzLiBTZWUgYHN1YnNjcmliZWAgZnVuY3Rpb24gZm9yIHVzYWdlLlxuICAgICAgICAgKi9cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGdldENvbmZpZygpIHtcbiAgICAgICAgICAgIGlmIChhcmd1bWVudHMubGVuZ3RoIDw9IDEgJiYgdHlwZW9mIChhcmd1bWVudHMubGVuZ3RoIDw9IDAgPyB1bmRlZmluZWQgOiBhcmd1bWVudHNbMF0pICE9PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgdmFyIG9wdGlvbiA9IGFyZ3VtZW50cy5sZW5ndGggPD0gMCA/IHVuZGVmaW5lZCA6IGFyZ3VtZW50c1swXTtcbiAgICAgICAgICAgICAgICByZXR1cm4gb3B0aW9uID8gZGVlcEFjY2VzcyhhY2Nlc3NvcigpLCBvcHRpb24pIDogX2dldENvbmZpZygpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHN1YnNjcmliZSguLi5hcmd1bWVudHMpO1xuICAgICAgICB9O1xuICAgIH0pO1xuICAgIHZhciBbcmVhZENvbmZpZywgcmVhZEFueUNvbmZpZ10gPSBbZ2V0Q29uZmlnLCBnZXRBbnlDb25maWddLm1hcCh3cmFwZWUgPT4ge1xuICAgICAgICAvKlxuICAgICAgICAgKiBMaWtlIGdldENvbmZpZywgZXhjZXB0IHRoYXQgaXQgcmV0dXJucyBhIGRlZXBDbG9uZSBvZiB0aGUgcmVzdWx0LlxuICAgICAgICAgKi9cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIHJlYWRDb25maWcoKSB7XG4gICAgICAgICAgICB2YXIgcmVzID0gd3JhcGVlKC4uLmFyZ3VtZW50cyk7XG4gICAgICAgICAgICBpZiAocmVzICYmIHR5cGVvZiByZXMgPT09ICdvYmplY3QnKSB7XG4gICAgICAgICAgICAgICAgcmVzID0gZGVlcENsb25lKHJlcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgICB9O1xuICAgIH0pO1xuICAgIC8qKlxuICAgICAqIEludGVybmFsIEFQSSBmb3IgbW9kdWxlcyAoc3VjaCBhcyBwcmViaWQtc2VydmVyKSB0aGF0IG1pZ2h0IG5lZWQgYWNjZXNzIHRvIGFsbCBiaWRkZXIgY29uZmlnXG4gICAgICovXG4gICAgZnVuY3Rpb24gZ2V0QmlkZGVyQ29uZmlnKCkge1xuICAgICAgICByZXR1cm4gYmlkZGVyQ29uZmlnO1xuICAgIH1cbiAgICAvKlxuICAgICAqIFNldHMgY29uZmlndXJhdGlvbiBnaXZlbiBhbiBvYmplY3QgY29udGFpbmluZyBrZXktdmFsdWUgcGFpcnMgYW5kIGNhbGxzXG4gICAgICogbGlzdGVuZXJzIHRoYXQgd2VyZSBhZGRlZCBieSB0aGUgYHN1YnNjcmliZWAgZnVuY3Rpb25cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBzZXRDb25maWcob3B0aW9ucykge1xuICAgICAgICBpZiAoIWlzUGxhaW5PYmplY3Qob3B0aW9ucykpIHtcbiAgICAgICAgICAgIGxvZ0Vycm9yKCdzZXRDb25maWcgb3B0aW9ucyBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHZhciB0b3BpY3MgPSBPYmplY3Qua2V5cyhvcHRpb25zKTtcbiAgICAgICAgdmFyIHRvcGljYWxDb25maWcgPSB7fTtcbiAgICAgICAgdG9waWNzLmZvckVhY2godG9waWMgPT4ge1xuICAgICAgICAgICAgdmFyIG9wdGlvbiA9IG9wdGlvbnNbdG9waWNdO1xuICAgICAgICAgICAgaWYgKGlzUGxhaW5PYmplY3QoZGVmYXVsdHNbdG9waWNdKSAmJiBpc1BsYWluT2JqZWN0KG9wdGlvbikpIHtcbiAgICAgICAgICAgICAgICBvcHRpb24gPSBPYmplY3QuYXNzaWduKHt9LCBkZWZhdWx0c1t0b3BpY10sIG9wdGlvbik7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHRvcGljYWxDb25maWdbdG9waWNdID0gY29uZmlnW3RvcGljXSA9IG9wdGlvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgbG9nV2FybihcIkNhbm5vdCBzZXQgY29uZmlnIGZvciBwcm9wZXJ0eSBcIi5jb25jYXQodG9waWMsIFwiIDogXCIpLCBlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICAgIGNhbGxTdWJzY3JpYmVycyh0b3BpY2FsQ29uZmlnKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogU2V0cyBjb25maWd1cmF0aW9uIGRlZmF1bHRzIHdoaWNoIHNldENvbmZpZyB2YWx1ZXMgY2FuIGJlIGFwcGxpZWQgb24gdG9wIG9mXG4gICAgICogQHBhcmFtIHtvYmplY3R9IG9wdGlvbnNcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBzZXREZWZhdWx0cyhvcHRpb25zKSB7XG4gICAgICAgIGlmICghaXNQbGFpbk9iamVjdChkZWZhdWx0cykpIHtcbiAgICAgICAgICAgIGxvZ0Vycm9yKCdkZWZhdWx0cyBtdXN0IGJlIGFuIG9iamVjdCcpO1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIE9iamVjdC5hc3NpZ24oZGVmYXVsdHMsIG9wdGlvbnMpO1xuICAgICAgICAvLyBBZGQgZGVmYXVsdCB2YWx1ZXMgdG8gY29uZmlnIGFzIHdlbGxcbiAgICAgICAgT2JqZWN0LmFzc2lnbihjb25maWcsIG9wdGlvbnMpO1xuICAgIH1cbiAgICAvKlxuICAgICAqIEFkZHMgYSBmdW5jdGlvbiB0byBhIHNldCBvZiBsaXN0ZW5lcnMgdGhhdCBhcmUgaW52b2tlZCB3aGVuZXZlciBgc2V0Q29uZmlnYFxuICAgICAqIGlzIGNhbGxlZC4gVGhlIHN1YnNjcmliZWQgZnVuY3Rpb24gd2lsbCBiZSBwYXNzZWQgdGhlIG9wdGlvbnMgb2JqZWN0IHRoYXRcbiAgICAgKiB3YXMgdXNlZCBpbiB0aGUgYHNldENvbmZpZ2AgY2FsbC4gVG9waWNzIGNhbiBiZSBzdWJzY3JpYmVkIHRvIHRvIG9ubHkgZ2V0XG4gICAgICogdXBkYXRlcyB3aGVuIHNwZWNpZmljIHByb3BlcnRpZXMgYXJlIHVwZGF0ZWQgYnkgcGFzc2luZyBhIHRvcGljIHN0cmluZyBhc1xuICAgICAqIHRoZSBmaXJzdCBwYXJhbWV0ZXIuXG4gICAgICpcbiAgICAgKiBJZiBgb3B0aW9ucy5pbml0YCBpcyB0cnVlLCB0aGUgbGlzdGVuZXIgd2lsbCBiZSBpbW1lZGlhdGVseSBjYWxsZWQgd2l0aCB0aGUgY3VycmVudCBvcHRpb25zLlxuICAgICAqXG4gICAgICogUmV0dXJucyBhbiBgdW5zdWJzY3JpYmVgIGZ1bmN0aW9uIGZvciByZW1vdmluZyB0aGUgc3Vic2NyaWJlciBmcm9tIHRoZVxuICAgICAqIHNldCBvZiBsaXN0ZW5lcnNcbiAgICAgKlxuICAgICAqIEV4YW1wbGUgdXNlOlxuICAgICAqIC8vIHN1YnNjcmliZSB0byBhbGwgY29uZmlndXJhdGlvbiBjaGFuZ2VzXG4gICAgICogc3Vic2NyaWJlKChjb25maWcpID0+IGNvbnNvbGUubG9nKCdjb25maWcgc2V0OicsIGNvbmZpZykpO1xuICAgICAqXG4gICAgICogLy8gc3Vic2NyaWJlIHRvIG9ubHkgJ2xvZ2dpbmcnIGNoYW5nZXNcbiAgICAgKiBzdWJzY3JpYmUoJ2xvZ2dpbmcnLCAoY29uZmlnKSA9PiBjb25zb2xlLmxvZygnbG9nZ2luZyBzZXQ6JywgY29uZmlnKSk7XG4gICAgICpcbiAgICAgKiAvLyB1bnN1YnNjcmliZVxuICAgICAqIGNvbnN0IHVuc3Vic2NyaWJlID0gc3Vic2NyaWJlKC4uLik7XG4gICAgICogdW5zdWJzY3JpYmUoKTsgLy8gbm8gbG9uZ2VyIGxpc3RlbmluZ1xuICAgICAqXG4gICAgICovXG4gICAgZnVuY3Rpb24gc3Vic2NyaWJlKHRvcGljLCBsaXN0ZW5lcikge1xuICAgICAgICB2YXIgb3B0aW9ucyA9IGFyZ3VtZW50cy5sZW5ndGggPiAyICYmIGFyZ3VtZW50c1syXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzJdIDoge307XG4gICAgICAgIHZhciBjYWxsYmFjayA9IGxpc3RlbmVyO1xuICAgICAgICBpZiAodHlwZW9mIHRvcGljICE9PSAnc3RyaW5nJykge1xuICAgICAgICAgICAgLy8gZmlyc3QgcGFyYW0gc2hvdWxkIGJlIGNhbGxiYWNrIGZ1bmN0aW9uIGluIHRoaXMgY2FzZSxcbiAgICAgICAgICAgIC8vIG1lYW5pbmcgaXQgZ2V0cyBjYWxsZWQgZm9yIGFueSBjb25maWcgY2hhbmdlXG4gICAgICAgICAgICBjYWxsYmFjayA9IHRvcGljO1xuICAgICAgICAgICAgdG9waWMgPSBBTExfVE9QSUNTO1xuICAgICAgICAgICAgb3B0aW9ucyA9IGxpc3RlbmVyIHx8IHt9O1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgY2FsbGJhY2sgIT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIGxvZ0Vycm9yKCdsaXN0ZW5lciBtdXN0IGJlIGEgZnVuY3Rpb24nKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgbmwgPSB7XG4gICAgICAgICAgICB0b3BpYyxcbiAgICAgICAgICAgIGNhbGxiYWNrXG4gICAgICAgIH07XG4gICAgICAgIGxpc3RlbmVycy5wdXNoKG5sKTtcbiAgICAgICAgaWYgKG9wdGlvbnMuaW5pdCkge1xuICAgICAgICAgICAgaWYgKHRvcGljID09PSBBTExfVE9QSUNTKSB7XG4gICAgICAgICAgICAgICAgY2FsbGJhY2soZ2V0Q29uZmlnKCkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIHN0YW5kYXJkL25vLWNhbGxiYWNrLWxpdGVyYWxcbiAgICAgICAgICAgICAgICBjYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgICAgIFt0b3BpY106IGdldENvbmZpZyh0b3BpYylcbiAgICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICAvLyBzYXZlIGFuZCBjYWxsIHRoaXMgZnVuY3Rpb24gdG8gcmVtb3ZlIHRoZSBsaXN0ZW5lclxuICAgICAgICByZXR1cm4gZnVuY3Rpb24gdW5zdWJzY3JpYmUoKSB7XG4gICAgICAgICAgICBsaXN0ZW5lcnMuc3BsaWNlKGxpc3RlbmVycy5pbmRleE9mKG5sKSwgMSk7XG4gICAgICAgIH07XG4gICAgfVxuICAgIC8qXG4gICAgICogQ2FsbHMgbGlzdGVuZXJzIHRoYXQgd2VyZSBhZGRlZCBieSB0aGUgYHN1YnNjcmliZWAgZnVuY3Rpb25cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjYWxsU3Vic2NyaWJlcnMob3B0aW9ucykge1xuICAgICAgICB2YXIgVE9QSUNTID0gT2JqZWN0LmtleXMob3B0aW9ucyk7XG4gICAgICAgIC8vIGNhbGwgc3Vic2NyaWJlcnMgb2YgYSBzcGVjaWZpYyB0b3BpYywgcGFzc2luZyBvbmx5IHRoYXQgY29uZmlndXJhdGlvblxuICAgICAgICBsaXN0ZW5lcnMuZmlsdGVyKGxpc3RlbmVyID0+IGluY2x1ZGVzKFRPUElDUywgbGlzdGVuZXIudG9waWMpKS5mb3JFYWNoKGxpc3RlbmVyID0+IHtcbiAgICAgICAgICAgIGxpc3RlbmVyLmNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICBbbGlzdGVuZXIudG9waWNdOiBvcHRpb25zW2xpc3RlbmVyLnRvcGljXVxuICAgICAgICAgICAgfSk7XG4gICAgICAgIH0pO1xuICAgICAgICAvLyBjYWxsIHN1YnNjcmliZXJzIHRoYXQgZGlkbid0IGdpdmUgYSB0b3BpYywgcGFzc2luZyBldmVyeXRoaW5nIHRoYXQgd2FzIHNldFxuICAgICAgICBsaXN0ZW5lcnMuZmlsdGVyKGxpc3RlbmVyID0+IGxpc3RlbmVyLnRvcGljID09PSBBTExfVE9QSUNTKS5mb3JFYWNoKGxpc3RlbmVyID0+IGxpc3RlbmVyLmNhbGxiYWNrKG9wdGlvbnMpKTtcbiAgICB9XG4gICAgZnVuY3Rpb24gc2V0QmlkZGVyQ29uZmlnKGNvbmZpZykge1xuICAgICAgICB2YXIgbWVyZ2VGbGFnID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiBmYWxzZTtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIGNoZWNrKGNvbmZpZyk7XG4gICAgICAgICAgICBjb25maWcuYmlkZGVycy5mb3JFYWNoKGJpZGRlciA9PiB7XG4gICAgICAgICAgICAgICAgaWYgKCFiaWRkZXJDb25maWdbYmlkZGVyXSkge1xuICAgICAgICAgICAgICAgICAgICBiaWRkZXJDb25maWdbYmlkZGVyXSA9IGF0dGFjaFByb3BlcnRpZXMoe30sIGZhbHNlKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgT2JqZWN0LmtleXMoY29uZmlnLmNvbmZpZykuZm9yRWFjaCh0b3BpYyA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHZhciBvcHRpb24gPSBjb25maWcuY29uZmlnW3RvcGljXTtcbiAgICAgICAgICAgICAgICAgICAgdmFyIGN1cnJlbnRDb25maWcgPSBiaWRkZXJDb25maWdbYmlkZGVyXVt0b3BpY107XG4gICAgICAgICAgICAgICAgICAgIGlmIChpc1BsYWluT2JqZWN0KG9wdGlvbikgJiYgKGN1cnJlbnRDb25maWcgPT0gbnVsbCB8fCBpc1BsYWluT2JqZWN0KGN1cnJlbnRDb25maWcpKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgdmFyIGZ1bmMgPSBtZXJnZUZsYWcgPyBtZXJnZURlZXAgOiBPYmplY3QuYXNzaWduO1xuICAgICAgICAgICAgICAgICAgICAgICAgYmlkZGVyQ29uZmlnW2JpZGRlcl1bdG9waWNdID0gZnVuYyh7fSwgY3VycmVudENvbmZpZyB8fCB7fSwgb3B0aW9uKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGJpZGRlckNvbmZpZ1tiaWRkZXJdW3RvcGljXSA9IG9wdGlvbjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgIGxvZ0Vycm9yKGUpO1xuICAgICAgICB9XG4gICAgICAgIGZ1bmN0aW9uIGNoZWNrKG9iaikge1xuICAgICAgICAgICAgaWYgKCFpc1BsYWluT2JqZWN0KG9iaikpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyAnc2V0QmlkZGVyQ29uZmlnIGJpZGRlciBvcHRpb25zIG11c3QgYmUgYW4gb2JqZWN0JztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghKEFycmF5LmlzQXJyYXkob2JqLmJpZGRlcnMpICYmIG9iai5iaWRkZXJzLmxlbmd0aCkpIHtcbiAgICAgICAgICAgICAgICB0aHJvdyAnc2V0QmlkZGVyQ29uZmlnIGJpZGRlciBvcHRpb25zIG11c3QgY29udGFpbiBhIGJpZGRlcnMgbGlzdCB3aXRoIGF0IGxlYXN0IDEgYmlkZGVyJztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmICghaXNQbGFpbk9iamVjdChvYmouY29uZmlnKSkge1xuICAgICAgICAgICAgICAgIHRocm93ICdzZXRCaWRkZXJDb25maWcgYmlkZGVyIG9wdGlvbnMgbXVzdCBjb250YWluIGEgY29uZmlnIG9iamVjdCc7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgZnVuY3Rpb24gbWVyZ2VDb25maWcob2JqKSB7XG4gICAgICAgIGlmICghaXNQbGFpbk9iamVjdChvYmopKSB7XG4gICAgICAgICAgICBsb2dFcnJvcignbWVyZ2VDb25maWcgaW5wdXQgbXVzdCBiZSBhbiBvYmplY3QnKTtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB2YXIgbWVyZ2VkQ29uZmlnID0gbWVyZ2VEZWVwKF9nZXRDb25maWcoKSwgb2JqKTtcbiAgICAgICAgc2V0Q29uZmlnKF9vYmplY3RTcHJlYWQoe30sIG1lcmdlZENvbmZpZykpO1xuICAgICAgICByZXR1cm4gbWVyZ2VkQ29uZmlnO1xuICAgIH1cbiAgICBmdW5jdGlvbiBtZXJnZUJpZGRlckNvbmZpZyhvYmopIHtcbiAgICAgICAgcmV0dXJuIHNldEJpZGRlckNvbmZpZyhvYmosIHRydWUpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBJbnRlcm5hbCBmdW5jdGlvbnMgZm9yIGNvcmUgdG8gZXhlY3V0ZSBzb21lIHN5bmNocm9ub3VzIGNvZGUgd2hpbGUgaGF2aW5nIGFuIGFjdGl2ZSBiaWRkZXIgc2V0LlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHJ1bldpdGhCaWRkZXIoYmlkZGVyLCBmbikge1xuICAgICAgICBjdXJyQmlkZGVyID0gYmlkZGVyO1xuICAgICAgICB0cnkge1xuICAgICAgICAgICAgcmV0dXJuIGZuKCk7XG4gICAgICAgIH1cbiAgICAgICAgZmluYWxseSB7XG4gICAgICAgICAgICByZXNldEJpZGRlcigpO1xuICAgICAgICB9XG4gICAgfVxuICAgIGZ1bmN0aW9uIGNhbGxiYWNrV2l0aEJpZGRlcihiaWRkZXIpIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIChjYikge1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGNiID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgYXJnc1tfa2V5XSA9IGFyZ3VtZW50c1tfa2V5XTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gcnVuV2l0aEJpZGRlcihiaWRkZXIsIGNiLmJpbmQodGhpcywgLi4uYXJncykpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICAgICAgbG9nV2FybignY29uZmlnLmNhbGxiYWNrV2l0aEJpZGRlciBjYWxsYmFjayBpcyBub3QgYSBmdW5jdGlvbicpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH07XG4gICAgICAgIH07XG4gICAgfVxuICAgIGZ1bmN0aW9uIGdldEN1cnJlbnRCaWRkZXIoKSB7XG4gICAgICAgIHJldHVybiBjdXJyQmlkZGVyO1xuICAgIH1cbiAgICBmdW5jdGlvbiByZXNldEJpZGRlcigpIHtcbiAgICAgICAgY3VyckJpZGRlciA9IG51bGw7XG4gICAgfVxuICAgIHJlc2V0Q29uZmlnKCk7XG4gICAgcmV0dXJuIHtcbiAgICAgICAgZ2V0Q3VycmVudEJpZGRlcixcbiAgICAgICAgcmVzZXRCaWRkZXIsXG4gICAgICAgIGdldENvbmZpZyxcbiAgICAgICAgZ2V0QW55Q29uZmlnLFxuICAgICAgICByZWFkQ29uZmlnLFxuICAgICAgICByZWFkQW55Q29uZmlnLFxuICAgICAgICBzZXRDb25maWcsXG4gICAgICAgIG1lcmdlQ29uZmlnLFxuICAgICAgICBzZXREZWZhdWx0cyxcbiAgICAgICAgcmVzZXRDb25maWcsXG4gICAgICAgIHJ1bldpdGhCaWRkZXIsXG4gICAgICAgIGNhbGxiYWNrV2l0aEJpZGRlcixcbiAgICAgICAgc2V0QmlkZGVyQ29uZmlnLFxuICAgICAgICBnZXRCaWRkZXJDb25maWcsXG4gICAgICAgIG1lcmdlQmlkZGVyQ29uZmlnXG4gICAgfTtcbn1cbi8qKlxuICogU2V0IGEgYGNhY2hlLnVybGAgaWYgd2Ugc2hvdWxkIHVzZSBwcmViaWQtY2FjaGUgdG8gc3RvcmUgdmlkZW8gYmlkcyBiZWZvcmUgYWRkaW5nIGJpZHMgdG8gdGhlIGF1Y3Rpb24uXG4gKiBUaGlzIG11c3QgYmUgc2V0IGlmIHlvdSB3YW50IHRvIHVzZSB0aGUgZGZwQWRTZXJ2ZXJWaWRlbyBtb2R1bGUuXG4gKi9cbmV4cG9ydCB2YXIgY29uZmlnID0gbmV3Q29uZmlnKCk7XG4iLCJleHBvcnQgdmFyIEpTT05fTUFQUElORyA9IHtcbiAgICBQTF9DT0RFOiAnY29kZScsXG4gICAgUExfU0laRTogJ3NpemVzJyxcbiAgICBQTF9CSURTOiAnYmlkcycsXG4gICAgQkRfQklEREVSOiAnYmlkZGVyJyxcbiAgICBCRF9JRDogJ3BhcmFtc2QnLFxuICAgIEJEX1BMX0lEOiAncGxhY2VtZW50SWQnLFxuICAgIEFEU0VSVkVSX1RBUkdFVElORzogJ2Fkc2VydmVyVGFyZ2V0aW5nJyxcbiAgICBCRF9TRVRUSU5HX1NUQU5EQVJEOiAnc3RhbmRhcmQnXG59O1xuZXhwb3J0IHZhciBERUJVR19NT0RFID0gJ3BianNfZGVidWcnO1xuZXhwb3J0IHZhciBTVEFUVVMgPSB7XG4gICAgR09PRDogMVxufTtcbmV4cG9ydCB2YXIgRVZFTlRTID0ge1xuICAgIEFVQ1RJT05fSU5JVDogJ2F1Y3Rpb25Jbml0JyxcbiAgICBBVUNUSU9OX1RJTUVPVVQ6ICdhdWN0aW9uVGltZW91dCcsXG4gICAgQVVDVElPTl9FTkQ6ICdhdWN0aW9uRW5kJyxcbiAgICBCSURfQURKVVNUTUVOVDogJ2JpZEFkanVzdG1lbnQnLFxuICAgIEJJRF9USU1FT1VUOiAnYmlkVGltZW91dCcsXG4gICAgQklEX1JFUVVFU1RFRDogJ2JpZFJlcXVlc3RlZCcsXG4gICAgQklEX1JFU1BPTlNFOiAnYmlkUmVzcG9uc2UnLFxuICAgIEJJRF9SRUpFQ1RFRDogJ2JpZFJlamVjdGVkJyxcbiAgICBOT19CSUQ6ICdub0JpZCcsXG4gICAgU0VBVF9OT05fQklEOiAnc2VhdE5vbkJpZCcsXG4gICAgQklEX1dPTjogJ2JpZFdvbicsXG4gICAgQklEREVSX0RPTkU6ICdiaWRkZXJEb25lJyxcbiAgICBCSURERVJfRVJST1I6ICdiaWRkZXJFcnJvcicsXG4gICAgU0VUX1RBUkdFVElORzogJ3NldFRhcmdldGluZycsXG4gICAgQkVGT1JFX1JFUVVFU1RfQklEUzogJ2JlZm9yZVJlcXVlc3RCaWRzJyxcbiAgICBCRUZPUkVfQklEREVSX0hUVFA6ICdiZWZvcmVCaWRkZXJIdHRwJyxcbiAgICBSRVFVRVNUX0JJRFM6ICdyZXF1ZXN0QmlkcycsXG4gICAgQUREX0FEX1VOSVRTOiAnYWRkQWRVbml0cycsXG4gICAgQURfUkVOREVSX0ZBSUxFRDogJ2FkUmVuZGVyRmFpbGVkJyxcbiAgICBBRF9SRU5ERVJfU1VDQ0VFREVEOiAnYWRSZW5kZXJTdWNjZWVkZWQnLFxuICAgIFRDRjJfRU5GT1JDRU1FTlQ6ICd0Y2YyRW5mb3JjZW1lbnQnLFxuICAgIEFVQ1RJT05fREVCVUc6ICdhdWN0aW9uRGVidWcnLFxuICAgIEJJRF9WSUVXQUJMRTogJ2JpZFZpZXdhYmxlJyxcbiAgICBTVEFMRV9SRU5ERVI6ICdzdGFsZVJlbmRlcicsXG4gICAgRVhQSVJFRF9SRU5ERVI6ICdleHBpcmVkUmVuZGVyJyxcbiAgICBCSUxMQUJMRV9FVkVOVDogJ2JpbGxhYmxlRXZlbnQnLFxuICAgIEJJRF9BQ0NFUFRFRDogJ2JpZEFjY2VwdGVkJyxcbiAgICBSVU5fUEFBUElfQVVDVElPTjogJ3BhYXBpUnVuQXVjdGlvbicsXG4gICAgUEJTX0FOQUxZVElDUzogJ3Bic0FuYWx5dGljcycsXG4gICAgUEFBUElfQklEOiAncGFhcGlCaWQnLFxuICAgIFBBQVBJX05PX0JJRDogJ3BhYXBpTm9CaWQnLFxuICAgIFBBQVBJX0VSUk9SOiAncGFhcGlFcnJvcidcbn07XG5leHBvcnQgdmFyIEFEX1JFTkRFUl9GQUlMRURfUkVBU09OID0ge1xuICAgIFBSRVZFTlRfV1JJVElOR19PTl9NQUlOX0RPQ1VNRU5UOiAncHJldmVudFdyaXRpbmdPbk1haW5Eb2N1bWVudCcsXG4gICAgTk9fQUQ6ICdub0FkJyxcbiAgICBFWENFUFRJT046ICdleGNlcHRpb24nLFxuICAgIENBTk5PVF9GSU5EX0FEOiAnY2Fubm90RmluZEFkJyxcbiAgICBNSVNTSU5HX0RPQ19PUl9BRElEOiAnbWlzc2luZ0RvY09yQWRpZCdcbn07XG5leHBvcnQgdmFyIEVWRU5UX0lEX1BBVEhTID0ge1xuICAgIGJpZFdvbjogJ2FkVW5pdENvZGUnXG59O1xuZXhwb3J0IHZhciBHUkFOVUxBUklUWV9PUFRJT05TID0ge1xuICAgIExPVzogJ2xvdycsXG4gICAgTUVESVVNOiAnbWVkaXVtJyxcbiAgICBISUdIOiAnaGlnaCcsXG4gICAgQVVUTzogJ2F1dG8nLFxuICAgIERFTlNFOiAnZGVuc2UnLFxuICAgIENVU1RPTTogJ2N1c3RvbSdcbn07XG5leHBvcnQgdmFyIFRBUkdFVElOR19LRVlTID0ge1xuICAgIEJJRERFUjogJ2hiX2JpZGRlcicsXG4gICAgQURfSUQ6ICdoYl9hZGlkJyxcbiAgICBQUklDRV9CVUNLRVQ6ICdoYl9wYicsXG4gICAgU0laRTogJ2hiX3NpemUnLFxuICAgIERFQUw6ICdoYl9kZWFsJyxcbiAgICBTT1VSQ0U6ICdoYl9zb3VyY2UnLFxuICAgIEZPUk1BVDogJ2hiX2Zvcm1hdCcsXG4gICAgVVVJRDogJ2hiX3V1aWQnLFxuICAgIENBQ0hFX0lEOiAnaGJfY2FjaGVfaWQnLFxuICAgIENBQ0hFX0hPU1Q6ICdoYl9jYWNoZV9ob3N0JyxcbiAgICBBRE9NQUlOOiAnaGJfYWRvbWFpbicsXG4gICAgQUNBVDogJ2hiX2FjYXQnLFxuICAgIENSSUQ6ICdoYl9jcmlkJyxcbiAgICBEU1A6ICdoYl9kc3AnXG59O1xuZXhwb3J0IHZhciBERUZBVUxUX1RBUkdFVElOR19LRVlTID0ge1xuICAgIEJJRERFUjogJ2hiX2JpZGRlcicsXG4gICAgQURfSUQ6ICdoYl9hZGlkJyxcbiAgICBQUklDRV9CVUNLRVQ6ICdoYl9wYicsXG4gICAgU0laRTogJ2hiX3NpemUnLFxuICAgIERFQUw6ICdoYl9kZWFsJyxcbiAgICBGT1JNQVQ6ICdoYl9mb3JtYXQnLFxuICAgIFVVSUQ6ICdoYl91dWlkJyxcbiAgICBDQUNIRV9IT1NUOiAnaGJfY2FjaGVfaG9zdCdcbn07XG5leHBvcnQgdmFyIE5BVElWRV9LRVlTID0ge1xuICAgIHRpdGxlOiAnaGJfbmF0aXZlX3RpdGxlJyxcbiAgICBib2R5OiAnaGJfbmF0aXZlX2JvZHknLFxuICAgIGJvZHkyOiAnaGJfbmF0aXZlX2JvZHkyJyxcbiAgICBwcml2YWN5TGluazogJ2hiX25hdGl2ZV9wcml2YWN5JyxcbiAgICBwcml2YWN5SWNvbjogJ2hiX25hdGl2ZV9wcml2aWNvbicsXG4gICAgc3BvbnNvcmVkQnk6ICdoYl9uYXRpdmVfYnJhbmQnLFxuICAgIGltYWdlOiAnaGJfbmF0aXZlX2ltYWdlJyxcbiAgICBpY29uOiAnaGJfbmF0aXZlX2ljb24nLFxuICAgIGNsaWNrVXJsOiAnaGJfbmF0aXZlX2xpbmt1cmwnLFxuICAgIGRpc3BsYXlVcmw6ICdoYl9uYXRpdmVfZGlzcGxheXVybCcsXG4gICAgY3RhOiAnaGJfbmF0aXZlX2N0YScsXG4gICAgcmF0aW5nOiAnaGJfbmF0aXZlX3JhdGluZycsXG4gICAgYWRkcmVzczogJ2hiX25hdGl2ZV9hZGRyZXNzJyxcbiAgICBkb3dubG9hZHM6ICdoYl9uYXRpdmVfZG93bmxvYWRzJyxcbiAgICBsaWtlczogJ2hiX25hdGl2ZV9saWtlcycsXG4gICAgcGhvbmU6ICdoYl9uYXRpdmVfcGhvbmUnLFxuICAgIHByaWNlOiAnaGJfbmF0aXZlX3ByaWNlJyxcbiAgICBzYWxlUHJpY2U6ICdoYl9uYXRpdmVfc2FsZXByaWNlJyxcbiAgICByZW5kZXJlclVybDogJ2hiX3JlbmRlcmVyX3VybCcsXG4gICAgYWRUZW1wbGF0ZTogJ2hiX2FkVGVtcGxhdGUnXG59O1xuZXhwb3J0IHZhciBTMlMgPSB7XG4gICAgU1JDOiAnczJzJyxcbiAgICBERUZBVUxUX0VORFBPSU5UOiAnaHR0cHM6Ly9wcmViaWQuYWRueHMuY29tL3Bicy92MS9vcGVucnRiMi9hdWN0aW9uJyxcbiAgICBTWU5DRURfQklEREVSU19LRVk6ICdwYmpzU3luY3MnXG59O1xuZXhwb3J0IHZhciBCSURfU1RBVFVTID0ge1xuICAgIEJJRF9UQVJHRVRJTkdfU0VUOiAndGFyZ2V0aW5nU2V0JyxcbiAgICBSRU5ERVJFRDogJ3JlbmRlcmVkJyxcbiAgICBCSURfUkVKRUNURUQ6ICdiaWRSZWplY3RlZCdcbn07XG5leHBvcnQgdmFyIFJFSkVDVElPTl9SRUFTT04gPSB7XG4gICAgSU5WQUxJRDogJ0JpZCBoYXMgbWlzc2luZyBvciBpbnZhbGlkIHByb3BlcnRpZXMnLFxuICAgIElOVkFMSURfUkVRVUVTVF9JRDogJ0ludmFsaWQgcmVxdWVzdCBJRCcsXG4gICAgQklEREVSX0RJU0FMTE9XRUQ6ICdCaWRkZXIgY29kZSBpcyBub3QgYWxsb3dlZCBieSBhbGxvd2VkQWx0ZXJuYXRlQmlkZGVyQ29kZXMgLyBhbGxvd1Vua25vd25CaWRkZXJDb2RlcycsXG4gICAgRkxPT1JfTk9UX01FVDogJ0JpZCBkb2VzIG5vdCBtZWV0IHByaWNlIGZsb29yJyxcbiAgICBDQU5OT1RfQ09OVkVSVF9DVVJSRU5DWTogJ1VuYWJsZSB0byBjb252ZXJ0IGN1cnJlbmN5JyxcbiAgICBEU0FfUkVRVUlSRUQ6ICdCaWQgZG9lcyBub3QgcHJvdmlkZSByZXF1aXJlZCBEU0EgdHJhbnNwYXJlbmN5IGluZm8nLFxuICAgIERTQV9NSVNNQVRDSDogJ0JpZCBpbmRpY2F0ZXMgaW5hcHByb3ByaWF0ZSBEU0EgcmVuZGVyaW5nIG1ldGhvZCcsXG4gICAgUFJJQ0VfVE9PX0hJR0g6ICdCaWQgcHJpY2UgZXhjZWVkcyBtYXhpbXVtIHZhbHVlJ1xufTtcbmV4cG9ydCB2YXIgUFJFQklEX05BVElWRV9EQVRBX0tFWVNfVE9fT1JUQiA9IHtcbiAgICBib2R5OiAnZGVzYycsXG4gICAgYm9keTI6ICdkZXNjMicsXG4gICAgc3BvbnNvcmVkQnk6ICdzcG9uc29yZWQnLFxuICAgIGN0YTogJ2N0YXRleHQnLFxuICAgIHJhdGluZzogJ3JhdGluZycsXG4gICAgYWRkcmVzczogJ2FkZHJlc3MnLFxuICAgIGRvd25sb2FkczogJ2Rvd25sb2FkcycsXG4gICAgbGlrZXM6ICdsaWtlcycsXG4gICAgcGhvbmU6ICdwaG9uZScsXG4gICAgcHJpY2U6ICdwcmljZScsXG4gICAgc2FsZVByaWNlOiAnc2FsZXByaWNlJyxcbiAgICBkaXNwbGF5VXJsOiAnZGlzcGxheXVybCdcbn07XG5leHBvcnQgdmFyIE5BVElWRV9BU1NFVF9UWVBFUyA9IHtcbiAgICBzcG9uc29yZWQ6IDEsXG4gICAgZGVzYzogMixcbiAgICByYXRpbmc6IDMsXG4gICAgbGlrZXM6IDQsXG4gICAgZG93bmxvYWRzOiA1LFxuICAgIHByaWNlOiA2LFxuICAgIHNhbGVwcmljZTogNyxcbiAgICBwaG9uZTogOCxcbiAgICBhZGRyZXNzOiA5LFxuICAgIGRlc2MyOiAxMCxcbiAgICBkaXNwbGF5dXJsOiAxMSxcbiAgICBjdGF0ZXh0OiAxMlxufTtcbmV4cG9ydCB2YXIgTkFUSVZFX0lNQUdFX1RZUEVTID0ge1xuICAgIElDT046IDEsXG4gICAgTUFJTjogM1xufTtcbmV4cG9ydCB2YXIgTkFUSVZFX0tFWVNfVEhBVF9BUkVfTk9UX0FTU0VUUyA9IFsncHJpdmFjeUljb24nLCAnY2xpY2tVcmwnLCAnc2VuZFRhcmdldGluZ0tleXMnLCAnYWRUZW1wbGF0ZScsICdyZW5kZXJlclVybCcsICd0eXBlJ107XG5leHBvcnQgdmFyIE1FU1NBR0VTID0ge1xuICAgIFJFUVVFU1Q6ICdQcmViaWQgUmVxdWVzdCcsXG4gICAgUkVTUE9OU0U6ICdQcmViaWQgUmVzcG9uc2UnLFxuICAgIE5BVElWRTogJ1ByZWJpZCBOYXRpdmUnLFxuICAgIEVWRU5UOiAnUHJlYmlkIEV2ZW50J1xufTtcbmV4cG9ydCB2YXIgUEJfTE9DQVRPUiA9ICdfX3BiX2xvY2F0b3JfXyc7XG4iLCJpbXBvcnQgeyBmaW5kIH0gZnJvbSAnLi9wb2x5ZmlsbC5qcyc7XG5pbXBvcnQgeyBpc0VtcHR5LCBsb2dXYXJuIH0gZnJvbSAnLi91dGlscy5qcyc7XG5pbXBvcnQgeyBjb25maWcgfSBmcm9tICcuL2NvbmZpZy5qcyc7XG52YXIgX2RlZmF1bHRQcmVjaXNpb24gPSAyO1xudmFyIF9sZ1ByaWNlQ29uZmlnID0ge1xuICAgICdidWNrZXRzJzogW3tcbiAgICAgICAgICAgICdtYXgnOiA1LFxuICAgICAgICAgICAgJ2luY3JlbWVudCc6IDAuNVxuICAgICAgICB9XVxufTtcbnZhciBfbWdQcmljZUNvbmZpZyA9IHtcbiAgICAnYnVja2V0cyc6IFt7XG4gICAgICAgICAgICAnbWF4JzogMjAsXG4gICAgICAgICAgICAnaW5jcmVtZW50JzogMC4xXG4gICAgICAgIH1dXG59O1xudmFyIF9oZ1ByaWNlQ29uZmlnID0ge1xuICAgICdidWNrZXRzJzogW3tcbiAgICAgICAgICAgICdtYXgnOiAyMCxcbiAgICAgICAgICAgICdpbmNyZW1lbnQnOiAwLjAxXG4gICAgICAgIH1dXG59O1xudmFyIF9kZW5zZVByaWNlQ29uZmlnID0ge1xuICAgICdidWNrZXRzJzogW3tcbiAgICAgICAgICAgICdtYXgnOiAzLFxuICAgICAgICAgICAgJ2luY3JlbWVudCc6IDAuMDFcbiAgICAgICAgfSwge1xuICAgICAgICAgICAgJ21heCc6IDgsXG4gICAgICAgICAgICAnaW5jcmVtZW50JzogMC4wNVxuICAgICAgICB9LCB7XG4gICAgICAgICAgICAnbWF4JzogMjAsXG4gICAgICAgICAgICAnaW5jcmVtZW50JzogMC41XG4gICAgICAgIH1dXG59O1xudmFyIF9hdXRvUHJpY2VDb25maWcgPSB7XG4gICAgJ2J1Y2tldHMnOiBbe1xuICAgICAgICAgICAgJ21heCc6IDUsXG4gICAgICAgICAgICAnaW5jcmVtZW50JzogMC4wNVxuICAgICAgICB9LCB7XG4gICAgICAgICAgICAnbWF4JzogMTAsXG4gICAgICAgICAgICAnaW5jcmVtZW50JzogMC4xXG4gICAgICAgIH0sIHtcbiAgICAgICAgICAgICdtYXgnOiAyMCxcbiAgICAgICAgICAgICdpbmNyZW1lbnQnOiAwLjVcbiAgICAgICAgfV1cbn07XG5mdW5jdGlvbiBnZXRQcmljZUJ1Y2tldFN0cmluZyhjcG0sIGN1c3RvbUNvbmZpZykge1xuICAgIHZhciBncmFudWxhcml0eU11bHRpcGxpZXIgPSBhcmd1bWVudHMubGVuZ3RoID4gMiAmJiBhcmd1bWVudHNbMl0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1syXSA6IDE7XG4gICAgdmFyIGNwbUZsb2F0ID0gcGFyc2VGbG9hdChjcG0pO1xuICAgIGlmIChpc05hTihjcG1GbG9hdCkpIHtcbiAgICAgICAgY3BtRmxvYXQgPSAnJztcbiAgICB9XG4gICAgcmV0dXJuIHtcbiAgICAgICAgbG93OiBjcG1GbG9hdCA9PT0gJycgPyAnJyA6IGdldENwbVN0cmluZ1ZhbHVlKGNwbSwgX2xnUHJpY2VDb25maWcsIGdyYW51bGFyaXR5TXVsdGlwbGllciksXG4gICAgICAgIG1lZDogY3BtRmxvYXQgPT09ICcnID8gJycgOiBnZXRDcG1TdHJpbmdWYWx1ZShjcG0sIF9tZ1ByaWNlQ29uZmlnLCBncmFudWxhcml0eU11bHRpcGxpZXIpLFxuICAgICAgICBoaWdoOiBjcG1GbG9hdCA9PT0gJycgPyAnJyA6IGdldENwbVN0cmluZ1ZhbHVlKGNwbSwgX2hnUHJpY2VDb25maWcsIGdyYW51bGFyaXR5TXVsdGlwbGllciksXG4gICAgICAgIGF1dG86IGNwbUZsb2F0ID09PSAnJyA/ICcnIDogZ2V0Q3BtU3RyaW5nVmFsdWUoY3BtLCBfYXV0b1ByaWNlQ29uZmlnLCBncmFudWxhcml0eU11bHRpcGxpZXIpLFxuICAgICAgICBkZW5zZTogY3BtRmxvYXQgPT09ICcnID8gJycgOiBnZXRDcG1TdHJpbmdWYWx1ZShjcG0sIF9kZW5zZVByaWNlQ29uZmlnLCBncmFudWxhcml0eU11bHRpcGxpZXIpLFxuICAgICAgICBjdXN0b206IGNwbUZsb2F0ID09PSAnJyA/ICcnIDogZ2V0Q3BtU3RyaW5nVmFsdWUoY3BtLCBjdXN0b21Db25maWcsIGdyYW51bGFyaXR5TXVsdGlwbGllcilcbiAgICB9O1xufVxuZnVuY3Rpb24gZ2V0Q3BtU3RyaW5nVmFsdWUoY3BtLCBjb25maWcsIGdyYW51bGFyaXR5TXVsdGlwbGllcikge1xuICAgIHZhciBjcG1TdHIgPSAnJztcbiAgICBpZiAoIWlzVmFsaWRQcmljZUNvbmZpZyhjb25maWcpKSB7XG4gICAgICAgIHJldHVybiBjcG1TdHI7XG4gICAgfVxuICAgIHZhciBjYXAgPSBjb25maWcuYnVja2V0cy5yZWR1Y2UoKHByZXYsIGN1cnIpID0+IHtcbiAgICAgICAgaWYgKHByZXYubWF4ID4gY3Vyci5tYXgpIHtcbiAgICAgICAgICAgIHJldHVybiBwcmV2O1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjdXJyO1xuICAgIH0sIHtcbiAgICAgICAgJ21heCc6IDBcbiAgICB9KTtcbiAgICB2YXIgYnVja2V0Rmxvb3IgPSAwO1xuICAgIHZhciBidWNrZXQgPSBmaW5kKGNvbmZpZy5idWNrZXRzLCBidWNrZXQgPT4ge1xuICAgICAgICBpZiAoY3BtID4gY2FwLm1heCAqIGdyYW51bGFyaXR5TXVsdGlwbGllcikge1xuICAgICAgICAgICAgLy8gY3BtIGV4Y2VlZHMgY2FwLCBqdXN0IHJldHVybiB0aGUgY2FwLlxuICAgICAgICAgICAgdmFyIHByZWNpc2lvbiA9IGJ1Y2tldC5wcmVjaXNpb247XG4gICAgICAgICAgICBpZiAodHlwZW9mIHByZWNpc2lvbiA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgICBwcmVjaXNpb24gPSBfZGVmYXVsdFByZWNpc2lvbjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNwbVN0ciA9IChidWNrZXQubWF4ICogZ3JhbnVsYXJpdHlNdWx0aXBsaWVyKS50b0ZpeGVkKHByZWNpc2lvbik7XG4gICAgICAgIH1cbiAgICAgICAgZWxzZSBpZiAoY3BtIDw9IGJ1Y2tldC5tYXggKiBncmFudWxhcml0eU11bHRpcGxpZXIgJiYgY3BtID49IGJ1Y2tldEZsb29yICogZ3JhbnVsYXJpdHlNdWx0aXBsaWVyKSB7XG4gICAgICAgICAgICBidWNrZXQubWluID0gYnVja2V0Rmxvb3I7XG4gICAgICAgICAgICByZXR1cm4gYnVja2V0O1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYnVja2V0Rmxvb3IgPSBidWNrZXQubWF4O1xuICAgICAgICB9XG4gICAgfSk7XG4gICAgaWYgKGJ1Y2tldCkge1xuICAgICAgICBjcG1TdHIgPSBnZXRDcG1UYXJnZXQoY3BtLCBidWNrZXQsIGdyYW51bGFyaXR5TXVsdGlwbGllcik7XG4gICAgfVxuICAgIHJldHVybiBjcG1TdHI7XG59XG5mdW5jdGlvbiBpc1ZhbGlkUHJpY2VDb25maWcoY29uZmlnKSB7XG4gICAgaWYgKGlzRW1wdHkoY29uZmlnKSB8fCAhY29uZmlnLmJ1Y2tldHMgfHwgIUFycmF5LmlzQXJyYXkoY29uZmlnLmJ1Y2tldHMpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgdmFyIGlzVmFsaWQgPSB0cnVlO1xuICAgIGNvbmZpZy5idWNrZXRzLmZvckVhY2goYnVja2V0ID0+IHtcbiAgICAgICAgaWYgKCFidWNrZXQubWF4IHx8ICFidWNrZXQuaW5jcmVtZW50KSB7XG4gICAgICAgICAgICBpc1ZhbGlkID0gZmFsc2U7XG4gICAgICAgIH1cbiAgICB9KTtcbiAgICByZXR1cm4gaXNWYWxpZDtcbn1cbmZ1bmN0aW9uIGdldENwbVRhcmdldChjcG0sIGJ1Y2tldCwgZ3JhbnVsYXJpdHlNdWx0aXBsaWVyKSB7XG4gICAgdmFyIHByZWNpc2lvbiA9IHR5cGVvZiBidWNrZXQucHJlY2lzaW9uICE9PSAndW5kZWZpbmVkJyA/IGJ1Y2tldC5wcmVjaXNpb24gOiBfZGVmYXVsdFByZWNpc2lvbjtcbiAgICB2YXIgaW5jcmVtZW50ID0gYnVja2V0LmluY3JlbWVudCAqIGdyYW51bGFyaXR5TXVsdGlwbGllcjtcbiAgICB2YXIgYnVja2V0TWluID0gYnVja2V0Lm1pbiAqIGdyYW51bGFyaXR5TXVsdGlwbGllcjtcbiAgICB2YXIgcm91bmRpbmdGdW5jdGlvbiA9IE1hdGguZmxvb3I7XG4gICAgdmFyIGN1c3RvbVJvdW5kaW5nRnVuY3Rpb24gPSBjb25maWcuZ2V0Q29uZmlnKCdjcG1Sb3VuZGluZ0Z1bmN0aW9uJyk7XG4gICAgaWYgKHR5cGVvZiBjdXN0b21Sb3VuZGluZ0Z1bmN0aW9uID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgIHJvdW5kaW5nRnVuY3Rpb24gPSBjdXN0b21Sb3VuZGluZ0Z1bmN0aW9uO1xuICAgIH1cbiAgICAvLyBzdGFydCBpbmNyZW1lbnRzIGF0IHRoZSBidWNrZXQgbWluIGFuZCB0aGVuIGFkZCBidWNrZXQgbWluIGJhY2sgdG8gYXJyaXZlIGF0IHRoZSBjb3JyZWN0IHJvdW5kaW5nXG4gICAgLy8gbm90ZSAtIHdlJ3JlIHBhZGRpbmcgdGhlIHZhbHVlcyB0byBhdm9pZCB1c2luZyBkZWNpbWFscyBpbiB0aGUgbWF0aCBwcmlvciB0byBmbG9vcmluZ1xuICAgIC8vIHRoaXMgaXMgZG9uZSBhcyBKUyBjYW4gcmV0dXJuIHZhbHVlcyBzbGlnaHRseSBiZWxvdyB0aGUgZXhwZWN0ZWQgbWFyayB3aGljaCB3b3VsZCBza2V3IHRoZSBwcmljZSBidWNrZXQgdGFyZ2V0XG4gICAgLy8gICAoZWcgNC4wMSAvIDAuMDEgPSA0MDAuOTk5OTk5OTk5OTk5OTQpXG4gICAgLy8gbWluIHByZWNpc29uIHNob3VsZCBiZSAyIHRvIG1vdmUgZGVjaW1hbCBwbGFjZSBvdmVyLlxuICAgIHZhciBwb3cgPSBNYXRoLnBvdygxMCwgcHJlY2lzaW9uICsgMik7XG4gICAgdmFyIGNwbVRvUm91bmQgPSAoY3BtICogcG93IC0gYnVja2V0TWluICogcG93KSAvIChpbmNyZW1lbnQgKiBwb3cpO1xuICAgIHZhciBjcG1UYXJnZXQ7XG4gICAgdmFyIGludmFsaWRSb3VuZGluZztcbiAgICAvLyBJdCBpcyBsaWtlbHkgdGhhdCB3ZSB3aWxsIGJlIHBhc3NlZCB7Y3BtUm91bmRpbmdGdW5jdGlvbjogcm91bmRpbmdGdW5jdGlvbigpfVxuICAgIC8vIHJhdGhlciB0aGFuIHRoZSBleHBlY3RlZCB7Y3BtUm91bmRpbmdGdW5jdGlvbjogcm91bmRpbmdGdW5jdGlvbn0uIERlZmF1bHQgYmFjayB0byBmbG9vciBpbiB0aGF0IGNhc2VcbiAgICB0cnkge1xuICAgICAgICBjcG1UYXJnZXQgPSByb3VuZGluZ0Z1bmN0aW9uKGNwbVRvUm91bmQpICogaW5jcmVtZW50ICsgYnVja2V0TWluO1xuICAgIH1cbiAgICBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGludmFsaWRSb3VuZGluZyA9IHRydWU7XG4gICAgfVxuICAgIGlmIChpbnZhbGlkUm91bmRpbmcgfHwgdHlwZW9mIGNwbVRhcmdldCAhPT0gJ251bWJlcicpIHtcbiAgICAgICAgbG9nV2FybignSW52YWxpZCByb3VuZGluZyBmdW5jdGlvbiBwYXNzZWQgaW4gY29uZmlnJyk7XG4gICAgICAgIGNwbVRhcmdldCA9IE1hdGguZmxvb3IoY3BtVG9Sb3VuZCkgKiBpbmNyZW1lbnQgKyBidWNrZXRNaW47XG4gICAgfVxuICAgIC8vIGZvcmNlIHRvIDEwIGRlY2ltYWwgcGxhY2VzIHRvIGRlYWwgd2l0aCBpbXByZWNpc2UgZGVjaW1hbC9iaW5hcnkgY29udmVyc2lvbnNcbiAgICAvLyAgICAoZm9yIGV4YW1wbGUgMC4xICogMyA9IDAuMzAwMDAwMDAwMDAwMDAwMDQpXG4gICAgY3BtVGFyZ2V0ID0gTnVtYmVyKGNwbVRhcmdldC50b0ZpeGVkKDEwKSk7XG4gICAgcmV0dXJuIGNwbVRhcmdldC50b0ZpeGVkKHByZWNpc2lvbik7XG59XG5leHBvcnQgeyBnZXRQcmljZUJ1Y2tldFN0cmluZywgaXNWYWxpZFByaWNlQ29uZmlnIH07XG4iLCIvLyBUaGVzZSBzdHVicyBhcmUgaGVyZSB0byBoZWxwIHRyYW5zaXRpb24gYXdheSBmcm9tIGNvcmUtanMgcG9seWZpbGxzIGZvciBicm93c2VycyB3ZSBhcmUgbm8gbG9uZ2VyIHN1cHBvcnRpbmcuXG4vLyBZb3Ugc2hvdWxkIG5vdCBuZWVkIHRoZXNlIGZvciBuZXcgY29kZTsgdXNlIHN0b2NrIEpTIGluc3RlYWQhXG5leHBvcnQgZnVuY3Rpb24gaW5jbHVkZXModGFyZ2V0LCBlbGVtLCBzdGFydCkge1xuICAgIHJldHVybiB0YXJnZXQgJiYgdGFyZ2V0LmluY2x1ZGVzKGVsZW0sIHN0YXJ0KSB8fCBmYWxzZTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBhcnJheUZyb20oKSB7XG4gICAgcmV0dXJuIEFycmF5LmZyb20uYXBwbHkoQXJyYXksIGFyZ3VtZW50cyk7XG59XG5leHBvcnQgZnVuY3Rpb24gZmluZChhcnIsIHByZWQsIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gYXJyICYmIGFyci5maW5kKHByZWQsIHRoaXNBcmcpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZpbmRJbmRleChhcnIsIHByZWQsIHRoaXNBcmcpIHtcbiAgICByZXR1cm4gYXJyICYmIGFyci5maW5kSW5kZXgocHJlZCwgdGhpc0FyZyk7XG59XG4iLCIvLyBpZiAkJFBSRUJJRF9HTE9CQUwkJCBhbHJlYWR5IGV4aXN0cyBpbiBnbG9iYWwgZG9jdW1lbnQgc2NvcGUsIHVzZSBpdCwgaWYgbm90LCBjcmVhdGUgdGhlIG9iamVjdFxuLy8gZ2xvYmFsIGRlZmluYXRpb24gc2hvdWxkIGhhcHBlbiBCRUZPUkUgaW1wb3J0cyB0byBhdm9pZCBnbG9iYWwgdW5kZWZpbmVkIGVycm9ycy5cbi8qIGdsb2JhbCAkJERFRklORV9QUkVCSURfR0xPQkFMJCQgKi9cbnZhciBzY29wZSA9ICF0cnVlID8ge30gOiB3aW5kb3c7XG52YXIgZ2xvYmFsID0gc2NvcGUucGJqcyA9IHNjb3BlLnBianMgfHwge307XG5nbG9iYWwuY21kID0gZ2xvYmFsLmNtZCB8fCBbXTtcbmdsb2JhbC5xdWUgPSBnbG9iYWwucXVlIHx8IFtdO1xuLy8gY3JlYXRlIGEgcGJqcyBnbG9iYWwgcG9pbnRlclxuaWYgKHNjb3BlID09PSB3aW5kb3cpIHtcbiAgICBzY29wZS5fcGJqc0dsb2JhbHMgPSBzY29wZS5fcGJqc0dsb2JhbHMgfHwgW107XG4gICAgc2NvcGUuX3BianNHbG9iYWxzLnB1c2goXCJwYmpzXCIpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldEdsb2JhbCgpIHtcbiAgICByZXR1cm4gZ2xvYmFsO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHJlZ2lzdGVyTW9kdWxlKG5hbWUpIHtcbiAgICBnbG9iYWwuaW5zdGFsbGVkTW9kdWxlcy5wdXNoKG5hbWUpO1xufVxuIiwiaW1wb3J0IHsgY29uZmlnIH0gZnJvbSAnLi9jb25maWcuanMnO1xuaW1wb3J0IHsga2xvbmEgfSBmcm9tICdrbG9uYS9qc29uJztcbmltcG9ydCB7IGluY2x1ZGVzIH0gZnJvbSAnLi9wb2x5ZmlsbC5qcyc7XG5pbXBvcnQgeyBFVkVOVFMgfSBmcm9tICcuL2NvbnN0YW50cy5qcyc7XG5pbXBvcnQgeyBHcmVlZHlQcm9taXNlIH0gZnJvbSAnLi91dGlscy9wcm9taXNlLmpzJztcbmltcG9ydCB7IGdldEdsb2JhbCB9IGZyb20gJy4vcHJlYmlkR2xvYmFsLmpzJztcbmltcG9ydCB7IGRlZmF1bHQgYXMgZGVlcEFjY2VzcyB9IGZyb20gJ2Rsdi9pbmRleC5qcyc7XG5leHBvcnQgeyBkZWVwQWNjZXNzIH07XG5leHBvcnQgeyBkc2V0IGFzIGRlZXBTZXRWYWx1ZSB9IGZyb20gJ2RzZXQnO1xudmFyIHRTdHIgPSAnU3RyaW5nJztcbnZhciB0Rm4gPSAnRnVuY3Rpb24nO1xudmFyIHROdW1iID0gJ051bWJlcic7XG52YXIgdE9iamVjdCA9ICdPYmplY3QnO1xudmFyIHRCb29sZWFuID0gJ0Jvb2xlYW4nO1xudmFyIHRvU3RyaW5nID0gT2JqZWN0LnByb3RvdHlwZS50b1N0cmluZztcbnZhciBjb25zb2xlRXhpc3RzID0gQm9vbGVhbih3aW5kb3cuY29uc29sZSk7XG52YXIgY29uc29sZUxvZ0V4aXN0cyA9IEJvb2xlYW4oY29uc29sZUV4aXN0cyAmJiB3aW5kb3cuY29uc29sZS5sb2cpO1xudmFyIGNvbnNvbGVJbmZvRXhpc3RzID0gQm9vbGVhbihjb25zb2xlRXhpc3RzICYmIHdpbmRvdy5jb25zb2xlLmluZm8pO1xudmFyIGNvbnNvbGVXYXJuRXhpc3RzID0gQm9vbGVhbihjb25zb2xlRXhpc3RzICYmIHdpbmRvdy5jb25zb2xlLndhcm4pO1xudmFyIGNvbnNvbGVFcnJvckV4aXN0cyA9IEJvb2xlYW4oY29uc29sZUV4aXN0cyAmJiB3aW5kb3cuY29uc29sZS5lcnJvcik7XG52YXIgZXZlbnRFbWl0dGVyO1xudmFyIHBianNJbnN0YW5jZSA9IGdldEdsb2JhbCgpO1xuZXhwb3J0IGZ1bmN0aW9uIF9zZXRFdmVudEVtaXR0ZXIoZW1pdEZuKSB7XG4gICAgLy8gY2FsbGVkIGZyb20gZXZlbnRzLmpzIC0gdGhpcyBob29wIGlzIHRvIGF2b2lkIGNpcmN1bGFyIGltcG9ydHNcbiAgICBldmVudEVtaXR0ZXIgPSBlbWl0Rm47XG59XG5mdW5jdGlvbiBlbWl0RXZlbnQoKSB7XG4gICAgaWYgKGV2ZW50RW1pdHRlciAhPSBudWxsKSB7XG4gICAgICAgIGV2ZW50RW1pdHRlciguLi5hcmd1bWVudHMpO1xuICAgIH1cbn1cbi8vIHRoaXMgYWxsb3dzIHN0dWJiaW5nIG9mIHV0aWxpdHkgZnVuY3Rpb25zIHRoYXQgYXJlIHVzZWQgaW50ZXJuYWxseSBieSBvdGhlciB1dGlsaXR5IGZ1bmN0aW9uc1xuZXhwb3J0IHZhciBpbnRlcm5hbCA9IHtcbiAgICBjaGVja0Nvb2tpZVN1cHBvcnQsXG4gICAgY3JlYXRlVHJhY2tQaXhlbElmcmFtZUh0bWwsXG4gICAgZ2V0V2luZG93U2VsZixcbiAgICBnZXRXaW5kb3dUb3AsXG4gICAgY2FuQWNjZXNzV2luZG93VG9wLFxuICAgIGdldFdpbmRvd0xvY2F0aW9uLFxuICAgIGluc2VydFVzZXJTeW5jSWZyYW1lLFxuICAgIGluc2VydEVsZW1lbnQsXG4gICAgaXNGbixcbiAgICB0cmlnZ2VyUGl4ZWwsXG4gICAgbG9nRXJyb3IsXG4gICAgbG9nV2FybixcbiAgICBsb2dNZXNzYWdlLFxuICAgIGxvZ0luZm8sXG4gICAgcGFyc2VRUyxcbiAgICBmb3JtYXRRUyxcbiAgICBkZWVwRXF1YWxcbn07XG52YXIgcHJlYmlkSW50ZXJuYWwgPSB7fTtcbi8qKlxuICogUmV0dXJucyBvYmplY3QgdGhhdCBpcyB1c2VkIGFzIGludGVybmFsIHByZWJpZCBuYW1lc3BhY2VcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFByZWJpZEludGVybmFsKCkge1xuICAgIHJldHVybiBwcmViaWRJbnRlcm5hbDtcbn1cbi8qIHV0aWxpdHkgbWV0aG9kIHRvIGdldCBpbmNyZW1lbnRhbCBpbnRlZ2VyIHN0YXJ0aW5nIGZyb20gMSAqL1xudmFyIGdldEluY3JlbWVudGFsSW50ZWdlciA9IGZ1bmN0aW9uICgpIHtcbiAgICB2YXIgY291bnQgPSAwO1xuICAgIHJldHVybiBmdW5jdGlvbiAoKSB7XG4gICAgICAgIGNvdW50Kys7XG4gICAgICAgIHJldHVybiBjb3VudDtcbiAgICB9O1xufSgpO1xuLy8gZ2VuZXJhdGUgYSByYW5kb20gc3RyaW5nICh0byBiZSB1c2VkIGFzIGEgZHluYW1pYyBKU09OUCBjYWxsYmFjaylcbmV4cG9ydCBmdW5jdGlvbiBnZXRVbmlxdWVJZGVudGlmaWVyU3RyKCkge1xuICAgIHJldHVybiBnZXRJbmNyZW1lbnRhbEludGVnZXIoKSArIE1hdGgucmFuZG9tKCkudG9TdHJpbmcoMTYpLnN1YnN0cigyKTtcbn1cbi8qKlxuICogUmV0dXJucyBhIHJhbmRvbSB2NCBVVUlEIG9mIHRoZSBmb3JtIHh4eHh4eHh4LXh4eHgtNHh4eC15eHh4LXh4eHh4eHh4eHh4eCxcbiAqIHdoZXJlIGVhY2ggeCBpcyByZXBsYWNlZCB3aXRoIGEgcmFuZG9tIGhleGFkZWNpbWFsIGRpZ2l0IGZyb20gMCB0byBmLFxuICogYW5kIHkgaXMgcmVwbGFjZWQgd2l0aCBhIHJhbmRvbSBoZXhhZGVjaW1hbCBkaWdpdCBmcm9tIDggdG8gYi5cbiAqIGh0dHBzOi8vZ2lzdC5naXRodWIuY29tL2plZC85ODI4ODMgdmlhIG5vZGUtdXVpZFxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2VuZXJhdGVVVUlEKHBsYWNlaG9sZGVyKSB7XG4gICAgcmV0dXJuIHBsYWNlaG9sZGVyID8gKHBsYWNlaG9sZGVyIF4gX2dldFJhbmRvbURhdGEoKSA+PiBwbGFjZWhvbGRlciAvIDQpLnRvU3RyaW5nKDE2KSA6IChbMWU3XSArIC0xZTMgKyAtNGUzICsgLThlMyArIC0xZTExKS5yZXBsYWNlKC9bMDE4XS9nLCBnZW5lcmF0ZVVVSUQpO1xufVxuLyoqXG4gKiBSZXR1cm5zIHJhbmRvbSBkYXRhIHVzaW5nIHRoZSBDcnlwdG8gQVBJIGlmIGF2YWlsYWJsZSBhbmQgTWF0aC5yYW5kb20gaWYgbm90XG4gKiBNZXRob2QgaXMgZnJvbSBodHRwczovL2dpc3QuZ2l0aHViLmNvbS9qZWQvOTgyODgzIGxpa2UgZ2VuZXJhdGVVVUlELCBkaXJlY3QgbGluayBodHRwczovL2dpc3QuZ2l0aHViLmNvbS9qZWQvOTgyODgzI2dpc3Rjb21tZW50LTQ1MTA0XG4gKi9cbmZ1bmN0aW9uIF9nZXRSYW5kb21EYXRhKCkge1xuICAgIGlmICh3aW5kb3cgJiYgd2luZG93LmNyeXB0byAmJiB3aW5kb3cuY3J5cHRvLmdldFJhbmRvbVZhbHVlcykge1xuICAgICAgICByZXR1cm4gY3J5cHRvLmdldFJhbmRvbVZhbHVlcyhuZXcgVWludDhBcnJheSgxKSlbMF0gJSAxNjtcbiAgICB9XG4gICAgZWxzZSB7XG4gICAgICAgIHJldHVybiBNYXRoLnJhbmRvbSgpICogMTY7XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGdldEJpZElkUGFyYW1ldGVyKGtleSwgcGFyYW1zT2JqKSB7XG4gICAgcmV0dXJuIChwYXJhbXNPYmogPT09IG51bGwgfHwgcGFyYW1zT2JqID09PSB2b2lkIDAgPyB2b2lkIDAgOiBwYXJhbXNPYmpba2V5XSkgfHwgJyc7XG59XG4vLyBwYXJzZSBhIHF1ZXJ5IHN0cmluZyBvYmplY3QgcGFzc2VkIGluIGJpZCBwYXJhbXNcbi8vIGJpZCBwYXJhbXMgc2hvdWxkIGJlIGFuIG9iamVjdCBzdWNoIGFzIHtrZXk6IFwidmFsdWVcIiwga2V5MSA6IFwidmFsdWUxXCJ9XG4vLyBhbGlhc2VzIHRvIGZvcm1hdFFTXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VRdWVyeVN0cmluZ1BhcmFtZXRlcnMocXVlcnlPYmopIHtcbiAgICB2YXIgcmVzdWx0ID0gJyc7XG4gICAgZm9yICh2YXIgayBpbiBxdWVyeU9iaikge1xuICAgICAgICBpZiAocXVlcnlPYmouaGFzT3duUHJvcGVydHkoaykpIHtcbiAgICAgICAgICAgIHJlc3VsdCArPSBrICsgJz0nICsgZW5jb2RlVVJJQ29tcG9uZW50KHF1ZXJ5T2JqW2tdKSArICcmJztcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXN1bHQgPSByZXN1bHQucmVwbGFjZSgvJiQvLCAnJyk7XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbi8vIHRyYW5zZm9ybSBhbiBBZFNlcnZlciB0YXJnZXRpbmcgYmlkcyBpbnRvIGEgcXVlcnkgc3RyaW5nIHRvIHNlbmQgdG8gdGhlIGFkc2VydmVyXG5leHBvcnQgZnVuY3Rpb24gdHJhbnNmb3JtQWRTZXJ2ZXJUYXJnZXRpbmdPYmoodGFyZ2V0aW5nKSB7XG4gICAgLy8gd2UgZXhwZWN0IHRvIHJlY2VpdmUgdGFyZ2V0aW5nIGZvciBhIHNpbmdsZSBzbG90IGF0IGEgdGltZVxuICAgIGlmICh0YXJnZXRpbmcgJiYgT2JqZWN0LmdldE93blByb3BlcnR5TmFtZXModGFyZ2V0aW5nKS5sZW5ndGggPiAwKSB7XG4gICAgICAgIHJldHVybiBPYmplY3Qua2V5cyh0YXJnZXRpbmcpLm1hcChrZXkgPT4gXCJcIi5jb25jYXQoa2V5LCBcIj1cIikuY29uY2F0KGVuY29kZVVSSUNvbXBvbmVudCh0YXJnZXRpbmdba2V5XSkpKS5qb2luKCcmJyk7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxufVxuLyoqXG4gKiBQYXJzZSBhIEdQVC1TdHlsZSBnZW5lcmFsIHNpemUgQXJyYXkgbGlrZSBgW1szMDAsIDI1MF1dYCBvciBgXCIzMDB4MjUwLDk3MHg5MFwiYCBpbnRvIGFuIGFycmF5IG9mIHdpZHRoLCBoZWlnaHQgdHVwbGVzIGBbWzMwMCwgMjUwXV1gIG9yICdbWzMwMCwyNTBdLCBbOTcwLDkwXV0nXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzaXplc1RvU2l6ZVR1cGxlcyhzaXplcykge1xuICAgIGlmICh0eXBlb2Ygc2l6ZXMgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgIC8vIG11bHRpcGxlIHNpemVzIHdpbGwgYmUgY29tbWEtc2VwYXJhdGVkXG4gICAgICAgIHJldHVybiBzaXplcy5zcGxpdCgvXFxzKixcXHMqLykubWFwKHN6ID0+IHN6Lm1hdGNoKC9eKFxcZCspeChcXGQrKSQvaSkpLmZpbHRlcihtYXRjaCA9PiBtYXRjaCkubWFwKF9yZWYgPT4ge1xuICAgICAgICAgICAgdmFyIFtfLCB3LCBoXSA9IF9yZWY7XG4gICAgICAgICAgICByZXR1cm4gW3BhcnNlSW50KHcsIDEwKSwgcGFyc2VJbnQoaCwgMTApXTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIGVsc2UgaWYgKEFycmF5LmlzQXJyYXkoc2l6ZXMpKSB7XG4gICAgICAgIGlmIChpc1ZhbGlkR1BUU2luZ2xlU2l6ZShzaXplcykpIHtcbiAgICAgICAgICAgIHJldHVybiBbc2l6ZXNdO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBzaXplcy5maWx0ZXIoaXNWYWxpZEdQVFNpbmdsZVNpemUpO1xuICAgIH1cbiAgICByZXR1cm4gW107XG59XG4vKipcbiAqIFBhcnNlIGEgR1BULVN0eWxlIGdlbmVyYWwgc2l6ZSBBcnJheSBsaWtlIGBbWzMwMCwgMjUwXV1gIG9yIGBcIjMwMHgyNTAsOTcweDkwXCJgIGludG8gYW4gYXJyYXkgb2Ygc2l6ZXMgYFtcIjMwMHgyNTBcIl1gIG9yICdbJzMwMHgyNTAnLCAnOTcweDkwJ10nXG4gKiBAcGFyYW0gIHsoQXJyYXkuPG51bWJlcltdPnxBcnJheS48bnVtYmVyPil9IHNpemVPYmogSW5wdXQgYXJyYXkgb3IgZG91YmxlIGFycmF5IFszMDAsMjUwXSBvciBbWzMwMCwyNTBdLCBbNzI4LDkwXV1cbiAqIEByZXR1cm4ge0FycmF5LjxzdHJpbmc+fSAgQXJyYXkgb2Ygc3RyaW5ncyBsaWtlIGBbXCIzMDB4MjUwXCJdYCBvciBgW1wiMzAweDI1MFwiLCBcIjcyOHg5MFwiXWBcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlU2l6ZXNJbnB1dChzaXplT2JqKSB7XG4gICAgcmV0dXJuIHNpemVzVG9TaXplVHVwbGVzKHNpemVPYmopLm1hcChzaXplVHVwbGVUb1NpemVTdHJpbmcpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHNpemVUdXBsZVRvU2l6ZVN0cmluZyhzaXplKSB7XG4gICAgcmV0dXJuIHNpemVbMF0gKyAneCcgKyBzaXplWzFdO1xufVxuLy8gUGFyc2UgYSBHUFQgc3R5bGUgc2luZ2xlIHNpemUgYXJyYXksIChpLmUgWzMwMCwgMjUwXSlcbi8vIGludG8gYW4gQXBwTmV4dXMgc3R5bGUgc3RyaW5nLCAoaS5lLiAzMDB4MjUwKVxuZXhwb3J0IGZ1bmN0aW9uIHBhcnNlR1BUU2luZ2xlU2l6ZUFycmF5KHNpbmdsZVNpemUpIHtcbiAgICBpZiAoaXNWYWxpZEdQVFNpbmdsZVNpemUoc2luZ2xlU2l6ZSkpIHtcbiAgICAgICAgcmV0dXJuIHNpemVUdXBsZVRvU2l6ZVN0cmluZyhzaW5nbGVTaXplKTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gc2l6ZVR1cGxlVG9SdGJTaXplKHNpemUpIHtcbiAgICByZXR1cm4ge1xuICAgICAgICB3OiBzaXplWzBdLFxuICAgICAgICBoOiBzaXplWzFdXG4gICAgfTtcbn1cbi8vIFBhcnNlIGEgR1BUIHN0eWxlIHNpbmdsZSBzaXplIGFycmF5LCAoaS5lIFszMDAsIDI1MF0pXG4vLyBpbnRvIE9wZW5SVEItY29tcGF0aWJsZSAoaW1wLmJhbm5lci53L2gsIGltcC5iYW5uZXIuZm9ybWF0LncvaCwgaW1wLnZpZGVvLncvaCkgb2JqZWN0KGkuZS4ge3c6MzAwLCBoOjI1MH0pXG5leHBvcnQgZnVuY3Rpb24gcGFyc2VHUFRTaW5nbGVTaXplQXJyYXlUb1J0YlNpemUoc2luZ2xlU2l6ZSkge1xuICAgIGlmIChpc1ZhbGlkR1BUU2luZ2xlU2l6ZShzaW5nbGVTaXplKSkge1xuICAgICAgICByZXR1cm4gc2l6ZVR1cGxlVG9SdGJTaXplKHNpbmdsZVNpemUpO1xuICAgIH1cbn1cbmZ1bmN0aW9uIGlzVmFsaWRHUFRTaW5nbGVTaXplKHNpbmdsZVNpemUpIHtcbiAgICAvLyBpZiB3ZSBhcmVuJ3QgZXhhY3RseSAyIGl0ZW1zIGluIHRoaXMgYXJyYXksIGl0IGlzIGludmFsaWRcbiAgICByZXR1cm4gaXNBcnJheShzaW5nbGVTaXplKSAmJiBzaW5nbGVTaXplLmxlbmd0aCA9PT0gMiAmJiAhaXNOYU4oc2luZ2xlU2l6ZVswXSkgJiYgIWlzTmFOKHNpbmdsZVNpemVbMV0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGdldFdpbmRvd1RvcCgpIHtcbiAgICByZXR1cm4gd2luZG93LnRvcDtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRXaW5kb3dTZWxmKCkge1xuICAgIHJldHVybiB3aW5kb3cuc2VsZjtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRXaW5kb3dMb2NhdGlvbigpIHtcbiAgICByZXR1cm4gd2luZG93LmxvY2F0aW9uO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNhbkFjY2Vzc1dpbmRvd1RvcCgpIHtcbiAgICB0cnkge1xuICAgICAgICBpZiAoaW50ZXJuYWwuZ2V0V2luZG93VG9wKCkubG9jYXRpb24uaHJlZikge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cbi8qKlxuICogV3JhcHBlcnMgdG8gY29uc29sZS4obG9nIHwgaW5mbyB8IHdhcm4gfCBlcnJvcikuIFRha2VzIE4gYXJndW1lbnRzLCB0aGUgc2FtZSBhcyB0aGUgbmF0aXZlIG1ldGhvZHNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGxvZ01lc3NhZ2UoKSB7XG4gICAgaWYgKGRlYnVnVHVybmVkT24oKSAmJiBjb25zb2xlTG9nRXhpc3RzKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgICAgIGNvbnNvbGUubG9nLmFwcGx5KGNvbnNvbGUsIGRlY29yYXRlTG9nKGFyZ3VtZW50cywgJ01FU1NBR0U6JykpO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBsb2dJbmZvKCkge1xuICAgIGlmIChkZWJ1Z1R1cm5lZE9uKCkgJiYgY29uc29sZUluZm9FeGlzdHMpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgICAgY29uc29sZS5pbmZvLmFwcGx5KGNvbnNvbGUsIGRlY29yYXRlTG9nKGFyZ3VtZW50cywgJ0lORk86JykpO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBsb2dXYXJuKCkge1xuICAgIGlmIChkZWJ1Z1R1cm5lZE9uKCkgJiYgY29uc29sZVdhcm5FeGlzdHMpIHtcbiAgICAgICAgLy8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnNvbGVcbiAgICAgICAgY29uc29sZS53YXJuLmFwcGx5KGNvbnNvbGUsIGRlY29yYXRlTG9nKGFyZ3VtZW50cywgJ1dBUk5JTkc6JykpO1xuICAgIH1cbiAgICBlbWl0RXZlbnQoRVZFTlRTLkFVQ1RJT05fREVCVUcsIHtcbiAgICAgICAgdHlwZTogJ1dBUk5JTkcnLFxuICAgICAgICBhcmd1bWVudHM6IGFyZ3VtZW50c1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGxvZ0Vycm9yKCkge1xuICAgIGlmIChkZWJ1Z1R1cm5lZE9uKCkgJiYgY29uc29sZUVycm9yRXhpc3RzKSB7XG4gICAgICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBuby1jb25zb2xlXG4gICAgICAgIGNvbnNvbGUuZXJyb3IuYXBwbHkoY29uc29sZSwgZGVjb3JhdGVMb2coYXJndW1lbnRzLCAnRVJST1I6JykpO1xuICAgIH1cbiAgICBlbWl0RXZlbnQoRVZFTlRTLkFVQ1RJT05fREVCVUcsIHtcbiAgICAgICAgdHlwZTogJ0VSUk9SJyxcbiAgICAgICAgYXJndW1lbnRzOiBhcmd1bWVudHNcbiAgICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwcmVmaXhMb2cocHJlZml4KSB7XG4gICAgZnVuY3Rpb24gZGVjb3JhdGUoZm4pIHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgICAgIGZvciAodmFyIF9sZW4gPSBhcmd1bWVudHMubGVuZ3RoLCBhcmdzID0gbmV3IEFycmF5KF9sZW4pLCBfa2V5ID0gMDsgX2tleSA8IF9sZW47IF9rZXkrKykge1xuICAgICAgICAgICAgICAgIGFyZ3NbX2tleV0gPSBhcmd1bWVudHNbX2tleV07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmbihwcmVmaXgsIC4uLmFyZ3MpO1xuICAgICAgICB9O1xuICAgIH1cbiAgICByZXR1cm4ge1xuICAgICAgICBsb2dFcnJvcjogZGVjb3JhdGUobG9nRXJyb3IpLFxuICAgICAgICBsb2dXYXJuOiBkZWNvcmF0ZShsb2dXYXJuKSxcbiAgICAgICAgbG9nTWVzc2FnZTogZGVjb3JhdGUobG9nTWVzc2FnZSksXG4gICAgICAgIGxvZ0luZm86IGRlY29yYXRlKGxvZ0luZm8pXG4gICAgfTtcbn1cbmZ1bmN0aW9uIGRlY29yYXRlTG9nKGFyZ3MsIHByZWZpeCkge1xuICAgIGFyZ3MgPSBbXS5zbGljZS5jYWxsKGFyZ3MpO1xuICAgIHZhciBiaWRkZXIgPSBjb25maWcuZ2V0Q3VycmVudEJpZGRlcigpO1xuICAgIHByZWZpeCAmJiBhcmdzLnVuc2hpZnQocHJlZml4KTtcbiAgICBpZiAoYmlkZGVyKSB7XG4gICAgICAgIGFyZ3MudW5zaGlmdChsYWJlbCgnI2FhYScpKTtcbiAgICB9XG4gICAgYXJncy51bnNoaWZ0KGxhYmVsKCcjM2I4OGMzJykpO1xuICAgIGFyZ3MudW5zaGlmdCgnJWNQcmViaWQnICsgKGJpZGRlciA/IFwiJWNcIi5jb25jYXQoYmlkZGVyKSA6ICcnKSk7XG4gICAgcmV0dXJuIGFyZ3M7XG4gICAgZnVuY3Rpb24gbGFiZWwoY29sb3IpIHtcbiAgICAgICAgcmV0dXJuIFwiZGlzcGxheTogaW5saW5lLWJsb2NrOyBjb2xvcjogI2ZmZjsgYmFja2dyb3VuZDogXCIuY29uY2F0KGNvbG9yLCBcIjsgcGFkZGluZzogMXB4IDRweDsgYm9yZGVyLXJhZGl1czogM3B4O1wiKTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaGFzQ29uc29sZUxvZ2dlcigpIHtcbiAgICByZXR1cm4gY29uc29sZUxvZ0V4aXN0cztcbn1cbmV4cG9ydCBmdW5jdGlvbiBkZWJ1Z1R1cm5lZE9uKCkge1xuICAgIHJldHVybiAhIWNvbmZpZy5nZXRDb25maWcoJ2RlYnVnJyk7XG59XG5leHBvcnQgdmFyIGNyZWF0ZUlmcmFtZSA9ICgoKSA9PiB7XG4gICAgdmFyIERFRkFVTFRTID0ge1xuICAgICAgICBib3JkZXI6ICcwcHgnLFxuICAgICAgICBoc3BhY2U6ICcwJyxcbiAgICAgICAgdnNwYWNlOiAnMCcsXG4gICAgICAgIG1hcmdpbldpZHRoOiAnMCcsXG4gICAgICAgIG1hcmdpbkhlaWdodDogJzAnLFxuICAgICAgICBzY3JvbGxpbmc6ICdubycsXG4gICAgICAgIGZyYW1lQm9yZGVyOiAnMCcsXG4gICAgICAgIGFsbG93dHJhbnNwYXJlbmN5OiAndHJ1ZSdcbiAgICB9O1xuICAgIHJldHVybiBmdW5jdGlvbiAoZG9jLCBhdHRycykge1xuICAgICAgICB2YXIgc3R5bGUgPSBhcmd1bWVudHMubGVuZ3RoID4gMiAmJiBhcmd1bWVudHNbMl0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1syXSA6IHt9O1xuICAgICAgICB2YXIgZiA9IGRvYy5jcmVhdGVFbGVtZW50KCdpZnJhbWUnKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihmLCBPYmplY3QuYXNzaWduKHt9LCBERUZBVUxUUywgYXR0cnMpKTtcbiAgICAgICAgT2JqZWN0LmFzc2lnbihmLnN0eWxlLCBzdHlsZSk7XG4gICAgICAgIHJldHVybiBmO1xuICAgIH07XG59KSgpO1xuZXhwb3J0IGZ1bmN0aW9uIGNyZWF0ZUludmlzaWJsZUlmcmFtZSgpIHtcbiAgICByZXR1cm4gY3JlYXRlSWZyYW1lKGRvY3VtZW50LCB7XG4gICAgICAgIGlkOiBnZXRVbmlxdWVJZGVudGlmaWVyU3RyKCksXG4gICAgICAgIHdpZHRoOiAwLFxuICAgICAgICBoZWlnaHQ6IDAsXG4gICAgICAgIHNyYzogJ2Fib3V0OmJsYW5rJ1xuICAgIH0sIHtcbiAgICAgICAgZGlzcGxheTogJ25vbmUnLFxuICAgICAgICBoZWlnaHQ6ICcwcHgnLFxuICAgICAgICB3aWR0aDogJzBweCcsXG4gICAgICAgIGJvcmRlcjogJzBweCdcbiAgICB9KTtcbn1cbi8qXG4gKiAgIENoZWNrIGlmIGEgZ2l2ZW4gcGFyYW1ldGVyIG5hbWUgZXhpc3RzIGluIHF1ZXJ5IHN0cmluZ1xuICogICBhbmQgaWYgaXQgZG9lcyByZXR1cm4gdGhlIHZhbHVlXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRQYXJhbWV0ZXJCeU5hbWUobmFtZSkge1xuICAgIHJldHVybiBwYXJzZVFTKGdldFdpbmRvd0xvY2F0aW9uKCkuc2VhcmNoKVtuYW1lXSB8fCAnJztcbn1cbi8qKlxuICogUmV0dXJuIGlmIHRoZSBvYmplY3QgaXMgb2YgdGhlXG4gKiBnaXZlbiB0eXBlLlxuICogQHBhcmFtIHsqfSBvYmplY3QgdG8gdGVzdFxuICogQHBhcmFtIHtTdHJpbmd9IF90IHR5cGUgc3RyaW5nIChlLmcuLCBBcnJheSlcbiAqIEByZXR1cm4ge0Jvb2xlYW59IGlmIG9iamVjdCBpcyBvZiB0eXBlIF90XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBpc0Eob2JqZWN0LCBfdCkge1xuICAgIHJldHVybiB0b1N0cmluZy5jYWxsKG9iamVjdCkgPT09ICdbb2JqZWN0ICcgKyBfdCArICddJztcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0ZuKG9iamVjdCkge1xuICAgIHJldHVybiBpc0Eob2JqZWN0LCB0Rm4pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGlzU3RyKG9iamVjdCkge1xuICAgIHJldHVybiBpc0Eob2JqZWN0LCB0U3RyKTtcbn1cbmV4cG9ydCB2YXIgaXNBcnJheSA9IEFycmF5LmlzQXJyYXkuYmluZChBcnJheSk7XG5leHBvcnQgZnVuY3Rpb24gaXNOdW1iZXIob2JqZWN0KSB7XG4gICAgcmV0dXJuIGlzQShvYmplY3QsIHROdW1iKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc1BsYWluT2JqZWN0KG9iamVjdCkge1xuICAgIHJldHVybiBpc0Eob2JqZWN0LCB0T2JqZWN0KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0Jvb2xlYW4ob2JqZWN0KSB7XG4gICAgcmV0dXJuIGlzQShvYmplY3QsIHRCb29sZWFuKTtcbn1cbi8qKlxuICogUmV0dXJuIGlmIHRoZSBvYmplY3QgaXMgXCJlbXB0eVwiO1xuICogdGhpcyBpbmNsdWRlcyBmYWxzZXksIG5vIGtleXMsIG9yIG5vIGl0ZW1zIGF0IGluZGljZXNcbiAqIEBwYXJhbSB7Kn0gb2JqZWN0IG9iamVjdCB0byB0ZXN0XG4gKiBAcmV0dXJuIHtCb29sZWFufSBpZiBvYmplY3QgaXMgZW1wdHlcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzRW1wdHkob2JqZWN0KSB7XG4gICAgaWYgKCFvYmplY3QpXG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIGlmIChpc0FycmF5KG9iamVjdCkgfHwgaXNTdHIob2JqZWN0KSkge1xuICAgICAgICByZXR1cm4gIShvYmplY3QubGVuZ3RoID4gMCk7XG4gICAgfVxuICAgIHJldHVybiBPYmplY3Qua2V5cyhvYmplY3QpLmxlbmd0aCA8PSAwO1xufVxuLyoqXG4gKiBSZXR1cm4gaWYgc3RyaW5nIGlzIGVtcHR5LCBudWxsLCBvciB1bmRlZmluZWRcbiAqIEBwYXJhbSBzdHIgc3RyaW5nIHRvIHRlc3RcbiAqIEByZXR1cm5zIHtib29sZWFufSBpZiBzdHJpbmcgaXMgZW1wdHlcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzRW1wdHlTdHIoc3RyKSB7XG4gICAgcmV0dXJuIGlzU3RyKHN0cikgJiYgKCFzdHIgfHwgc3RyLmxlbmd0aCA9PT0gMCk7XG59XG4vKipcbiAqIEl0ZXJhdGUgb2JqZWN0IHdpdGggdGhlIGZ1bmN0aW9uXG4gKiBmYWxscyBiYWNrIHRvIGVzNSBgZm9yRWFjaGBcbiAqIEBwYXJhbSB7QXJyYXl8T2JqZWN0fSBvYmplY3RcbiAqIEBwYXJhbSB7RnVuY3Rpb259IGZuIC0gVGhlIGZ1bmN0aW9uIHRvIGV4ZWN1dGUgZm9yIGVhY2ggZWxlbWVudC4gSXQgcmVjZWl2ZXMgdGhyZWUgYXJndW1lbnRzOiB2YWx1ZSwga2V5LCBhbmQgdGhlIG9yaWdpbmFsIG9iamVjdC5cbiAqIEByZXR1cm5zIHt2b2lkfVxuICovXG5leHBvcnQgZnVuY3Rpb24gX2VhY2gob2JqZWN0LCBmbikge1xuICAgIGlmIChpc0ZuKG9iamVjdCA9PT0gbnVsbCB8fCBvYmplY3QgPT09IHZvaWQgMCA/IHZvaWQgMCA6IG9iamVjdC5mb3JFYWNoKSlcbiAgICAgICAgcmV0dXJuIG9iamVjdC5mb3JFYWNoKGZuLCB0aGlzKTtcbiAgICBPYmplY3QuZW50cmllcyhvYmplY3QgfHwge30pLmZvckVhY2goX3JlZjIgPT4ge1xuICAgICAgICB2YXIgW2ssIHZdID0gX3JlZjI7XG4gICAgICAgIHJldHVybiBmbi5jYWxsKHRoaXMsIHYsIGspO1xuICAgIH0pO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGNvbnRhaW5zKGEsIG9iaikge1xuICAgIHJldHVybiBpc0ZuKGEgPT09IG51bGwgfHwgYSA9PT0gdm9pZCAwID8gdm9pZCAwIDogYS5pbmNsdWRlcykgJiYgYS5pbmNsdWRlcyhvYmopO1xufVxuLyoqXG4gKiBNYXAgYW4gYXJyYXkgb3Igb2JqZWN0IGludG8gYW5vdGhlciBhcnJheVxuICogZ2l2ZW4gYSBmdW5jdGlvblxuICogQHBhcmFtIHtBcnJheXxPYmplY3R9IG9iamVjdFxuICogQHBhcmFtIHtGdW5jdGlvbn0gY2FsbGJhY2sgLSBUaGUgZnVuY3Rpb24gdG8gZXhlY3V0ZSBmb3IgZWFjaCBlbGVtZW50LiBJdCByZWNlaXZlcyB0aHJlZSBhcmd1bWVudHM6IHZhbHVlLCBrZXksIGFuZCB0aGUgb3JpZ2luYWwgb2JqZWN0LlxuICogQHJldHVybiB7QXJyYXl9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBfbWFwKG9iamVjdCwgY2FsbGJhY2spIHtcbiAgICBpZiAoaXNGbihvYmplY3QgPT09IG51bGwgfHwgb2JqZWN0ID09PSB2b2lkIDAgPyB2b2lkIDAgOiBvYmplY3QubWFwKSlcbiAgICAgICAgcmV0dXJuIG9iamVjdC5tYXAoY2FsbGJhY2spO1xuICAgIHJldHVybiBPYmplY3QuZW50cmllcyhvYmplY3QgfHwge30pLm1hcChfcmVmMyA9PiB7XG4gICAgICAgIHZhciBbaywgdl0gPSBfcmVmMztcbiAgICAgICAgcmV0dXJuIGNhbGxiYWNrKHYsIGssIG9iamVjdCk7XG4gICAgfSk7XG59XG4vKlxuKiBJbnNlcnRzIGFuIGVsZW1lbnQoZWxtKSBhcyB0YXJnZXRzIGNoaWxkLCBieSBkZWZhdWx0IGFzIGZpcnN0IGNoaWxkXG4qIEBwYXJhbSB7SFRNTEVsZW1lbnR9IGVsbVxuKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBbZG9jXVxuKiBAcGFyYW0ge0hUTUxFbGVtZW50fSBbdGFyZ2V0XVxuKiBAcGFyYW0ge0Jvb2xlYW59IFthc0xhc3RDaGlsZENoaWxkXVxuKiBAcmV0dXJuIHtIVE1MIEVsZW1lbnR9XG4qL1xuZXhwb3J0IGZ1bmN0aW9uIGluc2VydEVsZW1lbnQoZWxtLCBkb2MsIHRhcmdldCwgYXNMYXN0Q2hpbGRDaGlsZCkge1xuICAgIGRvYyA9IGRvYyB8fCBkb2N1bWVudDtcbiAgICB2YXIgcGFyZW50RWw7XG4gICAgaWYgKHRhcmdldCkge1xuICAgICAgICBwYXJlbnRFbCA9IGRvYy5nZXRFbGVtZW50c0J5VGFnTmFtZSh0YXJnZXQpO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcGFyZW50RWwgPSBkb2MuZ2V0RWxlbWVudHNCeVRhZ05hbWUoJ2hlYWQnKTtcbiAgICB9XG4gICAgdHJ5IHtcbiAgICAgICAgcGFyZW50RWwgPSBwYXJlbnRFbC5sZW5ndGggPyBwYXJlbnRFbCA6IGRvYy5nZXRFbGVtZW50c0J5VGFnTmFtZSgnYm9keScpO1xuICAgICAgICBpZiAocGFyZW50RWwubGVuZ3RoKSB7XG4gICAgICAgICAgICBwYXJlbnRFbCA9IHBhcmVudEVsWzBdO1xuICAgICAgICAgICAgdmFyIGluc2VydEJlZm9yZUVsID0gYXNMYXN0Q2hpbGRDaGlsZCA/IG51bGwgOiBwYXJlbnRFbC5maXJzdENoaWxkO1xuICAgICAgICAgICAgcmV0dXJuIHBhcmVudEVsLmluc2VydEJlZm9yZShlbG0sIGluc2VydEJlZm9yZUVsKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBjYXRjaCAoZSkgeyB9XG59XG4vKipcbiAqIFJldHVybnMgYSBwcm9taXNlIHRoYXQgY29tcGxldGVzIHdoZW4gdGhlIGdpdmVuIGVsZW1lbnQgdHJpZ2dlcnMgYSAnbG9hZCcgb3IgJ2Vycm9yJyBET00gZXZlbnQsIG9yIHdoZW5cbiAqIGB0aW1lb3V0YCBtaWxsaXNlY29uZHMgaGF2ZSBlbGFwc2VkLlxuICpcbiAqIEBwYXJhbSB7SFRNTEVsZW1lbnR9IGVsZW1lbnRcbiAqIEBwYXJhbSB7TnVtYmVyfSBbdGltZW91dF1cbiAqIEByZXR1cm5zIHtQcm9taXNlfVxuICovXG5leHBvcnQgZnVuY3Rpb24gd2FpdEZvckVsZW1lbnRUb0xvYWQoZWxlbWVudCwgdGltZW91dCkge1xuICAgIHZhciB0aW1lciA9IG51bGw7XG4gICAgcmV0dXJuIG5ldyBHcmVlZHlQcm9taXNlKHJlc29sdmUgPT4ge1xuICAgICAgICB2YXIgb25Mb2FkID0gZnVuY3Rpb24gKCkge1xuICAgICAgICAgICAgZWxlbWVudC5yZW1vdmVFdmVudExpc3RlbmVyKCdsb2FkJywgb25Mb2FkKTtcbiAgICAgICAgICAgIGVsZW1lbnQucmVtb3ZlRXZlbnRMaXN0ZW5lcignZXJyb3InLCBvbkxvYWQpO1xuICAgICAgICAgICAgaWYgKHRpbWVyICE9IG51bGwpIHtcbiAgICAgICAgICAgICAgICB3aW5kb3cuY2xlYXJUaW1lb3V0KHRpbWVyKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgfTtcbiAgICAgICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCdsb2FkJywgb25Mb2FkKTtcbiAgICAgICAgZWxlbWVudC5hZGRFdmVudExpc3RlbmVyKCdlcnJvcicsIG9uTG9hZCk7XG4gICAgICAgIGlmICh0aW1lb3V0ICE9IG51bGwpIHtcbiAgICAgICAgICAgIHRpbWVyID0gd2luZG93LnNldFRpbWVvdXQob25Mb2FkLCB0aW1lb3V0KTtcbiAgICAgICAgfVxuICAgIH0pO1xufVxuLyoqXG4gKiBJbnNlcnRzIGFuIGltYWdlIHBpeGVsIHdpdGggdGhlIHNwZWNpZmllZCBgdXJsYCBmb3IgY29va2llIHN5bmNcbiAqIEBwYXJhbSB7c3RyaW5nfSB1cmwgVVJMIHN0cmluZyBvZiB0aGUgaW1hZ2UgcGl4ZWwgdG8gbG9hZFxuICogQHBhcmFtICB7ZnVuY3Rpb259IFtkb25lXSBhbiBvcHRpb25hbCBleGl0IGNhbGxiYWNrLCB1c2VkIHdoZW4gdGhpcyB1c2Vyc3luYyBwaXhlbCBpcyBhZGRlZCBkdXJpbmcgYW4gYXN5bmMgcHJvY2Vzc1xuICogQHBhcmFtICB7TnVtYmVyfSBbdGltZW91dF0gYW4gb3B0aW9uYWwgdGltZW91dCBpbiBtaWxsaXNlY29uZHMgZm9yIHRoZSBpbWFnZSB0byBsb2FkIGJlZm9yZSBjYWxsaW5nIGBkb25lYFxuICovXG5leHBvcnQgZnVuY3Rpb24gdHJpZ2dlclBpeGVsKHVybCwgZG9uZSwgdGltZW91dCkge1xuICAgIHZhciBpbWcgPSBuZXcgSW1hZ2UoKTtcbiAgICBpZiAoZG9uZSAmJiBpbnRlcm5hbC5pc0ZuKGRvbmUpKSB7XG4gICAgICAgIHdhaXRGb3JFbGVtZW50VG9Mb2FkKGltZywgdGltZW91dCkudGhlbihkb25lKTtcbiAgICB9XG4gICAgaW1nLnNyYyA9IHVybDtcbn1cbi8qKlxuICogSW5zZXJ0cyBhbiBlbXB0eSBpZnJhbWUgd2l0aCB0aGUgc3BlY2lmaWVkIGBodG1sYCwgcHJpbWFyaWx5IHVzZWQgZm9yIHRyYWNraW5nIHB1cnBvc2VzXG4gKiAodGhvdWdoIGNvdWxkIGJlIGZvciBvdGhlciBwdXJwb3NlcylcbiAqIEBwYXJhbSB7c3RyaW5nfSBodG1sQ29kZSBzbmlwcGV0IG9mIEhUTUwgY29kZSB1c2VkIGZvciB0cmFja2luZyBwdXJwb3Nlc1xuICovXG5leHBvcnQgZnVuY3Rpb24gaW5zZXJ0SHRtbEludG9JZnJhbWUoaHRtbENvZGUpIHtcbiAgICBpZiAoIWh0bWxDb2RlKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgdmFyIGlmcmFtZSA9IGNyZWF0ZUludmlzaWJsZUlmcmFtZSgpO1xuICAgIGludGVybmFsLmluc2VydEVsZW1lbnQoaWZyYW1lLCBkb2N1bWVudCwgJ2JvZHknKTtcbiAgICAoZG9jID0+IHtcbiAgICAgICAgZG9jLm9wZW4oKTtcbiAgICAgICAgZG9jLndyaXRlKGh0bWxDb2RlKTtcbiAgICAgICAgZG9jLmNsb3NlKCk7XG4gICAgfSkoaWZyYW1lLmNvbnRlbnRXaW5kb3cuZG9jdW1lbnQpO1xufVxuLyoqXG4gKiBJbnNlcnRzIGVtcHR5IGlmcmFtZSB3aXRoIHRoZSBzcGVjaWZpZWQgYHVybGAgZm9yIGNvb2tpZSBzeW5jXG4gKiBAcGFyYW0gIHtzdHJpbmd9IHVybCBVUkwgdG8gYmUgcmVxdWVzdGVkXG4gKiBAcGFyYW0gIHtmdW5jdGlvbn0gW2RvbmVdIGFuIG9wdGlvbmFsIGV4aXQgY2FsbGJhY2ssIHVzZWQgd2hlbiB0aGlzIHVzZXJzeW5jIHBpeGVsIGlzIGFkZGVkIGR1cmluZyBhbiBhc3luYyBwcm9jZXNzXG4gKiBAcGFyYW0gIHtOdW1iZXJ9IFt0aW1lb3V0XSBhbiBvcHRpb25hbCB0aW1lb3V0IGluIG1pbGxpc2Vjb25kcyBmb3IgdGhlIGlmcmFtZSB0byBsb2FkIGJlZm9yZSBjYWxsaW5nIGBkb25lYFxuICovXG5leHBvcnQgZnVuY3Rpb24gaW5zZXJ0VXNlclN5bmNJZnJhbWUodXJsLCBkb25lLCB0aW1lb3V0KSB7XG4gICAgdmFyIGlmcmFtZUh0bWwgPSBpbnRlcm5hbC5jcmVhdGVUcmFja1BpeGVsSWZyYW1lSHRtbCh1cmwsIGZhbHNlLCAnYWxsb3ctc2NyaXB0cyBhbGxvdy1zYW1lLW9yaWdpbicpO1xuICAgIHZhciBkaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKTtcbiAgICBkaXYuaW5uZXJIVE1MID0gaWZyYW1lSHRtbDtcbiAgICB2YXIgaWZyYW1lID0gZGl2LmZpcnN0Q2hpbGQ7XG4gICAgaWYgKGRvbmUgJiYgaW50ZXJuYWwuaXNGbihkb25lKSkge1xuICAgICAgICB3YWl0Rm9yRWxlbWVudFRvTG9hZChpZnJhbWUsIHRpbWVvdXQpLnRoZW4oZG9uZSk7XG4gICAgfVxuICAgIGludGVybmFsLmluc2VydEVsZW1lbnQoaWZyYW1lLCBkb2N1bWVudCwgJ2h0bWwnLCB0cnVlKTtcbn1cbi8qKlxuICogQ3JlYXRlcyBhIHNuaXBwZXQgb2YgSFRNTCB0aGF0IHJldHJpZXZlcyB0aGUgc3BlY2lmaWVkIGB1cmxgXG4gKiBAcGFyYW0gIHtzdHJpbmd9IHVybCBVUkwgdG8gYmUgcmVxdWVzdGVkXG4gKiBAcGFyYW0gZW5jb2RlXG4gKiBAcmV0dXJuIHtzdHJpbmd9ICAgICBIVE1MIHNuaXBwZXQgdGhhdCBjb250YWlucyB0aGUgaW1nIHNyYyA9IHNldCB0byBgdXJsYFxuICovXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVHJhY2tQaXhlbEh0bWwodXJsKSB7XG4gICAgdmFyIGVuY29kZSA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogZW5jb2RlVVJJO1xuICAgIGlmICghdXJsKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG4gICAgdmFyIGVzY2FwZWRVcmwgPSBlbmNvZGUodXJsKTtcbiAgICB2YXIgaW1nID0gJzxkaXYgc3R5bGU9XCJwb3NpdGlvbjphYnNvbHV0ZTtsZWZ0OjBweDt0b3A6MHB4O3Zpc2liaWxpdHk6aGlkZGVuO1wiPic7XG4gICAgaW1nICs9ICc8aW1nIHNyYz1cIicgKyBlc2NhcGVkVXJsICsgJ1wiPjwvZGl2Pic7XG4gICAgcmV0dXJuIGltZztcbn1cbjtcbi8qKlxuICogZW5jb2RlVVJJLCBidXQgcHJlc2VydmVzIG1hY3JvcyBvZiB0aGUgZm9ybSAnJHtNQUNST30nIChlLmcuICcke0FVQ1RJT05fUFJJQ0V9JylcbiAqIEBwYXJhbSB1cmxcbiAqIEByZXR1cm4ge3N0cmluZ31cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGVuY29kZU1hY3JvVVJJKHVybCkge1xuICAgIHZhciBtYWNyb3MgPSBBcnJheS5mcm9tKHVybC5tYXRjaEFsbCgvXFwkKHtbXn1dK30pL2cpKS5tYXAobWF0Y2ggPT4gbWF0Y2hbMV0pO1xuICAgIHJldHVybiBtYWNyb3MucmVkdWNlKChzdHIsIG1hY3JvKSA9PiB7XG4gICAgICAgIHJldHVybiBzdHIucmVwbGFjZSgnJCcgKyBlbmNvZGVVUklDb21wb25lbnQobWFjcm8pLCAnJCcgKyBtYWNybyk7XG4gICAgfSwgZW5jb2RlVVJJKHVybCkpO1xufVxuLyoqXG4gKiBDcmVhdGVzIGEgc25pcHBldCBvZiBJZnJhbWUgSFRNTCB0aGF0IHJldHJpZXZlcyB0aGUgc3BlY2lmaWVkIGB1cmxgXG4gKiBAcGFyYW0gIHtzdHJpbmd9IHVybCBwbGFpbiBVUkwgdG8gYmUgcmVxdWVzdGVkXG4gKiBAcGFyYW0gIHtzdHJpbmd9IGVuY29kZVVyaSBib29sZWFuIGlmIFVSTCBzaG91bGQgYmUgZW5jb2RlZCBiZWZvcmUgaW5zZXJ0ZWQuIERlZmF1bHRzIHRvIHRydWVcbiAqIEBwYXJhbSAge3N0cmluZ30gc2FuZGJveCBzdHJpbmcgaWYgcHJvdmlkZWQgdGhlIHNhbmRib3ggYXR0cmlidXRlIHdpbGwgYmUgaW5jbHVkZWQgd2l0aCB0aGUgZ2l2ZW4gdmFsdWVcbiAqIEByZXR1cm4ge3N0cmluZ30gICAgIEhUTUwgc25pcHBldCB0aGF0IGNvbnRhaW5zIHRoZSBpZnJhbWUgc3JjID0gc2V0IHRvIGB1cmxgXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBjcmVhdGVUcmFja1BpeGVsSWZyYW1lSHRtbCh1cmwpIHtcbiAgICB2YXIgZW5jb2RlVXJpID0gYXJndW1lbnRzLmxlbmd0aCA+IDEgJiYgYXJndW1lbnRzWzFdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMV0gOiB0cnVlO1xuICAgIHZhciBzYW5kYm94ID0gYXJndW1lbnRzLmxlbmd0aCA+IDIgJiYgYXJndW1lbnRzWzJdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMl0gOiAnJztcbiAgICBpZiAoIXVybCkge1xuICAgICAgICByZXR1cm4gJyc7XG4gICAgfVxuICAgIGlmIChlbmNvZGVVcmkpIHtcbiAgICAgICAgdXJsID0gZW5jb2RlVVJJKHVybCk7XG4gICAgfVxuICAgIGlmIChzYW5kYm94KSB7XG4gICAgICAgIHNhbmRib3ggPSBcInNhbmRib3g9XFxcIlwiLmNvbmNhdChzYW5kYm94LCBcIlxcXCJcIik7XG4gICAgfVxuICAgIHJldHVybiBcIjxpZnJhbWUgXCIuY29uY2F0KHNhbmRib3gsIFwiIGlkPVxcXCJcIikuY29uY2F0KGdldFVuaXF1ZUlkZW50aWZpZXJTdHIoKSwgXCJcXFwiXFxuICAgICAgZnJhbWVib3JkZXI9XFxcIjBcXFwiXFxuICAgICAgYWxsb3d0cmFuc3BhcmVuY3k9XFxcInRydWVcXFwiXFxuICAgICAgbWFyZ2luaGVpZ2h0PVxcXCIwXFxcIiBtYXJnaW53aWR0aD1cXFwiMFxcXCJcXG4gICAgICB3aWR0aD1cXFwiMFxcXCIgaHNwYWNlPVxcXCIwXFxcIiB2c3BhY2U9XFxcIjBcXFwiIGhlaWdodD1cXFwiMFxcXCJcXG4gICAgICBzdHlsZT1cXFwiaGVpZ2h0OjBweDt3aWR0aDowcHg7ZGlzcGxheTpub25lO1xcXCJcXG4gICAgICBzY3JvbGxpbmc9XFxcIm5vXFxcIlxcbiAgICAgIHNyYz1cXFwiXCIpLmNvbmNhdCh1cmwsIFwiXFxcIj5cXG4gICAgPC9pZnJhbWU+XCIpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHVuaXF1ZXModmFsdWUsIGluZGV4LCBhcnJ5KSB7XG4gICAgcmV0dXJuIGFycnkuaW5kZXhPZih2YWx1ZSkgPT09IGluZGV4O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGZsYXR0ZW4oYSwgYikge1xuICAgIHJldHVybiBhLmNvbmNhdChiKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRCaWRSZXF1ZXN0KGlkLCBiaWRkZXJSZXF1ZXN0cykge1xuICAgIGlmICghaWQpIHtcbiAgICAgICAgcmV0dXJuO1xuICAgIH1cbiAgICByZXR1cm4gYmlkZGVyUmVxdWVzdHMuZmxhdE1hcChiciA9PiBici5iaWRzKS5maW5kKGJpZCA9PiBbJ2JpZElkJywgJ2FkSWQnLCAnYmlkX2lkJ10uc29tZShwcm9wID0+IGJpZFtwcm9wXSA9PT0gaWQpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRWYWx1ZShvYmosIGtleSkge1xuICAgIHJldHVybiBvYmpba2V5XTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBnZXRCaWRkZXJDb2RlcygpIHtcbiAgICB2YXIgYWRVbml0cyA9IGFyZ3VtZW50cy5sZW5ndGggPiAwICYmIGFyZ3VtZW50c1swXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzBdIDogcGJqc0luc3RhbmNlLmFkVW5pdHM7XG4gICAgLy8gdGhpcyBjb3VsZCBtZW1vaXplIGFkVW5pdHNcbiAgICByZXR1cm4gYWRVbml0cy5tYXAodW5pdCA9PiB1bml0LmJpZHMubWFwKGJpZCA9PiBiaWQuYmlkZGVyKS5yZWR1Y2UoZmxhdHRlbiwgW10pKS5yZWR1Y2UoZmxhdHRlbiwgW10pLmZpbHRlcihiaWRkZXIgPT4gdHlwZW9mIGJpZGRlciAhPT0gJ3VuZGVmaW5lZCcpLmZpbHRlcih1bmlxdWVzKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0dwdFB1YmFkc0RlZmluZWQoKSB7XG4gICAgaWYgKHdpbmRvdy5nb29nbGV0YWcgJiYgaXNGbih3aW5kb3cuZ29vZ2xldGFnLnB1YmFkcykgJiYgaXNGbih3aW5kb3cuZ29vZ2xldGFnLnB1YmFkcygpLmdldFNsb3RzKSkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG59XG5leHBvcnQgZnVuY3Rpb24gaXNBcG5HZXRUYWdEZWZpbmVkKCkge1xuICAgIGlmICh3aW5kb3cuYXBudGFnICYmIGlzRm4od2luZG93LmFwbnRhZy5nZXRUYWcpKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbn1cbmV4cG9ydCB2YXIgc29ydEJ5SGlnaGVzdENwbSA9IChhLCBiKSA9PiB7XG4gICAgcmV0dXJuIGIuY3BtIC0gYS5jcG07XG59O1xuLyoqXG4gKiBGaXNoZXLigJNZYXRlcyBzaHVmZmxlXG4gKiBodHRwOi8vc3RhY2tvdmVyZmxvdy5jb20vYS82Mjc0Mzk4XG4gKiBodHRwczovL2Jvc3Qub2Nrcy5vcmcvbWlrZS9zaHVmZmxlL1xuICogaXN0YW5idWwgaWdub3JlIG5leHRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNodWZmbGUoYXJyYXkpIHtcbiAgICB2YXIgY291bnRlciA9IGFycmF5Lmxlbmd0aDtcbiAgICAvLyB3aGlsZSB0aGVyZSBhcmUgZWxlbWVudHMgaW4gdGhlIGFycmF5XG4gICAgd2hpbGUgKGNvdW50ZXIgPiAwKSB7XG4gICAgICAgIC8vIHBpY2sgYSByYW5kb20gaW5kZXhcbiAgICAgICAgdmFyIGluZGV4ID0gTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogY291bnRlcik7XG4gICAgICAgIC8vIGRlY3JlYXNlIGNvdW50ZXIgYnkgMVxuICAgICAgICBjb3VudGVyLS07XG4gICAgICAgIC8vIGFuZCBzd2FwIHRoZSBsYXN0IGVsZW1lbnQgd2l0aCBpdFxuICAgICAgICB2YXIgdGVtcCA9IGFycmF5W2NvdW50ZXJdO1xuICAgICAgICBhcnJheVtjb3VudGVyXSA9IGFycmF5W2luZGV4XTtcbiAgICAgICAgYXJyYXlbaW5kZXhdID0gdGVtcDtcbiAgICB9XG4gICAgcmV0dXJuIGFycmF5O1xufVxuZXhwb3J0IGZ1bmN0aW9uIGRlZXBDbG9uZShvYmopIHtcbiAgICByZXR1cm4ga2xvbmEob2JqKSB8fCB7fTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpbklmcmFtZSgpIHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gaW50ZXJuYWwuZ2V0V2luZG93U2VsZigpICE9PSBpbnRlcm5hbC5nZXRXaW5kb3dUb3AoKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufVxuLyoqXG4gKiBodHRwczovL2lhYnRlY2hsYWIuY29tL3dwLWNvbnRlbnQvdXBsb2Fkcy8yMDE2LzAzL1NhZmVGcmFtZXNfdjEuMV9maW5hbC5wZGZcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzU2FmZUZyYW1lV2luZG93KCkge1xuICAgIGlmICghaW5JZnJhbWUoKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHZhciB3cyA9IGludGVybmFsLmdldFdpbmRvd1NlbGYoKTtcbiAgICByZXR1cm4gISEod3MuJHNmICYmIHdzLiRzZi5leHQpO1xufVxuLyoqXG4gKiBSZXR1cm5zIHRoZSByZXN1bHQgb2YgY2FsbGluZyB0aGUgZnVuY3Rpb24gJHNmLmV4dC5nZW9tKCkgaWYgaXQgZXhpc3RzXG4gKiBAc2VlIGh0dHBzOi8vaWFidGVjaGxhYi5jb20vd3AtY29udGVudC91cGxvYWRzLzIwMTYvMDMvU2FmZUZyYW1lc192MS4xX2ZpbmFsLnBkZiDigJQgNS40IEZ1bmN0aW9uICRzZi5leHQuZ2VvbVxuICogQHJldHVybnMge09iamVjdCB8IHVuZGVmaW5lZH0gZ2VvbWV0cmljIGluZm9ybWF0aW9uIGFib3V0IHRoZSBjb250YWluZXJcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldFNhZmVmcmFtZUdlb21ldHJ5KCkge1xuICAgIHRyeSB7XG4gICAgICAgIHZhciB3cyA9IGdldFdpbmRvd1NlbGYoKTtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB3cy4kc2YuZXh0Lmdlb20gPT09ICdmdW5jdGlvbicgPyB3cy4kc2YuZXh0Lmdlb20oKSA6IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgbG9nRXJyb3IoJ0Vycm9yIGdldHRpbmcgU2FmZUZyYW1lIGdlb21ldHJ5JywgZSk7XG4gICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIGlzU2FmYXJpQnJvd3NlcigpIHtcbiAgICByZXR1cm4gL14oKD8hY2hyb21lfGFuZHJvaWR8Y3Jpb3N8Znhpb3MpLikqc2FmYXJpL2kudGVzdChuYXZpZ2F0b3IudXNlckFnZW50KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXBsYWNlTWFjcm9zKHN0ciwgc3Vicykge1xuICAgIGlmICghc3RyKVxuICAgICAgICByZXR1cm47XG4gICAgcmV0dXJuIE9iamVjdC5lbnRyaWVzKHN1YnMpLnJlZHVjZSgoc3RyLCBfcmVmNCkgPT4ge1xuICAgICAgICB2YXIgW2tleSwgdmFsXSA9IF9yZWY0O1xuICAgICAgICByZXR1cm4gc3RyLnJlcGxhY2UobmV3IFJlZ0V4cCgnXFxcXCRcXFxceycgKyBrZXkgKyAnXFxcXH0nLCAnZycpLCB2YWwgfHwgJycpO1xuICAgIH0sIHN0cik7XG59XG5leHBvcnQgZnVuY3Rpb24gcmVwbGFjZUF1Y3Rpb25QcmljZShzdHIsIGNwbSkge1xuICAgIHJldHVybiByZXBsYWNlTWFjcm9zKHN0ciwge1xuICAgICAgICBBVUNUSU9OX1BSSUNFOiBjcG1cbiAgICB9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiByZXBsYWNlQ2xpY2tUaHJvdWdoKHN0ciwgY2xpY2t0YWcpIHtcbiAgICBpZiAoIXN0ciB8fCAhY2xpY2t0YWcgfHwgdHlwZW9mIGNsaWNrdGFnICE9PSAnc3RyaW5nJylcbiAgICAgICAgcmV0dXJuO1xuICAgIHJldHVybiBzdHIucmVwbGFjZSgvXFwke0NMSUNLVEhST1VHSH0vZywgY2xpY2t0YWcpO1xufVxuZXhwb3J0IGZ1bmN0aW9uIHRpbWVzdGFtcCgpIHtcbiAgICByZXR1cm4gbmV3IERhdGUoKS5nZXRUaW1lKCk7XG59XG4vKipcbiAqIFRoZSByZXR1cm5lZCB2YWx1ZSByZXByZXNlbnRzIHRoZSB0aW1lIGVsYXBzZWQgc2luY2UgdGhlIHRpbWUgb3JpZ2luLiBAc2VlIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0FQSS9QZXJmb3JtYW5jZS9ub3dcbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRQZXJmb3JtYW5jZU5vdygpIHtcbiAgICByZXR1cm4gd2luZG93LnBlcmZvcm1hbmNlICYmIHdpbmRvdy5wZXJmb3JtYW5jZS5ub3cgJiYgd2luZG93LnBlcmZvcm1hbmNlLm5vdygpIHx8IDA7XG59XG4vKipcbiAqIFJldHVucyB0aGUgZGlmZmVyZW5jZSBiZXR3ZWVuIGB0aW1pbmcuZG9tTG9hZGluZ2AgYW5kIGB0aW1pbmcubmF2aWdhdGlvblN0YXJ0YC5cbiAqIFRoaXMgZnVuY3Rpb24gdXNlcyB0aGUgZGVwcmVjYXRlZCBgUGVyZm9ybWFuY2UudGltaW5nYCBBUEkgYW5kIHNob3VsZCBiZSByZW1vdmVkIGluIGZ1dHVyZS5cbiAqIEl0IGhhcyBub3QgYmVlbiB1cGRhdGVkIHlldCBiZWNhdXNlIGl0IGlzIHN0aWxsIHVzZWQgaW4gc29tZSBtb2R1bGVzLlxuICogQGRlcHJlY2F0ZWRcbiAqIEBwYXJhbSB7V2luZG93fSB3IFRoZSB3aW5kb3cgb2JqZWN0IHVzZWQgdG8gcGVyZm9ybSB0aGUgYXBpIGNhbGwuIGRlZmF1bHQgdG8gd2luZG93LnNlbGZcbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREb21Mb2FkaW5nRHVyYXRpb24odykge1xuICAgIHZhciBfdyRwZXJmb3JtYW5jZTtcbiAgICB2YXIgZG9tTG9hZGluZ0R1cmF0aW9uID0gLTE7XG4gICAgdyA9IHcgfHwgZ2V0V2luZG93U2VsZigpO1xuICAgIHZhciBwZXJmb3JtYW5jZSA9IHcucGVyZm9ybWFuY2U7XG4gICAgaWYgKChfdyRwZXJmb3JtYW5jZSA9IHcucGVyZm9ybWFuY2UpICE9PSBudWxsICYmIF93JHBlcmZvcm1hbmNlICE9PSB2b2lkIDAgJiYgX3ckcGVyZm9ybWFuY2UudGltaW5nKSB7XG4gICAgICAgIGlmICh3LnBlcmZvcm1hbmNlLnRpbWluZy5uYXZpZ2F0aW9uU3RhcnQgPiAwKSB7XG4gICAgICAgICAgICB2YXIgdmFsID0gcGVyZm9ybWFuY2UudGltaW5nLmRvbUxvYWRpbmcgLSBwZXJmb3JtYW5jZS50aW1pbmcubmF2aWdhdGlvblN0YXJ0O1xuICAgICAgICAgICAgaWYgKHZhbCA+IDApIHtcbiAgICAgICAgICAgICAgICBkb21Mb2FkaW5nRHVyYXRpb24gPSB2YWw7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIGRvbUxvYWRpbmdEdXJhdGlvbjtcbn1cbi8qKlxuICogV2hlbiB0aGUgZGV2aWNlQWNjZXNzIGZsYWcgY29uZmlnIG9wdGlvbiBpcyBmYWxzZSwgbm8gY29va2llcyBzaG91bGQgYmUgcmVhZCBvciBzZXRcbiAqIEByZXR1cm5zIHtib29sZWFufVxuICovXG5leHBvcnQgZnVuY3Rpb24gaGFzRGV2aWNlQWNjZXNzKCkge1xuICAgIHJldHVybiBjb25maWcuZ2V0Q29uZmlnKCdkZXZpY2VBY2Nlc3MnKSAhPT0gZmFsc2U7XG59XG4vKipcbiAqIEByZXR1cm5zIHsoYm9vbGVhbnx1bmRlZmluZWQpfVxuICovXG5leHBvcnQgZnVuY3Rpb24gY2hlY2tDb29raWVTdXBwb3J0KCkge1xuICAgIC8vIGVzbGludC1kaXNhYmxlLW5leHQtbGluZSBwcmViaWQvbm8tbWVtYmVyXG4gICAgaWYgKHdpbmRvdy5uYXZpZ2F0b3IuY29va2llRW5hYmxlZCB8fCAhIWRvY3VtZW50LmNvb2tpZS5sZW5ndGgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxufVxuLyoqXG4gKiBHaXZlbiBhIGZ1bmN0aW9uLCByZXR1cm4gYSBmdW5jdGlvbiB3aGljaCBvbmx5IGV4ZWN1dGVzIHRoZSBvcmlnaW5hbCBhZnRlclxuICogaXQncyBiZWVuIGNhbGxlZCBudW1SZXF1aXJlZENhbGxzIHRpbWVzLlxuICpcbiAqIE5vdGUgdGhhdCB0aGUgYXJndW1lbnRzIGZyb20gdGhlIHByZXZpb3VzIGNhbGxzIHdpbGwgKm5vdCogYmUgZm9yd2FyZGVkIHRvIHRoZSBvcmlnaW5hbCBmdW5jdGlvbi5cbiAqIE9ubHkgdGhlIGZpbmFsIGNhbGwncyBhcmd1bWVudHMgbWF0dGVyLlxuICpcbiAqIEBwYXJhbSB7ZnVuY3Rpb259IGZ1bmMgVGhlIGZ1bmN0aW9uIHdoaWNoIHNob3VsZCBiZSBleGVjdXRlZCwgb25jZSB0aGUgcmV0dXJuZWQgZnVuY3Rpb24gaGFzIGJlZW4gZXhlY3V0ZWRcbiAqICAgbnVtUmVxdWlyZWRDYWxscyB0aW1lcy5cbiAqIEBwYXJhbSB7bnVtYmVyfSBudW1SZXF1aXJlZENhbGxzIFRoZSBudW1iZXIgb2YgdGltZXMgd2hpY2ggdGhlIHJldHVybmVkIGZ1bmN0aW9uIG5lZWRzIHRvIGJlIGNhbGxlZCBiZWZvcmVcbiAqICAgZnVuYyBpcy5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlbGF5RXhlY3V0aW9uKGZ1bmMsIG51bVJlcXVpcmVkQ2FsbHMpIHtcbiAgICBpZiAobnVtUmVxdWlyZWRDYWxscyA8IDEpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwibnVtUmVxdWlyZWRDYWxscyBtdXN0IGJlIGEgcG9zaXRpdmUgbnVtYmVyLiBHb3QgXCIuY29uY2F0KG51bVJlcXVpcmVkQ2FsbHMpKTtcbiAgICB9XG4gICAgdmFyIG51bUNhbGxzID0gMDtcbiAgICByZXR1cm4gZnVuY3Rpb24gKCkge1xuICAgICAgICBudW1DYWxscysrO1xuICAgICAgICBpZiAobnVtQ2FsbHMgPT09IG51bVJlcXVpcmVkQ2FsbHMpIHtcbiAgICAgICAgICAgIGZ1bmMuYXBwbHkodGhpcywgYXJndW1lbnRzKTtcbiAgICAgICAgfVxuICAgIH07XG59XG4vKipcbiAqIGh0dHBzOi8vc3RhY2tvdmVyZmxvdy5jb20vYS8zNDg5MDI3Ni80Mjg3MDRcbiAqIEBwYXJhbSB7QXJyYXl9IHhzXG4gKiBAcGFyYW0ge3N0cmluZ30ga2V5XG4gKiBAcmV0dXJucyB7T2JqZWN0fSB7JHtrZXlfdmFsdWV9OiAke2dyb3VwQnlBcnJheX0sIGtleV92YWx1ZToge2dyb3VwQnlBcnJheX19XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBncm91cEJ5KHhzLCBrZXkpIHtcbiAgICByZXR1cm4geHMucmVkdWNlKGZ1bmN0aW9uIChydiwgeCkge1xuICAgICAgICAocnZbeFtrZXldXSA9IHJ2W3hba2V5XV0gfHwgW10pLnB1c2goeCk7XG4gICAgICAgIHJldHVybiBydjtcbiAgICB9LCB7fSk7XG59XG4vKipcbiAqIEJ1aWxkIGFuIG9iamVjdCBjb25zaXN0aW5nIG9mIG9ubHkgZGVmaW5lZCBwYXJhbWV0ZXJzIHRvIGF2b2lkIGNyZWF0aW5nIGFuXG4gKiBvYmplY3Qgd2l0aCBkZWZpbmVkIGtleXMgYW5kIHVuZGVmaW5lZCB2YWx1ZXMuXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqZWN0IFRoZSBvYmplY3QgdG8gcGljayBkZWZpbmVkIHBhcmFtcyBvdXQgb2ZcbiAqIEBwYXJhbSB7c3RyaW5nW119IHBhcmFtcyBBbiBhcnJheSBvZiBzdHJpbmdzIHJlcHJlc2VudGluZyBwcm9wZXJ0aWVzIHRvIGxvb2sgZm9yIGluIHRoZSBvYmplY3RcbiAqIEByZXR1cm5zIHtPYmplY3R9IEFuIG9iamVjdCBjb250YWluaW5nIGFsbCB0aGUgc3BlY2lmaWVkIHZhbHVlcyB0aGF0IGFyZSBkZWZpbmVkXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXREZWZpbmVkUGFyYW1zKG9iamVjdCwgcGFyYW1zKSB7XG4gICAgcmV0dXJuIHBhcmFtcy5maWx0ZXIocGFyYW0gPT4gb2JqZWN0W3BhcmFtXSkucmVkdWNlKChiaWQsIHBhcmFtKSA9PiBPYmplY3QuYXNzaWduKGJpZCwge1xuICAgICAgICBbcGFyYW1dOiBvYmplY3RbcGFyYW1dXG4gICAgfSksIHt9KTtcbn1cbi8qKlxuICogQHR5cGVkZWYge09iamVjdH0gTWVkaWFUeXBlc1xuICogQHByb3BlcnR5IHtPYmplY3R9IGJhbm5lciBiYW5uZXIgY29uZmlndXJhdGlvblxuICogQHByb3BlcnR5IHtPYmplY3R9IG5hdGl2ZSBuYXRpdmUgY29uZmlndXJhdGlvblxuICogQHByb3BlcnR5IHtPYmplY3R9IHZpZGVvIHZpZGVvIGNvbmZpZ3VyYXRpb25cbiAqL1xuLyoqXG4gKiBWYWxpZGF0ZXMgYW4gYWR1bml0J3MgYG1lZGlhVHlwZXNgIHBhcmFtZXRlclxuICogQHBhcmFtIHtNZWRpYVR5cGVzfSBtZWRpYVR5cGVzIG1lZGlhVHlwZXMgcGFyYW1ldGVyIHRvIHZhbGlkYXRlXG4gKiBAcmV0dXJuIHtib29sZWFufSBJZiBvYmplY3QgaXMgdmFsaWRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGlzVmFsaWRNZWRpYVR5cGVzKG1lZGlhVHlwZXMpIHtcbiAgICB2YXIgU1VQUE9SVEVEX01FRElBX1RZUEVTID0gWydiYW5uZXInLCAnbmF0aXZlJywgJ3ZpZGVvJ107XG4gICAgdmFyIFNVUFBPUlRFRF9TVFJFQU1fVFlQRVMgPSBbJ2luc3RyZWFtJywgJ291dHN0cmVhbScsICdhZHBvZCddO1xuICAgIHZhciB0eXBlcyA9IE9iamVjdC5rZXlzKG1lZGlhVHlwZXMpO1xuICAgIGlmICghdHlwZXMuZXZlcnkodHlwZSA9PiBpbmNsdWRlcyhTVVBQT1JURURfTUVESUFfVFlQRVMsIHR5cGUpKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlmICh0cnVlICYmIG1lZGlhVHlwZXMudmlkZW8gJiYgbWVkaWFUeXBlcy52aWRlby5jb250ZXh0KSB7XG4gICAgICAgIHJldHVybiBpbmNsdWRlcyhTVVBQT1JURURfU1RSRUFNX1RZUEVTLCBtZWRpYVR5cGVzLnZpZGVvLmNvbnRleHQpO1xuICAgIH1cbiAgICByZXR1cm4gdHJ1ZTtcbn1cbi8qKlxuICogUmV0dXJucyB1c2VyIGNvbmZpZ3VyZWQgYmlkZGVyIHBhcmFtcyBmcm9tIGFkdW5pdFxuICogQHBhcmFtIHtPYmplY3R9IGFkVW5pdHNcbiAqIEBwYXJhbSB7c3RyaW5nfSBhZFVuaXRDb2RlIGNvZGVcbiAqIEBwYXJhbSB7c3RyaW5nfSBiaWRkZXIgY29kZVxuICogQHJldHVybiB7QXJyYXl9IHVzZXIgY29uZmlndXJlZCBwYXJhbSBmb3IgdGhlIGdpdmVuIGJpZGRlciBhZHVuaXQgY29uZmlndXJhdGlvblxuICovXG5leHBvcnQgZnVuY3Rpb24gZ2V0VXNlckNvbmZpZ3VyZWRQYXJhbXMoYWRVbml0cywgYWRVbml0Q29kZSwgYmlkZGVyKSB7XG4gICAgcmV0dXJuIGFkVW5pdHMuZmlsdGVyKGFkVW5pdCA9PiBhZFVuaXQuY29kZSA9PT0gYWRVbml0Q29kZSkuZmxhdE1hcChhZFVuaXQgPT4gYWRVbml0LmJpZHMpLmZpbHRlcihiaWRkZXJEYXRhID0+IGJpZGRlckRhdGEuYmlkZGVyID09PSBiaWRkZXIpLm1hcChiaWRkZXJEYXRhID0+IGJpZGRlckRhdGEucGFyYW1zIHx8IHt9KTtcbn1cbi8qKlxuICogUmV0dXJucyBEbyBOb3QgVHJhY2sgc3RhdGVcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGdldEROVCgpIHtcbiAgICByZXR1cm4gbmF2aWdhdG9yLmRvTm90VHJhY2sgPT09ICcxJyB8fCB3aW5kb3cuZG9Ob3RUcmFjayA9PT0gJzEnIHx8IG5hdmlnYXRvci5tc0RvTm90VHJhY2sgPT09ICcxJyB8fCBuYXZpZ2F0b3IuZG9Ob3RUcmFjayA9PT0gJ3llcyc7XG59XG5leHBvcnQgdmFyIGNvbXBhcmVDb2RlQW5kU2xvdCA9IChzbG90LCBhZFVuaXRDb2RlKSA9PiBzbG90LmdldEFkVW5pdFBhdGgoKSA9PT0gYWRVbml0Q29kZSB8fCBzbG90LmdldFNsb3RFbGVtZW50SWQoKSA9PT0gYWRVbml0Q29kZTtcbi8qKlxuICogUmV0dXJucyBmaWx0ZXIgZnVuY3Rpb24gdG8gbWF0Y2ggYWRVbml0Q29kZSBpbiBzbG90XG4gKiBAcGFyYW0ge09iamVjdH0gc2xvdCBHb29nbGVUYWcgc2xvdFxuICogQHJldHVybiB7ZnVuY3Rpb259IGZpbHRlciBmdW5jdGlvblxuICovXG5leHBvcnQgZnVuY3Rpb24gaXNBZFVuaXRDb2RlTWF0Y2hpbmdTbG90KHNsb3QpIHtcbiAgICByZXR1cm4gYWRVbml0Q29kZSA9PiBjb21wYXJlQ29kZUFuZFNsb3Qoc2xvdCwgYWRVbml0Q29kZSk7XG59XG4vKipcbiAqIENvbnN0cnVjdHMgd2FybmluZyBtZXNzYWdlIGZvciB3aGVuIHVuc3VwcG9ydGVkIGJpZGRlcnMgYXJlIGRyb3BwZWQgZnJvbSBhbiBhZHVuaXRcbiAqIEBwYXJhbSB7T2JqZWN0fSBhZFVuaXQgYWQgdW5pdCBmcm9tIHdoaWNoIHRoZSBiaWRkZXIgaXMgYmVpbmcgZHJvcHBlZFxuICogQHBhcmFtIHtzdHJpbmd9IGJpZGRlciBiaWRkZXIgY29kZSB0aGF0IGlzIG5vdCBjb21wYXRpYmxlIHdpdGggdGhlIGFkVW5pdFxuICogQHJldHVybiB7c3RyaW5nfSB3YXJuaW5nIG1lc3NhZ2UgdG8gZGlzcGxheSB3aGVuIGNvbmRpdGlvbiBpcyBtZXRcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHVuc3VwcG9ydGVkQmlkZGVyTWVzc2FnZShhZFVuaXQsIGJpZGRlcikge1xuICAgIHZhciBtZWRpYVR5cGUgPSBPYmplY3Qua2V5cyhhZFVuaXQubWVkaWFUeXBlcyB8fCB7XG4gICAgICAgICdiYW5uZXInOiAnYmFubmVyJ1xuICAgIH0pLmpvaW4oJywgJyk7XG4gICAgcmV0dXJuIFwiXFxuICAgIFwiLmNvbmNhdChhZFVuaXQuY29kZSwgXCIgaXMgYSBcIikuY29uY2F0KG1lZGlhVHlwZSwgXCIgYWQgdW5pdFxcbiAgICBjb250YWluaW5nIGJpZGRlcnMgdGhhdCBkb24ndCBzdXBwb3J0IFwiKS5jb25jYXQobWVkaWFUeXBlLCBcIjogXCIpLmNvbmNhdChiaWRkZXIsIFwiLlxcbiAgICBUaGlzIGJpZGRlciB3b24ndCBmZXRjaCBkZW1hbmQuXFxuICBcIik7XG59XG4vKipcbiAqIENoZWNrcyBpbnB1dCBpcyBpbnRlZ2VyIG9yIG5vdFxuICogaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSmF2YVNjcmlwdC9SZWZlcmVuY2UvR2xvYmFsX09iamVjdHMvTnVtYmVyL2lzSW50ZWdlclxuICogQHBhcmFtIHsqfSB2YWx1ZVxuICovXG5leHBvcnQgdmFyIGlzSW50ZWdlciA9IE51bWJlci5pc0ludGVnZXIuYmluZChOdW1iZXIpO1xuLyoqXG4gKiBSZXR1cm5zIGEgbmV3IG9iamVjdCB3aXRoIHVuZGVmaW5lZCBwcm9wZXJ0aWVzIHJlbW92ZWQgZnJvbSBnaXZlbiBvYmplY3RcbiAqIEBwYXJhbSBvYmogdGhlIG9iamVjdCB0byBjbGVhblxuICovXG5leHBvcnQgZnVuY3Rpb24gY2xlYW5PYmoob2JqKSB7XG4gICAgcmV0dXJuIE9iamVjdC5mcm9tRW50cmllcyhPYmplY3QuZW50cmllcyhvYmopLmZpbHRlcihfcmVmNSA9PiB7XG4gICAgICAgIHZhciBbXywgdl0gPSBfcmVmNTtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2ICE9PSAndW5kZWZpbmVkJztcbiAgICB9KSk7XG59XG4vKipcbiAqIENyZWF0ZSBhIG5ldyBvYmplY3Qgd2l0aCBzZWxlY3RlZCBwcm9wZXJ0aWVzLiAgQWxzbyBhbGxvd3MgcHJvcGVydHkgcmVuYW1pbmcgYW5kIHRyYW5zZm9ybSBmdW5jdGlvbnMuXG4gKiBAcGFyYW0gb2JqIHRoZSBvcmlnaW5hbCBvYmplY3RcbiAqIEBwYXJhbSBwcm9wZXJ0aWVzIEFuIGFycmF5IG9mIGRlc2lyZWQgcHJvcGVydGllc1xuICovXG5leHBvcnQgZnVuY3Rpb24gcGljayhvYmosIHByb3BlcnRpZXMpIHtcbiAgICBpZiAodHlwZW9mIG9iaiAhPT0gJ29iamVjdCcpIHtcbiAgICAgICAgcmV0dXJuIHt9O1xuICAgIH1cbiAgICByZXR1cm4gcHJvcGVydGllcy5yZWR1Y2UoKG5ld09iaiwgcHJvcCwgaSkgPT4ge1xuICAgICAgICBpZiAodHlwZW9mIHByb3AgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXdPYmo7XG4gICAgICAgIH1cbiAgICAgICAgdmFyIG5ld1Byb3AgPSBwcm9wO1xuICAgICAgICB2YXIgbWF0Y2ggPSBwcm9wLm1hdGNoKC9eKC4rPylcXHNhc1xccyguKz8pJC9pKTtcbiAgICAgICAgaWYgKG1hdGNoKSB7XG4gICAgICAgICAgICBwcm9wID0gbWF0Y2hbMV07XG4gICAgICAgICAgICBuZXdQcm9wID0gbWF0Y2hbMl07XG4gICAgICAgIH1cbiAgICAgICAgdmFyIHZhbHVlID0gb2JqW3Byb3BdO1xuICAgICAgICBpZiAodHlwZW9mIHByb3BlcnRpZXNbaSArIDFdID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICB2YWx1ZSA9IHByb3BlcnRpZXNbaSArIDFdKHZhbHVlLCBuZXdPYmopO1xuICAgICAgICB9XG4gICAgICAgIGlmICh0eXBlb2YgdmFsdWUgIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICBuZXdPYmpbbmV3UHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3T2JqO1xuICAgIH0sIHt9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBpc0FycmF5T2ZOdW1zKHZhbCwgc2l6ZSkge1xuICAgIHJldHVybiBpc0FycmF5KHZhbCkgJiYgKHNpemUgPyB2YWwubGVuZ3RoID09PSBzaXplIDogdHJ1ZSkgJiYgdmFsLmV2ZXJ5KHYgPT4gaXNJbnRlZ2VyKHYpKTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBwYXJzZVFTKHF1ZXJ5KSB7XG4gICAgcmV0dXJuICFxdWVyeSA/IHt9IDogcXVlcnkucmVwbGFjZSgvXlxcPy8sICcnKS5zcGxpdCgnJicpLnJlZHVjZSgoYWNjLCBjcml0ZXJpYSkgPT4ge1xuICAgICAgICB2YXIgW2ssIHZdID0gY3JpdGVyaWEuc3BsaXQoJz0nKTtcbiAgICAgICAgaWYgKC9cXFtcXF0kLy50ZXN0KGspKSB7XG4gICAgICAgICAgICBrID0gay5yZXBsYWNlKCdbXScsICcnKTtcbiAgICAgICAgICAgIGFjY1trXSA9IGFjY1trXSB8fCBbXTtcbiAgICAgICAgICAgIGFjY1trXS5wdXNoKHYpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgYWNjW2tdID0gdiB8fCAnJztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjO1xuICAgIH0sIHt9KTtcbn1cbmV4cG9ydCBmdW5jdGlvbiBmb3JtYXRRUyhxdWVyeSkge1xuICAgIHJldHVybiBPYmplY3Qua2V5cyhxdWVyeSkubWFwKGsgPT4gQXJyYXkuaXNBcnJheShxdWVyeVtrXSkgPyBxdWVyeVtrXS5tYXAodiA9PiBcIlwiLmNvbmNhdChrLCBcIltdPVwiKS5jb25jYXQodikpLmpvaW4oJyYnKSA6IFwiXCIuY29uY2F0KGssIFwiPVwiKS5jb25jYXQocXVlcnlba10pKS5qb2luKCcmJyk7XG59XG5leHBvcnQgZnVuY3Rpb24gcGFyc2VVcmwodXJsLCBvcHRpb25zKSB7XG4gICAgdmFyIHBhcnNlZCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2EnKTtcbiAgICBpZiAob3B0aW9ucyAmJiAnbm9EZWNvZGVXaG9sZVVSTCcgaW4gb3B0aW9ucyAmJiBvcHRpb25zLm5vRGVjb2RlV2hvbGVVUkwpIHtcbiAgICAgICAgcGFyc2VkLmhyZWYgPSB1cmw7XG4gICAgfVxuICAgIGVsc2Uge1xuICAgICAgICBwYXJzZWQuaHJlZiA9IGRlY29kZVVSSUNvbXBvbmVudCh1cmwpO1xuICAgIH1cbiAgICAvLyBpbiB3aW5kb3cubG9jYXRpb24gJ3NlYXJjaCcgaXMgc3RyaW5nLCBub3Qgb2JqZWN0XG4gICAgdmFyIHFzQXNTdHJpbmcgPSBvcHRpb25zICYmICdkZWNvZGVTZWFyY2hBc1N0cmluZycgaW4gb3B0aW9ucyAmJiBvcHRpb25zLmRlY29kZVNlYXJjaEFzU3RyaW5nO1xuICAgIHJldHVybiB7XG4gICAgICAgIGhyZWY6IHBhcnNlZC5ocmVmLFxuICAgICAgICBwcm90b2NvbDogKHBhcnNlZC5wcm90b2NvbCB8fCAnJykucmVwbGFjZSgvOiQvLCAnJyksXG4gICAgICAgIGhvc3RuYW1lOiBwYXJzZWQuaG9zdG5hbWUsXG4gICAgICAgIHBvcnQ6ICtwYXJzZWQucG9ydCxcbiAgICAgICAgcGF0aG5hbWU6IHBhcnNlZC5wYXRobmFtZS5yZXBsYWNlKC9eKD8hXFwvKS8sICcvJyksXG4gICAgICAgIHNlYXJjaDogcXNBc1N0cmluZyA/IHBhcnNlZC5zZWFyY2ggOiBpbnRlcm5hbC5wYXJzZVFTKHBhcnNlZC5zZWFyY2ggfHwgJycpLFxuICAgICAgICBoYXNoOiAocGFyc2VkLmhhc2ggfHwgJycpLnJlcGxhY2UoL14jLywgJycpLFxuICAgICAgICBob3N0OiBwYXJzZWQuaG9zdCB8fCB3aW5kb3cubG9jYXRpb24uaG9zdFxuICAgIH07XG59XG5leHBvcnQgZnVuY3Rpb24gYnVpbGRVcmwob2JqKSB7XG4gICAgcmV0dXJuIChvYmoucHJvdG9jb2wgfHwgJ2h0dHAnKSArICc6Ly8nICsgKG9iai5ob3N0IHx8IG9iai5ob3N0bmFtZSArIChvYmoucG9ydCA/IFwiOlwiLmNvbmNhdChvYmoucG9ydCkgOiAnJykpICsgKG9iai5wYXRobmFtZSB8fCAnJykgKyAob2JqLnNlYXJjaCA/IFwiP1wiLmNvbmNhdChpbnRlcm5hbC5mb3JtYXRRUyhvYmouc2VhcmNoIHx8ICcnKSkgOiAnJykgKyAob2JqLmhhc2ggPyBcIiNcIi5jb25jYXQob2JqLmhhc2gpIDogJycpO1xufVxuLyoqXG4gKiBUaGlzIGZ1bmN0aW9uIGRlZXBseSBjb21wYXJlcyB0d28gb2JqZWN0cyBjaGVja2luZyBmb3IgdGhlaXIgZXF1aXZhbGVuY2UuXG4gKiBAcGFyYW0ge09iamVjdH0gb2JqMVxuICogQHBhcmFtIHtPYmplY3R9IG9iajJcbiAqIEBwYXJhbSB7T2JqZWN0fSBbb3B0aW9uc10gLSBPcHRpb25zIGZvciBjb21wYXJpc29uLlxuICogQHBhcmFtIHtib29sZWFufSBbb3B0aW9ucy5jaGVja1R5cGVzPWZhbHNlXSAtIElmIHNldCwgdHdvIG9iamVjdHMgd2l0aCBpZGVudGljYWwgcHJvcGVydGllcyBidXQgZGlmZmVyZW50IGNvbnN0cnVjdG9ycyB3aWxsICpub3QqIGJlIGNvbnNpZGVyZWQgZXF1aXZhbGVudC5cbiAqIEByZXR1cm5zIHtib29sZWFufSAtIFJldHVybnMgYHRydWVgIGlmIHRoZSBvYmplY3RzIGFyZSBlcXVpdmFsZW50LCBgZmFsc2VgIG90aGVyd2lzZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGRlZXBFcXVhbChvYmoxLCBvYmoyKSB7XG4gICAgdmFyIHsgY2hlY2tUeXBlcyA9IGZhbHNlIH0gPSBhcmd1bWVudHMubGVuZ3RoID4gMiAmJiBhcmd1bWVudHNbMl0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1syXSA6IHt9O1xuICAgIGlmIChvYmoxID09PSBvYmoyKVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICBlbHNlIGlmICh0eXBlb2Ygb2JqMSA9PT0gJ29iamVjdCcgJiYgb2JqMSAhPT0gbnVsbCAmJiB0eXBlb2Ygb2JqMiA9PT0gJ29iamVjdCcgJiYgb2JqMiAhPT0gbnVsbCAmJiAoIWNoZWNrVHlwZXMgfHwgb2JqMS5jb25zdHJ1Y3RvciA9PT0gb2JqMi5jb25zdHJ1Y3RvcikpIHtcbiAgICAgICAgdmFyIHByb3BzMSA9IE9iamVjdC5rZXlzKG9iajEpO1xuICAgICAgICBpZiAocHJvcHMxLmxlbmd0aCAhPT0gT2JqZWN0LmtleXMob2JqMikubGVuZ3RoKVxuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICBmb3IgKHZhciBwcm9wIG9mIHByb3BzMSkge1xuICAgICAgICAgICAgaWYgKG9iajIuaGFzT3duUHJvcGVydHkocHJvcCkpIHtcbiAgICAgICAgICAgICAgICBpZiAoIWRlZXBFcXVhbChvYmoxW3Byb3BdLCBvYmoyW3Byb3BdLCB7XG4gICAgICAgICAgICAgICAgICAgIGNoZWNrVHlwZXNcbiAgICAgICAgICAgICAgICB9KSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBlbHNlIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbn1cbmV4cG9ydCBmdW5jdGlvbiBtZXJnZURlZXAodGFyZ2V0KSB7XG4gICAgZm9yICh2YXIgX2xlbjIgPSBhcmd1bWVudHMubGVuZ3RoLCBzb3VyY2VzID0gbmV3IEFycmF5KF9sZW4yID4gMSA/IF9sZW4yIC0gMSA6IDApLCBfa2V5MiA9IDE7IF9rZXkyIDwgX2xlbjI7IF9rZXkyKyspIHtcbiAgICAgICAgc291cmNlc1tfa2V5MiAtIDFdID0gYXJndW1lbnRzW19rZXkyXTtcbiAgICB9XG4gICAgaWYgKCFzb3VyY2VzLmxlbmd0aClcbiAgICAgICAgcmV0dXJuIHRhcmdldDtcbiAgICB2YXIgc291cmNlID0gc291cmNlcy5zaGlmdCgpO1xuICAgIGlmIChpc1BsYWluT2JqZWN0KHRhcmdldCkgJiYgaXNQbGFpbk9iamVjdChzb3VyY2UpKSB7XG4gICAgICAgIHZhciBfbG9vcCA9IGZ1bmN0aW9uIChrZXkpIHtcbiAgICAgICAgICAgIGlmIChpc1BsYWluT2JqZWN0KHNvdXJjZVtrZXldKSkge1xuICAgICAgICAgICAgICAgIGlmICghdGFyZ2V0W2tleV0pXG4gICAgICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24odGFyZ2V0LCB7XG4gICAgICAgICAgICAgICAgICAgICAgICBba2V5XToge31cbiAgICAgICAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgICAgbWVyZ2VEZWVwKHRhcmdldFtrZXldLCBzb3VyY2Vba2V5XSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChpc0FycmF5KHNvdXJjZVtrZXldKSkge1xuICAgICAgICAgICAgICAgIGlmICghdGFyZ2V0W2tleV0pIHtcbiAgICAgICAgICAgICAgICAgICAgT2JqZWN0LmFzc2lnbih0YXJnZXQsIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIFtrZXldOiBbLi4uc291cmNlW2tleV1dXG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChpc0FycmF5KHRhcmdldFtrZXldKSkge1xuICAgICAgICAgICAgICAgICAgICBzb3VyY2Vba2V5XS5mb3JFYWNoKG9iaiA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICB2YXIgYWRkSXRGbGFnID0gMTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGZvciAodmFyIGkgPSAwOyBpIDwgdGFyZ2V0W2tleV0ubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBpZiAoZGVlcEVxdWFsKHRhcmdldFtrZXldW2ldLCBvYmopKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGFkZEl0RmxhZyA9IDA7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgICAgIGlmIChhZGRJdEZsYWcpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0YXJnZXRba2V5XS5wdXNoKG9iaik7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIE9iamVjdC5hc3NpZ24odGFyZ2V0LCB7XG4gICAgICAgICAgICAgICAgICAgIFtrZXldOiBzb3VyY2Vba2V5XVxuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgICBmb3IgKHZhciBrZXkgaW4gc291cmNlKSB7XG4gICAgICAgICAgICBfbG9vcChrZXkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBtZXJnZURlZXAodGFyZ2V0LCAuLi5zb3VyY2VzKTtcbn1cbi8qKlxuICogcmV0dXJucyBhIGhhc2ggb2YgYSBzdHJpbmcgdXNpbmcgYSBmYXN0IGFsZ29yaXRobVxuICogc291cmNlOiBodHRwczovL3N0YWNrb3ZlcmZsb3cuY29tL2EvNTIxNzE0ODAvODQ1MzkwXG4gKiBAcGFyYW0gc3RyXG4gKiBAcGFyYW0gc2VlZCAob3B0aW9uYWwpXG4gKiBAcmV0dXJucyB7c3RyaW5nfVxuICovXG5leHBvcnQgZnVuY3Rpb24gY3lyYjUzSGFzaChzdHIpIHtcbiAgICB2YXIgc2VlZCA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogMDtcbiAgICAvLyBJRSBkb2Vzbid0IHN1cHBvcnQgaW11bFxuICAgIC8vIGh0dHBzOi8vZGV2ZWxvcGVyLm1vemlsbGEub3JnL2VuLVVTL2RvY3MvV2ViL0phdmFTY3JpcHQvUmVmZXJlbmNlL0dsb2JhbF9PYmplY3RzL01hdGgvaW11bCNQb2x5ZmlsbFxuICAgIHZhciBpbXVsID0gZnVuY3Rpb24gKG9wQSwgb3BCKSB7XG4gICAgICAgIGlmIChpc0ZuKE1hdGguaW11bCkpIHtcbiAgICAgICAgICAgIHJldHVybiBNYXRoLmltdWwob3BBLCBvcEIpO1xuICAgICAgICB9XG4gICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgb3BCIHw9IDA7IC8vIGVuc3VyZSB0aGF0IG9wQiBpcyBhbiBpbnRlZ2VyLiBvcEEgd2lsbCBhdXRvbWF0aWNhbGx5IGJlIGNvZXJjZWQuXG4gICAgICAgICAgICAvLyBmbG9hdGluZyBwb2ludHMgZ2l2ZSB1cyA1MyBiaXRzIG9mIHByZWNpc2lvbiB0byB3b3JrIHdpdGggcGx1cyAxIHNpZ24gYml0XG4gICAgICAgICAgICAvLyBhdXRvbWF0aWNhbGx5IGhhbmRsZWQgZm9yIG91ciBjb252aWVuZW5jZTpcbiAgICAgICAgICAgIC8vIDEuIDB4MDAzZmZmZmYgLypvcEEgJiAweDAwMGZmZmZmKi8gKiAweDdmZmZmZmZmIC8qb3BCKi8gPSAweDFmZmZmZjdmYzAwMDAxXG4gICAgICAgICAgICAvLyAgICAweDFmZmZmZjdmYzAwMDAxIDwgTnVtYmVyLk1BWF9TQUZFX0lOVEVHRVIgLyoweDFmZmZmZmZmZmZmZmZmKi9cbiAgICAgICAgICAgIHZhciByZXN1bHQgPSAob3BBICYgMHgwMDNmZmZmZikgKiBvcEI7XG4gICAgICAgICAgICAvLyAyLiBXZSBjYW4gcmVtb3ZlIGFuIGludGVnZXIgY29lcnNpb24gZnJvbSB0aGUgc3RhdGVtZW50IGFib3ZlIGJlY2F1c2U6XG4gICAgICAgICAgICAvLyAgICAweDFmZmZmZjdmYzAwMDAxICsgMHhmZmMwMDAwMCA9IDB4MWZmZmZmZmY4MDAwMDFcbiAgICAgICAgICAgIC8vICAgIDB4MWZmZmZmZmY4MDAwMDEgPCBOdW1iZXIuTUFYX1NBRkVfSU5URUdFUiAvKjB4MWZmZmZmZmZmZmZmZmYqL1xuICAgICAgICAgICAgaWYgKG9wQSAmIDB4ZmZjMDAwMDApXG4gICAgICAgICAgICAgICAgcmVzdWx0ICs9IChvcEEgJiAweGZmYzAwMDAwKSAqIG9wQiB8IDA7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0IHwgMDtcbiAgICAgICAgfVxuICAgIH07XG4gICAgdmFyIGgxID0gMHhkZWFkYmVlZiBeIHNlZWQ7XG4gICAgdmFyIGgyID0gMHg0MWM2Y2U1NyBeIHNlZWQ7XG4gICAgZm9yICh2YXIgaSA9IDAsIGNoOyBpIDwgc3RyLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIGNoID0gc3RyLmNoYXJDb2RlQXQoaSk7XG4gICAgICAgIGgxID0gaW11bChoMSBeIGNoLCAyNjU0NDM1NzYxKTtcbiAgICAgICAgaDIgPSBpbXVsKGgyIF4gY2gsIDE1OTczMzQ2NzcpO1xuICAgIH1cbiAgICBoMSA9IGltdWwoaDEgXiBoMSA+Pj4gMTYsIDIyNDY4MjI1MDcpIF4gaW11bChoMiBeIGgyID4+PiAxMywgMzI2NjQ4OTkwOSk7XG4gICAgaDIgPSBpbXVsKGgyIF4gaDIgPj4+IDE2LCAyMjQ2ODIyNTA3KSBeIGltdWwoaDEgXiBoMSA+Pj4gMTMsIDMyNjY0ODk5MDkpO1xuICAgIHJldHVybiAoNDI5NDk2NzI5NiAqICgyMDk3MTUxICYgaDIpICsgKGgxID4+PiAwKSkudG9TdHJpbmcoKTtcbn1cbi8qKlxuICogcmV0dXJucyB0aGUgcmVzdWx0IG9mIGBKU09OLnBhcnNlKGRhdGEpYCwgb3IgdW5kZWZpbmVkIGlmIHRoYXQgdGhyb3dzIGFuIGVycm9yLlxuICogQHBhcmFtIGRhdGFcbiAqIEByZXR1cm5zIHthbnl9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBzYWZlSlNPTlBhcnNlKGRhdGEpIHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5wYXJzZShkYXRhKTtcbiAgICB9XG4gICAgY2F0Y2ggKGUpIHsgfVxufVxuZXhwb3J0IGZ1bmN0aW9uIHNhZmVKU09ORW5jb2RlKGRhdGEpIHtcbiAgICB0cnkge1xuICAgICAgICByZXR1cm4gSlNPTi5zdHJpbmdpZnkoZGF0YSk7XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIHJldHVybiAnJztcbiAgICB9XG59XG4vKipcbiAqIFJldHVybnMgYSBtZW1vaXplZCB2ZXJzaW9uIG9mIGBmbmAuXG4gKlxuICogQHBhcmFtIGZuXG4gKiBAcGFyYW0ga2V5IGNhY2hlIGtleSBnZW5lcmF0b3IsIGludm9rZWQgd2l0aCB0aGUgc2FtZSBhcmd1bWVudHMgcGFzc2VkIHRvIGBmbmAuXG4gKiAgICAgICAgQnkgZGVmYXVsdCwgdGhlIGZpcnN0IGFyZ3VtZW50IGlzIHVzZWQgYXMga2V5LlxuICogQHJldHVybiB7ZnVuY3Rpb24oKTogYW55fVxuICovXG5leHBvcnQgZnVuY3Rpb24gbWVtb2l6ZShmbikge1xuICAgIHZhciBrZXkgPSBhcmd1bWVudHMubGVuZ3RoID4gMSAmJiBhcmd1bWVudHNbMV0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1sxXSA6IGZ1bmN0aW9uIChhcmcpIHtcbiAgICAgICAgcmV0dXJuIGFyZztcbiAgICB9O1xuICAgIHZhciBjYWNoZSA9IG5ldyBNYXAoKTtcbiAgICB2YXIgbWVtb2l6ZWQgPSBmdW5jdGlvbiAoKSB7XG4gICAgICAgIHZhciBjYWNoZUtleSA9IGtleS5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xuICAgICAgICBpZiAoIWNhY2hlLmhhcyhjYWNoZUtleSkpIHtcbiAgICAgICAgICAgIGNhY2hlLnNldChjYWNoZUtleSwgZm4uYXBwbHkodGhpcywgYXJndW1lbnRzKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNhY2hlLmdldChjYWNoZUtleSk7XG4gICAgfTtcbiAgICBtZW1vaXplZC5jbGVhciA9IGNhY2hlLmNsZWFyLmJpbmQoY2FjaGUpO1xuICAgIHJldHVybiBtZW1vaXplZDtcbn1cbi8qKlxuICogUmV0dXJucyBhIFVuaXggdGltZXN0YW1wIGZvciBnaXZlbiB0aW1lIHZhbHVlIGFuZCB1bml0LlxuICogQHBhcmFtIHtudW1iZXJ9IHRpbWVWYWx1ZSBudW1lcmljIHZhbHVlLCBkZWZhdWx0cyB0byAwICh3aGljaCBtZWFucyBub3cpXG4gKiBAcGFyYW0ge3N0cmluZ30gdGltZVVuaXQgZGVmYXVsdHMgdG8gZGF5cyAob3IgJ2QnKSwgdXNlICdtJyBmb3IgbWludXRlcy4gQW55IHBhcmFtZXRlciB0aGF0IGlzbid0ICdkJyBvciAnbScgd2lsbCByZXR1cm4gRGF0ZS5ub3coKS5cbiAqIEByZXR1cm5zIHtudW1iZXJ9XG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBnZXRVbml4VGltZXN0YW1wRnJvbU5vdygpIHtcbiAgICB2YXIgdGltZVZhbHVlID0gYXJndW1lbnRzLmxlbmd0aCA+IDAgJiYgYXJndW1lbnRzWzBdICE9PSB1bmRlZmluZWQgPyBhcmd1bWVudHNbMF0gOiAwO1xuICAgIHZhciB0aW1lVW5pdCA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogJ2QnO1xuICAgIHZhciBhY2NlcHRhYmxlVW5pdHMgPSBbJ20nLCAnZCddO1xuICAgIGlmIChhY2NlcHRhYmxlVW5pdHMuaW5kZXhPZih0aW1lVW5pdCkgPCAwKSB7XG4gICAgICAgIHJldHVybiBEYXRlLm5vdygpO1xuICAgIH1cbiAgICB2YXIgbXVsdGlwbGljYXRpb24gPSB0aW1lVmFsdWUgLyAodGltZVVuaXQgPT09ICdtJyA/IDE0NDAgOiAxKTtcbiAgICByZXR1cm4gRGF0ZS5ub3coKSArICh0aW1lVmFsdWUgJiYgdGltZVZhbHVlID4gMCA/IDEwMDAgKiA2MCAqIDYwICogMjQgKiBtdWx0aXBsaWNhdGlvbiA6IDApO1xufVxuLyoqXG4gKiBDb252ZXJ0cyBnaXZlbiBvYmplY3QgaW50byBhbiBhcnJheSwgc28ge2tleTogMSwgYW5vdGhlcktleTogJ2ZyZWQnLCB0aGlyZDogWydmcmVkJ119IGlzIHR1cm5lZFxuICogaW50byBbe2tleTogMX0sIHthbm90aGVyS2V5OiAnZnJlZCd9LCB7dGhpcmQ6IFsnZnJlZCddfV1cbiAqIEBwYXJhbSB7T2JqZWN0fSBvYmogdGhlIG9iamVjdFxuICogQHJldHVybnMge0FycmF5fVxuICovXG5leHBvcnQgZnVuY3Rpb24gY29udmVydE9iamVjdFRvQXJyYXkob2JqKSB7XG4gICAgcmV0dXJuIE9iamVjdC5rZXlzKG9iaikubWFwKGtleSA9PiB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICBba2V5XTogb2JqW2tleV1cbiAgICAgICAgfTtcbiAgICB9KTtcbn1cbi8qKlxuICogU2V0cyBkYXRhc2V0IGF0dHJpYnV0ZXMgb24gYSBzY3JpcHRcbiAqIEBwYXJhbSB7SFRNTFNjcmlwdEVsZW1lbnR9IHNjcmlwdFxuICogQHBhcmFtIHtvYmplY3R9IGF0dHJpYnV0ZXNcbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldFNjcmlwdEF0dHJpYnV0ZXMoc2NyaXB0LCBhdHRyaWJ1dGVzKSB7XG4gICAgT2JqZWN0LmVudHJpZXMoYXR0cmlidXRlcykuZm9yRWFjaChfcmVmNiA9PiB7XG4gICAgICAgIHZhciBbaywgdl0gPSBfcmVmNjtcbiAgICAgICAgcmV0dXJuIHNjcmlwdC5zZXRBdHRyaWJ1dGUoaywgdik7XG4gICAgfSk7XG59XG4vKipcbiAqIFBlcmZvcm0gYSBiaW5hcnkgc2VhcmNoIGZvciBgZWxgIG9uIGFuIG9yZGVyZWQgYXJyYXkgYGFycmAuXG4gKlxuICogQHJldHVybnMgdGhlIGxvd2VzdCBub25uZWdhdGl2ZSBpbnRlZ2VyIEkgdGhhdCBzYXRpc2ZpZXM6XG4gKiAgIGtleShhcnJbaV0pID49IGtleShlbCkgZm9yIGVhY2ggaSBiZXR3ZWVuIEkgYW5kIGFyci5sZW5ndGhcbiAqXG4gKiAgIChpZiBvbmUgb3IgbW9yZSBtYXRjaGVzIGFyZSBmb3VuZCBmb3IgYGVsYCwgcmV0dXJucyB0aGUgaW5kZXggb2YgdGhlIGZpcnN0O1xuICogICBpZiB0aGUgZWxlbWVudCBpcyBub3QgZm91bmQsIHJldHVybiB0aGUgaW5kZXggb2YgdGhlIGZpcnN0IGVsZW1lbnQgdGhhdCdzIGdyZWF0ZXI7XG4gKiAgIGlmIG5vIGdyZWF0ZXIgZWxlbWVudCBleGlzdHMsIHJldHVybiBgYXJyLmxlbmd0aGApXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBiaW5hcnlTZWFyY2goYXJyLCBlbCkge1xuICAgIHZhciBrZXkgPSBhcmd1bWVudHMubGVuZ3RoID4gMiAmJiBhcmd1bWVudHNbMl0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1syXSA6IGVsID0+IGVsO1xuICAgIHZhciBsZWZ0ID0gMDtcbiAgICB2YXIgcmlnaHQgPSBhcnIubGVuZ3RoICYmIGFyci5sZW5ndGggLSAxO1xuICAgIHZhciB0YXJnZXQgPSBrZXkoZWwpO1xuICAgIHdoaWxlIChyaWdodCAtIGxlZnQgPiAxKSB7XG4gICAgICAgIHZhciBtaWRkbGUgPSBsZWZ0ICsgTWF0aC5yb3VuZCgocmlnaHQgLSBsZWZ0KSAvIDIpO1xuICAgICAgICBpZiAodGFyZ2V0ID4ga2V5KGFyclttaWRkbGVdKSkge1xuICAgICAgICAgICAgbGVmdCA9IG1pZGRsZTtcbiAgICAgICAgfVxuICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgIHJpZ2h0ID0gbWlkZGxlO1xuICAgICAgICB9XG4gICAgfVxuICAgIHdoaWxlIChhcnIubGVuZ3RoID4gbGVmdCAmJiB0YXJnZXQgPiBrZXkoYXJyW2xlZnRdKSkge1xuICAgICAgICBsZWZ0Kys7XG4gICAgfVxuICAgIHJldHVybiBsZWZ0O1xufVxuLyoqXG4gKiBDaGVja3MgaWYgYW4gb2JqZWN0IGhhcyBub24tc2VyaWFsaXphYmxlIHByb3BlcnRpZXMuXG4gKiBOb24tc2VyaWFsaXphYmxlIHByb3BlcnRpZXMgYXJlIGZ1bmN0aW9ucyBhbmQgUmVnRXhwIG9iamVjdHMuXG4gKlxuICogQHBhcmFtIHtPYmplY3R9IG9iaiAtIFRoZSBvYmplY3QgdG8gY2hlY2suXG4gKiBAcGFyYW0ge1NldH0gY2hlY2tlZE9iamVjdHMgLSBBIHNldCBvZiBwcm9wZXJ0aWVzIHRoYXQgaGF2ZSBhbHJlYWR5IGJlZW4gY2hlY2tlZC5cbiAqIEByZXR1cm5zIHtib29sZWFufSAtIFJldHVybnMgdHJ1ZSBpZiB0aGUgb2JqZWN0IGhhcyBub24tc2VyaWFsaXphYmxlIHByb3BlcnRpZXMsIGZhbHNlIG90aGVyd2lzZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIGhhc05vblNlcmlhbGl6YWJsZVByb3BlcnR5KG9iaikge1xuICAgIHZhciBjaGVja2VkT2JqZWN0cyA9IGFyZ3VtZW50cy5sZW5ndGggPiAxICYmIGFyZ3VtZW50c1sxXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzFdIDogbmV3IFNldCgpO1xuICAgIGZvciAodmFyIGtleSBpbiBvYmopIHtcbiAgICAgICAgdmFyIHZhbHVlID0gb2JqW2tleV07XG4gICAgICAgIHZhciB0eXBlID0gdHlwZW9mIHZhbHVlO1xuICAgICAgICBpZiAodmFsdWUgPT09IHVuZGVmaW5lZCB8fCB0eXBlID09PSAnZnVuY3Rpb24nIHx8IHR5cGUgPT09ICdzeW1ib2wnIHx8IHZhbHVlIGluc3RhbmNlb2YgUmVnRXhwIHx8IHZhbHVlIGluc3RhbmNlb2YgTWFwIHx8IHZhbHVlIGluc3RhbmNlb2YgU2V0IHx8IHZhbHVlIGluc3RhbmNlb2YgRGF0ZSB8fCB2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlID09PSAnb2JqZWN0JyAmJiB2YWx1ZS5oYXNPd25Qcm9wZXJ0eSgndG9KU09OJykpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmICh2YWx1ZSAhPT0gbnVsbCAmJiB0eXBlID09PSAnb2JqZWN0JyAmJiB2YWx1ZS5jb25zdHJ1Y3RvciA9PT0gT2JqZWN0KSB7XG4gICAgICAgICAgICBpZiAoY2hlY2tlZE9iamVjdHMuaGFzKHZhbHVlKSkge1xuICAgICAgICAgICAgICAgIC8vIGNpcmN1bGFyIHJlZmVyZW5jZSwgbWVhbnMgd2UgaGF2ZSBhIG5vbi1zZXJpYWxpemFibGUgcHJvcGVydHlcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNoZWNrZWRPYmplY3RzLmFkZCh2YWx1ZSk7XG4gICAgICAgICAgICBpZiAoaGFzTm9uU2VyaWFsaXphYmxlUHJvcGVydHkodmFsdWUsIGNoZWNrZWRPYmplY3RzKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIHJldHVybiBmYWxzZTtcbn1cbi8qKlxuICogUmV0dXJucyB0aGUgdmFsdWUgb2YgYSBuZXN0ZWQgcHJvcGVydHkgaW4gYW4gYXJyYXkgb2Ygb2JqZWN0cy5cbiAqXG4gKiBAcGFyYW0ge0FycmF5fSBjb2xsZWN0aW9uIC0gQXJyYXkgb2Ygb2JqZWN0cy5cbiAqIEBwYXJhbSB7U3RyaW5nfSBrZXkgLSBLZXkgb2YgbmVzdGVkIHByb3BlcnR5LlxuICogQHJldHVybnMge2FueSwgdW5kZWZpbmVkfSAtIFZhbHVlIG9mIG5lc3RlZCBwcm9wZXJ0eS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIHNldE9uQW55KGNvbGxlY3Rpb24sIGtleSkge1xuICAgIGZvciAodmFyIGkgPSAwLCByZXN1bHQ7IGkgPCBjb2xsZWN0aW9uLmxlbmd0aDsgaSsrKSB7XG4gICAgICAgIHJlc3VsdCA9IGRlZXBBY2Nlc3MoY29sbGVjdGlvbltpXSwga2V5KTtcbiAgICAgICAgaWYgKHJlc3VsdCkge1xuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkO1xufVxuZXhwb3J0IGZ1bmN0aW9uIGV4dHJhY3REb21haW5Gcm9tSG9zdChwYWdlSG9zdCkge1xuICAgIHZhciBkb21haW4gPSBudWxsO1xuICAgIHRyeSB7XG4gICAgICAgIHZhciBkb21haW5zID0gL1stXFx3XStcXC4oWy1cXHddK3xbLVxcd117Myx9fFstXFx3XXsxLDN9XFwuWy1cXHddezJ9KSQvaS5leGVjKHBhZ2VIb3N0KTtcbiAgICAgICAgaWYgKGRvbWFpbnMgIT0gbnVsbCAmJiBkb21haW5zLmxlbmd0aCA+IDApIHtcbiAgICAgICAgICAgIGRvbWFpbiA9IGRvbWFpbnNbMF07XG4gICAgICAgICAgICBmb3IgKHZhciBpID0gMTsgaSA8IGRvbWFpbnMubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgICAgICBpZiAoZG9tYWluc1tpXS5sZW5ndGggPiBkb21haW4ubGVuZ3RoKSB7XG4gICAgICAgICAgICAgICAgICAgIGRvbWFpbiA9IGRvbWFpbnNbaV07XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIGNhdGNoIChlKSB7XG4gICAgICAgIGRvbWFpbiA9IG51bGw7XG4gICAgfVxuICAgIHJldHVybiBkb21haW47XG59XG5leHBvcnQgZnVuY3Rpb24gdHJpZ2dlck51cmxXaXRoQ3BtKGJpZCwgY3BtKSB7XG4gICAgaWYgKGlzU3RyKGJpZC5udXJsKSAmJiBiaWQubnVybCAhPT0gJycpIHtcbiAgICAgICAgYmlkLm51cmwgPSBiaWQubnVybC5yZXBsYWNlKC9cXCR7QVVDVElPTl9QUklDRX0vLCBjcG0pO1xuICAgICAgICB0cmlnZ2VyUGl4ZWwoYmlkLm51cmwpO1xuICAgIH1cbn1cbiIsImZ1bmN0aW9uIF9jbGFzc1ByaXZhdGVGaWVsZEluaXRTcGVjKGUsIHQsIGEpIHsgX2NoZWNrUHJpdmF0ZVJlZGVjbGFyYXRpb24oZSwgdCksIHQuc2V0KGUsIGEpOyB9XG5mdW5jdGlvbiBfY2hlY2tQcml2YXRlUmVkZWNsYXJhdGlvbihlLCB0KSB7IGlmICh0LmhhcyhlKSlcbiAgICB0aHJvdyBuZXcgVHlwZUVycm9yKFwiQ2Fubm90IGluaXRpYWxpemUgdGhlIHNhbWUgcHJpdmF0ZSBlbGVtZW50cyB0d2ljZSBvbiBhbiBvYmplY3RcIik7IH1cbmZ1bmN0aW9uIF9jbGFzc1ByaXZhdGVGaWVsZEdldChzLCBhKSB7IHJldHVybiBzLmdldChfYXNzZXJ0Q2xhc3NCcmFuZChzLCBhKSk7IH1cbmZ1bmN0aW9uIF9jbGFzc1ByaXZhdGVGaWVsZFNldChzLCBhLCByKSB7IHJldHVybiBzLnNldChfYXNzZXJ0Q2xhc3NCcmFuZChzLCBhKSwgciksIHI7IH1cbmZ1bmN0aW9uIF9hc3NlcnRDbGFzc0JyYW5kKGUsIHQsIG4pIHsgaWYgKFwiZnVuY3Rpb25cIiA9PSB0eXBlb2YgZSA/IGUgPT09IHQgOiBlLmhhcyh0KSlcbiAgICByZXR1cm4gYXJndW1lbnRzLmxlbmd0aCA8IDMgPyB0IDogbjsgdGhyb3cgbmV3IFR5cGVFcnJvcihcIlByaXZhdGUgZWxlbWVudCBpcyBub3QgcHJlc2VudCBvbiB0aGlzIG9iamVjdFwiKTsgfVxudmFyIFNVQ0NFU1MgPSAwO1xudmFyIEZBSUwgPSAxO1xuLyoqXG4gKiBBIHZlcnNpb24gb2YgUHJvbWlzZSB0aGF0IHJ1bnMgY2FsbGJhY2tzIHN5bmNocm9ub3VzbHkgd2hlbiBpdCBjYW4gKGkuZS4gYWZ0ZXIgaXQncyBiZWVuIGZ1bGZpbGxlZCBvciByZWplY3RlZCkuXG4gKi9cbnZhciBfcmVzdWx0ID0gLyojX19QVVJFX18qLyBuZXcgV2Vha01hcCgpO1xudmFyIF9jYWxsYmFja3MgPSAvKiNfX1BVUkVfXyovIG5ldyBXZWFrTWFwKCk7XG5leHBvcnQgY2xhc3MgR3JlZWR5UHJvbWlzZSB7XG4gICAgLyoqXG4gICAgICogQ29udmVuaWVuY2Ugd3JhcHBlciBmb3Igc2V0VGltZW91dDsgdGFrZXMgY2FyZSBvZiByZXR1cm5pbmcgYW4gYWxyZWFkeSBmdWxmaWxsZWQgR3JlZWR5UHJvbWlzZSB3aGVuIHRoZSBkZWxheSBpcyB6ZXJvLlxuICAgICAqXG4gICAgICogQHBhcmFtIHtOdW1iZXJ9IGRlbGF5TXMgZGVsYXkgaW4gbWlsbGlzZWNvbmRzXG4gICAgICogQHJldHVybnMge0dyZWVkeVByb21pc2V9IGEgcHJvbWlzZSB0aGF0IHJlc29sdmVzICh0byB1bmRlZmluZWQpIGluIGBkZWxheU1zYCBtaWxsaXNlY29uZHNcbiAgICAgKi9cbiAgICBzdGF0aWMgdGltZW91dCgpIHtcbiAgICAgICAgdmFyIGRlbGF5TXMgPSBhcmd1bWVudHMubGVuZ3RoID4gMCAmJiBhcmd1bWVudHNbMF0gIT09IHVuZGVmaW5lZCA/IGFyZ3VtZW50c1swXSA6IDA7XG4gICAgICAgIHJldHVybiBuZXcgR3JlZWR5UHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgICAgICAgIGRlbGF5TXMgPT09IDAgPyByZXNvbHZlKCkgOiBzZXRUaW1lb3V0KHJlc29sdmUsIGRlbGF5TXMpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgY29uc3RydWN0b3IocmVzb2x2ZXIpIHtcbiAgICAgICAgX2NsYXNzUHJpdmF0ZUZpZWxkSW5pdFNwZWModGhpcywgX3Jlc3VsdCwgdm9pZCAwKTtcbiAgICAgICAgX2NsYXNzUHJpdmF0ZUZpZWxkSW5pdFNwZWModGhpcywgX2NhbGxiYWNrcywgdm9pZCAwKTtcbiAgICAgICAgaWYgKHR5cGVvZiByZXNvbHZlciAhPT0gJ2Z1bmN0aW9uJykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdyZXNvbHZlciBub3QgYSBmdW5jdGlvbicpO1xuICAgICAgICB9XG4gICAgICAgIHZhciByZXN1bHQgPSBbXTtcbiAgICAgICAgdmFyIGNhbGxiYWNrcyA9IFtdO1xuICAgICAgICB2YXIgW3Jlc29sdmUsIHJlamVjdF0gPSBbU1VDQ0VTUywgRkFJTF0ubWFwKHR5cGUgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIGZ1bmN0aW9uICh2YWx1ZSkge1xuICAgICAgICAgICAgICAgIGlmICh0eXBlID09PSBTVUNDRVNTICYmIHR5cGVvZiAodmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHZvaWQgMCA/IHZvaWQgMCA6IHZhbHVlLnRoZW4pID09PSAnZnVuY3Rpb24nKSB7XG4gICAgICAgICAgICAgICAgICAgIHZhbHVlLnRoZW4ocmVzb2x2ZSwgcmVqZWN0KTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgZWxzZSBpZiAoIXJlc3VsdC5sZW5ndGgpIHtcbiAgICAgICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godHlwZSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICB3aGlsZSAoY2FsbGJhY2tzLmxlbmd0aClcbiAgICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrcy5zaGlmdCgpKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfTtcbiAgICAgICAgfSk7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXNvbHZlcihyZXNvbHZlLCByZWplY3QpO1xuICAgICAgICB9XG4gICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICByZWplY3QoZSk7XG4gICAgICAgIH1cbiAgICAgICAgX2NsYXNzUHJpdmF0ZUZpZWxkU2V0KF9yZXN1bHQsIHRoaXMsIHJlc3VsdCk7XG4gICAgICAgIF9jbGFzc1ByaXZhdGVGaWVsZFNldChfY2FsbGJhY2tzLCB0aGlzLCBjYWxsYmFja3MpO1xuICAgIH1cbiAgICB0aGVuKG9uU3VjY2Vzcywgb25FcnJvcikge1xuICAgICAgICB2YXIgcmVzdWx0ID0gX2NsYXNzUHJpdmF0ZUZpZWxkR2V0KF9yZXN1bHQsIHRoaXMpO1xuICAgICAgICByZXR1cm4gbmV3IHRoaXMuY29uc3RydWN0b3IoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgdmFyIGNvbnRpbnVhdGlvbiA9ICgpID0+IHtcbiAgICAgICAgICAgICAgICB2YXIgdmFsdWUgPSByZXN1bHRbMV07XG4gICAgICAgICAgICAgICAgdmFyIFtoYW5kbGVyLCByZXNvbHZlRm5dID0gcmVzdWx0WzBdID09PSBTVUNDRVNTID8gW29uU3VjY2VzcywgcmVzb2x2ZV0gOiBbb25FcnJvciwgcmVqZWN0XTtcbiAgICAgICAgICAgICAgICBpZiAodHlwZW9mIGhhbmRsZXIgPT09ICdmdW5jdGlvbicpIHtcbiAgICAgICAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHZhbHVlID0gaGFuZGxlcih2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXNvbHZlRm4gPSByZXNvbHZlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXNvbHZlRm4odmFsdWUpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHJlc3VsdC5sZW5ndGggPyBjb250aW51YXRpb24oKSA6IF9jbGFzc1ByaXZhdGVGaWVsZEdldChfY2FsbGJhY2tzLCB0aGlzKS5wdXNoKGNvbnRpbnVhdGlvbik7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBjYXRjaChvbkVycm9yKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRoZW4obnVsbCwgb25FcnJvcik7XG4gICAgfVxuICAgIGZpbmFsbHkob25GaW5hbGx5KSB7XG4gICAgICAgIHZhciB2YWw7XG4gICAgICAgIHJldHVybiB0aGlzLnRoZW4odiA9PiB7XG4gICAgICAgICAgICB2YWwgPSB2O1xuICAgICAgICAgICAgcmV0dXJuIG9uRmluYWxseSgpO1xuICAgICAgICB9LCBlID0+IHtcbiAgICAgICAgICAgIHZhbCA9IHRoaXMuY29uc3RydWN0b3IucmVqZWN0KGUpO1xuICAgICAgICAgICAgcmV0dXJuIG9uRmluYWxseSgpO1xuICAgICAgICB9KS50aGVuKCgpID0+IHZhbCk7XG4gICAgfVxuICAgIHN0YXRpYyByYWNlKHByb21pc2VzKSB7XG4gICAgICAgIHJldHVybiBuZXcgdGhpcygocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBfYXNzZXJ0Q2xhc3NCcmFuZChHcmVlZHlQcm9taXNlLCB0aGlzLCBfY29sbGVjdCkuY2FsbCh0aGlzLCBwcm9taXNlcywgKHN1Y2Nlc3MsIHJlc3VsdCkgPT4gc3VjY2VzcyA/IHJlc29sdmUocmVzdWx0KSA6IHJlamVjdChyZXN1bHQpKTtcbiAgICAgICAgfSk7XG4gICAgfVxuICAgIHN0YXRpYyBhbGwocHJvbWlzZXMpIHtcbiAgICAgICAgcmV0dXJuIG5ldyB0aGlzKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHZhciByZXMgPSBbXTtcbiAgICAgICAgICAgIF9hc3NlcnRDbGFzc0JyYW5kKEdyZWVkeVByb21pc2UsIHRoaXMsIF9jb2xsZWN0KS5jYWxsKHRoaXMsIHByb21pc2VzLCAoc3VjY2VzcywgdmFsLCBpKSA9PiBzdWNjZXNzID8gcmVzW2ldID0gdmFsIDogcmVqZWN0KHZhbCksICgpID0+IHJlc29sdmUocmVzKSk7XG4gICAgICAgIH0pO1xuICAgIH1cbiAgICBzdGF0aWMgYWxsU2V0dGxlZChwcm9taXNlcykge1xuICAgICAgICByZXR1cm4gbmV3IHRoaXMocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgICB2YXIgcmVzID0gW107XG4gICAgICAgICAgICBfYXNzZXJ0Q2xhc3NCcmFuZChHcmVlZHlQcm9taXNlLCB0aGlzLCBfY29sbGVjdCkuY2FsbCh0aGlzLCBwcm9taXNlcywgKHN1Y2Nlc3MsIHZhbCwgaSkgPT4gcmVzW2ldID0gc3VjY2VzcyA/IHtcbiAgICAgICAgICAgICAgICBzdGF0dXM6ICdmdWxmaWxsZWQnLFxuICAgICAgICAgICAgICAgIHZhbHVlOiB2YWxcbiAgICAgICAgICAgIH0gOiB7XG4gICAgICAgICAgICAgICAgc3RhdHVzOiAncmVqZWN0ZWQnLFxuICAgICAgICAgICAgICAgIHJlYXNvbjogdmFsXG4gICAgICAgICAgICB9LCAoKSA9PiByZXNvbHZlKHJlcykpO1xuICAgICAgICB9KTtcbiAgICB9XG4gICAgc3RhdGljIHJlc29sdmUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyB0aGlzKHJlc29sdmUgPT4gcmVzb2x2ZSh2YWx1ZSkpO1xuICAgIH1cbiAgICBzdGF0aWMgcmVqZWN0KGVycm9yKSB7XG4gICAgICAgIHJldHVybiBuZXcgdGhpcygocmVzb2x2ZSwgcmVqZWN0KSA9PiByZWplY3QoZXJyb3IpKTtcbiAgICB9XG59XG4vKipcbiAqIEByZXR1cm5zIGEge3Byb21pc2UsIHJlc29sdmUsIHJlamVjdH0gdHJpbyB3aGVyZSBgcHJvbWlzZWAgaXMgcmVzb2x2ZWQgYnkgY2FsbGluZyBgcmVzb2x2ZWAgb3IgYHJlamVjdGAuXG4gKi9cbmZ1bmN0aW9uIF9jb2xsZWN0KHByb21pc2VzLCBjb2xsZWN0b3IsIGRvbmUpIHtcbiAgICB2YXIgY250ID0gcHJvbWlzZXMubGVuZ3RoO1xuICAgIGZ1bmN0aW9uIGNsdCgpIHtcbiAgICAgICAgY29sbGVjdG9yLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG4gICAgICAgIGlmICgtLWNudCA8PSAwICYmIGRvbmUpXG4gICAgICAgICAgICBkb25lKCk7XG4gICAgfVxuICAgIHByb21pc2VzLmxlbmd0aCA9PT0gMCAmJiBkb25lID8gZG9uZSgpIDogcHJvbWlzZXMuZm9yRWFjaCgocCwgaSkgPT4gdGhpcy5yZXNvbHZlKHApLnRoZW4odmFsID0+IGNsdCh0cnVlLCB2YWwsIGkpLCBlcnIgPT4gY2x0KGZhbHNlLCBlcnIsIGkpKSk7XG59XG5leHBvcnQgZnVuY3Rpb24gZGVmZXIoKSB7XG4gICAgdmFyIHsgcHJvbWlzZUZhY3RvcnkgPSByZXNvbHZlciA9PiBuZXcgR3JlZWR5UHJvbWlzZShyZXNvbHZlcikgfSA9IGFyZ3VtZW50cy5sZW5ndGggPiAwICYmIGFyZ3VtZW50c1swXSAhPT0gdW5kZWZpbmVkID8gYXJndW1lbnRzWzBdIDoge307XG4gICAgZnVuY3Rpb24gaW52b2tlcihkZWxlZ2F0ZSkge1xuICAgICAgICByZXR1cm4gdmFsID0+IGRlbGVnYXRlKHZhbCk7XG4gICAgfVxuICAgIHZhciByZXNvbHZlRm4sIHJlamVjdEZuO1xuICAgIHJldHVybiB7XG4gICAgICAgIHByb21pc2U6IHByb21pc2VGYWN0b3J5KChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIHJlc29sdmVGbiA9IHJlc29sdmU7XG4gICAgICAgICAgICByZWplY3RGbiA9IHJlamVjdDtcbiAgICAgICAgfSksXG4gICAgICAgIHJlc29sdmU6IGludm9rZXIocmVzb2x2ZUZuKSxcbiAgICAgICAgcmVqZWN0OiBpbnZva2VyKHJlamVjdEZuKVxuICAgIH07XG59XG4iXSwibmFtZXMiOlsidG9Qcm9wZXJ0eUtleSIsIl9kZWZpbmVQcm9wZXJ0eSIsImUiLCJyIiwidCIsIk9iamVjdCIsImRlZmluZVByb3BlcnR5IiwidmFsdWUiLCJlbnVtZXJhYmxlIiwiY29uZmlndXJhYmxlIiwid3JpdGFibGUiLCJkZWZhdWx0IiwiX3R5cGVvZiIsInRvUHJpbWl0aXZlIiwiU3ltYm9sIiwiaSIsImNhbGwiLCJUeXBlRXJyb3IiLCJTdHJpbmciLCJOdW1iZXIiLCJvIiwiaXRlcmF0b3IiLCJjb25zdHJ1Y3RvciIsInByb3RvdHlwZSIsImluaXRDb3JlIiwiaW5pdE9waGFuIiwiX19kZWZQcm9wIiwiX19kZWZOb3JtYWxQcm9wIiwib2JqIiwia2V5IiwiX19wdWJsaWNGaWVsZCIsIkFCIiwiX3JlZiIsImFiVGVzdFN3aXRjaGVzIiwiYXJyYXlPZlRlc3RPYmplY3RzIiwiZXJyb3JSZXBvcnRlciIsImZvcmNlZFRlc3RFeGNlcHRpb24iLCJmb3JjZWRUZXN0VmFyaWFudHMiLCJtdnRJZCIsIm12dE1heFZhbHVlIiwib3BoYW5SZWNvcmQiLCJwYWdlSXNTZW5zaXRpdmUiLCJzZXJ2ZXJTaWRlVGVzdHMiLCJfY29yZSIsIl9vcGhhbiIsImFsbFJ1bm5hYmxlVGVzdHMiLCJmaXJzdFJ1bm5hYmxlVGVzdCIsInJ1bm5hYmxlVGVzdCIsImlzVXNlckluVmFyaWFudCIsInJlZ2lzdGVyQ29tcGxldGVFdmVudHMiLCJyZWdpc3RlckltcHJlc3Npb25FdmVudHMiLCJ0cmFja0FCVGVzdHMiLCJpc0V4cGlyZWQiLCJ2YXJpYW50Q2FuQmVSdW4iLCJ2YXJpYW50IiwiaXNJblRlc3QiLCJpZCIsImNhblJ1biIsInRlc3RDYW5CZVJ1biIsInRlc3QiLCJleHBpcmVkIiwiZXhwaXJ5IiwidGVzdFNob3VsZFNob3dGb3JTZW5zaXRpdmUiLCJzaG93Rm9yU2Vuc2l0aXZlIiwiaXNUZXN0T24iLCJjb25jYXQiLCJjYW5UZXN0QmVSdW4iLCJjb21wdXRlVmFyaWFudEZyb21NdnRDb29raWUiLCJzbWFsbGVzdFRlc3RJZCIsImF1ZGllbmNlT2Zmc2V0IiwibGFyZ2VzdFRlc3RJZCIsImF1ZGllbmNlIiwiX3Rlc3QkdmFyaWFudHMiLCJ2YXJpYW50cyIsImxlbmd0aCIsImdldEZvcmNlZFRlc3RWYXJpYW50IiwiZm9yY2VkVGVzdFZhcmlhbnRzMiIsIl9mb3JjZWRUZXN0VmFyaWFudHMyJCIsInRlc3RJZCIsImdldFZhcmlhbnRGcm9tSWRzIiwidGVzdDIiLCJ2YXJpYW50SWQiLCJfdGVzdDIkdmFyaWFudHMkZmluZCIsImZpbmQiLCJmb3JjZWRUZXN0IiwiZnJvbUNvb2tpZSIsInZhcmlhbnRGcm9tRm9yY2VkVGVzdCIsImZvcmNlZE91dE9mVGVzdCIsInZhcmlhbnRUb1J1biIsIl9vYmplY3RTcHJlYWQiLCJ0ZXN0cyIsInJlZHVjZSIsInByZXYiLCJjdXJyZW50VmFsdWUiLCJydCIsIl90ZXN0cyRtYXAkZmluZCIsIm1hcCIsInNvbWUiLCJydW5uYWJsZVRlc3QyIiwic3VibWl0IiwicGF5bG9hZCIsImFiVGVzdFJlZ2lzdGVyIiwibWFrZUFCRXZlbnQiLCJjb21wbGV0ZSIsImV2ZW50IiwidmFyaWFudE5hbWUiLCJjYW1wYWlnbkNvZGUiLCJjYW1wYWlnbkNvZGVzIiwiZGVmZXJzSW1wcmVzc2lvbiIsImV2ZXJ5IiwiaW1wcmVzc2lvbiIsImJ1aWxkT3BoYW5TdWJtaXR0ZXIiLCJkYXRhIiwicmVnaXN0ZXJDb21wbGV0ZUV2ZW50IiwibGlzdGVuZXIiLCJzdWNjZXNzIiwiZXJyb3IiLCJidWlsZE9waGFuUGF5bG9hZCIsInNlcnZlclNpZGVUZXN0T2JqIiwibG9nIiwia2V5cyIsImZpbHRlciIsImZvckVhY2giLCJzZXJ2ZXJTaWRlVmFyaWFudCIsInRlc3RFeHBpcnkiLCJjdXJyZW50VGltZSIsIkRhdGUiLCJ2YWx1ZU9mIiwidGhlVGVzdEV4cGlyeSIsInNldEhvdXJzIiwiSWRlbnRpdHlBdXRoIiwiaXNPbmVPZiIsInN0YWdlcyIsImlzU3RhZ2UiLCJnZXRTdGFnZSIsImlzRGV2Iiwic3RhZ2UiLCJnZXRJc3N1ZXIiLCJnZXRDbGllbnRJZCIsImdldFJlZGlyZWN0VXJpIiwib3JpZ2luIiwiZ2V0SWRlbnRpdHlBdXRoIiwiX3dpbmRvdyRndWFyZGlhbiRjb25mIiwiX2EkaWRlbnRpdHlBdXRoIiwiX3N3aXRjaGVzJGlkQ29va2llUmVmIiwiX2EiLCJ3aW5kb3ciLCJndWFyZGlhbiIsIkVycm9yIiwic3dpdGNoZXMiLCJjb25maWciLCJzdGFnZU9yRGV2IiwiaWRlbnRpdHlBdXRoIiwiaXNzdWVyIiwiY2xpZW50SWQiLCJyZWRpcmVjdFVyaSIsImxvY2F0aW9uIiwiaWRDb29raWVTZXNzaW9uUmVmcmVzaCIsImlkQ29va2llUmVmcmVzaCIsInNjb3BlcyIsImd1YXJkIiwicHJvZmlsZVVybHMiLCJpc1Byb2ZpbGVVcmwiLCJhcnJheSIsImluY2x1ZGVzIiwiX190eXBlRXJyb3IiLCJtc2ciLCJfX2FjY2Vzc0NoZWNrIiwibWVtYmVyIiwiaGFzIiwiX19wcml2YXRlR2V0IiwiZ2V0dGVyIiwiZ2V0IiwiX19wcml2YXRlQWRkIiwiV2Vha1NldCIsImFkZCIsInNldCIsIl9fcHJpdmF0ZVNldCIsInNldHRlciIsIl9fcHJpdmF0ZU1ldGhvZCIsIm1ldGhvZCIsIl9hdXRoU3RhdGUiLCJfZW1pdHRlciIsIl90b2tlbk1hbmFnZXIiLCJfQXV0aFN0YXRlTWFuYWdlcl9pbnN0YW5jZXMiLCJ1cGRhdGVBdXRoU3RhdGVfZm4iLCJBdXRoU3RhdGVNYW5hZ2VyIiwiZW1pdHRlciIsInRva2VuTWFuYWdlciIsImFjY2Vzc1Rva2VuIiwiaWRUb2tlbiIsImlzQXV0aGVudGljYXRlZCIsIm9uIiwiZ2V0QXV0aFN0YXRlIiwic3Vic2NyaWJlIiwiaGFuZGxlciIsInVuc3Vic2NyaWJlIiwib2ZmIiwiV2Vha01hcCIsInRva2VucyIsImdldFRva2Vuc1N5bmMiLCJlbWl0IiwiZ2V0Q29va2llIiwiX29wdGlvbnMiLCJfYXV0aFN0YXRlTWFuYWdlciIsIl9yZW5ld0F0VGltZW91dElkIiwiX0F1dG9SZW5ld1NlcnZpY2VfaW5zdGFuY2VzIiwiY2xlYXJSZW5ld0F0VGltZW91dF9mbiIsInNldFJlbmV3QXRUaW1lb3V0X2ZuIiwiaGFuZGxlQXV0aFN0YXRlQ2hhbmdlX2ZuIiwiQXV0b1JlbmV3U2VydmljZSIsIm9wdGlvbnMiLCJhdXRoU3RhdGVNYW5hZ2VyIiwic3RhcnQiLCJhdXRvUmVuZXciLCJzdGFydGVkIiwic3RhdGUiLCJjbGVhclRpbWVvdXQiLCJleHBpcmVzQXQiLCJub3ciLCJyZW5ld0F0IiwicmVuZXdHcmFjZVBlcmlvZCIsInRpbWVvdXQiLCJzZXRUaW1lb3V0IiwiZG9jdW1lbnQiLCJ2aXNpYmlsaXR5U3RhdGUiLCJhZGRFdmVudExpc3RlbmVyIiwiYXV0aFN0YXRlIiwiTWF0aCIsImZsb29yIiwibmFtZSIsInNob3VsZE1lbW9pemUiLCJvbmNlIiwic3RvcmFnZSIsIk9BdXRoRXJyb3IiLCJkYXlzMzBJbk1pbGxpcyIsInJlZGlyZWN0VG9SZWZyZXNoRW5kcG9pbnQiLCJwcm9maWxlVXJsIiwicmV0dXJuVXJsIiwiZW5kcG9pbnQiLCJyZXBsYWNlIiwic2hvdWxkUmVmcmVzaENvb2tpZSIsImxhc3RSZWZyZXNoIiwibGFzdFJlZnJlc2hJc1ZhbGlkIiwiY29va2llUmVmcmVzaElmUmVxdWlyZWQiLCJlbmFibGVkIiwic3BsaXQiLCJlcnJvcl9kZXNjcmlwdGlvbiIsImxhc3RSZWZyZXNoS2V5IiwibG9jYWwiLCJpc0F2YWlsYWJsZSIsImdldFRpbWUiLCJuZXdFeHBpcnkiLCJlbmNvZGVVUklDb21wb25lbnQiLCJocmVmIiwiZGVjMmhleCIsImRlYyIsImhleCIsInRvU3RyaW5nIiwic3Vic3RyaW5nIiwiZ2V0UmFuZG9tU3RyaW5nIiwiYXJyIiwiVWludDhBcnJheSIsImNlaWwiLCJjcnlwdG8iLCJnZXRSYW5kb21WYWx1ZXMiLCJzdHIiLCJBcnJheSIsImZyb20iLCJqb2luIiwic2xpY2UiLCJnZW5lcmF0ZVNoYTI1Nkhhc2giLCJfYXN5bmNUb0dlbmVyYXRvciIsImJ1ZmZlciIsIlRleHRFbmNvZGVyIiwiZW5jb2RlIiwiaGFzaEJ1ZmZlciIsInN1YnRsZSIsImRpZ2VzdCIsImhhc2hBcnJheSIsImhhc2giLCJmcm9tQ2hhckNvZGUiLCJhcHBseSIsIl94IiwiYXJndW1lbnRzIiwiZ2VuZXJhdGVDb2RlVmVyaWZpZXIiLCJnZW5lcmF0ZUNvZGVDaGFsbGVuZ2UiLCJfcmVmMiIsImNvZGVWZXJpZmllciIsImJhc2U2NHVybCIsImJhc2U2NFVybEVuY29kZSIsIl94MiIsImJhc2U2NFVybFRvU3RyaW5nIiwiYmFzZTY0VXJsIiwiYmFzZTY0IiwiYmFzZTY0VXJsVG9CYXNlNjQiLCJ1dGY4c3RyIiwiYXRvYiIsImRlY29kZVVSSUNvbXBvbmVudCIsImVzY2FwZSIsInN0cmluZ1RvQnVmZmVyIiwiY2hhckNvZGVBdCIsImJ0b2EiLCJfZXZlbnRzIiwiRW1pdHRlciIsImNhbGxiYWNrIiwiY3R4IiwiX2V2ZW50cyRuYW1lIiwiZXZlbnRzIiwiZXZlbnRBcnIiLCJwdXNoIiwiZm4iLCJsaXZlRXZlbnRzIiwiX3ByaXZhdGVHZXQkbmFtZSIsIl9sZW4iLCJfa2V5IiwibWVzc2FnZSIsInJlbW92ZUNvb2tpZSIsIlRva2VuIiwiVG9rZW5NYW5hZ2VyIiwiX29hdXRoVXJscyIsIl9hdXRvUmVuZXdTZXJ2aWNlIiwiX2lzU2lnbmVkSW5XaXRoQXV0aFN0YXRlSW5Qcm9ncmVzcyIsIl9JZGVudGl0eUF1dGhfaW5zdGFuY2VzIiwiaXNTaWduZWRJbldpdGhBdXRoU3RhdGVfZm4iLCJtYXhDbG9ja1NrZXciLCJvYXV0aFRpbWVvdXQiLCJzdHJpY3RDbG9ja1NrZXdDaGVjayIsImF1dGhvcml6ZVVybCIsInRva2VuVXJsIiwia2V5c1VybCIsInRva2VuIiwiaXNTaWduZWRJbldpdGhBdXRoU3RhdGUiLCJfdGhpcyIsImZpbmFsbHkiLCJpc1NpZ25lZEluIiwiX3RoaXMyIiwiX2dldENvb2tpZSIsInZlcmlmeVRva2VucyIsImd1U29Db29raWUiLCJwYXJzZUludCIsIm5vcm1hbGlzZWRDdXJyZW50VGltZSIsImNsb2NrU2tldyIsImNsYWltcyIsImlhdCIsImNsZWFyIiwiZ2V0VG9rZW5zIiwicmVmcmVzaElmUmVxdWlyZWQiLCJpc05vbk51bGxhYmxlIiwiX2dldFRva2Vuc0luUHJvZ3Jlc3MiLCJfZXhjaGFuZ2VDb2RlRm9yVG9rZW5zIiwiX2hhbmRsZU9BdXRoUmVzcG9uc2UiLCJfcGVyZm9ybUF1dGhDb2RlRmxvd0lmcmFtZSIsIl9Ub2tlbl9pbnN0YW5jZXMiLCJnZXRXaXRob3V0UHJvbXB0X2ZuIiwiaXNBY2Nlc3NUb2tlbkNsYWltcyIsIm1heWJlQ2xhaW1zIiwiYXVkIiwiYXV0aF90aW1lIiwiY2lkIiwiZW1haWxfdmFsaWRhdGVkIiwiZXhwIiwiaWRlbnRpdHlfdXNlcm5hbWUiLCJpc3MiLCJqdGkiLCJsZWdhY3lfaWRlbnRpdHlfaWQiLCJzY3AiLCJzdWIiLCJ1aWQiLCJ2ZXIiLCJpc0FjY2Vzc1Rva2VuIiwibWF5YmVUb2tlbiIsInRva2VuVHlwZSIsImlzSURUb2tlbkNsYWltcyIsImFtciIsImF0X2hhc2giLCJpZHAiLCJub25jZSIsInByZWZlcnJlZF91c2VybmFtZSIsInVzZXJfZ3JvdXBzIiwiaXNJRFRva2VuIiwiaXNPQXV0aEF1dGhvcml6ZVJlc3BvbnNlRXJyb3IiLCJyZXNwb25zZSIsIm1heWJlUmVzcG9uc2UiLCJpc09BdXRoVG9rZW5SZXNwb25zZUVycm9yIiwiY2FsY3VsYXRlQ2xvY2tTa2V3IiwiZGVjb2RlVG9rZW4iLCJoZWFkZXJTdHIiLCJwYXlsb2FkU3RyIiwic2lnbmF0dXJlIiwiaGVhZGVyIiwiSlNPTiIsInBhcnNlIiwiYWxnIiwia2lkIiwiZGVjb2RlVG9rZW5zIiwiYWNjZXNzVG9rZW5SYXciLCJhY2Nlc3NUb2tlbkNsb2NrU2tldyIsImlkVG9rZW5SYXciLCJpZFRva2VuQ2xvY2tTa2V3IiwiZGVjb2RlZEFjY2Vzc1Rva2VuIiwiYWNjZXNzVG9rZW5QYXlsb2FkIiwiYWJzIiwiZGVjb2RlZElEVG9rZW4iLCJpZFRva2VuUGF5bG9hZCIsInZlcmlmeUlkVG9rZW5DbGFpbXMiLCJkZWNvZGVkIiwibG9jYWxUaW1lIiwibm9ybWFsaXNlZFRpbWUiLCJ2ZXJpZnlBY2Nlc3NUb2tlbldpdGhBdEhhc2giLCJhY2Nlc3NfdG9rZW4iLCJhY2Nlc3NUb2tlbkhhc2giLCJhY2Nlc3NUb2tlbkhhc2gxMjgiLCJhY2Nlc3NUb2tlbkhhc2hCYXNlNjQiLCJ2ZXJpZnlTaWduYXR1cmUiLCJfcmVmMyIsImp3a3NVcmkiLCJqd3QiLCJqd2tzUmVzcG9uc2UiLCJmZXRjaCIsIm9rIiwiandrcyIsImpzb24iLCJrZXkyIiwia3R5IiwibiIsInVzZSIsImsiLCJhbGdvcml0aG0iLCJwdWJsaWNLZXkiLCJpbXBvcnRLZXkiLCJzaWciLCJpc1ZhbGlkIiwidmVyaWZ5IiwiX3gzIiwiX3g0IiwiX3g1IiwidmVyaWZ5QWNjZXNzVG9rZW5UaW1lc3RhbXBzIiwiYWRkUG9zdE1lc3NhZ2VMaXN0ZW5lciIsIm9wdHMiLCJyZXNwb25zZUhhbmRsZXIiLCJ0aW1lb3V0SWQiLCJtc2dSZWNlaXZlZE9yVGltZW91dCIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwicmVtb3ZlRXZlbnRMaXN0ZW5lciIsImxvYWRGcmFtZSIsInVybCIsImZyYW1lIiwiY3JlYXRlRWxlbWVudCIsInN0eWxlIiwiZGlzcGxheSIsInNyYyIsImJvZHkiLCJhcHBlbmRDaGlsZCIsInBlcmZvcm1BdXRoQ29kZUZsb3dJZnJhbWUiLCJfcmVmNCIsImF1dGhvcml6ZVBhcmFtcyIsIm9hdXRoVXJscyIsInNlYXJjaFBhcmFtcyIsIlVSTFNlYXJjaFBhcmFtcyIsInBvc3RNZXNzYWdlTGlzdGVuZXIiLCJpZnJhbWUiLCJhdXRob3JpemVSZXNwb25zZSIsImNvbnRhaW5zIiwicmVtb3ZlQ2hpbGQiLCJfeDYiLCJfeDciLCJfeDgiLCJtZW1vaXplZFZlcmlmeVRva2VucyIsIk1hcCIsIl9yZWY1IiwibWVtb2l6ZWQiLCJpZFRva2VuSldUIiwiYWNjZXNzVG9rZW5KV1QiLCJfeDkiLCJfeDAiLCJfeDEiLCJfeDEwIiwiZXhjaGFuZ2VDb2RlRm9yVG9rZW5zIiwiX3JlZjYiLCJjb2RlIiwidG9rZW5QYXJhbXMiLCJjbGllbnRfaWQiLCJjb2RlX3ZlcmlmaWVyIiwiZ3JhbnRfdHlwZSIsInJlZGlyZWN0X3VyaSIsImhlYWRlcnMiLCJfeDExIiwiX3gxMiIsIl94MTMiLCJfeDE0IiwiaGFuZGxlT0F1dGhSZXNwb25zZSIsIl9yZWY3Iiwib2F1dGhUb2tlblJlc3BvbnNlIiwiaWRfdG9rZW4iLCJfeDE1IiwiX3gxNiIsIl94MTciLCJfeDE4IiwiZ2V0V2l0aG91dFByb21wdCIsIl9yZWY4IiwiX3JlZjkiLCJjb2RlQ2hhbGxlbmdlIiwiY29kZV9jaGFsbGVuZ2UiLCJjb2RlX2NoYWxsZW5nZV9tZXRob2QiLCJwcm9tcHQiLCJyZXNwb25zZV90eXBlIiwicmVzcG9uc2VfbW9kZSIsInNjb3BlIiwidG9rZW5SZXNwb25zZSIsInBhcnNlZCIsIl90b2tlbiIsIl9zdG9yYWdlIiwiX2FjY2Vzc1Rva2VuS2V5IiwiX2lkVG9rZW5LZXkiLCJfVG9rZW5NYW5hZ2VyX2luc3RhbmNlcyIsImVtaXRBZGRlZF9mbiIsImVtaXRSZW1vdmVkX2ZuIiwiZW1pdFN0b3JhZ2VfZm4iLCJ0b2tlbkNsYXNzIiwicmVuZXciLCJzZXRUb2tlbnMiLCJ0b2tlblR5cGVzIiwiZXhpc3RpbmdUb2tlbnMiLCJhY2Nlc3NUb2tlblN0b3JhZ2UiLCJpZFRva2VuU3RvcmFnZSIsIm5ld1Rva2VuIiwiZXhpc3RpbmdUb2tlbiIsImFjY2Vzc1Rva2VuRnJvbVN0b3JhZ2UiLCJpZFRva2VuRnJvbVN0b3JhZ2UiLCJfYXJndW1lbnRzIiwidW5kZWZpbmVkIiwicmVtb3ZlIiwiX3RoaXMzIiwiRVJSX0lOVkFMSURfQ09PS0lFIiwiZ2V0Q29va2llVmFsdWVzIiwiZ2V0RG9tYWluQXR0cmlidXRlIiwiaXNWYWxpZENvb2tpZSIsIm1lbW9pemVkQ29va2llcyIsInNldENvb2tpZSIsImRheXNUb0xpdmUiLCJpc0Nyb3NzU3ViZG9tYWluIiwiZXhwaXJlcyIsInNldFVUQ0RhdGUiLCJnZXRVVENEYXRlIiwic2V0VVRDTW9udGgiLCJnZXRVVENNb250aCIsImNvb2tpZSIsInRvVVRDU3RyaW5nIiwidmFsdWUyIiwiXyIsImxpdGVyYWxzIiwiZGVzZXJpYWxpc2UiLCJnZXRNZWFzdXJlcyIsInN1YnNjcmlwdGlvbnMiLCJwZXJmb3JtYW5jZSIsImdldEVudHJpZXNCeVR5cGUiLCJmbGF0TWFwIiwiZW50cnlUeXBlIiwiZHVyYXRpb24iLCJzdGFydFRpbWUiLCJkZXRhaWwiLCJzdWJzY3JpcHRpb24iLCJ0b0pzb24iLCJzdHJpbmdpZnkiLCJpc1N0cmluZyIsImlzU3Vic2NyaXB0aW9uIiwiU0VQQVJBVE9SIiwic2VyaWFsaXNlIiwiYWN0aW9uIiwiZGx2IiwiZGVmIiwicCIsInVuZGVmIiwiZHNldCIsInZhbCIsImwiLCJ4IiwiaW5kZXhPZiIsImtsb25hIiwib3V0IiwidG1wIiwiaXNBcnJheSIsImFycmF5UHVzaCIsInZhbHVlcyIsImluZGV4Iiwib2Zmc2V0IiwiaXNGbGF0dGVuYWJsZSIsImJhc2VGbGF0dGVuIiwiZGVwdGgiLCJwcmVkaWNhdGUiLCJpc1N0cmljdCIsInJlc3VsdCIsImJhc2VHZXRUYWciLCJpc09iamVjdExpa2UiLCJhcmdzVGFnIiwiYmFzZUlzQXJndW1lbnRzIiwiaXNBcmd1bWVudHMiLCJzcHJlYWRhYmxlU3ltYm9sIiwiaXNDb25jYXRTcHJlYWRhYmxlIiwiZmxhdHRlbiIsIm9iamVjdFByb3RvIiwiaGFzT3duUHJvcGVydHkiLCJwcm9wZXJ0eUlzRW51bWVyYWJsZSIsIm93bktleXMiLCJnZXRPd25Qcm9wZXJ0eVN5bWJvbHMiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IiLCJnZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3JzIiwiZGVmaW5lUHJvcGVydGllcyIsImlzVmFsaWRQcmljZUNvbmZpZyIsImFycmF5RnJvbSIsImRlZXBBY2Nlc3MiLCJkZWVwQ2xvbmUiLCJnZXRQYXJhbWV0ZXJCeU5hbWUiLCJpc0Jvb2xlYW4iLCJpc1BsYWluT2JqZWN0IiwiaXNTdHIiLCJsb2dFcnJvciIsImxvZ01lc3NhZ2UiLCJsb2dXYXJuIiwibWVyZ2VEZWVwIiwiREVCVUdfTU9ERSIsIkRFRkFVTFRfREVCVUciLCJ0b1VwcGVyQ2FzZSIsIkRFRkFVTFRfQklEREVSX1RJTUVPVVQiLCJERUZBVUxUX0VOQUJMRV9TRU5EX0FMTF9CSURTIiwiREVGQVVMVF9ESVNBQkxFX0FKQVhfVElNRU9VVCIsIkRFRkFVTFRfQklEX0NBQ0hFIiwiREVGQVVMVF9ERVZJQ0VfQUNDRVNTIiwiREVGQVVMVF9NQVhfTkVTVEVEX0lGUkFNRVMiLCJERUZBVUxUX01BWEJJRF9WQUxVRSIsIkRFRkFVTFRfSUZSQU1FU19DT05GSUciLCJSQU5ET00iLCJGSVhFRCIsIlZBTElEX09SREVSUyIsIkRFRkFVTFRfQklEREVSX1NFUVVFTkNFIiwiR1JBTlVMQVJJVFlfT1BUSU9OUyIsIkxPVyIsIk1FRElVTSIsIkhJR0giLCJBVVRPIiwiREVOU0UiLCJDVVNUT00iLCJBTExfVE9QSUNTIiwiYXR0YWNoUHJvcGVydGllcyIsInVzZURlZmF1bHRWYWx1ZXMiLCJwcmljZUdyYW51bGFyaXR5IiwiY3VzdG9tUHJpY2VCdWNrZXQiLCJtZWRpYVR5cGVQcmljZUdyYW51bGFyaXR5IiwiYmlkZGVyU2VxdWVuY2UiLCJhdWN0aW9uT3B0aW9ucyIsImdldFByb3AiLCJzZXRQcm9wIiwicHJvcHMiLCJwdWJsaXNoZXJEb21haW4iLCJ2YWxpZGF0ZVByaWNlR3JhbnVsYXJpdHkiLCJoYXNHcmFudWxhcml0eSIsImFnZ3JlZ2F0ZSIsIml0ZW0iLCJ2YWxpZGF0ZWF1Y3Rpb25PcHRpb25zIiwiZnJvbUVudHJpZXMiLCJlbnRyaWVzIiwiYXNzaWduIiwiYmluZCIsIm9wdGlvbiIsIm5ld0NvbmZpZyIsImxpc3RlbmVycyIsImRlZmF1bHRzIiwiYmlkZGVyQ29uZmlnIiwiY3VyckJpZGRlciIsInJlc2V0Q29uZmlnIiwiZGVidWciLCJiaWRkZXJUaW1lb3V0IiwiZW5hYmxlU2VuZEFsbEJpZHMiLCJ1c2VCaWRDYWNoZSIsImRldmljZUFjY2VzcyIsImRpc2FibGVBamF4VGltZW91dCIsIm1heE5lc3RlZElmcmFtZXMiLCJtYXhCaWQiLCJ1c2VyU3luYyIsInRvcGljcyIsImNhbGxTdWJzY3JpYmVycyIsIm1lbW8iLCJ0b3BpYyIsIl9nZXRDb25maWciLCJjdXJyQmlkZGVyQ29uZmlnIiwiY29uZmlnVG9waWNTZXQiLCJTZXQiLCJfZ2V0UmVzdHJpY3RlZENvbmZpZyIsImNvbmYiLCJnZXRBbnlDb25maWciLCJnZXRDb25maWciLCJhY2Nlc3NvciIsInJlYWRDb25maWciLCJyZWFkQW55Q29uZmlnIiwid3JhcGVlIiwicmVzIiwiZ2V0QmlkZGVyQ29uZmlnIiwic2V0Q29uZmlnIiwidG9waWNhbENvbmZpZyIsInNldERlZmF1bHRzIiwibmwiLCJpbml0Iiwic3BsaWNlIiwiVE9QSUNTIiwic2V0QmlkZGVyQ29uZmlnIiwibWVyZ2VGbGFnIiwiY2hlY2siLCJiaWRkZXJzIiwiYmlkZGVyIiwiY3VycmVudENvbmZpZyIsImZ1bmMiLCJtZXJnZUNvbmZpZyIsIm1lcmdlZENvbmZpZyIsIm1lcmdlQmlkZGVyQ29uZmlnIiwicnVuV2l0aEJpZGRlciIsInJlc2V0QmlkZGVyIiwiY2FsbGJhY2tXaXRoQmlkZGVyIiwiY2IiLCJhcmdzIiwiZ2V0Q3VycmVudEJpZGRlciIsIkpTT05fTUFQUElORyIsIlBMX0NPREUiLCJQTF9TSVpFIiwiUExfQklEUyIsIkJEX0JJRERFUiIsIkJEX0lEIiwiQkRfUExfSUQiLCJBRFNFUlZFUl9UQVJHRVRJTkciLCJCRF9TRVRUSU5HX1NUQU5EQVJEIiwiU1RBVFVTIiwiR09PRCIsIkVWRU5UUyIsIkFVQ1RJT05fSU5JVCIsIkFVQ1RJT05fVElNRU9VVCIsIkFVQ1RJT05fRU5EIiwiQklEX0FESlVTVE1FTlQiLCJCSURfVElNRU9VVCIsIkJJRF9SRVFVRVNURUQiLCJCSURfUkVTUE9OU0UiLCJCSURfUkVKRUNURUQiLCJOT19CSUQiLCJTRUFUX05PTl9CSUQiLCJCSURfV09OIiwiQklEREVSX0RPTkUiLCJCSURERVJfRVJST1IiLCJTRVRfVEFSR0VUSU5HIiwiQkVGT1JFX1JFUVVFU1RfQklEUyIsIkJFRk9SRV9CSURERVJfSFRUUCIsIlJFUVVFU1RfQklEUyIsIkFERF9BRF9VTklUUyIsIkFEX1JFTkRFUl9GQUlMRUQiLCJBRF9SRU5ERVJfU1VDQ0VFREVEIiwiVENGMl9FTkZPUkNFTUVOVCIsIkFVQ1RJT05fREVCVUciLCJCSURfVklFV0FCTEUiLCJTVEFMRV9SRU5ERVIiLCJFWFBJUkVEX1JFTkRFUiIsIkJJTExBQkxFX0VWRU5UIiwiQklEX0FDQ0VQVEVEIiwiUlVOX1BBQVBJX0FVQ1RJT04iLCJQQlNfQU5BTFlUSUNTIiwiUEFBUElfQklEIiwiUEFBUElfTk9fQklEIiwiUEFBUElfRVJST1IiLCJBRF9SRU5ERVJfRkFJTEVEX1JFQVNPTiIsIlBSRVZFTlRfV1JJVElOR19PTl9NQUlOX0RPQ1VNRU5UIiwiTk9fQUQiLCJFWENFUFRJT04iLCJDQU5OT1RfRklORF9BRCIsIk1JU1NJTkdfRE9DX09SX0FESUQiLCJFVkVOVF9JRF9QQVRIUyIsImJpZFdvbiIsIlRBUkdFVElOR19LRVlTIiwiQklEREVSIiwiQURfSUQiLCJQUklDRV9CVUNLRVQiLCJTSVpFIiwiREVBTCIsIlNPVVJDRSIsIkZPUk1BVCIsIlVVSUQiLCJDQUNIRV9JRCIsIkNBQ0hFX0hPU1QiLCJBRE9NQUlOIiwiQUNBVCIsIkNSSUQiLCJEU1AiLCJERUZBVUxUX1RBUkdFVElOR19LRVlTIiwiTkFUSVZFX0tFWVMiLCJ0aXRsZSIsImJvZHkyIiwicHJpdmFjeUxpbmsiLCJwcml2YWN5SWNvbiIsInNwb25zb3JlZEJ5IiwiaW1hZ2UiLCJpY29uIiwiY2xpY2tVcmwiLCJkaXNwbGF5VXJsIiwiY3RhIiwicmF0aW5nIiwiYWRkcmVzcyIsImRvd25sb2FkcyIsImxpa2VzIiwicGhvbmUiLCJwcmljZSIsInNhbGVQcmljZSIsInJlbmRlcmVyVXJsIiwiYWRUZW1wbGF0ZSIsIlMyUyIsIlNSQyIsIkRFRkFVTFRfRU5EUE9JTlQiLCJTWU5DRURfQklEREVSU19LRVkiLCJCSURfU1RBVFVTIiwiQklEX1RBUkdFVElOR19TRVQiLCJSRU5ERVJFRCIsIlJFSkVDVElPTl9SRUFTT04iLCJJTlZBTElEIiwiSU5WQUxJRF9SRVFVRVNUX0lEIiwiQklEREVSX0RJU0FMTE9XRUQiLCJGTE9PUl9OT1RfTUVUIiwiQ0FOTk9UX0NPTlZFUlRfQ1VSUkVOQ1kiLCJEU0FfUkVRVUlSRUQiLCJEU0FfTUlTTUFUQ0giLCJQUklDRV9UT09fSElHSCIsIlBSRUJJRF9OQVRJVkVfREFUQV9LRVlTX1RPX09SVEIiLCJOQVRJVkVfQVNTRVRfVFlQRVMiLCJzcG9uc29yZWQiLCJkZXNjIiwic2FsZXByaWNlIiwiZGVzYzIiLCJkaXNwbGF5dXJsIiwiY3RhdGV4dCIsIk5BVElWRV9JTUFHRV9UWVBFUyIsIklDT04iLCJNQUlOIiwiTkFUSVZFX0tFWVNfVEhBVF9BUkVfTk9UX0FTU0VUUyIsIk1FU1NBR0VTIiwiUkVRVUVTVCIsIlJFU1BPTlNFIiwiTkFUSVZFIiwiRVZFTlQiLCJQQl9MT0NBVE9SIiwiaXNFbXB0eSIsIl9kZWZhdWx0UHJlY2lzaW9uIiwiX2xnUHJpY2VDb25maWciLCJfbWdQcmljZUNvbmZpZyIsIl9oZ1ByaWNlQ29uZmlnIiwiX2RlbnNlUHJpY2VDb25maWciLCJfYXV0b1ByaWNlQ29uZmlnIiwiZ2V0UHJpY2VCdWNrZXRTdHJpbmciLCJjcG0iLCJjdXN0b21Db25maWciLCJncmFudWxhcml0eU11bHRpcGxpZXIiLCJjcG1GbG9hdCIsInBhcnNlRmxvYXQiLCJpc05hTiIsImxvdyIsImdldENwbVN0cmluZ1ZhbHVlIiwibWVkIiwiaGlnaCIsImF1dG8iLCJkZW5zZSIsImN1c3RvbSIsImNwbVN0ciIsImNhcCIsImJ1Y2tldHMiLCJjdXJyIiwibWF4IiwiYnVja2V0Rmxvb3IiLCJidWNrZXQiLCJwcmVjaXNpb24iLCJ0b0ZpeGVkIiwibWluIiwiZ2V0Q3BtVGFyZ2V0IiwiaW5jcmVtZW50IiwiYnVja2V0TWluIiwicm91bmRpbmdGdW5jdGlvbiIsImN1c3RvbVJvdW5kaW5nRnVuY3Rpb24iLCJwb3ciLCJjcG1Ub1JvdW5kIiwiY3BtVGFyZ2V0IiwiaW52YWxpZFJvdW5kaW5nIiwiZXJyIiwidGFyZ2V0IiwiZWxlbSIsInByZWQiLCJ0aGlzQXJnIiwiZmluZEluZGV4IiwiZ2xvYmFsIiwicGJqcyIsImNtZCIsInF1ZSIsIl9wYmpzR2xvYmFscyIsImdldEdsb2JhbCIsInJlZ2lzdGVyTW9kdWxlIiwiaW5zdGFsbGVkTW9kdWxlcyIsIkdyZWVkeVByb21pc2UiLCJkZWVwU2V0VmFsdWUiLCJ0U3RyIiwidEZuIiwidE51bWIiLCJ0T2JqZWN0IiwidEJvb2xlYW4iLCJjb25zb2xlRXhpc3RzIiwiQm9vbGVhbiIsImNvbnNvbGUiLCJjb25zb2xlTG9nRXhpc3RzIiwiY29uc29sZUluZm9FeGlzdHMiLCJpbmZvIiwiY29uc29sZVdhcm5FeGlzdHMiLCJ3YXJuIiwiY29uc29sZUVycm9yRXhpc3RzIiwiZXZlbnRFbWl0dGVyIiwicGJqc0luc3RhbmNlIiwiX3NldEV2ZW50RW1pdHRlciIsImVtaXRGbiIsImVtaXRFdmVudCIsImludGVybmFsIiwiY2hlY2tDb29raWVTdXBwb3J0IiwiY3JlYXRlVHJhY2tQaXhlbElmcmFtZUh0bWwiLCJnZXRXaW5kb3dTZWxmIiwiZ2V0V2luZG93VG9wIiwiY2FuQWNjZXNzV2luZG93VG9wIiwiZ2V0V2luZG93TG9jYXRpb24iLCJpbnNlcnRVc2VyU3luY0lmcmFtZSIsImluc2VydEVsZW1lbnQiLCJpc0ZuIiwidHJpZ2dlclBpeGVsIiwibG9nSW5mbyIsInBhcnNlUVMiLCJmb3JtYXRRUyIsImRlZXBFcXVhbCIsInByZWJpZEludGVybmFsIiwiZ2V0UHJlYmlkSW50ZXJuYWwiLCJnZXRJbmNyZW1lbnRhbEludGVnZXIiLCJjb3VudCIsImdldFVuaXF1ZUlkZW50aWZpZXJTdHIiLCJyYW5kb20iLCJzdWJzdHIiLCJnZW5lcmF0ZVVVSUQiLCJwbGFjZWhvbGRlciIsIl9nZXRSYW5kb21EYXRhIiwiZ2V0QmlkSWRQYXJhbWV0ZXIiLCJwYXJhbXNPYmoiLCJwYXJzZVF1ZXJ5U3RyaW5nUGFyYW1ldGVycyIsInF1ZXJ5T2JqIiwidHJhbnNmb3JtQWRTZXJ2ZXJUYXJnZXRpbmdPYmoiLCJ0YXJnZXRpbmciLCJnZXRPd25Qcm9wZXJ0eU5hbWVzIiwic2l6ZXNUb1NpemVUdXBsZXMiLCJzaXplcyIsInN6IiwibWF0Y2giLCJ3IiwiaCIsImlzVmFsaWRHUFRTaW5nbGVTaXplIiwicGFyc2VTaXplc0lucHV0Iiwic2l6ZU9iaiIsInNpemVUdXBsZVRvU2l6ZVN0cmluZyIsInNpemUiLCJwYXJzZUdQVFNpbmdsZVNpemVBcnJheSIsInNpbmdsZVNpemUiLCJzaXplVHVwbGVUb1J0YlNpemUiLCJwYXJzZUdQVFNpbmdsZVNpemVBcnJheVRvUnRiU2l6ZSIsInRvcCIsInNlbGYiLCJkZWJ1Z1R1cm5lZE9uIiwiZGVjb3JhdGVMb2ciLCJ0eXBlIiwicHJlZml4TG9nIiwicHJlZml4IiwiZGVjb3JhdGUiLCJ1bnNoaWZ0IiwibGFiZWwiLCJjb2xvciIsImhhc0NvbnNvbGVMb2dnZXIiLCJjcmVhdGVJZnJhbWUiLCJERUZBVUxUUyIsImJvcmRlciIsImhzcGFjZSIsInZzcGFjZSIsIm1hcmdpbldpZHRoIiwibWFyZ2luSGVpZ2h0Iiwic2Nyb2xsaW5nIiwiZnJhbWVCb3JkZXIiLCJhbGxvd3RyYW5zcGFyZW5jeSIsImRvYyIsImF0dHJzIiwiZiIsImNyZWF0ZUludmlzaWJsZUlmcmFtZSIsIndpZHRoIiwiaGVpZ2h0Iiwic2VhcmNoIiwiaXNBIiwib2JqZWN0IiwiX3QiLCJpc051bWJlciIsImlzRW1wdHlTdHIiLCJfZWFjaCIsInYiLCJhIiwiX21hcCIsImVsbSIsImFzTGFzdENoaWxkQ2hpbGQiLCJwYXJlbnRFbCIsImdldEVsZW1lbnRzQnlUYWdOYW1lIiwiaW5zZXJ0QmVmb3JlRWwiLCJmaXJzdENoaWxkIiwiaW5zZXJ0QmVmb3JlIiwid2FpdEZvckVsZW1lbnRUb0xvYWQiLCJlbGVtZW50IiwidGltZXIiLCJvbkxvYWQiLCJkb25lIiwiaW1nIiwiSW1hZ2UiLCJ0aGVuIiwiaW5zZXJ0SHRtbEludG9JZnJhbWUiLCJodG1sQ29kZSIsIm9wZW4iLCJ3cml0ZSIsImNsb3NlIiwiY29udGVudFdpbmRvdyIsImlmcmFtZUh0bWwiLCJkaXYiLCJpbm5lckhUTUwiLCJjcmVhdGVUcmFja1BpeGVsSHRtbCIsImVuY29kZVVSSSIsImVzY2FwZWRVcmwiLCJlbmNvZGVNYWNyb1VSSSIsIm1hY3JvcyIsIm1hdGNoQWxsIiwibWFjcm8iLCJlbmNvZGVVcmkiLCJzYW5kYm94IiwidW5pcXVlcyIsImFycnkiLCJiIiwiZ2V0QmlkUmVxdWVzdCIsImJpZGRlclJlcXVlc3RzIiwiYnIiLCJiaWRzIiwiYmlkIiwicHJvcCIsImdldFZhbHVlIiwiZ2V0QmlkZGVyQ29kZXMiLCJhZFVuaXRzIiwidW5pdCIsImlzR3B0UHViYWRzRGVmaW5lZCIsImdvb2dsZXRhZyIsInB1YmFkcyIsImdldFNsb3RzIiwiaXNBcG5HZXRUYWdEZWZpbmVkIiwiYXBudGFnIiwiZ2V0VGFnIiwic29ydEJ5SGlnaGVzdENwbSIsInNodWZmbGUiLCJjb3VudGVyIiwidGVtcCIsImluSWZyYW1lIiwiaXNTYWZlRnJhbWVXaW5kb3ciLCJ3cyIsIiRzZiIsImV4dCIsImdldFNhZmVmcmFtZUdlb21ldHJ5IiwiZ2VvbSIsImlzU2FmYXJpQnJvd3NlciIsIm5hdmlnYXRvciIsInVzZXJBZ2VudCIsInJlcGxhY2VNYWNyb3MiLCJzdWJzIiwiUmVnRXhwIiwicmVwbGFjZUF1Y3Rpb25QcmljZSIsIkFVQ1RJT05fUFJJQ0UiLCJyZXBsYWNlQ2xpY2tUaHJvdWdoIiwiY2xpY2t0YWciLCJ0aW1lc3RhbXAiLCJnZXRQZXJmb3JtYW5jZU5vdyIsImdldERvbUxvYWRpbmdEdXJhdGlvbiIsIl93JHBlcmZvcm1hbmNlIiwiZG9tTG9hZGluZ0R1cmF0aW9uIiwidGltaW5nIiwibmF2aWdhdGlvblN0YXJ0IiwiZG9tTG9hZGluZyIsImhhc0RldmljZUFjY2VzcyIsImNvb2tpZUVuYWJsZWQiLCJkZWxheUV4ZWN1dGlvbiIsIm51bVJlcXVpcmVkQ2FsbHMiLCJudW1DYWxscyIsImdyb3VwQnkiLCJ4cyIsInJ2IiwiZ2V0RGVmaW5lZFBhcmFtcyIsInBhcmFtcyIsInBhcmFtIiwiaXNWYWxpZE1lZGlhVHlwZXMiLCJtZWRpYVR5cGVzIiwiU1VQUE9SVEVEX01FRElBX1RZUEVTIiwiU1VQUE9SVEVEX1NUUkVBTV9UWVBFUyIsInR5cGVzIiwidmlkZW8iLCJjb250ZXh0IiwiZ2V0VXNlckNvbmZpZ3VyZWRQYXJhbXMiLCJhZFVuaXRDb2RlIiwiYWRVbml0IiwiYmlkZGVyRGF0YSIsImdldEROVCIsImRvTm90VHJhY2siLCJtc0RvTm90VHJhY2siLCJjb21wYXJlQ29kZUFuZFNsb3QiLCJzbG90IiwiZ2V0QWRVbml0UGF0aCIsImdldFNsb3RFbGVtZW50SWQiLCJpc0FkVW5pdENvZGVNYXRjaGluZ1Nsb3QiLCJ1bnN1cHBvcnRlZEJpZGRlck1lc3NhZ2UiLCJtZWRpYVR5cGUiLCJpc0ludGVnZXIiLCJjbGVhbk9iaiIsInBpY2siLCJwcm9wZXJ0aWVzIiwibmV3T2JqIiwibmV3UHJvcCIsImlzQXJyYXlPZk51bXMiLCJxdWVyeSIsImFjYyIsImNyaXRlcmlhIiwicGFyc2VVcmwiLCJub0RlY29kZVdob2xlVVJMIiwicXNBc1N0cmluZyIsImRlY29kZVNlYXJjaEFzU3RyaW5nIiwicHJvdG9jb2wiLCJob3N0bmFtZSIsInBvcnQiLCJwYXRobmFtZSIsImhvc3QiLCJidWlsZFVybCIsIm9iajEiLCJvYmoyIiwiY2hlY2tUeXBlcyIsInByb3BzMSIsIl9sZW4yIiwic291cmNlcyIsIl9rZXkyIiwic291cmNlIiwic2hpZnQiLCJfbG9vcCIsImFkZEl0RmxhZyIsImN5cmI1M0hhc2giLCJzZWVkIiwiaW11bCIsIm9wQSIsIm9wQiIsImgxIiwiaDIiLCJjaCIsInNhZmVKU09OUGFyc2UiLCJzYWZlSlNPTkVuY29kZSIsIm1lbW9pemUiLCJhcmciLCJjYWNoZSIsImNhY2hlS2V5IiwiZ2V0VW5peFRpbWVzdGFtcEZyb21Ob3ciLCJ0aW1lVmFsdWUiLCJ0aW1lVW5pdCIsImFjY2VwdGFibGVVbml0cyIsIm11bHRpcGxpY2F0aW9uIiwiY29udmVydE9iamVjdFRvQXJyYXkiLCJzZXRTY3JpcHRBdHRyaWJ1dGVzIiwic2NyaXB0IiwiYXR0cmlidXRlcyIsInNldEF0dHJpYnV0ZSIsImJpbmFyeVNlYXJjaCIsImVsIiwibGVmdCIsInJpZ2h0IiwibWlkZGxlIiwicm91bmQiLCJoYXNOb25TZXJpYWxpemFibGVQcm9wZXJ0eSIsImNoZWNrZWRPYmplY3RzIiwic2V0T25BbnkiLCJjb2xsZWN0aW9uIiwiZXh0cmFjdERvbWFpbkZyb21Ib3N0IiwicGFnZUhvc3QiLCJkb21haW4iLCJkb21haW5zIiwiZXhlYyIsInRyaWdnZXJOdXJsV2l0aENwbSIsIm51cmwiLCJfY2xhc3NQcml2YXRlRmllbGRJbml0U3BlYyIsIl9jaGVja1ByaXZhdGVSZWRlY2xhcmF0aW9uIiwiX2NsYXNzUHJpdmF0ZUZpZWxkR2V0IiwicyIsIl9hc3NlcnRDbGFzc0JyYW5kIiwiX2NsYXNzUHJpdmF0ZUZpZWxkU2V0IiwiU1VDQ0VTUyIsIkZBSUwiLCJfcmVzdWx0IiwiX2NhbGxiYWNrcyIsImRlbGF5TXMiLCJyZXNvbHZlciIsImNhbGxiYWNrcyIsIm9uU3VjY2VzcyIsIm9uRXJyb3IiLCJjb250aW51YXRpb24iLCJyZXNvbHZlRm4iLCJjYXRjaCIsIm9uRmluYWxseSIsInJhY2UiLCJwcm9taXNlcyIsIl9jb2xsZWN0IiwiYWxsIiwiYWxsU2V0dGxlZCIsInN0YXR1cyIsInJlYXNvbiIsImNvbGxlY3RvciIsImNudCIsImNsdCIsImRlZmVyIiwicHJvbWlzZUZhY3RvcnkiLCJpbnZva2VyIiwiZGVsZWdhdGUiLCJyZWplY3RGbiIsInByb21pc2UiXSwic291cmNlUm9vdCI6IiJ9