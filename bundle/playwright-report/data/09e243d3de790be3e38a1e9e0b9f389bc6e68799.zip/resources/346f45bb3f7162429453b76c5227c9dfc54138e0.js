"use strict";
(self["webpackChunk_guardian_commercial_bundle"] = self["webpackChunk_guardian_commercial_bundle"] || []).push([["consentless-advertising"],{

/***/ "./src/init/consentless-advertising.ts":
/*!*********************************************!*\
  !*** ./src/init/consentless-advertising.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   bootConsentless: () => (/* binding */ bootConsentless)
/* harmony export */ });
/* harmony import */ var _lib_messenger__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../lib/messenger */ "./src/lib/messenger.ts");
/* harmony import */ var _lib_messenger_background__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/messenger/background */ "./src/lib/messenger/background.ts");
/* harmony import */ var _lib_messenger_resize__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../lib/messenger/resize */ "./src/lib/messenger/resize.ts");
/* harmony import */ var _lib_messenger_type__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../lib/messenger/type */ "./src/lib/messenger/type.ts");
/* harmony import */ var _consentless_dynamic_article_body_adverts__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./consentless/dynamic/article-body-adverts */ "./src/init/consentless/dynamic/article-body-adverts.ts");
/* harmony import */ var _consentless_dynamic_exclusion_slot__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./consentless/dynamic/exclusion-slot */ "./src/init/consentless/dynamic/exclusion-slot.ts");
/* harmony import */ var _consentless_init_fixed_slots__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./consentless/init-fixed-slots */ "./src/init/consentless/init-fixed-slots.ts");
/* harmony import */ var _consentless_prepare_ootag__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./consentless/prepare-ootag */ "./src/init/consentless/prepare-ootag.ts");
/* harmony import */ var _shared_reload_page_on_consent_change__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./shared/reload-page-on-consent-change */ "./src/init/shared/reload-page-on-consent-change.ts");
/* harmony import */ var _shared_set_adtest_cookie__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./shared/set-adtest-cookie */ "./src/init/shared/set-adtest-cookie.ts");
/* harmony import */ var _shared_set_adtest_in_labels_cookie__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./shared/set-adtest-in-labels-cookie */ "./src/init/shared/set-adtest-in-labels-cookie.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }











var bootConsentless = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* (consentState) {
    var consentlessModuleList = [(0,_lib_messenger__WEBPACK_IMPORTED_MODULE_0__.init)([_lib_messenger_background__WEBPACK_IMPORTED_MODULE_1__.init, _lib_messenger_resize__WEBPACK_IMPORTED_MODULE_2__.init, _lib_messenger_type__WEBPACK_IMPORTED_MODULE_3__.init], []), (0,_shared_set_adtest_cookie__WEBPACK_IMPORTED_MODULE_9__.init)(), (0,_shared_set_adtest_in_labels_cookie__WEBPACK_IMPORTED_MODULE_10__.init)(), (0,_consentless_prepare_ootag__WEBPACK_IMPORTED_MODULE_7__.initConsentless)(consentState), (0,_consentless_dynamic_exclusion_slot__WEBPACK_IMPORTED_MODULE_5__.initExclusionSlot)(), (0,_consentless_init_fixed_slots__WEBPACK_IMPORTED_MODULE_6__.initFixedSlots)(), (0,_consentless_dynamic_article_body_adverts__WEBPACK_IMPORTED_MODULE_4__.initArticleBodyAdverts)(), (0,_shared_reload_page_on_consent_change__WEBPACK_IMPORTED_MODULE_8__.reloadPageOnConsentChange)()];
    yield Promise.all(consentlessModuleList);
    // Since we're in single-request mode
    // Call this once all ad slots are present on the page
    window.ootag.makeRequests();
  });
  return function bootConsentless(_x) {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/init/consentless/define-slot.ts":
/*!*********************************************!*\
  !*** ./src/init/consentless/define-slot.ts ***!
  \*********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   defineSlot: () => (/* binding */ defineSlot)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! fastdom */ "../node_modules/.pnpm/fastdom@1.0.12/node_modules/fastdom/fastdom.js");
/* harmony import */ var fastdom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(fastdom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _events_empty_advert__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../events/empty-advert */ "./src/events/empty-advert.ts");
/* harmony import */ var _render_advert_label__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./render-advert-label */ "./src/init/consentless/render-advert-label.ts");




/**
 * Define an Opt Out Advertising slot
 *
 * @param slot The HTML element in which the ad will be inserted
 *
 * @param slotName The name of the slot.
 * This is Typically presented as the `data-name` attribute on server-side-rendered slots
 *
 * @param slotKind The kind of slot represents what group the slot belongs to.
 * This only applies to inline slots, where we have:
 * - `inline`: Inlines that sat within the content (liveblogs, fronts, `inline1` on articles)
 * - `inline-right`: Inlines that can float in the right column on articles
 */
var defineSlot = (slot, slotName, slotKind) => {
  var slotId = slot.id;
  var filledCallback = (_adSlot, _ref) => {
    var {
      width,
      height,
      optOutExt
    } = _ref;
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "Filled consentless ".concat(slotId));
    var isFluid = width === 1 && height === 1;
    if (isFluid) {
      slot.classList.add('ad-slot--fluid');
    }
    if (optOutExt.tags.includes('NATIVE')) {
      slot.classList.add('ad-slot--native');
    }
    if (optOutExt.tags.includes('NOLABEL')) {
      slot.classList.add('ad-slot--no-label');
    }
    void (0,_render_advert_label__WEBPACK_IMPORTED_MODULE_3__.renderConsentlessAdvertLabel)(slot);
  };
  var emptyCallback = () => {
    (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.log)('commercial', "Empty consentless ".concat(slotId));
    fastdom__WEBPACK_IMPORTED_MODULE_1___default().mutate(() => {
      (0,_events_empty_advert__WEBPACK_IMPORTED_MODULE_2__.removeSlotFromDom)(slot);
    });
  };
  window.ootag.queue.push(() => {
    // Associate the slot name with each slot's targeting
    // Note we use the name as the value, but we associate it with a given slot id
    // For example for ad with id `dfp-ad--inline1` we add `slot=inline1`
    window.ootag.addParameterForSlot(slotId, 'slot', slotName);
    window.ootag.defineSlot({
      // Used to identify slots defined in the Opt Out interface
      // If a kind is present we use that, otherwise fall-back to the slot name
      adSlot: slotKind !== null && slotKind !== void 0 ? slotKind : slotName,
      targetId: slotId,
      id: slotId,
      filledCallback,
      emptyCallback
    });
  });
};


/***/ }),

/***/ "./src/init/consentless/dynamic/article-body-adverts.ts":
/*!**************************************************************!*\
  !*** ./src/init/consentless/dynamic/article-body-adverts.ts ***!
  \**************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initArticleBodyAdverts: () => (/* binding */ initArticleBodyAdverts)
/* harmony export */ });
/* harmony import */ var _insert_spacefinder_article__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../insert/spacefinder/article */ "./src/insert/spacefinder/article.ts");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _define_slot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../define-slot */ "./src/init/consentless/define-slot.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }




var fillConsentlessAdSlot = (name, slot) => {
  var isMobile = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_2__.getCurrentBreakpoint)() === 'mobile';
  var slotKind = isMobile || name === 'inline1' ? 'inline' : 'inline-right';
  (0,_define_slot__WEBPACK_IMPORTED_MODULE_3__.defineSlot)(slot, name, slotKind);
  return Promise.resolve();
};
var initArticleBodyAdverts = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    // do we need to rerun for the sign-in gate?
    if (!_lib_commercial_features__WEBPACK_IMPORTED_MODULE_1__.commercialFeatures.articleBodyAdverts) {
      return;
    }
    yield (0,_insert_spacefinder_article__WEBPACK_IMPORTED_MODULE_0__.addInlineAds)(fillConsentlessAdSlot, true);
  });
  return function initArticleBodyAdverts() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/init/consentless/dynamic/exclusion-slot.ts":
/*!********************************************************!*\
  !*** ./src/init/consentless/dynamic/exclusion-slot.ts ***!
  \********************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initExclusionSlot: () => (/* binding */ initExclusionSlot)
/* harmony export */ });
/* harmony import */ var _lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../../lib/create-ad-slot */ "./src/lib/create-ad-slot.ts");
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");
/* harmony import */ var _define_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../define-slot */ "./src/init/consentless/define-slot.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }



/**
 * This is responsible for inserting an _exclusion_ ad slot into the DOM
 *
 * This is a special type of ad which, when filled, blocks
 * all other ads on the page. This allows us to run "exclusion
 * campaigns" against certain breaking news pages.
 *
 * Exclusion ads are used for consentless advertising only.
 * GAM has a different mechanism to achieve the same thing.
 */
var initExclusionSlot = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    var adSlot = (0,_lib_create_ad_slot__WEBPACK_IMPORTED_MODULE_0__.createAdSlot)('exclusion');
    // Insert the slot into the body of the page
    // It doesn't particularly matter where we insert it, since it doesn't render anything
    yield _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_1__["default"].mutate(() => document.body.appendChild(adSlot));
    (0,_define_slot__WEBPACK_IMPORTED_MODULE_2__.defineSlot)(adSlot, 'exclusion');
  });
  return function initExclusionSlot() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/init/consentless/init-fixed-slots.ts":
/*!**************************************************!*\
  !*** ./src/init/consentless/init-fixed-slots.ts ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initFixedSlots: () => (/* binding */ initFixedSlots)
/* harmony export */ });
/* harmony import */ var _lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/detect/detect-breakpoint */ "./src/lib/detect/detect-breakpoint.ts");
/* harmony import */ var _consented_remove_slots__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../consented/remove-slots */ "./src/init/consented/remove-slots.ts");
/* harmony import */ var _define_slot__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./define-slot */ "./src/init/consentless/define-slot.ts");
function asyncGeneratorStep(n, t, e, r, o, a, c) { try { var i = n[a](c), u = i.value; } catch (n) { return void e(n); } i.done ? t(u) : Promise.resolve(u).then(r, o); }
function _asyncToGenerator(n) { return function () { var t = this, e = arguments; return new Promise(function (r, o) { var a = n.apply(t, e); function _next(n) { asyncGeneratorStep(a, r, o, _next, _throw, "next", n); } function _throw(n) { asyncGeneratorStep(a, r, o, _next, _throw, "throw", n); } _next(void 0); }); }; }



var isTabletOrMobile = () => {
  var breakpoint = (0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_0__.getCurrentBreakpoint)();
  return breakpoint === 'mobile' || breakpoint === 'tablet';
};
var initFixedSlots = /*#__PURE__*/function () {
  var _ref = _asyncToGenerator(function* () {
    yield (0,_consented_remove_slots__WEBPACK_IMPORTED_MODULE_1__.removeDisabledSlots)();
    // We remove top-above-nav on both tablet and mobile for consentless
    // due to issues with ad sizing in OptOut at the tablet breakpoint
    var isDCRMobileOrTablet = window.guardian.config.isDotcomRendering && isTabletOrMobile();
    var adverts = [...document.querySelectorAll('.js-ad-slot:not(.ad-slot--survey)')]
    // we need to not init top-above-nav on mobile and tablet view in DCR
    // as the DOM element needs to be removed and replaced to be inline
    .filter(adSlot => !(isDCRMobileOrTablet && adSlot.id === 'dfp-ad--top-above-nav'));
    if ((0,_lib_detect_detect_breakpoint__WEBPACK_IMPORTED_MODULE_0__.getCurrentBreakpoint)() === 'tablet') {
      // We need to explicitly remove the element as there are no styles to hide it on tablet
      var topAboveNav = document.querySelector('.top-banner-ad-container');
      topAboveNav === null || topAboveNav === void 0 || topAboveNav.remove();
    }
    // define slots
    adverts.forEach(slotElement => {
      var slotName = slotElement.dataset.name;
      var slotKind = slotName !== null && slotName !== void 0 && slotName.includes('inline') ? 'inline' : undefined;
      if (slotName) {
        (0,_define_slot__WEBPACK_IMPORTED_MODULE_2__.defineSlot)(slotElement, slotName, slotKind);
      }
    });
    return Promise.resolve();
  });
  return function initFixedSlots() {
    return _ref.apply(this, arguments);
  };
}();


/***/ }),

/***/ "./src/init/consentless/prepare-ootag.ts":
/*!***********************************************!*\
  !*** ./src/init/consentless/prepare-ootag.ts ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   initConsentless: () => (/* binding */ initConsentless)
/* harmony export */ });
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/loadScript/loadScript.js");
/* harmony import */ var _guardian_libs__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @guardian/libs */ "../node_modules/.pnpm/@guardian+libs@25.2.0_@guardian+ophan-tracker-js@2.4.0_tslib@2.8.1_typescript@5.8.3/node_modules/@guardian/libs/dist/logger/logger.js");
/* harmony import */ var _lib_commercial_features__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../lib/commercial-features */ "./src/lib/commercial-features.ts");
/* harmony import */ var _lib_identity_api__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../lib/identity/api */ "./src/lib/identity/api.ts");
/* harmony import */ var _lib_targeting_build_page_targeting_consentless__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../lib/targeting/build-page-targeting-consentless */ "./src/lib/targeting/build-page-targeting-consentless.ts");




function initConsentless(consentState) {
  return new Promise(resolve => {
    // Stub the command queue
    // @ts-expect-error -- it’s a stub, not the whole OO tag object
    window.ootag = {
      queue: []
    };
    window.ootag.queue.push(function () {
      // Ensures Opt Out logs are namespaced under Commercial
      window.ootag.logger = function () {
        for (var _len = arguments.length, args = new Array(_len), _key = 0; _key < _len; _key++) {
          args[_key] = arguments[_key];
        }
        (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_1__.log)('commercial', '[Opt Out Ads]', ...args);
      };
      window.ootag.initializeOo({
        publisher: 33,
        // We set our own custom logger above
        noLogging: 1,
        alwaysNoConsent: 1,
        noRequestsOnPageLoad: 1
      });
      void (0,_lib_identity_api__WEBPACK_IMPORTED_MODULE_3__.isUserLoggedIn)().then(isSignedIn => {
        Object.entries((0,_lib_targeting_build_page_targeting_consentless__WEBPACK_IMPORTED_MODULE_4__.buildPageTargetingConsentless)(consentState, _lib_commercial_features__WEBPACK_IMPORTED_MODULE_2__.commercialFeatures.adFree, isSignedIn)).forEach(_ref => {
          var [key, value] = _ref;
          if (!value) {
            return;
          }
          window.ootag.addParameter(key, value);
        });
        resolve();
      });
    });
    void (0,_guardian_libs__WEBPACK_IMPORTED_MODULE_0__.loadScript)('//cdn.optoutadvertising.com/script/ooguardian.v4.min.js');
  });
}


/***/ }),

/***/ "./src/init/consentless/render-advert-label.ts":
/*!*****************************************************!*\
  !*** ./src/init/consentless/render-advert-label.ts ***!
  \*****************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   renderConsentlessAdvertLabel: () => (/* binding */ renderConsentlessAdvertLabel)
/* harmony export */ });
/* harmony import */ var _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../lib/fastdom-promise */ "./src/lib/fastdom-promise.ts");

var shouldRenderConsentlessLabel = adSlotNode => {
  if (adSlotNode.classList.contains('ad-slot--frame') || adSlotNode.classList.contains('ad-slot--gc') || adSlotNode.classList.contains('u-h') || adSlotNode.classList.contains('ad-slot--no-label') ||
  // set for out-of-page (1x1) and empty (2x2) ads
  adSlotNode.classList.contains('ad-slot--collapse') || adSlotNode.getAttribute('data-label') === 'false') {
    return false;
  }
  return true;
};
var renderConsentlessAdvertLabel = adSlotNode => {
  return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_0__["default"].measure(() => {
    if (shouldRenderConsentlessLabel(adSlotNode)) {
      //Assigning the ad label text like this allows us to conditionally add extra text to it
      //eg. for the ad test labelling for google ads
      var adLabelContent = "Advertisement";
      return _lib_fastdom_promise__WEBPACK_IMPORTED_MODULE_0__["default"].mutate(() => {
        //when the time comes to use a different ad label for consentless, we can update
        //the attribute name that we set below and add a css selector accordingly
        adSlotNode.setAttribute('data-label-show', 'true');
        adSlotNode.setAttribute('ad-label-text', adLabelContent);
      });
    }
    return Promise.resolve();
  });
};
// TODO: flesh out this function once we have a better idea of what we want it to look like
// const insertConsentlessLabelInfo = (adLabelNode: HTMLElement): void => {
// 	const consentlessLabelInfo = document.createElement('button');
// 	consentlessLabelInfo.className = 'ad-slot__consentless-info u-button-reset';
// 	consentlessLabelInfo.setAttribute(
// 		'title',
// 		`Because of your choice this advertising sets no cookies and doesn't track you.`,
// 	);
// 	consentlessLabelInfo.innerHTML = `Opt Out: Why am I seeing this?`;
// 	adLabelNode.appendChild(consentlessLabelInfo);
// };

/***/ }),

/***/ "./src/lib/targeting/build-page-targeting-consentless.ts":
/*!***************************************************************!*\
  !*** ./src/lib/targeting/build-page-targeting-consentless.ts ***!
  \***************************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   buildPageTargetingConsentless: () => (/* binding */ buildPageTargetingConsentless)
/* harmony export */ });
/* harmony import */ var _guardian_commercial_core_targeting_build_page_targeting__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @guardian/commercial-core/targeting/build-page-targeting */ "../core/src/targeting/build-page-targeting.ts");

var consentlessTargetingKeys = ['ab', 'at', 'bl', 'bp', 'br', 'cc', 'lh', 'ct', 'dcre', 'edition', 'firstvisit', 'k', 'rc', 'rp', 's', 'se', 'sens', 'sh', 'si', 'skinsize', 'su', 'tn', 'url', 'urlkw'];
var isConsentlessKey = key => consentlessTargetingKeys.includes(key);
/**
 * Call buildPageTargeting then filter out the keys that are not needed for
 * consentless targeting.
 *
 * @param  {ConsentState} consentState
 * @param  {boolean} adFree
 * @param  {boolean} isSignedIn
 * @returns ConsentlessPageTargeting
 */
var buildPageTargetingConsentless = (consentState, adFree, isSignedIn) => {
  var consentedPageTargeting = (0,_guardian_commercial_core_targeting_build_page_targeting__WEBPACK_IMPORTED_MODULE_0__.buildPageTargeting)({
    adFree,
    consentState,
    clientSideParticipations: {},
    isSignedIn
  });
  return Object.fromEntries(Object.entries(consentedPageTargeting).filter(_ref => {
    var [k] = _ref;
    return isConsentlessKey(k);
  }));
};


/***/ })

}]);
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZ3JhdW4uY29uc2VudGxlc3MtYWR2ZXJ0aXNpbmcuY29tbWVyY2lhbC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUF5RDtBQUNRO0FBQ1I7QUFDSjtBQUMrQjtBQUNYO0FBQ1Q7QUFDRjtBQUNxQjtBQUNkO0FBQ2tCO0FBQ3ZGLElBQU1ZLGVBQWU7RUFBQSxJQUFBQyxJQUFBLEdBQUFDLGlCQUFBLENBQUcsV0FBT0MsWUFBWSxFQUFLO0lBQzVDLElBQU1DLHFCQUFxQixHQUFHLENBQzFCZixvREFBYSxDQUFDLENBQUNDLDJEQUFVLEVBQUVDLHVEQUFNLEVBQUVDLHFEQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsRUFDN0NNLCtEQUFlLENBQUMsQ0FBQyxFQUNqQkMsMEVBQXVCLENBQUMsQ0FBQyxFQUN6QkgsMkVBQWUsQ0FBQ08sWUFBWSxDQUFDLEVBQzdCVCxzRkFBaUIsQ0FBQyxDQUFDLEVBQ25CQyw2RUFBYyxDQUFDLENBQUMsRUFDaEJGLGlHQUFzQixDQUFDLENBQUMsRUFDeEJJLGdHQUF5QixDQUFDLENBQUMsQ0FDOUI7SUFDRCxNQUFNUSxPQUFPLENBQUNDLEdBQUcsQ0FBQ0YscUJBQXFCLENBQUM7SUFDeEM7SUFDQTtJQUNBRyxNQUFNLENBQUNDLEtBQUssQ0FBQ0MsWUFBWSxDQUFDLENBQUM7RUFDL0IsQ0FBQztFQUFBLGdCQWZLVCxlQUFlQSxDQUFBVSxFQUFBO0lBQUEsT0FBQVQsSUFBQSxDQUFBVSxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBZXBCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzFCb0M7QUFDUDtBQUNnQztBQUNPO0FBQ3JFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsSUFBTUssVUFBVSxHQUFHQSxDQUFDQyxJQUFJLEVBQUVDLFFBQVEsRUFBRUMsUUFBUSxLQUFLO0VBQzdDLElBQU1DLE1BQU0sR0FBR0gsSUFBSSxDQUFDSSxFQUFFO0VBQ3RCLElBQU1DLGNBQWMsR0FBR0EsQ0FBQ0MsT0FBTyxFQUFBdkIsSUFBQSxLQUFtQztJQUFBLElBQWpDO01BQUV3QixLQUFLO01BQUVDLE1BQU07TUFBRUM7SUFBVSxDQUFDLEdBQUExQixJQUFBO0lBQ3pEWSxtREFBRyxDQUFDLFlBQVksd0JBQUFlLE1BQUEsQ0FBd0JQLE1BQU0sQ0FBRSxDQUFDO0lBQ2pELElBQU1RLE9BQU8sR0FBR0osS0FBSyxLQUFLLENBQUMsSUFBSUMsTUFBTSxLQUFLLENBQUM7SUFDM0MsSUFBSUcsT0FBTyxFQUFFO01BQ1RYLElBQUksQ0FBQ1ksU0FBUyxDQUFDQyxHQUFHLENBQUMsZ0JBQWdCLENBQUM7SUFDeEM7SUFDQSxJQUFJSixTQUFTLENBQUNLLElBQUksQ0FBQ0MsUUFBUSxDQUFDLFFBQVEsQ0FBQyxFQUFFO01BQ25DZixJQUFJLENBQUNZLFNBQVMsQ0FBQ0MsR0FBRyxDQUFDLGlCQUFpQixDQUFDO0lBQ3pDO0lBQ0EsSUFBSUosU0FBUyxDQUFDSyxJQUFJLENBQUNDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRTtNQUNwQ2YsSUFBSSxDQUFDWSxTQUFTLENBQUNDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQztJQUMzQztJQUNBLEtBQUtmLGtGQUE0QixDQUFDRSxJQUFJLENBQUM7RUFDM0MsQ0FBQztFQUNELElBQU1nQixhQUFhLEdBQUdBLENBQUEsS0FBTTtJQUN4QnJCLG1EQUFHLENBQUMsWUFBWSx1QkFBQWUsTUFBQSxDQUF1QlAsTUFBTSxDQUFFLENBQUM7SUFDaERQLHFEQUFjLENBQUMsTUFBTTtNQUNqQkMsdUVBQWlCLENBQUNHLElBQUksQ0FBQztJQUMzQixDQUFDLENBQUM7RUFDTixDQUFDO0VBQ0RYLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDNEIsS0FBSyxDQUFDQyxJQUFJLENBQUMsTUFBTTtJQUMxQjtJQUNBO0lBQ0E7SUFDQTlCLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDOEIsbUJBQW1CLENBQUNqQixNQUFNLEVBQUUsTUFBTSxFQUFFRixRQUFRLENBQUM7SUFDMURaLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDUyxVQUFVLENBQUM7TUFDcEI7TUFDQTtNQUNBc0IsTUFBTSxFQUFFbkIsUUFBUSxhQUFSQSxRQUFRLGNBQVJBLFFBQVEsR0FBSUQsUUFBUTtNQUM1QnFCLFFBQVEsRUFBRW5CLE1BQU07TUFDaEJDLEVBQUUsRUFBRUQsTUFBTTtNQUNWRSxjQUFjO01BQ2RXO0lBQ0osQ0FBQyxDQUFDO0VBQ04sQ0FBQyxDQUFDO0FBQ04sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdERrRTtBQUNHO0FBQ087QUFDakM7QUFDNUMsSUFBTVUscUJBQXFCLEdBQUdBLENBQUNDLElBQUksRUFBRTNCLElBQUksS0FBSztFQUMxQyxJQUFNNEIsUUFBUSxHQUFHSCxtRkFBb0IsQ0FBQyxDQUFDLEtBQUssUUFBUTtFQUNwRCxJQUFNdkIsUUFBUSxHQUFHMEIsUUFBUSxJQUFJRCxJQUFJLEtBQUssU0FBUyxHQUFHLFFBQVEsR0FBRyxjQUFjO0VBQzNFNUIsd0RBQVUsQ0FBQ0MsSUFBSSxFQUFFMkIsSUFBSSxFQUFFekIsUUFBUSxDQUFDO0VBQ2hDLE9BQU9mLE9BQU8sQ0FBQzBDLE9BQU8sQ0FBQyxDQUFDO0FBQzVCLENBQUM7QUFDRCxJQUFNdEQsc0JBQXNCO0VBQUEsSUFBQVEsSUFBQSxHQUFBQyxpQkFBQSxDQUFHLGFBQVk7SUFDdkM7SUFDQSxJQUFJLENBQUN3Qyx3RUFBa0IsQ0FBQ00sa0JBQWtCLEVBQUU7TUFDeEM7SUFDSjtJQUNBLE1BQU1QLHlFQUFZLENBQUNHLHFCQUFxQixFQUFFLElBQUksQ0FBQztFQUNuRCxDQUFDO0VBQUEsZ0JBTktuRCxzQkFBc0JBLENBQUE7SUFBQSxPQUFBUSxJQUFBLENBQUFVLEtBQUEsT0FBQUMsU0FBQTtFQUFBO0FBQUEsR0FNM0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDaEIwRDtBQUNSO0FBQ1A7QUFDNUM7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxJQUFNbEIsaUJBQWlCO0VBQUEsSUFBQU8sSUFBQSxHQUFBQyxpQkFBQSxDQUFHLGFBQVk7SUFDbEMsSUFBTXFDLE1BQU0sR0FBR1UsaUVBQVksQ0FBQyxXQUFXLENBQUM7SUFDeEM7SUFDQTtJQUNBLE1BQU1uQyw0REFBTyxDQUFDcUIsTUFBTSxDQUFDLE1BQU1lLFFBQVEsQ0FBQ0MsSUFBSSxDQUFDQyxXQUFXLENBQUNiLE1BQU0sQ0FBQyxDQUFDO0lBQzdEdEIsd0RBQVUsQ0FBQ3NCLE1BQU0sRUFBRSxXQUFXLENBQUM7RUFDbkMsQ0FBQztFQUFBLGdCQU5LN0MsaUJBQWlCQSxDQUFBO0lBQUEsT0FBQU8sSUFBQSxDQUFBVSxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBTXRCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25CeUU7QUFDVjtBQUNyQjtBQUMzQyxJQUFNMEMsZ0JBQWdCLEdBQUdBLENBQUEsS0FBTTtFQUMzQixJQUFNQyxVQUFVLEdBQUdaLG1GQUFvQixDQUFDLENBQUM7RUFDekMsT0FBT1ksVUFBVSxLQUFLLFFBQVEsSUFBSUEsVUFBVSxLQUFLLFFBQVE7QUFDN0QsQ0FBQztBQUNELElBQU01RCxjQUFjO0VBQUEsSUFBQU0sSUFBQSxHQUFBQyxpQkFBQSxDQUFHLGFBQVk7SUFDL0IsTUFBTW1ELDRFQUFtQixDQUFDLENBQUM7SUFDM0I7SUFDQTtJQUNBLElBQU1HLG1CQUFtQixHQUFHakQsTUFBTSxDQUFDa0QsUUFBUSxDQUFDQyxNQUFNLENBQUNDLGlCQUFpQixJQUFJTCxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzFGLElBQU1NLE9BQU8sR0FBRyxDQUNaLEdBQUdWLFFBQVEsQ0FBQ1csZ0JBQWdCLENBQUMsbUNBQW1DLENBQUM7SUFFakU7SUFDQTtJQUFBLENBQ0NDLE1BQU0sQ0FBRXZCLE1BQU0sSUFBSyxFQUFFaUIsbUJBQW1CLElBQUlqQixNQUFNLENBQUNqQixFQUFFLEtBQUssdUJBQXVCLENBQUMsQ0FBQztJQUN4RixJQUFJcUIsbUZBQW9CLENBQUMsQ0FBQyxLQUFLLFFBQVEsRUFBRTtNQUNyQztNQUNBLElBQU1vQixXQUFXLEdBQUdiLFFBQVEsQ0FBQ2MsYUFBYSxDQUFDLDBCQUEwQixDQUFDO01BQ3RFRCxXQUFXLGFBQVhBLFdBQVcsZUFBWEEsV0FBVyxDQUFFRSxNQUFNLENBQUMsQ0FBQztJQUN6QjtJQUNBO0lBQ0FMLE9BQU8sQ0FBQ00sT0FBTyxDQUFFQyxXQUFXLElBQUs7TUFDN0IsSUFBTWhELFFBQVEsR0FBR2dELFdBQVcsQ0FBQ0MsT0FBTyxDQUFDdkIsSUFBSTtNQUN6QyxJQUFNekIsUUFBUSxHQUFHRCxRQUFRLGFBQVJBLFFBQVEsZUFBUkEsUUFBUSxDQUFFYyxRQUFRLENBQUMsUUFBUSxDQUFDLEdBQUcsUUFBUSxHQUFHb0MsU0FBUztNQUNwRSxJQUFJbEQsUUFBUSxFQUFFO1FBQ1ZGLHdEQUFVLENBQUNrRCxXQUFXLEVBQUVoRCxRQUFRLEVBQUVDLFFBQVEsQ0FBQztNQUMvQztJQUNKLENBQUMsQ0FBQztJQUNGLE9BQU9mLE9BQU8sQ0FBQzBDLE9BQU8sQ0FBQyxDQUFDO0VBQzVCLENBQUM7RUFBQSxnQkF6QktwRCxjQUFjQSxDQUFBO0lBQUEsT0FBQU0sSUFBQSxDQUFBVSxLQUFBLE9BQUFDLFNBQUE7RUFBQTtBQUFBLEdBeUJuQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoQ2dEO0FBQ2tCO0FBQ1g7QUFDNkM7QUFDckcsU0FBU2hCLGVBQWVBLENBQUNPLFlBQVksRUFBRTtFQUNuQyxPQUFPLElBQUlFLE9BQU8sQ0FBRTBDLE9BQU8sSUFBSztJQUM1QjtJQUNBO0lBQ0F4QyxNQUFNLENBQUNDLEtBQUssR0FBRztNQUNYNEIsS0FBSyxFQUFFO0lBQ1gsQ0FBQztJQUNEN0IsTUFBTSxDQUFDQyxLQUFLLENBQUM0QixLQUFLLENBQUNDLElBQUksQ0FBQyxZQUFZO01BQ2hDO01BQ0E5QixNQUFNLENBQUNDLEtBQUssQ0FBQ2lFLE1BQU0sR0FBRyxZQUFhO1FBQUEsU0FBQUMsSUFBQSxHQUFBOUQsU0FBQSxDQUFBK0QsTUFBQSxFQUFUQyxJQUFJLE9BQUFDLEtBQUEsQ0FBQUgsSUFBQSxHQUFBSSxJQUFBLE1BQUFBLElBQUEsR0FBQUosSUFBQSxFQUFBSSxJQUFBO1VBQUpGLElBQUksQ0FBQUUsSUFBQSxJQUFBbEUsU0FBQSxDQUFBa0UsSUFBQTtRQUFBO1FBQzFCakUsbURBQUcsQ0FBQyxZQUFZLEVBQUUsZUFBZSxFQUFFLEdBQUcrRCxJQUFJLENBQUM7TUFDL0MsQ0FBQztNQUNEckUsTUFBTSxDQUFDQyxLQUFLLENBQUN1RSxZQUFZLENBQUM7UUFDdEJDLFNBQVMsRUFBRSxFQUFFO1FBQ2I7UUFDQUMsU0FBUyxFQUFFLENBQUM7UUFDWkMsZUFBZSxFQUFFLENBQUM7UUFDbEJDLG9CQUFvQixFQUFFO01BQzFCLENBQUMsQ0FBQztNQUNGLEtBQUtaLGlFQUFjLENBQUMsQ0FBQyxDQUFDYSxJQUFJLENBQUVDLFVBQVUsSUFBSztRQUN2Q0MsTUFBTSxDQUFDQyxPQUFPLENBQUNmLDhHQUE2QixDQUFDckUsWUFBWSxFQUFFdUMsd0VBQWtCLENBQUM4QyxNQUFNLEVBQUVILFVBQVUsQ0FBQyxDQUFDLENBQUNuQixPQUFPLENBQUNqRSxJQUFBLElBQWtCO1VBQUEsSUFBakIsQ0FBQ3dGLEdBQUcsRUFBRUMsS0FBSyxDQUFDLEdBQUF6RixJQUFBO1VBQ3BILElBQUksQ0FBQ3lGLEtBQUssRUFBRTtZQUNSO1VBQ0o7VUFDQW5GLE1BQU0sQ0FBQ0MsS0FBSyxDQUFDbUYsWUFBWSxDQUFDRixHQUFHLEVBQUVDLEtBQUssQ0FBQztRQUN6QyxDQUFDLENBQUM7UUFDRjNDLE9BQU8sQ0FBQyxDQUFDO01BQ2IsQ0FBQyxDQUFDO0lBQ04sQ0FBQyxDQUFDO0lBQ0YsS0FBS3VCLDBEQUFVLENBQUMseURBQXlELENBQUM7RUFDOUUsQ0FBQyxDQUFDO0FBQ047Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ2dEO0FBQ2hELElBQU1zQiw0QkFBNEIsR0FBSUMsVUFBVSxJQUFLO0VBQ2pELElBQUlBLFVBQVUsQ0FBQy9ELFNBQVMsQ0FBQ2dFLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUMvQ0QsVUFBVSxDQUFDL0QsU0FBUyxDQUFDZ0UsUUFBUSxDQUFDLGFBQWEsQ0FBQyxJQUM1Q0QsVUFBVSxDQUFDL0QsU0FBUyxDQUFDZ0UsUUFBUSxDQUFDLEtBQUssQ0FBQyxJQUNwQ0QsVUFBVSxDQUFDL0QsU0FBUyxDQUFDZ0UsUUFBUSxDQUFDLG1CQUFtQixDQUFDO0VBQ2xEO0VBQ0FELFVBQVUsQ0FBQy9ELFNBQVMsQ0FBQ2dFLFFBQVEsQ0FBQyxtQkFBbUIsQ0FBQyxJQUNsREQsVUFBVSxDQUFDRSxZQUFZLENBQUMsWUFBWSxDQUFDLEtBQUssT0FBTyxFQUFFO0lBQ25ELE9BQU8sS0FBSztFQUNoQjtFQUNBLE9BQU8sSUFBSTtBQUNmLENBQUM7QUFDTSxJQUFNL0UsNEJBQTRCLEdBQUk2RSxVQUFVLElBQUs7RUFDeEQsT0FBTy9FLDREQUFPLENBQUNrRixPQUFPLENBQUMsTUFBTTtJQUN6QixJQUFJSiw0QkFBNEIsQ0FBQ0MsVUFBVSxDQUFDLEVBQUU7TUFDMUM7TUFDQTtNQUNBLElBQU1JLGNBQWMsa0JBQWtCO01BQ3RDLE9BQU9uRiw0REFBTyxDQUFDcUIsTUFBTSxDQUFDLE1BQU07UUFDeEI7UUFDQTtRQUNBMEQsVUFBVSxDQUFDSyxZQUFZLENBQUMsaUJBQWlCLEVBQUUsTUFBTSxDQUFDO1FBQ2xETCxVQUFVLENBQUNLLFlBQVksQ0FBQyxlQUFlLEVBQUVELGNBQWMsQ0FBQztNQUM1RCxDQUFDLENBQUM7SUFDTjtJQUNBLE9BQU81RixPQUFPLENBQUMwQyxPQUFPLENBQUMsQ0FBQztFQUM1QixDQUFDLENBQUM7QUFDTixDQUFDO0FBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxLOzs7Ozs7Ozs7Ozs7Ozs7QUN2QytGO0FBQy9GLElBQU1xRCx3QkFBd0IsR0FBRyxDQUM3QixJQUFJLEVBQ0osSUFBSSxFQUNKLElBQUksRUFDSixJQUFJLEVBQ0osSUFBSSxFQUNKLElBQUksRUFDSixJQUFJLEVBQ0osSUFBSSxFQUNKLE1BQU0sRUFDTixTQUFTLEVBQ1QsWUFBWSxFQUNaLEdBQUcsRUFDSCxJQUFJLEVBQ0osSUFBSSxFQUNKLEdBQUcsRUFDSCxJQUFJLEVBQ0osTUFBTSxFQUNOLElBQUksRUFDSixJQUFJLEVBQ0osVUFBVSxFQUNWLElBQUksRUFDSixJQUFJLEVBQ0osS0FBSyxFQUNMLE9BQU8sQ0FDVjtBQUNELElBQU1DLGdCQUFnQixHQUFJWixHQUFHLElBQUtXLHdCQUF3QixDQUFDbkUsUUFBUSxDQUFDd0QsR0FBRyxDQUFDO0FBQ3hFO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQU1qQiw2QkFBNkIsR0FBR0EsQ0FBQ3JFLFlBQVksRUFBRXFGLE1BQU0sRUFBRUgsVUFBVSxLQUFLO0VBQ3hFLElBQU1pQixzQkFBc0IsR0FBR0gsNEdBQWtCLENBQUM7SUFDOUNYLE1BQU07SUFDTnJGLFlBQVk7SUFDWm9HLHdCQUF3QixFQUFFLENBQUMsQ0FBQztJQUM1QmxCO0VBQ0osQ0FBQyxDQUFDO0VBQ0YsT0FBT0MsTUFBTSxDQUFDa0IsV0FBVyxDQUFDbEIsTUFBTSxDQUFDQyxPQUFPLENBQUNlLHNCQUFzQixDQUFDLENBQUN4QyxNQUFNLENBQUM3RCxJQUFBO0lBQUEsSUFBQyxDQUFDd0csQ0FBQyxDQUFDLEdBQUF4RyxJQUFBO0lBQUEsT0FBS29HLGdCQUFnQixDQUFDSSxDQUFDLENBQUM7RUFBQSxFQUFDLENBQUM7QUFDMUcsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRsZXNzLWFkdmVydGlzaW5nLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRsZXNzL2RlZmluZS1zbG90LnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRsZXNzL2R5bmFtaWMvYXJ0aWNsZS1ib2R5LWFkdmVydHMudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGxlc3MvZHluYW1pYy9leGNsdXNpb24tc2xvdC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvaW5pdC9jb25zZW50bGVzcy9pbml0LWZpeGVkLXNsb3RzLnRzIiwid2VicGFjazovL0BndWFyZGlhbi9jb21tZXJjaWFsLWJ1bmRsZS8uL3NyYy9pbml0L2NvbnNlbnRsZXNzL3ByZXBhcmUtb290YWcudHMiLCJ3ZWJwYWNrOi8vQGd1YXJkaWFuL2NvbW1lcmNpYWwtYnVuZGxlLy4vc3JjL2luaXQvY29uc2VudGxlc3MvcmVuZGVyLWFkdmVydC1sYWJlbC50cyIsIndlYnBhY2s6Ly9AZ3VhcmRpYW4vY29tbWVyY2lhbC1idW5kbGUvLi9zcmMvbGliL3RhcmdldGluZy9idWlsZC1wYWdlLXRhcmdldGluZy1jb25zZW50bGVzcy50cyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBpbml0IGFzIGluaXRNZXNzZW5nZXIgfSBmcm9tICcuLi9saWIvbWVzc2VuZ2VyJztcbmltcG9ydCB7IGluaXQgYXMgYmFja2dyb3VuZCB9IGZyb20gJy4uL2xpYi9tZXNzZW5nZXIvYmFja2dyb3VuZCc7XG5pbXBvcnQgeyBpbml0IGFzIHJlc2l6ZSB9IGZyb20gJy4uL2xpYi9tZXNzZW5nZXIvcmVzaXplJztcbmltcG9ydCB7IGluaXQgYXMgdHlwZSB9IGZyb20gJy4uL2xpYi9tZXNzZW5nZXIvdHlwZSc7XG5pbXBvcnQgeyBpbml0QXJ0aWNsZUJvZHlBZHZlcnRzIH0gZnJvbSAnLi9jb25zZW50bGVzcy9keW5hbWljL2FydGljbGUtYm9keS1hZHZlcnRzJztcbmltcG9ydCB7IGluaXRFeGNsdXNpb25TbG90IH0gZnJvbSAnLi9jb25zZW50bGVzcy9keW5hbWljL2V4Y2x1c2lvbi1zbG90JztcbmltcG9ydCB7IGluaXRGaXhlZFNsb3RzIH0gZnJvbSAnLi9jb25zZW50bGVzcy9pbml0LWZpeGVkLXNsb3RzJztcbmltcG9ydCB7IGluaXRDb25zZW50bGVzcyB9IGZyb20gJy4vY29uc2VudGxlc3MvcHJlcGFyZS1vb3RhZyc7XG5pbXBvcnQgeyByZWxvYWRQYWdlT25Db25zZW50Q2hhbmdlIH0gZnJvbSAnLi9zaGFyZWQvcmVsb2FkLXBhZ2Utb24tY29uc2VudC1jaGFuZ2UnO1xuaW1wb3J0IHsgaW5pdCBhcyBzZXRBZFRlc3RDb29raWUgfSBmcm9tICcuL3NoYXJlZC9zZXQtYWR0ZXN0LWNvb2tpZSc7XG5pbXBvcnQgeyBpbml0IGFzIHNldEFkVGVzdEluTGFiZWxzQ29va2llIH0gZnJvbSAnLi9zaGFyZWQvc2V0LWFkdGVzdC1pbi1sYWJlbHMtY29va2llJztcbmNvbnN0IGJvb3RDb25zZW50bGVzcyA9IGFzeW5jIChjb25zZW50U3RhdGUpID0+IHtcbiAgICBjb25zdCBjb25zZW50bGVzc01vZHVsZUxpc3QgPSBbXG4gICAgICAgIGluaXRNZXNzZW5nZXIoW2JhY2tncm91bmQsIHJlc2l6ZSwgdHlwZV0sIFtdKSxcbiAgICAgICAgc2V0QWRUZXN0Q29va2llKCksXG4gICAgICAgIHNldEFkVGVzdEluTGFiZWxzQ29va2llKCksXG4gICAgICAgIGluaXRDb25zZW50bGVzcyhjb25zZW50U3RhdGUpLFxuICAgICAgICBpbml0RXhjbHVzaW9uU2xvdCgpLFxuICAgICAgICBpbml0Rml4ZWRTbG90cygpLFxuICAgICAgICBpbml0QXJ0aWNsZUJvZHlBZHZlcnRzKCksXG4gICAgICAgIHJlbG9hZFBhZ2VPbkNvbnNlbnRDaGFuZ2UoKSxcbiAgICBdO1xuICAgIGF3YWl0IFByb21pc2UuYWxsKGNvbnNlbnRsZXNzTW9kdWxlTGlzdCk7XG4gICAgLy8gU2luY2Ugd2UncmUgaW4gc2luZ2xlLXJlcXVlc3QgbW9kZVxuICAgIC8vIENhbGwgdGhpcyBvbmNlIGFsbCBhZCBzbG90cyBhcmUgcHJlc2VudCBvbiB0aGUgcGFnZVxuICAgIHdpbmRvdy5vb3RhZy5tYWtlUmVxdWVzdHMoKTtcbn07XG5leHBvcnQgeyBib290Q29uc2VudGxlc3MgfTtcbiIsImltcG9ydCB7IGxvZyB9IGZyb20gJ0BndWFyZGlhbi9saWJzJztcbmltcG9ydCBmYXN0ZG9tIGZyb20gJ2Zhc3Rkb20nO1xuaW1wb3J0IHsgcmVtb3ZlU2xvdEZyb21Eb20gfSBmcm9tICcuLi8uLi9ldmVudHMvZW1wdHktYWR2ZXJ0JztcbmltcG9ydCB7IHJlbmRlckNvbnNlbnRsZXNzQWR2ZXJ0TGFiZWwgfSBmcm9tICcuL3JlbmRlci1hZHZlcnQtbGFiZWwnO1xuLyoqXG4gKiBEZWZpbmUgYW4gT3B0IE91dCBBZHZlcnRpc2luZyBzbG90XG4gKlxuICogQHBhcmFtIHNsb3QgVGhlIEhUTUwgZWxlbWVudCBpbiB3aGljaCB0aGUgYWQgd2lsbCBiZSBpbnNlcnRlZFxuICpcbiAqIEBwYXJhbSBzbG90TmFtZSBUaGUgbmFtZSBvZiB0aGUgc2xvdC5cbiAqIFRoaXMgaXMgVHlwaWNhbGx5IHByZXNlbnRlZCBhcyB0aGUgYGRhdGEtbmFtZWAgYXR0cmlidXRlIG9uIHNlcnZlci1zaWRlLXJlbmRlcmVkIHNsb3RzXG4gKlxuICogQHBhcmFtIHNsb3RLaW5kIFRoZSBraW5kIG9mIHNsb3QgcmVwcmVzZW50cyB3aGF0IGdyb3VwIHRoZSBzbG90IGJlbG9uZ3MgdG8uXG4gKiBUaGlzIG9ubHkgYXBwbGllcyB0byBpbmxpbmUgc2xvdHMsIHdoZXJlIHdlIGhhdmU6XG4gKiAtIGBpbmxpbmVgOiBJbmxpbmVzIHRoYXQgc2F0IHdpdGhpbiB0aGUgY29udGVudCAobGl2ZWJsb2dzLCBmcm9udHMsIGBpbmxpbmUxYCBvbiBhcnRpY2xlcylcbiAqIC0gYGlubGluZS1yaWdodGA6IElubGluZXMgdGhhdCBjYW4gZmxvYXQgaW4gdGhlIHJpZ2h0IGNvbHVtbiBvbiBhcnRpY2xlc1xuICovXG5jb25zdCBkZWZpbmVTbG90ID0gKHNsb3QsIHNsb3ROYW1lLCBzbG90S2luZCkgPT4ge1xuICAgIGNvbnN0IHNsb3RJZCA9IHNsb3QuaWQ7XG4gICAgY29uc3QgZmlsbGVkQ2FsbGJhY2sgPSAoX2FkU2xvdCwgeyB3aWR0aCwgaGVpZ2h0LCBvcHRPdXRFeHQgfSkgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBgRmlsbGVkIGNvbnNlbnRsZXNzICR7c2xvdElkfWApO1xuICAgICAgICBjb25zdCBpc0ZsdWlkID0gd2lkdGggPT09IDEgJiYgaGVpZ2h0ID09PSAxO1xuICAgICAgICBpZiAoaXNGbHVpZCkge1xuICAgICAgICAgICAgc2xvdC5jbGFzc0xpc3QuYWRkKCdhZC1zbG90LS1mbHVpZCcpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChvcHRPdXRFeHQudGFncy5pbmNsdWRlcygnTkFUSVZFJykpIHtcbiAgICAgICAgICAgIHNsb3QuY2xhc3NMaXN0LmFkZCgnYWQtc2xvdC0tbmF0aXZlJyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKG9wdE91dEV4dC50YWdzLmluY2x1ZGVzKCdOT0xBQkVMJykpIHtcbiAgICAgICAgICAgIHNsb3QuY2xhc3NMaXN0LmFkZCgnYWQtc2xvdC0tbm8tbGFiZWwnKTtcbiAgICAgICAgfVxuICAgICAgICB2b2lkIHJlbmRlckNvbnNlbnRsZXNzQWR2ZXJ0TGFiZWwoc2xvdCk7XG4gICAgfTtcbiAgICBjb25zdCBlbXB0eUNhbGxiYWNrID0gKCkgPT4ge1xuICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCBgRW1wdHkgY29uc2VudGxlc3MgJHtzbG90SWR9YCk7XG4gICAgICAgIGZhc3Rkb20ubXV0YXRlKCgpID0+IHtcbiAgICAgICAgICAgIHJlbW92ZVNsb3RGcm9tRG9tKHNsb3QpO1xuICAgICAgICB9KTtcbiAgICB9O1xuICAgIHdpbmRvdy5vb3RhZy5xdWV1ZS5wdXNoKCgpID0+IHtcbiAgICAgICAgLy8gQXNzb2NpYXRlIHRoZSBzbG90IG5hbWUgd2l0aCBlYWNoIHNsb3QncyB0YXJnZXRpbmdcbiAgICAgICAgLy8gTm90ZSB3ZSB1c2UgdGhlIG5hbWUgYXMgdGhlIHZhbHVlLCBidXQgd2UgYXNzb2NpYXRlIGl0IHdpdGggYSBnaXZlbiBzbG90IGlkXG4gICAgICAgIC8vIEZvciBleGFtcGxlIGZvciBhZCB3aXRoIGlkIGBkZnAtYWQtLWlubGluZTFgIHdlIGFkZCBgc2xvdD1pbmxpbmUxYFxuICAgICAgICB3aW5kb3cub290YWcuYWRkUGFyYW1ldGVyRm9yU2xvdChzbG90SWQsICdzbG90Jywgc2xvdE5hbWUpO1xuICAgICAgICB3aW5kb3cub290YWcuZGVmaW5lU2xvdCh7XG4gICAgICAgICAgICAvLyBVc2VkIHRvIGlkZW50aWZ5IHNsb3RzIGRlZmluZWQgaW4gdGhlIE9wdCBPdXQgaW50ZXJmYWNlXG4gICAgICAgICAgICAvLyBJZiBhIGtpbmQgaXMgcHJlc2VudCB3ZSB1c2UgdGhhdCwgb3RoZXJ3aXNlIGZhbGwtYmFjayB0byB0aGUgc2xvdCBuYW1lXG4gICAgICAgICAgICBhZFNsb3Q6IHNsb3RLaW5kID8/IHNsb3ROYW1lLFxuICAgICAgICAgICAgdGFyZ2V0SWQ6IHNsb3RJZCxcbiAgICAgICAgICAgIGlkOiBzbG90SWQsXG4gICAgICAgICAgICBmaWxsZWRDYWxsYmFjayxcbiAgICAgICAgICAgIGVtcHR5Q2FsbGJhY2ssXG4gICAgICAgIH0pO1xuICAgIH0pO1xufTtcbmV4cG9ydCB7IGRlZmluZVNsb3QgfTtcbiIsImltcG9ydCB7IGFkZElubGluZUFkcyB9IGZyb20gJy4uLy4uLy4uL2luc2VydC9zcGFjZWZpbmRlci9hcnRpY2xlJztcbmltcG9ydCB7IGNvbW1lcmNpYWxGZWF0dXJlcyB9IGZyb20gJy4uLy4uLy4uL2xpYi9jb21tZXJjaWFsLWZlYXR1cmVzJztcbmltcG9ydCB7IGdldEN1cnJlbnRCcmVha3BvaW50IH0gZnJvbSAnLi4vLi4vLi4vbGliL2RldGVjdC9kZXRlY3QtYnJlYWtwb2ludCc7XG5pbXBvcnQgeyBkZWZpbmVTbG90IH0gZnJvbSAnLi4vZGVmaW5lLXNsb3QnO1xuY29uc3QgZmlsbENvbnNlbnRsZXNzQWRTbG90ID0gKG5hbWUsIHNsb3QpID0+IHtcbiAgICBjb25zdCBpc01vYmlsZSA9IGdldEN1cnJlbnRCcmVha3BvaW50KCkgPT09ICdtb2JpbGUnO1xuICAgIGNvbnN0IHNsb3RLaW5kID0gaXNNb2JpbGUgfHwgbmFtZSA9PT0gJ2lubGluZTEnID8gJ2lubGluZScgOiAnaW5saW5lLXJpZ2h0JztcbiAgICBkZWZpbmVTbG90KHNsb3QsIG5hbWUsIHNsb3RLaW5kKTtcbiAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XG59O1xuY29uc3QgaW5pdEFydGljbGVCb2R5QWR2ZXJ0cyA9IGFzeW5jICgpID0+IHtcbiAgICAvLyBkbyB3ZSBuZWVkIHRvIHJlcnVuIGZvciB0aGUgc2lnbi1pbiBnYXRlP1xuICAgIGlmICghY29tbWVyY2lhbEZlYXR1cmVzLmFydGljbGVCb2R5QWR2ZXJ0cykge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGF3YWl0IGFkZElubGluZUFkcyhmaWxsQ29uc2VudGxlc3NBZFNsb3QsIHRydWUpO1xufTtcbmV4cG9ydCB7IGluaXRBcnRpY2xlQm9keUFkdmVydHMgfTtcbiIsImltcG9ydCB7IGNyZWF0ZUFkU2xvdCB9IGZyb20gJy4uLy4uLy4uL2xpYi9jcmVhdGUtYWQtc2xvdCc7XG5pbXBvcnQgZmFzdGRvbSBmcm9tICcuLi8uLi8uLi9saWIvZmFzdGRvbS1wcm9taXNlJztcbmltcG9ydCB7IGRlZmluZVNsb3QgfSBmcm9tICcuLi9kZWZpbmUtc2xvdCc7XG4vKipcbiAqIFRoaXMgaXMgcmVzcG9uc2libGUgZm9yIGluc2VydGluZyBhbiBfZXhjbHVzaW9uXyBhZCBzbG90IGludG8gdGhlIERPTVxuICpcbiAqIFRoaXMgaXMgYSBzcGVjaWFsIHR5cGUgb2YgYWQgd2hpY2gsIHdoZW4gZmlsbGVkLCBibG9ja3NcbiAqIGFsbCBvdGhlciBhZHMgb24gdGhlIHBhZ2UuIFRoaXMgYWxsb3dzIHVzIHRvIHJ1biBcImV4Y2x1c2lvblxuICogY2FtcGFpZ25zXCIgYWdhaW5zdCBjZXJ0YWluIGJyZWFraW5nIG5ld3MgcGFnZXMuXG4gKlxuICogRXhjbHVzaW9uIGFkcyBhcmUgdXNlZCBmb3IgY29uc2VudGxlc3MgYWR2ZXJ0aXNpbmcgb25seS5cbiAqIEdBTSBoYXMgYSBkaWZmZXJlbnQgbWVjaGFuaXNtIHRvIGFjaGlldmUgdGhlIHNhbWUgdGhpbmcuXG4gKi9cbmNvbnN0IGluaXRFeGNsdXNpb25TbG90ID0gYXN5bmMgKCkgPT4ge1xuICAgIGNvbnN0IGFkU2xvdCA9IGNyZWF0ZUFkU2xvdCgnZXhjbHVzaW9uJyk7XG4gICAgLy8gSW5zZXJ0IHRoZSBzbG90IGludG8gdGhlIGJvZHkgb2YgdGhlIHBhZ2VcbiAgICAvLyBJdCBkb2Vzbid0IHBhcnRpY3VsYXJseSBtYXR0ZXIgd2hlcmUgd2UgaW5zZXJ0IGl0LCBzaW5jZSBpdCBkb2Vzbid0IHJlbmRlciBhbnl0aGluZ1xuICAgIGF3YWl0IGZhc3Rkb20ubXV0YXRlKCgpID0+IGRvY3VtZW50LmJvZHkuYXBwZW5kQ2hpbGQoYWRTbG90KSk7XG4gICAgZGVmaW5lU2xvdChhZFNsb3QsICdleGNsdXNpb24nKTtcbn07XG5leHBvcnQgeyBpbml0RXhjbHVzaW9uU2xvdCB9O1xuIiwiaW1wb3J0IHsgZ2V0Q3VycmVudEJyZWFrcG9pbnQgfSBmcm9tICcuLi8uLi9saWIvZGV0ZWN0L2RldGVjdC1icmVha3BvaW50JztcbmltcG9ydCB7IHJlbW92ZURpc2FibGVkU2xvdHMgfSBmcm9tICcuLi9jb25zZW50ZWQvcmVtb3ZlLXNsb3RzJztcbmltcG9ydCB7IGRlZmluZVNsb3QgfSBmcm9tICcuL2RlZmluZS1zbG90JztcbmNvbnN0IGlzVGFibGV0T3JNb2JpbGUgPSAoKSA9PiB7XG4gICAgY29uc3QgYnJlYWtwb2ludCA9IGdldEN1cnJlbnRCcmVha3BvaW50KCk7XG4gICAgcmV0dXJuIGJyZWFrcG9pbnQgPT09ICdtb2JpbGUnIHx8IGJyZWFrcG9pbnQgPT09ICd0YWJsZXQnO1xufTtcbmNvbnN0IGluaXRGaXhlZFNsb3RzID0gYXN5bmMgKCkgPT4ge1xuICAgIGF3YWl0IHJlbW92ZURpc2FibGVkU2xvdHMoKTtcbiAgICAvLyBXZSByZW1vdmUgdG9wLWFib3ZlLW5hdiBvbiBib3RoIHRhYmxldCBhbmQgbW9iaWxlIGZvciBjb25zZW50bGVzc1xuICAgIC8vIGR1ZSB0byBpc3N1ZXMgd2l0aCBhZCBzaXppbmcgaW4gT3B0T3V0IGF0IHRoZSB0YWJsZXQgYnJlYWtwb2ludFxuICAgIGNvbnN0IGlzRENSTW9iaWxlT3JUYWJsZXQgPSB3aW5kb3cuZ3VhcmRpYW4uY29uZmlnLmlzRG90Y29tUmVuZGVyaW5nICYmIGlzVGFibGV0T3JNb2JpbGUoKTtcbiAgICBjb25zdCBhZHZlcnRzID0gW1xuICAgICAgICAuLi5kb2N1bWVudC5xdWVyeVNlbGVjdG9yQWxsKCcuanMtYWQtc2xvdDpub3QoLmFkLXNsb3QtLXN1cnZleSknKSxcbiAgICBdXG4gICAgICAgIC8vIHdlIG5lZWQgdG8gbm90IGluaXQgdG9wLWFib3ZlLW5hdiBvbiBtb2JpbGUgYW5kIHRhYmxldCB2aWV3IGluIERDUlxuICAgICAgICAvLyBhcyB0aGUgRE9NIGVsZW1lbnQgbmVlZHMgdG8gYmUgcmVtb3ZlZCBhbmQgcmVwbGFjZWQgdG8gYmUgaW5saW5lXG4gICAgICAgIC5maWx0ZXIoKGFkU2xvdCkgPT4gIShpc0RDUk1vYmlsZU9yVGFibGV0ICYmIGFkU2xvdC5pZCA9PT0gJ2RmcC1hZC0tdG9wLWFib3ZlLW5hdicpKTtcbiAgICBpZiAoZ2V0Q3VycmVudEJyZWFrcG9pbnQoKSA9PT0gJ3RhYmxldCcpIHtcbiAgICAgICAgLy8gV2UgbmVlZCB0byBleHBsaWNpdGx5IHJlbW92ZSB0aGUgZWxlbWVudCBhcyB0aGVyZSBhcmUgbm8gc3R5bGVzIHRvIGhpZGUgaXQgb24gdGFibGV0XG4gICAgICAgIGNvbnN0IHRvcEFib3ZlTmF2ID0gZG9jdW1lbnQucXVlcnlTZWxlY3RvcignLnRvcC1iYW5uZXItYWQtY29udGFpbmVyJyk7XG4gICAgICAgIHRvcEFib3ZlTmF2Py5yZW1vdmUoKTtcbiAgICB9XG4gICAgLy8gZGVmaW5lIHNsb3RzXG4gICAgYWR2ZXJ0cy5mb3JFYWNoKChzbG90RWxlbWVudCkgPT4ge1xuICAgICAgICBjb25zdCBzbG90TmFtZSA9IHNsb3RFbGVtZW50LmRhdGFzZXQubmFtZTtcbiAgICAgICAgY29uc3Qgc2xvdEtpbmQgPSBzbG90TmFtZT8uaW5jbHVkZXMoJ2lubGluZScpID8gJ2lubGluZScgOiB1bmRlZmluZWQ7XG4gICAgICAgIGlmIChzbG90TmFtZSkge1xuICAgICAgICAgICAgZGVmaW5lU2xvdChzbG90RWxlbWVudCwgc2xvdE5hbWUsIHNsb3RLaW5kKTtcbiAgICAgICAgfVxuICAgIH0pO1xuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcbn07XG5leHBvcnQgeyBpbml0Rml4ZWRTbG90cyB9O1xuIiwiaW1wb3J0IHsgbG9hZFNjcmlwdCwgbG9nIH0gZnJvbSAnQGd1YXJkaWFuL2xpYnMnO1xuaW1wb3J0IHsgY29tbWVyY2lhbEZlYXR1cmVzIH0gZnJvbSAnLi4vLi4vbGliL2NvbW1lcmNpYWwtZmVhdHVyZXMnO1xuaW1wb3J0IHsgaXNVc2VyTG9nZ2VkSW4gfSBmcm9tICcuLi8uLi9saWIvaWRlbnRpdHkvYXBpJztcbmltcG9ydCB7IGJ1aWxkUGFnZVRhcmdldGluZ0NvbnNlbnRsZXNzIH0gZnJvbSAnLi4vLi4vbGliL3RhcmdldGluZy9idWlsZC1wYWdlLXRhcmdldGluZy1jb25zZW50bGVzcyc7XG5mdW5jdGlvbiBpbml0Q29uc2VudGxlc3MoY29uc2VudFN0YXRlKSB7XG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG4gICAgICAgIC8vIFN0dWIgdGhlIGNvbW1hbmQgcXVldWVcbiAgICAgICAgLy8gQHRzLWV4cGVjdC1lcnJvciAtLSBpdOKAmXMgYSBzdHViLCBub3QgdGhlIHdob2xlIE9PIHRhZyBvYmplY3RcbiAgICAgICAgd2luZG93Lm9vdGFnID0ge1xuICAgICAgICAgICAgcXVldWU6IFtdLFxuICAgICAgICB9O1xuICAgICAgICB3aW5kb3cub290YWcucXVldWUucHVzaChmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgICAvLyBFbnN1cmVzIE9wdCBPdXQgbG9ncyBhcmUgbmFtZXNwYWNlZCB1bmRlciBDb21tZXJjaWFsXG4gICAgICAgICAgICB3aW5kb3cub290YWcubG9nZ2VyID0gKC4uLmFyZ3MpID0+IHtcbiAgICAgICAgICAgICAgICBsb2coJ2NvbW1lcmNpYWwnLCAnW09wdCBPdXQgQWRzXScsIC4uLmFyZ3MpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICAgIHdpbmRvdy5vb3RhZy5pbml0aWFsaXplT28oe1xuICAgICAgICAgICAgICAgIHB1Ymxpc2hlcjogMzMsXG4gICAgICAgICAgICAgICAgLy8gV2Ugc2V0IG91ciBvd24gY3VzdG9tIGxvZ2dlciBhYm92ZVxuICAgICAgICAgICAgICAgIG5vTG9nZ2luZzogMSxcbiAgICAgICAgICAgICAgICBhbHdheXNOb0NvbnNlbnQ6IDEsXG4gICAgICAgICAgICAgICAgbm9SZXF1ZXN0c09uUGFnZUxvYWQ6IDEsXG4gICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIHZvaWQgaXNVc2VyTG9nZ2VkSW4oKS50aGVuKChpc1NpZ25lZEluKSA9PiB7XG4gICAgICAgICAgICAgICAgT2JqZWN0LmVudHJpZXMoYnVpbGRQYWdlVGFyZ2V0aW5nQ29uc2VudGxlc3MoY29uc2VudFN0YXRlLCBjb21tZXJjaWFsRmVhdHVyZXMuYWRGcmVlLCBpc1NpZ25lZEluKSkuZm9yRWFjaCgoW2tleSwgdmFsdWVdKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGlmICghdmFsdWUpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICB3aW5kb3cub290YWcuYWRkUGFyYW1ldGVyKGtleSwgdmFsdWUpO1xuICAgICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICB9KTtcbiAgICAgICAgdm9pZCBsb2FkU2NyaXB0KCcvL2Nkbi5vcHRvdXRhZHZlcnRpc2luZy5jb20vc2NyaXB0L29vZ3VhcmRpYW4udjQubWluLmpzJyk7XG4gICAgfSk7XG59XG5leHBvcnQgeyBpbml0Q29uc2VudGxlc3MgfTtcbiIsImltcG9ydCBmYXN0ZG9tIGZyb20gJy4uLy4uL2xpYi9mYXN0ZG9tLXByb21pc2UnO1xuY29uc3Qgc2hvdWxkUmVuZGVyQ29uc2VudGxlc3NMYWJlbCA9IChhZFNsb3ROb2RlKSA9PiB7XG4gICAgaWYgKGFkU2xvdE5vZGUuY2xhc3NMaXN0LmNvbnRhaW5zKCdhZC1zbG90LS1mcmFtZScpIHx8XG4gICAgICAgIGFkU2xvdE5vZGUuY2xhc3NMaXN0LmNvbnRhaW5zKCdhZC1zbG90LS1nYycpIHx8XG4gICAgICAgIGFkU2xvdE5vZGUuY2xhc3NMaXN0LmNvbnRhaW5zKCd1LWgnKSB8fFxuICAgICAgICBhZFNsb3ROb2RlLmNsYXNzTGlzdC5jb250YWlucygnYWQtc2xvdC0tbm8tbGFiZWwnKSB8fFxuICAgICAgICAvLyBzZXQgZm9yIG91dC1vZi1wYWdlICgxeDEpIGFuZCBlbXB0eSAoMngyKSBhZHNcbiAgICAgICAgYWRTbG90Tm9kZS5jbGFzc0xpc3QuY29udGFpbnMoJ2FkLXNsb3QtLWNvbGxhcHNlJykgfHxcbiAgICAgICAgYWRTbG90Tm9kZS5nZXRBdHRyaWJ1dGUoJ2RhdGEtbGFiZWwnKSA9PT0gJ2ZhbHNlJykge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHJldHVybiB0cnVlO1xufTtcbmV4cG9ydCBjb25zdCByZW5kZXJDb25zZW50bGVzc0FkdmVydExhYmVsID0gKGFkU2xvdE5vZGUpID0+IHtcbiAgICByZXR1cm4gZmFzdGRvbS5tZWFzdXJlKCgpID0+IHtcbiAgICAgICAgaWYgKHNob3VsZFJlbmRlckNvbnNlbnRsZXNzTGFiZWwoYWRTbG90Tm9kZSkpIHtcbiAgICAgICAgICAgIC8vQXNzaWduaW5nIHRoZSBhZCBsYWJlbCB0ZXh0IGxpa2UgdGhpcyBhbGxvd3MgdXMgdG8gY29uZGl0aW9uYWxseSBhZGQgZXh0cmEgdGV4dCB0byBpdFxuICAgICAgICAgICAgLy9lZy4gZm9yIHRoZSBhZCB0ZXN0IGxhYmVsbGluZyBmb3IgZ29vZ2xlIGFkc1xuICAgICAgICAgICAgY29uc3QgYWRMYWJlbENvbnRlbnQgPSBgQWR2ZXJ0aXNlbWVudGA7XG4gICAgICAgICAgICByZXR1cm4gZmFzdGRvbS5tdXRhdGUoKCkgPT4ge1xuICAgICAgICAgICAgICAgIC8vd2hlbiB0aGUgdGltZSBjb21lcyB0byB1c2UgYSBkaWZmZXJlbnQgYWQgbGFiZWwgZm9yIGNvbnNlbnRsZXNzLCB3ZSBjYW4gdXBkYXRlXG4gICAgICAgICAgICAgICAgLy90aGUgYXR0cmlidXRlIG5hbWUgdGhhdCB3ZSBzZXQgYmVsb3cgYW5kIGFkZCBhIGNzcyBzZWxlY3RvciBhY2NvcmRpbmdseVxuICAgICAgICAgICAgICAgIGFkU2xvdE5vZGUuc2V0QXR0cmlidXRlKCdkYXRhLWxhYmVsLXNob3cnLCAndHJ1ZScpO1xuICAgICAgICAgICAgICAgIGFkU2xvdE5vZGUuc2V0QXR0cmlidXRlKCdhZC1sYWJlbC10ZXh0JywgYWRMYWJlbENvbnRlbnQpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgpO1xuICAgIH0pO1xufTtcbi8vIFRPRE86IGZsZXNoIG91dCB0aGlzIGZ1bmN0aW9uIG9uY2Ugd2UgaGF2ZSBhIGJldHRlciBpZGVhIG9mIHdoYXQgd2Ugd2FudCBpdCB0byBsb29rIGxpa2Vcbi8vIGNvbnN0IGluc2VydENvbnNlbnRsZXNzTGFiZWxJbmZvID0gKGFkTGFiZWxOb2RlOiBIVE1MRWxlbWVudCk6IHZvaWQgPT4ge1xuLy8gXHRjb25zdCBjb25zZW50bGVzc0xhYmVsSW5mbyA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2J1dHRvbicpO1xuLy8gXHRjb25zZW50bGVzc0xhYmVsSW5mby5jbGFzc05hbWUgPSAnYWQtc2xvdF9fY29uc2VudGxlc3MtaW5mbyB1LWJ1dHRvbi1yZXNldCc7XG4vLyBcdGNvbnNlbnRsZXNzTGFiZWxJbmZvLnNldEF0dHJpYnV0ZShcbi8vIFx0XHQndGl0bGUnLFxuLy8gXHRcdGBCZWNhdXNlIG9mIHlvdXIgY2hvaWNlIHRoaXMgYWR2ZXJ0aXNpbmcgc2V0cyBubyBjb29raWVzIGFuZCBkb2Vzbid0IHRyYWNrIHlvdS5gLFxuLy8gXHQpO1xuLy8gXHRjb25zZW50bGVzc0xhYmVsSW5mby5pbm5lckhUTUwgPSBgT3B0IE91dDogV2h5IGFtIEkgc2VlaW5nIHRoaXM/YDtcbi8vIFx0YWRMYWJlbE5vZGUuYXBwZW5kQ2hpbGQoY29uc2VudGxlc3NMYWJlbEluZm8pO1xuLy8gfTtcbiIsImltcG9ydCB7IGJ1aWxkUGFnZVRhcmdldGluZywgfSBmcm9tICdAZ3VhcmRpYW4vY29tbWVyY2lhbC1jb3JlL3RhcmdldGluZy9idWlsZC1wYWdlLXRhcmdldGluZyc7XG5jb25zdCBjb25zZW50bGVzc1RhcmdldGluZ0tleXMgPSBbXG4gICAgJ2FiJyxcbiAgICAnYXQnLFxuICAgICdibCcsXG4gICAgJ2JwJyxcbiAgICAnYnInLFxuICAgICdjYycsXG4gICAgJ2xoJyxcbiAgICAnY3QnLFxuICAgICdkY3JlJyxcbiAgICAnZWRpdGlvbicsXG4gICAgJ2ZpcnN0dmlzaXQnLFxuICAgICdrJyxcbiAgICAncmMnLFxuICAgICdycCcsXG4gICAgJ3MnLFxuICAgICdzZScsXG4gICAgJ3NlbnMnLFxuICAgICdzaCcsXG4gICAgJ3NpJyxcbiAgICAnc2tpbnNpemUnLFxuICAgICdzdScsXG4gICAgJ3RuJyxcbiAgICAndXJsJyxcbiAgICAndXJsa3cnLFxuXTtcbmNvbnN0IGlzQ29uc2VudGxlc3NLZXkgPSAoa2V5KSA9PiBjb25zZW50bGVzc1RhcmdldGluZ0tleXMuaW5jbHVkZXMoa2V5KTtcbi8qKlxuICogQ2FsbCBidWlsZFBhZ2VUYXJnZXRpbmcgdGhlbiBmaWx0ZXIgb3V0IHRoZSBrZXlzIHRoYXQgYXJlIG5vdCBuZWVkZWQgZm9yXG4gKiBjb25zZW50bGVzcyB0YXJnZXRpbmcuXG4gKlxuICogQHBhcmFtICB7Q29uc2VudFN0YXRlfSBjb25zZW50U3RhdGVcbiAqIEBwYXJhbSAge2Jvb2xlYW59IGFkRnJlZVxuICogQHBhcmFtICB7Ym9vbGVhbn0gaXNTaWduZWRJblxuICogQHJldHVybnMgQ29uc2VudGxlc3NQYWdlVGFyZ2V0aW5nXG4gKi9cbmNvbnN0IGJ1aWxkUGFnZVRhcmdldGluZ0NvbnNlbnRsZXNzID0gKGNvbnNlbnRTdGF0ZSwgYWRGcmVlLCBpc1NpZ25lZEluKSA9PiB7XG4gICAgY29uc3QgY29uc2VudGVkUGFnZVRhcmdldGluZyA9IGJ1aWxkUGFnZVRhcmdldGluZyh7XG4gICAgICAgIGFkRnJlZSxcbiAgICAgICAgY29uc2VudFN0YXRlLFxuICAgICAgICBjbGllbnRTaWRlUGFydGljaXBhdGlvbnM6IHt9LFxuICAgICAgICBpc1NpZ25lZEluLFxuICAgIH0pO1xuICAgIHJldHVybiBPYmplY3QuZnJvbUVudHJpZXMoT2JqZWN0LmVudHJpZXMoY29uc2VudGVkUGFnZVRhcmdldGluZykuZmlsdGVyKChba10pID0+IGlzQ29uc2VudGxlc3NLZXkoaykpKTtcbn07XG5leHBvcnQgeyBidWlsZFBhZ2VUYXJnZXRpbmdDb25zZW50bGVzcyB9O1xuIl0sIm5hbWVzIjpbImluaXQiLCJpbml0TWVzc2VuZ2VyIiwiYmFja2dyb3VuZCIsInJlc2l6ZSIsInR5cGUiLCJpbml0QXJ0aWNsZUJvZHlBZHZlcnRzIiwiaW5pdEV4Y2x1c2lvblNsb3QiLCJpbml0Rml4ZWRTbG90cyIsImluaXRDb25zZW50bGVzcyIsInJlbG9hZFBhZ2VPbkNvbnNlbnRDaGFuZ2UiLCJzZXRBZFRlc3RDb29raWUiLCJzZXRBZFRlc3RJbkxhYmVsc0Nvb2tpZSIsImJvb3RDb25zZW50bGVzcyIsIl9yZWYiLCJfYXN5bmNUb0dlbmVyYXRvciIsImNvbnNlbnRTdGF0ZSIsImNvbnNlbnRsZXNzTW9kdWxlTGlzdCIsIlByb21pc2UiLCJhbGwiLCJ3aW5kb3ciLCJvb3RhZyIsIm1ha2VSZXF1ZXN0cyIsIl94IiwiYXBwbHkiLCJhcmd1bWVudHMiLCJsb2ciLCJmYXN0ZG9tIiwicmVtb3ZlU2xvdEZyb21Eb20iLCJyZW5kZXJDb25zZW50bGVzc0FkdmVydExhYmVsIiwiZGVmaW5lU2xvdCIsInNsb3QiLCJzbG90TmFtZSIsInNsb3RLaW5kIiwic2xvdElkIiwiaWQiLCJmaWxsZWRDYWxsYmFjayIsIl9hZFNsb3QiLCJ3aWR0aCIsImhlaWdodCIsIm9wdE91dEV4dCIsImNvbmNhdCIsImlzRmx1aWQiLCJjbGFzc0xpc3QiLCJhZGQiLCJ0YWdzIiwiaW5jbHVkZXMiLCJlbXB0eUNhbGxiYWNrIiwibXV0YXRlIiwicXVldWUiLCJwdXNoIiwiYWRkUGFyYW1ldGVyRm9yU2xvdCIsImFkU2xvdCIsInRhcmdldElkIiwiYWRkSW5saW5lQWRzIiwiY29tbWVyY2lhbEZlYXR1cmVzIiwiZ2V0Q3VycmVudEJyZWFrcG9pbnQiLCJmaWxsQ29uc2VudGxlc3NBZFNsb3QiLCJuYW1lIiwiaXNNb2JpbGUiLCJyZXNvbHZlIiwiYXJ0aWNsZUJvZHlBZHZlcnRzIiwiY3JlYXRlQWRTbG90IiwiZG9jdW1lbnQiLCJib2R5IiwiYXBwZW5kQ2hpbGQiLCJyZW1vdmVEaXNhYmxlZFNsb3RzIiwiaXNUYWJsZXRPck1vYmlsZSIsImJyZWFrcG9pbnQiLCJpc0RDUk1vYmlsZU9yVGFibGV0IiwiZ3VhcmRpYW4iLCJjb25maWciLCJpc0RvdGNvbVJlbmRlcmluZyIsImFkdmVydHMiLCJxdWVyeVNlbGVjdG9yQWxsIiwiZmlsdGVyIiwidG9wQWJvdmVOYXYiLCJxdWVyeVNlbGVjdG9yIiwicmVtb3ZlIiwiZm9yRWFjaCIsInNsb3RFbGVtZW50IiwiZGF0YXNldCIsInVuZGVmaW5lZCIsImxvYWRTY3JpcHQiLCJpc1VzZXJMb2dnZWRJbiIsImJ1aWxkUGFnZVRhcmdldGluZ0NvbnNlbnRsZXNzIiwibG9nZ2VyIiwiX2xlbiIsImxlbmd0aCIsImFyZ3MiLCJBcnJheSIsIl9rZXkiLCJpbml0aWFsaXplT28iLCJwdWJsaXNoZXIiLCJub0xvZ2dpbmciLCJhbHdheXNOb0NvbnNlbnQiLCJub1JlcXVlc3RzT25QYWdlTG9hZCIsInRoZW4iLCJpc1NpZ25lZEluIiwiT2JqZWN0IiwiZW50cmllcyIsImFkRnJlZSIsImtleSIsInZhbHVlIiwiYWRkUGFyYW1ldGVyIiwic2hvdWxkUmVuZGVyQ29uc2VudGxlc3NMYWJlbCIsImFkU2xvdE5vZGUiLCJjb250YWlucyIsImdldEF0dHJpYnV0ZSIsIm1lYXN1cmUiLCJhZExhYmVsQ29udGVudCIsInNldEF0dHJpYnV0ZSIsImJ1aWxkUGFnZVRhcmdldGluZyIsImNvbnNlbnRsZXNzVGFyZ2V0aW5nS2V5cyIsImlzQ29uc2VudGxlc3NLZXkiLCJjb25zZW50ZWRQYWdlVGFyZ2V0aW5nIiwiY2xpZW50U2lkZVBhcnRpY2lwYXRpb25zIiwiZnJvbUVudHJpZXMiLCJrIl0sInNvdXJjZVJvb3QiOiIifQ==