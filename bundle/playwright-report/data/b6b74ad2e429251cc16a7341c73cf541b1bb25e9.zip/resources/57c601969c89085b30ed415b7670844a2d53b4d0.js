"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(self["webpackChunk_guardian_dotcom_rendering"] = self["webpackChunk_guardian_dotcom_rendering"] || []).push([["FooterLabel-importable"],{

/***/ "./src/components/FooterLabel.importable.tsx":
/*!***************************************************!*\
  !*** ./src/components/FooterLabel.importable.tsx ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   FooterLabel: () => (/* binding */ FooterLabel)\n/* harmony export */ });\n/* harmony import */ var _emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react/jsx-dev-runtime */ \"../node_modules/.pnpm/@emotion+react@11.14.0_@types+react@18.3.1_react@18.3.1/node_modules/@emotion/react/jsx-dev-runtime/dist/emotion-react-jsx-dev-runtime.browser.development.esm.js\");\n/* harmony import */ var _lib_useShouldAdapt__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../lib/useShouldAdapt */ \"./src/lib/useShouldAdapt.ts\");\n\n\n/**\n * Choose the correct label for the footer, which may indicate\n * that the page was adapted.\n *\n * ## Why does this need to be an Island?\n *\n * Deciding on whether to adapt can only be determined client-side.\n */ const FooterLabel = ()=>{\n    const adapted = (0,_lib_useShouldAdapt__WEBPACK_IMPORTED_MODULE_1__.useShouldAdapt)();\n    return adapted ? /*#__PURE__*/ (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: \"(dcr, adapted)\"\n    }, void 0, false) : /*#__PURE__*/ (0,_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: \"(dcr)\"\n    }, void 0, false);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvY29tcG9uZW50cy9Gb290ZXJMYWJlbC5pbXBvcnRhYmxlLnRzeCIsIm1hcHBpbmdzIjoiOzs7Ozs7O0FBQUE7QUFFQTs7Ozs7OztBQU9BO0FBRUE7QUFFQTtBQUFBO0FBQUE7QUFBQTs7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL0BndWFyZGlhbi9kb3Rjb20tcmVuZGVyaW5nLy4vc3JjL2NvbXBvbmVudHMvRm9vdGVyTGFiZWwuaW1wb3J0YWJsZS50c3g/NjUzYiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VTaG91bGRBZGFwdCB9IGZyb20gJy4uL2xpYi91c2VTaG91bGRBZGFwdCc7XG5cbi8qKlxuICogQ2hvb3NlIHRoZSBjb3JyZWN0IGxhYmVsIGZvciB0aGUgZm9vdGVyLCB3aGljaCBtYXkgaW5kaWNhdGVcbiAqIHRoYXQgdGhlIHBhZ2Ugd2FzIGFkYXB0ZWQuXG4gKlxuICogIyMgV2h5IGRvZXMgdGhpcyBuZWVkIHRvIGJlIGFuIElzbGFuZD9cbiAqXG4gKiBEZWNpZGluZyBvbiB3aGV0aGVyIHRvIGFkYXB0IGNhbiBvbmx5IGJlIGRldGVybWluZWQgY2xpZW50LXNpZGUuXG4gKi9cbmV4cG9ydCBjb25zdCBGb290ZXJMYWJlbCA9ICgpID0+IHtcblx0Y29uc3QgYWRhcHRlZCA9IHVzZVNob3VsZEFkYXB0KCk7XG5cblx0cmV0dXJuIGFkYXB0ZWQgPyA8PihkY3IsIGFkYXB0ZWQpPC8+IDogPD4oZGNyKTwvPjtcbn07XG4iXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./src/components/FooterLabel.importable.tsx\n\n}");

/***/ }),

/***/ "./src/lib/useShouldAdapt.ts":
/*!***********************************!*\
  !*** ./src/lib/useShouldAdapt.ts ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("{__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   useShouldAdapt: () => (/* binding */ useShouldAdapt)\n/* harmony export */ });\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ \"../node_modules/.pnpm/preact@10.15.1/node_modules/preact/compat/dist/compat.module.js\");\n/* harmony import */ var _client_adaptiveSite__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../client/adaptiveSite */ \"./src/client/adaptiveSite.ts\");\n\n\n/**\n * A hook that reports whether we should adapt the current page\n * to address poor performance issues\n */ const useShouldAdapt = ()=>{\n    const [shouldAdapt, setShouldAdapt] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);\n    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{\n        void (0,_client_adaptiveSite__WEBPACK_IMPORTED_MODULE_1__.shouldAdapt)().then(setShouldAdapt);\n    }, []);\n    return shouldAdapt;\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zcmMvbGliL3VzZVNob3VsZEFkYXB0LnRzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFBO0FBQ0E7QUFFQTs7O0FBR0E7QUFFQTtBQUVBO0FBQ0E7QUFDQTtBQUVBO0FBQ0EiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9AZ3VhcmRpYW4vZG90Y29tLXJlbmRlcmluZy8uL3NyYy9saWIvdXNlU2hvdWxkQWRhcHQudHM/ZmIwZSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VFZmZlY3QsIHVzZVN0YXRlIH0gZnJvbSAncmVhY3QnO1xuaW1wb3J0IHsgc2hvdWxkQWRhcHQgYXMgY2hlY2tTaG91bGRBZGFwdCB9IGZyb20gJy4uL2NsaWVudC9hZGFwdGl2ZVNpdGUnO1xuXG4vKipcbiAqIEEgaG9vayB0aGF0IHJlcG9ydHMgd2hldGhlciB3ZSBzaG91bGQgYWRhcHQgdGhlIGN1cnJlbnQgcGFnZVxuICogdG8gYWRkcmVzcyBwb29yIHBlcmZvcm1hbmNlIGlzc3Vlc1xuICovXG5leHBvcnQgY29uc3QgdXNlU2hvdWxkQWRhcHQgPSAoKTogYm9vbGVhbiA9PiB7XG5cdGNvbnN0IFtzaG91bGRBZGFwdCwgc2V0U2hvdWxkQWRhcHRdID0gdXNlU3RhdGUoZmFsc2UpO1xuXG5cdHVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0dm9pZCBjaGVja1Nob3VsZEFkYXB0KCkudGhlbihzZXRTaG91bGRBZGFwdCk7XG5cdH0sIFtdKTtcblxuXHRyZXR1cm4gc2hvdWxkQWRhcHQ7XG59O1xuIl0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./src/lib/useShouldAdapt.ts\n\n}");

/***/ })

}]);